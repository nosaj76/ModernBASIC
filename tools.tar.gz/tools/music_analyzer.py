#!/usr/bin/env python3
"""
Music Analyzer — standalone tool for analyzing audio and aiding BASIC music composition.

Combines algorithms from six studied open-source projects with ModernBASIC's
existing spectrum_analyzer.py and spectrum_compare.py:

  - Key detection (Krumhansl-Schmuckler)         from musical-key-finder
  - Chord identification (interval analysis)     from MusicAnalyser
  - Tempo/BPM + beat tracking                     from all-in-one + Essentia
  - Pitch detection (PredominantPitchMelodia)    from spectrum_analyzer (Essentia)
  - Chromagram extraction (CQT)                  from musical-key-finder (librosa)
  - Spectral fingerprinting concept               from SongRec
  - Camelot key compatibility                    from music-similarity
  - HPS harmonic product spectrum                from MusicAnalyser
  - Note-to-frequency mapping                     from MusicAnalyser
  - Autocorrelation pitch detection              from spectrum_compare
  - BASIC transcription output                   from spectrum_analyzer

Usage:
  python3 music_analyzer.py song.wav                Full analysis
  python3 music_analyzer.py song.wav key            Key only
  python3 music_analyzer.py song.wav chords         Chord progression
  python3 music_analyzer.py song.wav tempo          Tempo + beats
  python3 music_analyzer.py song.wav pitch          Pitch timeline
  python3 music_analyzer.py song.wav spectrum       Spectral profile
  python3 music_analyzer.py song.wav instrument     Instrument synthesis profile
  python3 music_analyzer.py song.wav basic          BASIC transcription
  python3 music_analyzer.py song.wav camelot key1   Camelot compatibility
  python3 music_analyzer.py --compare a.wav b.wav  Compare two files
"""
import sys, math, wave, struct, os
from collections import Counter

import numpy as np

try:
    import librosa
    HAS_LIBROSA = True
except ImportError:
    HAS_LIBROSA = False

try:
    import essentia.standard as es
    HAS_ESSENTIA = True
except ImportError:
    HAS_ESSENTIA = False

try:
    from scipy.signal import find_peaks
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False

# ═══════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════

NOTES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
NOTES_FLAT = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B']

# Krumhansl-Schmuckler key profiles (from musical-key-finder)
KRUMHANSL_MAJ = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
KRUMHANSL_MIN = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]

# Camelot wheel (from music-similarity) — harmonic mixing compatibility
CAMELOT_WHEEL = {
    'Ab major': '1B', 'A minor': '1A',
    'Db major': '2B', 'D# minor': '2A',
    'A major': '3B', 'F minor': '3A',
    'E major': '4B', 'G# minor': '4A',
    'B major': '5B', 'C# minor': '5A',
    'F# major': '6B', 'D# minor': '6A',
    'Db major': '6B', 'A# minor': '6A',
    'C# major': '7B', 'A# minor': '7A',
    'G# major': '8B', 'F minor': '8A',
    'D# major': '9B', 'A# minor': '9A',
    'A# major': '10B', 'G minor': '10A',
    'F major': '11B', 'D minor': '11A',
    'C major': '12B', 'E minor': '12A',
    'G major': '1B', 'A minor': '1A',
    'D major': '2B', 'B minor': '2A',
    'Eb major': '3B', 'C minor': '3A',
    'Bb major': '4B', 'G minor': '4A',
    'F major': '5B', 'D minor': '5A',
    'C major': '6B', 'A minor': '6A',
    'G major': '7B', 'E minor': '7A',
    'D major': '8B', 'B minor': '8A',
    'A major': '9B', 'F# minor': '9A',
    'E major': '10B', 'C# minor': '10A',
    'B major': '11B', 'G# minor': '11A',
    'F# major': '12B', 'D# minor': '12A',
}

# Note frequency table (from MusicAnalyser)
NOTE_FREQS = {
    32.70: 'C', 34.65: 'Db', 36.71: 'D', 38.89: 'Eb', 41.20: 'E',
    43.65: 'F', 46.25: 'Gb', 49.00: 'G', 51.91: 'Ab', 55.00: 'A',
    58.27: 'Bb', 61.74: 'B'
}

# Scale tables (from MusicAnalyser)
SCALES = [
    'C', 'D', 'E', 'F', 'G', 'A', 'B',
    'Db', 'Eb', 'F', 'Gb', 'Ab', 'Bb', 'C',
    'D', 'E', 'Gb', 'G', 'A', 'B', 'Db',
    'Eb', 'F', 'G', 'Ab', 'Bb', 'C', 'D',
    'E', 'Gb', 'Ab', 'A', 'B', 'Db', 'Eb',
    'F', 'G', 'A', 'Bb', 'C', 'D', 'E',
    'Gb', 'Ab', 'Bb', 'B', 'Db', 'Eb', 'F',
    'G', 'A', 'B', 'C', 'D', 'E', 'Gb',
    'Ab', 'Bb', 'C', 'Db', 'Eb', 'F', 'G',
    'A', 'B', 'Db', 'D', 'E', 'Gb', 'Ab',
    'Bb', 'C', 'D', 'Eb', 'F', 'G', 'A',
    'B', 'Db', 'Eb', 'E', 'Gb', 'Ab', 'Bb'
]

# ═══════════════════════════════════════════════════════════════
# AUDIO LOADING
# ═══════════════════════════════════════════════════════════════

def load_audio(path, max_seconds=None, sr=44100):
    """Load audio file as mono numpy array. Uses librosa if available, else wave."""
    if HAS_LIBROSA:
        audio, sr = librosa.load(path, sr=sr, mono=True)
        if max_seconds:
            audio = audio[:sr * max_seconds]
        return audio, sr

    # Fallback: raw WAV reading (from spectrum_compare.py)
    w = wave.open(path, 'rb')
    sr = w.getframerate()
    ch = w.getnchannels()
    n = w.getnframes()
    sw = w.getsampwidth()
    if max_seconds:
        n = min(n, sr * max_seconds)
    raw = w.readframes(n)
    w.close()

    if sw == 2:
        samples = struct.unpack(f'<{len(raw)//2}h', raw)
    elif sw == 4:
        samples = struct.unpack(f'<{len(raw)//4}i', raw)
    else:
        samples = struct.unpack(f'<{len(raw)}b', raw)

    if ch == 2:
        mono = np.array([(samples[i] + samples[i+1]) / 2.0 for i in range(0, len(samples), 2)], dtype=np.float32)
    else:
        mono = np.array(samples, dtype=np.float32)

    # Normalize to [-1, 1]
    if sw == 2:
        mono /= 32768.0
    elif sw == 1:
        mono /= 128.0
    elif sw == 4:
        mono /= 2147483648.0

    return mono, sr

# ═══════════════════════════════════════════════════════════════
# KEY DETECTION (Krumhansl-Schmuckler)
# Adapted from musical-key-finder-master
# ═══════════════════════════════════════════════════════════════

def detect_key(audio, sr):
    """Detect musical key using Krumhansl-Schmuckler correlation algorithm."""
    if not HAS_LIBROSA:
        return _detect_key_essentia(audio, sr)

    # HPSS for harmonic separation (improves accuracy)
    y_harmonic, _ = librosa.effects.hpss(audio)

    # Chromagram via CQT
    chroma = librosa.feature.chroma_cqt(y=y_harmonic, sr=sr, bins_per_octave=24)

    # Sum each pitch class
    chroma_vals = np.sum(chroma, axis=1)

    # Correlate against all 24 keys
    best_key = None
    best_corr = -1
    alt_key = None
    alt_corr = -1
    all_corrs = {}

    for i in range(12):
        rotated = np.roll(chroma_vals, -i)

        corr_maj = np.corrcoef(KRUMHANSL_MAJ, rotated)[0, 1]
        corr_min = np.corrcoef(KRUMHANSL_MIN, rotated)[0, 1]

        key_maj = f"{NOTES[i]} major"
        key_min = f"{NOTES[i]} minor"
        all_corrs[key_maj] = corr_maj
        all_corrs[key_min] = corr_min

        if corr_maj > best_corr:
            best_corr = corr_maj
            best_key = key_maj
        if corr_min > best_corr:
            best_corr = corr_min
            best_key = key_min

    # Find alternative key (within 90% of best)
    for key, corr in all_corrs.items():
        if corr > best_corr * 0.9 and corr != best_corr and corr > alt_corr:
            alt_key = key
            alt_corr = corr

    # Scale notes for the detected key
    root = best_key.split(' ')[0]
    mode = best_key.split(' ')[1]
    scale_notes = _get_scale_notes(root, mode)

    return {
        'key': best_key,
        'correlation': best_corr,
        'alt_key': alt_key,
        'alt_correlation': alt_corr,
        'chroma': chroma_vals,
        'scale_notes': scale_notes,
        'all_correlations': dict(sorted(all_corrs.items(), key=lambda x: -x[1]))
    }

def _detect_key_essentia(audio, sr):
    """Fallback key detection using Essentia."""
    if not HAS_ESSENTIA:
        return {'key': 'unknown', 'correlation': 0, 'alt_key': None,
                'chroma': np.zeros(12), 'scale_notes': [], 'all_correlations': {}}

    key_detector = es.Key(sampleRate=sr)
    key, scale, strength = key_detector(audio)
    detected = f"{key} {scale}"
    return {
        'key': detected,
        'correlation': strength,
        'alt_key': None,
        'alt_correlation': 0,
        'chroma': np.zeros(12),
        'scale_notes': _get_scale_notes(key, scale),
        'all_correlations': {detected: strength}
    }

def _get_scale_notes(root, mode):
    """Get the 7 notes of a scale given root and mode."""
    root_idx = NOTES.index(root) if root in NOTES else NOTES_FLAT.index(root)
    if mode == 'major':
        intervals = [0, 2, 4, 5, 7, 9, 11]
    else:
        intervals = [0, 2, 3, 5, 7, 8, 10]
    return [NOTES[(root_idx + i) % 12] for i in intervals]

# ═══════════════════════════════════════════════════════════════
# CHORD DETECTION
# Adapted from MusicAnalyser-master (Music.cs)
# ═══════════════════════════════════════════════════════════════

def get_chord_quality(intervals):
    """
    Identify chord quality from pitch-class intervals.
    Ported from MusicAnalyser Music.cs GetChordQuality.
    intervals: list of semitone distances from root (0-11).
    Returns chord name string.
    """
    intervals = sorted(set(intervals))
    fifth_omitted = 0

    while fifth_omitted <= 1:
        if 4 in intervals and 7 in intervals:
            remaining = [x for x in intervals if x not in (4, 7)]
            # Major chord
            if 2 in remaining:
                remaining = [x for x in remaining if x != 2]
                if 9 in remaining:
                    return "6/9" + _add_extensions([x for x in remaining if x != 9])
                if 10 in remaining:
                    remaining2 = [x for x in remaining if x != 10]
                    if 5 in remaining2:
                        return "11" + _add_extensions([x for x in remaining2 if x != 5])
                    return "9" + _add_extensions(remaining2)
                if 11 in remaining:
                    remaining2 = [x for x in remaining if x != 11]
                    if 9 in remaining2:
                        return "maj13" + _add_extensions([x for x in remaining2 if x != 9])
                    return "maj9" + _add_extensions(remaining2)
                return "add9" + _add_extensions(remaining)
            if 9 in remaining:
                return "6" + _add_extensions([x for x in remaining if x != 9])
            if 10 in remaining:
                remaining2 = [x for x in remaining if x != 10]
                if 1 in remaining2:
                    return "7b9" + _add_extensions([x for x in remaining2 if x != 1])
                if 3 in remaining2:
                    return "7#9" + _add_extensions([x for x in remaining2 if x != 3])
                return "7" + _add_extensions(remaining2)
            if 11 in remaining:
                return "maj7" + _add_extensions([x for x in remaining if x != 11])
            return "" + _add_extensions(remaining)

        if 3 in intervals and 7 in intervals:
            remaining = [x for x in intervals if x not in (3, 7)]
            if 9 in remaining:
                return "m6" + _add_extensions([x for x in remaining if x != 9])
            if 10 in remaining:
                remaining2 = [x for x in remaining if x != 10]
                if 2 in remaining2:
                    return "m9" + _add_extensions([x for x in remaining2 if x != 2])
                return "m7" + _add_extensions(remaining2)
            if 11 in remaining:
                return "mM7" + _add_extensions([x for x in remaining if x != 11])
            return "m" + _add_extensions(remaining)

        if 2 in intervals and 7 in intervals:
            remaining = [x for x in intervals if x not in (2, 7)]
            if 10 in remaining:
                remaining2 = [x for x in remaining if x != 10]
                if 2 in remaining2:
                    if 5 in remaining2:
                        return "9sus2" + _add_extensions([x for x in remaining2 if x != 5])
                    return "7sus2" + _add_extensions(remaining2)
            return "sus2" + _add_extensions(remaining)

        if 5 in intervals and 7 in intervals:
            remaining = [x for x in intervals if x not in (5, 7)]
            if 10 in remaining:
                remaining2 = [x for x in remaining if x != 10]
                if 2 in remaining2:
                    if 5 in remaining2:
                        return "9sus4" + _add_extensions([x for x in remaining2 if x != 5])
                    return "7sus4" + _add_extensions(remaining2)
            return "sus4" + _add_extensions(remaining)

        if 3 in intervals and 6 in intervals:
            remaining = [x for x in intervals if x not in (3, 6)]
            if 9 in remaining:
                return "dim7" + _add_extensions([x for x in remaining if x != 9])
            if 10 in remaining:
                return "m7b5" + _add_extensions([x for x in remaining if x != 10])
            return "dim" + _add_extensions(remaining)

        if 4 in intervals and 8 in intervals:
            return "aug" + _add_extensions([x for x in intervals if x not in (4, 8)])

        if 7 in intervals and len(intervals) == 1 and fifth_omitted == 0:
            return "5"

        intervals = intervals + [7]
        fifth_omitted += 1

    return "N/A"

def _add_extensions(intervals):
    """Format remaining chord extensions (from MusicAnalyser AddRemainingNotes)."""
    if not intervals:
        return ""
    names = {1: 'b9', 2: '9', 3: '#9', 4: 'b11', 5: '11',
             6: '#11', 8: '#5', 9: '6', 10: 'm7', 11: 'maj7'}
    parts = [names.get(i, str(i)) for i in intervals]
    return " (" + ", ".join(parts) + ")"

def detect_chords(audio, sr, hop_seconds=0.5, window_seconds=2.0):
    """
    Detect chord progression over time.
    Uses chromagram windows and interval analysis.
    """
    if not HAS_LIBROSA:
        return _detect_chords_simple(audio, sr)

    y_harmonic, _ = librosa.effects.hpss(audio)
    chroma = librosa.feature.chroma_cqt(y=y_harmonic, sr=sr, bins_per_octave=24)

    hop_frames = int(hop_seconds * sr / 512)
    window_frames = int(window_seconds * sr / 512)

    chords = []
    for i in range(0, chroma.shape[1] - window_frames, hop_frames):
        t = i * 512 / sr
        frame_chroma = np.mean(chroma[:, i:i+window_frames], axis=1)

        # Find root (strongest pitch class)
        root_idx = np.argmax(frame_chroma)

        # Build intervals from root (skip 0 which is the root itself)
        # Use higher threshold to avoid noise leakage from adjacent semitones
        max_chroma = np.max(frame_chroma)
        intervals = []
        for j in range(1, 12):
            if frame_chroma[(root_idx + j) % 12] > 0.5 * max_chroma:
                intervals.append(j)

        quality = get_chord_quality(intervals)
        chord_name = f"{NOTES[root_idx]}{quality}"

        # Skip if too weak
        if np.max(frame_chroma) < 0.1:
            chord_name = "N/C"

        chords.append((t, chord_name, frame_chroma[root_idx]))

    # Collapse consecutive same chords
    result = []
    for t, name, strength in chords:
        if not result or result[-1][1] != name:
            result.append((t, name, strength))
        else:
            # Extend duration
            pass

    return result

def _detect_chords_simple(audio, sr):
    """Simple chord detection without librosa — uses FFT bins."""
    window = int(sr * 2.0)
    hop = int(sr * 0.5)
    chords = []
    for start in range(0, len(audio) - window, hop):
        t = start / sr
        chunk = audio[start:start+window]
        if np.max(np.abs(chunk)) < 0.01:
            chords.append((t, "N/C", 0))
            continue
        spectrum = np.abs(np.fft.rfft(chunk * np.hanning(len(chunk))))
        freqs = np.fft.rfftfreq(len(chunk), 1.0/sr)
        # Map to pitch classes
        chroma = np.zeros(12)
        for f, mag in zip(freqs, spectrum):
            if f > 80 and f < 2000 and mag > 0.1 * np.max(spectrum):
                midi = round(69 + 12 * np.log2(f / 440.0))
                chroma[midi % 12] += mag
        if np.max(chroma) < 0.01:
            chords.append((t, "N/C", 0))
            continue
        root_idx = np.argmax(chroma)
        intervals = [j for j in range(1, 12) if chroma[(root_idx+j)%12] > 0.5 * np.max(chroma)]
        quality = get_chord_quality(intervals)
        chords.append((t, f"{NOTES[root_idx]}{quality}", chroma[root_idx]))
    return chords

# ═══════════════════════════════════════════════════════════════
# TEMPO / BEAT DETECTION
# Adapted from all-in-one tempo.py + Essentia
# ═══════════════════════════════════════════════════════════════

def detect_tempo(audio, sr):
    """Detect tempo (BPM) and beat positions."""
    if HAS_ESSENTIA:
        rhythm = es.RhythmExtractor2013()
        bpm, beats, bars, ticks, bpm_estimates = rhythm(audio)
        return {
            'bpm': round(float(bpm)),
            'bpm_raw': float(bpm),
            'beats': list(beats) if hasattr(beats, 'tolist') else [float(beats)],
            'bars': list(bars) if hasattr(bars, 'tolist') else ([] if isinstance(bars, float) else list(bars)),
            'bpm_estimates': list(bpm_estimates) if hasattr(bpm_estimates, 'tolist') else [float(bpm_estimates)]
        }

    # Fallback: librosa
    if HAS_LIBROSA:
        tempo, beats = librosa.beat.beat_track(y=audio, sr=sr)
        return {
            'bpm': round(float(tempo)),
            'bpm_raw': float(tempo),
            'beats': beats.tolist(),
            'bars': [],
            'bpm_estimates': []
        }

    # Last resort: energy-based onset detection (from all-in-one helpers.py concept)
    return _detect_tempo_energy(audio, sr)

def _detect_tempo_energy(audio, sr):
    """Simple energy-based tempo estimation."""
    frame_size = 1024
    hop = 512
    energy = []
    for i in range(0, len(audio) - frame_size, hop):
        chunk = audio[i:i+frame_size]
        energy.append(np.sqrt(np.mean(chunk**2)))

    # Onset detection: difference between consecutive energy frames
    onset = np.diff(energy)
    onset[onset < 0] = 0

    # Autocorrelation to find periodicity
    min_lag = int(60 / 200 * sr / hop)  # 200 BPM max
    max_lag = int(60 / 60 * sr / hop)   # 60 BPM min

    best_lag = 0
    best_corr = 0
    for lag in range(min_lag, min(max_lag, len(onset) // 2)):
        corr = np.sum(onset[:len(onset)-lag] * onset[lag:lag+len(onset)-lag])
        if corr > best_corr:
            best_corr = corr
            best_lag = lag

    if best_lag > 0:
        bpm = round(60.0 / (best_lag * hop / sr))
    else:
        bpm = 120

    return {'bpm': bpm, 'bpm_raw': bpm, 'beats': [], 'bars': [], 'bpm_estimates': []}

# ═══════════════════════════════════════════════════════════════
# PITCH DETECTION
# Adapted from spectrum_analyzer.py (Essentia) + spectrum_compare.py (autocorrelation)
# ═══════════════════════════════════════════════════════════════

def freq_to_note(freq):
    """Convert frequency to note name, MIDI number, and cents error."""
    if freq <= 0:
        return "N/A", 0, 0
    midi = round(69 + 12 * math.log2(freq / 440.0))
    cents = (69 + 12 * math.log2(freq / 440.0) - midi) * 100
    name = f"{NOTES[midi % 12]}{midi // 12 - 1}"
    return name, midi, cents

def detect_pitch_timeline(audio, sr, min_freq=55, max_freq=2000):
    """
    Extract pitch over time.
    Uses Essentia PredominantPitchMelodia if available, else autocorrelation.
    """
    if HAS_ESSENTIA:
        # Bandpass to clean noise (from spectrum_analyzer.py)
        bandpass = es.BandPass(bandwidth=max_freq - min_freq, cutoffFrequency=min_freq, sampleRate=sr)
        audio_clean = bandpass(audio)

        pitch_extractor = es.PredominantPitchMelodia(
            frameSize=2048, hopSize=128,
            minFrequency=min_freq, maxFrequency=max_freq
        )
        pitch, confidence = pitch_extractor(audio_clean)

        hop = 128
        notes = []
        prev_name = None
        prev_t = 0
        frame_count = 0
        min_note_frames = 3

        for i in range(len(pitch)):
            freq = float(pitch[i])
            if freq > 0:
                t = i * hop / sr
                name, midi, cents = freq_to_note(freq)
                if name != prev_name:
                    if prev_name is not None and frame_count >= min_note_frames:
                        dur = t - prev_t
                        notes.append((prev_t, prev_name, prev_midi if 'prev_midi' in dir() else 0, prev_freq if 'prev_freq' in dir() else 0, dur))
                    prev_name = name
                    prev_t = t
                    prev_midi = midi
                    prev_freq = freq
                    frame_count = 1
                else:
                    frame_count += 1

        if prev_name is not None:
            notes.append((prev_t, prev_name, prev_midi, prev_freq, 0.1))

        # Insert rests for gaps
        result = []
        prev_end = 0
        for t, name, midi, freq, dur in notes:
            gap = t - prev_end
            if gap > 0.2:
                result.append((prev_end, "R", 0, 0, gap))
            result.append((t, name, midi, freq, dur))
            prev_end = t + dur

        return result

    # Fallback: autocorrelation (from spectrum_compare.py)
    return _detect_pitch_autocorr(audio, sr, min_freq, max_freq)

def _detect_pitch_autocorr(audio, sr, min_freq=80, max_freq=2000):
    """Autocorrelation pitch detection with parabolic interpolation."""
    window_ms = 40
    step_ms = 30
    window = int(sr * window_ms / 1000)
    step = int(sr * step_ms / 1000)
    min_lag = int(sr / max_freq)
    max_lag = min(int(sr / min_freq), window - 1)

    notes = []
    for start in range(0, len(audio) - window, step):
        t = start / sr
        chunk = audio[start:start+window].copy()
        avg = np.mean(chunk)
        chunk = chunk - avg

        best_lag = 0
        best_corr = 0.0
        for lag in range(min_lag, max_lag):
            corr = np.sum(chunk[:len(chunk)-lag] * chunk[lag:lag+len(chunk)-lag])
            if corr > best_corr:
                best_corr = corr
                best_lag = lag

        if best_lag == 0 or best_corr < 1e-3:
            notes.append((t, None, 0, 0.0, 0))
            continue

        freq = sr / best_lag
        if min_freq <= freq <= max_freq:
            name, midi, cents = freq_to_note(freq)
            notes.append((t, name, midi, freq, 0))
        else:
            notes.append((t, None, 0, 0.0, 0))

    # Collapse consecutive same notes
    result = []
    prev = None
    prev_t = 0
    for t, name, midi, freq, _ in notes:
        if name != prev:
            if prev is not None:
                dur = t - prev_t
                result.append((prev_t, prev, 0, 0, dur))
            prev = name
            prev_t = t
    if prev is not None:
        result.append((prev_t, prev, 0, 0, 0.1))

    return result

# ═══════════════════════════════════════════════════════════════
# SPECTRAL ANALYSIS
# Adapted from SongRec algorithm.rs + MusicAnalyser BasicFFT
# ═══════════════════════════════════════════════════════════════

def analyze_spectrum(audio, sr, fft_size=4096):
    """
    Full spectral analysis: STFT, peak frequencies, HPS fundamental.
    Combines SongRec peak detection + MusicAnalyser HPS + spectrum_analyzer concepts.
    """
    # Apply Hann window (from SongRec hanning.rs)
    window = np.hanning(fft_size)
    hop = fft_size // 2

    # STFT
    frames = []
    for i in range(0, len(audio) - fft_size, hop):
        frame = audio[i:i+fft_size] * window
        spectrum = np.abs(np.fft.rfft(frame))
        frames.append(spectrum)

    if not frames:
        return {'peaks': [], 'hps': 0, 'spectrogram': []}

    # Average power spectrum (from ai-music-detector FakeprintExtractor)
    avg_spectrum = np.mean(np.array(frames), axis=0)
    freqs = np.fft.rfftfreq(fft_size, 1.0/sr)

    # Peak detection (from SongRec do_peak_recognition concept)
    peaks = []
    if HAS_SCIPY:
        peak_indices, properties = find_peaks(avg_spectrum, height=0.1*np.max(avg_spectrum), distance=10)
        for idx in peak_indices:
            freq = freqs[idx]
            if freq > 20 and freq < sr/2:
                mag = avg_spectrum[idx]
                name, midi, cents = freq_to_note(freq)
                peaks.append({
                    'frequency': freq,
                    'magnitude': mag,
                    'note': name,
                    'midi': midi,
                    'cents': cents
                })
    else:
        # Manual peak detection
        threshold = 0.1 * np.max(avg_spectrum)
        for i in range(1, len(avg_spectrum)-1):
            if avg_spectrum[i] > threshold and avg_spectrum[i] > avg_spectrum[i-1] and avg_spectrum[i] > avg_spectrum[i+1]:
                freq = freqs[i]
                if freq > 20 and freq < sr/2:
                    name, midi, cents = freq_to_note(freq)
                    peaks.append({
                        'frequency': freq,
                        'magnitude': avg_spectrum[i],
                        'note': name,
                        'midi': midi,
                        'cents': cents
                    })

    # Sort by magnitude
    peaks.sort(key=lambda x: -x['magnitude'])

    # HPS (Harmonic Product Spectrum) — from MusicAnalyser HPSDownsampler
    # Downsample spectrum by factors 2-5 and multiply to emphasize fundamental
    hps_spectrum = avg_spectrum.copy()
    for factor in range(2, 6):
        downsampled = avg_spectrum[::factor]
        hps_spectrum[:len(downsampled)] *= downsampled

    hps_peak_idx = np.argmax(hps_spectrum)
    hps_fundamental = freqs[hps_peak_idx] if hps_peak_idx < len(freqs) else 0

    return {
        'peaks': peaks[:20],  # Top 20 peaks
        'hps_fundamental': hps_fundamental,
        'hps_note': freq_to_note(hps_fundamental)[0] if hps_fundamental > 0 else "N/A",
        'spectrogram': np.array(frames),
        'freqs': freqs,
        'avg_spectrum': avg_spectrum
    }

# ═══════════════════════════════════════════════════════════════
# INSTRUMENT SYNTHESIS PROFILE
# Extract parameters for the waveguide + body-resonator model.
# ═══════════════════════════════════════════════════════════════

def analyze_instrument_profile(audio, sr, fundamental=None):
    """
    Derive synthesis parameters from an instrument sample (or averaged samples).
    Returns waveguide damping, brightness, pluck position, and body EQ peaks.
    """
    spec = analyze_spectrum(audio, sr, fft_size=4096)
    freqs = spec['freqs']
    spectrum = spec['avg_spectrum']

    if fundamental is None or fundamental <= 0:
        fundamental = spec['hps_fundamental']
    if fundamental <= 0:
        fundamental = 440.0

    # Harmonic amplitudes (relative to fundamental)
    harmonics = {}
    for h in range(1, 9):
        target = fundamental * h
        idx = np.argmin(np.abs(freqs - target))
        harmonics[h] = float(spectrum[idx])
    norm = harmonics.get(2, harmonics.get(1, 1.0)) or 1.0
    harmonic_ratios = {h: round(v / norm, 3) for h, v in harmonics.items()}

    # Temporal envelope: attack and decay
    env_window = int(0.005 * sr)
    env = []
    for i in range(0, len(audio) - env_window, env_window):
        env.append(np.sqrt(np.mean(audio[i:i+env_window]**2)))
    env = np.array(env)
    peak_idx = int(np.argmax(env))
    peak = float(env[peak_idx])
    attack_ms = peak_idx * 5
    decay50_idx = np.argmax(env[peak_idx:] < peak * 0.5)
    decay50_ms = int(decay50_idx) * 5 if env[peak_idx:].min() < peak * 0.5 else None
    decay10_idx = np.argmax(env[peak_idx:] < peak * 0.1)
    decay10_ms = int(decay10_idx) * 5 if env[peak_idx:].min() < peak * 0.1 else None

    # Convert decay to damping: fraction of energy lost per round trip.
    # damping ~ 1 - 0.5^(1 / round_trips_to_50_percent)
    period_s = 1.0 / fundamental
    round_trips_to_50 = (decay50_ms / 1000.0) / period_s if decay50_ms else 4.0
    damping = 1.0 - 0.5 ** (1.0 / max(round_trips_to_50, 0.5))

    # Brightness from spectral centroid relative to fundamental
    power = spectrum ** 2
    centroid = float(np.sum(freqs * power) / np.sum(power)) if np.sum(power) > 0 else fundamental
    brightness = min(0.99, max(0.5, 1.0 - (centroid - 4 * fundamental) / (8 * fundamental)))

    # Body resonant peaks: strongest peaks not at harmonics of fundamental
    body_peaks = []
    for p in spec['peaks']:
        f = p['frequency']
        if f < 80 or f > 6000:
            continue
        # Skip if close to a harmonic of the fundamental
        is_harmonic = any(abs(f - fundamental * h) < 30 for h in range(1, 9))
        if not is_harmonic:
            body_peaks.append({
                'freq': round(f, 1),
                'mag': round(float(p['magnitude'] / spec['peaks'][0]['magnitude']), 3),
                'note': p['note']
            })
    body_peaks = sorted(body_peaks, key=lambda x: -x['mag'])[:6]

    # Estimate pluck position from harmonic ratios: we want H2/H1 high and H1 low.
    h1 = harmonic_ratios.get(1, 1.0)
    h2 = harmonic_ratios.get(2, 1.0)
    # Small pluck_position -> weak H1, strong H2/H3/H4
    pluck_position = 0.10
    if h2 > h1 * 2.0:
        pluck_position = 0.08
    elif h2 < h1:
        pluck_position = 0.18

    return {
        'fundamental_hz': round(fundamental, 1),
        'attack_ms': attack_ms,
        'decay50_ms': decay50_ms,
        'decay10_ms': decay10_ms,
        'damping': round(damping, 4),
        'brightness': round(brightness, 4),
        'pluck_position': round(pluck_position, 4),
        'harmonic_ratios': harmonic_ratios,
        'body_peaks_hz': [p['freq'] for p in body_peaks],
        'spectral_centroid_hz': round(centroid, 1),
    }

def aggregate_instrument_profile(paths):
    """Average profiles across multiple instrument samples."""
    profiles = []
    for path in paths:
        audio, sr = load_audio(path, 120)
        spec = analyze_spectrum(audio, sr)
        fund = spec['hps_fundamental']
        if fund <= 0:
            continue
        profiles.append(analyze_instrument_profile(audio, sr, fundamental=fund))

    if not profiles:
        return None

    def avg(key):
        vals = [p[key] for p in profiles if p[key] is not None]
        return round(sum(vals) / len(vals), 4) if vals else None

    # Merge body peaks by 10Hz buckets
    peak_buckets = {}
    for p in profiles:
        for f in p['body_peaks_hz']:
            b = round(f / 10) * 10
            peak_buckets[b] = peak_buckets.get(b, 0) + 1
    common_peaks = sorted([b for b, c in peak_buckets.items() if c >= max(2, len(profiles)//4)])[:6]

    return {
        'samples': len(profiles),
        'attack_ms': avg('attack_ms'),
        'decay50_ms': avg('decay50_ms'),
        'decay10_ms': avg('decay10_ms'),
        'damping': avg('damping'),
        'brightness': avg('brightness'),
        'pluck_position': avg('pluck_position'),
        'body_peaks_hz': common_peaks,
        'spectral_centroid_hz': avg('spectral_centroid_hz'),
        'per_sample_profiles': profiles,
    }

# ═══════════════════════════════════════════════════════════════
# CAMELOT KEY COMPATIBILITY
# Adapted from music-similarity-master filters.py
# ═══════════════════════════════════════════════════════════════

def camelot_compatible(key_a, key_b):
    """
    Check if two keys are compatible for harmonic mixing.
    Uses Camelot wheel: same code, ±1, or relative major/minor.
    """
    code_a = CAMELOT_WHEEL.get(key_a)
    code_b = CAMELOT_WHEEL.get(key_b)
    if not code_a or not code_b:
        return False, "Unknown key"

    # Same code = perfectly compatible
    if code_a == code_b:
        return True, "Same key (perfect)"

    # ±1 on same letter (A-A or B-B)
    num_a = int(code_a[:-1])
    let_a = code_a[-1]
    num_b = int(code_b[:-1])
    let_b = code_b[-1]

    if let_a == let_b:
        diff = abs(num_a - num_b)
        if diff == 1 or diff == 11:  # adjacent on wheel
            return True, "Adjacent on Camelot wheel"

    # Relative major/minor (A <-> B, same number)
    if num_a == num_b and let_a != let_b:
        return True, "Relative major/minor"

    return False, "Not compatible"

# ═══════════════════════════════════════════════════════════════
# BASIC TRANSCRIPTION
# Adapted from spectrum_analyzer.py print_basic
# ═══════════════════════════════════════════════════════════════

def beats_to_notation(beats):
    """Convert beat count to musical notation."""
    durations = [
        (4.0, "1"), (3.0, "2."), (2.0, "2"), (1.5, "4."),
        (1.0, "4"), (0.75, "8."), (0.5, "8"), (0.375, "16."),
        (0.25, "16"), (0.1875, "32."), (0.125, "32"),
    ]
    for dur, notation in durations:
        if abs(beats - dur) < dur * 0.15:
            return notation
    best = min(durations, key=lambda x: abs(x[0] - beats))
    return best[1]

def transcribe_to_basic(notes, tempo, key_info=None):
    """Generate ModernBASIC program from detected notes."""
    melody = []
    bass = []

    for t, name, midi, freq, dur in notes:
        if name == "R":
            melody.append(("R", beats_to_notation(dur * tempo / 60)))
            bass.append(("R", beats_to_notation(dur * tempo / 60)))
        else:
            notation = beats_to_notation(dur * tempo / 60)
            if midi >= 67:
                melody.append((name, notation))
            else:
                bass.append((name, notation))

    lines = []
    lines.append("10 REM TRANSCRIBED BY MUSIC ANALYZER")
    if key_info:
        lines.append(f"20 REM Key: {key_info['key']} (corr: {key_info['correlation']:.3f})")
        lines.append(f"30 REM Scale: {' '.join(key_info['scale_notes'])}")
    lines.append("40 CLEAR")
    lines.append(f"50 TEMPO {tempo}")
    lines.append("60 VOL .8")
    lines.append("70 VOICE 1")
    lines.append('80 WAVE 1,"TRIANGLE"')
    lines.append("90 ADSR 1,1,90,.72,180")
    lines.append(f"100 VOL 1,.22")

    ln = 110
    mp = [f"{n}/{d}" for n, d in melody]
    for i in range(0, len(mp), 25):
        chunk = " ".join(mp[i:i+25])
        lines.append(f'{ln} PLAY 1,"{chunk}"')
        ln += 10

    if bass:
        lines.append(f"{ln} VOICE 2")
        ln += 10
        lines.append(f'{ln} WAVE 2,"SINE"')
        ln += 10
        lines.append(f"{ln} ADSR 2,5,100,.70,250")
        ln += 10
        lines.append(f"{ln} VOL 2,.14")
        ln += 10
        bp = [f"{n}/{d}" for n, d in bass]
        for i in range(0, len(bp), 25):
            chunk = " ".join(bp[i:i+25])
            lines.append(f'{ln} PLAY 2,"{chunk}"')
            ln += 10

    lines.append(f"{ln} SOUND RESUME")
    ln += 10
    lines.append(f"{ln} END")

    return "\n".join(lines)

# ═══════════════════════════════════════════════════════════════
# COMPARISON
# Adapted from spectrum_compare.py
# ═══════════════════════════════════════════════════════════════

def compare_files(path_a, path_b, max_seconds=60):
    """Compare two audio files by note sequences."""
    audio_a, sr_a = load_audio(path_a, max_seconds)
    audio_b, sr_b = load_audio(path_b, max_seconds)

    notes_a = detect_pitch_timeline(audio_a, sr_a)
    notes_b = detect_pitch_timeline(audio_b, sr_b)

    print(f"File A: {path_a} — {len(notes_a)} notes")
    print(f"File B: {path_b} — {len(notes_b)} notes")
    print()

    key_a = detect_key(audio_a, sr_a)
    key_b = detect_key(audio_b, sr_b)
    print(f"Key A: {key_a['key']} (corr: {key_a['correlation']:.3f})")
    print(f"Key B: {key_b['key']} (corr: {key_b['correlation']:.3f})")
    print()

    tempo_a = detect_tempo(audio_a, sr_a)
    tempo_b = detect_tempo(audio_b, sr_b)
    print(f"Tempo A: {tempo_a['bpm']} BPM")
    print(f"Tempo B: {tempo_b['bpm']} BPM")
    print()

    print(f"{'A_time':>7} {'A_note':>6} {'A_dur':>6}  |  {'B_time':>7} {'B_note':>6} {'B_dur':>6}  | Match")
    print("-" * 65)

    matches = 0
    total = 0
    ia, ib = 0, 0
    while ia < len(notes_a) and ib < len(notes_b):
        ta, na, _, _, da = notes_a[ia]
        tb, nb, _, _, db = notes_b[ib]
        match = "  " if na != nb else "=="
        if na is not None and nb is not None:
            total += 1
            if na == nb:
                matches += 1
        print(f"{ta:7.2f} {str(na):>6} {da:6.3f}  |  {tb:7.2f} {str(nb):>6} {db:6.3f}  | {match}")
        if ta + da < tb + db:
            ia += 1
        else:
            ib += 1

    if total > 0:
        print()
        print(f"Match rate: {matches}/{total} = {matches/total*100:.1f}%")

# ═══════════════════════════════════════════════════════════════
# OUTPUT FORMATTERS
# ═══════════════════════════════════════════════════════════════

def print_key_analysis(result):
    print("═ KEY DETECTION ═══════════════════════════════════════════")
    print(f"  Detected key:   {result['key']}")
    print(f"  Correlation:    {result['correlation']:.3f}")
    if result['alt_key']:
        print(f"  Alternative:    {result['alt_key']} ({result['alt_correlation']:.3f})")
    print(f"  Scale notes:    {' '.join(result['scale_notes'])}")
    print()
    print("  Chroma profile:")
    chroma_max = max(result['chroma']) if max(result['chroma']) > 0 else 1
    for i in range(12):
        bar = '█' * int(result['chroma'][i] / chroma_max * 30)
        print(f"    {NOTES[i]:>2}: {bar}")
    print()
    print("  Top 5 key candidates:")
    for i, (key, corr) in enumerate(list(result['all_correlations'].items())[:5]):
        print(f"    {key:>15}: {corr:.3f}")
    print()

def print_chord_analysis(chords):
    print("═ CHORD PROGRESSION ═══════════════════════════════════════")
    print(f"  {'time':>7}  {'chord':>12}  {'strength':>8}")
    print("  " + "-" * 35)
    for t, name, strength in chords:
        print(f"  {t:7.1f}s  {name:>12}  {strength:8.3f}")
    print()

    # Summary
    chord_counts = Counter(c[1] for c in chords if c[1] != "N/C")
    if chord_counts:
        print("  Most common chords:")
        for chord, count in chord_counts.most_common(5):
            print(f"    {chord:>12}: {count} times")
    print()

def print_tempo_analysis(result):
    print("═ TEMPO & BEATS ══════════════════════════════════════════")
    print(f"  BPM:           {result['bpm']}")
    print(f"  BPM (raw):     {result['bpm_raw']:.1f}")
    print(f"  Beat count:    {len(result['beats'])}")
    if result['bars']:
        print(f"  Bar count:     {len(result['bars'])}")
    if result['beats']:
        print(f"  First 10 beats (s): {', '.join(f'{b:.2f}' for b in result['beats'][:10])}")
    print()

def print_pitch_timeline(notes):
    print("═ PITCH TIMELINE ═════════════════════════════════════════")
    print(f"  {'time':>7}  {'note':>6}  {'midi':>4}  {'freq':>8}  {'dur':>6}")
    print("  " + "-" * 45)
    for t, name, midi, freq, dur in notes:
        if name == "R":
            print(f"  {t:7.2f}  {'rest':>6}  {'':>4}  {'':>8}  {dur:6.3f}")
        else:
            print(f"  {t:7.2f}  {name:>6}  {midi:4d}  {freq:8.1f}  {dur:6.3f}")
    print()

def print_spectrum_analysis(spec):
    print("═ SPECTRAL ANALYSIS ═══════════════════════════════════════")
    print(f"  HPS Fundamental: {spec['hps_fundamental']:.1f} Hz ({spec['hps_note']})")
    print(f"  Top spectral peaks:")
    print(f"    {'freq':>8}  {'note':>6}  {'midi':>4}  {'cents':>6}  {'magnitude':>10}")
    print("    " + "-" * 45)
    for p in spec['peaks'][:10]:
        print(f"    {p['frequency']:8.1f}  {p['note']:>6}  {p['midi']:4d}  {p['cents']:+6.0f}  {p['magnitude']:10.3f}")
    print()

def print_instrument_profile(profile):
    print("═ INSTRUMENT SYNTHESIS PROFILE ═════════════════════════════")
    print(f"  Fundamental:   {profile['fundamental_hz']:.1f} Hz")
    print(f"  Attack:        {profile['attack_ms']} ms")
    print(f"  Decay to 50%:  {profile['decay50_ms']} ms")
    print(f"  Decay to 10%:  {profile['decay10_ms']} ms")
    print(f"  Damping:       {profile['damping']}")
    print(f"  Brightness:    {profile['brightness']}")
    print(f"  Pluck pos:     {profile['pluck_position']}")
    print(f"  Centroid:      {profile['spectral_centroid_hz']:.1f} Hz")
    print(f"  Harmonic ratios:")
    for h in sorted(profile['harmonic_ratios'].keys()):
        print(f"    H{h}: {profile['harmonic_ratios'][h]:.3f}")
    print(f"  Body resonant peaks (Hz):")
    for f in profile['body_peaks_hz']:
        print(f"    {f:.1f}")
    print()

def print_camelot(key_a, key_b):
    compatible, reason = camelot_compatible(key_a, key_b)
    print("═ CAMELOT COMPATIBILITY ══════════════════════════════════")
    print(f"  Key A: {key_a} -> {CAMELOT_WHEEL.get(key_a, '?')}")
    print(f"  Key B: {key_b} -> {CAMELOT_WHEEL.get(key_b, '?')}")
    print(f"  Compatible: {'YES' if compatible else 'NO'} — {reason}")
    print()

# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    # Compare mode
    if sys.argv[1] == '--compare':
        if len(sys.argv) < 4:
            print("Usage: python3 music_analyzer.py --compare a.wav b.wav")
            sys.exit(1)
        compare_files(sys.argv[2], sys.argv[3])
        return

    path = sys.argv[1]
    if not os.path.exists(path):
        print(f"Error: {path} not found", file=sys.stderr)
        sys.exit(1)

    max_sec = int(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3].isdigit() else 120
    mode = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].isdigit() else 'all'

    print(f"Loading {path}...")
    audio, sr = load_audio(path, max_sec)
    print(f"Duration: {len(audio)/sr:.1f}s, Sample rate: {sr}Hz")
    print(f"Librosa: {'yes' if HAS_LIBROSA else 'no'}, Essentia: {'yes' if HAS_ESSENTIA else 'no'}")
    print()

    if mode == 'key':
        result = detect_key(audio, sr)
        print_key_analysis(result)

    elif mode == 'chords':
        chords = detect_chords(audio, sr)
        print_chord_analysis(chords)

    elif mode == 'tempo':
        result = detect_tempo(audio, sr)
        print_tempo_analysis(result)

    elif mode == 'pitch':
        notes = detect_pitch_timeline(audio, sr)
        print_pitch_timeline(notes)

    elif mode == 'spectrum':
        spec = analyze_spectrum(audio, sr)
        print_spectrum_analysis(spec)

    elif mode == 'instrument':
        profile = analyze_instrument_profile(audio, sr)
        print_instrument_profile(profile)

    elif mode == 'basic':
        notes = detect_pitch_timeline(audio, sr)
        tempo = detect_tempo(audio, sr)['bpm']
        key_info = detect_key(audio, sr)
        basic = transcribe_to_basic(notes, tempo, key_info)
        print(basic)

    elif mode == 'camelot':
        key_b = sys.argv[4] if len(sys.argv) > 4 else 'C major'
        key_a = detect_key(audio, sr)['key']
        print_camelot(key_a, key_b)

    elif mode == 'all':
        # Full analysis
        print("Analyzing key...")
        key_result = detect_key(audio, sr)
        print_key_analysis(key_result)

        print("Analyzing tempo...")
        tempo_result = detect_tempo(audio, sr)
        print_tempo_analysis(tempo_result)

        print("Analyzing chords...")
        chord_result = detect_chords(audio, sr)
        print_chord_analysis(chord_result)

        print("Analyzing pitch...")
        pitch_result = detect_pitch_timeline(audio, sr)
        print_pitch_timeline(pitch_result[:30])  # First 30 notes
        if len(pitch_result) > 30:
            print(f"  ... and {len(pitch_result) - 30} more notes")
        print()

        print("Analyzing spectrum...")
        spec_result = analyze_spectrum(audio, sr)
        print_spectrum_analysis(spec_result)

        print("═ SUMMARY ═══════════════════════════════════════════════")
        print(f"  Key:    {key_result['key']} (corr: {key_result['correlation']:.3f})")
        print(f"  Tempo:  {tempo_result['bpm']} BPM")
        print(f"  Scale:  {' '.join(key_result['scale_notes'])}")
        if chord_result:
            top_chords = Counter(c[1] for c in chord_result if c[1] != "N/C").most_common(3)
            print(f"  Chords: {', '.join(f'{c}x{n}' for c, n in top_chords)}")
        print(f"  HPS:    {spec_result['hps_note']} ({spec_result['hps_fundamental']:.1f} Hz)")
        print()

    else:
        print(f"Unknown mode: {mode}")
        print(__doc__)
        sys.exit(1)

if __name__ == '__main__':
    main()