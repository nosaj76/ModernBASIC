#!/usr/bin/env python3
"""Spectrum analyzer using Essentia for professional-grade pitch detection.
Uses PitchMelodia for melody extraction, RhythmExtractor for tempo,
and outputs musical notation for BASIC.
Usage:
  python3 spectrum_analyzer.py song.wav 60 melody
  python3 spectrum_analyzer.py song.wav 60 all
  python3 spectrum_analyzer.py song.wav 60 basic
"""
import sys, math, wave, struct

try:
    import essentia.standard as es
    HAS_ESSENTIA = True
except ImportError:
    HAS_ESSENTIA = False

NOTES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']

def beats_to_notation(beats):
    durations = [
        (4.0, "1"), (3.0, "2."), (2.0, "2"), (1.5, "4."),
        (1.0, "4"), (0.75, "8."), (0.5, "8"), (0.375, "16."),
        (0.25, "16"), (0.1875, "32."), (0.125, "32"),
    ]
    for dur, notation in durations:
        if abs(beats - dur) < dur * 0.15:
            return notation
    best = min(durations, key=lambda x: abs(x[0] - beats))
    return best[1]

def freq_to_note(freq):
    midi = round(69 + 12 * math.log2(freq / 440.0))
    cents = (69 + 12 * math.log2(freq / 440.0) - midi) * 100
    name = f"{NOTES[midi % 12]}{midi // 12 - 1}"
    return name, midi, cents

def detect_adsr_simple(audio, sr, note_start, note_end):
    """Simple ADSR detection from amplitude envelope."""
    start = int(sr * note_start)
    end = int(sr * note_end)
    if end - start < 200:
        return 5, 50, 0.5, 100
    
    frame = max(1, int(sr * 0.005))
    envelope = []
    for i in range(start, end - frame, frame):
        chunk = audio[i:i+frame]
        e = math.sqrt(sum(float(s)**2 for s in chunk) / len(chunk))
        envelope.append(e)
    
    if not envelope or max(envelope) == 0:
        return 5, 50, 0.5, 100
    
    peak = max(envelope)
    peak_idx = envelope.index(peak)
    
    attack_ms = max(5, (peak_idx - next((i for i, e in enumerate(envelope) if e > peak * 0.1), 0)) * 5)
    sustain_seg = envelope[peak_idx+1:int(len(envelope)*0.8)]
    sustain_level = sum(sustain_seg)/len(sustain_seg)/peak if sustain_seg else 0.5
    
    return min(attack_ms, 500), 50, max(0.05, min(sustain_level, 0.95)), 100

def transcribe(path, max_seconds=120, tempo=None):
    """Transcribe using Essentia's PitchMelodia."""
    if not HAS_ESSENTIA:
        print("Essentia not installed. Install with: pip3 install essentia", file=sys.stderr)
        return [], 72
    
    loader = es.MonoLoader(filename=path, sampleRate=44100)
    audio = loader()
    
    # Limit to max_seconds
    if max_seconds:
        audio = audio[:44100 * max_seconds]
    
    sr = 44100
    
    # Detect tempo
    if tempo is None:
        rhythm = es.RhythmExtractor2013()
        bpm, beats, bars, ticks, bpm_estimates = rhythm(audio)
        tempo = round(float(bpm))
        print(f"# Detected tempo: {tempo} BPM", file=sys.stderr)
    
    # Apply bandpass filter to block white noise
    # Keep only musical frequencies 80-2000 Hz
    bandpass = es.BandPass(bandwidth=1920, cutoffFrequency=80, sampleRate=44100)
    audio_clean = bandpass(audio)
    
    # Extract pitch using PredominantPitchMelodia on cleaned audio
    # minFrequency=500 focuses on melody range (B4 and above)
    # Skips A4 (440Hz) which dominates and blocks melody detection
    pitch_extractor = es.PredominantPitchMelodia(
        frameSize=2048, hopSize=128,
        minFrequency=500, maxFrequency=2000
    )
    pitch, pitch_confidence = pitch_extractor(audio_clean)
    
    # Build note list from pitch
    hop = 128
    notes = []
    prev_name = None
    prev_t = 0
    prev_midi = 0
    prev_freq = 0.0
    
    # Minimum note duration to avoid noise (40ms = 5 frames at hop=128)
    min_note_frames = 3
    # Track how many consecutive frames have the same note
    frame_count = 0
    
    for i in range(len(pitch)):
        freq = float(pitch[i])
        if freq > 0:
            t = i * hop / sr
            name, midi, cents = freq_to_note(freq)
            if name != prev_name:
                if prev_name is not None and frame_count >= min_note_frames:
                    dur = t - prev_t
                    notes.append((prev_t, prev_name, prev_midi, prev_freq, dur))
                prev_name = name
                prev_t = t
                prev_midi = midi
                prev_freq = freq
                frame_count = 1
            else:
                frame_count += 1
    
    if prev_name is not None:
        notes.append((prev_t, prev_name, prev_midi, prev_freq, 0.1))
    
    # Insert rests for gaps
    result = []
    prev_end = 0
    for t, name, midi, freq, dur in notes:
        gap = t - prev_end
        if gap > 0.2:
            # Insert rest
            result.append((prev_end, "R", 0, 0, gap))
        result.append((t, name, midi, freq, dur))
        prev_end = t + dur
    
    # Convert to musical notation
    ms_per_beat = 60000.0 / tempo
    final = []
    for t, name, midi, freq, dur in result:
        dur_ms = dur * 1000
        beats = dur_ms / ms_per_beat
        notation = beats_to_notation(beats) if name != "R" else beats_to_notation(beats)
        final.append((t * 1000, name, notation, beats, freq, 0))
    
    return final, tempo, audio, sr

def print_melody(results, midi_min=67):
    print(f"{'time':>7} {'note':>6} {'dur':>5} {'beats':>6} {'freq':>8}")
    print("-" * 45)
    for t_ms, name, notation, beats, freq, cents in results:
        if name == "R":
            print(f"{t_ms:6.0f}ms {'rest':>6} /{notation:>3} {beats:6.3f}")
        else:
            midi = round(69 + 12 * math.log2(freq / 440.0)) if freq > 0 else 0
            if midi >= midi_min:
                print(f"{t_ms:6.0f}ms {name:>6} /{notation:>3} {beats:6.3f} {freq:7.1f}Hz")

def print_all(results):
    print(f"{'time':>7} {'note':>6} {'dur':>5} {'beats':>6} {'freq':>8}")
    print("-" * 45)
    for t_ms, name, notation, beats, freq, cents in results:
        if name == "R":
            print(f"{t_ms:6.0f}ms {'rest':>6} /{notation:>3} {beats:6.3f}")
        else:
            print(f"{t_ms:6.0f}ms {name:>6} /{notation:>3} {beats:6.3f} {freq:7.1f}Hz")

def print_basic(results, tempo=72, audio=None, sr=None):
    melody = []
    bass = []
    
    for t_ms, name, notation, beats, freq, cents in results:
        if name == "R":
            melody.append(("R", notation))
            bass.append(("R", notation))
        else:
            midi = round(69 + 12 * math.log2(freq / 440.0)) if freq > 0 else 0
            if midi >= 67:
                melody.append((name, notation))
            else:
                bass.append((name, notation))
    
    print(f"10 REM TRANSCRIBED FROM AUDIO (Essentia)")
    print(f"20 CLEAR")
    print(f"30 TEMPO {tempo}")
    print(f"40 VOL 1.0")
    print(f'50 INSTRUMENT 1, "PIANO"')
    print(f'60 INSTRUMENT 2, "PIANO"')
    
    # ADSR detection
    if audio is not None:
        for t_ms, name, notation, beats, freq, cents in results:
            if name != "R" and freq > 0:
                midi = round(69 + 12 * math.log2(freq / 440.0))
                if midi >= 67:
                    a, d, s, r = detect_adsr_simple(audio, sr, t_ms/1000, t_ms/1000 + beats*60/tempo)
                    print(f"65 ADSR 1,{a},{d},{s},{r}")
                    break
        for t_ms, name, notation, beats, freq, cents in results:
            if name != "R" and freq > 0:
                midi = round(69 + 12 * math.log2(freq / 440.0))
                if midi < 67:
                    a, d, s, r = detect_adsr_simple(audio, sr, t_ms/1000, t_ms/1000 + beats*60/tempo)
                    print(f"75 ADSR 2,{a},{d},{s},{r}")
                    break
    
    mp = [f"{n}/{d}" for n, d in melody]
    ln = 100
    for i in range(0, len(mp), 25):
        print(f'{ln} PLAY 1,"{" ".join(mp[i:i+25])}"')
        ln += 10
    
    bp = [f"{n}/{d}" for n, d in bass]
    for i in range(0, len(bp), 25):
        print(f'{ln} PLAY 2,"{" ".join(bp[i:i+25])}"')
        ln += 10
    
    print(f'{ln} END')

if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else 'song.wav'
    max_sec = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    mode = sys.argv[3] if len(sys.argv) > 3 else 'melody'
    tempo = int(sys.argv[4]) if len(sys.argv) > 4 else None
    
    results, tempo, audio, sr = transcribe(path, max_sec, tempo)
    
    if mode == 'all':
        print_all(results)
    elif mode == 'basic':
        print_basic(results, tempo, audio, sr)
    else:
        print_melody(results)