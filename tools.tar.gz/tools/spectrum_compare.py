#!/usr/bin/env python3
"""Spectrum comparison tool.
Compares two audio files and shows how closely their note sequences match.
Usage: python3 spectrum_compare.py original.wav basic_output.wav"""
import wave, struct, math, sys

NOTES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']

def load_wav(path, max_seconds=None):
    w = wave.open(path, 'rb')
    sr = w.getframerate()
    ch = w.getnchannels()
    n = w.getnframes()
    if max_seconds:
        n = min(n, sr * max_seconds)
    raw = w.readframes(n)
    samples = struct.unpack(f'<{len(raw)//2}h', raw)
    w.close()
    if ch == 2:
        mono = [(samples[i] + samples[i+1]) / 2.0 for i in range(0, len(samples), 2)]
    else:
        mono = [float(s) for s in samples]
    return mono, sr

def detect_pitch(chunk, sr):
    """Autocorrelation pitch detection with parabolic interpolation."""
    n = len(chunk)
    avg = sum(chunk) / n
    chunk = [s - avg for s in chunk]
    min_lag = int(sr / 2000)
    max_lag = min(int(sr / 80), n - 1)
    
    best_lag = 0
    best_corr = 0.0
    for lag in range(min_lag, max_lag):
        corr = 0.0
        for i in range(n - lag):
            corr += chunk[i] * chunk[i + lag]
        if corr > best_corr:
            best_corr = corr
            best_lag = lag
    
    if best_lag == 0 or best_corr < 1e6:
        return None, 0.0
    
    freq = sr / best_lag
    if freq < 80 or freq > 2000:
        return None, 0.0
    
    # Parabolic interpolation
    if best_lag > min_lag and best_lag < max_lag - 1:
        c_left = sum(chunk[i] * chunk[i + best_lag - 1] for i in range(n - best_lag - 1))
        c_right = sum(chunk[i] * chunk[i + best_lag + 1] for i in range(n - best_lag - 1))
        denom = c_left + c_right - 2 * best_corr
        if denom != 0:
            shift = 0.5 * (c_left - c_right) / denom
            refined = best_lag + shift
            if refined > 0:
                freq = sr / refined
    
    return freq, best_corr

def extract_notes(mono, sr, window_ms=40, step_ms=30, min_conf=1e7):
    """Extract note sequence from audio."""
    window = int(sr * window_ms / 1000)
    step = int(sr * step_ms / 1000)
    
    notes = []
    for start in range(0, len(mono) - window, step):
        t = start / sr
        freq, conf = detect_pitch(mono[start:start+window], sr)
        if freq and conf > min_conf:
            midi = round(69 + 12 * math.log2(freq / 440))
            name = f"{NOTES[midi % 12]}{midi // 12 - 1}"
            notes.append((t, name, midi, freq, conf))
        else:
            notes.append((t, None, None, 0.0, 0.0))
    
    # Collapse consecutive same notes into one with duration
    result = []
    prev = None
    prev_t = 0
    for t, name, midi, freq, conf in notes:
        if name != prev:
            if prev is not None:
                dur = t - prev_t
                result.append((prev_t, prev, dur))
            prev = name
            prev_t = t
    if prev is not None:
        result.append((prev_t, prev, 0.1))
    
    return result

def compare(file_a, file_b, max_seconds=30):
    """Compare two audio files note by note."""
    mono_a, sr_a = load_wav(file_a, max_seconds)
    mono_b, sr_b = load_wav(file_b, max_seconds)
    
    notes_a = extract_notes(mono_a, sr_a)
    notes_b = extract_notes(mono_b, sr_b)
    
    print(f"File A: {len(notes_a)} notes")
    print(f"File B: {len(notes_b)} notes")
    print()
    
    # Side by side comparison
    print(f"{'A_time':>7} {'A_note':>6} {'A_dur':>6}  |  {'B_time':>7} {'B_note':>6} {'B_dur':>6}  | Match")
    print("-" * 65)
    
    matches = 0
    total = 0
    ia, ib = 0, 0
    
    while ia < len(notes_a) and ib < len(notes_b):
        ta, na, da = notes_a[ia]
        tb, nb, db = notes_b[ib]
        
        match = "  " if na != nb else "=="
        if na is not None and nb is not None:
            total += 1
            if na == nb:
                matches += 1
        
        print(f"{ta:7.2f} {str(na):>6} {da:6.3f}  |  {tb:7.2f} {str(nb):>6} {db:6.3f}  | {match}")
        
        # Advance the one that's earlier
        if ta + da < tb + db:
            ia += 1
        else:
            ib += 1
    
    # Print remaining
    while ia < len(notes_a):
        ta, na, da = notes_a[ia]
        print(f"{ta:7.2f} {str(na):>6} {da:6.3f}  |  {'---':>7} {'---':>6} {'---':>6}  |")
        ia += 1
    while ib < len(notes_b):
        tb, nb, db = notes_b[ib]
        print(f"{'---':>7} {'---':>6} {'---':>6}  |  {tb:7.2f} {str(nb):>6} {db:6.3f}  |")
        ib += 1
    
    if total > 0:
        print()
        print(f"Match rate: {matches}/{total} = {matches/total*100:.1f}%")

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python3 spectrum_compare.py original.wav basic_output.wav")
        sys.exit(1)
    compare(sys.argv[1], sys.argv[2])