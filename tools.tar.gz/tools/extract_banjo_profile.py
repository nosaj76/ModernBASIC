#!/usr/bin/env python3
"""
Extract banjo acoustic profile from reference samples and emit synthesis params.

Usage:
    python3 tools/extract_banjo_profile.py samples/banjo/ > src/instrument_synth/banjo_profile.inc

The tool analyzes clean single-note banjo samples, measures their shared
spectral envelope and temporal envelope, and produces numeric parameters for
the waveguide + body-resonator banjo model.
"""

import os, sys, wave, struct, math, json
from collections import defaultdict

def load_mono(path):
    with wave.open(path, 'r') as w:
        sr = w.getframerate()
        ch = w.getnchannels()
        raw = w.readframes(w.getnframes())
        if ch == 1:
            samples = [struct.unpack('<h', raw[i:i+2])[0] for i in range(0, len(raw), 2)]
        else:
            samples = [struct.unpack('<hh', raw[i:i+4])[0] for i in range(0, len(raw), 4)]
    return samples, sr

def envelope_metrics(samples, sr):
    win = int(0.005 * sr)
    env = []
    for i in range(0, len(samples) - win, win):
        env.append(math.sqrt(sum(s*s for s in samples[i:i+win]) / win))
    if not env:
        return None
    peak = max(env)
    pidx = env.index(peak)
    # decay to 50%
    d50 = next((i for i in range(pidx, len(env)) if env[i] < peak * 0.5), None)
    # decay to 10%
    d10 = next((i for i in range(pidx, len(env)) if env[i] < peak * 0.1), None)
    attack_ms = pidx * 5
    decay50_ms = (d50 - pidx) * 5 if d50 else None
    decay10_ms = (d10 - pidx) * 5 if d10 else None
    return {
        'attack_ms': attack_ms,
        'decay50_ms': decay50_ms,
        'decay10_ms': decay10_ms,
    }

def harmonic_profile(samples, sr, fundamental):
    N = min(4096, len(samples) - 1000)
    if N < 2048:
        return None
    start = max(0, len(samples)//4)
    seg = samples[start:start+N]
    window = [0.5 - 0.5*math.cos(2*math.pi*i/N) for i in range(N)]
    wseg = [seg[i] * window[i] for i in range(N)]

    harms = {}
    for h in range(1, 9):
        f = fundamental * h
        if f > sr/2:
            break
        sine = sum(wseg[i] * math.sin(2*math.pi*f*i/sr) for i in range(N))
        cosine = sum(wseg[i] * math.cos(2*math.pi*f*i/sr) for i in range(N))
        mag = math.sqrt(sine*sine + cosine*cosine) / N
        harms[h] = mag
    # normalize to H2 if present, else H1
    norm = harms.get(2, harms.get(1, 1.0)) or 1.0
    return {h: round(v / norm, 4) for h, v in harms.items()}

def spectral_peaks(samples, sr):
    N = min(4096, len(samples) - 1000)
    if N < 2048:
        return []
    start = max(0, len(samples)//4)
    seg = samples[start:start+N]
    window = [0.5 - 0.5*math.cos(2*math.pi*i/N) for i in range(N)]
    wseg = [seg[i] * window[i] for i in range(N)]

    mags = []
    freqs = []
    for k in range(N//2):
        f = k * sr / N
        s = sum(wseg[i] * math.sin(2*math.pi*k*i/N) for i in range(N))
        c = sum(wseg[i] * math.cos(2*math.pi*k*i/N) for i in range(N))
        mag = math.sqrt(s*s + c*c)
        mags.append(mag)
        freqs.append(f)
    peak = max(mags)
    peaks = []
    for i in range(2, len(mags)-2):
        if mags[i] > mags[i-1] and mags[i] > mags[i-2] and \
           mags[i] > mags[i+1] and mags[i] > mags[i+2] and \
           mags[i] > peak * 0.12:
            peaks.append((round(freqs[i], 1), round(mags[i]/peak, 3)))
    peaks.sort(key=lambda x: x[1], reverse=True)
    return peaks[:6]

def main():
    if len(sys.argv) < 2:
        print(f"usage: {sys.argv[0]} <samples_dir>", file=sys.stderr)
        sys.exit(1)
    samples_dir = sys.argv[1]
    files = sorted(f for f in os.listdir(samples_dir) if f.endswith('.wav'))

    all_env = []
    all_harms = defaultdict(list)
    all_peaks = defaultdict(list)

    for f in files:
        path = os.path.join(samples_dir, f)
        try:
            samples, sr = load_mono(path)
        except Exception as e:
            print(f"# skip {f}: {e}", file=sys.stderr)
            continue
        env = envelope_metrics(samples, sr)
        if env:
            all_env.append(env)

        # rough fundamental from autocorrelation for clean-ish samples
        # For now just use known sample names or skip if no pitch hint
        peaks = spectral_peaks(samples, sr)
        for freq, mag in peaks:
            bucket = round(freq / 10) * 10
            all_peaks[bucket].append(mag)

    # Aggregate
    env_avg = {
        'attack_ms': round(sum(e['attack_ms'] for e in all_env)/len(all_env), 1),
        'decay50_ms': round(sum(e['decay50_ms'] for e in all_env if e['decay50_ms'])/len([e for e in all_env if e['decay50_ms']]), 1) if any(e['decay50_ms'] for e in all_env) else None,
        'decay10_ms': round(sum(e['decay10_ms'] for e in all_env if e['decay10_ms'])/len([e for e in all_env if e['decay10_ms']]), 1) if any(e['decay10_ms'] for e in all_env) else None,
    }

    common_peaks = []
    for bucket in sorted(all_peaks.keys()):
        mags = all_peaks[bucket]
        if len(mags) >= 2:
            common_peaks.append((bucket, round(sum(mags)/len(mags), 3), len(mags)))
    common_peaks.sort(key=lambda x: x[1], reverse=True)

    profile = {
        'envelope': env_avg,
        'common_peaks_hz': [p[0] for p in common_peaks[:8]],
        'common_peak_mags': {str(p[0]): p[1] for p in common_peaks[:8]},
    }

    print(json.dumps(profile, indent=2))

if __name__ == '__main__':
    main()
