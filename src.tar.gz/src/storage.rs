//! Deterministic accounting for retained BASIC value payloads.
//!
//! The native runtime does not expose host allocator state. Instead, it owns a
//! configurable budget for payload bytes retained by scalar variables and
//! explicitly written sparse-array elements. Integers and reals each consume
//! eight bytes; strings consume their UTF-8 byte length. Replacements release
//! the prior payload before the new value is charged.

use crate::error::Error;
use crate::value::Value;

/// Default retained-value payload budget for modern 64-bit mode (64 MiB).
pub const DEFAULT_MAX_STORAGE_BYTES: usize = 64 * 1_048_576;
/// Default retained-value payload budget for legacy mode.
///
/// The value fits in the legacy signed integer range so `FRE(0)` can report
/// the complete default budget exactly.
pub const LEGACY_MAX_STORAGE_BYTES: usize = 32_767;

/// A deterministic aggregate budget for values retained by a BASIC program.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StorageBudget {
    max_bytes: usize,
    used_bytes: usize,
}

impl StorageBudget {
    /// Create an empty budget with the supplied byte limit.
    pub const fn new(max_bytes: usize) -> Self {
        Self {
            max_bytes,
            used_bytes: 0,
        }
    }

    /// Configured payload limit.
    pub const fn max_bytes(&self) -> usize {
        self.max_bytes
    }

    /// Payload currently retained by variables and written array elements.
    pub const fn used_bytes(&self) -> usize {
        self.used_bytes
    }

    /// Payload still available before the configured limit is reached.
    pub const fn remaining_bytes(&self) -> usize {
        self.max_bytes - self.used_bytes
    }

    /// Release all charges while preserving the configured limit.
    pub fn clear(&mut self) {
        self.used_bytes = 0;
    }

    /// Atomically account for replacing one retained value with another.
    pub(crate) fn replace(
        &mut self,
        previous: Option<&Value>,
        replacement: &Value,
    ) -> Result<(), Error> {
        let previous_bytes = previous.map_or(0, payload_bytes);
        let replacement_bytes = payload_bytes(replacement);
        let without_previous = self
            .used_bytes
            .checked_sub(previous_bytes)
            .ok_or_else(|| Error::syntax("internal retained-storage accounting underflow"))?;
        let next =
            without_previous
                .checked_add(replacement_bytes)
                .ok_or(Error::StorageLimitExceeded {
                    limit: self.max_bytes,
                })?;
        if next > self.max_bytes {
            return Err(Error::StorageLimitExceeded {
                limit: self.max_bytes,
            });
        }
        self.used_bytes = next;
        Ok(())
    }

    /// Release the payload charge for a retained value that is being removed.
    pub(crate) fn remove(&mut self, value: &Value) -> Result<(), Error> {
        self.used_bytes = self
            .used_bytes
            .checked_sub(payload_bytes(value))
            .ok_or_else(|| Error::syntax("internal retained-storage accounting underflow"))?;
        Ok(())
    }
}

/// Deterministic retained payload size of one runtime value.
pub fn payload_bytes(value: &Value) -> usize {
    match value {
        Value::Integer(_) | Value::Real(_) => size_of::<i64>(),
        Value::Complex(_) => size_of::<i64>() * 2,
        Value::List(values) => values
            .iter()
            .map(payload_bytes)
            .try_fold(0_usize, usize::checked_add)
            .unwrap_or(usize::MAX),
        Value::String(text) => text.len(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn replacement_releases_previous_payload() {
        let mut budget = StorageBudget::new(12);
        budget
            .replace(None, &Value::String("abcdefgh".into()))
            .unwrap();
        assert_eq!(budget.used_bytes(), 8);
        assert_eq!(budget.remaining_bytes(), 4);

        budget
            .replace(
                Some(&Value::String("abcdefgh".into())),
                &Value::String("xy".into()),
            )
            .unwrap();
        assert_eq!(budget.used_bytes(), 2);
        assert_eq!(budget.remaining_bytes(), 10);
    }

    #[test]
    fn failed_replacement_preserves_accounting() {
        let mut budget = StorageBudget::new(8);
        budget.replace(None, &Value::Integer(1)).unwrap();
        assert_eq!(
            budget.replace(None, &Value::Integer(2)).unwrap_err(),
            Error::StorageLimitExceeded { limit: 8 }
        );
        assert_eq!(budget.used_bytes(), 8);
    }

    #[test]
    fn clear_releases_every_charge_without_changing_limit() {
        let mut budget = StorageBudget::new(16);
        budget.replace(None, &Value::Integer(1)).unwrap();
        budget.clear();
        assert_eq!(budget.max_bytes(), 16);
        assert_eq!(budget.used_bytes(), 0);
        assert_eq!(budget.remaining_bytes(), 16);
    }

    #[test]
    fn removing_a_value_releases_its_payload() {
        let mut budget = StorageBudget::new(16);
        let value = Value::Integer(7);
        budget.replace(None, &value).unwrap();
        budget.remove(&value).unwrap();
        assert_eq!(budget.used_bytes(), 0);
    }
}
