use std::io::ErrorKind;
use std::path::Path;

use crate::error::Error;

pub(crate) const COLOR_CONFIG_FILENAME: &str = "modernbasic.cfg";

/// User-selectable colors for the native shell and program-window text UI.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ColorPrefs {
    pub screen_color: String,
    pub text_color: String,
}

impl Default for ColorPrefs {
    fn default() -> Self {
        Self {
            screen_color: "#000000".to_string(),
            text_color: "#00ff00".to_string(),
        }
    }
}

impl ColorPrefs {
    pub fn load(file_root: Option<&Path>) -> Result<Self, Error> {
        let Some(file_root) = file_root else {
            return Ok(Self::default());
        };
        let path = file_root.join(COLOR_CONFIG_FILENAME);
        let contents = match std::fs::read_to_string(&path) {
            Ok(contents) => contents,
            Err(error) if error.kind() == ErrorKind::NotFound => return Ok(Self::default()),
            Err(error) => {
                return Err(Error::Io(format!(
                    "cannot read color preferences from {COLOR_CONFIG_FILENAME}: {error}"
                )))
            }
        };
        Self::parse(&contents)
    }

    pub fn save(&self, file_root: Option<&Path>) -> Result<(), Error> {
        let Some(file_root) = file_root else {
            return Ok(());
        };
        let path = file_root.join(COLOR_CONFIG_FILENAME);
        let contents = format!(
            "screen_color={}\ntext_color={}\n",
            self.screen_color, self.text_color
        );
        std::fs::write(&path, contents).map_err(|error| {
            Error::Io(format!(
                "cannot save color preferences to {COLOR_CONFIG_FILENAME}: {error}"
            ))
        })
    }

    pub fn normalize_hex(value: &str) -> Result<String, Error> {
        let value = value.trim();
        if value.len() != 7
            || !value.starts_with('#')
            || !value[1..].bytes().all(|byte| byte.is_ascii_hexdigit())
        {
            return Err(Error::syntax(
                "color must use the #rrggbb hexadecimal format",
            ));
        }
        Ok(value.to_ascii_lowercase())
    }

    fn parse(contents: &str) -> Result<Self, Error> {
        let mut prefs = Self::default();
        for raw_line in contents.lines() {
            let line = raw_line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let Some((key, value)) = line.split_once('=') else {
                return Err(Error::syntax(format!(
                    "invalid {COLOR_CONFIG_FILENAME} entry: {line}"
                )));
            };
            match key.trim().to_ascii_lowercase().as_str() {
                "screen_color" => prefs.screen_color = Self::normalize_hex(value)?,
                "text_color" => prefs.text_color = Self::normalize_hex(value)?,
                _ => {}
            }
        }
        Ok(prefs)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_use_classic_green_on_black() {
        let prefs = ColorPrefs::default();
        assert_eq!(prefs.screen_color, "#000000");
        assert_eq!(prefs.text_color, "#00ff00");
    }

    #[test]
    fn config_round_trip_normalizes_hex_colors() {
        let root = std::env::temp_dir().join(format!(
            "modernbasic-color-prefs-{}-{:?}",
            std::process::id(),
            std::thread::current().id()
        ));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir(&root).unwrap();
        let prefs = ColorPrefs {
            screen_color: ColorPrefs::normalize_hex("#A0B1C2").unwrap(),
            text_color: ColorPrefs::normalize_hex("#D3E4F5").unwrap(),
        };
        prefs.save(Some(&root)).unwrap();
        assert_eq!(ColorPrefs::load(Some(&root)).unwrap(), prefs);
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn invalid_hex_colors_are_rejected() {
        for value in ["00ff00", "#0f0", "#00ff0000", "#00fg00"] {
            assert!(matches!(
                ColorPrefs::normalize_hex(value),
                Err(Error::Syntax { .. })
            ));
        }
    }
}
