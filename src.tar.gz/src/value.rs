use std::collections::HashMap;
use std::fmt;

use crate::complex::BasicComplex;
use crate::real::BasicReal;

/// A runtime value in the ModernBASIC interpreter.
///
/// This slice supports exact integers, finite reals, finite complex numbers,
/// lists, and Unicode strings. Variable storage follows the Microsoft suffix
/// rules documented by [`VariableType`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Value {
    Integer(i64),
    Real(BasicReal),
    Complex(BasicComplex),
    List(Vec<Value>),
    String(String),
}

impl Value {
    /// Construct an integer value.
    pub fn integer(value: i64) -> Self {
        Value::Integer(value)
    }

    /// Construct a string value.
    pub fn string(value: impl Into<String>) -> Self {
        Value::String(value.into())
    }

    /// Construct a checked real value.
    pub fn real(value: f64) -> Result<Self, crate::error::Error> {
        BasicReal::new(value).map(Value::Real)
    }

    /// Returns `true` if the value is an integer.
    pub fn is_integer(&self) -> bool {
        matches!(self, Value::Integer(_))
    }

    /// Returns `true` if the value is a string.
    pub fn is_string(&self) -> bool {
        matches!(self, Value::String(_))
    }

    /// Returns `true` for exact integers and finite real values.
    pub fn is_numeric(&self) -> bool {
        matches!(self, Value::Integer(_) | Value::Real(_) | Value::Complex(_))
    }

    /// The BASIC type name used in diagnostics.
    pub fn type_name(&self) -> &'static str {
        match self {
            Value::Integer(_) => "integer",
            Value::Real(_) => "real",
            Value::Complex(_) => "complex",
            Value::List(_) => "list",
            Value::String(_) => "string",
        }
    }

    /// The integer payload, if this is an integer.
    pub fn as_integer(&self) -> Option<i64> {
        match self {
            Value::Integer(n) => Some(*n),
            Value::Real(_) | Value::Complex(_) | Value::List(_) | Value::String(_) => None,
        }
    }

    /// Return an exact integer, accepting integral in-range real values.
    pub fn to_integer(&self) -> Result<i64, crate::error::Error> {
        match self {
            Value::Integer(value) => Ok(*value),
            Value::Real(value) => value.to_integer(),
            Value::Complex(_) | Value::List(_) | Value::String(_) => {
                Err(crate::error::Error::TypeMismatch)
            }
        }
    }

    /// Return whether a numeric value is nonzero.
    pub fn numeric_truth(&self) -> Result<bool, crate::error::Error> {
        match self {
            Value::Integer(value) => Ok(*value != 0),
            Value::Real(value) => Ok(!value.is_zero()),
            Value::Complex(value) => Ok(!value.is_zero()),
            Value::List(_) | Value::String(_) => Err(crate::error::Error::TypeMismatch),
        }
    }

    /// A string slice, if this is a string.
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Value::Integer(_) | Value::Real(_) | Value::Complex(_) | Value::List(_) => None,
            Value::String(s) => Some(s),
        }
    }

    /// The owned string payload, if this is a string.
    pub fn into_string(self) -> Option<String> {
        match self {
            Value::Integer(_) | Value::Real(_) | Value::Complex(_) | Value::List(_) => None,
            Value::String(s) => Some(s),
        }
    }

    /// The byte length of a string value, or `0` for a numeric value.
    pub fn byte_len(&self) -> usize {
        match self {
            Value::Integer(_) | Value::Real(_) | Value::Complex(_) => 0,
            Value::List(values) => values.iter().map(Value::byte_len).sum(),
            Value::String(s) => s.len(),
        }
    }
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Value::Integer(n) => write!(f, "{n}"),
            Value::Real(n) => write!(f, "{n}"),
            Value::Complex(n) => write!(f, "{n}"),
            Value::List(values) => {
                write!(f, "{{")?;
                for (index, value) in values.iter().enumerate() {
                    if index > 0 {
                        write!(f, ",")?;
                    }
                    write!(f, "{value}")?;
                }
                write!(f, "}}")
            }
            Value::String(s) => write!(f, "{s}"),
        }
    }
}

/// A variable store mapping BASIC variable names to their typed values.
pub type Variables = HashMap<String, Value>;

/// Microsoft BASIC type-declaration suffix attached to a variable name.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VariableType {
    /// Unsuffixed numeric variable. ModernBASIC preserves the exact integer/real
    /// value produced by the expression evaluator.
    Numeric,
    /// `$` string variable.
    String,
    /// `%` integer variable. ModernBASIC stores it as a signed 32-bit value.
    Integer,
    /// `&` long-integer variable. ModernBASIC stores it as a signed 64-bit value.
    Long,
    /// `!` single-precision variable.
    Single,
    /// `#` double-precision variable.
    Double,
}

/// Return the declared suffix type of a BASIC variable.
pub fn variable_type(name: &str) -> VariableType {
    match name.chars().last() {
        Some('$') => VariableType::String,
        Some('%') => VariableType::Integer,
        Some('&') => VariableType::Long,
        Some('!') => VariableType::Single,
        Some('#') => VariableType::Double,
        _ => VariableType::Numeric,
    }
}

/// Returns `true` if `name` denotes a string variable.
pub fn is_string_variable(name: &str) -> bool {
    variable_type(name) == VariableType::String
}

/// The default value for a missing variable of the given name.
///
/// Missing numeric variables evaluate as `0`; missing string variables evaluate
/// as the empty string.
pub fn default_for(name: &str) -> Value {
    if is_string_variable(name) {
        Value::String(String::new())
    } else {
        Value::Integer(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::error::Error;

    #[test]
    fn value_constructors_and_predicates() {
        let v = Value::integer(42);
        assert!(v.is_integer());
        assert!(!v.is_string());
        assert_eq!(v.type_name(), "integer");
        assert_eq!(v.as_integer(), Some(42));
        assert_eq!(v.as_str(), None);
        assert_eq!(v.byte_len(), 0);

        let real = Value::real(1.5).unwrap();
        assert!(real.is_numeric());
        assert!(!real.is_integer());
        assert_eq!(real.type_name(), "real");
        assert_eq!(real.to_integer().unwrap_err(), Error::IntegerRequired);

        let s = Value::string("hello");
        assert!(!s.is_integer());
        assert!(s.is_string());
        assert_eq!(s.type_name(), "string");
        assert_eq!(s.as_integer(), None);
        assert_eq!(s.as_str(), Some("hello"));
        assert_eq!(s.byte_len(), 5);
    }

    #[test]
    fn display_renders_without_quotes() {
        assert_eq!(Value::integer(-7).to_string(), "-7");
        assert_eq!(Value::real(1.25).unwrap().to_string(), "1.25");
        assert_eq!(Value::string("abc").to_string(), "abc");
    }

    #[test]
    fn variable_typing_by_suffix() {
        assert_eq!(variable_type("A"), VariableType::Numeric);
        assert_eq!(variable_type("A$"), VariableType::String);
        assert_eq!(variable_type("A%"), VariableType::Integer);
        assert_eq!(variable_type("A&"), VariableType::Long);
        assert_eq!(variable_type("A!"), VariableType::Single);
        assert_eq!(variable_type("A#"), VariableType::Double);
        assert!(is_string_variable("LONGNAME$"));
        assert!(!is_string_variable("A1"));
    }

    #[test]
    fn default_missing_values() {
        assert_eq!(default_for("X"), Value::Integer(0));
        assert_eq!(default_for("X$"), Value::String(String::new()));
    }
}
