//! Persistent graphics scene assembled by numbered ModernBASIC statements.
//!
//! The BASIC runtime owns scene state and serializes deterministic Artist Script
//! for its built-in pure-Rust Artist raster port. Live frames are rendered in
//! process; serialization is also retained for explicit file exports.

#![allow(clippy::too_many_arguments)]

use std::fmt::Write as _;

use crate::error::Error;

pub const DEFAULT_ARTIST_WIDTH: u32 = 1024;
pub const DEFAULT_ARTIST_HEIGHT: u32 = 768;
pub const DEFAULT_ARTIST_BACKGROUND: &str = "#ffffff";
pub const MAX_ARTIST_DIMENSION: u32 = 65_535;
pub const MAX_ARTIST_PIXELS: usize = 16_777_216;
pub const MAX_ARTIST_COMMANDS: usize = 1_000_000;

#[derive(Debug, Clone, PartialEq, Eq)]
struct PixelRun {
    x: usize,
    y: usize,
    pixels: Vec<u32>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ArtistScene {
    width: u32,
    height: u32,
    background: String,
    commands: Vec<String>,
    /// Consecutive device-space PSET calls are retained as one raster row.
    /// This keeps pixel paintings compact without changing the Artist export
    /// or renderer protocol.
    pending_pixel_run: Option<PixelRun>,
    layer_stack: Vec<String>,
    group_depth: usize,
    depth_grid_defined: bool,
}

impl Default for ArtistScene {
    fn default() -> Self {
        Self {
            width: DEFAULT_ARTIST_WIDTH,
            height: DEFAULT_ARTIST_HEIGHT,
            layer_stack: Vec::new(),
            group_depth: 0,
            depth_grid_defined: false,
            background: DEFAULT_ARTIST_BACKGROUND.to_string(),
            commands: Vec::new(),
            pending_pixel_run: None,
        }
    }
}

impl ArtistScene {
    pub fn set_screen(&mut self, width: i64, height: i64, background: &str) -> Result<(), Error> {
        let width = checked_dimension(width)?;
        let height = checked_dimension(height)?;
        let pixels = (width as usize)
            .checked_mul(height as usize)
            .ok_or(Error::IllegalQuantity)?;
        if pixels > MAX_ARTIST_PIXELS {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(background)?;
        self.layer_stack.clear();
        self.group_depth = 0;
        self.depth_grid_defined = false;
        self.width = width;
        self.height = height;
        self.background = background.to_string();
        self.commands.clear();
        self.pending_pixel_run = None;
        Ok(())
    }

    pub fn clear(&mut self, background: Option<&str>) -> Result<(), Error> {
        if let Some(background) = background {
            validate_style_atom(background)?;
            self.background = background.to_string();
        }
        self.commands.clear();
        self.pending_pixel_run = None;
        self.layer_stack.clear();
        self.group_depth = 0;
        self.depth_grid_defined = false;
        Ok(())
    }

    pub fn line(
        &mut self,
        x1: f64,
        y1: f64,
        x2: f64,
        y2: f64,
        stroke: &str,
        width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[x1, y1, x2, y2, width])?;
        if width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        self.push(format!(
            "line {x1} {y1} {x2} {y2} stroke={stroke} stroke-width={width}"
        ))
    }

    pub fn brush_stroke(
        &mut self,
        x1: f64,
        y1: f64,
        x2: f64,
        y2: f64,
        size: f64,
        color: &str,
        hardness: f64,
        opacity: f64,
        flow: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[x1, y1, x2, y2, size, hardness, opacity, flow])?;
        if !(0.1..=2_048.0).contains(&size)
            || !(0.0..=1.0).contains(&hardness)
            || !(0.0..=1.0).contains(&opacity)
            || !(0.0..=1.0).contains(&flow)
        {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(color)?;
        self.push(format!(
            "brush {x1} {y1} {x2} {y2} {size} {color} {hardness} {opacity} {flow}"
        ))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn rectangle(
        &mut self,
        x: f64,
        y: f64,
        width: f64,
        height: f64,
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[x, y, width, height, stroke_width])?;
        if width < 0.0 || height < 0.0 || stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        self.push(format!(
            "rectangle {x} {y} {width} {height} fill={fill} stroke={stroke} stroke-width={stroke_width}"
        ))
    }

    pub fn bitmap(
        &mut self,
        path: &str,
        x: f64,
        y: f64,
        width: f64,
        height: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[x, y, width, height])?;
        if path.is_empty() || width <= 0.0 || height <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        self.push(format!("bitmap \"{path}\" {x} {y} {width} {height}"))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn bitmap_warp(
        &mut self,
        path: &str,
        anchor_x: f64,
        anchor_y: f64,
        width: f64,
        height: f64,
        angle: f64,
        bend: f64,
        turn: f64,
        light: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[anchor_x, anchor_y, width, height, angle, bend, turn, light])?;
        if path.is_empty()
            || width <= 0.0
            || height <= 0.0
            || !(-1.0..=1.0).contains(&bend)
            || !(-1.0..=1.0).contains(&turn)
            || !(0.0..=2.0).contains(&light)
        {
            return Err(Error::IllegalQuantity);
        }
        self.push(format!(
            "bitmap_warp \"{path}\" {anchor_x} {anchor_y} {width} {height} {angle} {bend} {turn} {light}"
        ))
    }

    /// Retain an in-memory ARGB raster without routing it through a temporary
    /// image file. Graphics PUT uses this so later vector commands preserve
    /// their ordering relative to the copied pixels.
    pub(crate) fn raster_blit(
        &mut self,
        x: usize,
        y: usize,
        width: usize,
        height: usize,
        pixels: &[u32],
    ) -> Result<(), Error> {
        let expected = width.checked_mul(height).ok_or(Error::IllegalQuantity)?;
        if width == 0 || height == 0 || pixels.len() != expected {
            return Err(Error::IllegalQuantity);
        }
        let raw_payload_bytes = expected.checked_mul(9).ok_or(Error::IllegalQuantity)?;
        let mut rle_payload_bytes = 0usize;
        let mut run_start = 0usize;
        for index in 1..=pixels.len() {
            if index == pixels.len() || pixels[index] != pixels[run_start] {
                let run_length = index - run_start;
                rle_payload_bytes = rle_payload_bytes
                    .checked_add(decimal_digits(run_length))
                    .and_then(|value| value.checked_add(10))
                    .ok_or(Error::IllegalQuantity)?;
                run_start = index;
            }
        }
        let use_rle = rle_payload_bytes.saturating_add(4) < raw_payload_bytes;
        let payload_capacity = if use_rle {
            rle_payload_bytes
        } else {
            raw_payload_bytes
        };
        let mut command = String::with_capacity(payload_capacity.saturating_add(64));
        if use_rle {
            let _ = write!(command, "raster_rle {x} {y} {width} {height}");
            let mut run_pixel = pixels[0];
            let mut run_length = 0usize;
            for &pixel in pixels {
                if pixel == run_pixel {
                    run_length += 1;
                } else {
                    let _ = write!(command, " {run_length}:{run_pixel:08x}");
                    run_pixel = pixel;
                    run_length = 1;
                }
            }
            let _ = write!(command, " {run_length}:{run_pixel:08x}");
        } else {
            let _ = write!(command, "raster {x} {y} {width} {height}");
            for pixel in pixels {
                let _ = write!(command, " {pixel:08x}");
            }
        }
        self.push(command)
    }

    pub(crate) fn set_clip(
        &mut self,
        clip: Option<(usize, usize, usize, usize)>,
    ) -> Result<(), Error> {
        match clip {
            Some((left, top, right, bottom)) if left <= right && top <= bottom => {
                self.push(format!("clip {left} {top} {right} {bottom}"))
            }
            Some(_) => Err(Error::IllegalQuantity),
            None => self.push("clip_reset".to_string()),
        }
    }

    pub(crate) fn set_coordinate_transform(
        &mut self,
        scale_x: f64,
        scale_y: f64,
        translate_x: f64,
        translate_y: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[scale_x, scale_y, translate_x, translate_y])?;
        if scale_x == 0.0 || scale_y == 0.0 {
            return Err(Error::IllegalQuantity);
        }
        self.push(format!(
            "coordinate_transform {scale_x} {scale_y} {translate_x} {translate_y}"
        ))
    }

    pub fn pixel(&mut self, x: f64, y: f64, fill: &str) -> Result<(), Error> {
        validate_coordinates(&[x, y])?;
        validate_style_atom(fill)?;
        self.push(format!("pixel {x} {y} fill={fill}"))
    }

    /// Retain an already mapped true-color pixel. Adjacent pixels on the same
    /// scanline are coalesced into one inline raster command.
    pub(crate) fn pixel_argb(&mut self, x: usize, y: usize, color: u32) -> Result<(), Error> {
        if let Some(run) = &mut self.pending_pixel_run {
            if run.y == y && run.x.checked_add(run.pixels.len()) == Some(x) {
                run.pixels.push(color);
                return Ok(());
            }
        }
        self.flush_pixel_run()?;
        if self.commands.len() >= MAX_ARTIST_COMMANDS {
            return Err(Error::syntax("Artist scene command limit exceeded"));
        }
        self.pending_pixel_run = Some(PixelRun {
            x,
            y,
            pixels: vec![color],
        });
        Ok(())
    }

    pub fn point(&mut self, x: f64, y: f64, radius: f64, fill: &str) -> Result<(), Error> {
        validate_coordinates(&[x, y, radius])?;
        if radius < 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(fill)?;
        self.push(format!("point {x} {y} {radius} fill={fill} stroke=none"))
    }

    pub fn ellipse(
        &mut self,
        x: f64,
        y: f64,
        rx: f64,
        ry: f64,
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[x, y, rx, ry, stroke_width])?;
        if rx < 0.0 || ry < 0.0 || stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        self.push(format!(
            "ellipse {x} {y} {rx} {ry} fill={fill} stroke={stroke} stroke-width={stroke_width}"
        ))
    }

    pub fn polygon(
        &mut self,
        points: &[(f64, f64)],
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        if points.len() < 2 || stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        for &(x, y) in points {
            validate_coordinates(&[x, y])?;
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        let mut command = String::from("polygon");
        for &(x, y) in points {
            let _ = write!(command, " {x} {y}");
        }
        let _ = write!(
            command,
            " fill={fill} stroke={stroke} stroke-width={stroke_width}"
        );
        self.push(command)
    }

    pub fn polyline(
        &mut self,
        points: &[(f64, f64)],
        stroke: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        if points.len() < 2 || stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        for &(x, y) in points {
            validate_coordinates(&[x, y])?;
        }
        validate_style_atom(stroke)?;
        let mut command = String::from("polyline");
        for &(x, y) in points {
            let _ = write!(command, " {x} {y}");
        }
        let _ = write!(
            command,
            " fill=none stroke={stroke} stroke-width={stroke_width}"
        );
        self.push(command)
    }

    pub fn flood_fill(&mut self, x: f64, y: f64, fill: &str) -> Result<(), Error> {
        validate_coordinates(&[x, y])?;
        validate_style_atom(fill)?;
        self.push(format!("flood {x} {y} fill={fill} stroke=none"))
    }

    pub fn sprite(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        width: f64,
        height: f64,
        fill: &str,
        stroke: &str,
    ) -> Result<(), Error> {
        validate_identifier_atom(id)?;
        validate_coordinates(&[x, y, width, height])?;
        if width < 0.0 || height < 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(fill)?;
        validate_style_atom(stroke)?;
        self.push(format!(
            "sprite {id} {x} {y} {width} {height} fill={fill} stroke={stroke}"
        ))
    }

    pub fn move_sprite(&mut self, id: &str, x: f64, y: f64) -> Result<(), Error> {
        validate_identifier_atom(id)?;
        validate_coordinates(&[x, y])?;
        self.push(format!("movsprite {id} {x} {y}"))
    }

    pub fn circle(
        &mut self,
        x: f64,
        y: f64,
        radius: f64,
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[x, y, radius, stroke_width])?;
        if radius < 0.0 || stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        self.push(format!(
            "circle {x} {y} {radius} fill={fill} stroke={stroke} stroke-width={stroke_width}"
        ))
    }

    pub fn text(&mut self, x: f64, y: f64, size: f64, text: &str, fill: &str) -> Result<(), Error> {
        validate_coordinates(&[x, y, size])?;
        if size <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(fill)?;
        self.push(format!(
            "text {x} {y} {size} \"{}\" fill={fill}",
            escape_artist_string(text)
        ))
    }

    // ── Artist 0.65.0 additions ──

    pub fn gradient(
        &mut self,
        id: &str,
        x1: f64,
        y1: f64,
        x2: f64,
        y2: f64,
        stops: &[(f64, &str)],
    ) -> Result<(), Error> {
        validate_identifier_atom(id)?;
        validate_coordinates(&[x1, y1, x2, y2])?;
        let mut command = format!("gradient {id} {x1} {y1} {x2} {y2}");
        for &(offset, color) in stops {
            validate_style_atom(color)?;
            let _ = write!(command, " stop={offset},{color}");
        }
        self.push(command)
    }

    pub fn radial_gradient(
        &mut self,
        id: &str,
        cx: f64,
        cy: f64,
        fx: f64,
        fy: f64,
        r1: f64,
        r2: f64,
        stops: &[(f64, &str)],
    ) -> Result<(), Error> {
        validate_identifier_atom(id)?;
        validate_coordinates(&[cx, cy, fx, fy, r1, r2])?;
        let mut command = format!("gradient {id} kind=radial {cx} {cy} {fx} {fy} {r1} {r2}");
        for &(offset, color) in stops {
            validate_style_atom(color)?;
            let _ = write!(command, " stop={offset},{color}");
        }
        self.push(command)
    }

    pub fn arc(
        &mut self,
        cx: f64,
        cy: f64,
        rx: f64,
        ry: f64,
        start_angle: f64,
        end_angle: f64,
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[cx, cy, rx, ry, start_angle, end_angle, stroke_width])?;
        if rx < 0.0 || ry < 0.0 || stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        self.push(format!(
            "arc {cx} {cy} {rx} {ry} {start_angle} {end_angle} fill={fill} stroke={stroke} stroke-width={stroke_width}"
        ))
    }

    pub fn rounded_rectangle(
        &mut self,
        x: f64,
        y: f64,
        width: f64,
        height: f64,
        rx: f64,
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[x, y, width, height, rx, stroke_width])?;
        if width < 0.0 || height < 0.0 || rx < 0.0 || stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        self.push(format!(
            "rounded_rectangle {x} {y} {width} {height} {rx} fill={fill} stroke={stroke} stroke-width={stroke_width}"
        ))
    }

    pub fn ngon(
        &mut self,
        cx: f64,
        cy: f64,
        sides: i64,
        radius: f64,
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[cx, cy, radius, stroke_width])?;
        if !(3..=100).contains(&sides) || radius < 0.0 || stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        self.push(format!(
            "ngon {cx} {cy} {sides} {radius} fill={fill} stroke={stroke} stroke-width={stroke_width}"
        ))
    }

    pub fn star(
        &mut self,
        cx: f64,
        cy: f64,
        points: i64,
        outer_radius: f64,
        inner_radius: f64,
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[cx, cy, outer_radius, inner_radius, stroke_width])?;
        if !(3..=50).contains(&points)
            || outer_radius < 0.0
            || inner_radius < 0.0
            || stroke_width <= 0.0
        {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        self.push(format!(
            "star {cx} {cy} {points} {outer_radius} {inner_radius} fill={fill} stroke={stroke} stroke-width={stroke_width}"
        ))
    }

    pub fn path(
        &mut self,
        path_data: &str,
        stroke: &str,
        fill: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[stroke_width])?;
        if stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        validate_style_atom(fill)?;
        if path_data.is_empty() || path_data.len() > 100_000 {
            return Err(Error::syntax("invalid path data"));
        }
        self.push(format!(
            "path \"{}\" fill={fill} stroke={stroke} stroke-width={stroke_width}",
            escape_artist_string(path_data)
        ))
    }

    /// Paint deterministic fractal noise inside a closed vector path.
    pub fn paint_texture(
        &mut self,
        path_data: &str,
        seed: i64,
        scale: f64,
        octaves: i64,
        color1: &str,
        color2: &str,
        opacity: f64,
        blend: &str,
    ) -> Result<(), Error> {
        validate_coordinates(&[scale, opacity])?;
        if path_data.is_empty()
            || path_data.len() > 100_000
            || !(0.25..=4096.0).contains(&scale)
            || !(1..=8).contains(&octaves)
            || !(0.0..=1.0).contains(&opacity)
        {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(color1)?;
        validate_style_atom(color2)?;
        validate_identifier_atom(blend)?;
        if !matches!(
            blend.to_ascii_lowercase().as_str(),
            "normal"
                | "multiply"
                | "screen"
                | "overlay"
                | "darken"
                | "lighten"
                | "difference"
                | "xor"
                | "add"
                | "exclusion"
                | "color-dodge"
                | "color-burn"
                | "hard-light"
                | "soft-light"
                | "erase"
                | "hue"
                | "saturation"
                | "color"
                | "luminosity"
        ) {
            return Err(Error::syntax("invalid PAINT TEXTURE blend mode"));
        }
        self.push(format!(
            "texture \"{}\" {seed} {scale} {octaves} {color1} {color2} opacity={opacity} composite={}",
            escape_artist_string(path_data),
            blend.to_ascii_lowercase()
        ))
    }

    /// Apply a deterministic raster finishing operation to the canvas so far.
    pub fn paint_filter(&mut self, mode: &str, parameters: &[f64]) -> Result<(), Error> {
        validate_coordinates(parameters)?;
        let mode = mode.to_ascii_lowercase();
        let valid = match (mode.as_str(), parameters) {
            ("blur", [radius]) => (0.0..=32.0).contains(radius),
            ("sharpen", [amount]) => (0.0..=4.0).contains(amount),
            ("color", [brightness, contrast, saturation]) => {
                (0.0..=4.0).contains(brightness)
                    && (0.0..=4.0).contains(contrast)
                    && (0.0..=4.0).contains(saturation)
            }
            _ => false,
        };
        if !valid {
            return Err(Error::IllegalQuantity);
        }
        let mut command = format!("raster_filter {mode}");
        for parameter in parameters {
            let _ = write!(command, " {parameter}");
        }
        self.push(command)
    }

    pub fn bezier(
        &mut self,
        x1: f64,
        y1: f64,
        cx1: f64,
        cy1: f64,
        cx2: f64,
        cy2: f64,
        x2: f64,
        y2: f64,
        stroke: &str,
        stroke_width: f64,
    ) -> Result<(), Error> {
        validate_coordinates(&[x1, y1, cx1, cy1, cx2, cy2, x2, y2, stroke_width])?;
        if stroke_width <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_style_atom(stroke)?;
        self.push(format!(
            "bezier {x1} {y1} {cx1} {cy1} {cx2} {cy2} {x2} {y2} stroke={stroke} stroke-width={stroke_width}"
        ))
    }

    pub fn translate(&mut self, dx: f64, dy: f64) -> Result<(), Error> {
        validate_coordinates(&[dx, dy])?;
        self.push(format!("translate {dx} {dy}"))
    }

    pub fn rotate(&mut self, degrees: f64) -> Result<(), Error> {
        validate_coordinates(&[degrees])?;
        self.push(format!("rotate {degrees}"))
    }

    pub fn scale(&mut self, sx: f64, sy: f64) -> Result<(), Error> {
        validate_coordinates(&[sx, sy])?;
        if sx == 0.0 || sy == 0.0 {
            return Err(Error::IllegalQuantity);
        }
        self.push(format!("scale {sx} {sy}"))
    }

    pub fn set_blend(&mut self, mode: &str) -> Result<(), Error> {
        validate_identifier_atom(mode)?;
        self.push(format!("style composite={mode}"))
    }

    pub fn set_opacity(&mut self, opacity: f64) -> Result<(), Error> {
        validate_coordinates(&[opacity])?;
        if !(0.0..=1.0).contains(&opacity) {
            return Err(Error::IllegalQuantity);
        }
        self.push(format!("opacity {opacity}"))
    }

    pub fn begin_layer(&mut self, name: &str) -> Result<(), Error> {
        validate_identifier_atom(name)?;
        self.push(format!("layer {name}"))?;
        self.layer_stack.push(name.to_string());
        Ok(())
    }

    pub fn end_layer(&mut self) -> Result<(), Error> {
        if self.layer_stack.is_empty() {
            return Err(Error::syntax("ENDLAYER without LAYER"));
        }
        self.push("endlayer".to_string())?;
        self.layer_stack.pop();
        Ok(())
    }

    pub fn begin_group(&mut self) -> Result<(), Error> {
        self.push("group".to_string())?;
        self.group_depth = self.group_depth.saturating_add(1);
        Ok(())
    }

    pub fn end_group(&mut self) -> Result<(), Error> {
        if self.group_depth == 0 {
            return Err(Error::syntax("ENDGROUP without GROUP"));
        }
        self.push("endgroup".to_string())?;
        self.group_depth -= 1;
        Ok(())
    }

    pub fn light_source(
        &mut self,
        x: f64,
        y: f64,
        intensity: f64,
        color: &str,
    ) -> Result<(), Error> {
        validate_coordinates(&[x, y, intensity])?;
        validate_style_atom(color)?;
        if !(0.0..=1.0).contains(&intensity) {
            return Err(Error::IllegalQuantity);
        }
        self.push(format!("light_source {x} {y} {intensity} {color}"))
    }

    pub fn depth_grid(&mut self, horizon_pct: f64, rows: i64, rays: i64) -> Result<(), Error> {
        validate_coordinates(&[horizon_pct])?;
        if !(1..=100).contains(&rows)
            || !(3..=100).contains(&rays)
            || !(0.0..=100.0).contains(&horizon_pct)
        {
            return Err(Error::IllegalQuantity);
        }
        self.push(format!(
            "depth_grid horizon={horizon_pct}% rows={rows} rays={rays}"
        ))?;
        self.depth_grid_defined = true;
        Ok(())
    }

    pub fn depth_perception(
        &mut self,
        horizon_pct: f64,
        rows: i64,
        rays: i64,
    ) -> Result<(), Error> {
        validate_coordinates(&[horizon_pct])?;
        if !(1..=100).contains(&rows)
            || !(3..=100).contains(&rays)
            || !(0.0..=100.0).contains(&horizon_pct)
        {
            return Err(Error::IllegalQuantity);
        }
        self.push(format!(
            "depth_perception horizon={horizon_pct}% rows={rows} rays={rays}"
        ))?;
        self.depth_grid_defined = true;
        Ok(())
    }

    pub fn grid_on(&mut self, plane: &str) -> Result<(), Error> {
        if !self.depth_grid_defined {
            return Err(Error::syntax(
                "GRIDON requires DEPTHGRID or DEPTHPERCEPTION",
            ));
        }
        let plane = plane.to_ascii_uppercase();
        if !matches!(plane.as_str(), "SKY" | "GROUND" | "BOTH") {
            return Err(Error::syntax("GRIDON expects SKY, GROUND, or BOTH"));
        }
        self.push(format!("grid_on {}", plane.to_ascii_lowercase()))
    }

    pub fn grid_off(&mut self) -> Result<(), Error> {
        self.push("grid_off".to_string())
    }

    pub fn grid_point(
        &mut self,
        row: i64,
        column: &str,
        plane: &str,
        radius: f64,
        fill: &str,
    ) -> Result<(), Error> {
        if !self.depth_grid_defined {
            return Err(Error::syntax(
                "GRIDPOINT requires DEPTHGRID or DEPTHPERCEPTION",
            ));
        }
        if row < 1 || radius <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        validate_identifier_atom(column)?;
        validate_identifier_atom(plane)?;
        validate_style_atom(fill)?;
        self.push(format!(
            "depth_point row={row} col={} plane={} radius={radius} fill={fill}",
            column.to_ascii_uppercase(),
            plane.to_ascii_lowercase()
        ))
    }

    pub fn raw_command(&mut self, command: &str) -> Result<(), Error> {
        if command.is_empty() || command.len() > 10_000 {
            return Err(Error::syntax("invalid raw Artist command"));
        }
        self.push(command.to_string())
    }

    pub fn to_artist_script(&self) -> String {
        let mut source = String::with_capacity(self.commands.len().saturating_mul(64) + 128);
        let _ = writeln!(
            source,
            "canvas {} {} {}",
            self.width, self.height, self.background
        );
        for command in &self.commands {
            let _ = writeln!(source, "{command}");
        }
        if let Some(run) = &self.pending_pixel_run {
            write_pixel_run(&mut source, run);
        }
        source
    }

    pub fn command_count(&self) -> usize {
        self.commands.len()
            + if self.pending_pixel_run.is_some() {
                1
            } else {
                0
            }
    }

    fn push(&mut self, command: String) -> Result<(), Error> {
        self.flush_pixel_run()?;
        self.push_command(command)
    }

    fn push_command(&mut self, command: String) -> Result<(), Error> {
        if self.commands.len() >= MAX_ARTIST_COMMANDS {
            return Err(Error::syntax("Artist scene command limit exceeded"));
        }
        self.commands.push(command);
        Ok(())
    }

    fn flush_pixel_run(&mut self) -> Result<(), Error> {
        let Some(run) = self.pending_pixel_run.take() else {
            return Ok(());
        };
        let mut command = String::new();
        write_pixel_run(&mut command, &run);
        if command.ends_with('\n') {
            command.pop();
        }
        self.push_command(command)
    }
}

fn write_pixel_run(output: &mut String, run: &PixelRun) {
    let _ = write!(output, "raster {} {} {} 1", run.x, run.y, run.pixels.len());
    for pixel in &run.pixels {
        let _ = write!(output, " {pixel:08x}");
    }
    output.push('\n');
}

fn decimal_digits(mut value: usize) -> usize {
    let mut digits = 1;
    while value >= 10 {
        value /= 10;
        digits += 1;
    }
    digits
}

fn checked_dimension(value: i64) -> Result<u32, Error> {
    let value = u32::try_from(value).map_err(|_| Error::IllegalQuantity)?;
    if value == 0 || value > MAX_ARTIST_DIMENSION {
        return Err(Error::IllegalQuantity);
    }
    Ok(value)
}

fn validate_coordinates(values: &[f64]) -> Result<(), Error> {
    if values.iter().all(|value| value.is_finite()) {
        Ok(())
    } else {
        Err(Error::RealOverflow)
    }
}

fn validate_style_atom(value: &str) -> Result<(), Error> {
    if value.is_empty()
        || value.len() > 256
        || value
            .chars()
            .any(|ch| ch.is_whitespace() || matches!(ch, '"' | '\'' | '\\'))
    {
        return Err(Error::syntax("invalid Artist color or style value"));
    }
    Ok(())
}

fn validate_identifier_atom(value: &str) -> Result<(), Error> {
    if value.is_empty()
        || value.len() > 128
        || !value
            .chars()
            .all(|character| character.is_ascii_alphanumeric() || matches!(character, '_' | '-'))
    {
        return Err(Error::syntax("invalid Artist object identifier"));
    }
    Ok(())
}

fn escape_artist_string(value: &str) -> String {
    value
        .replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\n', "\\n")
        .replace('\r', "\\r")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scene_serializes_deterministically() {
        let mut scene = ArtistScene::default();
        scene.set_screen(320, 200, "#000000").unwrap();
        scene.line(1.0, 2.0, 3.0, 4.0, "#ffffff", 2.0).unwrap();
        scene.text(10.0, 20.0, 12.0, "A \"B\"", "#ff0000").unwrap();
        let source = scene.to_artist_script();
        assert!(source.starts_with("canvas 320 200 #000000\n"));
        assert!(source.contains("line 1 2 3 4 stroke=#ffffff stroke-width=2"));
        assert!(source.contains("text 10 20 12 \"A \\\"B\\\"\""));
    }

    #[test]
    fn adjacent_true_color_pixels_serialize_as_scanline_rasters() {
        let mut scene = ArtistScene::default();
        scene.set_screen(8, 4, "#000000").unwrap();
        scene.pixel_argb(1, 2, 0xffff0000).unwrap();
        scene.pixel_argb(2, 2, 0xff00ff00).unwrap();
        scene.pixel_argb(3, 2, 0xff0000ff).unwrap();
        assert_eq!(scene.command_count(), 1);
        assert!(scene
            .to_artist_script()
            .contains("raster 1 2 3 1 ffff0000 ff00ff00 ff0000ff\n"));

        scene.line(0.0, 0.0, 7.0, 0.0, "#ffffff", 1.0).unwrap();
        let source = scene.to_artist_script();
        assert!(source.find("raster 1 2 3 1").unwrap() < source.find("line 0 0 7 0").unwrap());
        assert_eq!(scene.command_count(), 2);
    }

    #[test]
    fn retained_rasters_choose_compact_run_length_encoding() {
        let mut scene = ArtistScene::default();
        scene.set_screen(16, 8, "#000000").unwrap();
        let pixels = vec![0xff12_3456; 16 * 8];
        scene.raster_blit(0, 0, 16, 8, &pixels).unwrap();
        let source = scene.to_artist_script();
        assert!(source.contains("raster_rle 0 0 16 8 128:ff123456"));
        assert!(source.len() < 100);
    }

    #[test]
    fn layer_and_group_nesting_is_validated_and_reset() {
        let mut scene = ArtistScene::default();
        assert!(scene.end_layer().is_err());
        assert!(scene.end_group().is_err());

        scene.begin_layer("FOREGROUND").unwrap();
        scene.begin_group().unwrap();
        scene.end_group().unwrap();
        scene.end_layer().unwrap();
        assert!(scene
            .to_artist_script()
            .contains("layer FOREGROUND\ngroup\nendgroup\nendlayer\n"));

        scene.begin_layer("TEMP").unwrap();
        scene.begin_group().unwrap();
        scene.clear(None).unwrap();
        assert!(scene.end_layer().is_err());
        assert!(scene.end_group().is_err());
    }

    #[test]
    fn procedural_paint_commands_serialize_and_validate() {
        let mut scene = ArtistScene::default();
        scene
            .paint_texture(
                "M 1 1 L 9 1 L 9 9 L 1 9 Z",
                42,
                8.0,
                4,
                "#173b18",
                "#b7d45b",
                0.75,
                "overlay",
            )
            .unwrap();
        scene.paint_filter("sharpen", &[0.4]).unwrap();
        let source = scene.to_artist_script();
        assert!(source.contains("texture \"M 1 1 L 9 1 L 9 9 L 1 9 Z\" 42 8 4"));
        assert!(source.contains("opacity=0.75 composite=overlay"));
        assert!(source.contains("raster_filter sharpen 0.4"));
        assert_eq!(
            scene
                .paint_texture("M0 0Z", 1, 0.0, 4, "red", "green", 1.0, "normal")
                .unwrap_err(),
            Error::IllegalQuantity
        );
        assert!(scene.paint_filter("blur", &[33.0]).is_err());
        assert!(scene.paint_filter("color", &[1.0, 1.0]).is_err());
    }

    #[test]
    fn invalid_dimensions_and_style_injection_are_rejected() {
        let mut scene = ArtistScene::default();
        assert_eq!(
            scene.set_screen(0, 100, "#fff").unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            scene.set_screen(65_535, 65_535, "#fff").unwrap_err(),
            Error::IllegalQuantity
        );
        assert!(scene
            .line(0.0, 0.0, 1.0, 1.0, "red stroke=evil", 1.0)
            .is_err());
        assert!(scene.grid_on("BOTH").is_err());
        assert!(scene.grid_point(1, "A", "GROUND", 2.0, "red").is_err());
        assert!(scene.depth_grid(50.0, 4, 2).is_err());
        scene.depth_grid(50.0, 4, 4).unwrap();
        scene.grid_on("GROUND").unwrap();
        scene.grid_point(1, "A", "GROUND", 2.0, "red").unwrap();
        scene.clear(None).unwrap();
        assert!(scene.grid_on("BOTH").is_err());
    }
}
