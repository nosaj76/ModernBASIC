use std::fmt;

/// Errors returned by ModernBASIC.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error {
    /// Division or modulo by zero.
    DivideByZero,
    /// Signed integer overflow.
    IntegerOverflow,
    /// Signed integer underflow.
    IntegerUnderflow,
    /// A real-number literal or operation produced NaN or infinity.
    RealOverflow,
    /// A native math function received a value outside its defined domain.
    MathDomain { function: &'static str },
    /// An exact integer cannot be represented exactly as a binary64 value.
    InexactRealConversion { value: i64 },
    /// A non-integral or out-of-range real was used where an integer is required.
    IntegerRequired,
    /// A value is outside the range allowed in `NumericMode::Legacy6502`.
    OutOfLegacyRange { value: i64, min: i64, max: i64 },
    /// Shift distance is negative or too large for a 64-bit integer.
    InvalidShift { shift: i64 },
    /// Operand type mismatch (e.g. bitwise operation on a string token).
    TypeMismatch,
    /// A string exceeds the configured byte limit.
    StringTooLong { length: usize, limit: usize },
    /// Retained scalar and sparse-array value payloads exceed their limit.
    StorageLimitExceeded { limit: usize },
    /// Generic syntax problem with a descriptive message.
    Syntax { msg: String },
    /// User-raised Microsoft BASIC error from the `ERROR` statement.
    UserError { code: i64 },
    /// A virtual address is outside the bounds of the region being accessed.
    VirtualAddressOutOfBounds { address: u64, limit: u64 },
    /// Negative values are not valid virtual addresses.
    NegativeVirtualAddress { value: i64 },
    /// The ordered program store cannot accept another line.
    ProgramFull,
    /// A tokenized binary program declares more lines than the decoder permits.
    ProgramLineLimitExceeded { limit: usize },
    /// A tokenized binary program expands to more tokens than the decoder permits.
    ProgramTokenLimitExceeded { limit: usize },
    /// A requested line number was not found.
    LineNotFound(u64),
    /// Program execution was interrupted by the user.
    Break,
    /// Program execution exceeded the configured step limit.
    StepLimitExceeded { limit: usize },
    /// Program execution exceeded the configured subroutine call-stack depth.
    CallStackExceeded { limit: usize },
    /// Program execution exceeded the configured loop-stack depth.
    LoopStackExceeded { limit: usize },
    /// User-defined function evaluation exceeded its configured recursion depth.
    FunctionStackExceeded { limit: usize },
    /// Expression syntax exceeded the parser's bounded recursion depth.
    ExpressionDepthExceeded { limit: usize },
    /// `FN` called a user-defined function whose `DEF` has not executed.
    UndefinedFunction { name: String },
    /// `RETURN` executed with no active `GOSUB` frame.
    ReturnWithoutGosub,
    /// `NEXT` executed without a matching active `FOR` frame.
    NextWithoutFor { variable: Option<String> },
    /// `CONT` was requested without a retained paused execution session.
    CannotContinue,
    /// `READ` exhausted every available `DATA` item.
    OutOfData { line: u64 },
    /// `READ` could not convert a DATA item to the destination type.
    BadData { line: u64 },
    /// Total number of DATA items exceeds the configured limit.
    DataLimitExceeded { limit: usize },
    /// Runtime INPUT reached EOF before every destination received a value.
    EndOfInput { line: u64 },
    /// Runtime `INPUT` or `GET` data could not be converted.
    BadInput { line: u64 },
    /// Native BASIC file I/O was used without an explicitly configured root.
    FileIoDisabled,
    /// A web or streaming operation was attempted without host permission.
    NetworkAccessDisabled,
    /// Native compilation was attempted without explicit host permission.
    NativeCompilationDisabled,
    /// A network address was not a bounded HTTP or HTTPS URL.
    InvalidNetworkUrl,
    /// A web response exceeded the configured byte limit.
    NetworkLimitExceeded { limit: usize },
    /// A BASIC file path was absolute, escaped the configured root, or used a symlink.
    InvalidFilePath,
    /// A logical file channel was outside the supported byte-sized range.
    InvalidFileChannel { channel: i64 },
    /// A logical file channel is already open.
    FileChannelAlreadyOpen { channel: u8 },
    /// A logical file channel is not open.
    FileChannelNotOpen { channel: u8 },
    /// A logical file channel was used for the wrong direction.
    FileModeMismatch { channel: u8 },
    /// Too many logical files are open concurrently.
    OpenFileLimitExceeded { limit: usize },
    /// File content exceeded the configured per-file byte limit.
    FileLimitExceeded { limit: usize },
    /// A native `VERIFY` target differs from the active canonical program.
    VerificationFailed,
    /// An input file reached EOF.
    EndOfFile { channel: u8 },
    /// An input file field could not be converted for its destination.
    BadFileData { channel: u8 },
    /// SYS/CALL/USR referenced an address with no host-registered safe service.
    SystemServiceNotRegistered { address: usize },
    /// One physical runtime input line exceeded its configured byte limit.
    InputLineTooLong { line: u64, limit: usize },
    /// One INPUT statement consumed too many physical input lines.
    InputLimitExceeded { line: u64, limit: usize },
    /// One `TAB` or `SPC` operation exceeded the configured padding limit.
    PrintLimitExceeded { limit: usize },
    /// A canonical `LIST` result exceeded the configured byte limit.
    ListingLimitExceeded { limit: usize },
    /// One numbered program source line exceeded its configured byte limit.
    SourceLineTooLong { limit: usize },
    /// Numbered program source contained invalid UTF-8.
    InvalidSourceEncoding,
    /// A raw token byte is not recognised by the detokeniser.
    UnknownToken(u8),
    /// I/O error from the CLI environment.
    Io(String),
    /// An array was explicitly dimensioned after it was already in use.
    RedimensionedArray,
    /// Array subscript is out of range or the wrong number of dimensions
    /// was supplied.
    BadSubscript,
    /// Array bound or subscript is negative.
    IllegalQuantity,
    /// Array logical element count exceeds the configured limit.
    ArrayTooLarge,
    /// Two matrices do not have dimensions compatible with an operation.
    MatrixDimensionMismatch,
    /// An operation requiring a square matrix received another shape.
    MatrixNotSquare { rows: usize, columns: usize },
    /// A MAT result does not fit the storage reserved for its target array.
    MatrixCapacityExceeded { requested: usize, reserved: usize },
    /// MAT accepts only Dartmouth vectors and two-dimensional matrices.
    MatrixRankUnsupported { dimensions: usize },
    /// One matrix statement would exceed its deterministic arithmetic budget.
    MatrixOperationLimitExceeded { operations: usize, limit: usize },
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::DivideByZero => write!(f, "division by zero"),
            Error::IntegerOverflow => write!(f, "integer overflow"),
            Error::IntegerUnderflow => write!(f, "integer underflow"),
            Error::RealOverflow => write!(f, "real-number overflow or non-finite result"),
            Error::MathDomain { function } => {
                write!(f, "math domain error in {function}")
            }
            Error::InexactRealConversion { value } => {
                write!(f, "integer {value} cannot be represented exactly as a real")
            }
            Error::IntegerRequired => write!(f, "integer value required"),
            Error::OutOfLegacyRange { value, min, max } => {
                write!(
                    f,
                    "value {value} is outside legacy 6502 range {min}..={max}"
                )
            }
            Error::InvalidShift { shift } => write!(f, "invalid shift distance {shift}"),
            Error::TypeMismatch => write!(f, "type mismatch"),
            Error::StringTooLong { length, limit } => {
                write!(f, "string length {length} bytes exceeds {limit} byte limit")
            }
            Error::StorageLimitExceeded { limit } => {
                write!(f, "retained value payload exceeds {limit} byte limit")
            }
            Error::Syntax { msg } => write!(f, "syntax error: {msg}"),
            Error::UserError { code } => write!(f, "user error {code}"),
            Error::VirtualAddressOutOfBounds { address, limit } => {
                write!(
                    f,
                    "virtual address {address:#x} out of bounds (limit {limit:#x})"
                )
            }
            Error::NegativeVirtualAddress { value } => {
                write!(f, "negative value {value} is not a valid virtual address")
            }
            Error::ProgramFull => write!(f, "program storage full"),
            Error::ProgramLineLimitExceeded { limit } => {
                write!(f, "binary program line limit ({limit}) exceeded")
            }
            Error::ProgramTokenLimitExceeded { limit } => {
                write!(f, "binary program token limit ({limit}) exceeded")
            }
            Error::LineNotFound(n) => write!(f, "line {n} not found"),
            Error::Break => write!(f, "BREAK"),
            Error::StepLimitExceeded { limit } => {
                write!(f, "execution step limit ({limit}) exceeded")
            }
            Error::CallStackExceeded { limit } => {
                write!(f, "call stack depth limit ({limit}) exceeded")
            }
            Error::LoopStackExceeded { limit } => {
                write!(f, "loop stack depth limit ({limit}) exceeded")
            }
            Error::FunctionStackExceeded { limit } => {
                write!(f, "user-function recursion limit ({limit}) exceeded")
            }
            Error::ExpressionDepthExceeded { limit } => {
                write!(f, "expression nesting limit ({limit}) exceeded")
            }
            Error::UndefinedFunction { name } => {
                write!(f, "undefined function FN{name}")
            }
            Error::ReturnWithoutGosub => write!(f, "RETURN without GOSUB"),
            Error::NextWithoutFor { variable } => match variable {
                Some(v) => write!(f, "NEXT {v} without FOR"),
                None => write!(f, "NEXT without FOR"),
            },
            Error::CannotContinue => {
                write!(f, "cannot continue without a paused execution session")
            }
            Error::OutOfData { line } => write!(f, "out of data on line {line}"),
            Error::BadData { line } => write!(f, "bad data on line {line}"),
            Error::DataLimitExceeded { limit } => {
                write!(f, "data item limit ({limit}) exceeded")
            }
            Error::EndOfInput { line } => write!(f, "end of input on line {line}"),
            Error::BadInput { line } => write!(f, "bad input on line {line}"),
            Error::FileIoDisabled => {
                write!(f, "file I/O is disabled; configure a sandbox root")
            }
            Error::NetworkAccessDisabled => {
                write!(
                    f,
                    "network access is disabled; enable the host network capability"
                )
            }
            Error::NativeCompilationDisabled => {
                write!(
                    f,
                    "native compilation is disabled; enable the host compilation capability"
                )
            }
            Error::InvalidNetworkUrl => {
                write!(f, "network URL must be a bounded HTTP or HTTPS address")
            }
            Error::NetworkLimitExceeded { limit } => {
                write!(f, "network response exceeds the {limit} byte limit")
            }
            Error::InvalidFilePath => write!(f, "file path is outside the sandbox policy"),
            Error::InvalidFileChannel { channel } => {
                write!(f, "file channel {channel} is outside 0..=255")
            }
            Error::FileChannelAlreadyOpen { channel } => {
                write!(f, "file channel {channel} is already open")
            }
            Error::FileChannelNotOpen { channel } => {
                write!(f, "file channel {channel} is not open")
            }
            Error::FileModeMismatch { channel } => {
                write!(f, "file channel {channel} has the wrong access mode")
            }
            Error::OpenFileLimitExceeded { limit } => {
                write!(f, "open file limit ({limit}) exceeded")
            }
            Error::FileLimitExceeded { limit } => {
                write!(f, "file byte limit ({limit}) exceeded")
            }
            Error::VerificationFailed => write!(f, "program verification failed"),
            Error::EndOfFile { channel } => write!(f, "end of file on channel {channel}"),
            Error::BadFileData { channel } => write!(f, "bad data on file channel {channel}"),
            Error::SystemServiceNotRegistered { address } => {
                write!(f, "system service {address} is not registered")
            }
            Error::InputLineTooLong { line, limit } => {
                write!(f, "input on line {line} exceeds {limit} byte limit")
            }
            Error::InputLimitExceeded { line, limit } => {
                write!(f, "input on line {line} exceeds {limit} line limit")
            }
            Error::PrintLimitExceeded { limit } => {
                write!(f, "PRINT padding exceeds {limit} column limit")
            }
            Error::ListingLimitExceeded { limit } => {
                write!(f, "program listing exceeds {limit} byte limit")
            }
            Error::SourceLineTooLong { limit } => {
                write!(f, "program source line exceeds {limit} byte limit")
            }
            Error::InvalidSourceEncoding => write!(f, "program source is not valid UTF-8"),
            Error::UnknownToken(b) => write!(f, "unknown token byte 0x{b:02X}"),
            Error::Io(s) => write!(f, "i/o error: {s}"),
            Error::RedimensionedArray => write!(f, "redimensioned array"),
            Error::BadSubscript => write!(f, "bad subscript"),
            Error::IllegalQuantity => write!(f, "illegal quantity"),
            Error::ArrayTooLarge => write!(f, "array too large"),
            Error::MatrixDimensionMismatch => write!(f, "matrix dimension mismatch"),
            Error::MatrixNotSquare { rows, columns } => {
                write!(f, "matrix is not square ({rows} by {columns})")
            }
            Error::MatrixCapacityExceeded {
                requested,
                reserved,
            } => write!(
                f,
                "matrix requires {requested} array elements but only {reserved} were reserved"
            ),
            Error::MatrixRankUnsupported { dimensions } => write!(
                f,
                "MAT requires a one- or two-dimensional array, got {dimensions} dimensions"
            ),
            Error::MatrixOperationLimitExceeded { operations, limit } => write!(
                f,
                "matrix operation requires {operations} arithmetic steps, exceeding limit {limit}"
            ),
        }
    }
}

impl std::error::Error for Error {}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e.to_string())
    }
}

impl Error {
    /// Convenience for creating a syntax error.
    pub fn syntax<S: Into<String>>(msg: S) -> Self {
        Error::Syntax { msg: msg.into() }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn user_interrupt_has_the_classic_break_diagnostic() {
        assert_eq!(Error::Break.to_string(), "BREAK");
    }
}
