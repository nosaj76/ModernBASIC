//! Native TI-BASIC-style graph state rendered by Artist 0.64.
//!
//! This module owns calculator-style coordinates and pixels.  It deliberately
//! does not implement a calculator display emulator: [`TiGraphState`] exports
//! an ordinary Artist Script scene, and Artist performs the actual rendering.

use std::fmt::{self, Write as _};

use crate::error::Error;

/// TI-84 Plus CE graph-area width in pixels.
pub const TI_GRAPH_WIDTH: usize = 265;
/// TI-84 Plus CE graph-area height in pixels.
pub const TI_GRAPH_HEIGHT: usize = 165;
/// Maximum samples used by one `DrawF` or `DrawInv` statement.
pub const TI_GRAPH_SAMPLES: usize = TI_GRAPH_WIDTH;

const TRANSPARENT: u8 = u8::MAX;
const DEFAULT_INK: u8 = 12;

struct BasicLabel(f64);

impl fmt::Display for BasicLabel {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.0.fract() == 0.0 {
            write!(formatter, "{}", self.0 as i64)
        } else {
            let text = format!("{:.2}", self.0);
            write!(
                formatter,
                "{}",
                text.trim_end_matches('0').trim_end_matches('.')
            )
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
struct GraphText {
    row: usize,
    column: usize,
    text: String,
    color: u8,
    size: usize,
}

/// Persistent graph window, drawing buffer, and display flags used by one run.
#[derive(Debug, Clone, PartialEq)]
pub struct TiGraphState {
    pub x_min: f64,
    pub x_max: f64,
    pub x_scale: f64,
    pub y_min: f64,
    pub y_max: f64,
    pub y_scale: f64,
    pub axes: bool,
    pub grid: bool,
    pub labels: bool,
    pub coordinates: bool,
    pub axes_color: u8,
    pub functions_enabled: [bool; 10],
    pub function_styles: [u8; 10],
    pixels: Vec<u8>,
    text: Vec<GraphText>,
}

impl Default for TiGraphState {
    fn default() -> Self {
        Self {
            x_min: -10.0,
            x_max: 10.0,
            x_scale: 1.0,
            y_min: -10.0,
            y_max: 10.0,
            y_scale: 1.0,
            axes: true,
            grid: false,
            labels: false,
            coordinates: true,
            axes_color: DEFAULT_INK,
            functions_enabled: [true; 10],
            function_styles: [1; 10],
            pixels: vec![TRANSPARENT; TI_GRAPH_WIDTH * TI_GRAPH_HEIGHT],
            text: Vec::new(),
        }
    }
}

impl TiGraphState {
    /// Restore the TI standard graph window without clearing drawings.
    pub fn standard_window(&mut self) {
        self.x_min = -10.0;
        self.x_max = 10.0;
        self.x_scale = 1.0;
        self.y_min = -10.0;
        self.y_max = 10.0;
        self.y_scale = 1.0;
    }

    /// Validate and replace graph bounds and tick scales.
    pub fn set_window(
        &mut self,
        x_min: f64,
        x_max: f64,
        x_scale: f64,
        y_min: f64,
        y_max: f64,
        y_scale: f64,
    ) -> Result<(), Error> {
        if !x_min.is_finite()
            || !x_max.is_finite()
            || !x_scale.is_finite()
            || !y_min.is_finite()
            || !y_max.is_finite()
            || !y_scale.is_finite()
            || x_min >= x_max
            || y_min >= y_max
            || x_scale <= 0.0
            || y_scale <= 0.0
        {
            return Err(Error::IllegalQuantity);
        }
        self.x_min = x_min;
        self.x_max = x_max;
        self.x_scale = x_scale;
        self.y_min = y_min;
        self.y_max = y_max;
        self.y_scale = y_scale;
        Ok(())
    }

    /// Clear TI draw operations while retaining window and display settings.
    pub fn clear_drawings(&mut self) {
        self.pixels.fill(TRANSPARENT);
        self.text.clear();
    }

    /// Set, clear, or toggle a graph-area pixel using `(row,column)` order.
    pub fn pixel_set(&mut self, row: i64, column: i64, color: Option<u8>) {
        if let Some(offset) = self.pixel_offset(row, column) {
            self.pixels[offset] = color.unwrap_or(TRANSPARENT);
        }
    }

    pub fn pixel_toggle(&mut self, row: i64, column: i64, color: u8) {
        if let Some(offset) = self.pixel_offset(row, column) {
            self.pixels[offset] = if self.pixels[offset] == TRANSPARENT {
                color
            } else {
                TRANSPARENT
            };
        }
    }

    /// Return whether the final graph pixel is on, including axes and grid.
    pub fn pixel_test(&self, row: i64, column: i64) -> bool {
        let Some(offset) = self.pixel_offset(row, column) else {
            return false;
        };
        if self.pixels[offset] != TRANSPARENT {
            return true;
        }
        self.base_pixel_on(row as usize, column as usize)
    }

    pub fn point_set(&mut self, x: f64, y: f64, color: Option<u8>) {
        if let Some((row, column)) = self.graph_to_pixel(x, y) {
            self.pixel_set(row, column, color);
        }
    }

    pub fn point_toggle(&mut self, x: f64, y: f64, color: u8) {
        if let Some((row, column)) = self.graph_to_pixel(x, y) {
            self.pixel_toggle(row, column, color);
        }
    }

    pub fn point_test(&self, x: f64, y: f64) -> bool {
        self.graph_to_pixel(x, y)
            .is_some_and(|(row, column)| self.pixel_test(row, column))
    }

    pub fn draw_line(&mut self, x0: f64, y0: f64, x1: f64, y1: f64, color: Option<u8>) {
        let (Some((r0, c0)), Some((r1, c1))) =
            (self.graph_to_pixel(x0, y0), self.graph_to_pixel(x1, y1))
        else {
            // Sampling a clipped segment still permits portions crossing the
            // graph window to become visible.
            self.draw_sampled_segment(x0, y0, x1, y1, color);
            return;
        };
        self.draw_pixel_line(c0, r0, c1, r1, color);
    }

    pub fn draw_horizontal(&mut self, y: f64, color: Option<u8>) {
        self.draw_line(self.x_min, y, self.x_max, y, color);
    }

    pub fn draw_vertical(&mut self, x: f64, color: Option<u8>) {
        self.draw_line(x, self.y_min, x, self.y_max, color);
    }

    pub fn draw_circle(&mut self, cx: f64, cy: f64, radius: f64, color: Option<u8>) {
        if !cx.is_finite() || !cy.is_finite() || !radius.is_finite() || radius < 0.0 {
            return;
        }
        let steps = (TI_GRAPH_WIDTH * 4).max(64);
        let mut previous = None;
        for index in 0..=steps {
            let angle = std::f64::consts::TAU * index as f64 / steps as f64;
            let point = (cx + radius * angle.cos(), cy + radius * angle.sin());
            if let Some((x, y)) = previous {
                self.draw_line(x, y, point.0, point.1, color);
            }
            previous = Some(point);
        }
    }

    /// Draw a sampled function in graph coordinates. Domain failures become
    /// discontinuities, matching TI graph behavior.
    pub fn draw_function<F>(&mut self, inverse: bool, color: Option<u8>, mut evaluate: F)
    where
        F: FnMut(f64) -> Option<f64>,
    {
        self.draw_function_styled(inverse, color, 1, &mut evaluate)
            .expect("style 1 is valid");
    }

    /// Draw using TI graph styles 1..=7. Dynamic calculator-only styles are
    /// represented by their deterministic final static image.
    pub fn draw_function_styled<F>(
        &mut self,
        inverse: bool,
        color: Option<u8>,
        style: u8,
        mut evaluate: F,
    ) -> Result<(), Error>
    where
        F: FnMut(f64) -> Option<f64>,
    {
        if !(1..=7).contains(&style) {
            return Err(Error::IllegalQuantity);
        }
        let mut previous = None;
        for index in 0..TI_GRAPH_SAMPLES {
            let independent = self.x_min
                + (self.x_max - self.x_min) * index as f64 / (TI_GRAPH_SAMPLES - 1) as f64;
            let Some(dependent) = evaluate(independent).filter(|value| value.is_finite()) else {
                previous = None;
                continue;
            };
            let point = if inverse {
                (dependent, independent)
            } else {
                (independent, dependent)
            };
            match style {
                3 => self.draw_line(point.0, point.1, point.0, self.y_max, color),
                4 => self.draw_line(point.0, self.y_min, point.0, point.1, color),
                7 => self.point_set(point.0, point.1, color),
                _ => {
                    if let Some((x, y)) = previous {
                        self.draw_line(x, y, point.0, point.1, color);
                    } else {
                        self.point_set(point.0, point.1, color);
                    }
                    if style == 2 {
                        if let Some((row, column)) = self.graph_to_pixel(point.0, point.1) {
                            self.pixel_set(row - 1, column, color);
                            self.pixel_set(row + 1, column, color);
                        }
                    }
                }
            }
            previous = Some(point);
        }
        Ok(())
    }

    /// Fill sampled columns between two functions inside an X interval.
    pub fn shade_between(
        &mut self,
        lower: &[Option<f64>],
        upper: &[Option<f64>],
        x_left: f64,
        x_right: f64,
        color: u8,
    ) -> Result<(), Error> {
        if lower.len() != TI_GRAPH_SAMPLES
            || upper.len() != TI_GRAPH_SAMPLES
            || !x_left.is_finite()
            || !x_right.is_finite()
            || x_left > x_right
        {
            return Err(Error::IllegalQuantity);
        }
        for index in 0..TI_GRAPH_SAMPLES {
            let x = self.x_min
                + (self.x_max - self.x_min) * index as f64 / (TI_GRAPH_SAMPLES - 1) as f64;
            if x < x_left || x > x_right {
                continue;
            }
            let (Some(first), Some(second)) = (lower[index], upper[index]) else {
                continue;
            };
            if first.max(second) < self.y_min || first.min(second) > self.y_max {
                continue;
            }
            let low = first.min(second).max(self.y_min);
            let high = first.max(second).min(self.y_max);
            let (Some((bottom, column)), Some((top, _))) =
                (self.graph_to_pixel(x, low), self.graph_to_pixel(x, high))
            else {
                continue;
            };
            self.draw_pixel_line(column, top, column, bottom, Some(color));
        }
        Ok(())
    }

    pub fn draw_text(
        &mut self,
        row: i64,
        column: i64,
        text: String,
        color: u8,
        size: usize,
    ) -> Result<(), Error> {
        if row < 0
            || column < 0
            || row as usize >= TI_GRAPH_HEIGHT
            || column as usize >= TI_GRAPH_WIDTH
            || !(1..=128).contains(&size)
            || text.len() > 4096
        {
            return Err(Error::IllegalQuantity);
        }
        self.text.push(GraphText {
            row: row as usize,
            column: column as usize,
            text,
            color,
            size,
        });
        Ok(())
    }

    /// Serialize the complete current graph as deterministic Artist Script.
    pub fn to_artist_script(&self) -> String {
        let mut script = String::with_capacity(32_768);
        let _ = writeln!(
            script,
            "canvas {TI_GRAPH_WIDTH} {TI_GRAPH_HEIGHT} {}",
            ti_color(20)
        );
        let _ = writeln!(script, "meta producer modernbasic-ti-graph");
        let _ = writeln!(
            script,
            "meta graph-window {} {} {} {}",
            self.x_min, self.x_max, self.y_min, self.y_max
        );

        if self.grid {
            self.write_grid(&mut script);
        }
        if self.axes {
            self.write_axes(&mut script);
        }
        if self.labels {
            self.write_labels(&mut script);
        }

        for row in 0..TI_GRAPH_HEIGHT {
            let mut column = 0usize;
            while column < TI_GRAPH_WIDTH {
                let color = self.pixels[row * TI_GRAPH_WIDTH + column];
                if color == TRANSPARENT {
                    column += 1;
                    continue;
                }
                let start = column;
                while column + 1 < TI_GRAPH_WIDTH
                    && self.pixels[row * TI_GRAPH_WIDTH + column + 1] == color
                {
                    column += 1;
                }
                let width = column - start + 1;
                let _ = writeln!(
                    script,
                    "rect {start} {row} {width} 1 fill={} stroke=none",
                    ti_color(color)
                );
                column += 1;
            }
        }

        for text in &self.text {
            let _ = writeln!(
                script,
                "text {} {} {} \"{}\" fill={} stroke=none font=monospace",
                text.column,
                text.row.saturating_add(text.size),
                text.size,
                escape_artist_string(&text.text),
                ti_color(text.color)
            );
        }
        script
    }

    fn write_grid(&self, script: &mut String) {
        let color = ti_color(21);
        let mut x = (self.x_min / self.x_scale).ceil() * self.x_scale;
        let mut count = 0usize;
        while x <= self.x_max && count <= TI_GRAPH_WIDTH {
            if let Some((_, column)) = self.graph_to_pixel(x, 0.0) {
                let _ = writeln!(
                    script,
                    "line {column} 0 {column} {} stroke={color} stroke-width=1",
                    TI_GRAPH_HEIGHT - 1
                );
            }
            x += self.x_scale;
            count += 1;
        }
        let mut y = (self.y_min / self.y_scale).ceil() * self.y_scale;
        count = 0;
        while y <= self.y_max && count <= TI_GRAPH_HEIGHT {
            if let Some((row, _)) = self.graph_to_pixel(0.0, y) {
                let _ = writeln!(
                    script,
                    "line 0 {row} {} {row} stroke={color} stroke-width=1",
                    TI_GRAPH_WIDTH - 1
                );
            }
            y += self.y_scale;
            count += 1;
        }
    }

    fn write_axes(&self, script: &mut String) {
        let color = ti_color(self.axes_color);
        if self.x_min <= 0.0 && self.x_max >= 0.0 {
            if let Some((_, column)) = self.graph_to_pixel(0.0, 0.0) {
                let _ = writeln!(
                    script,
                    "line {column} 0 {column} {} stroke={color} stroke-width=1",
                    TI_GRAPH_HEIGHT - 1
                );
            }
        }
        if self.y_min <= 0.0 && self.y_max >= 0.0 {
            if let Some((row, _)) = self.graph_to_pixel(0.0, 0.0) {
                let _ = writeln!(
                    script,
                    "line 0 {row} {} {row} stroke={color} stroke-width=1",
                    TI_GRAPH_WIDTH - 1
                );
            }
        }
    }

    fn write_labels(&self, script: &mut String) {
        let color = ti_color(self.axes_color);
        let x_label_row = self
            .graph_to_pixel(0.0, 0.0)
            .map(|(row, _)| row.saturating_add(7).min((TI_GRAPH_HEIGHT - 1) as i64))
            .unwrap_or((TI_GRAPH_HEIGHT - 2) as i64);
        let mut x = (self.x_min / self.x_scale).ceil() * self.x_scale;
        let mut count = 0usize;
        let pixel_spacing = self.x_scale / (self.x_max - self.x_min) * (TI_GRAPH_WIDTH - 1) as f64;
        let stride = (40.0 / pixel_spacing.max(1.0)).ceil().max(1.0) as usize;
        while x <= self.x_max && count <= 32 {
            if x != 0.0 && count % stride == 0 {
                if let Some((_, column)) = self.graph_to_pixel(x, 0.0) {
                    if (16..(TI_GRAPH_WIDTH as i64 - 16)).contains(&column) {
                        let _ = writeln!(
                            script,
                            "text {column} {x_label_row} 6 \"{}\" fill={color} stroke=none font=monospace align=center",
                            BasicLabel(x)
                        );
                    }
                }
            }
            x += self.x_scale;
            count += 1;
        }
    }

    fn draw_sampled_segment(&mut self, x0: f64, y0: f64, x1: f64, y1: f64, color: Option<u8>) {
        let steps = TI_GRAPH_WIDTH.max(TI_GRAPH_HEIGHT);
        let mut previous = None;
        for index in 0..=steps {
            let t = index as f64 / steps as f64;
            let point = (x0 + (x1 - x0) * t, y0 + (y1 - y0) * t);
            if let Some(pixel) = self.graph_to_pixel(point.0, point.1) {
                if let Some((row, column)) = previous {
                    self.draw_pixel_line(column, row, pixel.1, pixel.0, color);
                } else {
                    self.pixel_set(pixel.0, pixel.1, color);
                }
                previous = Some(pixel);
            }
        }
    }

    fn draw_pixel_line(
        &mut self,
        column0: i64,
        row0: i64,
        column1: i64,
        row1: i64,
        color: Option<u8>,
    ) {
        let mut x = column0;
        let mut y = row0;
        let dx = (column1 - column0).abs();
        let sx = if column0 < column1 { 1 } else { -1 };
        let dy = -(row1 - row0).abs();
        let sy = if row0 < row1 { 1 } else { -1 };
        let mut error = dx + dy;
        loop {
            self.pixel_set(y, x, color);
            if x == column1 && y == row1 {
                break;
            }
            let twice = 2 * error;
            if twice >= dy {
                error += dy;
                x += sx;
            }
            if twice <= dx {
                error += dx;
                y += sy;
            }
        }
    }

    fn graph_to_pixel(&self, x: f64, y: f64) -> Option<(i64, i64)> {
        if !x.is_finite()
            || !y.is_finite()
            || x < self.x_min
            || x > self.x_max
            || y < self.y_min
            || y > self.y_max
        {
            return None;
        }
        let column = ((x - self.x_min) / (self.x_max - self.x_min) * (TI_GRAPH_WIDTH - 1) as f64)
            .round() as i64;
        let row = ((self.y_max - y) / (self.y_max - self.y_min) * (TI_GRAPH_HEIGHT - 1) as f64)
            .round() as i64;
        Some((row, column))
    }

    fn pixel_offset(&self, row: i64, column: i64) -> Option<usize> {
        if row < 0
            || column < 0
            || row as usize >= TI_GRAPH_HEIGHT
            || column as usize >= TI_GRAPH_WIDTH
        {
            None
        } else {
            Some(row as usize * TI_GRAPH_WIDTH + column as usize)
        }
    }

    fn base_pixel_on(&self, row: usize, column: usize) -> bool {
        if self.axes {
            if self.x_min <= 0.0 && self.x_max >= 0.0 {
                if let Some((_, axis_column)) = self.graph_to_pixel(0.0, 0.0) {
                    if column == axis_column as usize {
                        return true;
                    }
                }
            }
            if self.y_min <= 0.0 && self.y_max >= 0.0 {
                if let Some((axis_row, _)) = self.graph_to_pixel(0.0, 0.0) {
                    if row == axis_row as usize {
                        return true;
                    }
                }
            }
        }
        false
    }
}

/// Validate a TI-84 CE color number.
pub fn validate_ti_color(color: i64) -> Result<u8, Error> {
    if (10..=24).contains(&color) {
        Ok(color as u8)
    } else {
        Err(Error::IllegalQuantity)
    }
}

/// Deterministic TI color-number mapping used by Artist Script output.
pub fn ti_color(color: u8) -> &'static str {
    match color {
        10 => "#0000ff", // BLUE
        11 => "#ff0000", // RED
        12 => "#000000", // BLACK
        13 => "#ff00ff", // MAGENTA
        14 => "#008000", // GREEN
        15 => "#ff8000", // ORANGE
        16 => "#8b4513", // BROWN
        17 => "#000080", // NAVY
        18 => "#00bfff", // LTBLUE
        19 => "#ffff00", // YELLOW
        20 => "#ffffff", // WHITE
        21 => "#d3d3d3", // LTGRAY
        22 => "#a9a9a9", // MEDGRAY
        23 => "#808080", // GRAY
        24 => "#404040", // DARKGRAY
        _ => "#000000",
    }
}

fn escape_artist_string(text: &str) -> String {
    text.replace('\\', "\\\\").replace('"', "\\\"")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pixels_points_lines_and_clear_are_queryable() {
        let mut graph = TiGraphState {
            axes: false,
            ..TiGraphState::default()
        };
        graph.pixel_set(4, 3, Some(11));
        assert!(graph.pixel_test(4, 3));
        graph.pixel_toggle(4, 3, 11);
        assert!(!graph.pixel_test(4, 3));
        graph.draw_line(-10.0, -10.0, 10.0, 10.0, Some(10));
        assert!(graph.point_test(0.0, 0.0));
        graph.clear_drawings();
        assert!(!graph.point_test(0.0, 0.0));
    }

    #[test]
    fn artist_script_contains_canvas_axes_runs_and_escaped_text() {
        let mut graph = TiGraphState {
            grid: true,
            ..TiGraphState::default()
        };
        graph.pixel_set(2, 3, Some(11));
        graph.pixel_set(2, 4, Some(11));
        graph.draw_text(5, 6, "A \"B\"".into(), 10, 12).unwrap();
        let source = graph.to_artist_script();
        assert!(source.starts_with("canvas 265 165 #ffffff\n"));
        assert!(source.contains("line 132 0 132 164"));
        assert!(source.contains("rect 3 2 2 1 fill=#ff0000 stroke=none"));
        assert!(source.contains("text 6 17 12 \"A \\\"B\\\"\""));
    }

    #[test]
    fn function_drawing_treats_none_as_a_discontinuity() {
        let mut graph = TiGraphState {
            axes: false,
            ..TiGraphState::default()
        };
        graph.draw_function(false, Some(12), |x| (x != 0.0).then_some(1.0 / x));
        assert!(graph.point_test(-1.0, -1.0));
        assert!(graph.point_test(1.0, 1.0));
    }

    #[test]
    fn window_and_color_validation_are_bounded() {
        let mut graph = TiGraphState::default();
        assert!(graph.set_window(-2.0, 2.0, 1.0, -3.0, 3.0, 1.0).is_ok());
        assert!(graph.set_window(2.0, -2.0, 1.0, -3.0, 3.0, 1.0).is_err());
        assert_eq!(validate_ti_color(10).unwrap(), 10);
        assert!(validate_ti_color(9).is_err());
    }
}
