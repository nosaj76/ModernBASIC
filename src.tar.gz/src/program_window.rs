//! Per-program X11 windows and interpreter-task lifecycle.
//!
//! This is a child module of `shell`: Xlib remains declared in one place, while
//! every program window owns its X11 resources, raster, input devices, channels,
//! and interpreter worker.

use std::collections::{HashMap, VecDeque};
use std::ffi::CString;
use std::os::raw::{c_char, c_int, c_long, c_uint, c_ulong, c_void};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver, Sender, TryRecvError};
use std::sync::{Arc, Mutex};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use crate::error::Error;
use crate::help::HelpViewer;
use crate::interpreter::{set_thread_interrupt_flag, RunOptions};
use crate::program::Program;
use crate::repl::run_repl_with_initial_program_options;
use crate::screen::{
    set_thread_interpreter_event_sender, set_thread_key_queue, set_thread_key_state,
    set_thread_pointer_state, InterpreterEvent, InterpreterOutputWriter, KeyState, PointerState,
    ScreenEvent, ScreenView, SharedDisplayInfo, SharedKeyQueue, SharedKeyState, SharedPointerState,
};

use super::{
    activate_window, byte_index_for_character, draw_ascii, draw_help_dialog,
    handle_help_dialog_key, help_dialog_capacity, map_pointer_to_raster,
    prepare_integrated_raster_source, put_raster_to_window, raster_viewport, selected_text,
    selection_span, serve_text_selection, set_window_fullscreen, set_window_pointer_visible,
    set_window_resizable, Atom, ChannelReader, ColorPrefs, Display, Font, GraphicsScaleMode,
    KeySym, RasterImage, RasterWindowTarget, TerminalBuffer, TerminalRow, Time, Window,
    X11ColorCache, X11Colors, X11RasterSurface, XButtonEvent, XConfigureEvent, XConvertSelection,
    XCreateGC, XCreateSimpleWindow, XDeleteProperty, XDestroyWindow, XFillRectangle, XFlush, XFree,
    XFreeGC, XGetWindowProperty, XLookupString, XMapWindow, XRaiseWindow, XResizeWindow,
    XSelectInput, XSelectionClearEvent, XSelectionEvent, XSelectionRequestEvent, XSetBackground,
    XSetFont, XSetForeground, XSetSelectionOwner, XSetWMProtocols, XSetWindowBackground,
    XStoreName, BUTTON_PRESS_MASK, BUTTON_RELEASE_MASK, CONTROL_MASK, EXPOSURE_MASK,
    FOCUS_CHANGE_MASK, FONT_ASCENT, FONT_HEIGHT, FONT_WIDTH, GC, KEY_PRESS_MASK, KEY_RELEASE_MASK,
    LEAVE_WINDOW_MASK, MARGIN_X, MARGIN_Y, MAX_PASTE_BYTES, MAX_RUNTIME_KEYS, POINTER_MOTION_MASK,
    SCENE_RENDER_DEBOUNCE, SHIFT_MASK, STATUS_HEIGHT, STRUCTURE_NOTIFY_MASK, XK_BACKSPACE,
    XK_DELETE, XK_DOWN, XK_END, XK_ESCAPE, XK_F1, XK_F5, XK_HOME, XK_INSERT, XK_LEFT, XK_PAGE_DOWN,
    XK_PAGE_UP, XK_RETURN, XK_RIGHT, XK_UP,
};
const XK_F12: c_ulong = 0xFFC9;

const DEFAULT_PROGRAM_WIDTH: u32 = 640;
const DEFAULT_PROGRAM_HEIGHT: u32 = 480 + STATUS_HEIGHT as u32;
const CURSOR_BLINK_INTERVAL: Duration = Duration::from_millis(530);
/// Throttle a producer that prints or presents frames faster than X11 can
/// display them. This prevents a runaway BASIC loop from consuming memory.
const MAX_PENDING_INTERPRETER_EVENTS: usize = 512;
/// Always return control to X11 after a finite amount of interpreter work so
/// the System Command Interface and Program Manager remain interactive.
const MAX_INTERPRETER_EVENTS_PER_SERVICE: usize = 32;
const INTERPRETER_SERVICE_BUDGET: Duration = Duration::from_millis(2);
/// Each task owns an interpreter worker, renderer worker, X11 resources, and
/// independent runtime state. Keep hostile or accidental repeated opens from
/// exhausting process and display resources.
const MAX_PROGRAM_TASKS: usize = 32;

fn ensure_program_task_capacity(active: usize) -> Result<(), Error> {
    if active >= MAX_PROGRAM_TASKS {
        return Err(Error::Io(format!(
            "program task limit reached ({MAX_PROGRAM_TASKS}); close a task before opening another"
        )));
    }
    Ok(())
}

type ProgramWorkers = (
    Option<JoinHandle<Result<(), Error>>>,
    Option<JoinHandle<()>>,
);

fn reap_program_workers(workers: &Mutex<Option<ProgramWorkers>>) {
    let workers = workers
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
        .take();
    let Some((worker, render_worker)) = workers else {
        return;
    };
    if let Some(worker) = worker {
        let _ = worker.join();
    }
    if let Some(worker) = render_worker {
        let _ = worker.join();
    }
}

fn request_interrupt_for_key(keysym: KeySym, modifiers: c_uint, interrupt: &AtomicBool) -> bool {
    // Ctrl+Esc is the classic BREAK key. F12 is a fallback that window
    // managers are less likely to intercept.
    let is_break = (keysym == XK_ESCAPE && modifiers & CONTROL_MASK != 0) || keysym == XK_F12;
    if !is_break {
        return false;
    }
    interrupt.store(true, Ordering::SeqCst);
    true
}

#[cfg(test)]
mod interrupt_tests {
    use super::*;

    #[test]
    fn ctrl_escape_requests_break_without_a_window_close_action() {
        let interrupt = AtomicBool::new(false);

        assert!(request_interrupt_for_key(
            XK_ESCAPE,
            CONTROL_MASK,
            &interrupt
        ));
        assert!(interrupt.load(Ordering::SeqCst));
    }

    #[test]
    fn non_break_keys_do_not_set_the_program_interrupt_flag() {
        let interrupt = AtomicBool::new(false);

        assert!(!request_interrupt_for_key(XK_ESCAPE, 0, &interrupt));
        assert!(!request_interrupt_for_key(XK_F5, CONTROL_MASK, &interrupt));
        assert!(!interrupt.load(Ordering::SeqCst));
    }

    #[test]
    fn f12_sets_the_program_interrupt_flag_without_modifiers() {
        let interrupt = AtomicBool::new(false);

        assert!(request_interrupt_for_key(XK_F12, 0, &interrupt));
        assert!(interrupt.load(Ordering::SeqCst));
    }
}

pub(super) fn log_diagnostic_error(task_id: Option<u64>, error: &str) {
    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    let task = task_id
        .map(|task_id| task_id.to_string())
        .unwrap_or_else(|| "shell".to_string());
    for line in error.lines().filter(|line| !line.trim().is_empty()) {
        eprintln!(
            "[{}.{:03}] task_id={} {}",
            timestamp.as_secs(),
            timestamp.subsec_millis(),
            task,
            line.trim_end()
        );
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum ProgramWindowState {
    Idle,
    Running,
    Stopped,
    Error,
}

impl ProgramWindowState {
    pub(super) fn name(self) -> &'static str {
        match self {
            Self::Idle => "READY",
            Self::Running => "RUNNING",
            Self::Stopped => "STOPPED",
            Self::Error => "ERROR",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum ProgramTaskStatus {
    Ready,
    Running,
}

impl ProgramTaskStatus {
    fn from_window_state(state: ProgramWindowState) -> Self {
        if state == ProgramWindowState::Running {
            Self::Running
        } else {
            Self::Ready
        }
    }

    pub(super) fn name(self) -> &'static str {
        match self {
            Self::Ready => "READY",
            Self::Running => "RUNNING",
        }
    }
}

fn ready_cursor_visible(
    at_prompt: bool,
    state: ProgramWindowState,
    terminal_cursor_visible: bool,
    blink_on: bool,
) -> bool {
    at_prompt && state != ProgramWindowState::Running && terminal_cursor_visible && blink_on
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct ProgramTaskInfo {
    pub task_id: u64,
    pub filename: String,
    pub status: ProgramTaskStatus,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PendingCommand {
    Load,
    Run,
    Other,
}

#[derive(Debug, Clone, Copy)]
pub(super) struct ProgramWindowPasteAtoms {
    pub(super) clipboard: Atom,
    pub(super) primary: Atom,
    pub(super) utf8_string: Atom,
    pub(super) text_plain_utf8: Atom,
    pub(super) text_atom: Atom,
    pub(super) string_atom: Atom,
    pub(super) targets_atom: Atom,
    pub(super) atom_atom: Atom,
    pub(super) paste_property: Atom,
}

#[derive(Debug, Clone, Copy)]
struct PendingPaste {
    selection: Atom,
    target_index: usize,
}

struct SceneRenderRequest {
    artist_source: String,
    raster_ppm: Option<Arc<[u8]>>,
}

type SceneRenderResult = Result<RasterImage, String>;

fn render_scene(request: SceneRenderRequest) -> SceneRenderResult {
    let result = if let Some(bytes) = request.raster_ppm {
        RasterImage::parse_ppm(&bytes)
    } else {
        crate::artist_renderer::render_ppm(&prepare_integrated_raster_source(
            &request.artist_source,
        ))
        .and_then(|bytes| RasterImage::parse_ppm(&bytes))
    };
    result.map_err(|error| error.to_string())
}

pub(super) struct ProgramWindowOpenContext<'a> {
    pub(super) display: *mut Display,
    pub(super) root: Window,
    pub(super) font: Font,
    pub(super) wm_delete: Atom,
    pub(super) run_options: RunOptions,
    pub(super) display_info: SharedDisplayInfo,
    pub(super) caps_mode: bool,
    pub(super) color_cache: &'a mut X11ColorCache,
}

/// One independently executing BASIC task and its presentation surface.
pub(super) struct ProgramWindow {
    pub task_id: u64,
    pub filename: String,
    pub window: Window,
    display: *mut Display,
    root: Window,
    paste_atoms: ProgramWindowPasteAtoms,
    pending_paste: Option<PendingPaste>,
    paste_queue: VecDeque<String>,
    selection_start: Option<(usize, usize)>,
    selection_end: Option<(usize, usize)>,
    selecting: bool,
    selected_text: String,
    gc: GC,
    reverse_gc: GC,
    colors: X11Colors,
    width: u32,
    height: u32,
    state: ProgramWindowState,
    screen_view: ScreenView,
    raster: Option<RasterImage>,
    raster_surface: X11RasterSurface,
    pending_scene: Option<String>,
    pending_raster_ppm: Option<Arc<[u8]>>,
    pending_scene_at: Option<Instant>,
    screen_error: Option<String>,
    dirty: bool,
    terminal: TerminalBuffer,
    help: HelpViewer,
    input: String,
    cursor: usize,
    scroll_offset: usize,
    history: Vec<String>,
    history_position: Option<usize>,
    edit_mode: bool,
    edit_lines: Vec<String>,
    edit_position: Option<usize>,
    edit_listing_start: Option<usize>,
    caps_mode: bool,
    at_prompt: bool,
    startup_ready_seen: bool,
    pending_commands: VecDeque<PendingCommand>,
    command_had_error: bool,
    command_stopped: bool,
    diagnostic_line: String,
    diagnostic_error_start: Option<usize>,
    last_diagnostic: String,
    cursor_blink_time: Instant,
    cursor_blink_on: bool,
    input_sender: Sender<Vec<u8>>,
    event_receiver: Option<Receiver<InterpreterEvent>>,
    render_request_sender: Option<Sender<SceneRenderRequest>>,
    render_result_receiver: Receiver<SceneRenderResult>,
    render_in_flight: bool,
    pointer_state: SharedPointerState,
    key_queue: SharedKeyQueue,
    key_state: SharedKeyState,
    interrupt: Arc<AtomicBool>,
    worker: Option<JoinHandle<Result<(), Error>>>,
    render_worker: Option<JoinHandle<()>>,
}

impl ProgramWindow {
    fn create(
        task_id: u64,
        source_path: Option<&Path>,
        initial_program: Option<Program>,
        color_prefs: &ColorPrefs,
        paste_atoms: ProgramWindowPasteAtoms,
        context: ProgramWindowOpenContext<'_>,
    ) -> Result<Self, Error> {
        let ProgramWindowOpenContext {
            display,
            root,
            font,
            wm_delete,
            run_options,
            display_info,
            caps_mode,
            color_cache,
        } = context;
        let load_path = source_path
            .map(|path| {
                let path = path.to_str().ok_or(Error::InvalidFilePath)?;
                if path.contains('"') {
                    return Err(Error::InvalidFilePath);
                }
                Ok(path.to_string())
            })
            .transpose()?;
        let run_initial_program = initial_program.is_some();
        let show_startup_prompt = source_path.is_none() && !run_initial_program;
        let filename = source_path
            .and_then(Path::file_name)
            .map(|name| name.to_string_lossy().into_owned())
            .unwrap_or_else(|| {
                if run_initial_program {
                    "COMPILED.M64B".to_string()
                } else {
                    "UNTITLED.BAS".to_string()
                }
            });
        let colors = color_cache.colors_for_prefs(display, color_prefs)?;
        let offset = 70 + (i32::try_from(task_id.saturating_sub(1) % 8).unwrap_or(0) * 28);
        let window = unsafe {
            XCreateSimpleWindow(
                display,
                root,
                offset,
                offset,
                DEFAULT_PROGRAM_WIDTH,
                DEFAULT_PROGRAM_HEIGHT,
                0,
                colors.text,
                colors.screen,
            )
        };
        if window == 0 {
            return Err(Error::Io("cannot create program X11 window".into()));
        }

        let title = CString::new(format!("ModernBASIC - Task {task_id} - {filename}"))
            .map_err(|_| Error::Io("invalid program window title".into()))?;
        let mut wm_delete = wm_delete;
        unsafe {
            XStoreName(display, window, title.as_ptr());
            XSetWMProtocols(display, window, &mut wm_delete, 1);
            XSelectInput(
                display,
                window,
                KEY_PRESS_MASK
                    | KEY_RELEASE_MASK
                    | BUTTON_PRESS_MASK
                    | BUTTON_RELEASE_MASK
                    | POINTER_MOTION_MASK
                    | LEAVE_WINDOW_MASK
                    | EXPOSURE_MASK
                    | STRUCTURE_NOTIFY_MASK
                    | FOCUS_CHANGE_MASK,
            );
        }

        let gc = unsafe { XCreateGC(display, window, 0, std::ptr::null_mut()) };
        let reverse_gc = unsafe { XCreateGC(display, window, 0, std::ptr::null_mut()) };
        if gc.is_null() || reverse_gc.is_null() {
            unsafe {
                if !gc.is_null() {
                    XFreeGC(display, gc);
                }
                if !reverse_gc.is_null() {
                    XFreeGC(display, reverse_gc);
                }
                XDestroyWindow(display, window);
            }
            return Err(Error::Io(
                "cannot create program-window X11 graphics contexts".into(),
            ));
        }
        unsafe {
            XSetForeground(display, gc, colors.text);
            XSetBackground(display, gc, colors.screen);
            XSetForeground(display, reverse_gc, colors.screen);
            XSetBackground(display, reverse_gc, colors.text);
            if font != 0 {
                XSetFont(display, gc, font);
                XSetFont(display, reverse_gc, font);
            }
        }

        let (input_sender, input_receiver) = mpsc::channel::<Vec<u8>>();
        let (event_sender, event_receiver) =
            mpsc::sync_channel::<InterpreterEvent>(MAX_PENDING_INTERPRETER_EVENTS);
        let (render_request_sender, render_request_receiver) =
            mpsc::channel::<SceneRenderRequest>();
        let (render_result_sender, render_result_receiver) = mpsc::channel::<SceneRenderResult>();
        let pointer_state = Arc::new(Mutex::new(PointerState::default()));
        let key_queue = Arc::new(Mutex::new(VecDeque::new()));
        let key_state = Arc::new(Mutex::new(KeyState::default()));
        let interrupt = Arc::new(AtomicBool::new(false));

        let worker_pointer = Arc::clone(&pointer_state);
        let worker_keys = Arc::clone(&key_queue);
        let worker_key_state = Arc::clone(&key_state);
        let worker_interrupt = Arc::clone(&interrupt);
        let render_worker = thread::Builder::new()
            .name(format!("modernbasic-render-{task_id}"))
            .spawn(move || {
                while let Ok(request) = render_request_receiver.recv() {
                    if render_result_sender.send(render_scene(request)).is_err() {
                        break;
                    }
                }
            })
            .map_err(|error| {
                unsafe {
                    XFreeGC(display, gc);
                    XFreeGC(display, reverse_gc);
                    XDestroyWindow(display, window);
                }
                Error::Io(format!("cannot start program renderer {task_id}: {error}"))
            })?;

        let worker_result = thread::Builder::new()
            .name(format!("modernbasic-task-{task_id}"))
            .spawn(move || {
                set_thread_interpreter_event_sender(Some(event_sender.clone()));
                set_thread_pointer_state(Some(worker_pointer));
                set_thread_key_queue(Some(worker_keys));
                set_thread_key_state(Some(worker_key_state));
                crate::screen::set_thread_display_info(display_info);
                set_thread_interrupt_flag(Some(worker_interrupt));

                let mut input = ChannelReader::new(input_receiver);
                let prompt_sender = event_sender.clone();
                let mut output = InterpreterOutputWriter::new(event_sender);
                let result = run_repl_with_initial_program_options(
                    &mut input,
                    &mut output,
                    run_options,
                    show_startup_prompt,
                    initial_program,
                    run_initial_program,
                    move || {
                        let _ = prompt_sender.send(InterpreterEvent::Ready);
                    },
                );

                set_thread_interrupt_flag(None);
                set_thread_interpreter_event_sender(None);
                set_thread_pointer_state(None);
                set_thread_key_queue(None);
                set_thread_key_state(None);
                result
            });
        let worker = match worker_result {
            Ok(worker) => worker,
            Err(error) => {
                drop(render_request_sender);
                let _ = render_worker.join();
                unsafe {
                    XFreeGC(display, gc);
                    XFreeGC(display, reverse_gc);
                    XDestroyWindow(display, window);
                }
                return Err(Error::Io(format!(
                    "cannot start program task {task_id}: {error}"
                )));
            }
        };

        unsafe {
            XMapWindow(display, window);
            XRaiseWindow(display, window);
            XFlush(display);
        }

        let mut program = Self {
            task_id,
            filename,
            window,
            display,
            root,
            paste_atoms,
            pending_paste: None,
            paste_queue: VecDeque::new(),
            selection_start: None,
            selection_end: None,
            selecting: false,
            selected_text: String::new(),
            gc,
            reverse_gc,
            colors,
            width: DEFAULT_PROGRAM_WIDTH,
            height: DEFAULT_PROGRAM_HEIGHT,
            state: ProgramWindowState::Idle,
            screen_view: ScreenView::Text,
            raster: None,
            raster_surface: X11RasterSurface::default(),
            pending_scene: None,
            pending_raster_ppm: None,
            pending_scene_at: None,
            screen_error: None,
            dirty: true,
            terminal: TerminalBuffer::with_colors(colors),
            help: HelpViewer::default(),
            input: String::new(),
            cursor: 0,
            scroll_offset: 0,
            history: Vec::new(),
            history_position: None,
            edit_mode: false,
            edit_lines: Vec::new(),
            edit_position: None,
            edit_listing_start: None,
            caps_mode,
            at_prompt: false,
            startup_ready_seen: false,
            pending_commands: VecDeque::new(),
            command_had_error: false,
            command_stopped: false,
            diagnostic_line: String::new(),
            diagnostic_error_start: None,
            last_diagnostic: String::new(),
            cursor_blink_time: Instant::now(),
            cursor_blink_on: true,
            input_sender,
            event_receiver: Some(event_receiver),
            render_request_sender: Some(render_request_sender),
            render_result_receiver,
            render_in_flight: false,
            pointer_state,
            key_queue,
            key_state,
            interrupt,
            worker: Some(worker),
            render_worker: Some(render_worker),
        };

        if let Some(path) = load_path {
            if let Err(error) =
                program.send_command(&format!("LOAD \"{path}\""), PendingCommand::Load)
            {
                program.terminate_and_close(display);
                return Err(error);
            }
        }
        Ok(program)
    }

    fn send_command(&mut self, command: &str, kind: PendingCommand) -> Result<(), Error> {
        self.interrupt.store(false, Ordering::SeqCst);
        if kind == PendingCommand::Run {
            self.last_diagnostic.clear();
        }
        let mut bytes = command.as_bytes().to_vec();
        bytes.push(b'\n');
        self.input_sender
            .send(bytes)
            .map_err(|_| Error::Io(format!("program task {} has closed", self.task_id)))?;
        self.pending_commands.push_back(kind);
        self.at_prompt = false;
        if kind == PendingCommand::Run {
            self.set_state(ProgramWindowState::Running);
        }
        self.dirty = true;
        Ok(())
    }

    fn submit_repl_line(&mut self) {
        let line = std::mem::take(&mut self.input);
        self.cursor = 0;
        self.scroll_offset = 0;
        self.history_position = None;
        if self.at_prompt
            && matches!(
                line.trim().to_ascii_uppercase().as_str(),
                "HELP" | "MANUAL" | "HELP MANUAL"
            )
        {
            super::remember_history(&mut self.history, &line);
            self.show_help();
            return;
        }
        self.terminal.append_entered_line(&line);
        super::remember_history(&mut self.history, &line);

        if self.at_prompt && line.trim().eq_ignore_ascii_case("EDIT") {
            self.edit_listing_start = Some(self.terminal.lines.len());
            if let Err(error) = self.send_command("LIST", PendingCommand::Other) {
                log_diagnostic_error(Some(self.task_id), &error.to_string());
                self.edit_listing_start = None;
                self.set_state(ProgramWindowState::Error);
            }
            self.dirty = true;
            return;
        }

        if self.edit_mode && super::numbered_program_line(&line).is_some() {
            let active = super::update_program_line_cache(
                &mut self.edit_lines,
                &mut self.edit_position,
                &line,
            );
            if !active {
                self.edit_position = None;
                self.edit_mode = false;
            }
        }

        let command = line
            .split_whitespace()
            .next()
            .unwrap_or_default()
            .to_ascii_uppercase();
        let kind = if matches!(command.as_str(), "RUN" | "STEP" | "CONT") {
            PendingCommand::Run
        } else {
            PendingCommand::Other
        };
        if let Err(error) = self.send_command(&line, kind) {
            log_diagnostic_error(Some(self.task_id), &error.to_string());
            self.terminal.push_bytes(format!("? {error}\n").as_bytes());
            self.scroll_offset = 0;
            self.set_state(ProgramWindowState::Error);
        }
        self.dirty = true;
    }

    fn finish_edit_listing(&mut self) {
        let start = self.edit_listing_start.take().unwrap_or(0);
        self.edit_lines = self
            .terminal
            .lines
            .iter()
            .skip(start)
            .filter_map(|line| super::validated_numbered_program_line(line))
            .map(|(_, line)| line.to_string())
            .collect();
        self.edit_position = None;
        self.edit_mode = !self.edit_lines.is_empty();
        if !self.edit_mode {
            log_diagnostic_error(Some(self.task_id), "PROGRAM IS EMPTY");
            self.terminal.push_bytes(b"? PROGRAM IS EMPTY\n ");
            self.scroll_offset = 0;
        }
    }

    fn leave_edit_mode(&mut self) {
        self.edit_mode = false;
        self.edit_lines.clear();
        self.edit_position = None;
        self.edit_listing_start = None;
        self.input.clear();
        self.cursor = 0;
        self.dirty = true;
    }

    fn show_help(&mut self) {
        let (columns, _) = help_dialog_capacity(self.width, self.height);
        self.help.show(columns);
        self.selection_start = None;
        self.selection_end = None;
        self.selecting = false;
        self.dirty = true;
    }

    fn select_edit_line(&mut self, previous: bool) {
        if !self.edit_mode || self.edit_lines.is_empty() || !self.at_prompt {
            return;
        }
        let last = self.edit_lines.len() - 1;
        let position = match (self.edit_position, previous) {
            (None, true) => last,
            (None, false) => 0,
            (Some(position), true) => position.saturating_sub(1),
            (Some(position), false) => (position + 1).min(last),
        };
        self.edit_position = Some(position);
        self.input = self.edit_lines[position].clone();
        self.cursor = self.input.chars().count();
        self.history_position = None;
        self.dirty = true;
    }

    fn history_previous(&mut self) {
        if !self.at_prompt || self.history.is_empty() {
            return;
        }
        let position = self
            .history_position
            .map(|position| position.saturating_sub(1))
            .unwrap_or(self.history.len() - 1);
        self.history_position = Some(position);
        self.input = self.history[position].clone();
        self.cursor = self.input.chars().count();
        self.dirty = true;
    }

    fn history_next(&mut self) {
        if !self.at_prompt {
            return;
        }
        let Some(position) = self.history_position else {
            return;
        };
        if position + 1 < self.history.len() {
            self.history_position = Some(position + 1);
            self.input = self.history[position + 1].clone();
        } else {
            self.history_position = None;
            self.input.clear();
        }
        self.cursor = self.input.chars().count();
        self.dirty = true;
    }

    fn request_break(&mut self) {
        self.interrupt.store(true, Ordering::SeqCst);
        let _ = self.input_sender.send(Vec::new());
        // Reveal BREAK and READY in this same window. The retained raster is
        // deliberately not cleared, so switching views does not clear RAM.
        self.screen_view = ScreenView::Text;
        self.dirty = true;
    }

    fn set_state(&mut self, state: ProgramWindowState) {
        if self.state != state {
            self.state = state;
            self.scroll_offset = 0;
            self.dirty = true;
        }
    }

    fn drain_interpreter_events(&mut self, display: *mut Display, color_cache: &mut X11ColorCache) {
        let started = Instant::now();
        for processed in 0..MAX_INTERPRETER_EVENTS_PER_SERVICE {
            if processed > 0 && started.elapsed() >= INTERPRETER_SERVICE_BUDGET {
                break;
            }
            let result = match self.event_receiver.as_ref() {
                Some(receiver) => receiver.try_recv(),
                None => return,
            };
            match result {
                Ok(InterpreterEvent::Output(bytes)) => {
                    let text = String::from_utf8_lossy(&bytes);
                    if text.starts_with('?') || text.contains("\n?") {
                        self.command_had_error = true;
                    }
                    self.capture_diagnostic_output(&text);
                    if text.contains("BREAK") || text.contains("PAUSED") {
                        self.command_stopped = true;
                    }
                    self.terminal.push_bytes(&bytes);
                    self.scroll_offset = 0;
                    self.dirty = true;
                }
                Ok(InterpreterEvent::Screen(event)) => {
                    self.handle_screen_event(display, color_cache, event)
                }
                Ok(InterpreterEvent::Ready) => self.handle_ready(),
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => {
                    if self.state == ProgramWindowState::Running {
                        self.set_state(ProgramWindowState::Error);
                    }
                    break;
                }
            }
        }
    }

    fn handle_ready(&mut self) {
        self.finish_diagnostic_line();
        if !self.startup_ready_seen {
            self.startup_ready_seen = true;
            self.at_prompt = self.pending_commands.is_empty();
        } else if let Some(completed) = self.pending_commands.pop_front() {
            if completed == PendingCommand::Other {
                // Direct graphics statements can select the raster view, but
                // READY and the next command prompt live in the terminal view.
                // Keep the raster available for manual view switching while
                // making the interactive prompt visible again.
                self.screen_view = ScreenView::Text;
            }
            if self.command_stopped {
                self.set_state(ProgramWindowState::Stopped);
            } else if self.command_had_error {
                self.set_state(ProgramWindowState::Error);
                // A graphics program may have left its raster view active.
                // Show the terminal automatically so the diagnostic is visible
                // and can be selected after the program returns to READY.
                self.screen_view = ScreenView::Text;
            } else if completed == PendingCommand::Run
                && self
                    .pending_commands
                    .iter()
                    .all(|item| *item != PendingCommand::Run)
            {
                self.set_state(ProgramWindowState::Idle);
            } else if self
                .pending_commands
                .iter()
                .any(|item| *item == PendingCommand::Run)
            {
                self.set_state(ProgramWindowState::Running);
            } else {
                self.set_state(ProgramWindowState::Idle);
            }
            self.command_had_error = false;
            self.command_stopped = false;
            self.at_prompt = self.pending_commands.is_empty();
            if self.edit_listing_start.is_some() {
                self.finish_edit_listing();
            }
        } else {
            self.at_prompt = true;
        }
        self.submit_next_paste_line();
        if self.at_prompt {
            self.cursor_blink_on = true;
            self.cursor_blink_time = Instant::now();
        }
        self.dirty = true;
    }

    fn capture_diagnostic_output(&mut self, text: &str) {
        let mut chunk_line_start = true;
        for character in text.chars() {
            match character {
                '\n' => {
                    self.finish_diagnostic_line();
                    chunk_line_start = true;
                }
                '\r' => {
                    self.diagnostic_line.clear();
                    self.diagnostic_error_start = None;
                    chunk_line_start = true;
                }
                '?' if chunk_line_start => {
                    self.diagnostic_error_start = Some(self.diagnostic_line.len());
                    self.diagnostic_line.push(character);
                    chunk_line_start = false;
                }
                character => {
                    self.diagnostic_line.push(character);
                    chunk_line_start = false;
                }
            }
        }
    }

    fn finish_diagnostic_line(&mut self) {
        if let Some(start) = self.diagnostic_error_start {
            let diagnostic = self.diagnostic_line[start..].to_string();
            log_diagnostic_error(Some(self.task_id), &diagnostic);
            self.last_diagnostic = diagnostic;
        }
        self.diagnostic_line.clear();
        self.diagnostic_error_start = None;
    }

    fn handle_screen_event(
        &mut self,
        display: *mut Display,
        color_cache: &mut X11ColorCache,
        event: ScreenEvent,
    ) {
        match event {
            ScreenEvent::Present {
                artist_source,
                raster_ppm,
                view,
            } => {
                let view_changed = self.screen_view != view;
                self.screen_view = view;
                self.pending_scene = Some(artist_source);
                self.pending_raster_ppm = raster_ppm;
                self.pending_scene_at.get_or_insert_with(Instant::now);
                self.screen_error = None;
                // The new scene is not displayable until the render worker
                // finishes. Redrawing here uploads the previous multi-megabyte
                // raster once, then uploads the new one again on completion.
                // Keep the old complete frame in the window and redraw only
                // for an actual view transition or a completed new raster.
                if view_changed && self.raster.is_some() {
                    self.dirty = true;
                }
            }
            ScreenEvent::Resize { width, height } => {
                if width > 0 && height > 0 {
                    unsafe {
                        XResizeWindow(
                            display,
                            self.window,
                            width,
                            height.saturating_add(STATUS_HEIGHT as u32),
                        );
                        XFlush(display);
                    }
                }
            }
            ScreenEvent::SetView(view) => {
                self.screen_view = view;
                self.dirty = true;
            }
            ScreenEvent::SetTextCursor {
                row,
                column,
                visible,
            } => {
                self.terminal.set_cursor(row, column, visible);
                self.dirty = true;
            }
            ScreenEvent::SetPrintRegion { top, bottom } => {
                self.terminal.set_print_region(top, bottom);
                self.dirty = true;
            }
            ScreenEvent::SetTextColors {
                foreground,
                background,
            } => {
                match color_cache.basic_text_colors(display, foreground, background) {
                    Ok(colors) => self.terminal.set_text_colors(colors),
                    Err(error) => self.set_screen_error(error.to_string()),
                }
                self.dirty = true;
            }
            ScreenEvent::SetBorderColor(_color) => {
                // Program windows currently have no distinct X11 border
                // region. The interpreter's GraphicsDevice retains the value
                // for shells that can render one.
            }
            ScreenEvent::SetError(error) => {
                self.set_screen_error(error);
                self.dirty = true;
            }
            ScreenEvent::ClearText => {
                self.terminal.clear_print_region();
                self.dirty = true;
            }
            ScreenEvent::SetTitle(title) => match CString::new(title) {
                Ok(title) => unsafe {
                    XStoreName(display, self.window, title.as_ptr());
                    XFlush(display);
                },
                Err(_) => self.set_screen_error("screen title contains a NUL byte".to_string()),
            },
            ScreenEvent::SetFullscreen(enabled) => {
                if let Err(error) = set_window_fullscreen(display, self.root, self.window, enabled)
                {
                    self.set_screen_error(error.to_string());
                }
            }
            ScreenEvent::SetResizable(enabled) => {
                set_window_resizable(display, self.window, enabled, self.width, self.height);
            }
            ScreenEvent::SetPointerVisible(visible) => {
                set_window_pointer_visible(display, self.window, visible);
            }
            ScreenEvent::DisplaySize { .. } => {}
        }
    }

    fn collect_render_result(&mut self) {
        let rendered = match self.render_result_receiver.try_recv() {
            Ok(rendered) => rendered,
            Err(TryRecvError::Empty) => return,
            Err(TryRecvError::Disconnected) => {
                self.render_in_flight = false;
                if self.render_worker.take().is_some() {
                    self.set_screen_error("program renderer stopped unexpectedly".to_string());
                }
                return;
            }
        };
        self.render_in_flight = false;

        // A newer presentation supersedes the frame that just completed. Do
        // not spend an X11 redraw on an already stale raster.
        if self.pending_scene.is_some() {
            return;
        }
        match rendered {
            Ok(raster) => {
                self.raster = Some(raster);
                self.screen_error = None;
            }
            Err(error) => self.set_screen_error(error),
        }
        self.dirty = true;
    }

    fn start_pending_scene_render(&mut self) {
        if self.render_in_flight {
            return;
        }
        let Some(started) = self.pending_scene_at else {
            return;
        };
        if started.elapsed() < SCENE_RENDER_DEBOUNCE {
            return;
        }
        let Some(source) = self.pending_scene.take() else {
            self.pending_scene_at = None;
            self.pending_raster_ppm = None;
            return;
        };
        self.pending_scene_at = None;
        let request = SceneRenderRequest {
            artist_source: source,
            raster_ppm: self.pending_raster_ppm.take(),
        };
        let Some(sender) = self.render_request_sender.as_ref() else {
            self.set_screen_error("program renderer is unavailable".to_string());
            return;
        };
        if sender.send(request).is_err() {
            self.set_screen_error("program renderer stopped unexpectedly".to_string());
            return;
        }
        self.render_in_flight = true;
    }

    fn set_screen_error(&mut self, error: String) {
        log_diagnostic_error(Some(self.task_id), &error);
        if self.last_diagnostic.is_empty() {
            self.last_diagnostic = error.clone();
        }
        self.screen_error = Some(error);
    }

    fn service(&mut self, display: *mut Display, color_cache: &mut X11ColorCache) {
        self.drain_interpreter_events(display, color_cache);
        self.collect_render_result();
        self.start_pending_scene_render();
        if self.at_prompt && self.state != ProgramWindowState::Running {
            if self.cursor_blink_time.elapsed() >= CURSOR_BLINK_INTERVAL {
                self.cursor_blink_on = !self.cursor_blink_on;
                self.cursor_blink_time = Instant::now();
                self.dirty = true;
            }
        } else if !self.cursor_blink_on {
            self.cursor_blink_on = true;
            self.dirty = true;
        }
    }

    fn redraw(&mut self, display: *mut Display, graphics_scale: GraphicsScaleMode) {
        if !self.dirty {
            return;
        }
        if self.help.is_open() {
            self.apply_gc_colors(display);
            draw_help_dialog(
                display,
                self.window,
                self.gc,
                self.reverse_gc,
                self.width,
                self.height,
                &mut self.help,
            );
            unsafe {
                XFlush(display);
            }
            self.dirty = false;
            return;
        }
        let content_height = self.height.saturating_sub(STATUS_HEIGHT as u32).max(1) as i32;
        match self.screen_view {
            ScreenView::Text => self.draw_terminal(display, 0, content_height),
            ScreenView::Graphics => {
                if self.raster.is_some() || self.screen_error.is_some() {
                    self.draw_graphics(display, 0, content_height, graphics_scale);
                } else {
                    self.draw_terminal(display, 0, content_height);
                }
            }
            ScreenView::Split => {
                let graphics_height = (content_height * 2 / 3).max(1);
                self.draw_graphics(display, 0, graphics_height, graphics_scale);
                self.draw_terminal(
                    display,
                    graphics_height + 1,
                    content_height - graphics_height - 1,
                );
            }
        }

        self.apply_gc_colors(display);

        let status_y = self.height as i32 - STATUS_HEIGHT;
        unsafe {
            XFillRectangle(
                display,
                self.window,
                self.gc,
                0,
                status_y,
                self.width,
                STATUS_HEIGHT as u32,
            );
        }
        let status = if self.state == ProgramWindowState::Error && !self.last_diagnostic.is_empty()
        {
            format!(
                "TASK {}  ERROR  {}  F1 HELP  CTRL+C COPY ERROR  F5 RUN",
                self.task_id, self.filename
            )
        } else if self.edit_mode {
            format!(
                "TASK {}  {}  {}  EDIT: UP/DOWN SELECT  ENTER REPLACE  ESC EXIT",
                self.task_id,
                self.state.name(),
                self.filename
            )
        } else {
            format!(
                "TASK {}  {}  {}  F1 HELP  UP/DOWN HISTORY  CTRL+ESC BREAK  F5 RUN",
                self.task_id,
                self.state.name(),
                self.filename
            )
        };
        draw_ascii(
            display,
            self.window,
            self.reverse_gc,
            MARGIN_X,
            status_y + 17,
            &status,
        );
        unsafe {
            XFlush(display);
        }
        self.dirty = false;
    }

    fn terminal_region(&self) -> Option<(i32, i32)> {
        let content_height = self.height.saturating_sub(STATUS_HEIGHT as u32).max(1) as i32;
        match self.screen_view {
            ScreenView::Text => Some((0, content_height)),
            ScreenView::Graphics if self.raster.is_none() && self.screen_error.is_none() => {
                Some((0, content_height))
            }
            ScreenView::Graphics => None,
            ScreenView::Split => {
                let graphics_height = (content_height * 2 / 3).max(1);
                Some((graphics_height + 1, content_height - graphics_height - 1))
            }
        }
    }

    fn terminal_visual(&self, columns: usize) -> Vec<TerminalRow> {
        let mut visual = Vec::new();
        let terminal_rows = self.terminal.rows_with_input(&self.input);
        let active_row = self.terminal.cursor_line.min(terminal_rows.len() - 1);
        for (row, line) in terminal_rows.iter().enumerate() {
            if row == active_row {
                visual.extend(super::wrap_cursor_row(line, columns));
            } else {
                visual.extend(super::wrap_completed_row(line, columns));
            }
        }
        visual
    }

    fn visual_line_count(&self) -> usize {
        let columns = ((self.width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        self.terminal_visual(columns).len()
    }

    fn visible_rows(&self) -> usize {
        let height = self
            .terminal_region()
            .map(|(_, height)| height)
            .unwrap_or(FONT_HEIGHT + MARGIN_Y * 2);
        ((height - MARGIN_Y * 2) / FONT_HEIGHT).max(1) as usize
    }

    fn scroll_up(&mut self, amount: usize) {
        let maximum = self.visual_line_count().saturating_sub(self.visible_rows());
        self.scroll_offset = self.scroll_offset.saturating_add(amount).min(maximum);
        self.dirty = true;
    }

    fn scroll_down(&mut self, amount: usize) {
        self.scroll_offset = self.scroll_offset.saturating_sub(amount);
        self.dirty = true;
    }

    fn terminal_text_position(&self, x: c_int, y: c_int, clamp: bool) -> Option<(usize, usize)> {
        let (top, height) = self.terminal_region()?;
        if height <= MARGIN_Y * 2 {
            return None;
        }
        let rows = ((height - MARGIN_Y * 2) / FONT_HEIGHT).max(1) as usize;
        let columns = ((self.width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let visual = self.terminal_visual(columns);
        let end = visual.len().saturating_sub(self.scroll_offset);
        let start = end.saturating_sub(rows);
        let visible = end.saturating_sub(start);
        if visible == 0 {
            return None;
        }
        let text_top = top + MARGIN_Y;
        if !clamp
            && (x < MARGIN_X
                || x >= MARGIN_X + columns as i32 * FONT_WIDTH
                || y < text_top
                || y >= text_top + visible as i32 * FONT_HEIGHT)
        {
            return None;
        }
        let column = ((x - MARGIN_X) / FONT_WIDTH).clamp(0, columns as i32 - 1) as usize;
        let visible_row = ((y - text_top) / FONT_HEIGHT).clamp(0, visible as i32 - 1) as usize;
        Some((start + visible_row, column))
    }

    fn begin_selection(&mut self, x: c_int, y: c_int) {
        let position = self.terminal_text_position(x, y, false);
        self.selection_start = position;
        self.selection_end = position;
        self.selecting = position.is_some();
        self.dirty = true;
    }

    fn extend_selection(&mut self, x: c_int, y: c_int) {
        if !self.selecting {
            return;
        }
        if let Some(position) = self.terminal_text_position(x, y, true) {
            self.selection_end = Some(position);
            self.dirty = true;
        }
    }

    fn finish_selection(&mut self, x: c_int, y: c_int, time: Time) {
        if !self.selecting {
            return;
        }
        self.extend_selection(x, y);
        self.selecting = false;
        let (Some(start), Some(end)) = (self.selection_start, self.selection_end) else {
            return;
        };
        let columns = ((self.width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let visual = self.terminal_visual(columns);
        self.selected_text = selected_text(visual.iter().map(|row| row.text.as_str()), start, end);
        if self.selected_text.is_empty() {
            self.selection_start = None;
            self.selection_end = None;
        } else {
            unsafe {
                XSetSelectionOwner(self.display, self.paste_atoms.primary, self.window, time);
                XSetSelectionOwner(self.display, self.paste_atoms.clipboard, self.window, time);
                XFlush(self.display);
            }
        }
        self.dirty = true;
    }

    fn handle_selection_request(&self, event: XSelectionRequestEvent) {
        if self.selected_text.is_empty()
            || (event.selection != self.paste_atoms.primary
                && event.selection != self.paste_atoms.clipboard)
        {
            return;
        }
        serve_text_selection(
            self.display,
            &self.selected_text,
            self.paste_targets(),
            self.paste_atoms.targets_atom,
            self.paste_atoms.atom_atom,
            event,
        );
    }

    fn handle_selection_clear(&mut self, event: XSelectionClearEvent) {
        if event.selection != self.paste_atoms.primary
            && event.selection != self.paste_atoms.clipboard
        {
            return;
        }
        self.selection_start = None;
        self.selection_end = None;
        self.selecting = false;
        self.selected_text.clear();
        self.dirty = true;
    }

    fn draw_terminal(&self, display: *mut Display, top: i32, height: i32) {
        if height <= MARGIN_Y * 2 {
            return;
        }
        unsafe {
            XSetForeground(display, self.gc, self.terminal.text_colors.background);
            XFillRectangle(
                display,
                self.window,
                self.gc,
                0,
                top,
                self.width,
                height as u32,
            );
        }
        let rows = ((height - MARGIN_Y * 2) / FONT_HEIGHT).max(1) as usize;
        let columns = ((self.width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let terminal_rows = self.terminal.rows_with_input(&self.input);
        let active_row = self.terminal.cursor_line.min(terminal_rows.len() - 1);
        let mut active_visual_row = 0usize;
        let mut visual = Vec::new();
        for (row, line) in terminal_rows.iter().enumerate() {
            if row == active_row {
                active_visual_row = visual.len();
                visual.extend(super::wrap_cursor_row(line, columns));
            } else {
                visual.extend(super::wrap_completed_row(line, columns));
            }
        }
        let end = visual.len().saturating_sub(self.scroll_offset);
        let start = visual
            .len()
            .saturating_sub(rows.saturating_add(self.scroll_offset));
        for (row, line) in visual[start..end].iter().enumerate() {
            let mut rendered_line = line.clone();
            if let (Some(selection_start), Some(selection_end)) =
                (self.selection_start, self.selection_end)
            {
                let line_length = rendered_line.text.chars().count();
                if let Some((first, last)) =
                    selection_span(start + row, line_length, selection_start, selection_end)
                {
                    rendered_line
                        .colors
                        .resize(line_length, self.terminal.text_colors);
                    for colors in &mut rendered_line.colors[first..last] {
                        std::mem::swap(&mut colors.foreground, &mut colors.background);
                    }
                }
            }
            super::draw_terminal_row(
                display,
                self.window,
                self.gc,
                MARGIN_X,
                top + MARGIN_Y + FONT_ASCENT + row as i32 * FONT_HEIGHT,
                &rendered_line,
            );
        }
        let prefix_columns = self
            .terminal
            .cursor_column
            .saturating_add(self.input.chars().take(self.cursor).count());
        let cursor_row = active_visual_row + prefix_columns / columns;
        if self.scroll_offset == 0
            && ready_cursor_visible(
                self.at_prompt,
                self.state,
                self.terminal.cursor_visible,
                self.cursor_blink_on,
            )
            && cursor_row >= start
            && cursor_row < end
        {
            let x = MARGIN_X + (prefix_columns % columns) as i32 * FONT_WIDTH;
            let y = top + MARGIN_Y + (cursor_row - start) as i32 * FONT_HEIGHT + FONT_HEIGHT - 2;
            unsafe {
                XSetForeground(display, self.gc, self.terminal.text_colors.foreground);
                XFillRectangle(display, self.window, self.gc, x, y, FONT_WIDTH as u32, 2);
            }
        }
    }

    fn draw_graphics(
        &mut self,
        display: *mut Display,
        top: i32,
        height: i32,
        graphics_scale: GraphicsScaleMode,
    ) {
        if height <= 0 {
            return;
        }
        if let Some(error) = &self.screen_error {
            unsafe {
                XFillRectangle(
                    display,
                    self.window,
                    self.reverse_gc,
                    0,
                    top,
                    self.width,
                    height as u32,
                );
            }
            draw_ascii(
                display,
                self.window,
                self.gc,
                MARGIN_X,
                top + MARGIN_Y + FONT_ASCENT,
                &format!("? GRAPHICS ERROR: {error}"),
            );
            return;
        }
        let Some(raster) = &self.raster else {
            unsafe {
                XFillRectangle(
                    display,
                    self.window,
                    self.reverse_gc,
                    0,
                    top,
                    self.width,
                    height as u32,
                );
            }
            draw_ascii(
                display,
                self.window,
                self.gc,
                MARGIN_X,
                top + MARGIN_Y + FONT_ASCENT,
                "GRAPHICS SCREEN - NO FRAME PRESENTED",
            );
            return;
        };
        let region_height = height as u32;
        let Some(viewport) = raster_viewport(
            self.width,
            region_height,
            raster.width,
            raster.height,
            graphics_scale,
        ) else {
            return;
        };
        // Retain the old complete frame until XPutImage replaces it. Clearing
        // the full window here made the background visible between X11
        // requests and caused animation to flash. Only repaint letterbox bands
        // that are not covered by the incoming raster.
        unsafe {
            if viewport.y > 0 {
                XFillRectangle(
                    display,
                    self.window,
                    self.reverse_gc,
                    0,
                    top,
                    self.width,
                    viewport.y as u32,
                );
            }
            let viewport_bottom = viewport.y.saturating_add(viewport.height as i32);
            if viewport_bottom < height {
                XFillRectangle(
                    display,
                    self.window,
                    self.reverse_gc,
                    0,
                    top + viewport_bottom,
                    self.width,
                    (height - viewport_bottom) as u32,
                );
            }
            if viewport.x > 0 {
                XFillRectangle(
                    display,
                    self.window,
                    self.reverse_gc,
                    0,
                    top + viewport.y,
                    viewport.x as u32,
                    viewport.height,
                );
            }
            let viewport_right = viewport.x.saturating_add(viewport.width as i32);
            if viewport_right < self.width as i32 {
                XFillRectangle(
                    display,
                    self.window,
                    self.reverse_gc,
                    viewport_right,
                    top + viewport.y,
                    (self.width as i32 - viewport_right) as u32,
                    viewport.height,
                );
            }
        }
        if let Err(error) = put_raster_to_window(
            RasterWindowTarget {
                display,
                window: self.window,
                gc: self.gc,
                x: viewport.x,
                y: top + viewport.y,
                width: viewport.width,
                height: viewport.height,
            },
            raster,
            &mut self.raster_surface,
        ) {
            self.set_screen_error(error.to_string());
        }
    }

    fn configure(&mut self, event: XConfigureEvent) {
        self.width = event.width.max(1) as u32;
        self.height = event.height.max(1) as u32;
        let maximum = self.visual_line_count().saturating_sub(self.visible_rows());
        self.scroll_offset = self.scroll_offset.min(maximum);
        self.dirty = true;
    }

    fn expose(&mut self) {
        self.dirty = true;
    }

    fn leave(&mut self) {
        if let Ok(mut pointer) = self.pointer_state.lock() {
            pointer.inside = false;
        }
    }

    fn pointer_position(
        &self,
        x: c_int,
        y: c_int,
        graphics_scale: GraphicsScaleMode,
    ) -> Option<(i64, i64)> {
        let content_height = self.height.saturating_sub(STATUS_HEIGHT as u32).max(1);
        let graphics_height = match self.screen_view {
            ScreenView::Text => 0,
            ScreenView::Graphics => content_height,
            ScreenView::Split => (content_height * 2 / 3).max(1),
        };
        self.raster.as_ref().and_then(|raster| {
            raster_viewport(
                self.width,
                graphics_height,
                raster.width,
                raster.height,
                graphics_scale,
            )
            .and_then(|viewport| map_pointer_to_raster(x, y, viewport, raster.width, raster.height))
        })
    }

    fn update_pointer(
        &self,
        x: c_int,
        y: c_int,
        button: Option<(u32, bool)>,
        graphics_scale: GraphicsScaleMode,
    ) {
        let logical = self.pointer_position(x, y, graphics_scale);
        if let Ok(mut pointer) = self.pointer_state.lock() {
            pointer.update(logical, button);
        }
    }

    fn queue_key(&self, key: String) {
        if let Ok(mut queue) = self.key_queue.lock() {
            if queue.len() == MAX_RUNTIME_KEYS {
                queue.pop_front();
            }
            queue.push_back(key);
        }
    }

    fn paste_targets(&self) -> [Atom; 4] {
        [
            self.paste_atoms.utf8_string,
            self.paste_atoms.text_plain_utf8,
            self.paste_atoms.text_atom,
            self.paste_atoms.string_atom,
        ]
    }

    fn request_paste(&mut self, selection: Atom) {
        self.pending_paste = Some(PendingPaste {
            selection,
            target_index: 0,
        });
        self.request_pending_paste();
    }

    fn request_pending_paste(&mut self) {
        let Some(pending) = self.pending_paste else {
            return;
        };
        let targets = self.paste_targets();
        let Some(target) = targets.get(pending.target_index).copied() else {
            self.pending_paste = None;
            self.paste_notice("? CLIPBOARD DOES NOT CONTAIN TEXT");
            return;
        };
        unsafe {
            XConvertSelection(
                self.display,
                pending.selection,
                target,
                self.paste_atoms.paste_property,
                self.window,
                0,
            );
            XFlush(self.display);
        }
    }

    fn retry_paste_target(&mut self) {
        if let Some(mut pending) = self.pending_paste {
            pending.target_index += 1;
            self.pending_paste = Some(pending);
            self.request_pending_paste();
        }
    }

    fn handle_selection_notify(&mut self, event: XSelectionEvent) {
        let Some(pending) = self.pending_paste else {
            return;
        };
        if event.requestor != self.window || event.selection != pending.selection {
            return;
        }
        if event.property == 0 {
            self.retry_paste_target();
            return;
        }

        let mut actual_type: Atom = 0;
        let mut actual_format: c_int = 0;
        let mut item_count: c_ulong = 0;
        let mut bytes_after: c_ulong = 0;
        let mut data: *mut u8 = std::ptr::null_mut();
        let long_length = MAX_PASTE_BYTES.div_ceil(4) as c_long;
        let status = unsafe {
            XGetWindowProperty(
                self.display,
                self.window,
                event.property,
                0,
                long_length,
                1,
                0,
                &mut actual_type,
                &mut actual_format,
                &mut item_count,
                &mut bytes_after,
                &mut data,
            )
        };

        if status != 0 || actual_type == 0 || actual_format != 8 || data.is_null() {
            if !data.is_null() {
                unsafe {
                    XFree(data.cast::<c_void>());
                }
            }
            unsafe {
                XDeleteProperty(self.display, self.window, event.property);
            }
            self.retry_paste_target();
            return;
        }

        let length = item_count as usize;
        if length > MAX_PASTE_BYTES || bytes_after != 0 {
            unsafe {
                XFree(data.cast::<c_void>());
                XDeleteProperty(self.display, self.window, event.property);
            }
            self.pending_paste = None;
            self.paste_notice("? PASTE TOO LARGE");
            return;
        }

        let bytes = unsafe { std::slice::from_raw_parts(data as *const u8, length) };
        let text = if event.target == self.paste_atoms.string_atom {
            bytes
                .iter()
                .map(|byte| char::from(*byte))
                .collect::<String>()
        } else {
            String::from_utf8_lossy(bytes).into_owned()
        };
        unsafe {
            XFree(data.cast::<c_void>());
            XDeleteProperty(self.display, self.window, event.property);
        }
        self.pending_paste = None;
        self.apply_paste(&text);
    }

    fn apply_paste(&mut self, text: &str) {
        if self.scroll_offset != 0 {
            self.scroll_offset = 0;
            self.dirty = true;
        }
        if self.state == ProgramWindowState::Running {
            for character in super::normalize_paste_text(text).chars() {
                if character == '\n' {
                    self.queue_key("ENTER".to_string());
                } else {
                    self.queue_key(character.to_string());
                }
            }
            return;
        }

        match super::plan_paste(&self.input, self.cursor, text) {
            super::PastePlan::Insert(text) => {
                let byte = byte_index_for_character(&self.input, self.cursor);
                self.input.insert_str(byte, &text);
                self.cursor += text.chars().count();
                self.dirty = true;
            }
            super::PastePlan::Submit(lines) => {
                self.input.clear();
                self.cursor = 0;
                self.history_position = None;
                self.paste_queue.extend(lines);
                self.submit_next_paste_line();
            }
        }
    }

    fn submit_next_paste_line(&mut self) {
        if !self.at_prompt || self.state == ProgramWindowState::Running {
            return;
        }
        let Some(line) = self.paste_queue.pop_front() else {
            return;
        };
        self.input = line;
        self.cursor = self.input.chars().count();
        self.submit_repl_line();
    }

    fn paste_notice(&mut self, message: &str) {
        if message.trim_start().starts_with('?') {
            log_diagnostic_error(Some(self.task_id), message);
        }
        self.terminal.push_bytes(message.as_bytes());
        self.terminal.push_bytes(b"\n");
        self.scroll_offset = 0;
        self.dirty = true;
    }

    fn handle_key(&mut self, mut event: super::XKeyEvent) {
        let mut buffer = [0 as c_char; 32];
        let mut keysym: KeySym = 0;
        let length = unsafe {
            XLookupString(
                &mut event,
                buffer.as_mut_ptr(),
                buffer.len() as c_int,
                &mut keysym,
                std::ptr::null_mut(),
            )
        };
        let typed_text = if length > 0 {
            let bytes = unsafe {
                std::slice::from_raw_parts(buffer.as_ptr().cast::<u8>(), length as usize)
            };
            std::str::from_utf8(bytes).ok().map(str::to_owned)
        } else {
            None
        };
        if self.help.is_open() {
            let (_, rows) = help_dialog_capacity(self.width, self.height);
            handle_help_dialog_key(&mut self.help, keysym, typed_text.as_deref(), rows);
            self.dirty = true;
            return;
        }
        if keysym == XK_F1 && self.at_prompt && self.state != ProgramWindowState::Running {
            self.show_help();
            return;
        }
        if let Some(keycode) = crate::screen::qb64_key_code(keysym) {
            if let Ok(mut state) = self.key_state.lock() {
                state.press(keycode);
            }
        }
        let ctrl = event.state & CONTROL_MASK != 0;
        let shift = event.state & SHIFT_MASK != 0;
        if request_interrupt_for_key(keysym, event.state, &self.interrupt) {
            self.pending_paste = None;
            self.paste_queue.clear();
            let _ = self.input_sender.send(Vec::new());
            self.screen_view = ScreenView::Text;
            self.dirty = true;
            return;
        }
        if ctrl && super::control_shortcut_letter(keysym) == Some(b'c') {
            if self.selected_text.is_empty() && !self.last_diagnostic.is_empty() {
                self.selected_text = self.last_diagnostic.clone();
            }
            if !self.selected_text.is_empty() {
                unsafe {
                    XSetSelectionOwner(
                        self.display,
                        self.paste_atoms.primary,
                        self.window,
                        event.time,
                    );
                    XSetSelectionOwner(
                        self.display,
                        self.paste_atoms.clipboard,
                        self.window,
                        event.time,
                    );
                    XFlush(self.display);
                }
            }
            return;
        }

        if self.at_prompt && self.state != ProgramWindowState::Running {
            match keysym {
                XK_PAGE_UP => {
                    self.scroll_up(self.visible_rows().saturating_sub(2));
                    return;
                }
                XK_PAGE_DOWN => {
                    self.scroll_down(self.visible_rows().saturating_sub(2));
                    return;
                }
                XK_HOME if ctrl => {
                    self.scroll_up(usize::MAX);
                    return;
                }
                XK_END if ctrl => {
                    self.scroll_offset = 0;
                    self.dirty = true;
                    return;
                }
                _ => {}
            }
        }

        if self.scroll_offset != 0 {
            self.scroll_offset = 0;
            self.dirty = true;
        }
        if (keysym == XK_INSERT && shift)
            || (ctrl && super::control_shortcut_letter(keysym) == Some(b'v'))
        {
            self.request_paste(self.paste_atoms.clipboard);
            return;
        }
        if keysym == XK_F5 && self.at_prompt {
            self.input = "RUN".to_string();
            self.cursor = 3;
            self.submit_repl_line();
            return;
        }

        let named = match keysym {
            XK_RETURN => Some("ENTER"),
            XK_BACKSPACE => Some("BACKSPACE"),
            XK_DELETE => Some("DELETE"),
            XK_LEFT => Some("LEFT"),
            XK_RIGHT => Some("RIGHT"),
            XK_UP => Some("UP"),
            XK_DOWN => Some("DOWN"),
            XK_HOME => Some("HOME"),
            XK_END => Some("END"),
            XK_PAGE_UP => Some("PAGEUP"),
            XK_PAGE_DOWN => Some("PAGEDOWN"),
            XK_ESCAPE => Some("ESC"),
            _ => None,
        };
        if self.state == ProgramWindowState::Running {
            if let Some(key) = named {
                self.queue_key(key.to_string());
            } else if let Some(text) = typed_text.as_deref() {
                for character in text.chars().filter(|character| !character.is_control()) {
                    self.queue_key(character.to_string());
                }
            }
            // Graphics programs own every key, including Enter. Do not also
            // submit Enter as an empty READY line behind the running game.
            if self.screen_view != ScreenView::Text {
                return;
            }
            if matches!(keysym, XK_UP | XK_DOWN) {
                return;
            }
        }

        if self.at_prompt && keysym == XK_UP && event.state & CONTROL_MASK == 0 {
            if self.edit_mode {
                self.select_edit_line(true);
            } else {
                self.history_previous();
            }
            return;
        }
        if self.at_prompt && keysym == XK_DOWN && event.state & CONTROL_MASK == 0 {
            if self.edit_mode {
                self.select_edit_line(false);
            } else {
                self.history_next();
            }
            return;
        }

        match keysym {
            XK_RETURN => self.submit_repl_line(),
            XK_BACKSPACE if self.cursor > 0 => {
                let start = byte_index_for_character(&self.input, self.cursor - 1);
                let end = byte_index_for_character(&self.input, self.cursor);
                self.input.replace_range(start..end, "");
                self.cursor -= 1;
                self.dirty = true;
            }
            XK_DELETE if self.cursor < self.input.chars().count() => {
                let start = byte_index_for_character(&self.input, self.cursor);
                let end = byte_index_for_character(&self.input, self.cursor + 1);
                self.input.replace_range(start..end, "");
                self.dirty = true;
            }
            XK_LEFT => {
                self.cursor = self.cursor.saturating_sub(1);
                self.dirty = true;
            }
            XK_RIGHT => {
                self.cursor = (self.cursor + 1).min(self.input.chars().count());
                self.dirty = true;
            }
            XK_HOME => {
                self.cursor = 0;
                self.dirty = true;
            }
            XK_END => {
                self.cursor = self.input.chars().count();
                self.dirty = true;
            }
            XK_ESCAPE => {
                self.pending_paste = None;
                self.paste_queue.clear();
                if self.edit_mode {
                    self.leave_edit_mode();
                } else {
                    self.input.clear();
                    self.cursor = 0;
                    self.history_position = None;
                    self.dirty = true;
                }
            }
            _ if typed_text.is_some() => {
                if let Some(text) = typed_text.as_deref() {
                    for mut character in text.chars().filter(|character| !character.is_control()) {
                        if self.caps_mode
                            && character.is_ascii_alphabetic()
                            && !super::cursor_is_inside_quotes(&self.input, self.cursor)
                        {
                            character = character.to_ascii_uppercase();
                        }
                        let byte = byte_index_for_character(&self.input, self.cursor);
                        self.input.insert(byte, character);
                        self.cursor += 1;
                    }
                    self.dirty = true;
                }
            }
            _ => {}
        }
    }

    fn handle_key_release(&mut self, mut event: super::XKeyEvent) {
        let mut buffer = [0 as c_char; 1];
        let mut keysym: KeySym = 0;
        unsafe {
            XLookupString(
                &mut event,
                buffer.as_mut_ptr(),
                buffer.len() as c_int,
                &mut keysym,
                std::ptr::null_mut(),
            );
        }
        if let Some(keycode) = crate::screen::qb64_key_code(keysym) {
            if let Ok(mut state) = self.key_state.lock() {
                state.release(keycode);
            }
        }
    }

    fn focus_changed(&mut self, focused: bool) {
        if !focused {
            if let Ok(mut state) = self.key_state.lock() {
                state.clear_held();
            }
        }
    }

    fn terminate_and_close(mut self, display: *mut Display) {
        self.interrupt.store(true, Ordering::SeqCst);
        let _ = self.input_sender.send(Vec::new());
        let _ = self.input_sender.send(b"QUIT\n".to_vec());
        // A runaway producer may be blocked by the bounded event queue. Drop
        // its receiver so every blocked send wakes with an error and the
        // worker can observe the interrupt request.
        drop(self.event_receiver.take());
        drop(self.render_request_sender.take());

        // Release the X11 window immediately. Joining either worker here
        // would block the event loop when a BASIC statement or rasterization
        // is still in progress, making every shell window unresponsive.
        unsafe {
            XFreeGC(display, self.gc);
            XFreeGC(display, self.reverse_gc);
            XDestroyWindow(display, self.window);
            XFlush(display);
        }

        let task_id = self.task_id;
        let workers = Arc::new(Mutex::new(Some((
            self.worker.take(),
            self.render_worker.take(),
        ))));
        let reaper_workers = Arc::clone(&workers);
        let reaper = thread::Builder::new()
            .name(format!("modernbasic-reaper-{task_id}"))
            .spawn(move || {
                reap_program_workers(&reaper_workers);
            });
        if reaper.is_err() {
            // Thread creation failure must not detach the task and retain its
            // interpreter RAM forever. The X window is already gone, so the
            // rare fallback waits here until QUIT drops the retained session.
            reap_program_workers(&workers);
        }
    }

    fn set_colors(&mut self, display: *mut Display, colors: X11Colors) {
        self.colors = colors;
        self.terminal.set_text_colors(colors);
        self.apply_gc_colors(display);
        unsafe {
            XSetWindowBackground(display, self.window, colors.screen);
        }
        self.dirty = true;
    }

    fn apply_gc_colors(&self, display: *mut Display) {
        unsafe {
            XSetForeground(display, self.gc, self.colors.text);
            XSetBackground(display, self.gc, self.colors.screen);
            XSetForeground(display, self.reverse_gc, self.colors.screen);
            XSetBackground(display, self.reverse_gc, self.colors.text);
        }
    }
}

pub(super) struct ProgramWindowManager {
    windows: HashMap<Window, ProgramWindow>,
    by_task: HashMap<u64, Window>,
    next_task_id: u64,
    selected_task: Option<u64>,
    paste_atoms: ProgramWindowPasteAtoms,
    graphics_scale: GraphicsScaleMode,
    color_prefs: ColorPrefs,
}

impl ProgramWindowManager {
    pub(super) fn new(
        graphics_scale: GraphicsScaleMode,
        color_prefs: ColorPrefs,
        paste_atoms: ProgramWindowPasteAtoms,
    ) -> Self {
        Self {
            windows: HashMap::new(),
            by_task: HashMap::new(),
            next_task_id: 1,
            selected_task: None,
            paste_atoms,
            graphics_scale,
            color_prefs,
        }
    }

    pub(super) fn open(
        &mut self,
        source_path: Option<PathBuf>,
        initial_program: Option<Program>,
        context: ProgramWindowOpenContext<'_>,
    ) -> Result<u64, Error> {
        ensure_program_task_capacity(self.windows.len())?;
        let task_id = self.next_task_id;
        self.next_task_id = self
            .next_task_id
            .checked_add(1)
            .ok_or_else(|| Error::Io("program task ID space exhausted".into()))?;
        let program = ProgramWindow::create(
            task_id,
            source_path.as_deref(),
            initial_program,
            &self.color_prefs,
            self.paste_atoms,
            context,
        )?;
        let window = program.window;
        self.windows.insert(window, program);
        self.by_task.insert(task_id, window);
        self.selected_task = Some(task_id);
        Ok(task_id)
    }

    fn resolve_task(&self, requested: Option<u64>) -> Option<u64> {
        requested
            .or(self.selected_task)
            .filter(|id| self.by_task.contains_key(id))
    }

    fn resolve_selector(&self, selector: &str) -> Result<u64, Error> {
        let selector = selector.trim();
        let selector = selector
            .strip_prefix('"')
            .and_then(|value| value.strip_suffix('"'))
            .unwrap_or(selector)
            .trim();
        if selector.is_empty() {
            return Err(Error::syntax("program filename required"));
        }
        if let Ok(task_id) = selector.parse::<u64>() {
            return self
                .by_task
                .contains_key(&task_id)
                .then_some(task_id)
                .ok_or_else(|| Error::Io("no matching program task".into()));
        }
        let requested_name = Path::new(selector)
            .file_name()
            .map(|name| name.to_string_lossy())
            .unwrap_or_else(|| selector.into());
        let matches = self
            .windows
            .values()
            .filter(|program| program.filename.eq_ignore_ascii_case(&requested_name))
            .map(|program| program.task_id)
            .collect::<Vec<_>>();
        match matches.as_slice() {
            [task_id] => Ok(*task_id),
            [] => Err(Error::Io(format!("no open program named {requested_name}"))),
            _ => Err(Error::Io(format!(
                "more than one task is named {requested_name}; use its task ID"
            ))),
        }
    }

    pub(super) fn close_selector(
        &mut self,
        display: *mut Display,
        selector: &str,
    ) -> Result<u64, Error> {
        let task_id = self.resolve_selector(selector)?;
        self.close(display, Some(task_id))
            .ok_or_else(|| Error::Io("no matching program task".into()))
    }

    pub(super) fn stop_selector(&mut self, selector: &str) -> Result<u64, Error> {
        let task_id = self.resolve_selector(selector)?;
        self.stop(Some(task_id))
            .ok_or_else(|| Error::Io("no matching program task".into()))
    }

    pub(super) fn focus_selector(
        &mut self,
        display: *mut Display,
        root: Window,
        selector: &str,
    ) -> Result<u64, Error> {
        let task_id = self.resolve_selector(selector)?;
        self.focus(display, root, Some(task_id))
            .ok_or_else(|| Error::Io("no matching program task".into()))
    }

    pub(super) fn close(&mut self, display: *mut Display, requested: Option<u64>) -> Option<u64> {
        let task_id = self.resolve_task(requested)?;
        let window = self.by_task.remove(&task_id)?;
        let program = self.windows.remove(&window)?;
        program.terminate_and_close(display);
        if self.selected_task == Some(task_id) {
            self.selected_task = self.by_task.keys().copied().max();
        }
        Some(task_id)
    }

    pub(super) fn stop(&mut self, requested: Option<u64>) -> Option<u64> {
        let task_id = self.resolve_task(requested)?;
        let window = *self.by_task.get(&task_id)?;
        self.windows.get_mut(&window)?.request_break();
        Some(task_id)
    }

    pub(super) fn close_window(&mut self, display: *mut Display, window: Window) -> Option<u64> {
        let program = self.windows.remove(&window)?;
        let task_id = program.task_id;
        self.by_task.remove(&task_id);
        program.terminate_and_close(display);
        if self.selected_task == Some(task_id) {
            self.selected_task = self.by_task.keys().copied().max();
        }
        Some(task_id)
    }

    pub(super) fn focus(
        &mut self,
        display: *mut Display,
        root: Window,
        requested: Option<u64>,
    ) -> Option<u64> {
        let task_id = self.resolve_task(requested)?;
        let window = *self.by_task.get(&task_id)?;
        activate_window(display, root, window);
        self.selected_task = Some(task_id);
        Some(task_id)
    }

    pub(super) fn list(&self) -> Vec<ProgramTaskInfo> {
        let mut tasks = self
            .windows
            .values()
            .map(|program| ProgramTaskInfo {
                task_id: program.task_id,
                filename: program.filename.clone(),
                status: ProgramTaskStatus::from_window_state(program.state),
            })
            .collect::<Vec<_>>();
        tasks.sort_by_key(|task| task.task_id);
        tasks
    }

    pub(super) fn selected_task(&self) -> Option<u64> {
        self.selected_task
    }

    pub(super) fn contains_window(&self, window: Window) -> bool {
        self.windows.contains_key(&window)
    }

    pub(super) fn service(&mut self, display: *mut Display, color_cache: &mut X11ColorCache) {
        for program in self.windows.values_mut() {
            program.service(display, color_cache);
            program.redraw(display, self.graphics_scale);
        }
    }

    pub(super) fn set_colors(
        &mut self,
        display: *mut Display,
        color_prefs: ColorPrefs,
        colors: X11Colors,
    ) {
        self.color_prefs = color_prefs;
        for program in self.windows.values_mut() {
            program.set_colors(display, colors);
        }
    }

    pub(super) fn handle_key(&mut self, window: Window, event: super::XKeyEvent) {
        if let Some(program) = self.windows.get_mut(&window) {
            self.selected_task = Some(program.task_id);
            program.handle_key(event);
        }
    }

    pub(super) fn handle_key_release(&mut self, window: Window, event: super::XKeyEvent) {
        if let Some(program) = self.windows.get_mut(&window) {
            program.handle_key_release(event);
        }
    }

    pub(super) fn handle_focus(&mut self, window: Window, focused: bool) {
        if let Some(program) = self.windows.get_mut(&window) {
            program.focus_changed(focused);
        }
    }

    pub(super) fn handle_button(&mut self, window: Window, event: XButtonEvent, pressed: bool) {
        if let Some(program) = self.windows.get_mut(&window) {
            self.selected_task = Some(program.task_id);
            if program.help.is_open() {
                if pressed {
                    let (_, rows) = help_dialog_capacity(program.width, program.height);
                    match event.button {
                        4 => program.help.page_up(3),
                        5 => program.help.page_down(3.min(rows.max(1))),
                        _ => {}
                    }
                    program.dirty = true;
                }
                return;
            }
            program.update_pointer(
                event.x,
                event.y,
                Some((event.button, pressed)),
                self.graphics_scale,
            );
            match (event.button, pressed) {
                (1, true) => program.begin_selection(event.x, event.y),
                (1, false) => program.finish_selection(event.x, event.y, event.time),
                (2, true) => program.request_paste(self.paste_atoms.primary),
                (4, true) => program.scroll_up(3),
                (5, true) => program.scroll_down(3),
                _ => {}
            }
        }
    }

    pub(super) fn handle_selection_notify(&mut self, window: Window, event: XSelectionEvent) {
        if let Some(program) = self.windows.get_mut(&window) {
            program.handle_selection_notify(event);
        }
    }

    pub(super) fn handle_selection_request(&self, window: Window, event: XSelectionRequestEvent) {
        if let Some(program) = self.windows.get(&window) {
            program.handle_selection_request(event);
        }
    }

    pub(super) fn handle_selection_clear(&mut self, window: Window, event: XSelectionClearEvent) {
        if let Some(program) = self.windows.get_mut(&window) {
            program.handle_selection_clear(event);
        }
    }

    pub(super) fn handle_motion(&mut self, window: Window, x: c_int, y: c_int) {
        if let Some(program) = self.windows.get_mut(&window) {
            if program.help.is_open() {
                return;
            }
            program.update_pointer(x, y, None, self.graphics_scale);
            program.extend_selection(x, y);
        }
    }

    pub(super) fn handle_leave(&mut self, window: Window) {
        if let Some(program) = self.windows.get_mut(&window) {
            program.leave();
        }
    }

    pub(super) fn handle_expose(&mut self, window: Window) {
        if let Some(program) = self.windows.get_mut(&window) {
            program.expose();
        }
    }

    pub(super) fn handle_configure(&mut self, window: Window, event: XConfigureEvent) {
        if let Some(program) = self.windows.get_mut(&window) {
            program.configure(event);
        }
    }

    pub(super) fn close_all(&mut self, display: *mut Display) {
        let windows = self
            .windows
            .drain()
            .map(|(_, program)| program)
            .collect::<Vec<_>>();
        self.by_task.clear();
        self.selected_task = None;
        for program in windows {
            program.terminate_and_close(display);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cursor_is_visible_only_during_the_blink_on_phase_of_a_ready_prompt() {
        assert!(ready_cursor_visible(
            true,
            ProgramWindowState::Idle,
            true,
            true
        ));
        assert!(!ready_cursor_visible(
            true,
            ProgramWindowState::Running,
            true,
            true
        ));
        assert!(!ready_cursor_visible(
            false,
            ProgramWindowState::Idle,
            true,
            true
        ));
        assert!(!ready_cursor_visible(
            true,
            ProgramWindowState::Idle,
            true,
            false
        ));
    }

    #[test]
    fn program_manager_reports_only_running_or_ready() {
        assert_eq!(
            ProgramTaskStatus::from_window_state(ProgramWindowState::Running).name(),
            "RUNNING"
        );
        for state in [
            ProgramWindowState::Idle,
            ProgramWindowState::Stopped,
            ProgramWindowState::Error,
        ] {
            assert_eq!(ProgramTaskStatus::from_window_state(state).name(), "READY");
        }
    }

    #[test]
    fn program_task_capacity_has_an_explicit_boundary() {
        assert!(ensure_program_task_capacity(0).is_ok());
        assert!(ensure_program_task_capacity(MAX_PROGRAM_TASKS - 1).is_ok());
        let error = ensure_program_task_capacity(MAX_PROGRAM_TASKS).unwrap_err();
        assert!(error
            .to_string()
            .contains("program task limit reached (32)"));
        assert!(ensure_program_task_capacity(usize::MAX).is_err());
    }
}
