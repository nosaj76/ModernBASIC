//! Deterministic executable slice for numbered BASIC programs.
//!
//! This module implements a tiny interpreter that re-uses the existing
//! tokenizer, expression evaluator and program store.  Supported statements:
//!
//! * `LET v = expr` and implicit assignment (`v = expr`), including array
//!   elements such as `A(I,J) = X`.
//! * `DIM A(upper1,upper2,...)` and `DIM` lists such as
//!   `DIM A(2,3),B$(4)`.
//! * Array reads in expressions, including `PRINT`, `IF`, and subscripts.
//! * Checked numeric/string built-ins implemented by [`crate::functions`].
//! * Numeric one-or-more-argument user functions with `DEF FN`, plus
//!   multi-line numeric and string `FUNCTION` declarations.
//! * `PRINT` / `PRINT#` with semicolons, fixed comma zones, `TAB`, `SPC`, and
//!   runtime `POS`
//! * Bounded canonical `LIST [start][-end]` and active-store `NEW`
//! * Native `RUN [line]`, explicit termination reasons, and retained sessions
//! * `GOTO line`
//! * `IF expr THEN line_or_statement` and `IF expr GOTO line`
//! * `GOSUB line` / `RETURN`
//! * `ON expr GOTO line_list` and `ON expr GOSUB line_list`
//! * `FOR v = start TO limit [STEP step]` / `NEXT [v[,v...]]`
//! * Distinct `END` / `STOP` with host-native `STOP` continuation
//! * `DATA`, `READ`, `RESTORE`, and reader-driven `INPUT` / `GET`
//! * Sandboxed native `OPEN`, `CLOSE`, `PRINT#`, `INPUT#`, `GET#`, `LOAD`,
//!   `SAVE`, and canonical source `VERIFY`
//! * `CLEAR` runtime-state reset
//! * Colon-separated multiple statements on a single line
//!
//! Variable typing follows Microsoft BASIC suffix rules: `$` is string, `%` is
//! signed 32-bit integer, `&` is signed 64-bit integer, `!` is single precision,
//! and `#` is double precision. Unsuffixed numeric names use the normal ModernBASIC
//! numeric value model. Missing numeric variables read as `0`, missing string
//! variables read as `""`, and incompatible assignments report
//! [`Error::TypeMismatch`].
//!
//! Array semantics follow `array.s` / `var.s`: upper bounds are inclusive, a
//! reference before `DIM` implicitly creates each dimension with upper bound
//! 10, explicit `DIM` of an existing array is a redimension error, out-of-range
//! or wrong-dimension subscripts report [`Error::BadSubscript`], and negative
//! bounds or indices report [`Error::IllegalQuantity`].
//!
//! Execution proceeds through a native statement-level program counter.  Each
//! physical program line is flattened into one or more executable statement
//! entries, split only on [`TokenInstance::Colon`].  Quoted strings and `REM`
//! text are opaque to the splitter because their colons are stored inside
//! `TokenInstance::String` and `TokenInstance::Rem`.  Empty segments are kept so
//! a `GOTO` target that is a colon-only or empty line still resolves to a
//! valid statement.
//!
//! Branch targets (`GOTO`, numeric `IF` targets and `ON` branches) are resolved
//! against a deterministic line-number-to-first-statement lookup.  Sequential
//! advance moves to the next statement, which may be on the same physical
//! line.
//! Configurable step, call-stack, loop-stack, output-padding, listing-byte,
//! string-byte, aggregate retained-payload, array-element and runtime-input
//! limits guard against runaway loops, recursion, oversized values, and
//! unbounded input retries.

use std::cell::RefCell;
use std::collections::{BTreeMap, HashMap, HashSet};
use std::io::{BufRead, Write};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use crate::arrays::{ArrayStore, DEFAULT_MAX_ARRAY_ELEMENTS, LEGACY_MAX_ARRAY_ELEMENTS};
use crate::artist_backend::ArtistBackend;
use crate::data::{DataCursor, DEFAULT_MAX_DATA_ITEMS, LEGACY_MAX_DATA_ITEMS};
use crate::error::Error;
use crate::eval;
use crate::file_io::{
    FileMode, FileStore, DEFAULT_MAX_BINARY_PROGRAM_BYTES, DEFAULT_MAX_FILE_BYTES,
    DEFAULT_MAX_OPEN_FILES,
};
use crate::flipbook::{expand_frame_template, FlipbookSequence};
use crate::graphics::{screen_mode_dimensions, GraphicsDevice, GraphicsMode, RasterAction};
use crate::image_codec::{decode_image, read_ppm, register_memory_image, RgbImage};
use crate::input::{
    convert_get_byte, convert_input_field, read_get_byte, read_input_line, split_input_fields,
    DEFAULT_MAX_INPUT_BYTES, DEFAULT_MAX_INPUT_LINES, LEGACY_MAX_INPUT_BYTES,
};
use crate::integer::{BasicInteger, NumericMode};
use crate::mat::{
    self, MatArraySpec, MatExpression, MatFill, MatPrintItem, MatPrintMode, MatStatement,
};
use crate::matrix::{Matrix, MatrixShape};
use crate::network::{WebMethod, DEFAULT_MAX_NETWORK_BYTES};
use crate::output::{advance_column, spaces_to_next_zone};
use crate::program::{Program, DEFAULT_MAX_SOURCE_LINE_BYTES, MAX_BASIC_LINE_NUMBER};
use crate::random::{BasicRng, DEFAULT_RANDOM_SEED};
use crate::real::BasicReal;
use crate::screen::{emit_screen_event, screen_attached, ScreenEvent, ScreenView};
use crate::storage::{StorageBudget, DEFAULT_MAX_STORAGE_BYTES, LEGACY_MAX_STORAGE_BYTES};
use crate::synth::{
    FilterMode, LfoTarget, LfoWaveform, PlaybackSession, SidSynth, SynthArrangement, SynthProfile,
    Waveform,
};
use crate::ti_graph::{validate_ti_color, TiGraphState};
use crate::tokens::{detokenize, tokenize, Token, TokenInstance};
use crate::user_functions::{compact_function_name, UserFunctions};
use crate::value::{is_string_variable, variable_type, Value, VariableType, Variables};
use crate::video::VideoRecorder;

/// Default maximum nesting depth for user-defined function evaluation.
pub const DEFAULT_MAX_FUNCTION_DEPTH: usize = 100;
/// Default statement budget for a non-interactive modern batch run.
///
/// The graphical and terminal READY environments remain unlimited because
/// they provide an explicit BREAK path. Batch runs keep a finite guard while
/// allowing computation-sized programs to use current 64-bit hardware.
pub const DEFAULT_MAX_STEPS: usize = 10_000_000;
/// Default maximum spaces emitted by one `TAB`, `SPC`, or comma operation.
pub const DEFAULT_MAX_PRINT_PADDING: usize = 1_048_576;
/// Default maximum bytes emitted by one canonical `LIST` command.
pub const DEFAULT_MAX_LISTING_BYTES: usize = 16 * 1_048_576;
/// Default arithmetic-work limit for one matrix multiply or inverse.
pub const DEFAULT_MAX_MATRIX_OPERATIONS: usize = 25_000_000;
/// Maximum number of host-approved entries visible through `ENVIRON$`.
pub const MAX_ENVIRONMENT_ENTRIES: usize = 255;
/// Hard ceiling for a SoundFont engine asset. Ordinary BASIC files retain the
/// much smaller configurable `max_file_bytes` limit.
const MAX_SOUNDFONT_BYTES: usize = 512 * 1_048_576;
const MAX_INPUT_FUNCTION_COUNT: usize = 32_767;
const DEFAULT_SOUNDFONT_PATH: &str = "soundfont/MuseScore_General.sf2";
const TEXT_SCREEN_COLUMNS: usize = 80;
const TEXT_SCREEN_ROWS: usize = 25;
const DEFAULT_TEXT_COLOR_FG: i64 = 10;
const DEFAULT_TEXT_COLOR_BG: i64 = 0;
const SYSTEM_SOUNDFONT_PATHS: &[&str] = &[
    "/usr/share/sounds/sf2/MuseScore_General.sf2",
    "/usr/share/sounds/sf2/FluidR3_GM.sf2",
    "/usr/share/sounds/sf2/TimGM6mb.sf2",
    "/usr/share/soundfonts/FluidR3_GM.sf2",
    "/usr/share/soundfonts/default.sf2",
];
const SYSTEM_SOUNDFONT_ROOTS: &[&str] = &[
    "/usr/local/share/modernbasic/soundfont",
    "/usr/share/modernbasic/soundfont",
];

/// Locate the root-level SoundFont hardware directory independently of the
/// BASIC program's current file directory. READY may `CD` anywhere beneath
/// `programs`, but backend instruments must remain connected.
fn discover_backend_soundfont_root(file_root: Option<&Path>) -> Option<PathBuf> {
    if let Some(root) = file_root.and_then(|root| std::fs::canonicalize(root).ok()) {
        for ancestor in root.ancestors() {
            let candidate = ancestor.join("soundfont");
            if let Ok(candidate) = std::fs::canonicalize(candidate) {
                if candidate.is_dir() {
                    return Some(candidate);
                }
            }
        }
    }

    let executable = std::env::current_exe().ok()?;
    for ancestor in executable.ancestors().skip(1) {
        let candidate = ancestor.join("soundfont");
        if let Ok(candidate) = std::fs::canonicalize(candidate) {
            if candidate.is_dir() {
                return Some(candidate);
            }
        }
    }
    for candidate in SYSTEM_SOUNDFONT_ROOTS {
        if let Ok(candidate) = std::fs::canonicalize(candidate) {
            if candidate.is_dir() {
                return Some(candidate);
            }
        }
    }
    None
}

/// Strip the reserved backend prefix from `soundfont/bank.sf2` while leaving
/// validation of the remaining relative path to FileStore's sandbox resolver.
fn backend_soundfont_relative(path: &str) -> Option<PathBuf> {
    let mut components = Path::new(path).components();
    let Component::Normal(first) = components.next()? else {
        return None;
    };
    if !first.to_string_lossy().eq_ignore_ascii_case("soundfont") {
        return None;
    }
    let relative = components.as_path();
    (!relative.as_os_str().is_empty()).then(|| relative.to_path_buf())
}

static INTERRUPT_REQUESTED: AtomicBool = AtomicBool::new(false);

std::thread_local! {
    /// A shell task installs its own interrupt flag so BREAK stops only that
    /// interpreter. Hosts that do not install one retain the historical global
    /// interrupt API below.
    static THREAD_INTERRUPT_REQUESTED: RefCell<Option<Arc<AtomicBool>>> = const { RefCell::new(None) };
}

/// Sentinel used by interactive hosts that must run until an explicit BREAK.
pub const UNLIMITED_STEPS: usize = usize::MAX;

/// Request that the active interpreter stop at the next safe execution boundary.
///
/// CPU-bound execution observes this between statements. The graphical shell
/// also wakes blocked INPUT/GET reads so Ctrl+Escape becomes an immediate BREAK.
/// The flag intentionally lives outside [`RunOptions`] so existing
/// deterministic API equality and serialization assumptions remain unchanged.
pub fn request_interrupt() {
    INTERRUPT_REQUESTED.store(true, Ordering::SeqCst);
}

/// Clear a previously requested user interrupt.
pub fn clear_interrupt() {
    INTERRUPT_REQUESTED.store(false, Ordering::SeqCst);
}

/// Install or remove the interrupt source for the current interpreter thread.
///
/// This is crate-private because it is a host integration detail, not part of
/// the language-facing execution API.
pub(crate) fn set_thread_interrupt_flag(flag: Option<Arc<AtomicBool>>) {
    THREAD_INTERRUPT_REQUESTED.with(|slot| {
        *slot.borrow_mut() = flag;
    });
}

pub(crate) fn take_interrupt() -> bool {
    let local = THREAD_INTERRUPT_REQUESTED.with(|slot| {
        slot.borrow()
            .as_ref()
            .is_some_and(|flag| flag.swap(false, Ordering::SeqCst))
    });
    local || INTERRUPT_REQUESTED.swap(false, Ordering::SeqCst)
}

/// Options that control a program run.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RunOptions {
    /// Numeric semantics to use for literals and arithmetic.
    pub mode: NumericMode,
    /// Optional line at which initial execution begins.
    pub start_line: Option<u64>,
    /// Maximum number of executed *statements* before the run is aborted.
    /// [`UNLIMITED_STEPS`] disables the automatic cutoff for an interactive host.
    pub max_steps: usize,
    /// Maximum depth of the `GOSUB` call stack.
    pub max_call_depth: usize,
    /// Maximum depth of the `FOR`/`NEXT` loop stack.
    pub max_loop_depth: usize,
    /// Maximum recursion depth of `DEF FN` and multi-line `FUNCTION` calls.
    pub max_function_depth: usize,
    /// Maximum spaces emitted by one output-formatting operation.
    pub max_print_padding: usize,
    /// Maximum bytes emitted by one `LIST` command.
    pub max_listing_bytes: usize,
    /// Maximum byte length of a string value.
    pub max_string_bytes: usize,
    /// Maximum aggregate payload retained by scalar and sparse-array values.
    pub max_storage_bytes: usize,
    /// Maximum total logical array element count across all arrays.
    pub max_array_elements: usize,
    /// Maximum total number of DATA items a program may contain.
    pub max_data_items: usize,
    /// Maximum conceptual arithmetic operations in one multiply or inverse.
    pub max_matrix_operations: usize,
    /// Maximum byte length of one physical runtime input line.
    pub max_input_bytes: usize,
    /// Maximum physical lines one INPUT statement may consume.
    pub max_input_lines: usize,
    /// Initial deterministic `RND` seed for this program run.
    pub random_seed: u64,
    /// Host-approved command tail visible through `COMMAND$`.
    ///
    /// This is empty by default; the interpreter never reads the host process
    /// command line implicitly.
    pub command_line: String,
    /// Host-approved environment visible through `ENVIRON$`.
    ///
    /// Entries retain their supplied order. Names are matched
    /// ASCII-case-insensitively, and duplicate names use the final value. This
    /// is empty by default; the interpreter never inherits the host process
    /// environment implicitly.
    pub environment: Vec<(String, String)>,
    /// Permit HTTP(S), streaming media, and host-browser operations.
    ///
    /// This is false by default. Library and command-line hosts must grant the
    /// capability explicitly.
    pub network_enabled: bool,
    /// Maximum bytes returned by one WEB request or download.
    pub max_network_bytes: usize,
    /// Initial named native-synthesis profile. AUTO inspects the current host;
    /// STANDARD preserves 16 voices with three oscillator layers.
    pub synth_profile: SynthProfile,
    /// Optional exact voice override applied after the named profile.
    pub synth_voice_count: Option<usize>,
    /// Optional exact oscillator-per-voice override applied after the profile.
    pub synth_oscillator_count: Option<usize>,
    /// Optional native file sandbox root. `None` disables BASIC file I/O.
    pub file_root: Option<PathBuf>,
    /// Stable root for static program assets. When omitted, this uses
    /// `file_root`; interactive LOAD sets it to the loaded program directory.
    pub asset_root: Option<PathBuf>,
    /// Optional sandbox root for generated graphics, audio, and video files.
    /// When omitted, generated files use `file_root` for compatibility.
    pub output_root: Option<PathBuf>,
    /// Optional shared, read-only SoundFont backend root.
    pub soundfont_root: Option<PathBuf>,
    /// Maximum number of concurrently open BASIC file channels.
    pub max_open_files: usize,
    /// Maximum bytes read from or written to one BASIC file.
    pub max_file_bytes: usize,
    /// Default SVG target written by graphing or `SAVEIMAGE`.
    pub graph_output: Option<PathBuf>,
    /// Ask the desktop to open rendered Artist output.
    pub open_graph_window: bool,
    /// Test/embedding override for the append-only `LPRINT` spool. When unset,
    /// `/dev/usb/lp0` is preferred and `/tmp/modernbasic_print.spool` is the
    /// fallback.
    pub print_spool_path: Option<PathBuf>,
}

impl RunOptions {
    /// Modern 64-bit semantics with generous default limits.
    pub fn modern() -> Self {
        Self {
            mode: NumericMode::Modern,
            start_line: None,
            max_steps: DEFAULT_MAX_STEPS,
            max_call_depth: 1_000,
            max_loop_depth: 1_000,
            max_function_depth: DEFAULT_MAX_FUNCTION_DEPTH,
            max_print_padding: DEFAULT_MAX_PRINT_PADDING,
            max_listing_bytes: DEFAULT_MAX_LISTING_BYTES,
            max_string_bytes: NumericMode::MODERN_MAX_STRING_BYTES,
            max_storage_bytes: DEFAULT_MAX_STORAGE_BYTES,
            max_array_elements: DEFAULT_MAX_ARRAY_ELEMENTS,
            max_data_items: DEFAULT_MAX_DATA_ITEMS,
            max_matrix_operations: DEFAULT_MAX_MATRIX_OPERATIONS,
            max_input_bytes: DEFAULT_MAX_INPUT_BYTES,
            max_input_lines: DEFAULT_MAX_INPUT_LINES,
            random_seed: DEFAULT_RANDOM_SEED,
            command_line: String::new(),
            environment: Vec::new(),
            network_enabled: false,
            max_network_bytes: DEFAULT_MAX_NETWORK_BYTES,
            synth_profile: SynthProfile::Auto,
            synth_voice_count: None,
            synth_oscillator_count: None,
            file_root: None,
            asset_root: None,
            output_root: None,
            soundfont_root: None,
            max_open_files: DEFAULT_MAX_OPEN_FILES,
            max_file_bytes: DEFAULT_MAX_FILE_BYTES,
            graph_output: None,
            open_graph_window: false,
            print_spool_path: None,
        }
    }

    /// Internal checked 6502-range regression profile.
    ///
    /// This is retained for tests and source-port diagnostics only. It is not a
    /// second public language dialect; the command-line product is ModernBASIC.
    pub fn legacy() -> Self {
        Self {
            mode: NumericMode::Legacy6502,
            start_line: None,
            max_steps: 100_000,
            max_call_depth: 1_000,
            max_loop_depth: 1_000,
            max_function_depth: DEFAULT_MAX_FUNCTION_DEPTH,
            max_print_padding: DEFAULT_MAX_PRINT_PADDING,
            max_listing_bytes: DEFAULT_MAX_LISTING_BYTES,
            max_string_bytes: NumericMode::LEGACY_MAX_STRING_BYTES,
            max_storage_bytes: LEGACY_MAX_STORAGE_BYTES,
            max_array_elements: LEGACY_MAX_ARRAY_ELEMENTS,
            max_data_items: LEGACY_MAX_DATA_ITEMS,
            max_matrix_operations: DEFAULT_MAX_MATRIX_OPERATIONS,
            max_input_bytes: LEGACY_MAX_INPUT_BYTES,
            max_input_lines: DEFAULT_MAX_INPUT_LINES,
            random_seed: DEFAULT_RANDOM_SEED,
            command_line: String::new(),
            environment: Vec::new(),
            network_enabled: false,
            max_network_bytes: DEFAULT_MAX_NETWORK_BYTES,
            synth_profile: SynthProfile::Standard,
            synth_voice_count: None,
            synth_oscillator_count: None,
            file_root: None,
            asset_root: None,
            output_root: None,
            soundfont_root: None,
            max_open_files: DEFAULT_MAX_OPEN_FILES,
            max_file_bytes: DEFAULT_MAX_FILE_BYTES,
            graph_output: None,
            open_graph_window: false,
            print_spool_path: None,
        }
    }

    /// Override the step limit.
    pub fn with_max_steps(mut self, max_steps: usize) -> Self {
        self.max_steps = max_steps;
        self
    }

    /// Disable automatic step termination. Interactive BASIC shells use this
    /// profile so intentional loops continue until the user requests BREAK.
    pub fn with_unlimited_steps(mut self) -> Self {
        self.max_steps = UNLIMITED_STEPS;
        self
    }

    /// Begin initial execution at an exact numbered line.
    pub fn with_start_line(mut self, start_line: u64) -> Self {
        self.start_line = Some(start_line);
        self
    }

    /// Override the subroutine call-stack depth limit.
    pub fn with_max_call_depth(mut self, max_call_depth: usize) -> Self {
        self.max_call_depth = max_call_depth;
        self
    }

    /// Override the loop-stack depth limit.
    pub fn with_max_loop_depth(mut self, max_loop_depth: usize) -> Self {
        self.max_loop_depth = max_loop_depth;
        self
    }

    /// Override the user-function recursion depth limit.
    pub fn with_max_function_depth(mut self, max_function_depth: usize) -> Self {
        self.max_function_depth = max_function_depth;
        self
    }

    /// Override the padding limit for `TAB`, `SPC`, and comma zones.
    pub fn with_max_print_padding(mut self, max_print_padding: usize) -> Self {
        self.max_print_padding = max_print_padding;
        self
    }

    /// Override the byte limit for one canonical `LIST` result.
    pub fn with_max_listing_bytes(mut self, max_listing_bytes: usize) -> Self {
        self.max_listing_bytes = max_listing_bytes;
        self
    }

    /// Override the string byte limit.
    pub fn with_max_string_bytes(mut self, max_string_bytes: usize) -> Self {
        self.max_string_bytes = max_string_bytes;
        self
    }

    /// Override the aggregate retained-value payload limit.
    pub fn with_max_storage_bytes(mut self, max_storage_bytes: usize) -> Self {
        self.max_storage_bytes = max_storage_bytes;
        self
    }

    /// Override the total logical array element limit.
    pub fn with_max_array_elements(mut self, max_array_elements: usize) -> Self {
        self.max_array_elements = max_array_elements;
        self
    }

    /// Override the total DATA item limit.
    pub fn with_max_data_items(mut self, max_data_items: usize) -> Self {
        self.max_data_items = max_data_items;
        self
    }

    /// Override the maximum byte length of one runtime input line.
    pub fn with_max_input_bytes(mut self, max_input_bytes: usize) -> Self {
        self.max_input_bytes = max_input_bytes;
        self
    }

    /// Override the physical-line limit for one INPUT statement.
    pub fn with_max_input_lines(mut self, max_input_lines: usize) -> Self {
        self.max_input_lines = max_input_lines;
        self
    }

    /// Override the deterministic initial `RND` seed.
    pub fn with_random_seed(mut self, random_seed: u64) -> Self {
        self.random_seed = random_seed;
        self
    }

    /// Select the initial native synthesis profile for this run.
    pub fn with_synth_profile(mut self, profile: SynthProfile) -> Self {
        self.synth_profile = profile;
        self
    }

    /// Override the initial active native voice count.
    pub fn with_synth_voice_count(mut self, count: usize) -> Self {
        self.synth_voice_count = Some(count);
        self
    }

    /// Override the initial oscillator layers available to every native voice.
    pub fn with_synth_oscillator_count(mut self, count: usize) -> Self {
        self.synth_oscillator_count = Some(count);
        self
    }

    /// Supply the exact host-approved text returned by `COMMAND$`.
    pub fn with_command_line(mut self, command_line: impl Into<String>) -> Self {
        self.command_line = command_line.into();
        self
    }

    /// Replace the host-approved environment returned by `ENVIRON$`.
    pub fn with_environment<I, K, V>(mut self, environment: I) -> Self
    where
        I: IntoIterator<Item = (K, V)>,
        K: Into<String>,
        V: Into<String>,
    {
        self.environment = environment
            .into_iter()
            .map(|(name, value)| (name.into(), value.into()))
            .collect();
        self
    }

    /// Append one host-approved environment entry for `ENVIRON$`.
    pub fn with_environment_variable(
        mut self,
        name: impl Into<String>,
        value: impl Into<String>,
    ) -> Self {
        self.environment.push((name.into(), value.into()));
        self
    }

    /// Grant or revoke HTTP(S), streaming-media, and browser access.
    pub fn with_network_access(mut self, enabled: bool) -> Self {
        self.network_enabled = enabled;
        self
    }

    /// Override the maximum bytes returned by one WEB request.
    pub fn with_max_network_bytes(mut self, max_network_bytes: usize) -> Self {
        self.max_network_bytes = max_network_bytes;
        self
    }

    /// Enable native BASIC file I/O inside the supplied sandbox directory.
    pub fn with_file_root(mut self, file_root: impl Into<PathBuf>) -> Self {
        self.file_root = Some(file_root.into());
        self
    }

    /// Resolve static SoundFont, bitmap, flipbook, audio, and video inputs from
    /// a stable root that is unaffected by BASIC `CD`/`CHDIR`.
    pub fn with_asset_root(mut self, asset_root: impl Into<PathBuf>) -> Self {
        self.asset_root = Some(asset_root.into());
        self
    }

    /// Place generated graphics, audio, and video in a separate sandbox.
    pub fn with_output_root(mut self, output_root: impl Into<PathBuf>) -> Self {
        self.output_root = Some(output_root.into());
        self
    }

    /// Select a shared SoundFont backend independently of BASIC file storage.
    pub fn with_soundfont_root(mut self, soundfont_root: impl Into<PathBuf>) -> Self {
        self.soundfont_root = Some(soundfont_root.into());
        self
    }

    /// Override the concurrent open-channel limit.
    pub fn with_max_open_files(mut self, max_open_files: usize) -> Self {
        self.max_open_files = max_open_files;
        self
    }

    /// Override the maximum bytes read from or written to one file.
    pub fn with_max_file_bytes(mut self, max_file_bytes: usize) -> Self {
        self.max_file_bytes = max_file_bytes;
        self
    }

    /// Override the arithmetic-work limit for one matrix operation.
    pub fn with_max_matrix_operations(mut self, max_matrix_operations: usize) -> Self {
        self.max_matrix_operations = max_matrix_operations;
        self
    }

    /// Select the default SVG path written by graph rendering.
    pub fn with_graph_output(mut self, output: impl Into<PathBuf>) -> Self {
        self.graph_output = Some(output.into());
        self
    }

    /// Control whether successful Artist rendering opens its SVG on the desktop.
    pub fn with_open_graph_window(mut self, open: bool) -> Self {
        self.open_graph_window = open;
        self
    }

    /// Override the append-only `LPRINT` spool target. This is useful for
    /// embedded sessions and deterministic hardware-free tests.
    pub fn with_print_spool_path(mut self, path: impl Into<PathBuf>) -> Self {
        self.print_spool_path = Some(path.into());
        self
    }
}

fn validated_process_context(
    options: &RunOptions,
) -> Result<(String, Vec<(String, String)>), Error> {
    if options.environment.len() > MAX_ENVIRONMENT_ENTRIES {
        return Err(Error::IllegalQuantity);
    }
    if options.command_line.len() > options.max_string_bytes {
        return Err(Error::StringTooLong {
            length: options.command_line.len(),
            limit: options.max_string_bytes,
        });
    }

    let mut environment: Vec<(String, String)> = Vec::with_capacity(options.environment.len());
    for (name, value) in &options.environment {
        if name.is_empty() || name.contains('=') {
            return Err(Error::syntax(
                "environment names must be non-empty and cannot contain '='",
            ));
        }
        let entry_length = name
            .len()
            .checked_add(1)
            .and_then(|length| length.checked_add(value.len()))
            .ok_or(Error::StringTooLong {
                length: usize::MAX,
                limit: options.max_string_bytes,
            })?;
        if entry_length > options.max_string_bytes {
            return Err(Error::StringTooLong {
                length: entry_length,
                limit: options.max_string_bytes,
            });
        }
        if let Some(existing) = environment
            .iter_mut()
            .find(|(existing, _)| existing.eq_ignore_ascii_case(name))
        {
            *existing = (name.clone(), value.clone());
        } else {
            environment.push((name.clone(), value.clone()));
        }
    }

    let context_bytes =
        environment
            .iter()
            .try_fold(options.command_line.len(), |total, (name, value)| {
                total
                    .checked_add(name.len())
                    .and_then(|total| total.checked_add(1))
                    .and_then(|total| total.checked_add(value.len()))
                    .ok_or(Error::StringTooLong {
                        length: usize::MAX,
                        limit: options.max_string_bytes,
                    })
            })?;
    if context_bytes > options.max_string_bytes {
        return Err(Error::StringTooLong {
            length: context_bytes,
            limit: options.max_string_bytes,
        });
    }
    Ok((options.command_line.clone(), environment))
}

/// Why a successful one-shot execution returned to its host caller.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum RunTermination {
    /// Execution advanced beyond the final statement or loaded an empty store.
    #[default]
    Exhausted,
    /// An `END` statement executed.
    End,
    /// A `STOP` statement executed.
    Stop,
    /// A retained session yielded after one debugger `STEP` operation.
    Step,
    /// A `LIST` direct command returned a canonical listing.
    List,
    /// A `NEW` direct command cleared the active store.
    New,
}

/// Captured result of running a program.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RunResult {
    /// Number of *statements* executed.
    pub steps: usize,
    /// Active numbered program after `LOAD`, `NEW`, `RUN`, or completion.
    pub final_program: Program,
    /// Deterministic reason execution returned successfully.
    pub termination: RunTermination,
}

/// Observable lifecycle state for a retained native execution session.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SessionState {
    /// The program has not started yet.
    Ready,
    /// A `STOP` statement paused execution and `resume` is available.
    Stopped,
    /// A debugger `STEP` completed and execution can be stepped or resumed.
    Paused,
    /// Execution completed for the supplied reason.
    Terminated(RunTermination),
    /// Execution returned an error; the partial session cannot be resumed.
    Faulted,
}

/// Result of one start or resume operation on an [`ExecutionSession`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SessionResult {
    /// Total statements consumed by this session across every resume.
    pub total_steps: usize,
    /// Session state after this operation.
    pub state: SessionState,
}

#[derive(Debug, Clone, Copy)]
enum SessionPosition {
    Ready(Option<u64>),
    Stopped(usize),
    Paused(usize),
    Terminated(RunTermination),
    Faulted,
}

/// Retained host-native BASIC execution state with resumable `STOP` support.
///
/// The session owns the active program copy, variables, arrays, DATA cursor,
/// control stacks, RNG, file channels, step budget, and output column. A host
/// may therefore call [`ExecutionSession::resume`] after `STOP` without
/// reconstructing or emulating historical memory.
pub struct ExecutionSession {
    interpreter: Interpreter,
    position: SessionPosition,
}

/// A host-approved deterministic replacement for a legacy machine-code entry point.
pub type SystemService = fn(i64) -> Result<i64, Error>;

impl ExecutionSession {
    /// Create a ready session over an immutable caller-supplied program.
    pub fn new(program: &Program, options: RunOptions) -> Result<Self, Error> {
        let mut interpreter = Interpreter::new(options)?;
        interpreter.current_program = program.clone();
        interpreter.prepare_program_assets()?;
        let start_line = interpreter.initial_start_line.take();
        Ok(Self {
            interpreter,
            position: SessionPosition::Ready(start_line),
        })
    }

    /// Current observable lifecycle state.
    pub fn state(&self) -> SessionState {
        match self.position {
            SessionPosition::Ready(_) => SessionState::Ready,
            SessionPosition::Stopped(_) => SessionState::Stopped,
            SessionPosition::Paused(_) => SessionState::Paused,
            SessionPosition::Terminated(reason) => SessionState::Terminated(reason),
            SessionPosition::Faulted => SessionState::Faulted,
        }
    }

    /// Active numbered program, including any successful `LOAD` or `NEW`.
    pub fn active_program(&self) -> &Program {
        &self.interpreter.current_program
    }

    /// Replace the active numbered program after an interactive edit.
    /// Runtime values are retained, but a paused `STOP` continuation is
    /// invalidated because its statement address may no longer exist.
    pub fn replace_program(&mut self, program: &Program) -> Result<(), Error> {
        self.interpreter
            .install_program_with_assets(program.clone())?;
        self.interpreter.release_structured_storage();
        self.interpreter.call_stack.clear();
        self.interpreter.loop_stack.clear();
        self.position = SessionPosition::Ready(None);
        Ok(())
    }

    /// Prepare static assets declared by the active stored program.
    /// Interactive hosts call this before advertising the next READY boundary.
    pub fn prepare_program_assets(&mut self) -> Result<usize, Error> {
        Ok(self.interpreter.prepared_asset_count)
    }

    /// Return a completed or faulted session to a fresh RUN boundary without
    /// discarding assets that were already prepared before READY.
    pub(crate) fn restart_ready(&mut self) {
        self.position = SessionPosition::Ready(None);
    }

    /// Change the directory used by subsequent BASIC file operations while
    /// retaining the active program, variables, arrays, and open channels.
    pub fn set_file_root(&mut self, root: impl Into<PathBuf>) -> Result<(), Error> {
        self.interpreter.files.set_root(root.into())
    }

    /// Register a safe deterministic service used by SYS and numeric CALL.
    pub fn register_system_service(&mut self, address: usize, service: SystemService) {
        self.interpreter.system_services.insert(address, service);
    }

    /// Execute one unnumbered direct-mode BASIC line while retaining variables,
    /// arrays, files, RNG state, and the active numbered program.
    pub fn execute_direct<W: Write>(
        &mut self,
        source: &str,
        writer: &mut W,
    ) -> Result<SessionResult, Error> {
        let mut input = std::io::empty();
        self.execute_direct_with_input(source, &mut input, writer)
    }

    /// Execute one unnumbered direct-mode BASIC line with runtime input.
    pub fn execute_direct_with_input<R: BufRead + ?Sized, W: Write>(
        &mut self,
        source: &str,
        input: &mut R,
        writer: &mut W,
    ) -> Result<SessionResult, Error> {
        if matches!(
            self.position,
            SessionPosition::Stopped(_) | SessionPosition::Paused(_)
        ) {
            return Err(Error::CannotContinue);
        }
        let outcome = match self.interpreter.execute_direct(source, input, writer) {
            Ok(outcome) => outcome,
            Err(error) => {
                self.interpreter.release_screen_locks();
                if error == Error::Break {
                    self.interpreter.stop_runtime_processes();
                }
                self.interpreter.close_device_handles();
                return Err(error);
            }
        };
        self.position = match (outcome.termination, outcome.resume_pc) {
            (RunTermination::Stop, Some(resume_pc)) => SessionPosition::Stopped(resume_pc),
            _ => SessionPosition::Ready(None),
        };
        Ok(SessionResult {
            total_steps: self.interpreter.steps,
            state: self.state(),
        })
    }

    /// Total statement count consumed across every session operation.
    pub fn total_steps(&self) -> usize {
        self.interpreter.steps
    }

    /// Retained scalar and sparse-array value payload in bytes.
    pub fn storage_bytes_used(&self) -> usize {
        self.interpreter.storage.used_bytes()
    }

    /// Remaining retained-value payload budget in bytes.
    pub fn storage_bytes_remaining(&self) -> usize {
        self.interpreter.storage.remaining_bytes()
    }

    pub(crate) fn finish_terminal_output_line<W: Write>(
        &mut self,
        writer: &mut W,
    ) -> Result<(), Error> {
        if self.interpreter.output_column != 0 {
            writer.write_all(b"\n")?;
            self.interpreter.output_column = 0;
            self.interpreter.advance_text_row();
        }
        Ok(())
    }

    pub(crate) fn audio_is_active(&self) -> bool {
        self.interpreter.playback.is_active() || self.interpreter.speech.is_active()
    }

    /// Start the session with an empty runtime input stream.
    pub fn run<W: Write>(&mut self, writer: &mut W) -> Result<SessionResult, Error> {
        let mut input = std::io::empty();
        self.run_with_input(&mut input, writer)
    }

    /// Start the session with an explicit runtime input stream.
    pub fn run_with_input<R: BufRead + ?Sized, W: Write>(
        &mut self,
        input: &mut R,
        writer: &mut W,
    ) -> Result<SessionResult, Error> {
        let SessionPosition::Ready(start_line) = self.position else {
            return Err(Error::CannotContinue);
        };
        self.execute(ExecutionEntry::Rebuild(start_line), input, writer, false)
    }

    /// Continue after the most recent `STOP` or debugger step, with no input.
    pub fn resume<W: Write>(&mut self, writer: &mut W) -> Result<SessionResult, Error> {
        let mut input = std::io::empty();
        self.resume_with_input(&mut input, writer)
    }

    /// Continue after `STOP` or a debugger step while retaining runtime input.
    pub fn resume_with_input<R: BufRead + ?Sized, W: Write>(
        &mut self,
        input: &mut R,
        writer: &mut W,
    ) -> Result<SessionResult, Error> {
        let resume_pc = match self.position {
            SessionPosition::Stopped(resume_pc) | SessionPosition::Paused(resume_pc) => resume_pc,
            _ => return Err(Error::CannotContinue),
        };
        self.execute(ExecutionEntry::Resume(resume_pc), input, writer, false)
    }

    /// Execute exactly one stored-program statement with no runtime input.
    ///
    /// A step follows real control flow: stepping a `GOTO` pauses before its
    /// destination, stepping a `GOSUB` pauses before the first subroutine
    /// statement, and stepping a `RETURN` pauses at the saved return address.
    pub fn step<W: Write>(&mut self, writer: &mut W) -> Result<SessionResult, Error> {
        let mut input = std::io::empty();
        self.step_with_input(&mut input, writer)
    }

    /// Execute exactly one stored-program statement with explicit runtime input.
    pub fn step_with_input<R: BufRead + ?Sized, W: Write>(
        &mut self,
        input: &mut R,
        writer: &mut W,
    ) -> Result<SessionResult, Error> {
        let entry = match self.position {
            SessionPosition::Ready(start_line) => ExecutionEntry::Rebuild(start_line),
            SessionPosition::Stopped(resume_pc) | SessionPosition::Paused(resume_pc) => {
                ExecutionEntry::Resume(resume_pc)
            }
            SessionPosition::Terminated(_) | SessionPosition::Faulted => {
                return Err(Error::CannotContinue)
            }
        };
        self.execute(entry, input, writer, true)
    }

    /// Line containing the next statement that will execute, when resumable.
    pub fn next_line(&self) -> Option<u64> {
        let (statements, line_first) = build_statements(&self.interpreter.current_program);
        let pc = match self.position {
            SessionPosition::Ready(Some(line)) => *line_first.get(&line)?,
            SessionPosition::Ready(None) => 0,
            SessionPosition::Stopped(pc) | SessionPosition::Paused(pc) => pc,
            SessionPosition::Terminated(_) | SessionPosition::Faulted => return None,
        };
        statements.get(pc).map(|statement| statement.line_number)
    }

    fn execute<R: BufRead + ?Sized, W: Write>(
        &mut self,
        entry: ExecutionEntry,
        input: &mut R,
        writer: &mut W,
        single_step: bool,
    ) -> Result<SessionResult, Error> {
        self.position = SessionPosition::Faulted;
        let outcome = match self.interpreter.execute(input, writer, entry, single_step) {
            Ok(outcome) => outcome,
            Err(error) => {
                self.interpreter.release_screen_locks();
                if error == Error::Break {
                    self.interpreter.stop_runtime_processes();
                }
                self.interpreter.close_device_handles();
                return Err(error);
            }
        };
        self.position = match (outcome.termination, outcome.resume_pc) {
            (RunTermination::Stop, Some(resume_pc)) => SessionPosition::Stopped(resume_pc),
            (RunTermination::Stop, None) => return Err(Error::CannotContinue),
            (RunTermination::Step, Some(resume_pc)) => SessionPosition::Paused(resume_pc),
            (RunTermination::Step, None) => return Err(Error::CannotContinue),
            (reason, _) => SessionPosition::Terminated(reason),
        };
        Ok(SessionResult {
            total_steps: self.interpreter.steps,
            state: self.state(),
        })
    }

    fn into_run_result(mut self, termination: RunTermination) -> RunResult {
        RunResult {
            steps: self.interpreter.steps,
            final_program: std::mem::take(&mut self.interpreter.current_program),
            termination,
        }
    }
}

/// Run a numbered BASIC program, writing `PRINT` output to `writer`.
///
/// This is the compatibility one-shot API. Use [`ExecutionSession`] when a
/// host must retain state and call [`ExecutionSession::resume`] after `STOP`.
///
/// Statements are executed in ascending line-number order, advancing to the
/// next statement within the same line when colons are present.  The program
/// starts at `options.start_line` when supplied, otherwise at the first line,
/// and stops when it reaches the end, executes `END`/`STOP`/`LIST`, or clears
/// the active store with `NEW`. `RUN` clears BASIC program state and restarts
/// while retaining the enclosing budget and run-owned resources. The returned
/// [`RunResult`] records the final active program and exact termination reason.
/// If more than `options.max_steps` statements are executed, the run returns
/// [`Error::StepLimitExceeded`]. [`UNLIMITED_STEPS`] disables that cutoff for
/// an interactive host that provides an explicit BREAK control.
pub fn run<W: Write>(
    program: &Program,
    options: RunOptions,
    writer: &mut W,
) -> Result<RunResult, Error> {
    let mut input = std::io::empty();
    run_with_input(program, options, &mut input, writer)
}

/// Run a numbered BASIC program with an explicit runtime input stream.
pub fn run_with_input<R: BufRead + ?Sized, W: Write>(
    program: &Program,
    options: RunOptions,
    input: &mut R,
    writer: &mut W,
) -> Result<RunResult, Error> {
    let mut session = ExecutionSession::new(program, options)?;
    let result = session.run_with_input(input, writer)?;
    let termination = match result.state {
        SessionState::Stopped => RunTermination::Stop,
        SessionState::Terminated(reason) => reason,
        SessionState::Ready | SessionState::Paused | SessionState::Faulted => {
            return Err(Error::CannotContinue)
        }
    };
    Ok(session.into_run_result(termination))
}

/// Convenience wrapper that captures output into a `String`.
pub fn run_to_string(program: &Program, options: RunOptions) -> Result<(String, RunResult), Error> {
    let mut buf = Vec::new();
    let result = run(program, options, &mut buf)?;
    let text = String::from_utf8(buf).map_err(|e| Error::Io(e.to_string()))?;
    Ok((text, result))
}

/// Capture program output while supplying an explicit runtime input stream.
pub fn run_to_string_with_input<R: BufRead + ?Sized>(
    program: &Program,
    options: RunOptions,
    input: &mut R,
) -> Result<(String, RunResult), Error> {
    let mut buf = Vec::new();
    let result = run_with_input(program, options, input, &mut buf)?;
    let text = String::from_utf8(buf).map_err(|error| Error::Io(error.to_string()))?;
    Ok((text, result))
}

/// A single executable statement carved out of a numbered program line.
#[derive(Debug, Clone)]
struct Statement {
    /// The original physical line number this statement came from.
    line_number: u64,
    /// Tokens belonging to this statement only.  Empty for an empty segment.
    body: Vec<TokenInstance>,
}

#[derive(Debug, Clone)]
struct PreparedImageAsset {
    image: Arc<RgbImage>,
    virtual_path: PathBuf,
}

#[derive(Debug, Default)]
struct ProgramAssetManifest {
    soundfonts: Vec<(String, String)>,
    images: Vec<String>,
    media: Vec<(String, ProgramMediaKind)>,
    uses_instrument: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum ProgramMediaKind {
    Audio,
    Video,
}

struct CallFrame {
    /// Statement index to resume after `RETURN`.
    return_pc: usize,
    /// Loop-stack depth at the time of the matching `GOSUB`.
    loop_depth: usize,
    /// Event handlers are ordinary GOSUBs, but their matching RETURN also
    /// releases the trap's non-reentrancy guard.
    event: Option<EventKind>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum EventKind {
    Timer,
    Collision,
    Key,
    Com(u8),
    Pen,
    Strig,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum EventMode {
    Off,
    On,
    Stopped,
}

fn parse_event_mode(rest: &[TokenInstance], event: &str) -> Result<EventMode, Error> {
    match rest {
        [TokenInstance::Keyword(Token::On)] => Ok(EventMode::On),
        [TokenInstance::Ident(name)] if name == "ON" => Ok(EventMode::On),
        [TokenInstance::Keyword(Token::Stop)] => Ok(EventMode::Stopped),
        [TokenInstance::Ident(name)] if name == "STOP" => Ok(EventMode::Stopped),
        [TokenInstance::Ident(name)] if name == "OFF" => Ok(EventMode::Off),
        _ => Err(Error::syntax(format!("{event} expects ON, OFF, or STOP"))),
    }
}

struct TimerEventTrap {
    target: Option<u64>,
    interval: Duration,
    next_due: Option<Instant>,
    mode: EventMode,
    active: bool,
}

impl Default for TimerEventTrap {
    fn default() -> Self {
        Self {
            target: None,
            interval: Duration::from_secs(1),
            next_due: None,
            mode: EventMode::Off,
            active: false,
        }
    }
}

struct CollisionEventTrap {
    target: Option<u64>,
    mode: EventMode,
    active: bool,
    collision_latched: bool,
}

impl Default for CollisionEventTrap {
    fn default() -> Self {
        Self {
            target: None,
            mode: EventMode::Off,
            active: false,
            collision_latched: false,
        }
    }
}

struct ComEventTrap {
    target: Option<u64>,
    channel: u8,
    mode: EventMode,
    active: bool,
    latched_error: Option<Error>,
}

impl Default for ComEventTrap {
    fn default() -> Self {
        Self {
            target: None,
            channel: 0,
            mode: EventMode::Off,
            active: false,
            latched_error: None,
        }
    }
}

struct EdgeEventTrap {
    target: Option<u64>,
    selector: Option<u8>,
    mode: EventMode,
    active: bool,
    last_generation: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SessionClockOffset {
    Ahead(Duration),
    Behind(Duration),
}

impl SessionClockOffset {
    fn between(target: SystemTime, host: SystemTime) -> Self {
        match target.duration_since(host) {
            Ok(duration) => Self::Ahead(duration),
            Err(error) => Self::Behind(error.duration()),
        }
    }

    fn apply(self, host: SystemTime) -> SystemTime {
        match self {
            Self::Ahead(duration) => host.checked_add(duration).unwrap_or(host),
            Self::Behind(duration) => host.checked_sub(duration).unwrap_or(UNIX_EPOCH),
        }
    }
}

impl Default for EdgeEventTrap {
    fn default() -> Self {
        Self {
            target: None,
            selector: None,
            mode: EventMode::Off,
            active: false,
            last_generation: 0,
        }
    }
}

struct KeyEventTrap {
    target: Option<u64>,
    keycode: Option<u8>,
    mode: EventMode,
    active: bool,
}

impl Default for KeyEventTrap {
    fn default() -> Self {
        Self {
            target: None,
            keycode: None,
            mode: EventMode::Off,
            active: false,
        }
    }
}

#[derive(Debug, Clone)]
struct ProcedureDefinition {
    name: String,
    parameters: Vec<ProcedureParameter>,
    return_type: Option<VariableType>,
    start_pc: usize,
    end_pc: usize,
    shared: HashSet<String>,
    statics: HashSet<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ParameterMode {
    ByVal,
    ByRef,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ParameterShape {
    Scalar,
    Array,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ProcedureParameter {
    name: String,
    mode: ParameterMode,
    shape: ParameterShape,
    declaration: VariableType,
    record_type: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum ScalarReference {
    Global(String),
    Static { procedure: String, name: String },
    Local { frame_index: usize, name: String },
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum VariableReference {
    Scalar(ScalarReference),
    ArrayElement { name: String, indices: Vec<i64> },
}

impl VariableReference {
    fn name(&self) -> &str {
        match self {
            Self::Scalar(ScalarReference::Global(name))
            | Self::Scalar(ScalarReference::Static { name, .. })
            | Self::Scalar(ScalarReference::Local { name, .. })
            | Self::ArrayElement { name, .. } => name,
        }
    }
}

enum ProcedureArgument {
    Value(Value),
    Reference(VariableReference),
    ArrayReference(String),
    RecordArrayReference {
        record_type: String,
        actual_base: String,
        fields: Vec<(String, String)>,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct TypeField {
    name: String,
    declaration: VariableType,
    fixed_string_bytes: Option<usize>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct NestedTypeField {
    name: String,
    type_name: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum UnresolvedTypeFieldKind {
    Primitive {
        declaration: VariableType,
        fixed_string_bytes: Option<usize>,
    },
    Nested(String),
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct UnresolvedTypeField {
    name: String,
    kind: UnresolvedTypeFieldKind,
    line_number: u64,
}

#[derive(Debug, Clone)]
struct UnresolvedTypeDefinition {
    name: String,
    fields: Vec<UnresolvedTypeField>,
    start_pc: usize,
    end_pc: usize,
}

#[derive(Debug, Clone)]
struct TypeDefinition {
    name: String,
    fields: Vec<TypeField>,
    nested_fields: Vec<NestedTypeField>,
    start_pc: usize,
    end_pc: usize,
}

fn record_instance_declarations(base: &str, definition: &TypeDefinition) -> Vec<(String, String)> {
    let mut declarations = Vec::with_capacity(definition.nested_fields.len() + 1);
    declarations.push((base.to_string(), definition.name.clone()));
    declarations.extend(
        definition
            .nested_fields
            .iter()
            .map(|field| (format!("{base}.{}", field.name), field.type_name.clone())),
    );
    declarations
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct DeclaredValueType {
    declaration: VariableType,
    fixed_string_bytes: Option<usize>,
}

#[derive(Debug, Clone, Default)]
struct StructuredDefinitions {
    subs: HashMap<String, ProcedureDefinition>,
    functions: HashMap<String, ProcedureDefinition>,
    types: HashMap<String, TypeDefinition>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum StructuredKind {
    Sub,
    Function,
}

struct PendingProcedure {
    name: String,
    parameters: Vec<ProcedureParameter>,
    return_type: Option<VariableType>,
    start_pc: usize,
    shared: HashSet<String>,
    statics: HashSet<String>,
}

struct ProcedureFrame {
    name: String,
    kind: StructuredKind,
    return_pc: usize,
    loop_depth: usize,
    gosub_depth: usize,
    locals: Variables,
    byref: HashMap<String, VariableReference>,
    /// Canonical physical arrays owned by this call and removed on return.
    local_arrays: HashSet<String>,
    /// Type declarations shadowed by local or STATIC array aliases and
    /// restored when this invocation returns.
    local_array_types: HashMap<String, Option<DeclaredValueType>>,
    /// Record-instance declarations shadowed by local or STATIC record arrays.
    local_record_types: HashMap<String, Option<String>>,
    /// Whole-record array formals mapped to the caller's ultimate record base.
    record_byref: HashMap<String, String>,
    shared: HashSet<String>,
    statics: HashSet<String>,
}

struct ProcedureArrayOwnership {
    canonical_names: Vec<String>,
    scalar_names: Vec<String>,
    declared_names: Vec<String>,
    record_names: Vec<String>,
    record_type: Option<String>,
    is_static: bool,
}

struct LoopFrame {
    /// Loop variable name.
    var: String,
    /// Final value (inclusive for positive steps, inclusive for negative steps).
    limit: i64,
    /// Increment added by each `NEXT`.
    step: i64,
    /// Statement index of the first statement after the `FOR`.
    resume_pc: usize,
}

#[derive(Debug, Clone, Copy)]
struct StringAllocation {
    address: usize,
    capacity: usize,
}

struct Interpreter {
    mode: NumericMode,
    initial_start_line: Option<u64>,
    max_string_bytes: usize,
    max_data_items: usize,
    max_input_bytes: usize,
    max_input_lines: usize,
    max_matrix_operations: usize,
    vars: Variables,
    arrays: ArrayStore,
    default_types: [VariableType; 26],
    /// Explicit scalar/array field kinds established by `DIM ... AS ...`.
    declared_value_types: HashMap<String, DeclaredValueType>,
    /// Record base names and their declared user-defined type.
    record_instances: HashMap<String, String>,
    common_vars: HashSet<String>,
    /// Scalar names declared with CONST during the current program run.
    constants: HashSet<String>,
    /// Active structured SUB calls. Scalars are local unless declared SHARED.
    procedure_stack: Vec<ProcedureFrame>,
    /// Persistent scalar storage, keyed first by procedure and then variable.
    static_vars: HashMap<String, Variables>,
    /// Canonical physical arrays retained by STATIC procedure declarations.
    static_arrays: HashSet<String>,
    /// First established declared kind for each procedure STATIC value.
    static_declared_types: HashMap<String, String>,
    /// Validated declarations for the currently executing stored program.
    structured_definitions: StructuredDefinitions,
    /// Return-value handoff from a nested structured FUNCTION execution loop.
    function_result: Option<Value>,
    storage: StorageBudget,
    data_cursor: DataCursor,
    steps: usize,
    max_steps: usize,
    max_call_depth: usize,
    max_loop_depth: usize,
    max_function_depth: usize,
    def_function_depth: usize,
    max_print_padding: usize,
    max_listing_bytes: usize,
    call_stack: Vec<CallFrame>,
    loop_stack: Vec<LoopFrame>,
    rng: BasicRng,
    command_line: String,
    environment: Vec<(String, String)>,
    session_env: HashMap<String, String>,
    session_clock_offset: Option<SessionClockOffset>,
    network_enabled: bool,
    max_network_bytes: usize,
    files: FileStore,
    /// Read-only static inputs prepared before READY.
    assets: FileStore,
    outputs: FileStore,
    /// Read-only backend hardware assets, stable across READY `CD` commands.
    soundfont_files: Option<FileStore>,
    /// Fully decoded still images retained for BITMAP and FLIPBOOK statements.
    prepared_images: HashMap<String, PreparedImageAsset>,
    /// Local or network playback inputs retained as immutable bytes.
    prepared_media: HashMap<String, crate::media::MediaSource>,
    /// Source spelling to canonical parsed-bank identity for the active program.
    prepared_soundfont_keys: HashMap<String, String>,
    /// Immediate READY commands may prepare evaluated paths on demand. Stored
    /// execution never crosses this runtime asset boundary.
    executing_direct: bool,
    /// Unique static assets declared by the active stored program.
    prepared_asset_count: usize,
    graph_output: Option<PathBuf>,
    open_graph_window: bool,
    graph: TiGraphState,
    graphics: GraphicsDevice,
    screen_view: ScreenView,
    screen_lock_depth: usize,
    pending_screen_present: Option<ScreenEvent>,
    presentation_dirty: bool,
    /// A synchronous presentation render failed. Automatic presentation must
    /// keep using the checked renderer until it succeeds, rather than enqueue
    /// source-only work and incorrectly mark the scene clean.
    presentation_render_failed: bool,
    video: Option<VideoRecorder>,
    flipbooks: HashMap<String, FlipbookSequence>,
    /// Most recent integrated raster, keyed by its deterministic Artist
    /// source. FLIP and an immediately following VIDEO FRAME share this data.
    last_raster_source: Option<String>,
    last_raster_ppm: Option<Arc<[u8]>>,
    default_synth_arrangement: SynthArrangement,
    playback: PlaybackSession,
    speech: crate::speech::SpeechSession,
    synth: SidSynth,
    sf_engine: crate::sf_engine::SfEngine,
    /// Validated `SING` scores retained for optional `WAVEFILE` export.
    singing_scores: Vec<crate::speech::SingingScore>,
    /// Sequential PLAY position for each BASIC voice. These remain symbolic
    /// until playback, so a long SoundFont score starts without pre-rendering.
    play_positions_seconds: [f64; crate::synth::VOICE_COUNT],
    mml_state: MmlState,
    current_program: Program,
    user_functions: UserFunctions,
    /// One-based logical text cursor row. `output_column` is its zero-based column.
    cursor_row: usize,
    output_column: usize,
    view_print_top: usize,
    view_print_bottom: usize,
    text_cursor_visible: bool,
    text_color_fg: i64,
    text_color_bg: i64,
    cmd_channel: Option<u8>,
    null_padding: usize,
    output_width: Option<usize>,
    print_spool_path: Option<PathBuf>,
    lprint_column: usize,
    system_services: HashMap<usize, SystemService>,
    usr_addresses: [Option<usize>; 10],
    virtual_memory: Vec<u8>,
    memory_segment: usize,
    string_allocations: HashMap<(usize, String), StringAllocation>,
    next_string_addresses: HashMap<usize, usize>,
    virtual_ports: Vec<u8>,
    trace_enabled: bool,
    random_fields: HashMap<u8, Vec<(String, usize, usize)>>,
    /// Error trap target line (from ON ERROR GOTO). 0 = no trap.
    on_error_goto: Option<u64>,
    /// Prevent recursive trapping while an error handler is active.
    error_handler_active: bool,
    /// Last error code (for ERR variable).
    last_err_code: i64,
    /// Last error line (for ERL variable).
    last_err_line: u64,
    /// Statement that raised the active error.
    resume_pc: Option<usize>,
    /// Loop depth to restore when RESUME leaves the handler.
    resume_loop_depth: usize,
    timer_trap: TimerEventTrap,
    collision_trap: CollisionEventTrap,
    key_trap: KeyEventTrap,
    com_traps: HashMap<u8, ComEventTrap>,
    pen_trap: EdgeEventTrap,
    strig_trap: EdgeEventTrap,
}

enum Control {
    /// Continue with the next statement (possibly on the same line).
    Advance,
    /// Branch to the first statement of the target line.
    Goto(u64),
    /// Enter a classic line-number subroutine.
    Gosub(u64),
    /// Resume at a specific statement and truncate the loop stack to a saved
    /// depth.  Used by `RETURN` and by `NEXT` when it loops back.
    Resume { pc: usize, loop_depth: usize },
    /// Skip a false IF to its inline ELSE, or to the next physical line.
    SkipIfFalse,
    /// A reached ELSE means the THEN branch ran; skip its alternate branch.
    SkipElse,
    /// Skip a false pre-test WHILE body through its matching WEND.
    SkipWhile,
    /// Skip a false pre-test DO body through its matching LOOP.
    SkipDo,
    /// Scan a structured selection for the first matching branch.
    Select(Value),
    /// A reached CASE/WHEN means a prior branch ran; leave the selection.
    SkipCase,
    /// Leave the nearest active structured loop of this family.
    ExitLoop(LoopExitKind),
    /// Invoke a validated structured procedure in the stored program.
    CallSub {
        name: String,
        arguments: Vec<ProcedureArgument>,
    },
    /// Skip a procedure declaration while executing the program's main body.
    SkipSub,
    /// Return from the active structured procedure.
    ReturnSub,
    /// Skip a multi-line FUNCTION declaration in the main program stream.
    SkipFunction,
    /// Skip a user-defined TYPE declaration in the main program stream.
    SkipType,
    /// Return the active FUNCTION's typed result.
    ReturnFunction,
    /// Rebuild the executable stream and start at the first or named line.
    Restart(Option<u64>),
    /// Return successfully to the host for a specific direct-command reason.
    Terminate(RunTermination),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum LoopExitKind {
    Do,
    For,
    While,
    Repeat,
}

#[derive(Debug, Clone, Copy)]
enum ExecutionEntry {
    /// Full rebuild from RUN: resets data cursor and default type declarations.
    Rebuild(Option<u64>),
    /// Direct-mode GOTO: enters the stored program without resetting DATA.
    DirectGoto(u64),
    Resume(usize),
    Function(usize),
}

struct ExecutionOutcome {
    termination: RunTermination,
    resume_pc: Option<usize>,
}

struct DrawMacroState {
    color: String,
    angle_degrees: f64,
    scale: f64,
    blank_next: bool,
    return_next: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum MmlArticulation {
    Normal,
    Staccato,
    Legato,
}

#[derive(Debug, Clone)]
struct MmlState {
    octave: u8,
    length: u8,
    tempo: u16,
    articulation: MmlArticulation,
    background: bool,
}

impl Default for MmlState {
    fn default() -> Self {
        Self {
            octave: 4,
            length: 4,
            tempo: 120,
            articulation: MmlArticulation::Normal,
            background: false,
        }
    }
}

struct MmlEvent {
    note: Option<String>,
    beats: f64,
    articulation: MmlArticulation,
    tied_to_next: bool,
}

impl Interpreter {
    fn new(options: RunOptions) -> Result<Self, Error> {
        let (command_line, environment) = validated_process_context(&options)?;
        let soundfont_root = if let Some(root) = options.soundfont_root.as_deref() {
            let root = std::fs::canonicalize(root)?;
            if !root.is_dir() {
                return Err(Error::InvalidFilePath);
            }
            Some(root)
        } else {
            discover_backend_soundfont_root(options.file_root.as_deref())
        };
        let soundfont_files = soundfont_root
            .map(|root| FileStore::new(Some(root), 0, MAX_SOUNDFONT_BYTES))
            .transpose()?;
        let asset_root = options
            .asset_root
            .clone()
            .or_else(|| options.file_root.clone());
        let output_root = options
            .output_root
            .clone()
            .or_else(|| options.file_root.clone());
        let files = FileStore::new(
            options.file_root.clone(),
            options.max_open_files,
            options.max_file_bytes,
        )?;
        let assets = FileStore::new(asset_root, 0, options.max_file_bytes)?;
        let outputs = FileStore::new(output_root, 0, options.max_file_bytes)?;
        let graph = TiGraphState::default();
        let vars = graph_system_variables(&graph)?;
        let mut synth_arrangement = options.synth_profile.arrangement();
        if let Some(voices) = options.synth_voice_count {
            synth_arrangement.voices = voices;
        }
        if let Some(oscillators) = options.synth_oscillator_count {
            synth_arrangement.oscillators = oscillators;
        }
        let synth = SidSynth::with_arrangement(synth_arrangement)?;
        Ok(Self {
            mode: options.mode,
            initial_start_line: options.start_line,
            max_string_bytes: options.max_string_bytes,
            max_data_items: options.max_data_items,
            max_input_bytes: options.max_input_bytes,
            max_input_lines: options.max_input_lines,
            max_matrix_operations: options.max_matrix_operations,
            vars,
            arrays: ArrayStore::new(options.max_array_elements),
            default_types: [VariableType::Numeric; 26],
            declared_value_types: HashMap::new(),
            record_instances: HashMap::new(),
            common_vars: HashSet::new(),
            constants: HashSet::new(),
            procedure_stack: Vec::new(),
            static_vars: HashMap::new(),
            static_arrays: HashSet::new(),
            static_declared_types: HashMap::new(),
            structured_definitions: StructuredDefinitions::default(),
            function_result: None,
            storage: StorageBudget::new(options.max_storage_bytes),
            data_cursor: DataCursor::default(),
            steps: 0,
            max_steps: options.max_steps,
            max_call_depth: options.max_call_depth,
            max_loop_depth: options.max_loop_depth,
            max_function_depth: options.max_function_depth,
            def_function_depth: 0,
            max_print_padding: options.max_print_padding,
            max_listing_bytes: options.max_listing_bytes,
            call_stack: Vec::new(),
            loop_stack: Vec::new(),
            rng: BasicRng::new(options.random_seed),
            command_line,
            environment,
            session_env: HashMap::new(),
            session_clock_offset: None,
            network_enabled: options.network_enabled,
            max_network_bytes: options.max_network_bytes,
            files,
            assets,
            outputs,
            soundfont_files,
            prepared_images: HashMap::new(),
            prepared_media: HashMap::new(),
            prepared_soundfont_keys: HashMap::new(),
            executing_direct: false,
            prepared_asset_count: 0,
            graph_output: options.graph_output,
            open_graph_window: options.open_graph_window,
            graph,
            graphics: GraphicsDevice::default(),
            screen_view: ScreenView::Text,
            screen_lock_depth: 0,
            pending_screen_present: None,
            presentation_dirty: false,
            presentation_render_failed: false,
            video: None,
            flipbooks: HashMap::new(),
            last_raster_source: None,
            last_raster_ppm: None,
            default_synth_arrangement: synth_arrangement,
            playback: PlaybackSession::default(),
            speech: crate::speech::SpeechSession::default(),
            synth,
            sf_engine: crate::sf_engine::SfEngine::new(44100),
            singing_scores: Vec::new(),
            play_positions_seconds: [0.0; crate::synth::VOICE_COUNT],
            mml_state: MmlState::default(),
            current_program: Program::new(),
            user_functions: UserFunctions::default(),
            cursor_row: 1,
            output_column: 0,
            view_print_top: 1,
            view_print_bottom: TEXT_SCREEN_ROWS,
            text_cursor_visible: true,
            text_color_fg: DEFAULT_TEXT_COLOR_FG,
            text_color_bg: DEFAULT_TEXT_COLOR_BG,
            cmd_channel: None,
            null_padding: 0,
            output_width: None,
            print_spool_path: options.print_spool_path,
            lprint_column: 0,
            system_services: HashMap::new(),
            usr_addresses: [None; 10],
            virtual_memory: vec![0; 1_048_576],
            memory_segment: 0,
            string_allocations: HashMap::new(),
            next_string_addresses: HashMap::new(),
            virtual_ports: vec![0; 65_536],
            trace_enabled: false,
            random_fields: HashMap::new(),
            on_error_goto: None,
            error_handler_active: false,
            last_err_code: 0,
            last_err_line: 0,
            resume_pc: None,
            resume_loop_depth: 0,
            timer_trap: TimerEventTrap::default(),
            collision_trap: CollisionEventTrap::default(),
            key_trap: KeyEventTrap::default(),
            com_traps: HashMap::new(),
            pen_trap: EdgeEventTrap::default(),
            strig_trap: EdgeEventTrap::default(),
        })
    }

    /// Open a SoundFont as backend hardware. The reserved `soundfont/` prefix
    /// targets the root-level hardware directory; other paths retain ordinary
    /// BASIC sandbox semantics for user-supplied banks.
    fn open_soundfont_asset(&self, path: &str) -> Result<std::io::BufReader<std::fs::File>, Error> {
        if let (Some(files), Some(relative)) = (
            self.soundfont_files.as_ref(),
            backend_soundfont_relative(path),
        ) {
            return files.open_asset_with_limit(
                relative.to_str().ok_or(Error::InvalidFilePath)?,
                MAX_SOUNDFONT_BYTES,
            );
        }
        self.assets.open_asset_with_limit(path, MAX_SOUNDFONT_BYTES)
    }

    fn resolve_soundfont_asset(&self, path: &str) -> Result<PathBuf, Error> {
        if let (Some(files), Some(relative)) = (
            self.soundfont_files.as_ref(),
            backend_soundfont_relative(path),
        ) {
            return files.resolve(relative.to_str().ok_or(Error::InvalidFilePath)?, true);
        }
        self.assets.resolve(path, true)
    }

    fn execute_direct<R: BufRead + ?Sized, W: Write>(
        &mut self,
        source: &str,
        input: &mut R,
        writer: &mut W,
    ) -> Result<ExecutionOutcome, Error> {
        let tokens = tokenize(source)?;
        let statements = split_line_statements(0, &tokens);
        let direct_definitions = validate_control_structures(&statements)?;
        let (stored_statements, _) = build_statements(&self.current_program);
        self.structured_definitions = validate_control_structures(&stored_statements)?;
        const DIRECT_PC_BASE: usize = usize::MAX / 2;

        let mut index = 0usize;
        while index < statements.len() {
            self.check_step_limit()?;
            self.steps = self.steps.saturating_add(1);
            let direct_pc = DIRECT_PC_BASE.saturating_add(index);
            let prior_direct = self.executing_direct;
            self.executing_direct = true;
            let result = self.execute_statement(&statements[index], direct_pc, input, writer);
            self.executing_direct = prior_direct;
            let control = result?;
            match control {
                Control::Advance => index += 1,
                Control::SkipIfFalse => {
                    index = if is_block_if(&statements[index]) {
                        block_if_false_target(&statements, index)?
                    } else {
                        inline_else_after(&statements, index)
                            .map_or(statements.len(), |else_pc| else_pc + 1)
                    };
                }
                Control::SkipElse => {
                    index = if is_inline_else(&statements, index) {
                        statements.len()
                    } else {
                        matching_block_if_end(&statements, index)? + 1
                    };
                }
                Control::SkipWhile => {
                    index = matching_wend(&statements, index)? + 1;
                }
                Control::SkipDo => {
                    index = matching_loop(&statements, index)? + 1;
                }
                Control::Select(selector) => {
                    index =
                        self.select_case_target(&statements, index, &selector, input, writer)?;
                }
                Control::SkipCase => {
                    index = matching_select_end(&statements, index)? + 1;
                }
                Control::ExitLoop(kind) => {
                    index = matching_loop_exit(&statements, index, kind)? + 1;
                }
                Control::SkipSub => {
                    let (name, _) = parse_sub_header(&statements[index])?;
                    index = direct_definitions
                        .subs
                        .get(&name)
                        .ok_or_else(|| Error::syntax(format!("undefined SUB {name}")))?
                        .end_pc
                        + 1;
                }
                Control::SkipFunction => {
                    let (name, _) = parse_function_header(&statements[index])?;
                    index = direct_definitions
                        .functions
                        .get(&name)
                        .ok_or_else(|| Error::syntax(format!("undefined FUNCTION {name}")))?
                        .end_pc
                        + 1;
                }
                Control::SkipType => {
                    let name = parse_type_header(&statements[index])?;
                    index = direct_definitions
                        .types
                        .get(&name)
                        .ok_or_else(|| Error::syntax(format!("undefined TYPE {name}")))?
                        .end_pc
                        + 1;
                }
                Control::CallSub { name, arguments } => {
                    let definition = self
                        .structured_definitions
                        .subs
                        .get(&name)
                        .cloned()
                        .ok_or_else(|| Error::syntax(format!("undefined SUB {name}")))?;
                    self.enter_sub(
                        &definition,
                        arguments,
                        DIRECT_PC_BASE.saturating_add(index + 1),
                    )?;
                    let outcome = self.execute(
                        input,
                        writer,
                        ExecutionEntry::Resume(definition.start_pc + 1),
                        false,
                    )?;
                    if outcome.termination != RunTermination::Exhausted {
                        return Ok(outcome);
                    }
                    index += 1;
                }
                Control::ReturnSub | Control::ReturnFunction => {
                    return Err(Error::syntax(
                        "structured return requires an active stored-program call",
                    ));
                }
                Control::Goto(target) | Control::Gosub(target) => {
                    return self.execute(input, writer, ExecutionEntry::DirectGoto(target), false);
                }
                Control::Restart(Some(target)) => {
                    return self.execute(
                        input,
                        writer,
                        ExecutionEntry::Rebuild(Some(target)),
                        false,
                    );
                }
                Control::Restart(None) => {
                    return self.execute(input, writer, ExecutionEntry::Rebuild(None), false);
                }
                Control::Resume { pc, loop_depth } => {
                    self.loop_stack.truncate(loop_depth);
                    let Some(local_pc) = pc.checked_sub(DIRECT_PC_BASE) else {
                        return Ok(ExecutionOutcome {
                            termination: RunTermination::Exhausted,
                            resume_pc: None,
                        });
                    };
                    if local_pc >= statements.len() {
                        return Ok(ExecutionOutcome {
                            termination: RunTermination::Exhausted,
                            resume_pc: None,
                        });
                    }
                    index = local_pc;
                }
                Control::Terminate(reason) => {
                    return Ok(ExecutionOutcome {
                        termination: reason,
                        resume_pc: None,
                    });
                }
            }
        }

        Ok(ExecutionOutcome {
            termination: RunTermination::Exhausted,
            resume_pc: None,
        })
    }

    fn execute<R: BufRead + ?Sized, W: Write>(
        &mut self,
        input: &mut R,
        writer: &mut W,
        mut entry: ExecutionEntry,
        single_step: bool,
    ) -> Result<ExecutionOutcome, Error> {
        let mut stepped = false;
        'programs: loop {
            let (statements, line_first) = build_statements(&self.current_program);
            let definitions = validate_control_structures(&statements)?;
            self.structured_definitions = definitions.clone();
            let mut pc = match entry {
                ExecutionEntry::Rebuild(start_line) => {
                    self.default_types = [VariableType::Numeric; 26];
                    self.vars.remove("__DEF_TYPES$");
                    self.data_cursor =
                        DataCursor::from_program(&self.current_program, self.max_data_items)?;
                    if statements.is_empty() {
                        if let Some(target) = start_line {
                            return Err(Error::LineNotFound(target));
                        }
                        return Ok(ExecutionOutcome {
                            termination: RunTermination::Exhausted,
                            resume_pc: None,
                        });
                    }
                    if let Some(target) = start_line {
                        let target_pc =
                            *line_first.get(&target).ok_or(Error::LineNotFound(target))?;
                        if structured_declaration_at_pc(&definitions, target_pc).is_some() {
                            return Err(Error::syntax(
                                "RUN/GOTO cannot enter a structured SUB/FUNCTION/TYPE declaration",
                            ));
                        }
                        target_pc
                    } else {
                        0
                    }
                }
                ExecutionEntry::DirectGoto(target) => {
                    if statements.is_empty() {
                        return Err(Error::LineNotFound(target));
                    }
                    *line_first.get(&target).ok_or(Error::LineNotFound(target))?
                }
                ExecutionEntry::Resume(pc) => {
                    if pc >= statements.len() {
                        return Ok(ExecutionOutcome {
                            termination: RunTermination::Exhausted,
                            resume_pc: None,
                        });
                    }
                    pc
                }
                ExecutionEntry::Function(pc) => {
                    if pc >= statements.len() {
                        return Err(Error::syntax("FUNCTION body is outside the program"));
                    }
                    pc
                }
            };
            loop {
                if single_step && stepped {
                    return Ok(ExecutionOutcome {
                        termination: RunTermination::Step,
                        resume_pc: Some(pc),
                    });
                }
                match self.pending_event() {
                    Ok(Some((event, target))) => {
                        let target_pc =
                            *line_first.get(&target).ok_or(Error::LineNotFound(target))?;
                        Self::validate_procedure_branch(&definitions, pc, target_pc, true)?;
                        self.begin_event(event, pc)?;
                        pc = target_pc;
                        continue;
                    }
                    Ok(None) => {}
                    Err(error) => {
                        let line_number = statements[pc].line_number;
                        pc = self.trap_runtime_error(error, line_number, pc, &line_first)?;
                        continue;
                    }
                }
                self.check_step_limit()?;
                self.steps = self.steps.saturating_add(1);

                let stmt = &statements[pc];
                let line_number = stmt.line_number;
                if self.trace_enabled {
                    self.write_terminal_line(writer, &format!("[{line_number}]"))?;
                }
                let execution = self.execute_statement(stmt, pc, input, writer);
                stepped = true;
                let next = match execution {
                    Ok(c) => c,
                    Err(e) => {
                        pc = self.trap_runtime_error(e, line_number, pc, &line_first)?;
                        continue;
                    }
                };

                match next {
                    Control::Advance => {
                        pc += 1;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::Goto(target) => {
                        let target_pc =
                            *line_first.get(&target).ok_or(Error::LineNotFound(target))?;
                        Self::validate_procedure_branch(&definitions, pc, target_pc, false)?;
                        pc = target_pc;
                    }
                    Control::Gosub(target) => {
                        let target_pc =
                            *line_first.get(&target).ok_or(Error::LineNotFound(target))?;
                        Self::validate_procedure_branch(&definitions, pc, target_pc, true)?;
                        pc = target_pc;
                    }
                    Control::Resume {
                        pc: new_pc,
                        loop_depth,
                    } => {
                        self.loop_stack.truncate(loop_depth);
                        pc = new_pc;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::SkipIfFalse => {
                        pc = if is_block_if(&statements[pc]) {
                            block_if_false_target(&statements, pc)?
                        } else {
                            inline_else_after(&statements, pc).map_or_else(
                                || first_statement_after_line(&statements, pc),
                                |else_pc| else_pc + 1,
                            )
                        };
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::SkipElse => {
                        pc = if is_inline_else(&statements, pc) {
                            first_statement_after_line(&statements, pc)
                        } else {
                            matching_block_if_end(&statements, pc)? + 1
                        };
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::SkipWhile => {
                        pc = matching_wend(&statements, pc)? + 1;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::SkipDo => {
                        pc = matching_loop(&statements, pc)? + 1;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::Select(selector) => {
                        pc = self.select_case_target(&statements, pc, &selector, input, writer)?;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::SkipCase => {
                        pc = matching_select_end(&statements, pc)? + 1;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::ExitLoop(kind) => {
                        pc = matching_loop_exit(&statements, pc, kind)? + 1;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::SkipSub => {
                        let (name, _) = parse_sub_header(&statements[pc])?;
                        pc = definitions
                            .subs
                            .get(&name)
                            .ok_or_else(|| Error::syntax(format!("undefined SUB {name}")))?
                            .end_pc
                            + 1;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::SkipFunction => {
                        let (name, _) = parse_function_header(&statements[pc])?;
                        pc = definitions
                            .functions
                            .get(&name)
                            .ok_or_else(|| Error::syntax(format!("undefined FUNCTION {name}")))?
                            .end_pc
                            + 1;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::SkipType => {
                        let name = parse_type_header(&statements[pc])?;
                        pc = definitions
                            .types
                            .get(&name)
                            .ok_or_else(|| Error::syntax(format!("undefined TYPE {name}")))?
                            .end_pc
                            + 1;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::CallSub { name, arguments } => {
                        let Some(definition) = definitions.subs.get(&name) else {
                            pc = self.trap_runtime_error(
                                Error::syntax(format!("undefined SUB {name}")),
                                line_number,
                                pc,
                                &line_first,
                            )?;
                            continue;
                        };
                        if let Err(error) = self.enter_sub(definition, arguments, pc + 1) {
                            pc = self.trap_runtime_error(error, line_number, pc, &line_first)?;
                            continue;
                        }
                        pc = definition.start_pc + 1;
                    }
                    Control::ReturnSub => {
                        let (return_pc, loop_depth) = self.leave_sub()?;
                        self.loop_stack.truncate(loop_depth);
                        pc = return_pc;
                        if pc >= statements.len() {
                            return Ok(ExecutionOutcome {
                                termination: RunTermination::Exhausted,
                                resume_pc: None,
                            });
                        }
                    }
                    Control::ReturnFunction => {
                        self.function_result = Some(self.leave_function()?);
                        return Ok(ExecutionOutcome {
                            termination: RunTermination::Exhausted,
                            resume_pc: None,
                        });
                    }
                    Control::Restart(target) => {
                        entry = ExecutionEntry::Rebuild(target);
                        continue 'programs;
                    }
                    Control::Terminate(reason) => {
                        return Ok(ExecutionOutcome {
                            termination: reason,
                            resume_pc: (reason == RunTermination::Stop).then_some(pc + 1),
                        });
                    }
                }
            }
        }
    }

    fn check_step_limit(&self) -> Result<(), Error> {
        if take_interrupt() {
            return Err(Error::Break);
        }
        if self.max_steps != UNLIMITED_STEPS && self.steps >= self.max_steps {
            return Err(Error::StepLimitExceeded {
                limit: self.max_steps,
            });
        }
        Ok(())
    }

    fn trap_runtime_error(
        &mut self,
        error: Error,
        line_number: u64,
        pc: usize,
        line_first: &BTreeMap<u64, usize>,
    ) -> Result<usize, Error> {
        self.release_screen_locks();
        let Some(target) = self.on_error_goto.filter(|_| !self.error_handler_active) else {
            return Err(error);
        };
        self.last_err_code = error_code(&error);
        self.last_err_line = line_number;
        self.vars
            .insert("ERR".to_string(), Value::Integer(self.last_err_code));
        self.vars
            .insert("ERL".to_string(), Value::Integer(line_number as i64));
        self.error_handler_active = true;
        self.resume_pc = Some(pc);
        self.resume_loop_depth = self.loop_stack.len();
        line_first
            .get(&target)
            .copied()
            .ok_or(Error::LineNotFound(target))
    }

    fn validate_procedure_branch(
        definitions: &StructuredDefinitions,
        source_pc: usize,
        target_pc: usize,
        gosub: bool,
    ) -> Result<(), Error> {
        let source = structured_declaration_at_pc(definitions, source_pc);
        let target = structured_declaration_at_pc(definitions, target_pc);
        match (source, target) {
            (None, None) => Ok(()),
            (None, Some(_)) => Err(Error::syntax(
                "GOTO/GOSUB cannot enter a structured SUB/FUNCTION/TYPE declaration",
            )),
            (Some(active), Some(target)) if active == target => Ok(()),
            (Some(_), None) if gosub => Ok(()),
            (Some(_), _) => Err(Error::syntax(
                "GOTO cannot leave its SUB/FUNCTION and GOSUB cannot enter another procedure body",
            )),
        }
    }

    fn execute_statement<R: BufRead + ?Sized, W: Write>(
        &mut self,
        stmt: &Statement,
        pc: usize,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        let result = self.execute_statement_inner(stmt, pc, input, writer);
        if result.is_ok() {
            self.present_dirty_graphics_scene();
        }
        result
    }

    fn execute_statement_inner<R: BufRead + ?Sized, W: Write>(
        &mut self,
        stmt: &Statement,
        pc: usize,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        let line_number = stmt.line_number;
        let resolved_body;
        let contains_input_call = stmt.body.windows(2).any(|tokens| {
            matches!(tokens, [TokenInstance::Ident(name), TokenInstance::LParen] if name == "INPUT$")
        });
        let body = if (self.structured_definitions.functions.is_empty() && !contains_input_call)
            || is_function_start(stmt)
            || is_sub_start(stmt)
            || is_type_start(stmt)
            || matches!(stmt.body.first(), Some(TokenInstance::Ident(name)) if name == "DECLARE")
            || is_case_branch(stmt)
            || matches!(
                stmt.body.first(),
                Some(TokenInstance::Keyword(
                    Token::Call | Token::If | Token::While
                ))
            )
            || matches!(
                stmt.body.as_slice(),
                [
                    TokenInstance::Keyword(Token::Def),
                    TokenInstance::Keyword(Token::Fn),
                    ..
                ]
            )
            || matches!(stmt.body.first(), Some(TokenInstance::Ident(name)) if matches!(name.as_str(), "DO" | "LOOP" | "UNTIL"))
        {
            &stmt.body
        } else {
            resolved_body = self.resolve_function_calls(&stmt.body, input, writer)?;
            &resolved_body
        };

        if body.is_empty() {
            return Ok(Control::Advance);
        }

        // Identifier-encoded extension statements are not reserved words in
        // assignment position. Resolve every `name = expression` before any
        // command-specific validation so adding a command cannot make an
        // existing variable (COMPILE, LOADB, LPRINT, STRIG, PEN, and so on)
        // unusable, including inside a structured FUNCTION.
        if let [TokenInstance::Ident(name), TokenInstance::Keyword(Token::Equal), rest @ ..] =
            body.as_slice()
        {
            if matches!(name.as_str(), "DATE$" | "TIME$") {
                return self
                    .execute_clock_assignment(name, rest)
                    .map_err(|error| annotate(line_number, error));
            }
            self.execute_value_assignment(body)
                .map_err(|error| annotate(line_number, error))?;
            return Ok(Control::Advance);
        }

        if matches!(
            self.procedure_stack.last(),
            Some(frame) if frame.kind == StructuredKind::Function
        ) && !is_function_end(stmt)
            && (matches!(
                body.first(),
                Some(TokenInstance::Keyword(
                    Token::End | Token::Stop | Token::List | Token::New | Token::Run | Token::Load
                ))
            ) || matches!(body.first(), Some(TokenInstance::Ident(name)) if matches!(name.as_str(), "CHAIN" | "MERGE" | "LOADB" | "SAVEB" | "COMPILE")))
        {
            return Err(annotate(
                line_number,
                Error::syntax("program-state command is not allowed inside FUNCTION"),
            ));
        }

        if body
            .iter()
            .any(|token| matches!(token, TokenInstance::StoreArrow))
        {
            return self
                .execute_ti_store(body)
                .map_err(|error| annotate(line_number, error));
        }

        match &body[0] {
            TokenInstance::Rem(_) => Ok(Control::Advance),
            TokenInstance::Ident(name) if matches!(name.as_str(), "ENDIF" | "IFEND") => {
                expect_end_of_line(&body[1..]).map_err(|e| annotate(line_number, e))?;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::End)
                if matches!(body.get(1), Some(TokenInstance::Keyword(Token::If))) =>
            {
                expect_end_of_line(&body[2..]).map_err(|e| annotate(line_number, e))?;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::If)
                if matches!(body.get(1), Some(TokenInstance::Keyword(Token::End))) =>
            {
                expect_end_of_line(&body[2..]).map_err(|e| annotate(line_number, e))?;
                Ok(Control::Advance)
            }
            _ if is_select_end(stmt) => Ok(Control::Advance),
            TokenInstance::Ident(name) if name == "SELECT" || is_bbc_case_start(stmt) => self
                .execute_select(body)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if matches!(name.as_str(), "CASE" | "WHEN") => {
                if body.len() == 1 {
                    return Err(annotate(
                        line_number,
                        Error::syntax("CASE/WHEN requires a value or ELSE"),
                    ));
                }
                Ok(Control::SkipCase)
            }
            TokenInstance::Ident(name) if name == "OTHERWISE" => {
                expect_end_of_line(&body[1..]).map_err(|e| annotate(line_number, e))?;
                Ok(Control::SkipCase)
            }
            TokenInstance::Ident(name) if name == "ELSE" => {
                expect_end_of_line(&body[1..]).map_err(|e| annotate(line_number, e))?;
                Ok(Control::SkipElse)
            }
            TokenInstance::Ident(name) if name == "DO" => self
                .execute_do(&body[1..], pc, input, writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "LOOP" => self
                .execute_loop(&body[1..], input, writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "REPEAT" => self
                .execute_repeat(&body[1..], pc)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "UNTIL" => self
                .execute_until(&body[1..], input, writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "EXIT" => {
                if matches!(body.get(1), Some(TokenInstance::Ident(kind)) if kind == "SUB") {
                    expect_end_of_line(&body[2..]).map_err(|e| annotate(line_number, e))?;
                    if !matches!(
                        self.procedure_stack.last(),
                        Some(frame) if frame.kind == StructuredKind::Sub
                    ) {
                        Err(annotate(
                            line_number,
                            Error::syntax("EXIT SUB without active SUB"),
                        ))
                    } else {
                        Ok(Control::ReturnSub)
                    }
                } else if matches!(body.get(1), Some(TokenInstance::Ident(kind)) if kind == "FUNCTION")
                {
                    expect_end_of_line(&body[2..]).map_err(|e| annotate(line_number, e))?;
                    if !matches!(
                        self.procedure_stack.last(),
                        Some(frame) if frame.kind == StructuredKind::Function
                    ) {
                        Err(annotate(
                            line_number,
                            Error::syntax("EXIT FUNCTION without active FUNCTION"),
                        ))
                    } else {
                        Ok(Control::ReturnFunction)
                    }
                } else {
                    self.execute_exit_loop(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                }
            }
            TokenInstance::Ident(name) if name == "SUB" => Ok(Control::SkipSub),
            TokenInstance::Ident(name) if name == "FUNCTION" => Ok(Control::SkipFunction),
            TokenInstance::Ident(name) if name == "TYPE" => Ok(Control::SkipType),
            TokenInstance::Ident(name) if name == "DECLARE" => Ok(Control::Advance),
            TokenInstance::Ident(name) if name == "SHARED" => {
                if self.procedure_stack.is_empty() {
                    Err(annotate(
                        line_number,
                        Error::syntax(format!("{name} is only valid inside SUB or FUNCTION")),
                    ))
                } else {
                    Ok(Control::Advance)
                }
            }
            TokenInstance::Ident(name) if name == "STATIC" => {
                if self.procedure_stack.is_empty() {
                    Err(annotate(
                        line_number,
                        Error::syntax("STATIC is only valid inside SUB or FUNCTION"),
                    ))
                } else {
                    self.execute_static_arrays(&body[1..])
                        .map_err(|error| annotate(line_number, error))
                }
            }
            TokenInstance::Ident(name) if name == "LOCATE" => self
                .execute_locate(&body[1..])
                .map_err(|error| annotate(line_number, error)),
            TokenInstance::Ident(name) if name == "VIEW" => {
                if matches!(body.get(1), Some(TokenInstance::Keyword(Token::Print))) {
                    self.execute_view_print(&body[2..])
                        .map_err(|error| annotate(line_number, error))
                } else {
                    self.execute_graphics_view(&body[1..])
                        .map_err(|error| annotate(line_number, error))
                }
            }
            TokenInstance::Ident(name) if name == "WINDOW" => self
                .execute_graphics_window(&body[1..])
                .map_err(|error| annotate(line_number, error)),
            TokenInstance::Ident(name) if name == "PCOPY" => self
                .execute_pcopy(&body[1..])
                .map_err(|error| annotate(line_number, error)),
            TokenInstance::Ident(name) if name == "HOME" => {
                expect_end_of_line(&body[1..]).map_err(|error| annotate(line_number, error))?;
                emit_screen_event(ScreenEvent::ClearText);
                self.set_text_cursor(self.view_print_top, 1, self.text_cursor_visible);
                Ok(Control::Advance)
            }
            TokenInstance::Ident(name) if name == "HTAB" => self
                .execute_text_tab(&body[1..], false)
                .map_err(|error| annotate(line_number, error)),
            TokenInstance::Ident(name) if name == "VTAB" => self
                .execute_text_tab(&body[1..], true)
                .map_err(|error| annotate(line_number, error)),
            TokenInstance::Ident(name) if name == "SLEEP" => self
                .execute_sleep(&body[1..])
                .map_err(|error| annotate(line_number, error)),
            TokenInstance::Ident(name) if name == "TEXTCOLOR" => self
                .execute_text_color(&body[1..])
                .map_err(|error| annotate(line_number, error)),
            TokenInstance::Keyword(Token::End) if matches!(body.get(1), Some(TokenInstance::Ident(name)) if name == "SUB") =>
            {
                expect_end_of_line(&body[2..]).map_err(|e| annotate(line_number, e))?;
                if !matches!(
                    self.procedure_stack.last(),
                    Some(frame) if frame.kind == StructuredKind::Sub
                ) {
                    Err(annotate(
                        line_number,
                        Error::syntax("END SUB without active SUB"),
                    ))
                } else {
                    Ok(Control::ReturnSub)
                }
            }
            TokenInstance::Keyword(Token::End) if matches!(body.get(1), Some(TokenInstance::Ident(name)) if name == "FUNCTION") =>
            {
                expect_end_of_line(&body[2..]).map_err(|e| annotate(line_number, e))?;
                if !matches!(
                    self.procedure_stack.last(),
                    Some(frame) if frame.kind == StructuredKind::Function
                ) {
                    Err(annotate(
                        line_number,
                        Error::syntax("END FUNCTION without active FUNCTION"),
                    ))
                } else {
                    Ok(Control::ReturnFunction)
                }
            }
            TokenInstance::Keyword(Token::End) => {
                expect_end_of_line(&body[1..]).map_err(|e| annotate(line_number, e))?;
                self.release_screen_locks();
                if let Some(video) = self.video.take() {
                    video.finish().map_err(|e| annotate(line_number, e))?;
                }
                self.play_queued_audio()?;
                self.playback.wait()?;
                self.close_device_handles();
                Ok(Control::Terminate(RunTermination::End))
            }
            TokenInstance::Keyword(Token::Stop) => {
                expect_end_of_line(&body[1..]).map_err(|e| annotate(line_number, e))?;
                self.release_screen_locks();
                if let Some(video) = self.video.take() {
                    video.finish().map_err(|e| annotate(line_number, e))?;
                }
                self.play_queued_audio()?;
                self.playback.wait()?;
                self.close_device_handles();
                Ok(Control::Terminate(RunTermination::Stop))
            }
            TokenInstance::Keyword(Token::Let) => {
                self.execute_value_assignment(&body[1..])
                    .map_err(|e| annotate(line_number, e))?;
                Ok(Control::Advance)
            }
            // MID$ statement: MID$(A$, start, len) = replacement
            TokenInstance::Keyword(Token::Mid) => self
                .execute_mid_statement(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "CHANGE" => self
                .execute_change(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "REDIM" => self
                .execute_redim(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "CONST" => self
                .execute_const(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "COMMON" => self
                .execute_common(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "CHAIN" => self
                .execute_chain(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "MERGE" => self
                .execute_merge(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "LOADB" => self
                .execute_load_binary(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "SAVEB" => self
                .execute_save_binary(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "COMPILE" => self
                .execute_compile(&body[1..], writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "SEEK" => self
                .execute_seek(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "CHDIR" => self
                .execute_chdir(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "SCREENCONTROL" => self
                .execute_screen_control(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "SCREENLOCK" => {
                expect_end_of_line(&body[1..]).map_err(|e| annotate(line_number, e))?;
                self.screen_lock_depth = self
                    .screen_lock_depth
                    .checked_add(1)
                    .ok_or_else(|| annotate(line_number, Error::IllegalQuantity))?;
                Ok(Control::Advance)
            }
            TokenInstance::Ident(name) if name == "SCREENUNLOCK" => {
                expect_end_of_line(&body[1..]).map_err(|e| annotate(line_number, e))?;
                if self.screen_lock_depth == 0 {
                    Err(annotate(
                        line_number,
                        Error::syntax("SCREENUNLOCK without SCREENLOCK"),
                    ))
                } else {
                    self.screen_lock_depth -= 1;
                    if self.screen_lock_depth == 0 {
                        self.flush_screen_lock();
                    }
                    Ok(Control::Advance)
                }
            }
            TokenInstance::Ident(name) if name == "ONERR" => {
                let mut alias = Vec::with_capacity(body.len());
                alias.push(TokenInstance::Ident("ERR".to_string()));
                alias.extend_from_slice(&body[1..]);
                self.execute_on(&alias, pc + 1)
                    .map_err(|e| annotate(line_number, e))
            }
            TokenInstance::Ident(name)
                if matches!(name.as_str(), "LOCK" | "UNLOCK")
                    && matches!(body.get(1), Some(TokenInstance::Hash)) =>
            {
                self.execute_file_lock(name == "UNLOCK", &body[1..])
                    .map_err(|e| annotate(line_number, e))
            }
            TokenInstance::Ident(name) if name == "WEB" => self
                .execute_web_statement(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "ENVIRON" => self
                .execute_environ(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name)
                if name == "COM" && !matches!(body.get(1), Some(TokenInstance::LParen)) =>
            {
                self.execute_com_open(&body[1..])
                    .map_err(|e| annotate(line_number, e))
            }
            TokenInstance::Ident(name)
                if matches!(name.as_str(), "TIMER" | "COLLISION" | "PEN" | "STRIG")
                    || (matches!(name.as_str(), "KEY" | "COM" | "STRIG")
                        && matches!(body.get(1), Some(TokenInstance::LParen))) =>
            {
                self.execute_event_control(name, &body[1..])
                    .map_err(|e| annotate(line_number, e))
            }
            TokenInstance::Ident(name) if is_graphics_statement(name) => self
                .execute_graphics_statement(name, &body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if is_synth_statement(name) => self
                .execute_synth_statement(name, &body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if name == "GRAPH" => self
                .execute_graph_statement(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(name) if is_ti_graph_statement(name) => self
                .execute_ti_graph_statement(name, &body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Ident(_) => {
                self.execute_value_assignment(body)
                    .map_err(|e| annotate(line_number, e))?;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::Print) => {
                if matches!(body.get(1), Some(TokenInstance::Hash)) {
                    self.execute_print_file(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                } else if matches!(body.get(1), Some(TokenInstance::Keyword(Token::Using))) {
                    self.execute_print_using(&body[2..], writer)
                        .map_err(|e| annotate(line_number, e))?;
                    Ok(Control::Advance)
                } else {
                    self.execute_print(&body[1..], writer)
                        .map_err(|e| annotate(line_number, e))?;
                    Ok(Control::Advance)
                }
            }
            TokenInstance::Keyword(Token::Mat) => self
                .execute_mat(&body[1..], line_number, input, writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::List) => self
                .execute_list(&body[1..], writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::New) => self
                .execute_new(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Run) => self
                .execute_run(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Cont) => self
                .execute_cont(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::PrintFile) => self
                .execute_print_file(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Open) => self
                .execute_open(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Close) => self
                .execute_close(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Load) => self
                .execute_load(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Save) => self
                .execute_save(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Verify) => self
                .execute_verify(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Wait) => self
                .execute_wait(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Poke) => {
                let arguments = split_graph_arguments(&body[1..])?;
                if arguments.len() != 2 {
                    return Err(Error::syntax("POKE expects address, value"));
                }
                let address = self.evaluate_integer(arguments[0])?;
                let value = self.evaluate_integer(arguments[1])?;
                if !(0..=65_535).contains(&address) || !(0..=255).contains(&value) {
                    return Err(Error::IllegalQuantity);
                }
                let physical = self
                    .memory_segment
                    .saturating_mul(16)
                    .saturating_add(address as usize);
                let byte = self
                    .virtual_memory
                    .get_mut(physical)
                    .ok_or(Error::IllegalQuantity)?;
                *byte = value as u8;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::Cmd) => self
                .execute_cmd(&body[1..], writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Sys) => self
                .execute_system_call(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Goto) => {
                let target = parse_line_number(&body[1..]).map_err(|e| annotate(line_number, e))?;
                Ok(Control::Goto(target))
            }
            TokenInstance::Keyword(Token::Go) => self
                .execute_go(&body[1..], pc + 1)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::If) => self
                .execute_if(&body[1..], line_number, pc, input, writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::On) => self
                .execute_on(&body[1..], pc + 1)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Gosub) => self
                .execute_gosub(&body[1..], pc + 1)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Return) => self
                .execute_return(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::For) => self
                .execute_for(&body[1..], pc, pc + 1)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Next) => self
                .execute_next(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Dim) => self
                .execute_dim(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Def) => {
                // DEF FN is the function definition. DEF SEG, DEF USR,
                // DEFINT/DEFSNG/DEFDBL/DEFSTR are type declarations.
                if matches!(body.get(1), Some(TokenInstance::Keyword(Token::Fn))) {
                    self.execute_def(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                } else if matches!(body.get(1), Some(TokenInstance::Ident(s)) if s == "SEG") {
                    let mut rest = &body[2..];
                    if matches!(rest.first(), Some(TokenInstance::Keyword(Token::Equal))) {
                        rest = &rest[1..];
                    }
                    self.memory_segment = if rest.is_empty() {
                        0
                    } else {
                        let segment = self.evaluate_integer(rest)?;
                        if !(0..=65_535).contains(&segment) {
                            return Err(Error::IllegalQuantity);
                        }
                        segment as usize
                    };
                    Ok(Control::Advance)
                } else if matches!(body.get(1), Some(TokenInstance::Keyword(Token::Usr)))
                    || matches!(body.get(1), Some(TokenInstance::Ident(s)) if s.starts_with("USR"))
                {
                    self.execute_def_usr(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                } else if matches!(body.get(1), Some(TokenInstance::Keyword(Token::Int))) {
                    self.execute_default_type(&body[2..], VariableType::Integer)
                        .map_err(|e| annotate(line_number, e))
                } else if matches!(body.get(1), Some(TokenInstance::Keyword(Token::Str))) {
                    self.execute_default_type(&body[2..], VariableType::String)
                        .map_err(|e| annotate(line_number, e))
                } else if let Some(TokenInstance::Ident(kind)) = body.get(1) {
                    let declaration_type = match kind.as_str() {
                        "INT" => Some(VariableType::Integer),
                        "SNG" => Some(VariableType::Single),
                        "DBL" => Some(VariableType::Double),
                        "STR" => Some(VariableType::String),
                        _ => None,
                    };
                    if let Some(declaration_type) = declaration_type {
                        self.execute_default_type(&body[2..], declaration_type)
                            .map_err(|e| annotate(line_number, e))
                    } else if let Some(declaration_type) = [
                        ("INT", VariableType::Integer),
                        ("SNG", VariableType::Single),
                        ("DBL", VariableType::Double),
                        ("STR", VariableType::String),
                    ]
                    .iter()
                    .find_map(|(prefix, declaration_type)| {
                        kind.strip_prefix(prefix)
                            .filter(|suffix| !suffix.is_empty())
                            .map(|suffix| (*declaration_type, suffix))
                    }) {
                        self.execute_default_type_text(declaration_type.1, declaration_type.0)
                            .map_err(|e| annotate(line_number, e))
                    } else {
                        self.execute_def(&body[1..])
                            .map_err(|e| annotate(line_number, e))
                    }
                } else {
                    // Fall through to execute_def which will report the proper error
                    self.execute_def(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                }
            }
            TokenInstance::Keyword(Token::Data) => Ok(Control::Advance),
            TokenInstance::Keyword(Token::Read) => self
                .execute_read(&body[1..], line_number)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::LineInput) => {
                if matches!(body.get(1), Some(TokenInstance::Hash)) {
                    self.execute_line_input_file(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                } else {
                    self.execute_line_input(&body[1..], line_number, input, writer)
                        .map_err(|e| annotate(line_number, e))
                }
            }
            TokenInstance::Keyword(Token::Input) => {
                if matches!(body.get(1), Some(TokenInstance::Hash)) {
                    self.execute_input_file(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                } else {
                    self.execute_input(&body[1..], line_number, input, writer)
                        .map_err(|e| annotate(line_number, e))
                }
            }
            TokenInstance::Keyword(Token::InputFile) => self
                .execute_input_file(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Get) => {
                if matches!(body.get(1), Some(TokenInstance::Hash)) {
                    self.execute_get_file(&body[1..], line_number)
                        .map_err(|e| annotate(line_number, e))
                } else if starts_graphics_get(&body[1..]) {
                    self.execute_graphics_get(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                } else {
                    self.execute_get(&body[1..], line_number, input)
                        .map_err(|e| annotate(line_number, e))
                }
            }
            TokenInstance::Keyword(Token::GetFile) => self
                .execute_get_file(&body[1..], line_number)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Restore) => self
                .execute_restore(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Clear) => self
                .execute_clear(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            // MS-BASIC extension statements
            TokenInstance::Keyword(Token::While) => self
                .execute_while(&body[1..], pc, input, writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Wend) => {
                self.execute_wend().map_err(|e| annotate(line_number, e))
            }
            TokenInstance::Keyword(Token::Swap) => self
                .execute_swap(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::WriteStmt) => {
                if matches!(body.get(1), Some(TokenInstance::Hash)) {
                    self.execute_write_file(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                } else {
                    self.execute_write(&body[1..], writer)
                        .map_err(|e| annotate(line_number, e))
                }
            }
            TokenInstance::Keyword(Token::Randomize) => self
                .execute_randomize(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::OptionBase) => {
                // OPTION BASE 0|1 -- "BASE" is an identifier, skip it
                let rest = if matches!(body.get(1), Some(TokenInstance::Ident(s)) if s == "BASE") {
                    &body[2..]
                } else {
                    &body[1..]
                };
                self.execute_option_base(rest)
                    .map_err(|e| annotate(line_number, e))
            }
            TokenInstance::Keyword(Token::Width) => {
                let width = self.evaluate_integer(&body[1..])?;
                if !(1..=255).contains(&width) {
                    return Err(Error::IllegalQuantity);
                }
                self.output_width = Some(width as usize);
                self.output_column %= width as usize;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::Kill) => self
                .execute_kill(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Name) => self
                .execute_name(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Tron) => {
                self.trace_enabled = true;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::Troff) => {
                self.trace_enabled = false;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::Erase) => self
                .execute_erase(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Lprint) => {
                self.execute_lprint(&body[1..])
                    .map_err(|e| annotate(line_number, e))?;
                Ok(Control::Advance)
            }
            // Additional MS-BASIC statements (accept and handle)
            TokenInstance::Keyword(Token::Auto) => {
                Err(Error::syntax("AUTO is a READY-only command"))
            }
            TokenInstance::Keyword(Token::Call) => self
                .execute_call(&body[1..], input, writer)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Delete) => {
                Err(Error::syntax("DELETE is a READY-only command"))
            }
            TokenInstance::Keyword(Token::Edit) => {
                Err(Error::syntax("EDIT is a READY-only command"))
            }
            TokenInstance::Keyword(Token::Renum) => {
                Err(Error::syntax("RENUM is a READY-only command"))
            }
            TokenInstance::Keyword(Token::Llist) => {
                // LLIST — list to printer. Same as LIST to stdout.
                self.execute_list(&body[1..], writer)
                    .map_err(|e| annotate(line_number, e))?;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::Null) => {
                let padding = self.evaluate_integer(&body[1..])?;
                if !(0..=255).contains(&padding) {
                    return Err(Error::IllegalQuantity);
                }
                self.null_padding = padding as usize;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::Out) => {
                let arguments = split_graph_arguments(&body[1..])?;
                if arguments.len() != 2 {
                    return Err(Error::syntax("OUT expects port, value"));
                }
                let port = self.evaluate_integer(arguments[0])?;
                let value = self.evaluate_integer(arguments[1])?;
                if !(0..=65_535).contains(&port) || !(0..=255).contains(&value) {
                    return Err(Error::IllegalQuantity);
                }
                self.virtual_ports[port as usize] = value as u8;
                Ok(Control::Advance)
            }
            TokenInstance::Keyword(Token::Put) => {
                if starts_graphics_point(&body[1..]) {
                    self.execute_graphics_put(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                } else {
                    self.execute_put_random(&body[1..])
                        .map_err(|e| annotate(line_number, e))
                }
            }
            TokenInstance::Keyword(Token::Field) => self
                .execute_field(&body[1..])
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Lset) => self
                .execute_set_fixed_string(&body[1..], false)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::Rset) => self
                .execute_set_fixed_string(&body[1..], true)
                .map_err(|e| annotate(line_number, e)),
            TokenInstance::Keyword(Token::ErrorStmt) => {
                // ERROR n — raise a Microsoft BASIC error for ON ERROR.
                let code = self.evaluate_integer(&body[1..])?;
                if !(1..=255).contains(&code) {
                    return Err(Error::IllegalQuantity);
                }
                Err(Error::UserError { code })
            }
            TokenInstance::Keyword(Token::Resume) => {
                // RESUME [NEXT | line] — leave an active error handler while
                // retaining the configured ON ERROR target for later errors.
                let error_pc = self
                    .resume_pc
                    .take()
                    .ok_or_else(|| Error::syntax("RESUME without active error"))?;
                let loop_depth = self.resume_loop_depth;
                self.error_handler_active = false;
                let is_next = match body.get(1) {
                    Some(TokenInstance::Keyword(Token::Next)) => true,
                    Some(TokenInstance::Ident(s)) if s == "NEXT" => true,
                    _ => false,
                };
                if is_next {
                    Ok(Control::Resume {
                        pc: error_pc.saturating_add(1),
                        loop_depth,
                    })
                } else if !body[1..].is_empty() {
                    // RESUME line: goto that line. RESUME 0 means resume at the
                    // faulting statement (same as plain RESUME), not GOTO line 0.
                    let target =
                        parse_line_number(&body[1..]).map_err(|e| annotate(line_number, e))?;
                    if target == 0 {
                        Ok(Control::Resume {
                            pc: error_pc,
                            loop_depth,
                        })
                    } else {
                        self.loop_stack.truncate(loop_depth);
                        Ok(Control::Goto(target))
                    }
                } else {
                    Ok(Control::Resume {
                        pc: error_pc,
                        loop_depth,
                    })
                }
            }
            _ => Err(Error::syntax(format!(
                "line {line_number}: unsupported statement"
            ))),
        }
    }

    fn execute_ti_store(&mut self, body: &[TokenInstance]) -> Result<Control, Error> {
        let mut arrows = body
            .iter()
            .enumerate()
            .filter(|(_, token)| matches!(token, TokenInstance::StoreArrow));
        let (arrow, _) = arrows
            .next()
            .ok_or_else(|| Error::syntax("TI store arrow required"))?;
        if arrows.next().is_some() || arrow == 0 {
            return Err(Error::syntax("TI store expects expression→variable"));
        }
        let [TokenInstance::Ident(name)] = &body[arrow + 1..] else {
            return Err(Error::syntax("TI store target must be one variable"));
        };
        let value = self.evaluate_value(&body[..arrow])?;
        self.assign(name.clone(), value)?;
        Ok(Control::Advance)
    }

    fn execute_graphics_statement(
        &mut self,
        name: &str,
        rest: &[TokenInstance],
    ) -> Result<Control, Error> {
        match name {
            "SCREEN" => {
                let arguments = split_graph_arguments(rest)?;
                if let [argument] = arguments.as_slice() {
                    if let Some(word) = graphics_mode_word(argument) {
                        match word {
                            "TEXT" => {
                                self.screen_view = ScreenView::Text;
                                emit_screen_event(ScreenEvent::SetView(ScreenView::Text));
                                return Ok(Control::Advance);
                            }
                            "GRAPHICS" => {
                                self.screen_view = ScreenView::Graphics;
                                self.present_graphics_scene(true, ScreenView::Graphics);
                                return Ok(Control::Advance);
                            }
                            "GRAPHICS2D" => {
                                self.graphics.set_graphics_mode(GraphicsMode::TwoD);
                                self.screen_view = ScreenView::Graphics;
                                self.present_graphics_scene(true, ScreenView::Graphics);
                                return Ok(Control::Advance);
                            }
                            "GRAPHICS3D" => {
                                self.graphics.set_graphics_mode(GraphicsMode::Perspective3D);
                                self.screen_view = ScreenView::Graphics;
                                self.present_graphics_scene(true, ScreenView::Graphics);
                                return Ok(Control::Advance);
                            }
                            "SPLIT" => {
                                self.screen_view = ScreenView::Split;
                                self.present_graphics_scene(true, ScreenView::Split);
                                return Ok(Control::Advance);
                            }
                            "STANDARD" => {
                                let (w, h) = (1024i64, 768i64);
                                self.graphics.set_screen(w, h, "#000000")?;
                                self.screen_view = ScreenView::Graphics;
                                emit_screen_event(ScreenEvent::Resize {
                                    width: w as u32,
                                    height: h as u32,
                                });
                                self.present_graphics_scene(false, ScreenView::Graphics);
                                return Ok(Control::Advance);
                            }
                            "HD" => {
                                let (w, h) = (1280i64, 720i64);
                                self.graphics.set_screen(w, h, "#000000")?;
                                self.screen_view = ScreenView::Graphics;
                                emit_screen_event(ScreenEvent::Resize {
                                    width: w as u32,
                                    height: h as u32,
                                });
                                self.present_graphics_scene(false, ScreenView::Graphics);
                                return Ok(Control::Advance);
                            }
                            "MAX" => {
                                let info = crate::screen::display_info();
                                let w = if info.width > 0 {
                                    info.width as i64
                                } else {
                                    1920
                                };
                                let h = if info.height > 0 {
                                    info.height as i64
                                } else {
                                    1080
                                };
                                self.graphics.set_screen(w, h, "#000000")?;
                                self.screen_view = ScreenView::Graphics;
                                emit_screen_event(ScreenEvent::Resize {
                                    width: w as u32,
                                    height: h as u32,
                                });
                                self.present_graphics_scene(false, ScreenView::Graphics);
                                return Ok(Control::Advance);
                            }
                            _ => {}
                        }
                    }
                }
                match arguments.as_slice() {
                    [mode] => {
                        let mode = self.evaluate_integer(mode)?;
                        let (width, height, background) = screen_mode_dimensions(mode)?;
                        self.graphics.set_screen(width, height, background)?;
                        if mode == 0 {
                            self.screen_view = ScreenView::Text;
                            emit_screen_event(ScreenEvent::SetView(ScreenView::Text));
                        } else {
                            self.screen_view = ScreenView::Graphics;
                            emit_screen_event(ScreenEvent::Resize {
                                width: width as u32,
                                height: height as u32,
                            });
                            self.present_graphics_scene(false, ScreenView::Graphics);
                        }
                    }
                    [width, height] | [width, height, _] => {
                        let width = self.evaluate_integer(width)?;
                        let height = self.evaluate_integer(height)?;
                        let background = if let Some(argument) = arguments.get(2) {
                            self.evaluate_graphics_color(argument)?
                        } else {
                            self.graphics.background().to_string()
                        };
                        self.graphics.set_screen(width, height, &background)?;
                        self.screen_view = ScreenView::Graphics;
                        emit_screen_event(ScreenEvent::Resize {
                            width: width as u32,
                            height: height as u32,
                        });
                        self.present_graphics_scene(false, ScreenView::Graphics);
                    }
                    _ => {
                        return Err(Error::syntax(
                            "SCREEN expects TEXT, GRAPHICS, GRAPHICS2D, GRAPHICS3D, SPLIT, a classic mode, or width,height[,background]",
                        ))
                    }
                }
            }
            "CLS" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 0, 1)?;
                let clear_text = arguments.is_empty()
                    && matches!(self.screen_view, ScreenView::Text | ScreenView::Split);
                if clear_text {
                    emit_screen_event(ScreenEvent::ClearText);
                    self.cursor_row = self.view_print_top;
                    self.output_column = 0;
                    emit_screen_event(ScreenEvent::SetTextCursor {
                        row: self.cursor_row,
                        column: 1,
                        visible: self.text_cursor_visible,
                    });
                }
                if self.screen_view != ScreenView::Text || !arguments.is_empty() {
                    let background = arguments
                        .first()
                        .map(|argument| self.evaluate_graphics_color(argument))
                        .transpose()?;
                    self.graphics.clear(background.as_deref())?;
                    let view = if self.screen_view == ScreenView::Text {
                        ScreenView::Graphics
                    } else {
                        self.screen_view
                    };
                    self.screen_view = view;
                    if self.graphics.drawing_is_visible() {
                        self.present_graphics_scene(false, view);
                    }
                }
            }
            "COLOR" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 3)?;
                let foreground = self.evaluate_graphics_color(arguments[0])?;
                self.graphics.set_foreground(&foreground);
                if let Some(argument) = arguments.get(1) {
                    let background = self.evaluate_graphics_color(argument)?;
                    self.graphics.set_background(&background);
                }
                if let Some(argument) = arguments.get(2) {
                    let border = self.evaluate_graphics_color(argument)?;
                    self.graphics.set_border_color(&border);
                    // A visible border is shell-dependent, but every shell is
                    // informed and the device retains the requested color.
                    emit_screen_event(ScreenEvent::SetBorderColor(border));
                }
            }
            "PALETTE" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 2, 2)?;
                let index = self.evaluate_integer(arguments[0])?;
                let color = self.evaluate_graphics_color_literal(arguments[1])?;
                self.graphics.set_palette_color(index, &color)?;
            }
            "PSET" | "PRESET" => {
                let (coordinates, after) = parse_graphics_coordinate(rest, 0)?;
                if !matches!(coordinates.len(), 2 | 3) {
                    return Err(Error::syntax(
                        "PSET/PRESET coordinate requires x,y or x,y,z",
                    ));
                }
                let x = self.evaluate_graph_real(coordinates[0])?;
                let y = self.evaluate_graph_real(coordinates[1])?;
                let tail = graphics_tail_arguments(rest, after)?;
                expect_graph_arity(name, &tail, 0, 1)?;
                let color = if name == "PRESET" {
                    self.graphics.background().to_string()
                } else if let Some(argument) = tail.first() {
                    self.evaluate_graphics_color(argument)?
                } else {
                    self.graphics.foreground().to_string()
                };
                if let Some(z_tokens) = coordinates.get(2) {
                    let z = self.evaluate_graph_real(z_tokens)?;
                    if name == "PRESET" {
                        self.graphics.unset_perspective_pixel(x, y, z)?;
                    } else {
                        self.graphics.set_perspective_pixel(x, y, z, &color)?;
                    }
                } else {
                    self.graphics.scene_mut().pixel(x, y, &color)?;
                    self.graphics.set_cursor(x, y);
                }
            }
            "LINE" => self.execute_microsoft_line(rest)?,
            "BRUSH" => self.execute_brush(rest)?,
            "RECT" | "RECTANGLE" => self.execute_rectangle(name, rest)?,
            "CIRCLE" => self.execute_microsoft_circle(rest)?,
            "ELLIPSE" | "OVAL" => {
                let (x_tokens, y_tokens, after) = parse_graphics_point(rest, 0)?;
                let x = self.evaluate_graph_real(x_tokens)?;
                let y = self.evaluate_graph_real(y_tokens)?;
                let arguments = graphics_tail_arguments(rest, after)?;
                expect_graph_arity(name, &arguments, 2, 5)?;
                let rx = self.evaluate_graph_real(arguments[0])?;
                let ry = self.evaluate_graph_real(arguments[1])?;
                let stroke = if let Some(argument) = arguments.get(2) {
                    self.evaluate_graphics_color(argument)?
                } else {
                    self.graphics.foreground().to_string()
                };
                let fill = if let Some(argument) = arguments.get(3) {
                    self.evaluate_graphics_color_or_none(argument)?
                } else {
                    "none".to_string()
                };
                let width = arguments
                    .get(4)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(1.0);
                self.graphics
                    .scene_mut()
                    .ellipse(x, y, rx, ry, &stroke, &fill, width)?;
            }
            "PAINT" => {
                let extension = rest.first().and_then(token_command_word);
                if extension.is_some_and(|word| word.eq_ignore_ascii_case("TEXTURE")) {
                    let arguments = split_graph_arguments(&rest[1..])?;
                    expect_graph_arity("PAINT TEXTURE", &arguments, 6, 8)?;
                    let path_data = self
                        .evaluate_value(arguments[0])?
                        .into_string()
                        .ok_or(Error::TypeMismatch)?;
                    let seed = self.evaluate_integer(arguments[1])?;
                    let scale = self.evaluate_graph_real(arguments[2])?;
                    let octaves = self.evaluate_integer(arguments[3])?;
                    let color1 = self.evaluate_graphics_color(arguments[4])?;
                    let color2 = self.evaluate_graphics_color(arguments[5])?;
                    let opacity = arguments
                        .get(6)
                        .map(|argument| self.evaluate_graph_real(argument))
                        .transpose()?
                        .unwrap_or(1.0);
                    let blend = arguments
                        .get(7)
                        .map(|argument| {
                            self.evaluate_value(argument)?
                                .into_string()
                                .ok_or(Error::TypeMismatch)
                        })
                        .transpose()?
                        .unwrap_or_else(|| "normal".to_string());
                    self.graphics.scene_mut().paint_texture(
                        &path_data, seed, scale, octaves, &color1, &color2, opacity, &blend,
                    )?;
                } else if extension.is_some_and(|word| word.eq_ignore_ascii_case("FILTER")) {
                    let arguments = split_graph_arguments(&rest[1..])?;
                    if arguments.is_empty() {
                        return Err(Error::syntax("PAINT FILTER requires a mode"));
                    }
                    let mode = self
                        .evaluate_value(arguments[0])?
                        .into_string()
                        .ok_or(Error::TypeMismatch)?;
                    match mode.to_ascii_uppercase().as_str() {
                        "BLUR" | "SHARPEN" => expect_graph_arity("PAINT FILTER", &arguments, 2, 2)?,
                        "COLOR" => expect_graph_arity("PAINT FILTER", &arguments, 4, 4)?,
                        _ => return Err(Error::syntax("unknown PAINT FILTER mode")),
                    }
                    let parameters = arguments[1..]
                        .iter()
                        .map(|argument| self.evaluate_graph_real(argument))
                        .collect::<Result<Vec<_>, _>>()?;
                    self.graphics.scene_mut().paint_filter(&mode, &parameters)?;
                } else {
                    let (x_tokens, y_tokens, after) = parse_graphics_point(rest, 0)?;
                    let x = self.evaluate_graph_real(x_tokens)?;
                    let y = self.evaluate_graph_real(y_tokens)?;
                    let arguments = graphics_tail_arguments(rest, after)?;
                    expect_graph_arity(name, &arguments, 0, 2)?;
                    let fill = if let Some(argument) = arguments.first() {
                        self.evaluate_graphics_color(argument)?
                    } else {
                        self.graphics.foreground().to_string()
                    };
                    // Artist performs the actual flood operation. A Microsoft
                    // border-color argument is accepted for source compatibility;
                    // the retained vector scene does not need to duplicate it.
                    if let Some(border) = arguments.get(1) {
                        let _ = self.evaluate_graphics_color(border)?;
                    }
                    self.graphics.scene_mut().flood_fill(x, y, &fill)?;
                }
            }
            "MOVE" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 2, 2)?;
                let x = self.evaluate_graph_real(arguments[0])?;
                let y = self.evaluate_graph_real(arguments[1])?;
                self.graphics.set_cursor(x, y);
            }
            "DRAWTO" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 2, 5)?;
                let (x0, y0) = self.graphics.cursor();
                let x1 = self.evaluate_graph_real(arguments[0])?;
                let y1 = self.evaluate_graph_real(arguments[1])?;
                let color = if let Some(argument) = arguments.get(2) {
                    self.evaluate_graphics_color(argument)?
                } else {
                    self.graphics.foreground().to_string()
                };
                let width = arguments
                    .get(3)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(1.0);
                self.graphics
                    .scene_mut()
                    .line(x0, y0, x1, y1, &color, width)?;
                self.graphics.set_cursor(x1, y1);
            }
            "DRAW" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 3)?;
                let commands = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let color = if let Some(argument) = arguments.get(1) {
                    self.evaluate_graphics_color(argument)?
                } else {
                    self.graphics.foreground().to_string()
                };
                let width = arguments
                    .get(2)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(1.0);
                self.execute_draw_macro(&commands, &color, width)?;
            }
            "GRADIENT" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 7, 7)?;
                let id = self.graphics_identifier(arguments[0])?;
                let x1 = self.evaluate_graph_real(arguments[1])?;
                let y1 = self.evaluate_graph_real(arguments[2])?;
                let x2 = self.evaluate_graph_real(arguments[3])?;
                let y2 = self.evaluate_graph_real(arguments[4])?;
                let first = self.evaluate_graphics_color(arguments[5])?;
                let second = self.evaluate_graphics_color(arguments[6])?;
                self.graphics.scene_mut().gradient(
                    &id,
                    x1,
                    y1,
                    x2,
                    y2,
                    &[(0.0, first.as_str()), (1.0, second.as_str())],
                )?;
            }
            "RADIALGRADIENT" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 6, 6)?;
                let id = self.graphics_identifier(arguments[0])?;
                let cx = self.evaluate_graph_real(arguments[1])?;
                let cy = self.evaluate_graph_real(arguments[2])?;
                let radius = self.evaluate_graph_real(arguments[3])?;
                let first = self.evaluate_graphics_color(arguments[4])?;
                let second = self.evaluate_graphics_color(arguments[5])?;
                self.graphics.scene_mut().radial_gradient(
                    &id,
                    cx,
                    cy,
                    cx,
                    cy,
                    0.0,
                    radius,
                    &[(0.0, first.as_str()), (1.0, second.as_str())],
                )?;
            }
            "ARC" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 9, 9)?;
                let cx = self.evaluate_graph_real(arguments[0])?;
                let cy = self.evaluate_graph_real(arguments[1])?;
                let rx = self.evaluate_graph_real(arguments[2])?;
                let ry = self.evaluate_graph_real(arguments[3])?;
                let start = self.evaluate_graph_real(arguments[4])?;
                let end = self.evaluate_graph_real(arguments[5])?;
                let stroke = self.evaluate_graphics_color(arguments[6])?;
                let fill = self.evaluate_graphics_color_or_none(arguments[7])?;
                let width = self.evaluate_graph_real(arguments[8])?;
                self.graphics
                    .scene_mut()
                    .arc(cx, cy, rx, ry, start, end, &stroke, &fill, width)?;
            }
            "BEZIER" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 10, 10)?;
                let values = (0..8)
                    .map(|index| self.evaluate_graph_real(arguments[index]))
                    .collect::<Result<Vec<_>, _>>()?;
                let stroke = self.evaluate_graphics_color(arguments[8])?;
                let width = self.evaluate_graph_real(arguments[9])?;
                self.graphics.scene_mut().bezier(
                    values[0], values[1], values[2], values[3], values[4], values[5], values[6],
                    values[7], &stroke, width,
                )?;
            }
            "ROUNDEDRECT" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 8, 8)?;
                let x = self.evaluate_graph_real(arguments[0])?;
                let y = self.evaluate_graph_real(arguments[1])?;
                let width = self.evaluate_graph_real(arguments[2])?;
                let height = self.evaluate_graph_real(arguments[3])?;
                let radius = self.evaluate_graph_real(arguments[4])?;
                let stroke = self.evaluate_graphics_color(arguments[5])?;
                let fill = self.evaluate_graphics_color_or_none(arguments[6])?;
                let line_width = self.evaluate_graph_real(arguments[7])?;
                self.graphics
                    .scene_mut()
                    .rounded_rectangle(x, y, width, height, radius, &stroke, &fill, line_width)?;
            }
            "OPACITY" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 1)?;
                let opacity = self.evaluate_graph_real(arguments[0])?;
                self.graphics.scene_mut().set_opacity(opacity)?;
            }
            "TRANSLATE" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 2, 2)?;
                let dx = self.evaluate_graph_real(arguments[0])?;
                let dy = self.evaluate_graph_real(arguments[1])?;
                self.graphics.scene_mut().translate(dx, dy)?;
            }
            "ROTATE" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 1)?;
                let degrees = self.evaluate_graph_real(arguments[0])?;
                self.graphics.scene_mut().rotate(degrees)?;
            }
            "SCALE" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 2)?;
                let sx = self.evaluate_graph_real(arguments[0])?;
                let sy = if arguments.len() == 2 {
                    self.evaluate_graph_real(arguments[1])?
                } else {
                    sx
                };
                self.graphics.scene_mut().scale(sx, sy)?;
            }
            "BLEND" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 1)?;
                let mode = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                self.graphics
                    .scene_mut()
                    .set_blend(&mode.to_ascii_lowercase())?;
            }
            "NGON" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 7, 7)?;
                let cx = self.evaluate_graph_real(arguments[0])?;
                let cy = self.evaluate_graph_real(arguments[1])?;
                let sides = self.evaluate_integer(arguments[2])?;
                let radius = self.evaluate_graph_real(arguments[3])?;
                let stroke = self.evaluate_graphics_color(arguments[4])?;
                let fill = self.evaluate_graphics_color_or_none(arguments[5])?;
                let width = self.evaluate_graph_real(arguments[6])?;
                self.graphics
                    .scene_mut()
                    .ngon(cx, cy, sides, radius, &stroke, &fill, width)?;
            }
            "STAR" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 8, 8)?;
                let cx = self.evaluate_graph_real(arguments[0])?;
                let cy = self.evaluate_graph_real(arguments[1])?;
                let points = self.evaluate_integer(arguments[2])?;
                let outer = self.evaluate_graph_real(arguments[3])?;
                let inner = self.evaluate_graph_real(arguments[4])?;
                let stroke = self.evaluate_graphics_color(arguments[5])?;
                let fill = self.evaluate_graphics_color_or_none(arguments[6])?;
                let width = self.evaluate_graph_real(arguments[7])?;
                self.graphics
                    .scene_mut()
                    .star(cx, cy, points, outer, inner, &stroke, &fill, width)?;
            }
            "BITMAP" => {
                if rest
                    .first()
                    .and_then(token_command_word)
                    .is_some_and(|command| command.eq_ignore_ascii_case("WARP"))
                {
                    let arguments = split_graph_arguments(&rest[1..])?;
                    expect_graph_arity("BITMAP WARP", &arguments, 8, 9)?;
                    let filename = self
                        .evaluate_value(arguments[0])?
                        .into_string()
                        .ok_or(Error::TypeMismatch)?;
                    self.ensure_image_prepared(&filename)?;
                    let path = self
                        .prepared_images
                        .get(&filename)
                        .map(|asset| asset.virtual_path.clone())
                        .ok_or_else(|| Error::syntax("BITMAP asset was not prepared by LOAD"))?;
                    let anchor_x = self.evaluate_graph_real(arguments[1])?;
                    let anchor_y = self.evaluate_graph_real(arguments[2])?;
                    let width = self.evaluate_graph_real(arguments[3])?;
                    let height = self.evaluate_graph_real(arguments[4])?;
                    let angle = self.evaluate_graph_real(arguments[5])?;
                    let bend = self.evaluate_graph_real(arguments[6])?;
                    let turn = self.evaluate_graph_real(arguments[7])?;
                    let light = arguments
                        .get(8)
                        .map(|argument| self.evaluate_graph_real(argument))
                        .transpose()?
                        .unwrap_or(1.0);
                    self.graphics.scene_mut().bitmap_warp(
                        &path.to_string_lossy(),
                        anchor_x,
                        anchor_y,
                        width,
                        height,
                        angle,
                        bend,
                        turn,
                        light,
                    )?;
                } else {
                    let arguments = split_graph_arguments(rest)?;
                    expect_graph_arity(name, &arguments, 5, 5)?;
                    let filename = self
                        .evaluate_value(arguments[0])?
                        .into_string()
                        .ok_or(Error::TypeMismatch)?;
                    self.ensure_image_prepared(&filename)?;
                    let path = self
                        .prepared_images
                        .get(&filename)
                        .map(|asset| asset.virtual_path.clone())
                        .ok_or_else(|| Error::syntax("BITMAP asset was not prepared by LOAD"))?;
                    let x = self.evaluate_graph_real(arguments[1])?;
                    let y = self.evaluate_graph_real(arguments[2])?;
                    let width = self.evaluate_graph_real(arguments[3])?;
                    let height = self.evaluate_graph_real(arguments[4])?;
                    self.graphics.scene_mut().bitmap(
                        &path.to_string_lossy(),
                        x,
                        y,
                        width,
                        height,
                    )?;
                }
            }
            "PATH" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 4, 4)?;
                let path = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let stroke = self.evaluate_graphics_color(arguments[1])?;
                let fill = self.evaluate_graphics_color_or_none(arguments[2])?;
                let width = self.evaluate_graph_real(arguments[3])?;
                self.graphics
                    .scene_mut()
                    .path(&path, &stroke, &fill, width)?;
            }
            "PERSPECTIVE" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 3, 6)?;
                let horizon_x = self.evaluate_graph_real(arguments[0])?;
                let horizon_y = self.evaluate_graph_real(arguments[1])?;
                let focal_length = self.evaluate_graph_real(arguments[2])?;
                let near = arguments
                    .get(3)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(0.1);
                let far = arguments
                    .get(4)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(1_000_000.0);
                let ambient = arguments
                    .get(5)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(0.35);
                self.graphics.configure_perspective(
                    horizon_x,
                    horizon_y,
                    focal_length,
                    near,
                    far,
                    ambient,
                )?;
            }
            "OBJECT" => {
                let (command_token, tail) = rest.split_first().ok_or_else(|| {
                    Error::syntax(
                        "OBJECT requires SHAPE, MOVE, SCALE, CAMERA, LIGHT, REMOVE, or CLEAR",
                    )
                })?;
                let command = token_command_word(command_token).ok_or_else(|| {
                    Error::syntax(
                        "OBJECT requires SHAPE, MOVE, SCALE, CAMERA, LIGHT, REMOVE, or CLEAR",
                    )
                })?;
                let arguments = split_graph_arguments(tail)?;
                match command {
                    "SHAPE" => {
                        expect_graph_arity("OBJECT SHAPE", &arguments, 7, 8)?;
                        let id = self.graphics_identifier(arguments[0])?;
                        let x = self.evaluate_graph_real(arguments[1])?;
                        let y = self.evaluate_graph_real(arguments[2])?;
                        let z = self.evaluate_graph_real(arguments[3])?;
                        let width = self.evaluate_graph_real(arguments[4])?;
                        let height = self.evaluate_graph_real(arguments[5])?;
                        let fill = self.evaluate_graphics_color(arguments[6])?;
                        let stroke = arguments
                            .get(7)
                            .map(|argument| self.evaluate_graphics_color_or_none(argument))
                            .transpose()?
                            .unwrap_or_else(|| "none".to_string());
                        self.graphics.define_perspective_object(
                            &id, x, y, z, width, height, &fill, &stroke,
                        )?;
                    }
                    "MOVE" => {
                        expect_graph_arity("OBJECT MOVE", &arguments, 4, 4)?;
                        let id = self.graphics_identifier(arguments[0])?;
                        let x = self.evaluate_graph_real(arguments[1])?;
                        let y = self.evaluate_graph_real(arguments[2])?;
                        let z = self.evaluate_graph_real(arguments[3])?;
                        self.graphics.move_perspective_object(&id, x, y, z)?;
                    }
                    "SCALE" => {
                        expect_graph_arity("OBJECT SCALE", &arguments, 3, 3)?;
                        let id = self.graphics_identifier(arguments[0])?;
                        let width = self.evaluate_graph_real(arguments[1])?;
                        let height = self.evaluate_graph_real(arguments[2])?;
                        self.graphics.scale_perspective_object(&id, width, height)?;
                    }
                    "CAMERA" => {
                        expect_graph_arity("OBJECT CAMERA", &arguments, 3, 3)?;
                        let x = self.evaluate_graph_real(arguments[0])?;
                        let y = self.evaluate_graph_real(arguments[1])?;
                        let z = self.evaluate_graph_real(arguments[2])?;
                        self.graphics.set_perspective_camera(x, y, z)?;
                    }
                    "LIGHT" => {
                        expect_graph_arity("OBJECT LIGHT", &arguments, 7, 7)?;
                        let id = self.graphics_identifier(arguments[0])?;
                        let x = self.evaluate_graph_real(arguments[1])?;
                        let y = self.evaluate_graph_real(arguments[2])?;
                        let z = self.evaluate_graph_real(arguments[3])?;
                        let intensity = self.evaluate_graph_real(arguments[4])?;
                        let range = self.evaluate_graph_real(arguments[5])?;
                        let color = self.evaluate_graphics_color(arguments[6])?;
                        self.graphics
                            .define_perspective_light(&id, x, y, z, intensity, range, &color)?;
                    }
                    "REMOVE" => {
                        expect_graph_arity("OBJECT REMOVE", &arguments, 1, 1)?;
                        let id = self.graphics_identifier(arguments[0])?;
                        self.graphics.remove_perspective_object(&id)?;
                    }
                    "CLEAR" => {
                        expect_graph_arity("OBJECT CLEAR", &arguments, 0, 0)?;
                        self.graphics.clear_perspective_world();
                    }
                    _ => {
                        return Err(Error::syntax(
                            "OBJECT requires SHAPE, MOVE, SCALE, CAMERA, LIGHT, REMOVE, or CLEAR",
                        ))
                    }
                }
            }
            "LIGHT" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 4, 4)?;
                let x = self.evaluate_graph_real(arguments[0])?;
                let y = self.evaluate_graph_real(arguments[1])?;
                let intensity = self.evaluate_graph_real(arguments[2])?;
                let color = self.evaluate_graphics_color(arguments[3])?;
                self.graphics
                    .scene_mut()
                    .light_source(x, y, intensity, &color)?;
            }
            "DEPTHPERCEPTION" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 3, 3)?;
                let horizon = self.evaluate_graph_real(arguments[0])?;
                let rows = self.evaluate_integer(arguments[1])?;
                let rays = self.evaluate_integer(arguments[2])?;
                self.graphics
                    .scene_mut()
                    .depth_perception(horizon, rows, rays)?;
            }
            "DEPTHGRID" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 3, 3)?;
                let horizon = self.evaluate_graph_real(arguments[0])?;
                let rows = self.evaluate_integer(arguments[1])?;
                let rays = self.evaluate_integer(arguments[2])?;
                self.graphics.scene_mut().depth_grid(horizon, rows, rays)?;
            }
            "GRIDON" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 0, 1)?;
                let plane = if arguments.is_empty() {
                    "BOTH".to_string()
                } else {
                    self.graphics_identifier(arguments[0])?
                };
                self.graphics.scene_mut().grid_on(&plane)?;
            }
            "GRIDOFF" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graphics.scene_mut().grid_off()?;
            }
            "GRIDPOINT" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 5, 5)?;
                let row = self.evaluate_integer(arguments[0])?;
                let column = self
                    .evaluate_value(arguments[1])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let plane = self
                    .evaluate_value(arguments[2])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let radius = self.evaluate_graph_real(arguments[3])?;
                let fill = self.evaluate_graphics_color(arguments[4])?;
                self.graphics
                    .scene_mut()
                    .grid_point(row, &column, &plane, radius, &fill)?;
            }
            "LAYER" | "BEGINLAYER" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 1)?;
                let layer = self.graphics_identifier(arguments[0])?;
                self.graphics.scene_mut().begin_layer(&layer)?;
            }
            "ENDLAYER" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graphics.scene_mut().end_layer()?;
            }
            "GROUP" | "BEGINGROUP" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graphics.scene_mut().begin_group()?;
            }
            "ENDGROUP" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graphics.scene_mut().end_group()?;
            }
            "POLYGON" => self.execute_polygon(rest)?,
            "TEXT" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 4, 5)?;
                let x = self.evaluate_graph_real(arguments[0])?;
                let y = self.evaluate_graph_real(arguments[1])?;
                let size = self.evaluate_graph_real(arguments[2])?;
                let text = self
                    .evaluate_value(arguments[3])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let color = if let Some(argument) = arguments.get(4) {
                    self.evaluate_graphics_color(argument)?
                } else {
                    self.graphics.foreground().to_string()
                };
                self.graphics.scene_mut().text(x, y, size, &text, &color)?;
            }
            "SPRITE" | "BLIT" => {
                let arguments = split_graph_arguments(rest)?;
                if let Some([x_tokens, y_tokens, z_tokens]) = arguments
                    .get(1)
                    .and_then(|coordinate| parse_complete_graphics_xyz(coordinate).ok())
                {
                    expect_graph_arity(name, &arguments, 4, 6)?;
                    let id = self.graphics_identifier(arguments[0])?;
                    let x = self.evaluate_graph_real(x_tokens)?;
                    let y = self.evaluate_graph_real(y_tokens)?;
                    let z = self.evaluate_graph_real(z_tokens)?;
                    let width = self.evaluate_graph_real(arguments[2])?;
                    let height = self.evaluate_graph_real(arguments[3])?;
                    let fill = if let Some(argument) = arguments.get(4) {
                        self.evaluate_graphics_color(argument)?
                    } else {
                        self.graphics.foreground().to_string()
                    };
                    let stroke = if let Some(argument) = arguments.get(5) {
                        self.evaluate_graphics_color(argument)?
                    } else {
                        "none".to_string()
                    };
                    self.graphics
                        .perspective_sprite(&id, x, y, z, width, height, &fill, &stroke)?;
                } else {
                    expect_graph_arity(name, &arguments, 5, 7)?;
                    let id = self.graphics_identifier(arguments[0])?;
                    let x = self.evaluate_graph_real(arguments[1])?;
                    let y = self.evaluate_graph_real(arguments[2])?;
                    let width = self.evaluate_graph_real(arguments[3])?;
                    let height = self.evaluate_graph_real(arguments[4])?;
                    let fill = if let Some(argument) = arguments.get(5) {
                        self.evaluate_graphics_color(argument)?
                    } else {
                        self.graphics.foreground().to_string()
                    };
                    let stroke = if let Some(argument) = arguments.get(6) {
                        self.evaluate_graphics_color(argument)?
                    } else {
                        "none".to_string()
                    };
                    self.graphics
                        .sprite(&id, x, y, width, height, &fill, &stroke)?;
                }
            }
            "MOVESPRITE" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 3, 4)?;
                let id = self.graphics_identifier(arguments[0])?;
                let x = self.evaluate_graph_real(arguments[1])?;
                let y = self.evaluate_graph_real(arguments[2])?;
                let z = arguments
                    .get(3)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?;
                self.graphics.move_sprite(&id, x, y, z)?;
            }
            "SPRITEMOTION" => {
                let arguments = split_graph_arguments(rest)?;
                let id = arguments
                    .first()
                    .ok_or_else(|| {
                        Error::syntax(
                            "SPRITEMOTION expects sprite,vx,vy[,ax,ay] or sprite,vx,vy,vz[,ax,ay,az]",
                        )
                    })
                    .and_then(|argument| self.graphics_identifier(argument))?;
                let (velocity, acceleration) = match arguments.len() {
                    3 => (
                        [
                            self.evaluate_graph_real(arguments[1])?,
                            self.evaluate_graph_real(arguments[2])?,
                            0.0,
                        ],
                        [0.0; 3],
                    ),
                    4 => (
                        [
                            self.evaluate_graph_real(arguments[1])?,
                            self.evaluate_graph_real(arguments[2])?,
                            self.evaluate_graph_real(arguments[3])?,
                        ],
                        [0.0; 3],
                    ),
                    5 => (
                        [
                            self.evaluate_graph_real(arguments[1])?,
                            self.evaluate_graph_real(arguments[2])?,
                            0.0,
                        ],
                        [
                            self.evaluate_graph_real(arguments[3])?,
                            self.evaluate_graph_real(arguments[4])?,
                            0.0,
                        ],
                    ),
                    7 => (
                        [
                            self.evaluate_graph_real(arguments[1])?,
                            self.evaluate_graph_real(arguments[2])?,
                            self.evaluate_graph_real(arguments[3])?,
                        ],
                        [
                            self.evaluate_graph_real(arguments[4])?,
                            self.evaluate_graph_real(arguments[5])?,
                            self.evaluate_graph_real(arguments[6])?,
                        ],
                    ),
                    _ => return Err(Error::syntax(
                        "SPRITEMOTION expects sprite,vx,vy[,ax,ay] or sprite,vx,vy,vz[,ax,ay,az]",
                    )),
                };
                self.graphics
                    .set_sprite_motion(&id, velocity, acceleration)?;
            }
            "ADVANCESPRITES" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 1)?;
                let seconds = self.evaluate_graph_real(arguments[0])?;
                self.graphics.advance_sprites(seconds)?;
            }
            "BUFFER" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 1)?;
                let index = self.evaluate_integer(arguments[0])?;
                self.graphics.select_draw_buffer(index)?;
            }
            "FRAME" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 1)?;
                let milliseconds = self.evaluate_integer(arguments[0])?;
                if !(1..=1_000).contains(&milliseconds) {
                    return Err(Error::IllegalQuantity);
                }
                std::thread::sleep(std::time::Duration::from_millis(milliseconds as u64));
            }
            "FLIP" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graphics.flip()?;
                let view = self.graphics_presentation_view();
                self.screen_view = view;
                self.present_graphics_scene(true, view);
            }
            "SCREENSHOT" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 1, 1)?;
                let path = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                if !path.to_ascii_lowercase().ends_with(".png") {
                    return Err(Error::syntax("SCREENSHOT output must end in .png"));
                }
                let output = self.outputs.output_path(&path)?;
                let source = self.graphics.displayed_scene_source();
                ArtistBackend::new().render_output(&source, &output, false)?;
                self.retain_generated_image(&path, &source)?;
            }
            "FLIPBOOK" => {
                let (command_token, tail) = rest
                    .split_first()
                    .ok_or_else(|| Error::syntax("FLIPBOOK requires CREATE, REMOVE, or CLEAR"))?;
                let command = token_command_word(command_token)
                    .ok_or_else(|| Error::syntax("FLIPBOOK requires CREATE, REMOVE, or CLEAR"))?;
                let arguments = split_graph_arguments(tail)?;
                match command {
                    "CREATE" => {
                        expect_graph_arity("FLIPBOOK CREATE", &arguments, 5, 5)?;
                        let id = self.graphics_identifier(arguments[0])?;
                        let template = self
                            .evaluate_value(arguments[1])?
                            .into_string()
                            .ok_or(Error::TypeMismatch)?;
                        let first = self.evaluate_integer(arguments[2])?;
                        let last = self.evaluate_integer(arguments[3])?;
                        let fps = self.evaluate_integer(arguments[4])?;
                        let frame_names = expand_frame_template(&template, first, last)?;
                        let mut frames = Vec::with_capacity(frame_names.len());
                        for frame_name in frame_names {
                            self.ensure_image_prepared(&frame_name)?;
                            frames.push(Arc::clone(
                                &self
                                    .prepared_images
                                    .get(&frame_name)
                                    .ok_or_else(|| {
                                        Error::syntax("FLIPBOOK frame was not prepared by LOAD")
                                    })?
                                    .image,
                            ));
                        }
                        let sequence = FlipbookSequence::from_images(&id, frames, fps)?;
                        self.flipbooks.insert(id.to_ascii_uppercase(), sequence);
                    }
                    "REMOVE" => {
                        expect_graph_arity("FLIPBOOK REMOVE", &arguments, 1, 1)?;
                        let id = self.graphics_identifier(arguments[0])?.to_ascii_uppercase();
                        if self.flipbooks.remove(&id).is_none() {
                            return Err(Error::syntax(format!("undefined FLIPBOOK {id}")));
                        }
                    }
                    "CLEAR" => {
                        expect_graph_arity("FLIPBOOK CLEAR", &arguments, 0, 0)?;
                        self.flipbooks.clear();
                    }
                    _ => return Err(Error::syntax("FLIPBOOK requires CREATE, REMOVE, or CLEAR")),
                }
            }
            "VIDEO" => {
                let (command, tail) = rest
                    .split_first()
                    .ok_or_else(|| Error::syntax("VIDEO requires START, FRAME, STOP, or EXPORT"))?;
                let command = token_command_word(command)
                    .ok_or_else(|| Error::syntax("VIDEO requires START, FRAME, STOP, or EXPORT"))?;
                match command {
                    "EXPORT" => {
                        let arguments = split_graph_arguments(tail)?;
                        expect_graph_arity("VIDEO EXPORT", &arguments, 2, 3)?;
                        if self.video.is_some() {
                            return Err(Error::syntax(
                                "VIDEO EXPORT cannot run during VIDEO START recording",
                            ));
                        }
                        let id = self.graphics_identifier(arguments[0])?.to_ascii_uppercase();
                        let sequence = self
                            .flipbooks
                            .get(&id)
                            .cloned()
                            .ok_or_else(|| Error::syntax(format!("undefined FLIPBOOK {id}")))?;
                        let output_name = self
                            .evaluate_value(arguments[1])?
                            .into_string()
                            .ok_or(Error::TypeMismatch)?;
                        let output = self.outputs.output_path(&output_name)?;
                        let audio = arguments
                            .get(2)
                            .map(|argument| {
                                self.evaluate_value(argument)?
                                    .into_string()
                                    .ok_or(Error::TypeMismatch)
                            })
                            .transpose()?
                            .map(|path| {
                                self.resolve_playback_source(&path, ProgramMediaKind::Audio)
                            })
                            .transpose()?;
                        let (width, height) = sequence.native_dimensions();
                        let mut recorder =
                            VideoRecorder::start(output, i64::from(sequence.fps()), audio)?;
                        sequence.stream_frames(width, height, |_, ppm| {
                            recorder.write_ppm_frame(ppm.as_ref())
                        })?;
                        recorder.finish()?;
                    }
                    "START" => {
                        let arguments = split_graph_arguments(tail)?;
                        expect_graph_arity("VIDEO START", &arguments, 2, 3)?;
                        if self.video.is_some() {
                            return Err(Error::syntax("VIDEO recording is already active"));
                        }
                        let path = self
                            .evaluate_value(arguments[0])?
                            .into_string()
                            .ok_or(Error::TypeMismatch)?;
                        let fps = self.evaluate_integer(arguments[1])?;
                        let output = self.outputs.output_path(&path)?;
                        let audio = arguments
                            .get(2)
                            .map(|argument| {
                                self.evaluate_value(argument)?
                                    .into_string()
                                    .ok_or(Error::TypeMismatch)
                            })
                            .transpose()?
                            .map(|path| {
                                self.resolve_playback_source(&path, ProgramMediaKind::Audio)
                            })
                            .transpose()?;
                        self.video = Some(VideoRecorder::start(output, fps, audio)?);
                    }
                    "FRAME" => {
                        expect_end_of_line(tail)?;
                        if self.video.is_none() {
                            return Err(Error::syntax("VIDEO FRAME requires VIDEO START"));
                        }
                        let source = self.graphics.displayed_scene_source();
                        let ppm = self.render_graphics_source(&source)?;
                        self.video
                            .as_mut()
                            .expect("video presence checked above")
                            .write_ppm_frame(ppm.as_ref())?;
                    }
                    "STOP" => {
                        expect_end_of_line(tail)?;
                        let video = self
                            .video
                            .take()
                            .ok_or_else(|| Error::syntax("VIDEO STOP requires VIDEO START"))?;
                        video.finish()?;
                    }
                    _ => {
                        return Err(Error::syntax(
                            "VIDEO requires START, FRAME, STOP, or EXPORT",
                        ))
                    }
                }
            }
            "SAVEIMAGE" | "RENDER" | "DISPLAY" => {
                let arguments = split_graph_arguments(rest)?;
                expect_graph_arity(name, &arguments, 0, 1)?;
                let source = if name == "DISPLAY" {
                    self.graphics.displayed_scene_source()
                } else {
                    self.graphics.scene_source()
                };
                let attached_screen = if name == "DISPLAY" && screen_attached() {
                    let view = self.graphics_presentation_view();
                    self.screen_view = view;
                    self.present_graphics_scene(true, view)
                } else {
                    false
                };

                // DISPLAY without a filename is an in-window screen operation
                // when the native shell is attached. File-oriented commands,
                // explicit DISPLAY paths, and non-shell execution still render
                // through Artist's normal output boundary.
                if !arguments.is_empty() || name != "DISPLAY" || !attached_screen {
                    let (output, retained_path) = if let Some(argument) = arguments.first() {
                        let path = self
                            .evaluate_value(argument)?
                            .into_string()
                            .ok_or(Error::TypeMismatch)?;
                        (self.outputs.output_path(&path)?, Some(path))
                    } else {
                        (
                            self.graph_output
                                .clone()
                                .unwrap_or_else(|| PathBuf::from("modernbasic-screen.svg")),
                            None,
                        )
                    };
                    ArtistBackend::new().render_output(
                        &source,
                        &output,
                        !attached_screen && (name == "DISPLAY" || self.open_graph_window),
                    )?;
                    if let Some(path) = retained_path {
                        self.retain_generated_image(&path, &source)?;
                    }
                }
            }
            _ => {
                return Err(Error::syntax(format!(
                    "unsupported graphics statement {name}"
                )))
            }
        }
        Ok(Control::Advance)
    }

    fn execute_brush(&mut self, rest: &[TokenInstance]) -> Result<(), Error> {
        let (x1_tokens, y1_tokens, after_first) = parse_graphics_point(rest, 0)?;
        if !matches!(
            rest.get(after_first),
            Some(TokenInstance::Keyword(Token::Minus))
        ) {
            return Err(Error::syntax("BRUSH requires (x1,y1)-(x2,y2)"));
        }
        let (x2_tokens, y2_tokens, after_second) = parse_graphics_point(rest, after_first + 1)?;
        let arguments = graphics_tail_arguments(rest, after_second)?;
        expect_graph_arity("BRUSH", &arguments, 2, 5)?;
        let x1 = self.evaluate_graph_real(x1_tokens)?;
        let y1 = self.evaluate_graph_real(y1_tokens)?;
        let x2 = self.evaluate_graph_real(x2_tokens)?;
        let y2 = self.evaluate_graph_real(y2_tokens)?;
        let size = self.evaluate_graph_real(arguments[0])?;
        let color = self.evaluate_graphics_color(arguments[1])?;
        let hardness = arguments
            .get(2)
            .map(|argument| self.evaluate_graph_real(argument))
            .transpose()?
            .unwrap_or(0.65);
        let opacity = arguments
            .get(3)
            .map(|argument| self.evaluate_graph_real(argument))
            .transpose()?
            .unwrap_or(1.0);
        let flow = arguments
            .get(4)
            .map(|argument| self.evaluate_graph_real(argument))
            .transpose()?
            .unwrap_or(0.7);
        self.graphics
            .scene_mut()
            .brush_stroke(x1, y1, x2, y2, size, &color, hardness, opacity, flow)?;
        self.graphics.set_cursor(x2, y2);
        Ok(())
    }

    fn execute_microsoft_line(&mut self, rest: &[TokenInstance]) -> Result<(), Error> {
        if matches!(rest.first(), Some(TokenInstance::LParen)) {
            let (x1_tokens, y1_tokens, after_first) = parse_graphics_point(rest, 0)?;
            if !matches!(
                rest.get(after_first),
                Some(TokenInstance::Keyword(Token::Minus))
            ) {
                return Err(Error::syntax("LINE requires (x1,y1)-(x2,y2)"));
            }
            let (x2_tokens, y2_tokens, after_second) = parse_graphics_point(rest, after_first + 1)?;
            let x1 = self.evaluate_graph_real(x1_tokens)?;
            let y1 = self.evaluate_graph_real(y1_tokens)?;
            let x2 = self.evaluate_graph_real(x2_tokens)?;
            let y2 = self.evaluate_graph_real(y2_tokens)?;
            let arguments = graphics_tail_arguments(rest, after_second)?;
            expect_graph_arity("LINE", &arguments, 0, 3)?;
            let color = if let Some(argument) = arguments.first() {
                self.evaluate_graphics_color(argument)?
            } else {
                self.graphics.foreground().to_string()
            };
            let (mode, width) = self.evaluate_line_tail(&arguments)?;
            match mode.as_str() {
                "" => self
                    .graphics
                    .scene_mut()
                    .line(x1, y1, x2, y2, &color, width)?,
                "B" => self.graphics.scene_mut().rectangle(
                    x1.min(x2),
                    y1.min(y2),
                    (x2 - x1).abs(),
                    (y2 - y1).abs(),
                    &color,
                    "none",
                    width,
                )?,
                "BF" => self.graphics.scene_mut().rectangle(
                    x1.min(x2),
                    y1.min(y2),
                    (x2 - x1).abs(),
                    (y2 - y1).abs(),
                    &color,
                    &color,
                    width,
                )?,
                _ => return Err(Error::syntax("LINE mode must be B or BF")),
            }
            self.graphics.set_cursor(x2, y2);
            return Ok(());
        }

        let arguments = split_graph_arguments(rest)?;
        expect_graph_arity("LINE", &arguments, 4, 7)?;
        let x1 = self.evaluate_graph_real(arguments[0])?;
        let y1 = self.evaluate_graph_real(arguments[1])?;
        let x2 = self.evaluate_graph_real(arguments[2])?;
        let y2 = self.evaluate_graph_real(arguments[3])?;
        let color = if let Some(argument) = arguments.get(4) {
            self.evaluate_graphics_color(argument)?
        } else {
            self.graphics.foreground().to_string()
        };
        let (mode, width) = self.evaluate_line_tail(&arguments[4..])?;
        match mode.as_str() {
            "" => self
                .graphics
                .scene_mut()
                .line(x1, y1, x2, y2, &color, width)?,
            "B" => self.graphics.scene_mut().rectangle(
                x1.min(x2),
                y1.min(y2),
                (x2 - x1).abs(),
                (y2 - y1).abs(),
                &color,
                "none",
                width,
            )?,
            "BF" => self.graphics.scene_mut().rectangle(
                x1.min(x2),
                y1.min(y2),
                (x2 - x1).abs(),
                (y2 - y1).abs(),
                &color,
                &color,
                width,
            )?,
            _ => return Err(Error::syntax("LINE mode must be B or BF")),
        }
        self.graphics.set_cursor(x2, y2);
        Ok(())
    }

    fn evaluate_line_tail(
        &mut self,
        arguments: &[&[TokenInstance]],
    ) -> Result<(String, f64), Error> {
        let Some(mode_or_width) = arguments.get(1) else {
            return Ok((String::new(), 1.0));
        };
        let word = graphics_mode_word(mode_or_width);
        if word.is_some_and(|value| value.eq_ignore_ascii_case("B"))
            || word.is_some_and(|value| value.eq_ignore_ascii_case("BF"))
            || word == Some("")
        {
            let mode = word.unwrap_or_default().to_ascii_uppercase();
            let width = arguments
                .get(2)
                .map(|argument| self.evaluate_graph_real(argument))
                .transpose()?
                .unwrap_or(1.0);
            return Ok((mode, width));
        }
        if arguments.len() > 2 {
            return Err(Error::syntax("LINE mode must be B or BF"));
        }
        if word.is_some() && !matches!(mode_or_width.first(), Some(TokenInstance::Ident(_))) {
            return Err(Error::syntax("LINE mode must be B or BF"));
        }
        Ok((String::new(), self.evaluate_graph_real(mode_or_width)?))
    }

    fn execute_rectangle(&mut self, name: &str, rest: &[TokenInstance]) -> Result<(), Error> {
        let (x, y, width, height, style) = if matches!(rest.first(), Some(TokenInstance::LParen)) {
            let (x1_tokens, y1_tokens, after_first) = parse_graphics_point(rest, 0)?;
            if !matches!(
                rest.get(after_first),
                Some(TokenInstance::Keyword(Token::Minus))
            ) {
                return Err(Error::syntax(format!("{name} requires (x1,y1)-(x2,y2)")));
            }
            let (x2_tokens, y2_tokens, after_second) = parse_graphics_point(rest, after_first + 1)?;
            let x1 = self.evaluate_graph_real(x1_tokens)?;
            let y1 = self.evaluate_graph_real(y1_tokens)?;
            let x2 = self.evaluate_graph_real(x2_tokens)?;
            let y2 = self.evaluate_graph_real(y2_tokens)?;
            (
                x1.min(x2),
                y1.min(y2),
                (x2 - x1).abs(),
                (y2 - y1).abs(),
                graphics_tail_arguments(rest, after_second)?,
            )
        } else {
            let arguments = split_graph_arguments(rest)?;
            expect_graph_arity(name, &arguments, 4, 7)?;
            (
                self.evaluate_graph_real(arguments[0])?,
                self.evaluate_graph_real(arguments[1])?,
                self.evaluate_graph_real(arguments[2])?,
                self.evaluate_graph_real(arguments[3])?,
                arguments[4..].to_vec(),
            )
        };

        expect_graph_arity(name, &style, 0, 3)?;
        let stroke = if let Some(argument) = style.first() {
            self.evaluate_graphics_color(argument)?
        } else {
            self.graphics.foreground().to_string()
        };
        let fill = if let Some(argument) = style.get(1) {
            self.evaluate_graphics_color_or_none(argument)?
        } else {
            "none".to_string()
        };
        let stroke_width = style
            .get(2)
            .map(|argument| self.evaluate_graph_real(argument))
            .transpose()?
            .unwrap_or(1.0);
        self.graphics
            .scene_mut()
            .rectangle(x, y, width, height, &stroke, &fill, stroke_width)
    }

    fn execute_microsoft_circle(&mut self, rest: &[TokenInstance]) -> Result<(), Error> {
        let (x, y, arguments) = if matches!(rest.first(), Some(TokenInstance::LParen)) {
            let (x_tokens, y_tokens, after) = parse_graphics_point(rest, 0)?;
            (
                self.evaluate_graph_real(x_tokens)?,
                self.evaluate_graph_real(y_tokens)?,
                graphics_tail_arguments(rest, after)?,
            )
        } else {
            let arguments = split_graph_arguments(rest)?;
            expect_graph_arity("CIRCLE", &arguments, 3, 6)?;
            let x = self.evaluate_graph_real(arguments[0])?;
            let y = self.evaluate_graph_real(arguments[1])?;
            (x, y, arguments[2..].to_vec())
        };
        expect_graph_arity("CIRCLE", &arguments, 1, 4)?;
        let radius = self.evaluate_graph_real(arguments[0])?;
        let stroke = if let Some(argument) = arguments.get(1) {
            self.evaluate_graphics_color(argument)?
        } else {
            self.graphics.foreground().to_string()
        };
        let fill = if let Some(argument) = arguments.get(2) {
            self.evaluate_graphics_color_or_none(argument)?
        } else {
            "none".to_string()
        };
        let width = arguments
            .get(3)
            .map(|argument| self.evaluate_graph_real(argument))
            .transpose()?
            .unwrap_or(1.0);
        self.graphics
            .scene_mut()
            .circle(x, y, radius, &stroke, &fill, width)?;
        self.graphics.set_cursor(x, y);
        Ok(())
    }

    fn execute_polygon(&mut self, rest: &[TokenInstance]) -> Result<(), Error> {
        let arguments = split_graph_arguments(rest)?;
        let mut points = Vec::new();
        let mut style_start = 0usize;
        for (index, argument) in arguments.iter().enumerate() {
            if !matches!(argument.first(), Some(TokenInstance::LParen)) {
                style_start = index;
                break;
            }
            let (x_tokens, y_tokens, after) = parse_graphics_point(argument, 0)?;
            if after != argument.len() {
                return Err(Error::syntax("POLYGON point contains extra tokens"));
            }
            points.push((
                self.evaluate_graph_real(x_tokens)?,
                self.evaluate_graph_real(y_tokens)?,
            ));
            style_start = index + 1;
        }
        if points.len() < 3 {
            return Err(Error::syntax(
                "POLYGON requires at least three parenthesized points",
            ));
        }
        let style = &arguments[style_start..];
        if style.len() > 3 {
            return Err(Error::syntax("POLYGON accepts stroke, fill, and width"));
        }
        let stroke = if let Some(argument) = style.first() {
            self.evaluate_graphics_color(argument)?
        } else {
            self.graphics.foreground().to_string()
        };
        let fill = if let Some(argument) = style.get(1) {
            self.evaluate_graphics_color_or_none(argument)?
        } else {
            "none".to_string()
        };
        let width = style
            .get(2)
            .map(|argument| self.evaluate_graph_real(argument))
            .transpose()?
            .unwrap_or(1.0);
        self.graphics
            .scene_mut()
            .polygon(&points, &stroke, &fill, width)
    }

    fn execute_draw_macro(
        &mut self,
        commands: &str,
        default_color: &str,
        width: f64,
    ) -> Result<(), Error> {
        if width <= 0.0 || !width.is_finite() {
            return Err(Error::IllegalQuantity);
        }
        let mut state = DrawMacroState {
            color: default_color.to_string(),
            angle_degrees: 0.0,
            scale: 1.0,
            blank_next: false,
            return_next: false,
        };
        self.execute_draw_macro_inner(commands, width, 0, &mut state)
    }

    fn execute_draw_macro_inner(
        &mut self,
        commands: &str,
        width: f64,
        depth: usize,
        state: &mut DrawMacroState,
    ) -> Result<(), Error> {
        const MAX_DRAW_MACRO_DEPTH: usize = 16;
        let bytes = commands.as_bytes();
        let mut position = 0usize;
        while position < bytes.len() {
            while position < bytes.len()
                && (bytes[position].is_ascii_whitespace() || bytes[position] == b';')
            {
                position += 1;
            }
            if position >= bytes.len() {
                break;
            }
            let command = (bytes[position] as char).to_ascii_uppercase();
            position += 1;
            match command {
                'B' => {
                    state.blank_next = true;
                    continue;
                }
                'N' => {
                    state.return_next = true;
                    continue;
                }
                'C' => {
                    let index = parse_draw_integer(bytes, &mut position)?;
                    state.color = self.graphics.palette_color(index)?.to_string();
                    continue;
                }
                'A' => {
                    let angle = parse_draw_integer(bytes, &mut position)?;
                    if !(0..=7).contains(&angle) {
                        return Err(Error::IllegalQuantity);
                    }
                    state.angle_degrees = angle as f64 * 45.0;
                    continue;
                }
                'T' => {
                    if position >= bytes.len()
                        || !(bytes[position] as char).eq_ignore_ascii_case(&'A')
                    {
                        return Err(Error::syntax("DRAW T must be followed by A"));
                    }
                    position += 1;
                    let angle = parse_draw_number(bytes, &mut position)?;
                    if !(-360.0..=360.0).contains(&angle) {
                        return Err(Error::IllegalQuantity);
                    }
                    state.angle_degrees = angle;
                    continue;
                }
                'S' => {
                    let scale = parse_draw_integer(bytes, &mut position)?;
                    if !(0..=255).contains(&scale) {
                        return Err(Error::IllegalQuantity);
                    }
                    state.scale = scale as f64 / 4.0;
                    continue;
                }
                'X' => {
                    if depth >= MAX_DRAW_MACRO_DEPTH {
                        return Err(Error::syntax("DRAW X exceeds maximum recursion depth 16"));
                    }
                    let name = parse_draw_identifier(bytes, &mut position)?;
                    if self.effective_variable_type(&name) != VariableType::String {
                        return Err(Error::TypeMismatch);
                    }
                    let nested = self
                        .scalar_value(&name)?
                        .unwrap_or_else(|| Value::String(String::new()))
                        .into_string()
                        .ok_or(Error::TypeMismatch)?;
                    self.execute_draw_macro_inner(&nested, width, depth + 1, state)?;
                    continue;
                }
                'P' => {
                    let fill_index = parse_draw_integer(bytes, &mut position)?;
                    if position >= bytes.len() || bytes[position] != b',' {
                        return Err(Error::syntax("DRAW P requires fillcolor,bordercolor"));
                    }
                    position += 1;
                    let border_index = parse_draw_integer(bytes, &mut position)?;
                    let fill = self.graphics.palette_color(fill_index)?.to_string();
                    let _ = self.graphics.palette_color(border_index)?;
                    let (x, y) = self.graphics.cursor();
                    self.graphics.scene_mut().flood_fill(x, y, &fill)?;
                    continue;
                }
                'M' => {
                    let x = parse_draw_number(bytes, &mut position)?;
                    if position >= bytes.len() || bytes[position] != b',' {
                        return Err(Error::syntax("DRAW M requires x,y"));
                    }
                    position += 1;
                    let y = parse_draw_number(bytes, &mut position)?;
                    let (old_x, old_y) = self.graphics.cursor();
                    if !state.blank_next {
                        self.graphics
                            .scene_mut()
                            .line(old_x, old_y, x, y, &state.color, width)?;
                    }
                    self.graphics.set_cursor(x, y);
                    if state.return_next {
                        self.graphics.set_cursor(old_x, old_y);
                    }
                    state.blank_next = false;
                    state.return_next = false;
                    continue;
                }
                'U' | 'D' | 'L' | 'R' | 'E' | 'F' | 'G' | 'H' => {}
                _ => return Err(Error::syntax(format!("unsupported DRAW command {command}"))),
            }
            let distance = parse_draw_optional_number(bytes, &mut position)?.unwrap_or(1.0);
            if distance < 0.0 || !distance.is_finite() {
                return Err(Error::IllegalQuantity);
            }
            let distance = distance * state.scale;
            let (x0, y0) = self.graphics.cursor();
            let diagonal = distance / std::f64::consts::SQRT_2;
            let (dx, dy) = match command {
                'U' => (0.0, -distance),
                'D' => (0.0, distance),
                'L' => (-distance, 0.0),
                'R' => (distance, 0.0),
                'E' => (diagonal, -diagonal),
                'F' => (diagonal, diagonal),
                'G' => (-diagonal, diagonal),
                'H' => (-diagonal, -diagonal),
                _ => unreachable!(),
            };
            let radians = state.angle_degrees.to_radians();
            let rotated_dx = dx * radians.cos() + dy * radians.sin();
            let rotated_dy = -dx * radians.sin() + dy * radians.cos();
            let x1 = x0 + rotated_dx;
            let y1 = y0 + rotated_dy;
            if !state.blank_next {
                self.graphics
                    .scene_mut()
                    .line(x0, y0, x1, y1, &state.color, width)?;
            }
            self.graphics.set_cursor(x1, y1);
            if state.return_next {
                self.graphics.set_cursor(x0, y0);
            }
            state.blank_next = false;
            state.return_next = false;
        }
        Ok(())
    }

    fn evaluate_graphics_color(&mut self, tokens: &[TokenInstance]) -> Result<String, Error> {
        let value = self.evaluate_value(tokens)?;
        match value {
            Value::String(color) => Ok(color),
            numeric => {
                let index = BasicInteger::with_mode(self.mode, numeric.to_integer()?)?.value();
                Ok(self.graphics.palette_color(index)?.to_string())
            }
        }
    }

    fn evaluate_graphics_color_literal(
        &mut self,
        tokens: &[TokenInstance],
    ) -> Result<String, Error> {
        self.evaluate_graphics_color(tokens)
    }

    fn evaluate_graphics_color_or_none(
        &mut self,
        tokens: &[TokenInstance],
    ) -> Result<String, Error> {
        if graphics_mode_word(tokens).is_some_and(|word| word == "NONE") {
            return Ok("none".to_string());
        }
        self.evaluate_graphics_color(tokens)
    }

    fn graphics_identifier(&mut self, tokens: &[TokenInstance]) -> Result<String, Error> {
        if let [TokenInstance::Ident(name)] = tokens {
            if !is_string_variable(name) {
                return Ok(name.clone());
            }
        }
        self.evaluate_value(tokens)?
            .into_string()
            .ok_or(Error::TypeMismatch)
    }

    fn ensure_network_access(&self) -> Result<(), Error> {
        if self.network_enabled {
            Ok(())
        } else {
            Err(Error::NetworkAccessDisabled)
        }
    }

    fn resolve_playback_source(
        &mut self,
        value: &str,
        kind: ProgramMediaKind,
    ) -> Result<crate::media::MediaSource, Error> {
        self.ensure_media_prepared(value, kind)?;
        self.prepared_media
            .get(value)
            .cloned()
            .ok_or_else(|| Error::syntax("media asset was not prepared by LOAD"))
    }

    fn execute_web_statement(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (command_token, tail) = rest
            .split_first()
            .ok_or_else(|| Error::syntax("WEB requires OPEN, GET, POST, or DOWNLOAD"))?;
        let command = token_command_word(command_token)
            .ok_or_else(|| Error::syntax("WEB requires OPEN, GET, POST, or DOWNLOAD"))?;
        let arguments = split_graph_arguments(tail)?;

        match command {
            "OPEN" => {
                expect_graph_arity("WEB OPEN", &arguments, 1, 1)?;
                let url = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                self.ensure_network_access()?;
                crate::network::open_browser(&url)?;
            }
            "GET" => {
                expect_graph_arity("WEB GET", &arguments, 2, 2)?;
                let destination = parse_list_lvalue(arguments[1], "WEB GET")?;
                if !self.is_string_destination(&destination.name) {
                    return Err(Error::TypeMismatch);
                }
                self.ensure_assignable(&destination.name)?;
                let url = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                self.ensure_network_access()?;
                let bytes = crate::network::fetch(
                    &url,
                    WebMethod::Get,
                    self.max_network_bytes.min(self.max_string_bytes),
                )?;
                let text = String::from_utf8(bytes).map_err(|_| {
                    Error::syntax("WEB GET response is not UTF-8; use WEB DOWNLOAD")
                })?;
                self.assign_lvalue(destination, Value::String(text))?;
            }
            "POST" => {
                expect_graph_arity("WEB POST", &arguments, 3, 4)?;
                let destination = parse_list_lvalue(arguments[2], "WEB POST")?;
                if !self.is_string_destination(&destination.name) {
                    return Err(Error::TypeMismatch);
                }
                self.ensure_assignable(&destination.name)?;
                let url = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let body = self
                    .evaluate_value(arguments[1])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let content_type = arguments
                    .get(3)
                    .map(|argument| {
                        self.evaluate_value(argument)?
                            .into_string()
                            .ok_or(Error::TypeMismatch)
                    })
                    .transpose()?
                    .unwrap_or_else(|| "application/json".to_string());
                self.ensure_network_access()?;
                let bytes = crate::network::fetch(
                    &url,
                    WebMethod::Post {
                        body: body.as_bytes(),
                        content_type: &content_type,
                    },
                    self.max_network_bytes.min(self.max_string_bytes),
                )?;
                let text = String::from_utf8(bytes).map_err(|_| {
                    Error::syntax("WEB POST response is not UTF-8; use WEB DOWNLOAD")
                })?;
                self.assign_lvalue(destination, Value::String(text))?;
            }
            "DOWNLOAD" => {
                expect_graph_arity("WEB DOWNLOAD", &arguments, 2, 2)?;
                let url = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let path = self
                    .evaluate_value(arguments[1])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                self.outputs.output_path(&path)?;
                self.ensure_network_access()?;
                let limit = self.max_network_bytes.min(self.outputs.max_file_bytes());
                let bytes = crate::network::fetch(&url, WebMethod::Get, limit)?;
                self.outputs.write_all(&path, &bytes)?;
            }
            _ => return Err(Error::syntax("WEB requires OPEN, GET, POST, or DOWNLOAD")),
        }
        Ok(Control::Advance)
    }

    fn execute_chdir(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("CHDIR requires a directory path"));
        }
        let path = self
            .evaluate_value(rest)?
            .into_string()
            .ok_or(Error::TypeMismatch)?;
        self.files.change_dir(&path)?;
        Ok(Control::Advance)
    }

    fn execute_screen_control(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let arguments = split_graph_arguments(rest)?;
        expect_graph_arity("SCREENCONTROL", &arguments, 2, 2)?;
        let flag = self.evaluate_integer(arguments[0])?;
        let event = match flag {
            0 => ScreenEvent::SetTitle(
                self.evaluate_value(arguments[1])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?,
            ),
            1 => ScreenEvent::SetFullscreen(self.evaluate_integer(arguments[1])? != 0),
            2 => ScreenEvent::SetResizable(self.evaluate_integer(arguments[1])? != 0),
            3 => ScreenEvent::SetPointerVisible(self.evaluate_integer(arguments[1])? != 0),
            _ => return Err(Error::IllegalQuantity),
        };
        emit_screen_event(event);
        Ok(Control::Advance)
    }

    fn send_screen_event(&mut self, event: ScreenEvent) -> bool {
        if self.screen_lock_depth > 0 && matches!(event, ScreenEvent::Present { .. }) {
            self.pending_screen_present = Some(event);
            true
        } else {
            emit_screen_event(event)
        }
    }

    fn flush_screen_lock(&mut self) {
        if self.presentation_dirty && self.graphics.drawing_is_visible() && screen_attached() {
            self.pending_screen_present = None;
            let view = self.graphics_presentation_view();
            self.screen_view = view;
            if self.presentation_render_failed {
                self.present_graphics_scene(false, view);
                return;
            }
            let presented = emit_screen_event(ScreenEvent::Present {
                artist_source: self.graphics.scene_source(),
                raster_ppm: None,
                view,
            });
            if presented {
                self.graphics.mark_scene_presented();
                self.presentation_dirty = false;
            }
            return;
        }
        if let Some(event) = self.pending_screen_present.take() {
            emit_screen_event(event);
        }
    }

    fn release_screen_locks(&mut self) {
        self.screen_lock_depth = 0;
        self.flush_screen_lock();
    }

    fn present_media_frame(
        &mut self,
        label: &str,
        frame_index: usize,
        ppm: Arc<[u8]>,
    ) -> Result<(), Error> {
        if take_interrupt() {
            return Err(Error::Break);
        }
        let (width, height) = self.graphics.dimensions();
        let view = self.graphics_presentation_view();
        self.screen_view = view;
        self.last_raster_source = None;
        self.last_raster_ppm = Some(Arc::clone(&ppm));
        if screen_attached() {
            self.send_screen_event(ScreenEvent::Present {
                artist_source: format!(
                    "canvas {width} {height} #000000\n# {label} frame {}\n",
                    frame_index + 1
                ),
                raster_ppm: Some(ppm),
                view,
            });
        }
        Ok(())
    }

    fn play_flipbook(&mut self, id: &str, loops: i64) -> Result<(), Error> {
        if !(1..=1_000).contains(&loops) {
            return Err(Error::IllegalQuantity);
        }
        let id = id.to_ascii_uppercase();
        let sequence = self
            .flipbooks
            .get(&id)
            .cloned()
            .ok_or_else(|| Error::syntax(format!("undefined FLIPBOOK {id}")))?;
        let (width, height) = self.graphics.dimensions();
        let paced = screen_attached();
        let frame_time = Duration::from_secs_f64(1.0 / sequence.fps() as f64);
        let mut deadline = Instant::now();
        for _ in 0..loops {
            sequence.stream_frames(width, height, |frame_index, ppm| {
                self.present_media_frame(sequence.id(), frame_index, ppm)?;
                if paced {
                    deadline += frame_time;
                    if let Some(remaining) = deadline.checked_duration_since(Instant::now()) {
                        std::thread::sleep(remaining);
                    }
                }
                Ok(())
            })?;
        }
        Ok(())
    }

    fn play_video_source(&mut self, source: &crate::media::MediaSource) -> Result<(), Error> {
        let fps = crate::media::video_frame_rate(source)?;
        crate::media::play_audio(&self.playback, source.clone())?;
        let (width, height) = self.graphics.dimensions();
        let paced = screen_attached();
        let frame_time = Duration::from_secs_f64(1.0 / fps);
        let mut deadline = Instant::now();
        crate::media::stream_video(source, width, height, |frame_index, ppm| {
            self.present_media_frame("video", frame_index, ppm)?;
            if paced {
                deadline += frame_time;
                if let Some(remaining) = deadline.checked_duration_since(Instant::now()) {
                    std::thread::sleep(remaining);
                }
            }
            Ok(())
        })?;
        Ok(())
    }

    fn graphics_presentation_view(&self) -> ScreenView {
        if self.screen_view == ScreenView::Split {
            ScreenView::Split
        } else {
            ScreenView::Graphics
        }
    }

    fn present_dirty_graphics_scene(&mut self) {
        if self.graphics.scene_is_dirty() {
            self.presentation_dirty = true;
        }
        if !self.presentation_dirty
            || !self.graphics.drawing_is_visible()
            || !screen_attached()
            || self.screen_lock_depth > 0
        {
            return;
        }
        let view = self.graphics_presentation_view();
        self.screen_view = view;
        if self.presentation_render_failed {
            self.present_graphics_scene(false, view);
            return;
        }
        let presented = emit_screen_event(ScreenEvent::Present {
            artist_source: self.graphics.scene_source(),
            raster_ppm: None,
            view,
        });
        if presented {
            self.graphics.mark_scene_presented();
            self.presentation_dirty = false;
        }
    }

    fn render_graphics_source(&mut self, source: &str) -> Result<Arc<[u8]>, Error> {
        if self.last_raster_source.as_deref() == Some(source) {
            if let Some(ppm) = &self.last_raster_ppm {
                return Ok(Arc::clone(ppm));
            }
        }
        let ppm: Arc<[u8]> = crate::artist_renderer::render_ppm(source)?.into();
        self.last_raster_source = Some(source.to_string());
        self.last_raster_ppm = Some(Arc::clone(&ppm));
        Ok(ppm)
    }

    fn present_graphics_scene(&mut self, displayed: bool, view: ScreenView) -> bool {
        if !screen_attached() {
            return false;
        }
        let artist_source = if displayed {
            self.graphics.displayed_scene_source()
        } else {
            self.graphics.scene_source()
        };
        let raster_ppm = match self.render_graphics_source(&artist_source) {
            Ok(raster) => {
                self.presentation_render_failed = false;
                Some(raster)
            }
            Err(error) => {
                self.report_screen_error(&error);
                // Preserve both dirty states so a later statement boundary can
                // retry after a transient renderer failure.
                self.presentation_dirty = true;
                self.presentation_render_failed = true;
                return false;
            }
        };
        let presented = self.send_screen_event(ScreenEvent::Present {
            artist_source,
            raster_ppm,
            view,
        });
        if presented {
            self.graphics.mark_scene_presented();
            self.presentation_dirty = false;
        }
        presented
    }

    fn report_screen_error(&self, error: &Error) {
        // The shell records SetError in its diagnostic log and keeps the
        // message visible instead of replacing it with a stale frame.
        emit_screen_event(ScreenEvent::SetError(format!(
            "graphics renderer failed: {error}"
        )));
    }

    fn queue_play_sequence(&mut self, voice: i64, sequence: &str, beats: f64) -> Result<(), Error> {
        let explicit_sampled_routes = self.synth.explicit_sampled_play_routes();
        if !self.sf_engine.is_loaded()
            && self.synth.play_sequence_uses_route(
                voice,
                sequence,
                beats,
                explicit_sampled_routes,
            )?
        {
            self.load_soundfont_device()?;
        }
        if self.sf_engine.is_loaded() {
            let sampled_routes = self.synth.sampled_play_routes();
            self.sf_engine.queue_play_sequence(
                voice,
                sequence,
                beats,
                self.synth.tempo_bpm(),
                &mut self.play_positions_seconds,
                sampled_routes,
            )?;
            let routes = self.synth.native_play_routes();
            if routes.iter().any(|route| *route) {
                self.synth
                    .play_sequence_routed(voice, sequence, beats, routes)?;
            }
        } else {
            self.sf_engine.queue_play_sequence(
                voice,
                sequence,
                beats,
                self.synth.tempo_bpm(),
                &mut self.play_positions_seconds,
                [false; crate::synth::VOICE_COUNT],
            )?;
            self.synth.play_sequence(voice, sequence, beats)?;
        }
        Ok(())
    }

    fn convert_mml(&mut self, source: &str) -> Result<String, Error> {
        let mut state = self.mml_state.clone();
        let mut events = Vec::new();
        self.parse_mml_inner(source, 0, self.synth.tempo_bpm(), &mut state, &mut events)?;
        if events.is_empty() {
            return Err(Error::syntax(
                "PLAY MML requires at least one note or pause",
            ));
        }

        let mut tokens = Vec::new();
        let mut position = 0usize;
        while position < events.len() {
            let event = &events[position];
            if event.note.is_none() {
                if event.tied_to_next {
                    return Err(Error::syntax("PLAY MML cannot tie a pause"));
                }
                tokens.push(format!("R:{}", event.beats));
                position += 1;
                continue;
            }
            let note = event.note.as_ref().expect("checked MML note");
            let articulation = event.articulation;
            let mut duration = event.beats;
            while events[position].tied_to_next {
                position += 1;
                let Some(next) = events.get(position) else {
                    return Err(Error::syntax("PLAY MML tie requires another note"));
                };
                if next.note.as_ref() != Some(note) {
                    return Err(Error::syntax("PLAY MML ties require matching pitches"));
                }
                duration += next.beats;
            }
            let gate = match articulation {
                MmlArticulation::Normal => 0.875,
                MmlArticulation::Staccato => 0.75,
                MmlArticulation::Legato => 1.0,
            };
            let sounding = duration * gate;
            tokens.push(format!("{note}:{sounding}"));
            if gate < 1.0 {
                tokens.push(format!("R:{}", duration - sounding));
            }
            position += 1;
        }
        self.mml_state = state;
        Ok(tokens.join(" "))
    }

    fn parse_mml_inner(
        &mut self,
        source: &str,
        depth: usize,
        playback_tempo: f64,
        state: &mut MmlState,
        events: &mut Vec<MmlEvent>,
    ) -> Result<(), Error> {
        const MAX_MML_DEPTH: usize = 16;
        let bytes = source.as_bytes();
        let mut position = 0usize;
        while position < bytes.len() {
            while position < bytes.len()
                && (bytes[position].is_ascii_whitespace() || matches!(bytes[position], b',' | b';'))
            {
                position += 1;
            }
            if position >= bytes.len() {
                break;
            }
            let command = (bytes[position] as char).to_ascii_uppercase();
            position += 1;
            match command {
                'O' => {
                    let octave = parse_mml_number(bytes, &mut position)?;
                    if octave > 6 {
                        return Err(Error::IllegalQuantity);
                    }
                    state.octave = octave as u8;
                }
                'L' => {
                    let length = parse_mml_number(bytes, &mut position)?;
                    if !(1..=64).contains(&length) {
                        return Err(Error::IllegalQuantity);
                    }
                    state.length = length as u8;
                }
                'T' => {
                    let tempo = parse_mml_number(bytes, &mut position)?;
                    if !(32..=255).contains(&tempo) {
                        return Err(Error::IllegalQuantity);
                    }
                    state.tempo = tempo as u16;
                }
                'M' => {
                    let mode = bytes
                        .get(position)
                        .map(|byte| (*byte as char).to_ascii_uppercase())
                        .ok_or_else(|| Error::syntax("PLAY MML M requires N, S, L, B, or F"))?;
                    position += 1;
                    match mode {
                        'N' => state.articulation = MmlArticulation::Normal,
                        'S' => state.articulation = MmlArticulation::Staccato,
                        'L' => state.articulation = MmlArticulation::Legato,
                        'B' => state.background = true,
                        'F' => state.background = false,
                        _ => return Err(Error::syntax("PLAY MML M requires N, S, L, B, or F")),
                    }
                }
                'X' => {
                    if depth >= MAX_MML_DEPTH {
                        return Err(Error::syntax("PLAY MML X exceeds recursion depth 16"));
                    }
                    let name = parse_mml_identifier(bytes, &mut position)?;
                    if self.effective_variable_type(&name) != VariableType::String {
                        return Err(Error::TypeMismatch);
                    }
                    let nested = self
                        .scalar_value(&name)?
                        .unwrap_or_else(|| Value::String(String::new()))
                        .into_string()
                        .ok_or(Error::TypeMismatch)?;
                    self.parse_mml_inner(&nested, depth + 1, playback_tempo, state, events)?;
                }
                '<' => {
                    state.octave = state.octave.checked_sub(1).ok_or(Error::IllegalQuantity)?;
                }
                '>' => {
                    if state.octave == 6 {
                        return Err(Error::IllegalQuantity);
                    }
                    state.octave += 1;
                }
                'A'..='G' | 'P' => {
                    let note = if command == 'P' {
                        None
                    } else {
                        let accidental = match bytes.get(position).copied() {
                            Some(b'#' | b'+') => {
                                position += 1;
                                "#"
                            }
                            Some(b'-') => {
                                position += 1;
                                "B"
                            }
                            _ => "",
                        };
                        Some(format!("{command}{accidental}{}", state.octave))
                    };
                    let length = parse_mml_optional_number(bytes, &mut position)?
                        .unwrap_or(u16::from(state.length));
                    if !(1..=64).contains(&length) {
                        return Err(Error::IllegalQuantity);
                    }
                    let mut dot_value = 0.5;
                    let mut length_factor = 1.0;
                    while matches!(bytes.get(position), Some(b'.')) {
                        length_factor += dot_value;
                        dot_value *= 0.5;
                        position += 1;
                    }
                    while position < bytes.len() && bytes[position].is_ascii_whitespace() {
                        position += 1;
                    }
                    let tied_to_next = matches!(bytes.get(position), Some(b'&'));
                    if tied_to_next {
                        position += 1;
                    }
                    let beats = (4.0 / f64::from(length)) * length_factor * playback_tempo
                        / f64::from(state.tempo);
                    events.push(MmlEvent {
                        note,
                        beats,
                        articulation: state.articulation,
                        tied_to_next,
                    });
                }
                '&' => return Err(Error::syntax("PLAY MML tie must follow a note")),
                _ => {
                    return Err(Error::syntax(format!(
                        "unsupported PLAY MML command {command}"
                    )))
                }
            }
        }
        Ok(())
    }

    fn execute_synth_statement(
        &mut self,
        name: &str,
        rest: &[TokenInstance],
    ) -> Result<Control, Error> {
        // SOUND sub-commands: ON, OFF, WAIT, RESUME.
        if name == "SOUND" {
            if let Some((command_token, tail)) = rest.split_first() {
                if let Some(command) = token_command_word(command_token) {
                    match command {
                        "ON" => {
                            expect_end_of_line(tail)?;
                            self.synth.set_enabled(true);
                            return Ok(Control::Advance);
                        }
                        "OFF" => {
                            expect_end_of_line(tail)?;
                            self.synth.set_enabled(false);
                            self.playback.stop();
                            self.speech.stop();
                            return Ok(Control::Advance);
                        }
                        "WAIT" => {
                            expect_end_of_line(tail)?;
                            return Ok(Control::Advance);
                        }
                        "RESUME" => {
                            expect_end_of_line(tail)?;
                            self.play_queued_audio()?;
                            return Ok(Control::Advance);
                        }
                        _ => {}
                    }
                }
            }
        }
        if name == "PLAY" {
            if let Some((command_token, tail)) = rest.split_first() {
                if let Some(command) = token_command_word(command_token) {
                    match command {
                        "MML" => {
                            let expression =
                                tail.strip_prefix(&[TokenInstance::Comma]).unwrap_or(tail);
                            if expression.is_empty() {
                                return Err(Error::syntax("PLAY MML requires a string"));
                            }
                            let source = self
                                .evaluate_value(expression)?
                                .into_string()
                                .ok_or(Error::TypeMismatch)?;
                            let sequence = self.convert_mml(&source)?;
                            let voice = (self.synth.selected_voice() + 1) as i64;
                            self.queue_play_sequence(voice, &sequence, 1.0)?;
                            if !self.mml_state.background {
                                self.play_queued_audio()?;
                                self.playback.wait()?;
                                self.synth.clear();
                                self.sf_engine.clear_score();
                                self.play_positions_seconds = [0.0; crate::synth::VOICE_COUNT];
                            }
                            return Ok(Control::Advance);
                        }
                        "AUDIO" => {
                            let arguments = split_graph_arguments(tail)?;
                            expect_graph_arity("PLAY AUDIO", &arguments, 1, 1)?;
                            let path = self
                                .evaluate_value(arguments[0])?
                                .into_string()
                                .ok_or(Error::TypeMismatch)?;
                            let source =
                                self.resolve_playback_source(&path, ProgramMediaKind::Audio)?;
                            crate::media::play_audio(&self.playback, source)?;
                            return Ok(Control::Advance);
                        }
                        "VIDEO" => {
                            let arguments = split_graph_arguments(tail)?;
                            expect_graph_arity("PLAY VIDEO", &arguments, 1, 1)?;
                            let path = self
                                .evaluate_value(arguments[0])?
                                .into_string()
                                .ok_or(Error::TypeMismatch)?;
                            let source =
                                self.resolve_playback_source(&path, ProgramMediaKind::Video)?;
                            self.play_video_source(&source)?;
                            return Ok(Control::Advance);
                        }
                        "FLIPBOOK" => {
                            let arguments = split_graph_arguments(tail)?;
                            expect_graph_arity("PLAY FLIPBOOK", &arguments, 1, 3)?;
                            let id = self.graphics_identifier(arguments[0])?;
                            let loops = arguments
                                .get(1)
                                .map(|argument| self.evaluate_integer(argument))
                                .transpose()?
                                .unwrap_or(1);
                            if let Some(soundtrack) = arguments.get(2) {
                                let path = self
                                    .evaluate_value(soundtrack)?
                                    .into_string()
                                    .ok_or(Error::TypeMismatch)?;
                                let source =
                                    self.resolve_playback_source(&path, ProgramMediaKind::Audio)?;
                                crate::media::play_audio(&self.playback, source)?;
                            }
                            self.play_flipbook(&id, loops)?;
                            return Ok(Control::Advance);
                        }
                        _ => {}
                    }
                }
            }
        }
        let arguments = split_graph_arguments(rest)?;
        match name {
            "SYNTHPROFILE" => {
                expect_graph_arity(name, &arguments, 1, 1)?;
                let profile = SynthProfile::parse(&synth_word(arguments[0], self)?)?;
                self.synth.configure_arrangement(profile.arrangement())?;
            }
            "VOICES" => {
                expect_graph_arity(name, &arguments, 1, 1)?;
                let count = self.evaluate_integer(arguments[0])?;
                self.synth.set_voice_count(count)?;
            }
            "OSCILLATORS" => {
                expect_graph_arity(name, &arguments, 1, 1)?;
                let count = self.evaluate_integer(arguments[0])?;
                self.synth.set_oscillator_count(count)?;
            }
            "TEMPO" => {
                expect_graph_arity(name, &arguments, 1, 1)?;
                let bpm = self.evaluate_graph_real(arguments[0])?;
                self.synth.set_tempo(bpm)?;
            }
            // VOICE n — select voice n (1, 2, 3, ...)
            "VOICE" => {
                expect_graph_arity(name, &arguments, 1, 1)?;
                let voice = self.evaluate_integer(arguments[0])?;
                self.synth.select_voice(voice)?;
            }
            // OSCILLATOR voice,slot,waveform,ratio,detune-cents,level
            // Each native voice owns the configured number of tuned oscillator layers.
            "OSCILLATOR" => {
                expect_graph_arity(name, &arguments, 6, 6)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let oscillator = self.evaluate_integer(arguments[1])?;
                let waveform = Waveform::parse(&synth_word(arguments[2], self)?)?;
                let ratio = self.evaluate_graph_real(arguments[3])?;
                let detune_cents = self.evaluate_graph_real(arguments[4])?;
                let level = self.evaluate_graph_real(arguments[5])?;
                self.synth.set_oscillator(
                    voice,
                    oscillator,
                    waveform,
                    ratio,
                    detune_cents,
                    level,
                )?;
            }
            // WAVE is the recommended spelling; WAVEFORM remains accepted.
            "WAVEFORM" | "WAVE" => {
                expect_graph_arity(name, &arguments, 1, 3)?;
                // WAVEFORM "name"              — selected voice
                // WAVEFORM voice, "name"       — explicit voice
                // WAVEFORM voice, 3            — numeric waveform id
                // WAVEFORM voice, "name", pw   — with pulse width
                // WAVEFORM voice, "0.0,0.5,...— custom wave table
                let (voice, wave_arg, width_arg) = if arguments.len() == 1 {
                    ((self.synth.selected_voice() + 1) as i64, 0, None)
                } else {
                    (self.evaluate_integer(arguments[0])?, 1, arguments.get(2))
                };
                let definition = match arguments[wave_arg].first() {
                    Some(TokenInstance::Number(n)) => waveform_from_numeric(*n)?,
                    Some(TokenInstance::Real(s)) => {
                        let n: i64 = s.parse().unwrap_or(-1);
                        waveform_from_numeric(n)?
                    }
                    _ => synth_word(arguments[wave_arg], self)?,
                };
                if let Ok(waveform) = Waveform::parse(&definition) {
                    self.synth.set_waveform(voice, waveform)?;
                } else {
                    let samples = parse_wave_samples(&definition)?;
                    self.synth.set_wave_table(voice, &samples)?;
                    self.synth.set_waveform(voice, Waveform::Custom)?;
                }
                if let Some(width) = width_arg {
                    let width = self.evaluate_graph_real(width)?;
                    self.synth.set_pulse_width(voice, width)?;
                }
            }
            // ADSR is the canonical name. ENVELOPE is an alias.
            "ADSR" | "ENVELOPE" => {
                expect_graph_arity(name, &arguments, 4, 5)?;
                let (voice, offset) = if arguments.len() == 4 {
                    ((self.synth.selected_voice() + 1) as i64, 0)
                } else {
                    (self.evaluate_integer(arguments[0])?, 1)
                };
                let attack = self.evaluate_graph_real(arguments[offset])?;
                let decay = self.evaluate_graph_real(arguments[offset + 1])?;
                let sustain = self.evaluate_graph_real(arguments[offset + 2])?;
                let release = self.evaluate_graph_real(arguments[offset + 3])?;
                self.synth
                    .set_envelope(voice, attack, decay, sustain, release)?;
            }
            // PULSEWIDTH sets the duty cycle for one oscillator. The compact
            // forms continue to address oscillator 1.
            "PULSEWIDTH" => {
                expect_graph_arity(name, &arguments, 1, 3)?;
                let (voice, oscillator, width) = if arguments.len() == 1 {
                    (
                        (self.synth.selected_voice() + 1) as i64,
                        1,
                        self.evaluate_graph_real(arguments[0])?,
                    )
                } else if arguments.len() == 2 {
                    (
                        self.evaluate_integer(arguments[0])?,
                        1,
                        self.evaluate_graph_real(arguments[1])?,
                    )
                } else {
                    (
                        self.evaluate_integer(arguments[0])?,
                        self.evaluate_integer(arguments[1])?,
                        self.evaluate_graph_real(arguments[2])?,
                    )
                };
                self.synth
                    .set_oscillator_pulse_width(voice, oscillator, width)?;
            }
            // VOL is the sole volume statement.
            // VOL level           — master volume
            // VOL voice, level    — per-voice volume
            "VOL" => {
                expect_graph_arity(name, &arguments, 1, 2)?;
                if arguments.len() == 1 {
                    let volume = self.evaluate_graph_real(arguments[0])?;
                    self.synth.set_master_volume(volume)?;
                } else {
                    let voice = self.evaluate_integer(arguments[0])?;
                    let volume = self.evaluate_graph_real(arguments[1])?;
                    self.synth.set_volume(voice, volume)?;
                }
            }
            "STEREO" => {
                expect_graph_arity(name, &arguments, 2, 2)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let pan = self.evaluate_graph_real(arguments[1])?;
                self.synth.set_pan(voice, pan)?;
            }
            // MIXER voice,synth-level,midi-level
            // Zero disables a destination; nonzero levels select synth, MIDI,
            // or both for subsequent PLAY notes on this BASIC voice.
            "MIXER" => {
                expect_graph_arity(name, &arguments, 3, 3)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let native_level = self.evaluate_graph_real(arguments[1])?;
                let sampled_level = self.evaluate_graph_real(arguments[2])?;
                self.synth
                    .set_voice_mix(voice, native_level, sampled_level)?;
            }
            // PAN sets the stereo position for the currently selected voice.
            "PAN" => {
                expect_graph_arity(name, &arguments, 1, 1)?;
                let voice = (self.synth.selected_voice() + 1) as i64;
                let pan = self.evaluate_graph_real(arguments[0])?;
                self.synth.set_pan(voice, pan)?;
            }
            // General MIDI channel controls for sampled SoundFont instruments.
            // Levels are normalized 0..1 at the BASIC boundary.
            "EXPRESSION" | "MODULATION" | "SUSTAIN" | "REVERB" | "CHORUS" => {
                expect_graph_arity(name, &arguments, 2, 2)?;
                let voice = self.evaluate_integer(arguments[0])?;
                crate::synth::midi_channel_for_voice(voice)?;
                let level = self.evaluate_graph_real(arguments[1])?;
                let amount = normalized_midi_level(level)?;
                if !self.sf_engine.is_loaded() {
                    self.load_soundfont_device()?;
                }
                let controller = match name {
                    "MODULATION" => 1,
                    "EXPRESSION" => 11,
                    "SUSTAIN" => 64,
                    "REVERB" => 91,
                    "CHORUS" => 93,
                    _ => unreachable!(),
                };
                self.sf_engine
                    .set_controller_for_voice(voice, controller, amount)?;
            }
            // PITCHBEND uses a normalized -1..1 position. The SoundFont
            // device standard bend range is two semitones in either direction.
            "PITCHBEND" => {
                expect_graph_arity(name, &arguments, 2, 2)?;
                let voice = self.evaluate_integer(arguments[0])?;
                crate::synth::midi_channel_for_voice(voice)?;
                let amount = self.evaluate_graph_real(arguments[1])?;
                let bend = normalized_midi_pitch_bend(amount)?;
                if !self.sf_engine.is_loaded() {
                    self.load_soundfont_device()?;
                }
                self.sf_engine.set_pitch_bend_for_voice(voice, bend)?;
            }
            // DSP voice,drive,tone,presence,compression,gate
            // All values are normalized 0..1 and apply only to that sampled
            // voice before the complete score is mixed.
            "DSP" => {
                expect_graph_arity(name, &arguments, 6, 6)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let drive = self.evaluate_graph_real(arguments[1])?;
                let tone = self.evaluate_graph_real(arguments[2])?;
                let presence = self.evaluate_graph_real(arguments[3])?;
                let compression = self.evaluate_graph_real(arguments[4])?;
                let gate = self.evaluate_graph_real(arguments[5])?;
                self.synth
                    .set_sampled_dsp(voice, drive, tone, presence, compression, gate)?;
            }
            "FILTER" => {
                expect_graph_arity(name, &arguments, 2, 5)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let mode = FilterMode::parse(&synth_word(arguments[1], self)?)?;
                let cutoff = arguments
                    .get(2)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(4_000.0);
                let resonance = arguments
                    .get(3)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(0.0);
                let key_track = arguments
                    .get(4)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(0.0);
                self.synth
                    .set_filter(voice, mode, cutoff, resonance, key_track)?;
            }
            "FILTERADSR" => {
                expect_graph_arity(name, &arguments, 6, 6)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let attack = self.evaluate_graph_real(arguments[1])?;
                let decay = self.evaluate_graph_real(arguments[2])?;
                let sustain = self.evaluate_graph_real(arguments[3])?;
                let release = self.evaluate_graph_real(arguments[4])?;
                let amount = self.evaluate_graph_real(arguments[5])?;
                self.synth
                    .set_filter_envelope(voice, attack, decay, sustain, release, amount)?;
            }
            "LFO" => {
                expect_graph_arity(name, &arguments, 5, 5)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let target = LfoTarget::parse(&synth_word(arguments[1], self)?)?;
                let waveform = LfoWaveform::parse(&synth_word(arguments[2], self)?)?;
                let rate_hz = self.evaluate_graph_real(arguments[3])?;
                let depth = self.evaluate_graph_real(arguments[4])?;
                self.synth
                    .set_lfo(voice, target, waveform, rate_hz, depth)?;
            }
            "GLIDE" => {
                expect_graph_arity(name, &arguments, 2, 2)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let milliseconds = self.evaluate_graph_real(arguments[1])?;
                self.synth.set_glide(voice, milliseconds)?;
            }
            "DRIVE" => {
                expect_graph_arity(name, &arguments, 2, 2)?;
                let voice = self.evaluate_integer(arguments[0])?;
                let amount = self.evaluate_graph_real(arguments[1])?;
                self.synth.set_drive(voice, amount)?;
            }
            "PLAY" => {
                expect_graph_arity(name, &arguments, 1, 3)?;
                let first = self.evaluate_value(arguments[0])?;
                let (voice, sequence, beats_argument) = if arguments.len() >= 2
                    && first.is_numeric()
                {
                    let voice = BasicInteger::with_mode(self.mode, first.to_integer()?)?.value();
                    let sequence = self
                        .evaluate_value(arguments[1])?
                        .into_string()
                        .ok_or(Error::TypeMismatch)?;
                    (voice, sequence, arguments.get(2))
                } else {
                    let sequence = first.into_string().ok_or(Error::TypeMismatch)?;
                    (
                        (self.synth.selected_voice() + 1) as i64,
                        sequence,
                        arguments.get(1),
                    )
                };
                let beats = beats_argument
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(1.0);
                self.queue_play_sequence(voice, &sequence, beats)?;
            }
            "SAY" => {
                expect_graph_arity(name, &arguments, 1, 6)?;
                if !self.synth.is_enabled() {
                    return Ok(Control::Advance);
                }
                let text = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let rate = arguments
                    .get(1)
                    .map(|argument| self.evaluate_integer(argument))
                    .transpose()?
                    .unwrap_or(150);
                let pitch = arguments
                    .get(2)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(110.0);
                let volume = arguments
                    .get(3)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(1.0);
                let voice = arguments
                    .get(4)
                    .map(|argument| synth_word(argument, self))
                    .transpose()?
                    .unwrap_or_else(|| "en-us".to_string());
                let mode = arguments
                    .get(5)
                    .map(|argument| synth_word(argument, self))
                    .transpose()?
                    .map(|word| crate::speech::SpeechMode::parse(&word))
                    .transpose()?
                    .unwrap_or(crate::speech::SpeechMode::Queue);
                crate::speech::speak(&mut self.speech, &text, rate, pitch, volume, &voice, mode)?;
                if mode == crate::speech::SpeechMode::Interrupt {
                    self.singing_scores.clear();
                }
            }
            "SING" => {
                expect_graph_arity(name, &arguments, 2, 6)?;
                if !self.synth.is_enabled() {
                    return Ok(Control::Advance);
                }
                let lyrics = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let sequence = self
                    .evaluate_value(arguments[1])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let default_beats = arguments
                    .get(2)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(1.0);
                let volume = arguments
                    .get(3)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(1.0);
                let voice = arguments
                    .get(4)
                    .map(|argument| synth_word(argument, self))
                    .transpose()?
                    .unwrap_or_else(|| "en-us".to_string());
                let mode = arguments
                    .get(5)
                    .map(|argument| synth_word(argument, self))
                    .transpose()?
                    .map(|word| crate::speech::SpeechMode::parse(&word))
                    .transpose()?
                    .unwrap_or(crate::speech::SpeechMode::Wait);
                let score = crate::speech::sing_with_score(
                    &mut self.speech,
                    &lyrics,
                    &sequence,
                    default_beats,
                    self.synth.tempo_bpm(),
                    volume,
                    &voice,
                    mode,
                )?;
                if mode == crate::speech::SpeechMode::Interrupt {
                    self.singing_scores.clear();
                }
                self.singing_scores.push(score);
            }
            // SOUND generates an arbitrary-frequency tone on one configured
            // WAVE voice. PLAY separately interprets musical note notation.
            //   SOUND hz, voice, ms [, level] [, end_hz] [, steps]
            "SOUND" => {
                expect_graph_arity(name, &arguments, 3, 6)?;
                let start_hz = self.evaluate_graph_real(arguments[0])?;
                let voice = self.evaluate_integer(arguments[1])?;
                let duration_ms = self.evaluate_graph_real(arguments[2])?;
                let volume = arguments
                    .get(3)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?;
                let end_hz = arguments
                    .get(4)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?;
                let steps = arguments
                    .get(5)
                    .map(|argument| self.evaluate_integer(argument))
                    .transpose()?
                    .map(|count| usize::try_from(count).map_err(|_| Error::IllegalQuantity))
                    .transpose()?;
                if let Some(end_hz) = end_hz {
                    self.synth.play_sweep(
                        voice,
                        start_hz,
                        end_hz,
                        duration_ms,
                        volume,
                        None,
                        steps,
                    )?;
                } else {
                    self.synth
                        .play_tone(voice, start_hz, duration_ms, volume, None)?;
                }
            }
            "BEEP" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                let voice = (self.synth.selected_voice() + 1) as i64;
                self.synth.play_tone(voice, 880.0, 150.0, None, None)?;
            }
            // SOUNDFONT loads one global bank or binds a bank to BASIC voices.
            //   SOUNDFONT path$
            //   SOUNDFONT voice,path$
            //   SOUNDFONT first_voice,last_voice,path$
            "SOUNDFONT" => {
                expect_graph_arity(name, &arguments, 1, 3)?;
                if self.sf_engine.has_score() {
                    return Err(Error::syntax(
                        "SOUNDFONT must appear before sampled PLAY statements",
                    ));
                }
                let voice_range = match arguments.len() {
                    1 => None,
                    2 => {
                        let voice = self.evaluate_integer(arguments[0])?;
                        crate::synth::midi_channel_for_voice(voice)?;
                        Some((voice, voice))
                    }
                    3 => {
                        let first = self.evaluate_integer(arguments[0])?;
                        let last = self.evaluate_integer(arguments[1])?;
                        crate::synth::midi_channel_for_voice(first)?;
                        crate::synth::midi_channel_for_voice(last)?;
                        if last < first {
                            return Err(Error::IllegalQuantity);
                        }
                        Some((first, last))
                    }
                    _ => unreachable!(),
                };
                let path = self
                    .evaluate_value(arguments.last().expect("SOUNDFONT has an argument"))?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                if !path.to_ascii_lowercase().ends_with(".sf2") {
                    return Err(Error::syntax("SOUNDFONT requires a .sf2 bank"));
                }
                self.ensure_soundfont_prepared(&path)?;
                let cache_key = self
                    .prepared_soundfont_keys
                    .get(&path)
                    .ok_or_else(|| Error::syntax("SOUNDFONT asset was not prepared by LOAD"))?;
                if !self
                    .sf_engine
                    .activate_prepared_soundfont(cache_key, voice_range)?
                {
                    return Err(Error::syntax("SOUNDFONT asset was not prepared by LOAD"));
                }
                if let Some((first, last)) = voice_range {
                    for voice in first..=last {
                        self.play_positions_seconds[(voice - 1) as usize] = 0.0;
                    }
                } else {
                    self.play_positions_seconds = [0.0; crate::synth::VOICE_COUNT];
                }
            }
            // INSTRUMENT selects an instrument from the loaded SoundFont.
            //   INSTRUMENT voice, "ACOUSTIC GRAND PIANO"
            //   INSTRUMENT voice, 0
            // The SoundFont auto-loads from the configured default bank.
            "INSTRUMENT" => {
                expect_graph_arity(name, &arguments, 2, 2)?;
                let voice = self.evaluate_integer(arguments[0])?;
                if !self.sf_engine.is_loaded() {
                    self.load_soundfont_device()?;
                }
                match self.evaluate_value(arguments[1])? {
                    Value::String(instrument_name) => {
                        self.sf_engine
                            .select_instrument_by_name(voice, &instrument_name)?;
                    }
                    value => {
                        let program = value.to_integer()?;
                        if !(0..=127).contains(&program) {
                            return Err(Error::IllegalQuantity);
                        }
                        self.sf_engine
                            .select_instrument_for_voice(voice, program as u8)?;
                    }
                }
            }
            // WAVEFILE exports the rendered audio to a WAV file.
            "WAVEFILE" => {
                expect_graph_arity(name, &arguments, 1, 1)?;
                let path = self
                    .evaluate_value(arguments[0])?
                    .into_string()
                    .ok_or(Error::TypeMismatch)?;
                let wav = self.render_queued_audio_wav()?;
                self.outputs.write_all(&path, &wav)?;
                self.prepared_media.insert(
                    path.clone(),
                    crate::media::MediaSource::memory(Arc::from(wav), path),
                );
            }
            _ => {
                return Err(Error::syntax(format!(
                    "unsupported synthesizer statement {name}"
                )))
            }
        }
        Ok(Control::Advance)
    }

    fn execute_graph_statement(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (command, tail) = rest
            .split_first()
            .ok_or_else(|| Error::syntax("GRAPH requires a command"))?;
        let command =
            token_command_word(command).ok_or_else(|| Error::syntax("invalid GRAPH command"))?;
        match command {
            "CLEAR" => self.execute_ti_graph_statement("CLRDRAW", tail),
            "DISPLAY" => {
                if tail.is_empty() {
                    self.execute_ti_graph_statement("DISPGRAPH", tail)
                } else {
                    let arguments = split_graph_arguments(tail)?;
                    expect_graph_arity("GRAPH DISPLAY", &arguments, 1, 1)?;
                    let path = self
                        .evaluate_value(arguments[0])?
                        .into_string()
                        .ok_or(Error::TypeMismatch)?;
                    let old_output = self.graph_output.replace(self.outputs.output_path(&path)?);
                    let result = self.execute_ti_graph_statement("DISPGRAPH", &[]);
                    self.graph_output = old_output;
                    result
                }
            }
            "WINDOW" => {
                let arguments = split_graph_arguments(tail)?;
                expect_graph_arity("GRAPH WINDOW", &arguments, 6, 6)?;
                let x_min = self.evaluate_graph_real(arguments[0])?;
                let x_max = self.evaluate_graph_real(arguments[1])?;
                let x_scale = self.evaluate_graph_real(arguments[2])?;
                let y_min = self.evaluate_graph_real(arguments[3])?;
                let y_max = self.evaluate_graph_real(arguments[4])?;
                let y_scale = self.evaluate_graph_real(arguments[5])?;
                self.graph
                    .set_window(x_min, x_max, x_scale, y_min, y_max, y_scale)?;
                install_graph_system_variables(&mut self.vars, &self.graph)?;
                Ok(Control::Advance)
            }
            "FUNCTION" | "PLOT" => self.execute_ti_graph_statement("DRAWF", tail),
            "INVERSE" => self.execute_ti_graph_statement("DRAWINV", tail),
            "LINE" => self.execute_ti_graph_statement("GLINE", tail),
            "CIRCLE" => self.execute_ti_graph_statement("GCIRCLE", tail),
            "TEXT" => self.execute_ti_graph_statement("GTEXT", tail),
            "HORIZONTAL" | "VERTICAL" | "TANGENT" | "SHADE" => {
                self.execute_ti_graph_statement(command, tail)
            }
            "GRID" | "AXES" | "LABELS" | "COORDS" => {
                let (setting, extra) = tail
                    .split_first()
                    .ok_or_else(|| Error::syntax("GRAPH switch requires ON or OFF"))?;
                expect_end_of_line(extra)?;
                let setting = token_command_word(setting)
                    .ok_or_else(|| Error::syntax("GRAPH switch requires ON or OFF"))?;
                let mapped = match (command, setting) {
                    ("GRID", "ON") => "GRIDON",
                    ("GRID", "OFF") => "GRIDOFF",
                    ("AXES", "ON") => "AXESON",
                    ("AXES", "OFF") => "AXESOFF",
                    ("LABELS", "ON") => "LABELON",
                    ("LABELS", "OFF") => "LABELOFF",
                    ("COORDS", "ON") => "COORDON",
                    ("COORDS", "OFF") => "COORDOFF",
                    _ => return Err(Error::syntax("GRAPH switch requires ON or OFF")),
                };
                self.execute_ti_graph_statement(mapped, &[])
            }
            "ZOOM" => {
                let (kind, extra) = tail.split_first().ok_or_else(|| {
                    Error::syntax("GRAPH ZOOM requires STANDARD, TRIG, DECIMAL, or SQUARE")
                })?;
                expect_end_of_line(extra)?;
                let kind = token_command_word(kind)
                    .ok_or_else(|| Error::syntax("invalid GRAPH ZOOM mode"))?;
                let mapped = match kind {
                    "STANDARD" => "ZSTANDARD",
                    "TRIG" => "ZTRIG",
                    "DECIMAL" => "ZDECIMAL",
                    "SQUARE" => "ZSQUARE",
                    _ => return Err(Error::syntax("invalid GRAPH ZOOM mode")),
                };
                self.execute_ti_graph_statement(mapped, &[])
            }
            _ => Err(Error::syntax(format!(
                "unsupported GRAPH command {command}"
            ))),
        }
    }

    fn execute_ti_graph_statement(
        &mut self,
        name: &str,
        rest: &[TokenInstance],
    ) -> Result<Control, Error> {
        let arguments = split_graph_arguments(rest)?;
        match name {
            "CLRDRAW" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.clear_drawings();
            }
            "DISPGRAPH" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.sync_graph_window_from_variables()?;
                let output = self
                    .graph_output
                    .clone()
                    .unwrap_or_else(|| PathBuf::from("modernbasic-graph.svg"));
                let display = self.graph_with_enabled_functions()?;
                let source = display.to_artist_script();
                let view = self.graphics_presentation_view();
                self.screen_view = view;
                let attached_screen = if screen_attached() {
                    match crate::artist_renderer::render_ppm(&source) {
                        Ok(bytes) => self.send_screen_event(ScreenEvent::Present {
                            artist_source: source.clone(),
                            raster_ppm: Some(Arc::from(bytes)),
                            view,
                        }),
                        Err(error) => {
                            self.report_screen_error(&error);
                            false
                        }
                    }
                } else {
                    false
                };
                ArtistBackend::new().render_svg(
                    &source,
                    &output,
                    !attached_screen && self.open_graph_window,
                )?;
            }
            "ZSTANDARD" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.standard_window();
                install_graph_system_variables(&mut self.vars, &self.graph)?;
            }
            "ZTRIG" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.set_window(
                    -2.0 * std::f64::consts::PI,
                    2.0 * std::f64::consts::PI,
                    std::f64::consts::PI / 2.0,
                    -4.0,
                    4.0,
                    1.0,
                )?;
                install_graph_system_variables(&mut self.vars, &self.graph)?;
            }
            "ZDECIMAL" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.set_window(-4.7, 4.7, 1.0, -3.1, 3.1, 1.0)?;
                install_graph_system_variables(&mut self.vars, &self.graph)?;
            }
            "ZSQUARE" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.sync_graph_window_from_variables()?;
                let y_center = (self.graph.y_min + self.graph.y_max) / 2.0;
                let y_range = (self.graph.x_max - self.graph.x_min)
                    * (crate::ti_graph::TI_GRAPH_HEIGHT - 1) as f64
                    / (crate::ti_graph::TI_GRAPH_WIDTH - 1) as f64;
                self.graph.set_window(
                    self.graph.x_min,
                    self.graph.x_max,
                    self.graph.x_scale,
                    y_center - y_range / 2.0,
                    y_center + y_range / 2.0,
                    self.graph.y_scale,
                )?;
                install_graph_system_variables(&mut self.vars, &self.graph)?;
            }
            "AXESON" => {
                expect_graph_arity(name, &arguments, 0, 1)?;
                self.graph.axes = true;
                if let Some(color) = arguments.first() {
                    self.graph.axes_color = validate_ti_color(self.evaluate_integer(color)?)?;
                }
            }
            "AXESOFF" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.axes = false;
            }
            "GRIDON" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.grid = true;
            }
            "GRIDOFF" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.grid = false;
            }
            "LABELON" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.labels = true;
            }
            "LABELOFF" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.labels = false;
            }
            "COORDON" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.coordinates = true;
            }
            "COORDOFF" => {
                expect_graph_arity(name, &arguments, 0, 0)?;
                self.graph.coordinates = false;
            }
            "LINE" | "GLINE" => {
                expect_graph_arity(name, &arguments, 4, 7)?;
                self.sync_graph_window_from_variables()?;
                let x0 = self.evaluate_graph_real(arguments[0])?;
                let y0 = self.evaluate_graph_real(arguments[1])?;
                let x1 = self.evaluate_graph_real(arguments[2])?;
                let y1 = self.evaluate_graph_real(arguments[3])?;
                let erase = arguments
                    .get(4)
                    .map(|argument| self.evaluate_integer(argument))
                    .transpose()?
                    .is_some_and(|value| value != 0);
                let color = arguments
                    .get(5)
                    .map(|argument| self.evaluate_integer(argument))
                    .transpose()?
                    .map(validate_ti_color)
                    .transpose()?
                    .unwrap_or(12);
                if let Some(style) = arguments.get(6) {
                    let style = self.evaluate_integer(style)?;
                    if !(1..=2).contains(&style) {
                        return Err(Error::IllegalQuantity);
                    }
                }
                self.graph
                    .draw_line(x0, y0, x1, y1, (!erase).then_some(color));
            }
            "HORIZONTAL" | "VERTICAL" => {
                expect_graph_arity(name, &arguments, 1, 2)?;
                self.sync_graph_window_from_variables()?;
                let coordinate = self.evaluate_graph_real(arguments[0])?;
                let color = self.graph_color_argument(arguments.get(1), 12)?;
                if name == "HORIZONTAL" {
                    self.graph.draw_horizontal(coordinate, Some(color));
                } else {
                    self.graph.draw_vertical(coordinate, Some(color));
                }
            }
            "CIRCLE" | "GCIRCLE" => {
                expect_graph_arity(name, &arguments, 3, 5)?;
                self.sync_graph_window_from_variables()?;
                let x = self.evaluate_graph_real(arguments[0])?;
                let y = self.evaluate_graph_real(arguments[1])?;
                let radius = self.evaluate_graph_real(arguments[2])?;
                if radius < 0.0 {
                    return Err(Error::IllegalQuantity);
                }
                let color = self.graph_color_argument(arguments.get(3), 12)?;
                if let Some(style) = arguments.get(4) {
                    let style = self.evaluate_integer(style)?;
                    if !(1..=2).contains(&style) {
                        return Err(Error::IllegalQuantity);
                    }
                }
                self.graph.draw_circle(x, y, radius, Some(color));
            }
            "DRAWF" | "DRAWINV" => {
                expect_graph_arity(name, &arguments, 1, 2)?;
                self.sync_graph_window_from_variables()?;
                let color = self.graph_color_argument(arguments.get(1), 12)?;
                let samples = self.sample_graph_expression(arguments[0])?;
                let mut samples = samples.into_iter();
                self.graph
                    .draw_function(name == "DRAWINV", Some(color), |_| samples.next().flatten());
            }
            "TANGENT" => {
                expect_graph_arity(name, &arguments, 2, 3)?;
                self.sync_graph_window_from_variables()?;
                let at = self.evaluate_graph_real(arguments[1])?;
                let color = self.graph_color_argument(arguments.get(2), 12)?;
                let samples = self.sample_graph_expression(arguments[0])?;
                let position = ((at - self.graph.x_min) / (self.graph.x_max - self.graph.x_min)
                    * (samples.len() - 1) as f64)
                    .round();
                if !position.is_finite() || position < 1.0 || position >= (samples.len() - 1) as f64
                {
                    return Err(Error::IllegalQuantity);
                }
                let index = position as usize;
                let (Some(left), Some(center), Some(right)) =
                    (samples[index - 1], samples[index], samples[index + 1])
                else {
                    return Err(Error::MathDomain {
                        function: "TANGENT",
                    });
                };
                let dx = (self.graph.x_max - self.graph.x_min) / (samples.len() - 1) as f64;
                let slope = (right - left) / (2.0 * dx);
                let x_min = self.graph.x_min;
                let x_max = self.graph.x_max;
                self.graph.draw_line(
                    x_min,
                    center + slope * (x_min - at),
                    x_max,
                    center + slope * (x_max - at),
                    Some(color),
                );
            }
            "SHADE" => {
                expect_graph_arity(name, &arguments, 2, 6)?;
                self.sync_graph_window_from_variables()?;
                let lower = self.sample_graph_expression(arguments[0])?;
                let upper = self.sample_graph_expression(arguments[1])?;
                let x_left = arguments
                    .get(2)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(self.graph.x_min);
                let x_right = arguments
                    .get(3)
                    .map(|argument| self.evaluate_graph_real(argument))
                    .transpose()?
                    .unwrap_or(self.graph.x_max);
                if let Some(resolution) = arguments.get(4) {
                    let resolution = self.evaluate_integer(resolution)?;
                    if !(1..=8).contains(&resolution) {
                        return Err(Error::IllegalQuantity);
                    }
                }
                if let Some(pattern) = arguments.get(5) {
                    let pattern = self.evaluate_integer(pattern)?;
                    if !(1..=4).contains(&pattern) {
                        return Err(Error::IllegalQuantity);
                    }
                }
                self.graph
                    .shade_between(&lower, &upper, x_left, x_right, 22)?;
            }
            "FNON" | "FNOFF" => {
                expect_graph_arity(name, &arguments, 0, 10)?;
                let enabled = name == "FNON";
                if arguments.is_empty() {
                    self.graph.functions_enabled.fill(enabled);
                } else {
                    for argument in arguments {
                        let number = self.evaluate_integer(argument)?;
                        let index = match number {
                            1..=9 => number as usize - 1,
                            0 | 10 => 9,
                            _ => return Err(Error::IllegalQuantity),
                        };
                        self.graph.functions_enabled[index] = enabled;
                    }
                }
            }
            "GRAPHSTYLE" => {
                expect_graph_arity(name, &arguments, 2, 2)?;
                let number = self.evaluate_integer(arguments[0])?;
                let index = match number {
                    1..=9 => number as usize - 1,
                    0 | 10 => 9,
                    _ => return Err(Error::IllegalQuantity),
                };
                let style = self.evaluate_integer(arguments[1])?;
                if !(1..=7).contains(&style) {
                    return Err(Error::IllegalQuantity);
                }
                self.graph.function_styles[index] = style as u8;
            }
            "PXL-ON" | "PXL-OFF" | "PXL-CHANGE" => {
                expect_graph_arity(name, &arguments, 2, 3)?;
                let row = self.evaluate_integer(arguments[0])?;
                let column = self.evaluate_integer(arguments[1])?;
                let color = self.graph_color_argument(arguments.get(2), 12)?;
                match name {
                    "PXL-ON" => self.graph.pixel_set(row, column, Some(color)),
                    "PXL-OFF" => self.graph.pixel_set(row, column, None),
                    _ => self.graph.pixel_toggle(row, column, color),
                }
            }
            "PT-ON" | "PT-OFF" | "PT-CHANGE" => {
                expect_graph_arity(name, &arguments, 2, 4)?;
                self.sync_graph_window_from_variables()?;
                let x = self.evaluate_graph_real(arguments[0])?;
                let y = self.evaluate_graph_real(arguments[1])?;
                // The optional mark argument controls calculator glyph shape.
                // This native pixel graph accepts and validates it while using
                // the one-pixel point that all marks share at their center.
                if let Some(mark) = arguments.get(2) {
                    let mark = self.evaluate_integer(mark)?;
                    if !(1..=7).contains(&mark) {
                        return Err(Error::IllegalQuantity);
                    }
                }
                let color = self.graph_color_argument(arguments.get(3), 12)?;
                match name {
                    "PT-ON" => self.graph.point_set(x, y, Some(color)),
                    "PT-OFF" => self.graph.point_set(x, y, None),
                    _ => self.graph.point_toggle(x, y, color),
                }
            }
            "TEXT" | "GTEXT" => {
                expect_graph_arity(name, &arguments, 3, 5)?;
                let row = self.evaluate_integer(arguments[0])?;
                let column = self.evaluate_integer(arguments[1])?;
                let text = self.evaluate_value(arguments[2])?.to_string();
                let color = self.graph_color_argument(arguments.get(3), 12)?;
                let size = arguments
                    .get(4)
                    .map(|argument| self.evaluate_integer(argument))
                    .transpose()?
                    .unwrap_or(8);
                let size = usize::try_from(size).map_err(|_| Error::IllegalQuantity)?;
                self.graph.draw_text(row, column, text, color, size)?;
            }
            _ => {
                return Err(Error::syntax(format!(
                    "unsupported TI graph statement {name}"
                )))
            }
        }
        Ok(Control::Advance)
    }

    fn graph_color_argument(
        &mut self,
        argument: Option<&&[TokenInstance]>,
        default: u8,
    ) -> Result<u8, Error> {
        argument
            .map(|argument| self.evaluate_integer(argument))
            .transpose()?
            .map(validate_ti_color)
            .transpose()
            .map(|color| color.unwrap_or(default))
    }

    fn graph_with_enabled_functions(&mut self) -> Result<TiGraphState, Error> {
        let mut display = self.graph.clone();
        const COLORS: [u8; 10] = [10, 11, 14, 13, 15, 17, 18, 16, 23, 24];
        for (index, color) in COLORS.into_iter().enumerate() {
            if !self.graph.functions_enabled[index] {
                continue;
            }
            let number = if index == 9 { 0 } else { index + 1 };
            let names = [format!("Y{number}"), format!("Y{number}$")];
            let Some(expression) = names.iter().find_map(|name| {
                self.vars
                    .get(name)
                    .and_then(Value::as_str)
                    .map(str::to_string)
            }) else {
                continue;
            };
            let tokens = crate::tokens::tokenize(&expression)?;
            let samples = self.sample_graph_expression(&tokens)?;
            let mut samples = samples.into_iter();
            display.draw_function_styled(
                false,
                Some(color),
                self.graph.function_styles[index],
                |_| samples.next().flatten(),
            )?;
        }
        Ok(display)
    }

    fn evaluate_graph_real(&mut self, tokens: &[TokenInstance]) -> Result<f64, Error> {
        graph_real(self.evaluate_value(tokens)?)
    }

    fn sync_graph_window_from_variables(&mut self) -> Result<(), Error> {
        let x_min = graph_variable(&self.vars, "XMIN", self.graph.x_min)?;
        let x_max = graph_variable(&self.vars, "XMAX", self.graph.x_max)?;
        let x_scale = graph_variable(&self.vars, "XSCL", self.graph.x_scale)?;
        let y_min = graph_variable(&self.vars, "YMIN", self.graph.y_min)?;
        let y_max = graph_variable(&self.vars, "YMAX", self.graph.y_max)?;
        let y_scale = graph_variable(&self.vars, "YSCL", self.graph.y_scale)?;
        self.graph
            .set_window(x_min, x_max, x_scale, y_min, y_max, y_scale)
    }

    fn sample_graph_expression(
        &mut self,
        expression: &[TokenInstance],
    ) -> Result<Vec<Option<f64>>, Error> {
        use crate::ti_graph::TI_GRAPH_SAMPLES;

        let original_vars = self.vars.clone();
        let original_arrays = self.arrays.clone();
        let original_rng = self.rng.clone();
        let x_min = self.graph.x_min;
        let x_max = self.graph.x_max;
        let result = (|| {
            let mut samples = Vec::with_capacity(TI_GRAPH_SAMPLES);
            for index in 0..TI_GRAPH_SAMPLES {
                let x = x_min + (x_max - x_min) * index as f64 / (TI_GRAPH_SAMPLES - 1) as f64;
                self.vars
                    .insert("X".into(), Value::Real(BasicReal::new(x)?));
                let value = match self.evaluate_value(expression) {
                    Ok(value) => Some(graph_real(value)?),
                    Err(Error::DivideByZero | Error::MathDomain { .. } | Error::RealOverflow) => {
                        None
                    }
                    Err(error) => return Err(error),
                };
                samples.push(value);
            }
            Ok(samples)
        })();
        self.vars = original_vars;
        self.arrays = original_arrays;
        self.rng = original_rng;
        result
    }

    fn execute_read(&mut self, rest: &[TokenInstance], line_number: u64) -> Result<Control, Error> {
        let lvalues = parse_read_list(rest)?;
        for lvalue in &lvalues {
            if lvalue.subscripts.is_empty() {
                self.ensure_assignable(&lvalue.name)?;
            }
        }
        for lvalue in lvalues {
            let indices: Vec<i64> = lvalue
                .subscripts
                .iter()
                .map(|sub| self.evaluate_integer(sub))
                .collect::<Result<Vec<_>, _>>()?;
            let name = lvalue.name;
            if !indices.is_empty() {
                self.arrays.ensure_element(&name, &indices)?;
            }
            if self.is_string_destination(&name) {
                let s = self
                    .data_cursor
                    .read_string(self.max_string_bytes, line_number)?;
                let value = Value::String(s);
                if indices.is_empty() {
                    self.assign(name, value)?;
                } else {
                    let value = self.coerce_default_assignment(&name, value)?;
                    self.arrays
                        .store_bounded(&name, &indices, value, &mut self.storage)?;
                }
            } else {
                let value = self.data_cursor.read_numeric(self.mode, line_number)?;
                if indices.is_empty() {
                    self.assign(name, value)?;
                } else {
                    let value = self.coerce_default_assignment(&name, value)?;
                    self.arrays
                        .store_bounded(&name, &indices, value, &mut self.storage)?;
                }
            }
        }
        Ok(Control::Advance)
    }

    fn execute_mat<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        line_number: u64,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        match mat::parse(rest)? {
            MatStatement::Read(arrays) => self.execute_mat_read(&arrays, line_number)?,
            MatStatement::Print(arrays) => self.execute_mat_print(&arrays, writer)?,
            MatStatement::Input(name) => {
                self.execute_mat_input(&name, line_number, input, writer)?
            }
            MatStatement::Assign { target, expression } => {
                self.execute_mat_assignment(&target, &expression)?
            }
        }
        Ok(Control::Advance)
    }

    fn execute_mat_read(
        &mut self,
        specifications: &[MatArraySpec],
        line_number: u64,
    ) -> Result<(), Error> {
        let mut resolved = Vec::with_capacity(specifications.len());
        for specification in specifications {
            let shape = specification
                .dimensions
                .as_deref()
                .map(|dimensions| self.evaluate_mat_shape(dimensions))
                .transpose()?;
            resolved.push((specification.name.clone(), shape));
        }

        let mut arrays = self.arrays.clone();
        let mut storage = self.storage.clone();
        let mut cursor = self.data_cursor.clone();
        for (name, explicit_shape) in resolved {
            let shape = match explicit_shape {
                Some(shape) => shape,
                None => Matrix::from_store(&mut arrays, &name)?.shape(),
            };
            let length = shape.logical_len()?;
            let mut values = Vec::new();
            values
                .try_reserve_exact(length)
                .map_err(|_| Error::ArrayTooLarge)?;
            for _ in 0..length {
                values.push(cursor.read_numeric(self.mode, line_number)?);
            }
            Matrix::from_values(shape, values)?.store_as(&mut arrays, &mut storage, &name)?;
        }

        self.arrays = arrays;
        self.storage = storage;
        self.data_cursor = cursor;
        Ok(())
    }

    fn execute_mat_assignment(
        &mut self,
        target: &str,
        expression: &MatExpression,
    ) -> Result<(), Error> {
        let explicit_fill_shape = match expression {
            MatExpression::Fill {
                dimensions: Some(dimensions),
                ..
            } => Some(self.evaluate_mat_shape(dimensions)?),
            _ => None,
        };
        let scalar = match expression {
            MatExpression::Scale { factor, .. } => Some(self.evaluate_value(factor)?),
            _ => None,
        };

        let mut arrays = self.arrays.clone();
        let mut storage = self.storage.clone();
        let mut variables = self.vars.clone();
        let (result, determinant) = match expression {
            MatExpression::Copy(source) => (Matrix::from_store(&mut arrays, source)?, None),
            MatExpression::Add(left, right) => {
                let left = Matrix::from_store(&mut arrays, left)?;
                let right = Matrix::from_store(&mut arrays, right)?;
                (left.add(&right, self.mode)?, None)
            }
            MatExpression::Subtract(left, right) => {
                let left = Matrix::from_store(&mut arrays, left)?;
                let right = Matrix::from_store(&mut arrays, right)?;
                (left.subtract(&right, self.mode)?, None)
            }
            MatExpression::Multiply(left, right) => {
                let left = Matrix::from_store(&mut arrays, left)?;
                let right = Matrix::from_store(&mut arrays, right)?;
                (
                    left.multiply(&right, self.mode, self.max_matrix_operations)?,
                    None,
                )
            }
            MatExpression::Scale { source, .. } => {
                let source = Matrix::from_store(&mut arrays, source)?;
                let scalar = scalar
                    .as_ref()
                    .ok_or_else(|| Error::syntax("internal MAT scalar was not evaluated"))?;
                (source.scale(scalar, self.mode)?, None)
            }
            MatExpression::Transpose(source) => {
                (Matrix::from_store(&mut arrays, source)?.transpose()?, None)
            }
            MatExpression::Inverse(source) => {
                let (inverse, determinant) =
                    Matrix::from_store(&mut arrays, source)?.inverse(self.max_matrix_operations)?;
                (inverse, Some(determinant))
            }
            MatExpression::Fill { kind, .. } => {
                let shape = match explicit_fill_shape {
                    Some(shape) => shape,
                    None => Matrix::from_store(&mut arrays, target)?.shape(),
                };
                let matrix = match kind {
                    MatFill::Zero => Matrix::filled(shape, Value::Integer(0))?,
                    MatFill::One => Matrix::filled(shape, Value::Integer(1))?,
                    MatFill::Identity => Matrix::identity(shape)?,
                };
                (matrix, None)
            }
        };

        result.store_as(&mut arrays, &mut storage, target)?;
        if let Some(determinant) = determinant {
            self.ensure_assignable("DET")?;
            Self::assign_to_store(&mut variables, &mut storage, "DET".to_string(), determinant)?;
        }
        self.arrays = arrays;
        self.storage = storage;
        self.vars = variables;
        Ok(())
    }

    fn evaluate_mat_shape(
        &mut self,
        dimensions: &[Vec<TokenInstance>],
    ) -> Result<MatrixShape, Error> {
        let mut bounds = Vec::with_capacity(dimensions.len());
        for expression in dimensions {
            let bound = self.evaluate_integer(expression)?;
            if bound < 0 {
                return Err(Error::IllegalQuantity);
            }
            bounds.push(usize::try_from(bound).map_err(|_| Error::ArrayTooLarge)?);
        }
        match bounds.as_slice() {
            [length] => Ok(MatrixShape::Vector(*length)),
            [0, columns] => Ok(MatrixShape::RowVector(*columns)),
            [rows, columns] => Ok(MatrixShape::Matrix {
                rows: *rows,
                columns: *columns,
            }),
            dimensions => Err(Error::MatrixRankUnsupported {
                dimensions: dimensions.len(),
            }),
        }
    }

    fn execute_mat_input<R: BufRead + ?Sized, W: Write>(
        &mut self,
        name: &str,
        line_number: u64,
        input: &mut R,
        writer: &mut W,
    ) -> Result<(), Error> {
        let mut input_lines = 0usize;
        loop {
            self.write_terminal_text(writer, "? ")?;
            writer.flush()?;
            let mut fields = Vec::new();
            loop {
                if input_lines >= self.max_input_lines {
                    return Err(Error::InputLimitExceeded {
                        line: line_number,
                        limit: self.max_input_lines,
                    });
                }
                input_lines += 1;
                let line = read_input_line(input, self.max_input_bytes, line_number)?
                    .ok_or(Error::EndOfInput { line: line_number })?;
                let trimmed = line.trim_end();
                let continued = trimmed.ends_with('&');
                let content = if continued {
                    trimmed
                        .strip_suffix('&')
                        .expect("checked MAT INPUT continuation")
                        .trim_end()
                } else {
                    line.as_str()
                };
                if !content.trim().is_empty() {
                    fields.extend(split_input_fields(content));
                    if fields.len() > self.arrays.max_elements() {
                        return Err(Error::ArrayTooLarge);
                    }
                }
                if !continued {
                    break;
                }
                self.write_terminal_text(writer, "?? ")?;
                writer.flush()?;
            }

            let values = fields
                .iter()
                .map(|field| convert_input_field(field, false, self.mode, self.max_string_bytes))
                .collect::<Result<Vec<_>, _>>();
            let Ok(values) = values else {
                self.write_terminal_line(writer, "?REDO FROM START")?;
                continue;
            };

            let shape = MatrixShape::Vector(values.len());
            let matrix = Matrix::from_values(shape, values)?;
            let mut arrays = self.arrays.clone();
            let mut storage = self.storage.clone();
            let mut variables = self.vars.clone();
            matrix.store_as(&mut arrays, &mut storage, name)?;
            let count = i64::try_from(shape.logical_len()?).map_err(|_| Error::ArrayTooLarge)?;
            let count = BasicInteger::with_mode(self.mode, count)?.value();
            self.ensure_assignable("NUM")?;
            Self::assign_to_store(
                &mut variables,
                &mut storage,
                "NUM".to_string(),
                Value::Integer(count),
            )?;
            self.arrays = arrays;
            self.storage = storage;
            self.vars = variables;
            return Ok(());
        }
    }

    fn execute_mat_print<W: Write>(
        &mut self,
        specifications: &[MatPrintItem],
        writer: &mut W,
    ) -> Result<(), Error> {
        if self.output_column != 0 {
            writer.write_all(b"\n")?;
            self.output_column = 0;
            self.advance_text_row();
        }
        for specification in specifications {
            let matrix = Matrix::from_store(&mut self.arrays, &specification.name)?;
            self.render_mat_matrix(&matrix, specification.mode, writer)?;
        }
        Ok(())
    }

    fn render_mat_matrix<W: Write>(
        &mut self,
        matrix: &Matrix,
        mode: MatPrintMode,
        writer: &mut W,
    ) -> Result<(), Error> {
        match matrix.shape() {
            MatrixShape::Vector(_) => match mode {
                MatPrintMode::Normal => {
                    for value in matrix.values() {
                        self.write_terminal_line(writer, &value.to_string())?;
                    }
                    if matrix.values().is_empty() {
                        self.write_terminal_line(writer, "")?;
                    }
                }
                MatPrintMode::Row => self.render_mat_zoned_row(matrix.values(), writer)?,
                MatPrintMode::Packed => self.render_mat_packed_row(matrix.values(), writer)?,
            },
            MatrixShape::RowVector(_) => match mode {
                MatPrintMode::Normal | MatPrintMode::Row => {
                    self.render_mat_zoned_row(matrix.values(), writer)?
                }
                MatPrintMode::Packed => self.render_mat_packed_row(matrix.values(), writer)?,
            },
            MatrixShape::Matrix { rows, columns } => {
                for row in 0..rows {
                    let start = row.checked_mul(columns).ok_or(Error::ArrayTooLarge)?;
                    let end = start.checked_add(columns).ok_or(Error::ArrayTooLarge)?;
                    let values = &matrix.values()[start..end];
                    match mode {
                        MatPrintMode::Normal | MatPrintMode::Row => {
                            self.render_mat_zoned_row(values, writer)?
                        }
                        MatPrintMode::Packed => self.render_mat_packed_row(values, writer)?,
                    }
                }
            }
        }
        Ok(())
    }

    fn render_mat_zoned_row<W: Write>(
        &mut self,
        values: &[Value],
        writer: &mut W,
    ) -> Result<(), Error> {
        if values.is_empty() {
            return self.write_terminal_line(writer, "");
        }
        for (position, value) in values.iter().enumerate() {
            if position != 0 && position % 5 == 0 {
                writer.write_all(b"\n")?;
                self.output_column = 0;
                self.advance_text_row();
            } else if position % 5 != 0 {
                let spaces = spaces_to_next_zone(self.output_column);
                let mut column = self.output_column;
                self.write_print_spaces(writer, spaces, &mut column)?;
                self.output_column = column;
            }
            self.write_terminal_text(writer, &value.to_string())?;
        }
        writer.write_all(b"\n")?;
        self.output_column = 0;
        self.advance_text_row();
        Ok(())
    }

    fn render_mat_packed_row<W: Write>(
        &mut self,
        values: &[Value],
        writer: &mut W,
    ) -> Result<(), Error> {
        for (position, value) in values.iter().enumerate() {
            if position != 0 {
                self.write_terminal_text(writer, " ")?;
            }
            self.write_terminal_text(writer, &value.to_string())?;
        }
        writer.write_all(b"\n")?;
        self.output_column = 0;
        self.advance_text_row();
        Ok(())
    }

    fn execute_line_input<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        line_number: u64,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        let (prompt, variable_tokens) = match rest.first() {
            Some(TokenInstance::String(prompt)) => {
                if !matches!(rest.get(1), Some(TokenInstance::Semicolon)) {
                    return Err(Error::syntax("LINE INPUT prompt must be followed by ';'"));
                }
                (Some(prompt.as_str()), &rest[2..])
            }
            _ => (None, rest),
        };
        let destinations = self.resolve_destinations(parse_input_list(variable_tokens)?)?;
        if destinations.len() != 1 || !self.is_string_destination(&destinations[0].name) {
            return Err(Error::syntax("LINE INPUT expects one string variable"));
        }
        if let Some(prompt) = prompt {
            self.write_terminal_text(writer, prompt)?;
        }
        writer.flush()?;
        let value = read_input_line(input, self.max_input_bytes, line_number)?
            .ok_or(Error::EndOfInput { line: line_number })?;
        self.store_destinations(&destinations, vec![Value::String(value)])?;
        Ok(Control::Advance)
    }

    fn execute_input<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        line_number: u64,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        let (prompt, variable_tokens) = match rest.first() {
            Some(TokenInstance::String(prompt)) => {
                if !matches!(rest.get(1), Some(TokenInstance::Semicolon)) {
                    return Err(Error::syntax("INPUT prompt must be followed by ';'"));
                }
                (Some(prompt.as_str()), &rest[2..])
            }
            _ => (None, rest),
        };
        let lvalues = parse_input_list(variable_tokens)?;
        let destinations = self.resolve_destinations(lvalues)?;

        let mut input_lines = 0usize;
        'redo: loop {
            if input_lines >= self.max_input_lines {
                return Err(Error::InputLimitExceeded {
                    line: line_number,
                    limit: self.max_input_lines,
                });
            }

            if let Some(text) = prompt {
                self.write_terminal_text(writer, text)?;
            }
            self.write_terminal_text(writer, "? ")?;
            writer.flush()?;

            let mut fields = Vec::new();
            while fields.len() < destinations.len() {
                if input_lines >= self.max_input_lines {
                    return Err(Error::InputLimitExceeded {
                        line: line_number,
                        limit: self.max_input_lines,
                    });
                }
                input_lines += 1;
                let line = match read_input_line(input, self.max_input_bytes, line_number) {
                    Ok(Some(line)) => line,
                    Ok(None) => return Err(Error::EndOfInput { line: line_number }),
                    Err(Error::BadInput { .. }) => {
                        self.write_terminal_line(writer, "?REDO FROM START")?;
                        continue 'redo;
                    }
                    Err(error) => return Err(error),
                };
                fields.extend(split_input_fields(&line));
                if fields.len() < destinations.len() {
                    self.write_terminal_text(writer, "?? ")?;
                    writer.flush()?;
                }
            }

            let mut values = Vec::with_capacity(destinations.len());
            for (destination, field) in destinations.iter().zip(fields.iter()) {
                match convert_input_field(
                    field,
                    self.is_string_destination(&destination.name),
                    self.mode,
                    self.max_string_bytes,
                ) {
                    Ok(value) => values.push(value),
                    Err(_) => {
                        self.write_terminal_line(writer, "?REDO FROM START")?;
                        continue 'redo;
                    }
                }
            }

            self.store_destinations(&destinations, values)?;

            if fields.len() > destinations.len() {
                self.write_terminal_line(writer, "?EXTRA IGNORED")?;
            }
            return Ok(Control::Advance);
        }
    }

    fn execute_open(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let serial_as = if rest
            .iter()
            .any(|token| matches!(token, TokenInstance::Keyword(Token::For)))
        {
            None
        } else {
            rest.iter()
                .position(|token| matches!(token, TokenInstance::Ident(name) if name == "AS"))
        };
        if let Some(as_pos) = serial_as {
            if as_pos == 0 {
                return Err(Error::syntax("OPEN requires a path before AS"));
            }
            let path = self
                .evaluate_value(&rest[..as_pos])?
                .into_string()
                .ok_or(Error::TypeMismatch)?;
            let mut channel_pos = as_pos + 1;
            if matches!(rest.get(channel_pos), Some(TokenInstance::Hash)) {
                channel_pos += 1;
            }
            if channel_pos >= rest.len() {
                return Err(Error::syntax("OPEN AS requires a channel"));
            }
            let channel = FileStore::channel(self.evaluate_integer(&rest[channel_pos..])?)?;
            if let Some(port) = self.files.open_serial_spec(channel, &path)? {
                if let Some(trap) = self.com_traps.get_mut(&port) {
                    trap.channel = channel;
                }
                return Ok(Control::Advance);
            }
        }
        let shorthand_mode_first = matches!(rest.first(), Some(TokenInstance::String(_)))
            || matches!(
                rest.first(),
                Some(TokenInstance::Ident(name)) if is_string_variable(name)
            );
        if shorthand_mode_first
            && !rest
                .iter()
                .any(|token| matches!(token, TokenInstance::Keyword(Token::For)))
        {
            let (mode, mut pos) = self.evaluate_value_at(rest, 0)?;
            let mode = mode.into_string().ok_or(Error::TypeMismatch)?;
            let mode = match mode.trim().to_ascii_uppercase().as_str() {
                "I" | "INPUT" | "READ" => FileMode::Read,
                "O" | "OUTPUT" | "WRITE" => FileMode::Write,
                "A" | "APPEND" => FileMode::Append,
                "R" | "RANDOM" => FileMode::Random,
                "B" | "BINARY" => FileMode::Binary,
                _ => {
                    return Err(Error::syntax(
                        "OPEN shorthand mode must be I, O, A, R, or B",
                    ))
                }
            };
            if !matches!(rest.get(pos), Some(TokenInstance::Comma)) {
                return Err(Error::syntax("OPEN shorthand mode must be followed by ','"));
            }
            pos += 1;
            if matches!(rest.get(pos), Some(TokenInstance::Hash)) {
                pos += 1;
            }
            let (channel, next) = self.evaluate_value_at(rest, pos)?;
            let channel = BasicInteger::with_mode(self.mode, channel.to_integer()?)?.value();
            let channel = FileStore::channel(channel)?;
            if !matches!(rest.get(next), Some(TokenInstance::Comma)) {
                return Err(Error::syntax(
                    "OPEN shorthand channel must be followed by ','",
                ));
            }
            let (path, next) = self.evaluate_value_at(rest, next + 1)?;
            let path = path.into_string().ok_or(Error::TypeMismatch)?;
            expect_end_of_line(&rest[next..])?;
            self.files.open(channel, &path, mode)?;
            return Ok(Control::Advance);
        }

        if let Some(for_pos) = rest
            .iter()
            .position(|token| matches!(token, TokenInstance::Keyword(Token::For)))
        {
            if for_pos == 0 {
                return Err(Error::syntax("OPEN requires a file path before FOR"));
            }
            let path = self
                .evaluate_value(&rest[..for_pos])?
                .into_string()
                .ok_or(Error::TypeMismatch)?;
            let mode_token = rest
                .get(for_pos + 1)
                .ok_or_else(|| Error::syntax("OPEN FOR requires a mode"))?;
            let mode = match mode_token {
                TokenInstance::Keyword(Token::Input) => FileMode::Read,
                TokenInstance::Ident(name) if name == "READ" => FileMode::Read,
                TokenInstance::Ident(name) if name == "OUTPUT" || name == "WRITE" => {
                    FileMode::Write
                }
                TokenInstance::Ident(name) if name == "APPEND" => FileMode::Append,
                TokenInstance::Ident(name) if name == "RANDOM" => FileMode::Random,
                TokenInstance::Ident(name) if name == "BINARY" => FileMode::Binary,
                _ => return Err(Error::syntax(
                    "OPEN FOR mode must be INPUT, OUTPUT, READ, WRITE, APPEND, RANDOM, or BINARY",
                )),
            };
            let as_pos = for_pos + 2;
            if !matches!(rest.get(as_pos), Some(TokenInstance::Ident(name)) if name == "AS") {
                return Err(Error::syntax("OPEN FOR requires AS before the channel"));
            }
            let mut channel_pos = as_pos + 1;
            if matches!(rest.get(channel_pos), Some(TokenInstance::Hash)) {
                channel_pos += 1;
            }
            if channel_pos >= rest.len() {
                return Err(Error::syntax("OPEN AS requires a channel"));
            }
            let len_pos = rest[channel_pos..]
                .iter()
                .position(|token| {
                    matches!(token, TokenInstance::Ident(name) if name == "LEN")
                        || matches!(token, TokenInstance::Keyword(Token::Len))
                })
                .map(|position| channel_pos + position);
            let channel_end = len_pos.unwrap_or(rest.len());
            let channel =
                FileStore::channel(self.evaluate_integer(&rest[channel_pos..channel_end])?)?;
            self.files.open(channel, &path, mode)?;
            if let Some(len_pos) = len_pos {
                if mode != FileMode::Random
                    || !matches!(
                        rest.get(len_pos + 1),
                        Some(TokenInstance::Keyword(Token::Equal))
                    )
                {
                    return Err(Error::syntax("OPEN LEN requires RANDOM mode and '='"));
                }
                let length = self.evaluate_integer(&rest[len_pos + 2..])?;
                let length = usize::try_from(length).map_err(|_| Error::IllegalQuantity)?;
                self.files.set_random_record_len(channel, length)?;
            }
            return Ok(Control::Advance);
        }

        let (channel, mut pos) = self.evaluate_file_channel_prefix(rest, "OPEN")?;
        let (path, next) = self.evaluate_value_at(rest, pos)?;
        let path = path.into_string().ok_or(Error::TypeMismatch)?;
        pos = next;
        if !matches!(rest.get(pos), Some(TokenInstance::Comma)) {
            return Err(Error::syntax("OPEN requires a mode after ','"));
        }
        pos += 1;
        let (mode, next) = self.evaluate_value_at(rest, pos)?;
        let mode = mode.into_string().ok_or(Error::TypeMismatch)?;
        expect_end_of_line(&rest[next..])?;
        self.files.open(channel, &path, FileMode::parse(&mode)?)?;
        Ok(Control::Advance)
    }

    fn execute_com_open(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("COM requires a one-based port number"));
        }
        let port = self.evaluate_integer(rest)?;
        let port = u8::try_from(port).map_err(|_| Error::IllegalQuantity)?;
        if port == 0 {
            return Err(Error::IllegalQuantity);
        }
        self.files.open_serial_port(port)?;
        Ok(Control::Advance)
    }

    fn execute_environ(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("ENVIRON requires a VAR=value string"));
        }
        let entry = self
            .evaluate_value(rest)?
            .into_string()
            .ok_or(Error::TypeMismatch)?;
        let Some((name, value)) = entry.split_once('=') else {
            return Err(Error::syntax("ENVIRON requires VAR=value"));
        };
        if name.is_empty() {
            return Err(Error::syntax("ENVIRON variable name cannot be empty"));
        }
        if entry.len() > self.max_string_bytes {
            return Err(Error::StringTooLong {
                length: entry.len(),
                limit: self.max_string_bytes,
            });
        }
        let existing = self
            .session_env
            .keys()
            .find(|existing| existing.eq_ignore_ascii_case(name))
            .cloned();
        let had_overlay = existing.is_some();
        if let Some(existing) = existing {
            self.session_env.remove(&existing);
        }
        let shadows_base = self
            .environment
            .iter()
            .any(|(candidate, _)| candidate.eq_ignore_ascii_case(name));
        let overlay_only = self
            .session_env
            .keys()
            .filter(|overlay| {
                !self
                    .environment
                    .iter()
                    .any(|(base, _)| base.eq_ignore_ascii_case(overlay))
            })
            .count();
        let total =
            self.environment.len() + overlay_only + usize::from(!had_overlay && !shadows_base);
        if total > MAX_ENVIRONMENT_ENTRIES {
            return Err(Error::IllegalQuantity);
        }
        self.session_env.insert(name.to_string(), value.to_string());
        Ok(Control::Advance)
    }

    fn execute_clock_assignment(
        &mut self,
        name: &str,
        rest: &[TokenInstance],
    ) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax(format!("{name}= requires a string value")));
        }
        let text = self
            .evaluate_value(rest)?
            .into_string()
            .ok_or(Error::TypeMismatch)?;
        let host_now = SystemTime::now();
        let base = self.current_session_time_at(host_now);
        let mut calendar = crate::local_time::local_calendar_at(base)?;
        if name == "DATE$" {
            let (month, day, year) = parse_session_date(&text)?;
            calendar.year = year;
            calendar.month = month;
            calendar.day = day;
        } else {
            let (hour, minute, second) = parse_session_time(&text)?;
            calendar.hour = hour;
            calendar.minute = minute;
            calendar.second = second;
        }
        let requested = crate::local_time::system_time_from_local(calendar)?;
        self.session_clock_offset = Some(SessionClockOffset::between(requested, host_now));
        Ok(Control::Advance)
    }

    fn current_session_time_at(&self, host: SystemTime) -> SystemTime {
        self.session_clock_offset
            .map_or(host, |offset| offset.apply(host))
    }

    fn current_session_time(&self) -> SystemTime {
        self.current_session_time_at(SystemTime::now())
    }

    fn parse_random_channel_record(
        &mut self,
        rest: &[TokenInstance],
        statement: &str,
    ) -> Result<(u8, Option<usize>), Error> {
        let start = usize::from(matches!(rest.first(), Some(TokenInstance::Hash)));
        if start >= rest.len() {
            return Err(Error::syntax(format!("{statement} requires a channel")));
        }
        let (channel_value, next) = self.evaluate_value_at(rest, start)?;
        let channel = FileStore::channel(channel_value.to_integer()?)?;
        if next == rest.len() {
            return Ok((channel, None));
        }
        if !matches!(rest.get(next), Some(TokenInstance::Comma)) {
            return Err(Error::syntax(format!(
                "{statement} expects channel[,record]"
            )));
        }
        let record = self.evaluate_integer(&rest[next + 1..])?;
        let record = usize::try_from(record).map_err(|_| Error::IllegalQuantity)?;
        Ok((channel, Some(record)))
    }

    fn execute_field(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (channel, mut position) = self.evaluate_file_channel_prefix(rest, "FIELD")?;
        let record_len = self.files.random_record_len(channel)?;
        let mut bindings = Vec::new();
        let mut offset = 0usize;
        loop {
            let as_position = rest[position..]
                .iter()
                .position(|token| matches!(token, TokenInstance::Ident(name) if name == "AS"))
                .map(|index| position + index)
                .ok_or_else(|| Error::syntax("FIELD width requires AS variable$"))?;
            let width = self.evaluate_integer(&rest[position..as_position])?;
            let width = usize::try_from(width).map_err(|_| Error::IllegalQuantity)?;
            if width == 0 {
                return Err(Error::IllegalQuantity);
            }
            let name = match rest.get(as_position + 1) {
                Some(TokenInstance::Ident(name)) if is_string_variable(name) => name.clone(),
                _ => return Err(Error::TypeMismatch),
            };
            let end = offset.checked_add(width).ok_or(Error::IllegalQuantity)?;
            if end > record_len {
                return Err(Error::IllegalQuantity);
            }
            let value = " ".repeat(width);
            self.assign(name.clone(), Value::String(value.clone()))?;
            self.files
                .set_random_field(channel, offset, value.as_bytes())?;
            bindings.push((name, offset, width));
            offset = end;
            position = as_position + 2;
            if position == rest.len() {
                break;
            }
            if !matches!(rest.get(position), Some(TokenInstance::Comma)) {
                return Err(Error::syntax("FIELD bindings must be comma-separated"));
            }
            position += 1;
        }
        self.random_fields.insert(channel, bindings);
        Ok(Control::Advance)
    }

    fn execute_set_fixed_string(
        &mut self,
        rest: &[TokenInstance],
        right: bool,
    ) -> Result<Control, Error> {
        let eq = rest
            .iter()
            .position(|token| matches!(token, TokenInstance::Keyword(Token::Equal)))
            .ok_or_else(|| Error::syntax("LSET/RSET requires ="))?;
        let name = match &rest[..eq] {
            [TokenInstance::Ident(name)] if is_string_variable(name) => name.clone(),
            _ => return Err(Error::TypeMismatch),
        };
        let source = self
            .evaluate_value(&rest[eq + 1..])?
            .into_string()
            .ok_or(Error::TypeMismatch)?;
        let field = self.random_fields.iter().find_map(|(channel, bindings)| {
            bindings
                .iter()
                .find(|(field_name, _, _)| field_name == &name)
                .map(|(_, offset, width)| (*channel, *offset, *width))
        });
        let width = if let Some((_, _, width)) = field {
            width
        } else {
            self.scalar_value(&name)?
                .and_then(|value| match value {
                    Value::String(text) => Some(text.chars().count()),
                    _ => None,
                })
                .unwrap_or_else(|| source.chars().count())
        };
        let mut clipped: String = source.chars().take(width).collect();
        let padding = width.saturating_sub(clipped.chars().count());
        if right {
            clipped = format!("{}{}", " ".repeat(padding), clipped);
        } else {
            clipped.push_str(&" ".repeat(padding));
        }
        self.assign(name, Value::String(clipped.clone()))?;
        if let Some((channel, offset, _)) = field {
            self.files
                .set_random_field(channel, offset, clipped.as_bytes())?;
        }
        Ok(Control::Advance)
    }

    fn parse_direct_record_transfer(
        &self,
        tokens: &[TokenInstance],
        statement: &str,
    ) -> Result<Option<DirectRecordTransfer>, Error> {
        let mut depth = 0usize;
        let mut comma = None;
        for (index, token) in tokens.iter().enumerate() {
            match token {
                TokenInstance::LParen => depth = depth.saturating_add(1),
                TokenInstance::RParen => {
                    depth = depth.checked_sub(1).ok_or_else(|| {
                        Error::syntax(format!("unexpected ')' in {statement} record transfer"))
                    })?;
                }
                TokenInstance::Comma if depth == 0 => {
                    if comma.is_some() {
                        return Ok(None);
                    }
                    comma = Some(index);
                }
                _ => {}
            }
        }
        if depth != 0 {
            return Err(Error::syntax(format!(
                "expected ')' in {statement} record transfer"
            )));
        }
        let Some(comma) = comma else {
            return Ok(None);
        };
        let target_tokens = &tokens[comma + 1..];
        let Some(TokenInstance::Ident(name)) = target_tokens.first() else {
            return Ok(None);
        };
        if !self.record_instances.contains_key(name) {
            return Ok(None);
        }
        let target = parse_list_lvalue(target_tokens, statement)?;
        let position = if comma == 0 {
            None
        } else {
            Some(tokens[..comma].to_vec())
        };
        Ok(Some(DirectRecordTransfer { position, target }))
    }

    fn resolve_direct_record_target(
        &mut self,
        lvalue: &Lvalue,
        assignable: bool,
    ) -> Result<ResolvedRecordTarget, Error> {
        let type_name = self
            .record_instances
            .get(&lvalue.name)
            .cloned()
            .ok_or(Error::TypeMismatch)?;
        let definition = self
            .structured_definitions
            .types
            .get(&type_name)
            .cloned()
            .ok_or_else(|| Error::syntax(format!("undefined TYPE {type_name}")))?;
        let indices = self.evaluate_lvalue_indices(lvalue)?;
        for field in &definition.fields {
            let qualified = format!("{}.{}", lvalue.name, field.name);
            if assignable {
                self.ensure_assignable(&qualified)?;
            }
            let is_array = self.arrays.get(&qualified).is_some();
            if is_array == indices.is_empty() {
                return Err(Error::BadSubscript);
            }
            if !indices.is_empty() {
                self.arrays
                    .get(&qualified)
                    .ok_or(Error::BadSubscript)?
                    .load(&indices)?;
            }
        }
        Ok(ResolvedRecordTarget {
            base: lvalue.name.clone(),
            indices,
            definition,
        })
    }

    fn direct_record_len(&self, definition: &TypeDefinition) -> Result<usize, Error> {
        let mut length = 0usize;
        for field in &definition.fields {
            let width = match field.declaration {
                VariableType::Integer | VariableType::Single => 4,
                VariableType::Long | VariableType::Double => 8,
                VariableType::String => field.fixed_string_bytes.ok_or_else(|| {
                    Error::syntax(format!(
                        "direct GET/PUT of TYPE {} requires STRING * n for field {}",
                        definition.name, field.name
                    ))
                })?,
                VariableType::Numeric => return Err(Error::TypeMismatch),
            };
            length = length.checked_add(width).ok_or(Error::FileLimitExceeded {
                limit: self.files.max_file_bytes(),
            })?;
            if length > self.files.max_file_bytes() {
                return Err(Error::FileLimitExceeded {
                    limit: self.files.max_file_bytes(),
                });
            }
        }
        Ok(length)
    }

    fn encode_direct_record(&self, target: &ResolvedRecordTarget) -> Result<Vec<u8>, Error> {
        let mut bytes = Vec::with_capacity(self.direct_record_len(&target.definition)?);
        for field in &target.definition.fields {
            let qualified = format!("{}.{}", target.base, field.name);
            let value = if target.indices.is_empty() {
                self.scalar_value(&qualified)?
                    .unwrap_or_else(|| self.default_scalar_value(&qualified))
            } else {
                self.arrays
                    .get(&qualified)
                    .ok_or(Error::BadSubscript)?
                    .load(&target.indices)?
            };
            match field.declaration {
                VariableType::Integer => {
                    let value = value.to_integer()?;
                    let value = i32::try_from(value).map_err(|_| {
                        if value < 0 {
                            Error::IntegerUnderflow
                        } else {
                            Error::IntegerOverflow
                        }
                    })?;
                    bytes.extend_from_slice(&value.to_le_bytes());
                }
                VariableType::Long => {
                    bytes.extend_from_slice(&value.to_integer()?.to_le_bytes());
                }
                VariableType::Single | VariableType::Double => {
                    let value = match value {
                        Value::Integer(value) => value as f64,
                        Value::Real(value) => value.value(),
                        Value::Complex(_) | Value::List(_) | Value::String(_) => {
                            return Err(Error::TypeMismatch)
                        }
                    };
                    if field.declaration == VariableType::Single {
                        bytes.extend_from_slice(&(value as f32).to_le_bytes());
                    } else {
                        bytes.extend_from_slice(&value.to_le_bytes());
                    }
                }
                VariableType::String => {
                    let Value::String(text) = value else {
                        return Err(Error::TypeMismatch);
                    };
                    let width = field.fixed_string_bytes.ok_or_else(|| {
                        Error::syntax(format!(
                            "direct GET/PUT of TYPE {} requires STRING * n for field {}",
                            target.definition.name, field.name
                        ))
                    })?;
                    if text.len() != width {
                        return Err(Error::TypeMismatch);
                    }
                    bytes.extend_from_slice(text.as_bytes());
                }
                VariableType::Numeric => return Err(Error::TypeMismatch),
            }
        }
        Ok(bytes)
    }

    fn decode_direct_record(
        &self,
        target: &ResolvedRecordTarget,
        bytes: &[u8],
        channel: u8,
    ) -> Result<Vec<Value>, Error> {
        let expected = self.direct_record_len(&target.definition)?;
        if bytes.len() < expected {
            return Err(Error::BadFileData { channel });
        }
        let mut values = Vec::with_capacity(target.definition.fields.len());
        let mut cursor = 0usize;
        for field in &target.definition.fields {
            let width = match field.declaration {
                VariableType::Integer | VariableType::Single => 4,
                VariableType::Long | VariableType::Double => 8,
                VariableType::String => field.fixed_string_bytes.ok_or_else(|| {
                    Error::syntax(format!(
                        "direct GET/PUT of TYPE {} requires STRING * n for field {}",
                        target.definition.name, field.name
                    ))
                })?,
                VariableType::Numeric => return Err(Error::TypeMismatch),
            };
            let end = cursor
                .checked_add(width)
                .ok_or(Error::BadFileData { channel })?;
            let field_bytes = bytes
                .get(cursor..end)
                .ok_or(Error::BadFileData { channel })?;
            let value = match field.declaration {
                VariableType::Integer => Value::Integer(i64::from(i32::from_le_bytes(
                    field_bytes
                        .try_into()
                        .expect("validated INTEGER field width"),
                ))),
                VariableType::Long => Value::Integer(i64::from_le_bytes(
                    field_bytes.try_into().expect("validated LONG field width"),
                )),
                VariableType::Single => {
                    let value = f32::from_le_bytes(
                        field_bytes
                            .try_into()
                            .expect("validated SINGLE field width"),
                    );
                    Value::Real(
                        BasicReal::new(f64::from(value))
                            .map_err(|_| Error::BadFileData { channel })?,
                    )
                }
                VariableType::Double => {
                    let value = f64::from_le_bytes(
                        field_bytes
                            .try_into()
                            .expect("validated DOUBLE field width"),
                    );
                    Value::Real(BasicReal::new(value).map_err(|_| Error::BadFileData { channel })?)
                }
                VariableType::String => Value::String(
                    String::from_utf8(field_bytes.to_vec())
                        .map_err(|_| Error::BadFileData { channel })?,
                ),
                VariableType::Numeric => return Err(Error::TypeMismatch),
            };
            values.push(value);
            cursor = end;
        }
        Ok(values)
    }

    fn store_direct_record(
        &mut self,
        target: &ResolvedRecordTarget,
        values: Vec<Value>,
    ) -> Result<(), Error> {
        if values.len() != target.definition.fields.len() {
            return Err(Error::TypeMismatch);
        }
        let original_vars = self.vars.clone();
        let original_static_vars = self.static_vars.clone();
        let original_locals = self
            .procedure_stack
            .iter()
            .map(|frame| frame.locals.clone())
            .collect::<Vec<_>>();
        let original_arrays = self.arrays.clone();
        let original_storage = self.storage.clone();
        let result = (|| {
            for (field, value) in target.definition.fields.iter().zip(values) {
                let qualified = format!("{}.{}", target.base, field.name);
                if target.indices.is_empty() {
                    self.assign(qualified, value)?;
                } else {
                    let value = self.coerce_default_assignment(&qualified, value)?;
                    self.arrays.store_bounded(
                        &qualified,
                        &target.indices,
                        value,
                        &mut self.storage,
                    )?;
                }
            }
            Ok(())
        })();
        if result.is_err() {
            self.vars = original_vars;
            self.static_vars = original_static_vars;
            for (frame, locals) in self.procedure_stack.iter_mut().zip(original_locals) {
                frame.locals = locals;
            }
            self.arrays = original_arrays;
            self.storage = original_storage;
        }
        result
    }

    fn execute_put_random(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (channel, position) = self.evaluate_file_channel_head(rest, "PUT")?;
        let binary = self.files.is_binary(channel)?;
        let random = self.files.is_random(channel)?;
        if let Some(position) = position {
            if let Some(transfer) = self.parse_direct_record_transfer(&rest[position..], "PUT")? {
                if !binary && !random {
                    return Err(Error::FileModeMismatch { channel });
                }
                let record_or_position = transfer
                    .position
                    .map(|tokens| self.evaluate_integer(&tokens))
                    .transpose()?
                    .map(|value| usize::try_from(value).map_err(|_| Error::IllegalQuantity))
                    .transpose()?;
                let target = self.resolve_direct_record_target(&transfer.target, false)?;
                let bytes = self.encode_direct_record(&target)?;
                if binary {
                    if let Some(position) = record_or_position {
                        self.files.seek_binary(channel, position)?;
                    }
                    self.files.write(channel, &bytes)?;
                } else {
                    self.files
                        .put_random_data(channel, record_or_position, &bytes)?;
                }
                return Ok(Control::Advance);
            }
        }
        if binary {
            let position = position.ok_or_else(|| {
                Error::syntax("binary PUT channel must be followed by ',' and a byte")
            })?;
            let byte = self.evaluate_integer(&rest[position..])?;
            if !(0..=255).contains(&byte) {
                return Err(Error::IllegalQuantity);
            }
            self.files.write(channel, &[byte as u8])?;
            return Ok(Control::Advance);
        }
        let (channel, record) = self.parse_random_channel_record(rest, "PUT")?;
        self.files.put_random_record(channel, record)?;
        Ok(Control::Advance)
    }

    fn execute_seek(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (channel, position_start) = self.evaluate_file_channel_prefix(rest, "SEEK")?;
        let position = self.evaluate_integer(&rest[position_start..])?;
        let position = usize::try_from(position).map_err(|_| Error::IllegalQuantity)?;
        self.files.seek_binary(channel, position)?;
        Ok(Control::Advance)
    }

    fn execute_common(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        for name in parse_common_names(rest)? {
            self.common_vars.insert(name);
        }
        Ok(Control::Advance)
    }

    fn execute_chain(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("CHAIN requires a file path"));
        }
        let (path, mut pos) = self.evaluate_value_at(rest, 0)?;
        let path = path.into_string().ok_or(Error::TypeMismatch)?;
        let start_line = if pos == rest.len() {
            None
        } else {
            if !matches!(rest.get(pos), Some(TokenInstance::Comma)) {
                return Err(Error::syntax("CHAIN expects an optional ',line'"));
            }
            pos += 1;
            Some(parse_line_number(&rest[pos..])?)
        };

        let program_path = self.files.resolve(&path, true)?;
        let bytes = self.files.read_all(&path)?;
        let mut loaded = Program::new();
        loaded.read_from(
            &mut std::io::Cursor::new(bytes),
            DEFAULT_MAX_SOURCE_LINE_BYTES,
        )?;

        // COMMON variables and arrays cross the program boundary. Everything
        // else is rebuilt as a fresh program state before the chained file
        // begins execution.
        let common_names = self.common_vars.clone();
        let common_scalars = self
            .vars
            .iter()
            .filter(|(name, _)| common_names.contains(*name))
            .map(|(name, value)| (name.clone(), value.clone()))
            .collect::<Variables>();
        let common_arrays = self.arrays.clone_selected(&common_names);

        let mut next_vars = graph_system_variables(&self.graph)?;
        let mut next_storage = StorageBudget::new(self.storage.max_bytes());
        for (name, value) in common_scalars {
            next_storage.replace(None, &value)?;
            next_vars.insert(name, value);
        }
        for value in common_arrays.stored_values() {
            next_storage.replace(None, value)?;
        }

        self.install_program_with_assets_at(loaded, program_path.parent().map(Path::to_path_buf))?;
        self.vars = next_vars;
        self.arrays = common_arrays;
        self.storage = next_storage;
        self.data_cursor.reset();
        self.call_stack.clear();
        self.loop_stack.clear();
        self.user_functions.clear();
        self.common_vars = common_names;
        self.constants.clear();
        self.procedure_stack.clear();
        self.static_vars.clear();
        self.static_arrays.clear();
        self.static_declared_types.clear();
        self.timer_trap = TimerEventTrap::default();
        self.collision_trap = CollisionEventTrap::default();
        self.key_trap = KeyEventTrap::default();
        self.com_traps.clear();
        self.pen_trap = EdgeEventTrap::default();
        self.strig_trap = EdgeEventTrap::default();
        self.structured_definitions = StructuredDefinitions::default();
        self.function_result = None;
        Ok(Control::Restart(start_line))
    }

    fn execute_merge(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let path = self.evaluate_file_path(rest, "MERGE")?;
        let program_path = self.files.resolve(&path, true)?;
        let bytes = self.files.read_all(&path)?;
        let mut loaded = Program::new();
        loaded.read_from(
            &mut std::io::Cursor::new(bytes),
            DEFAULT_MAX_SOURCE_LINE_BYTES,
        )?;
        let mut merged = self.current_program.clone();
        merged.merge_from(&loaded);
        self.install_program_with_assets_at(merged, program_path.parent().map(Path::to_path_buf))?;
        Ok(Control::Advance)
    }

    fn execute_load(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let path = self.evaluate_file_path(rest, "LOAD")?;
        let program_path = self.files.resolve(&path, true)?;
        let bytes = self.files.read_all(&path)?;
        let mut loaded = Program::new();
        let mut source = std::io::Cursor::new(bytes);
        loaded.read_from(&mut source, DEFAULT_MAX_SOURCE_LINE_BYTES)?;

        // Commit only after the complete source has parsed successfully. LOAD
        // begins a fresh program state while retaining run-scoped resources:
        // limits, elapsed steps, RNG state, input/output, and open channels.
        self.install_program_with_assets_at(loaded, program_path.parent().map(Path::to_path_buf))?;
        self.clear_program_state();
        Ok(Control::Restart(None))
    }

    fn execute_load_binary(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let path = self.evaluate_file_path(rest, "LOADB")?;
        let program_path = self.files.resolve(&path, true)?;
        let max_bytes = self
            .files
            .max_file_bytes()
            .min(DEFAULT_MAX_BINARY_PROGRAM_BYTES);
        let bytes = self.files.read_all_with_limit(&path, max_bytes)?;
        let loaded = Program::from_binary_bytes(&bytes, max_bytes)?;

        // Match LOAD's atomic replacement and fresh program-state semantics,
        // while avoiding source decoding and tokenization entirely.
        self.install_program_with_assets_at(loaded, program_path.parent().map(Path::to_path_buf))?;
        self.clear_program_state();
        Ok(Control::Restart(None))
    }

    fn execute_list<W: Write>(
        &mut self,
        rest: &[TokenInstance],
        writer: &mut W,
    ) -> Result<Control, Error> {
        let (start, end) = parse_list_range(rest)?;
        let listing = self
            .current_program
            .to_listing_bytes(start, end, self.max_listing_bytes)?;
        if !listing.is_empty() {
            let prefix_bytes = usize::from(self.output_column != 0);
            if listing
                .len()
                .checked_add(prefix_bytes)
                .map_or(true, |length| length > self.max_listing_bytes)
            {
                return Err(Error::ListingLimitExceeded {
                    limit: self.max_listing_bytes,
                });
            }
            if prefix_bytes != 0 {
                writer.write_all(b"\n")?;
                self.advance_text_row();
            }
            writer.write_all(&listing)?;
            for _ in listing.iter().filter(|byte| **byte == b'\n') {
                self.advance_text_row();
            }
            self.output_column = 0;
        }
        Ok(Control::Terminate(RunTermination::List))
    }

    fn execute_new(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        expect_end_of_line(rest)?;
        self.current_program.clear();
        self.prepared_images.clear();
        self.prepared_media.clear();
        self.prepared_soundfont_keys.clear();
        self.prepared_asset_count = 0;
        self.clear_program_state();
        Ok(Control::Terminate(RunTermination::New))
    }

    fn execute_run(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let target = if rest.is_empty() {
            None
        } else {
            Some(parse_line_number(rest)?)
        };
        self.clear_program_state();
        Ok(Control::Restart(target))
    }

    fn execute_go(&mut self, rest: &[TokenInstance], return_pc: usize) -> Result<Control, Error> {
        match rest.split_first() {
            Some((TokenInstance::Keyword(Token::To), target)) => {
                Ok(Control::Goto(parse_line_number(target)?))
            }
            Some((TokenInstance::Ident(name), target)) if name == "SUB" => {
                self.execute_gosub(target, return_pc)
            }
            _ => Err(Error::syntax("GO requires TO or SUB and a line number")),
        }
    }

    fn execute_cont(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        expect_end_of_line(rest)?;
        Err(Error::CannotContinue)
    }

    fn clear_program_state(&mut self) {
        self.default_types = [VariableType::Numeric; 26];
        self.declared_value_types.clear();
        self.record_instances.clear();
        self.vars.clear();
        install_graph_system_variables(&mut self.vars, &self.graph)
            .expect("default graph window is finite");
        self.arrays.clear();
        self.common_vars.clear();
        self.constants.clear();
        self.storage.clear();
        self.data_cursor.reset();
        self.call_stack.clear();
        self.loop_stack.clear();
        self.procedure_stack.clear();
        self.static_vars.clear();
        self.static_arrays.clear();
        self.static_declared_types.clear();
        self.timer_trap = TimerEventTrap::default();
        self.collision_trap = CollisionEventTrap::default();
        self.key_trap = KeyEventTrap::default();
        self.com_traps.clear();
        self.pen_trap = EdgeEventTrap::default();
        self.strig_trap = EdgeEventTrap::default();
        self.function_result = None;
        self.user_functions.clear();
        self.on_error_goto = None;
        self.error_handler_active = false;
        self.last_err_code = 0;
        self.last_err_line = 0;
        self.resume_pc = None;
        self.resume_loop_depth = 0;
        self.string_allocations.clear();
        self.next_string_addresses.clear();
        self.video = None;
        self.flipbooks.clear();
        self.clear_audio_state();
    }

    fn close_device_handles(&mut self) {
        let _ = self.files.close_serials();
        crate::devices::close_joysticks();
    }

    /// BREAK stops activity owned by this task without clearing BASIC memory,
    /// its loaded program, prepared assets, or queued synthesis data.
    fn stop_runtime_processes(&mut self) {
        self.playback.stop();
        self.speech.stop();
        self.video.take();
    }

    fn release_structured_storage(&mut self) {
        let mut storage = self.storage.clone();
        let mut arrays = self.arrays.clone();
        for frame in self.procedure_stack.iter().rev() {
            for value in frame.locals.values() {
                storage
                    .remove(value)
                    .expect("procedure local storage accounting is balanced");
            }
            for name in &frame.local_arrays {
                arrays
                    .remove_bounded(name, &mut storage)
                    .expect("procedure local array storage accounting is balanced");
            }
            for (name, previous) in &frame.local_array_types {
                if let Some(previous) = previous {
                    self.declared_value_types.insert(name.clone(), *previous);
                } else {
                    self.declared_value_types.remove(name);
                }
            }
            for (name, previous) in &frame.local_record_types {
                if let Some(previous) = previous {
                    self.record_instances.insert(name.clone(), previous.clone());
                } else {
                    self.record_instances.remove(name);
                }
            }
        }
        for values in self.static_vars.values() {
            for value in values.values() {
                storage
                    .remove(value)
                    .expect("procedure STATIC storage accounting is balanced");
            }
        }
        for name in &self.static_arrays {
            arrays
                .remove_bounded(name, &mut storage)
                .expect("procedure STATIC array storage accounting is balanced");
        }
        arrays.clear_alias_scopes();
        self.arrays = arrays;
        self.storage = storage;
        self.procedure_stack.clear();
        self.static_vars.clear();
        self.static_arrays.clear();
        self.static_declared_types.clear();
        self.structured_definitions = StructuredDefinitions::default();
        self.function_result = None;
    }

    /// Standard BASIC state clearing includes every form of audio state. There
    /// is intentionally no second sound-reset path.
    fn clear_audio_state(&mut self) {
        self.playback.stop();
        self.speech.stop();
        self.synth = SidSynth::with_arrangement(self.default_synth_arrangement)
            .expect("the validated run synthesis arrangement remains valid");
        self.sf_engine.reset_music_state();
        self.singing_scores.clear();
        self.play_positions_seconds = [0.0; crate::synth::VOICE_COUNT];
    }

    /// Connect the default SoundFont MIDI device once, preferring the project-local
    /// General MIDI bank for instrument quality and retaining the compact system
    /// bank as a fallback. Explicit SOUNDFONT statements bypass this discovery
    /// path.
    fn load_soundfont_device(&mut self) -> Result<(), Error> {
        if self.sf_engine.load_cached_soundfont()? {
            return Ok(());
        }
        let bundled_error = match self.open_soundfont_asset(DEFAULT_SOUNDFONT_PATH) {
            Ok(mut reader) => match self.sf_engine.load_cached_soundfont_reader(&mut reader) {
                Ok(()) => return Ok(()),
                Err(error) => error,
            },
            Err(error) => error,
        };
        for path in SYSTEM_SOUNDFONT_PATHS {
            let Ok(metadata) = std::fs::metadata(path) else {
                continue;
            };
            if !metadata.is_file() || metadata.len() > MAX_SOUNDFONT_BYTES as u64 {
                continue;
            }
            let Ok(file) = std::fs::File::open(path) else {
                continue;
            };
            let mut reader = std::io::BufReader::with_capacity(1_048_576, file);
            if self
                .sf_engine
                .load_cached_soundfont_reader(&mut reader)
                .is_ok()
            {
                return Ok(());
            }
        }
        Err(Error::Io(format!(
            "no usable SoundFont found; run install-soundfont.sh or use SOUNDFONT \"path.sf2\" ({bundled_error})"
        )))
    }

    /// Discover, validate, and retain every static input asset before READY.
    /// RUN applies source-order behavior, but never opens these host files or
    /// performs a network fetch. Asset expressions in stored programs must be
    /// literal so the READY boundary is honest and deterministic.
    fn prepare_program_assets(&mut self) -> Result<usize, Error> {
        let (statements, _) = build_statements(&self.current_program);
        let manifest = Self::collect_program_asset_manifest(&statements)?;
        self.prepare_asset_manifest(manifest, true)
    }

    fn install_program_with_assets(&mut self, program: Program) -> Result<(), Error> {
        self.install_program_with_assets_at(program, None)
    }

    fn install_program_with_assets_at(
        &mut self,
        program: Program,
        asset_root: Option<PathBuf>,
    ) -> Result<(), Error> {
        let old_program = std::mem::replace(&mut self.current_program, program);
        let old_images = self.prepared_images.clone();
        let old_media = self.prepared_media.clone();
        let old_soundfont_keys = self.prepared_soundfont_keys.clone();
        let old_count = self.prepared_asset_count;
        let old_asset_root = self.assets.root_path().map(Path::to_path_buf);
        if let Some(asset_root) = asset_root {
            if let Err(error) = self.assets.set_root(asset_root) {
                self.current_program = old_program;
                return Err(error);
            }
        }
        if let Err(error) = self.prepare_program_assets() {
            self.current_program = old_program;
            self.prepared_images = old_images;
            self.prepared_media = old_media;
            self.prepared_soundfont_keys = old_soundfont_keys;
            self.prepared_asset_count = old_count;
            if let Some(old_asset_root) = old_asset_root {
                self.assets
                    .set_root(old_asset_root)
                    .expect("the previous canonical asset root remains valid");
            }
            return Err(error);
        }
        Ok(())
    }

    fn ensure_image_prepared(&mut self, path: &str) -> Result<(), Error> {
        if self.prepared_images.contains_key(path) {
            return Ok(());
        }
        if !self.executing_direct {
            return Err(Error::syntax("BITMAP asset was not prepared by LOAD"));
        }
        let manifest = ProgramAssetManifest {
            images: vec![path.to_string()],
            ..ProgramAssetManifest::default()
        };
        self.prepare_asset_manifest(manifest, false)?;
        Ok(())
    }

    fn ensure_media_prepared(&mut self, path: &str, kind: ProgramMediaKind) -> Result<(), Error> {
        if self.prepared_media.contains_key(path) {
            return Ok(());
        }
        if !self.executing_direct {
            return Err(Error::syntax("media asset was not prepared by LOAD"));
        }
        let manifest = ProgramAssetManifest {
            media: vec![(path.to_string(), kind)],
            ..ProgramAssetManifest::default()
        };
        self.prepare_asset_manifest(manifest, false)?;
        Ok(())
    }

    fn ensure_soundfont_prepared(&mut self, path: &str) -> Result<(), Error> {
        if self.prepared_soundfont_keys.contains_key(path) {
            return Ok(());
        }
        if !self.executing_direct {
            return Err(Error::syntax("SOUNDFONT asset was not prepared by LOAD"));
        }
        let manifest = ProgramAssetManifest {
            soundfonts: vec![(path.to_string(), path.to_string())],
            ..ProgramAssetManifest::default()
        };
        self.prepare_asset_manifest(manifest, false)?;
        Ok(())
    }

    fn prepare_asset_manifest(
        &mut self,
        manifest: ProgramAssetManifest,
        replace: bool,
    ) -> Result<usize, Error> {
        let mut images = if replace {
            HashMap::new()
        } else {
            self.prepared_images.clone()
        };
        let mut media = if replace {
            HashMap::new()
        } else {
            self.prepared_media.clone()
        };
        let mut soundfont_keys = if replace {
            HashMap::new()
        } else {
            self.prepared_soundfont_keys.clone()
        };

        for (_, path) in &manifest.soundfonts {
            let resolved = self.resolve_soundfont_asset(path)?;
            let cache_key = resolved.to_string_lossy().into_owned();
            if self.sf_engine.has_prepared_soundfont(&cache_key) {
                soundfont_keys.insert(path.clone(), cache_key);
                continue;
            }
            let mut reader = self.open_soundfont_asset(path)?;
            self.sf_engine
                .prepare_soundfont_reader(&cache_key, &mut reader)?;
            soundfont_keys.insert(path.clone(), cache_key);
        }

        for path in &manifest.images {
            if images.contains_key(path) {
                continue;
            }
            if !replace {
                if let Some(existing) = self.prepared_images.get(path) {
                    images.insert(path.clone(), existing.clone());
                    continue;
                }
            }
            let resolved = self.assets.resolve(path, true)?;
            let image = Arc::new(decode_image(&resolved)?);
            let extension = resolved
                .extension()
                .and_then(|value| value.to_str())
                .unwrap_or("img");
            let virtual_path = register_memory_image(&image, extension);
            images.insert(
                path.clone(),
                PreparedImageAsset {
                    image,
                    virtual_path,
                },
            );
        }

        for (path, kind) in &manifest.media {
            if !media.contains_key(path) {
                if !replace {
                    if let Some(existing) = self.prepared_media.get(path) {
                        media.insert(path.clone(), existing.clone());
                    }
                }
                if !media.contains_key(path) {
                    let bytes = if crate::network::is_http_url(path) {
                        self.ensure_network_access()?;
                        crate::network::fetch(path, WebMethod::Get, self.max_network_bytes)?
                    } else {
                        self.assets
                            .read_all_with_limit(path, self.assets.max_file_bytes())?
                    };
                    media.insert(
                        path.clone(),
                        crate::media::MediaSource::memory(Arc::from(bytes), path.clone()),
                    );
                }
            }
            let source = media
                .get(path)
                .expect("prepared media was inserted before validation");
            match kind {
                ProgramMediaKind::Audio => crate::media::validate_audio_source(source)?,
                ProgramMediaKind::Video => crate::media::validate_video_source(source)?,
            }
        }

        if manifest.uses_instrument && !self.sf_engine.is_loaded() {
            self.load_soundfont_device()?;
        }

        self.prepared_images = images;
        self.prepared_media = media;
        self.prepared_soundfont_keys = soundfont_keys;
        let media_count = manifest
            .media
            .iter()
            .map(|(path, _)| path)
            .collect::<HashSet<_>>()
            .len();
        let count = manifest.soundfonts.len() + manifest.images.len() + media_count;
        if replace {
            self.prepared_asset_count = count;
        } else {
            self.prepared_asset_count = self
                .prepared_asset_count
                .max(self.prepared_images.len() + self.prepared_media.len());
        }
        Ok(count)
    }

    fn collect_program_asset_manifest(
        statements: &[Statement],
    ) -> Result<ProgramAssetManifest, Error> {
        let mut asset_statements = statements.to_vec();
        for statement in statements {
            for index in 1..statement.body.len() {
                let Some(word) = statement.body.get(index).and_then(token_command_word) else {
                    continue;
                };
                if matches!(
                    word,
                    "SOUNDFONT"
                        | "INSTRUMENT"
                        | "BITMAP"
                        | "FLIPBOOK"
                        | "PLAY"
                        | "VIDEO"
                        | "WAVEFILE"
                        | "SAVEIMAGE"
                        | "RENDER"
                        | "DISPLAY"
                        | "SCREENSHOT"
                ) {
                    asset_statements.push(Statement {
                        line_number: statement.line_number,
                        body: statement.body[index..].to_vec(),
                    });
                }
            }
        }
        let statements = asset_statements.as_slice();
        let mut manifest = ProgramAssetManifest::default();
        let mut seen_soundfonts = HashSet::new();
        let mut seen_images = HashSet::new();
        let mut seen_media = HashSet::new();
        let generated_images = statements
            .iter()
            .filter_map(|statement| {
                let name = statement.body.first().and_then(token_command_word)?;
                if !matches!(name, "SAVEIMAGE" | "RENDER" | "DISPLAY" | "SCREENSHOT") {
                    return None;
                }
                let arguments = split_graph_arguments(&statement.body[1..]).ok()?;
                match arguments.as_slice() {
                    [[TokenInstance::String(path)]] => Some(path.clone()),
                    _ => None,
                }
            })
            .collect::<HashSet<_>>();
        let generated_media = statements
            .iter()
            .filter_map(|statement| {
                if statement.body.first().and_then(token_command_word) != Some("WAVEFILE") {
                    return None;
                }
                let arguments = split_graph_arguments(&statement.body[1..]).ok()?;
                match arguments.as_slice() {
                    [[TokenInstance::String(path)]] => Some(path.clone()),
                    _ => None,
                }
            })
            .collect::<HashSet<_>>();

        for statement in statements {
            let body = statement.body.as_slice();
            let Some(name) = body.first().and_then(token_command_word) else {
                continue;
            };
            match name {
                "INSTRUMENT" => manifest.uses_instrument = true,
                "SOUNDFONT" => {
                    let arguments = split_graph_arguments(&body[1..])?;
                    expect_graph_arity("SOUNDFONT", &arguments, 1, 3)?;
                    let path_index = arguments.len() - 1;
                    for voice in &arguments[..path_index] {
                        match voice {
                            [TokenInstance::Number(1..=16)] => {}
                            [TokenInstance::Number(_)] => return Err(Error::IllegalQuantity),
                            _ => {
                                return Err(Error::syntax(format!(
                                    "line {}: stored SOUNDFONT voice ranges must be literal 1..16 values",
                                    statement.line_number
                                )))
                            }
                        }
                    }
                    if arguments.len() == 3 {
                        let first = literal_asset_integer(
                            arguments[0],
                            statement.line_number,
                            "SOUNDFONT voice range",
                        )?;
                        let last = literal_asset_integer(
                            arguments[1],
                            statement.line_number,
                            "SOUNDFONT voice range",
                        )?;
                        if last < first {
                            return Err(Error::IllegalQuantity);
                        }
                    }
                    let path = literal_asset_string(
                        arguments[path_index],
                        statement.line_number,
                        "SOUNDFONT path",
                    )?;
                    if !path.to_ascii_lowercase().ends_with(".sf2") {
                        return Err(Error::syntax("SOUNDFONT requires a .sf2 bank"));
                    }
                    if seen_soundfonts.insert(path.clone()) {
                        manifest.soundfonts.push((path.clone(), path));
                    }
                }
                "BITMAP" => {
                    let tail = if body
                        .get(1)
                        .and_then(token_command_word)
                        .is_some_and(|word| word == "WARP")
                    {
                        &body[2..]
                    } else {
                        &body[1..]
                    };
                    let arguments = split_graph_arguments(tail)?;
                    if arguments.is_empty() {
                        return Err(Error::syntax("BITMAP requires an image path"));
                    }
                    let path =
                        literal_asset_string(arguments[0], statement.line_number, "BITMAP path")?;
                    if !generated_images.contains(&path) && seen_images.insert(path.clone()) {
                        manifest.images.push(path);
                    }
                }
                "FLIPBOOK" if body.get(1).and_then(token_command_word) == Some("CREATE") => {
                    let arguments = split_graph_arguments(&body[2..])?;
                    expect_graph_arity("FLIPBOOK CREATE", &arguments, 5, 5)?;
                    let template = literal_asset_string(
                        arguments[1],
                        statement.line_number,
                        "FLIPBOOK template",
                    )?;
                    let first = literal_asset_integer(
                        arguments[2],
                        statement.line_number,
                        "FLIPBOOK first frame",
                    )?;
                    let last = literal_asset_integer(
                        arguments[3],
                        statement.line_number,
                        "FLIPBOOK last frame",
                    )?;
                    let _fps = literal_asset_integer(
                        arguments[4],
                        statement.line_number,
                        "FLIPBOOK frame rate",
                    )?;
                    for path in expand_frame_template(&template, first, last)? {
                        if !generated_images.contains(&path) && seen_images.insert(path.clone()) {
                            manifest.images.push(path);
                        }
                    }
                }
                "PLAY" => {
                    let Some(kind) = body.get(1).and_then(token_command_word) else {
                        continue;
                    };
                    let arguments = split_graph_arguments(&body[2..])?;
                    let request = match kind {
                        "AUDIO" => arguments
                            .first()
                            .map(|path| (*path, ProgramMediaKind::Audio)),
                        "VIDEO" => arguments
                            .first()
                            .map(|path| (*path, ProgramMediaKind::Video)),
                        "FLIPBOOK" => arguments
                            .get(2)
                            .map(|path| (*path, ProgramMediaKind::Audio)),
                        _ => None,
                    };
                    if let Some((tokens, media_kind)) = request {
                        let path =
                            literal_asset_string(tokens, statement.line_number, "PLAY media path")?;
                        if !generated_media.contains(&path)
                            && seen_media.insert((path.clone(), media_kind))
                        {
                            manifest.media.push((path, media_kind));
                        }
                    }
                }
                "VIDEO" => {
                    let Some(command) = body.get(1).and_then(token_command_word) else {
                        continue;
                    };
                    if !matches!(command, "START" | "EXPORT") {
                        continue;
                    }
                    let arguments = split_graph_arguments(&body[2..])?;
                    if let Some(tokens) = arguments.get(2) {
                        let path = literal_asset_string(
                            tokens,
                            statement.line_number,
                            "VIDEO soundtrack path",
                        )?;
                        if !generated_media.contains(&path)
                            && seen_media.insert((path.clone(), ProgramMediaKind::Audio))
                        {
                            manifest.media.push((path, ProgramMediaKind::Audio));
                        }
                    }
                }
                _ => {}
            }
        }
        Ok(manifest)
    }

    fn retain_generated_image(&mut self, path: &str, source: &str) -> Result<(), Error> {
        let ppm = self.render_graphics_source(source)?;
        let image = Arc::new(
            read_ppm(std::io::Cursor::new(ppm.as_ref()))?
                .ok_or_else(|| Error::Io("generated image is empty".into()))?,
        );
        let extension = Path::new(path)
            .extension()
            .and_then(|value| value.to_str())
            .unwrap_or("img");
        let virtual_path = register_memory_image(&image, extension);
        self.prepared_images.insert(
            path.to_string(),
            PreparedImageAsset {
                image,
                virtual_path,
            },
        );
        Ok(())
    }

    /// Start whichever one of the native or SoundFont queues contains music.
    /// END, STOP, and the documented SOUND RESUME control all use this single
    /// implementation rather than separate playback commands.
    fn play_queued_audio(&mut self) -> Result<(), Error> {
        if !self.synth.is_enabled() || self.playback.is_active() {
            return Ok(());
        }
        match (self.synth.has_score(), self.sf_engine.has_score()) {
            (true, true) => {
                let wav = self.render_queued_audio_wav()?;
                self.playback.playback_wav_async(wav)
            }
            (false, true) => self.sf_engine.play_score_async(
                &self.playback,
                self.synth.soundfont_voice_mix(),
                self.synth.soundfont_voice_envelopes(),
                self.synth.soundfont_voice_dsp(),
                self.synth.master_volume(),
            ),
            (true, false) => self.synth.playback_async(&self.playback),
            (false, false) => Ok(()),
        }
    }

    fn render_queued_audio_wav(&self) -> Result<Vec<u8>, Error> {
        let music = match (self.synth.has_score(), self.sf_engine.has_score()) {
            (true, true) => {
                let native = self.synth.render_wav()?;
                let sampled = self.sf_engine.render_score_wav(
                    self.synth.soundfont_voice_mix(),
                    self.synth.soundfont_voice_envelopes(),
                    self.synth.soundfont_voice_dsp(),
                    self.synth.master_volume(),
                )?;
                Some(crate::synth::mix_stereo_pcm_wavs(&native, &sampled)?)
            }
            (false, true) => Some(self.sf_engine.render_score_wav(
                self.synth.soundfont_voice_mix(),
                self.synth.soundfont_voice_envelopes(),
                self.synth.soundfont_voice_dsp(),
                self.synth.master_volume(),
            )?),
            (true, false) => Some(self.synth.render_wav()?),
            (false, false) => None,
        };
        let vocals = (!self.singing_scores.is_empty())
            .then(|| crate::speech::render_singing_scores_wav(&self.singing_scores))
            .transpose()?;
        match (music, vocals) {
            (Some(music), Some(vocals)) => crate::synth::mix_stereo_pcm_wavs(&music, &vocals),
            (Some(music), None) => Ok(music),
            (None, Some(vocals)) => Ok(vocals),
            (None, None) => Err(Error::syntax("no synthesized audio has been created")),
        }
    }

    fn execute_save(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let path = self.evaluate_file_path(rest, "SAVE")?;
        let source = self
            .current_program
            .to_source_bytes(self.files.max_file_bytes())?;
        self.files.write_all(&path, &source)?;
        Ok(Control::Advance)
    }

    fn execute_save_binary(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let path = self.evaluate_file_path(rest, "SAVEB")?;
        let max_bytes = self
            .files
            .max_file_bytes()
            .min(DEFAULT_MAX_BINARY_PROGRAM_BYTES);
        let binary = self.current_program.to_binary_bytes(max_bytes)?;
        self.files.write_all(&path, &binary)?;
        Ok(Control::Advance)
    }

    fn execute_compile<W: Write>(
        &mut self,
        rest: &[TokenInstance],
        writer: &mut W,
    ) -> Result<Control, Error> {
        let path = self.evaluate_file_path(rest, "COMPILE")?;
        let output = self.files.output_path(&path)?;
        let build_path = format!("{path}.build");
        let build_directory = self.files.output_path(&build_path)?;
        crate::compiler::compile_program_in(&self.current_program, &output, &build_directory)?;
        writeln!(writer, "COMPILED {path}.")?;
        Ok(Control::Advance)
    }

    fn execute_verify(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let path = self.evaluate_file_path(rest, "VERIFY")?;
        let expected = self
            .current_program
            .to_source_bytes(self.files.max_file_bytes())?;
        let actual = self.files.read_all(&path)?;
        if actual != expected {
            return Err(Error::VerificationFailed);
        }
        Ok(Control::Advance)
    }

    fn evaluate_file_path(
        &mut self,
        rest: &[TokenInstance],
        statement: &str,
    ) -> Result<String, Error> {
        if rest.is_empty() {
            return Err(Error::syntax(format!(
                "{statement} requires a path expression"
            )));
        }
        self.evaluate_value(rest)?
            .into_string()
            .ok_or(Error::TypeMismatch)
    }

    fn execute_close(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            self.files.close_all()?;
            self.cmd_channel = None;
            return Ok(Control::Advance);
        }
        let channels = split_graph_arguments(rest)?;
        for channel in channels {
            let channel = channel
                .strip_prefix(&[TokenInstance::Hash])
                .unwrap_or(channel);
            if channel.is_empty() {
                return Err(Error::syntax("CLOSE requires a channel after '#'"));
            }
            let channel = FileStore::channel(self.evaluate_integer(channel)?)?;
            self.files.close(channel)?;
            if self.cmd_channel == Some(channel) {
                self.cmd_channel = None;
            }
        }
        Ok(Control::Advance)
    }

    fn execute_file_lock(
        &mut self,
        unlock: bool,
        rest: &[TokenInstance],
    ) -> Result<Control, Error> {
        let statement = if unlock { "UNLOCK" } else { "LOCK" };
        let arguments = split_graph_arguments(rest)?;
        if !(1..=2).contains(&arguments.len()) {
            return Err(Error::syntax(format!(
                "{statement} expects #channel [, start TO end]"
            )));
        }
        let Some(channel_tokens) = arguments[0].strip_prefix(&[TokenInstance::Hash]) else {
            return Err(Error::syntax(format!("{statement} channel requires '#'")));
        };
        if channel_tokens.is_empty() {
            return Err(Error::syntax(format!(
                "{statement} requires a channel after '#'"
            )));
        }
        let channel = FileStore::channel(self.evaluate_integer(channel_tokens)?)?;
        let range = if let Some(range) = arguments.get(1) {
            let Some(to) = range
                .iter()
                .position(|token| matches!(token, TokenInstance::Keyword(Token::To)))
            else {
                return Err(Error::syntax(format!(
                    "{statement} byte range requires start TO end"
                )));
            };
            if to == 0 || to + 1 == range.len() {
                return Err(Error::syntax(format!(
                    "{statement} byte range requires start TO end"
                )));
            }
            let start = self.evaluate_integer(&range[..to])?;
            let end = self.evaluate_integer(&range[to + 1..])?;
            let start = usize::try_from(start).map_err(|_| Error::IllegalQuantity)?;
            let end = usize::try_from(end).map_err(|_| Error::IllegalQuantity)?;
            Some((start, end))
        } else {
            None
        };
        if unlock {
            self.files.unlock(channel, range)?;
        } else {
            self.files.lock(channel, range)?;
        }
        Ok(Control::Advance)
    }

    fn execute_def_usr(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (index, mut position) = match rest.first() {
            Some(TokenInstance::Keyword(Token::Usr)) => match rest.get(1) {
                Some(TokenInstance::Number(value)) if (0..=9).contains(value) => {
                    (*value as usize, 2)
                }
                _ => (0, 1),
            },
            Some(TokenInstance::Ident(name)) if name.starts_with("USR") => {
                let suffix = &name[3..];
                let index = if suffix.is_empty() {
                    0
                } else {
                    suffix
                        .parse::<usize>()
                        .map_err(|_| Error::IllegalQuantity)?
                };
                if index > 9 {
                    return Err(Error::IllegalQuantity);
                }
                (index, 1)
            }
            _ => return Err(Error::syntax("DEF USR requires USR[n]=address")),
        };
        if !matches!(
            rest.get(position),
            Some(TokenInstance::Keyword(Token::Equal))
        ) {
            return Err(Error::syntax("DEF USR requires '='"));
        }
        position += 1;
        let address = self.evaluate_integer(&rest[position..])?;
        self.usr_addresses[index] =
            Some(usize::try_from(address).map_err(|_| Error::IllegalQuantity)?);
        Ok(Control::Advance)
    }

    fn execute_system_call(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("SYS/CALL requires a service address"));
        }
        let address = self.evaluate_integer(rest)?;
        let address = usize::try_from(address).map_err(|_| Error::IllegalQuantity)?;
        let service = self
            .system_services
            .get(&address)
            .copied()
            .ok_or(Error::SystemServiceNotRegistered { address })?;
        service(0)?;
        Ok(Control::Advance)
    }

    fn execute_call<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        let Some(TokenInstance::Ident(name)) = rest.first() else {
            return self.execute_system_call(rest);
        };
        let argument_tokens = match &rest[1..] {
            [] => Vec::new(),
            [TokenInstance::LParen, inside @ .., TokenInstance::RParen] => {
                split_graph_arguments(inside)?
            }
            _ => return Err(Error::syntax("CALL SUB expects name(argument, ...)")),
        };
        let definition = self
            .structured_definitions
            .subs
            .get(name)
            .cloned()
            .ok_or_else(|| Error::syntax(format!("undefined SUB {name}")))?;
        let arguments =
            self.prepare_procedure_arguments(&definition, argument_tokens, "SUB", input, writer)?;
        Ok(Control::CallSub {
            name: name.clone(),
            arguments,
        })
    }

    fn prepare_procedure_arguments<R: BufRead + ?Sized, W: Write>(
        &mut self,
        definition: &ProcedureDefinition,
        raw_arguments: Vec<&[TokenInstance]>,
        kind: &str,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Vec<ProcedureArgument>, Error> {
        if raw_arguments.len() != definition.parameters.len() {
            return Err(Error::syntax(format!(
                "{kind} {} expects {} arguments, got {}",
                definition.name,
                definition.parameters.len(),
                raw_arguments.len()
            )));
        }
        let mut arguments = Vec::with_capacity(raw_arguments.len());
        for (parameter, raw_argument) in definition.parameters.iter().zip(raw_arguments) {
            match (parameter.shape, parameter.mode) {
                (ParameterShape::Scalar, ParameterMode::ByVal) => {
                    let expression = self.resolve_function_calls(raw_argument, input, writer)?;
                    arguments.push(ProcedureArgument::Value(self.evaluate_value(&expression)?));
                }
                (ParameterShape::Scalar, ParameterMode::ByRef) => {
                    arguments.push(ProcedureArgument::Reference(
                        self.resolve_byref_argument(parameter, raw_argument)?,
                    ))
                }
                (ParameterShape::Array, ParameterMode::ByRef) => {
                    arguments.push(self.resolve_byref_array_argument(parameter, raw_argument)?)
                }
                (ParameterShape::Array, ParameterMode::ByVal) => {
                    return Err(Error::syntax("whole-array parameters require BYREF"));
                }
            }
        }
        Ok(arguments)
    }

    fn resolve_byref_array_argument(
        &self,
        parameter: &ProcedureParameter,
        tokens: &[TokenInstance],
    ) -> Result<ProcedureArgument, Error> {
        let [TokenInstance::Ident(name), TokenInstance::LParen, TokenInstance::RParen] = tokens
        else {
            return Err(Error::syntax(format!(
                "BYREF array parameter {} requires an array-name() argument",
                parameter.name
            )));
        };
        if let Some(actual_record_type) = self.record_instances.get(name) {
            let Some(formal_record_type) = parameter.record_type.as_ref() else {
                return Err(Error::syntax(format!(
                    "whole record array {name} requires a BYREF {}() AS {actual_record_type} formal",
                    parameter.name
                )));
            };
            if formal_record_type != actual_record_type {
                return Err(Error::syntax(format!(
                    "BYREF record-array parameter {} expects TYPE {}, but argument {} has TYPE {}",
                    parameter.name, formal_record_type, name, actual_record_type
                )));
            }
            let definition = self
                .structured_definitions
                .types
                .get(actual_record_type)
                .ok_or_else(|| Error::syntax(format!("undefined TYPE {actual_record_type}")))?;
            let mut fields = Vec::with_capacity(definition.fields.len());
            for field in &definition.fields {
                let qualified = format!("{name}.{}", field.name);
                if self.arrays.get(&qualified).is_none() {
                    return Err(Error::syntax(format!(
                        "BYREF record-array argument {name} is not dimensioned"
                    )));
                }
                fields.push((field.name.clone(), self.arrays.canonical_name(&qualified)));
            }
            let actual_base = self
                .procedure_stack
                .last()
                .and_then(|frame| frame.record_byref.get(name))
                .cloned()
                .unwrap_or_else(|| name.clone());
            return Ok(ProcedureArgument::RecordArrayReference {
                record_type: actual_record_type.clone(),
                actual_base,
                fields,
            });
        }
        if let Some(record_type) = &parameter.record_type {
            return Err(Error::syntax(format!(
                "BYREF record-array parameter {} expects TYPE {}, but argument {} is not a record array",
                parameter.name, record_type, name
            )));
        }
        let canonical = self.arrays.canonical_name(name);
        if self.arrays.get(name).is_none() {
            return Err(Error::syntax(format!(
                "BYREF array argument {name} is not dimensioned"
            )));
        }
        let formal_type = parameter.declaration;
        let actual_type = self.effective_variable_type(&canonical);
        if formal_type != actual_type {
            return Err(Error::syntax(format!(
                "BYREF array parameter {} has type {:?}, but argument {} has type {:?}",
                parameter.name, formal_type, name, actual_type
            )));
        }
        Ok(ProcedureArgument::ArrayReference(canonical))
    }

    fn resolve_byref_argument(
        &mut self,
        parameter: &ProcedureParameter,
        tokens: &[TokenInstance],
    ) -> Result<VariableReference, Error> {
        let lvalue = parse_list_lvalue(tokens, "BYREF argument")?;
        self.ensure_assignable(&lvalue.name)?;
        if self.record_instances.contains_key(&lvalue.name) {
            return Err(Error::syntax(format!(
                "whole record {} cannot be passed BYREF; pass one of its fields",
                lvalue.name
            )));
        }
        if !lvalue.subscripts.is_empty()
            && matches!(self.scalar_value(&lvalue.name)?, Some(Value::List(_)))
        {
            return Err(Error::syntax(
                "first-class list elements cannot be passed BYREF",
            ));
        }
        let reference = if lvalue.subscripts.is_empty() {
            self.resolve_scalar_reference(&lvalue.name)
        } else {
            let indices = lvalue
                .subscripts
                .iter()
                .map(|subscript| self.evaluate_integer(subscript))
                .collect::<Result<Vec<_>, _>>()?;
            self.arrays.ensure_element(&lvalue.name, &indices)?;
            VariableReference::ArrayElement {
                name: lvalue.name.clone(),
                indices,
            }
        };
        let formal_type = parameter.declaration;
        let actual_type = self.effective_variable_type(reference.name());
        if formal_type != actual_type {
            return Err(Error::syntax(format!(
                "BYREF parameter {} has type {:?}, but argument {} has type {:?}",
                parameter.name,
                formal_type,
                reference.name(),
                actual_type
            )));
        }
        Ok(reference)
    }

    fn resolve_function_calls<R: BufRead + ?Sized, W: Write>(
        &mut self,
        tokens: &[TokenInstance],
        input: &mut R,
        writer: &mut W,
    ) -> Result<Vec<TokenInstance>, Error> {
        let mut resolved = Vec::with_capacity(tokens.len());
        let mut position = 0usize;
        while position < tokens.len() {
            if matches!(tokens.get(position), Some(TokenInstance::Ident(name)) if name == "INPUT$")
                && matches!(tokens.get(position + 1), Some(TokenInstance::LParen))
            {
                let mut depth = 0usize;
                let mut close = None;
                for (index, token) in tokens.iter().enumerate().skip(position + 1) {
                    match token {
                        TokenInstance::LParen => depth = depth.saturating_add(1),
                        TokenInstance::RParen => {
                            depth = depth
                                .checked_sub(1)
                                .ok_or_else(|| Error::syntax("unmatched ')' in INPUT$ call"))?;
                            if depth == 0 {
                                close = Some(index);
                                break;
                            }
                        }
                        _ => {}
                    }
                }
                let close = close.ok_or_else(|| Error::syntax("unterminated INPUT$ call"))?;
                let arguments = split_graph_arguments(&tokens[position + 2..close])?;
                if !(1..=2).contains(&arguments.len()) {
                    return Err(Error::syntax("INPUT$ expects count[,#channel]"));
                }
                let count_tokens = self.resolve_function_calls(arguments[0], input, writer)?;
                let count = self.evaluate_integer(&count_tokens)?;
                if !(1..=MAX_INPUT_FUNCTION_COUNT as i64).contains(&count) {
                    return Err(Error::IllegalQuantity);
                }
                let count = count as usize;
                if count > self.max_string_bytes {
                    return Err(Error::StringTooLong {
                        length: count,
                        limit: self.max_string_bytes,
                    });
                }

                let channel = if let Some(argument) = arguments.get(1) {
                    let Some(channel_tokens) = argument.strip_prefix(&[TokenInstance::Hash]) else {
                        return Err(Error::syntax("INPUT$ file channel requires '#'"));
                    };
                    if channel_tokens.is_empty() {
                        return Err(Error::syntax("INPUT$ requires a channel after '#'"));
                    }
                    let channel_tokens =
                        self.resolve_function_calls(channel_tokens, input, writer)?;
                    Some(FileStore::channel(self.evaluate_integer(&channel_tokens)?)?)
                } else {
                    None
                };

                let mut bytes = vec![0u8; count];
                if let Some(channel) = channel {
                    for byte in &mut bytes {
                        *byte = self.files.read_byte(channel)?;
                    }
                } else {
                    input.read_exact(&mut bytes)?;
                }
                let text = String::from_utf8(bytes).map_err(|_| match channel {
                    Some(channel) => Error::BadFileData { channel },
                    None => Error::Io("INPUT$ read invalid UTF-8".into()),
                })?;
                resolved.push(TokenInstance::String(text));
                position = close + 1;
                continue;
            }

            if matches!(
                tokens.get(position),
                Some(TokenInstance::Keyword(Token::Piecewise))
            ) && matches!(tokens.get(position + 1), Some(TokenInstance::LParen))
            {
                let mut depth = 0usize;
                let mut close = None;
                for (index, token) in tokens.iter().enumerate().skip(position + 1) {
                    match token {
                        TokenInstance::LParen => depth = depth.saturating_add(1),
                        TokenInstance::RParen => {
                            depth = depth
                                .checked_sub(1)
                                .ok_or_else(|| Error::syntax("unmatched ')' in PIECEWISE call"))?;
                            if depth == 0 {
                                close = Some(index);
                                break;
                            }
                        }
                        _ => {}
                    }
                }
                let close = close.ok_or_else(|| Error::syntax("unterminated PIECEWISE call"))?;
                let inside = &tokens[position + 2..close];
                let arguments = split_graph_arguments(inside)?;
                if arguments.len() < 2 {
                    return Err(Error::syntax("PIECEWISE expects condition/value pairs"));
                }
                let pair_count = arguments.len() / 2;
                let mut selected = None;
                for pair in 0..pair_count {
                    let condition =
                        self.resolve_function_calls(arguments[pair * 2], input, writer)?;
                    if self.evaluate_value(&condition)?.numeric_truth()? {
                        selected = Some(arguments[pair * 2 + 1]);
                        break;
                    }
                }
                if selected.is_none() && arguments.len() % 2 == 1 {
                    selected = arguments.last().copied();
                }
                let selected = selected.ok_or(Error::MathDomain {
                    function: "PIECEWISE",
                })?;
                let selected = self.resolve_function_calls(selected, input, writer)?;
                resolved.push(TokenInstance::LParen);
                resolved.extend(selected);
                resolved.push(TokenInstance::RParen);
                position = close + 1;
                continue;
            }

            if let Some((name, open)) = self.user_function_call_at(tokens, position) {
                let mut depth = 0usize;
                let mut close = None;
                for (index, token) in tokens.iter().enumerate().skip(open) {
                    match token {
                        TokenInstance::LParen => depth = depth.saturating_add(1),
                        TokenInstance::RParen => {
                            depth = depth
                                .checked_sub(1)
                                .ok_or_else(|| Error::syntax("unmatched ')' in DEF FN call"))?;
                            if depth == 0 {
                                close = Some(index);
                                break;
                            }
                        }
                        _ => {}
                    }
                }
                let close = close.ok_or_else(|| Error::syntax("unterminated DEF FN call"))?;
                let raw_arguments = split_graph_arguments(&tokens[open + 1..close])?;
                let value = self.invoke_user_function(&name, raw_arguments, input, writer)?;
                resolved.extend(Self::function_result_tokens(value)?);
                position = close + 1;
                continue;
            }

            let Some(TokenInstance::Ident(name)) = tokens.get(position) else {
                resolved.push(tokens[position].clone());
                position += 1;
                continue;
            };
            let Some(definition) = self.structured_definitions.functions.get(name).cloned() else {
                resolved.push(tokens[position].clone());
                position += 1;
                continue;
            };
            if !matches!(tokens.get(position + 1), Some(TokenInstance::LParen)) {
                resolved.push(tokens[position].clone());
                position += 1;
                continue;
            }

            let mut depth = 0usize;
            let mut close = None;
            for (index, token) in tokens.iter().enumerate().skip(position + 1) {
                match token {
                    TokenInstance::LParen => depth = depth.saturating_add(1),
                    TokenInstance::RParen => {
                        depth = depth
                            .checked_sub(1)
                            .ok_or_else(|| Error::syntax("unmatched ')' in FUNCTION call"))?;
                        if depth == 0 {
                            close = Some(index);
                            break;
                        }
                    }
                    _ => {}
                }
            }
            let close = close.ok_or_else(|| Error::syntax("unterminated FUNCTION call"))?;
            let raw_arguments = split_graph_arguments(&tokens[position + 2..close])?;
            let arguments = self.prepare_procedure_arguments(
                &definition,
                raw_arguments,
                "FUNCTION",
                input,
                writer,
            )?;
            let value = self.invoke_function(&definition, arguments, input, writer)?;
            resolved.extend(Self::function_result_tokens(value)?);
            position = close + 1;
        }
        Ok(resolved)
    }

    fn user_function_call_at(
        &self,
        tokens: &[TokenInstance],
        position: usize,
    ) -> Option<(String, usize)> {
        match (
            tokens.get(position),
            tokens.get(position + 1),
            tokens.get(position + 2),
        ) {
            (Some(TokenInstance::Ident(identifier)), Some(TokenInstance::LParen), _)
                if !self
                    .structured_definitions
                    .functions
                    .contains_key(identifier) =>
            {
                let name = compact_function_name(identifier)?;
                self.user_functions.get(name)?;
                Some((name.to_string(), position + 1))
            }
            (
                Some(TokenInstance::Keyword(Token::Fn)),
                Some(TokenInstance::Ident(name)),
                Some(TokenInstance::LParen),
            ) => {
                self.user_functions.get(name)?;
                Some((name.clone(), position + 2))
            }
            _ => None,
        }
    }

    fn invoke_user_function<R: BufRead + ?Sized, W: Write>(
        &mut self,
        name: &str,
        raw_arguments: Vec<&[TokenInstance]>,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Value, Error> {
        let definition =
            self.user_functions
                .get(name)
                .cloned()
                .ok_or_else(|| Error::UndefinedFunction {
                    name: name.to_string(),
                })?;
        if raw_arguments.len() != definition.parameters.len() {
            return Err(Error::syntax(format!(
                "FN{name} expects {} arguments",
                definition.parameters.len()
            )));
        }
        if self.def_function_depth >= self.max_function_depth {
            return Err(Error::FunctionStackExceeded {
                limit: self.max_function_depth,
            });
        }

        let mut arguments = Vec::with_capacity(raw_arguments.len());
        for argument in raw_arguments {
            let argument = self.resolve_function_calls(argument, input, writer)?;
            let value = self.evaluate_value(&argument)?;
            if !value.is_numeric() {
                return Err(Error::TypeMismatch);
            }
            arguments.push(value);
        }

        let mut parameter_names = HashMap::new();
        let mut previous_values = Vec::with_capacity(arguments.len());
        for (index, (parameter, value)) in definition.parameters.iter().zip(arguments).enumerate() {
            let internal = format!("__DEF_FN_PARAM_{}_{}", self.def_function_depth, index);
            previous_values.push((internal.clone(), self.vars.insert(internal.clone(), value)));
            parameter_names.insert(parameter.clone(), internal);
        }

        self.def_function_depth = self.def_function_depth.saturating_add(1);
        let result = (|| {
            let mut body = Vec::with_capacity(definition.body.len());
            for (index, token) in definition.body.iter().enumerate() {
                if let TokenInstance::Ident(parameter) = token {
                    if !matches!(definition.body.get(index + 1), Some(TokenInstance::LParen)) {
                        if let Some(internal) = parameter_names.get(parameter) {
                            body.push(TokenInstance::Ident(internal.clone()));
                            continue;
                        }
                    }
                }
                body.push(token.clone());
            }
            let body = self.resolve_function_calls(&body, input, writer)?;
            let value = self.evaluate_value(&body)?;
            if value.is_numeric() {
                Ok(value)
            } else {
                Err(Error::TypeMismatch)
            }
        })();
        self.def_function_depth = self.def_function_depth.saturating_sub(1);
        for (name, previous) in previous_values {
            if let Some(previous) = previous {
                self.vars.insert(name, previous);
            } else {
                self.vars.remove(&name);
            }
        }
        result
    }

    fn invoke_function<R: BufRead + ?Sized, W: Write>(
        &mut self,
        definition: &ProcedureDefinition,
        arguments: Vec<ProcedureArgument>,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Value, Error> {
        self.enter_function(definition, arguments)?;
        self.function_result = None;
        let outcome = self.execute(
            input,
            writer,
            ExecutionEntry::Function(definition.start_pc + 1),
            false,
        )?;
        if outcome.termination != RunTermination::Exhausted {
            if matches!(
                self.procedure_stack.last(),
                Some(frame) if frame.kind == StructuredKind::Function
            ) {
                let _ = self.leave_function();
            }
            return Err(Error::syntax(
                "END, STOP, RUN, or READY commands cannot terminate a FUNCTION",
            ));
        }
        self.function_result
            .take()
            .ok_or_else(|| Error::syntax("FUNCTION ended without returning a value"))
    }

    fn function_result_tokens(value: Value) -> Result<Vec<TokenInstance>, Error> {
        let mut tokens = vec![TokenInstance::LParen];
        match value {
            Value::Integer(value) if value >= 0 => tokens.push(TokenInstance::Number(value)),
            Value::Integer(i64::MIN) => {
                tokens.push(TokenInstance::Keyword(Token::Minus));
                tokens.push(TokenInstance::Number(i64::MAX));
                tokens.push(TokenInstance::Keyword(Token::Minus));
                tokens.push(TokenInstance::Number(1));
            }
            Value::Integer(value) => {
                tokens.push(TokenInstance::Keyword(Token::Minus));
                tokens.push(TokenInstance::Number(-value));
            }
            Value::Real(value) => tokens.push(TokenInstance::Real(value.to_string())),
            Value::String(value) => tokens.push(TokenInstance::String(value)),
            Value::Complex(value) => {
                tokens.push(TokenInstance::Keyword(Token::Complex));
                tokens.push(TokenInstance::LParen);
                tokens.push(TokenInstance::Real(value.real().to_string()));
                tokens.push(TokenInstance::Comma);
                tokens.push(TokenInstance::Real(value.imaginary().to_string()));
                tokens.push(TokenInstance::RParen);
            }
            Value::List(_) => return Err(Error::TypeMismatch),
        }
        tokens.push(TokenInstance::RParen);
        Ok(tokens)
    }

    fn execute_wait(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let arguments = split_graph_arguments(rest)?;
        match arguments.as_slice() {
            [milliseconds] => {
                let milliseconds = self.evaluate_integer(milliseconds)?;
                if !(0..=3_600_000).contains(&milliseconds) {
                    return Err(Error::IllegalQuantity);
                }
                let mut remaining = milliseconds as u64;
                while remaining > 0 {
                    if take_interrupt() {
                        return Err(Error::Break);
                    }
                    let slice = remaining.min(10);
                    std::thread::sleep(Duration::from_millis(slice));
                    remaining -= slice;
                }
                Ok(Control::Advance)
            }
            [port, mask] | [port, mask, _] => {
                let port = self.evaluate_integer(port)?;
                let mask = self.evaluate_integer(mask)?;
                let invert = if let Some(argument) = arguments.get(2) {
                    self.evaluate_integer(argument)?
                } else {
                    0
                };
                if !(0..=65_535).contains(&port)
                    || !(0..=255).contains(&mask)
                    || !(0..=255).contains(&invert)
                {
                    return Err(Error::IllegalQuantity);
                }
                loop {
                    let value = self.virtual_ports[port as usize];
                    if ((value ^ invert as u8) & mask as u8) != 0 {
                        return Ok(Control::Advance);
                    }
                    if take_interrupt() {
                        return Err(Error::Break);
                    }
                    std::thread::sleep(Duration::from_millis(1));
                }
            }
            _ => Err(Error::syntax(
                "WAIT expects milliseconds or port, mask[, xor]",
            )),
        }
    }

    fn execute_locate(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let arguments = split_optional_arguments(rest, "LOCATE")?;
        if arguments.is_empty() || arguments.len() > 3 {
            return Err(Error::syntax(
                "LOCATE expects row[, column[, cursor_visible]]",
            ));
        }
        let row = arguments
            .first()
            .filter(|argument| !argument.is_empty())
            .map(|argument| self.evaluate_integer(argument))
            .transpose()?
            .map(|row| text_coordinate(row, TEXT_SCREEN_ROWS))
            .transpose()?
            .unwrap_or(self.cursor_row);
        let column = arguments
            .get(1)
            .filter(|argument| !argument.is_empty())
            .map(|argument| self.evaluate_integer(argument))
            .transpose()?
            .map(|column| text_coordinate(column, TEXT_SCREEN_COLUMNS))
            .transpose()?
            .unwrap_or(self.output_column.saturating_add(1));
        let visible = arguments
            .get(2)
            .filter(|argument| !argument.is_empty())
            .map(|argument| self.evaluate_integer(argument))
            .transpose()?
            .map_or(self.text_cursor_visible, |visible| visible != 0);
        if arguments.iter().all(|argument| argument.is_empty()) {
            return Err(Error::syntax("LOCATE requires at least one argument"));
        }
        self.set_text_cursor(row, column, visible);
        Ok(Control::Advance)
    }

    fn execute_view_print(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (top, bottom) = if rest.is_empty() {
            (1, TEXT_SCREEN_ROWS)
        } else {
            let Some(to) = rest
                .iter()
                .position(|token| matches!(token, TokenInstance::Keyword(Token::To)))
            else {
                return Err(Error::syntax("VIEW PRINT expects top TO bottom"));
            };
            let top = &rest[..to];
            let bottom = &rest[to + 1..];
            if top.is_empty() || bottom.is_empty() {
                return Err(Error::syntax("VIEW PRINT expects top TO bottom"));
            }
            let top = text_coordinate(self.evaluate_integer(top)?, TEXT_SCREEN_ROWS)?;
            let bottom = text_coordinate(self.evaluate_integer(bottom)?, TEXT_SCREEN_ROWS)?;
            (top, bottom)
        };
        if top > bottom {
            return Err(Error::IllegalQuantity);
        }
        self.view_print_top = top;
        self.view_print_bottom = bottom;
        emit_screen_event(ScreenEvent::SetPrintRegion { top, bottom });
        Ok(Control::Advance)
    }

    fn execute_graphics_view(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            self.graphics.reset_viewport()?;
            return Ok(Control::Advance);
        }
        let (screen_coordinates, rest) = match rest.split_first() {
            Some((token, tail))
                if token_command_word(token)
                    .is_some_and(|word| word.eq_ignore_ascii_case("SCREEN")) =>
            {
                (true, tail)
            }
            _ => (false, rest),
        };
        let (x1_tokens, y1_tokens, after_first) = parse_graphics_point(rest, 0)?;
        if !matches!(
            rest.get(after_first),
            Some(TokenInstance::Keyword(Token::Minus))
        ) {
            return Err(Error::syntax("VIEW requires (x1,y1)-(x2,y2)"));
        }
        let (x2_tokens, y2_tokens, after_second) = parse_graphics_point(rest, after_first + 1)?;
        let decoration = graphics_tail_arguments(rest, after_second)?;
        expect_graph_arity("VIEW", &decoration, 0, 2)?;
        let x1 = self.evaluate_integer(x1_tokens)?;
        let y1 = self.evaluate_integer(y1_tokens)?;
        let x2 = self.evaluate_integer(x2_tokens)?;
        let y2 = self.evaluate_integer(y2_tokens)?;
        let fill = decoration
            .first()
            .map(|argument| self.evaluate_graphics_color(argument))
            .transpose()?;
        let border = decoration
            .get(1)
            .map(|argument| self.evaluate_graphics_color(argument))
            .transpose()?;
        self.graphics
            .set_viewport(x1, y1, x2, y2, screen_coordinates)?;
        self.graphics
            .draw_viewport_decoration(fill.as_deref(), border.as_deref())?;
        if fill.is_some() || border.is_some() {
            let view = self.graphics_presentation_view();
            self.screen_view = view;
            self.present_graphics_scene(false, view);
        }
        Ok(Control::Advance)
    }

    fn execute_graphics_window(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            self.graphics.reset_window()?;
            return Ok(Control::Advance);
        }
        let (screen_coordinates, rest) = match rest.split_first() {
            Some((token, tail))
                if token_command_word(token)
                    .is_some_and(|word| word.eq_ignore_ascii_case("SCREEN")) =>
            {
                (true, tail)
            }
            _ => (false, rest),
        };
        let (x1_tokens, y1_tokens, after_first) = parse_graphics_point(rest, 0)?;
        if !matches!(
            rest.get(after_first),
            Some(TokenInstance::Keyword(Token::Minus))
        ) {
            return Err(Error::syntax("WINDOW requires (x1,y1)-(x2,y2)"));
        }
        let (x2_tokens, y2_tokens, after_second) = parse_graphics_point(rest, after_first + 1)?;
        expect_end_of_line(&rest[after_second..])?;
        let x1 = self.evaluate_graph_real(x1_tokens)?;
        let y1 = self.evaluate_graph_real(y1_tokens)?;
        let x2 = self.evaluate_graph_real(x2_tokens)?;
        let y2 = self.evaluate_graph_real(y2_tokens)?;
        self.graphics
            .set_window(x1, y1, x2, y2, screen_coordinates)?;
        Ok(Control::Advance)
    }

    fn execute_pcopy(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let arguments = split_graph_arguments(rest)?;
        expect_graph_arity("PCOPY", &arguments, 2, 2)?;
        let source = self.evaluate_integer(arguments[0])?;
        let destination = self.evaluate_integer(arguments[1])?;
        self.graphics.copy_page(source, destination)?;
        self.present_graphics_scene(true, self.graphics_presentation_view());
        Ok(Control::Advance)
    }

    fn execute_graphics_get(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (x1_tokens, y1_tokens, after_first) = parse_graphics_point(rest, 0)?;
        if !matches!(
            rest.get(after_first),
            Some(TokenInstance::Keyword(Token::Minus))
        ) {
            return Err(Error::syntax("graphics GET requires (x1,y1)-(x2,y2)"));
        }
        let (x2_tokens, y2_tokens, after_second) = parse_graphics_point(rest, after_first + 1)?;
        if !matches!(rest.get(after_second), Some(TokenInstance::Comma)) {
            return Err(Error::syntax("graphics GET requires an array name"));
        }
        let array = graphics_array_name(&rest[after_second + 1..], "GET")?;
        let x1 = self.evaluate_graph_real(x1_tokens)?;
        let y1 = self.evaluate_graph_real(y1_tokens)?;
        let x2 = self.evaluate_graph_real(x2_tokens)?;
        let y2 = self.evaluate_graph_real(y2_tokens)?;
        let (width, height, pixels) = self.graphics.capture_region(x1, y1, x2, y2)?;
        self.arrays
            .store_graphics_image(array, width, height, &pixels, &mut self.storage)?;
        Ok(Control::Advance)
    }

    fn execute_graphics_put(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (x_tokens, y_tokens, after) = parse_graphics_point(rest, 0)?;
        let arguments = graphics_tail_arguments(rest, after)?;
        expect_graph_arity("graphics PUT", &arguments, 1, 2)?;
        let array = graphics_array_name(arguments[0], "PUT")?;
        let action = match arguments
            .get(1)
            .and_then(|tokens| graphics_mode_word(tokens))
        {
            None | Some("PSET") => RasterAction::Pset,
            Some("PRESET") => RasterAction::Preset,
            Some("AND") => RasterAction::And,
            Some("OR") => RasterAction::Or,
            Some("XOR") => RasterAction::Xor,
            Some(_) => {
                return Err(Error::syntax(
                    "graphics PUT action must be PSET, PRESET, AND, OR, or XOR",
                ))
            }
        };
        let x = self.evaluate_graph_real(x_tokens)?;
        let y = self.evaluate_graph_real(y_tokens)?;
        let (width, height, pixels) = self.arrays.load_graphics_image(array)?;
        self.graphics
            .put_region(x, y, width, height, &pixels, action)?;
        let view = self.graphics_presentation_view();
        self.screen_view = view;
        self.present_graphics_scene(false, view);
        Ok(Control::Advance)
    }

    fn execute_text_tab(
        &mut self,
        rest: &[TokenInstance],
        vertical: bool,
    ) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax(if vertical {
                "VTAB expects one row"
            } else {
                "HTAB expects one column"
            }));
        }
        let value = self.evaluate_integer(rest)?;
        let value = text_coordinate(
            value,
            if vertical {
                TEXT_SCREEN_ROWS
            } else {
                TEXT_SCREEN_COLUMNS
            },
        )?;
        let row = if vertical { value } else { self.cursor_row };
        let column = if vertical {
            self.output_column.saturating_add(1)
        } else {
            value
        };
        self.set_text_cursor(row, column, self.text_cursor_visible);
        Ok(Control::Advance)
    }

    fn execute_sleep(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let seconds = if rest.is_empty() {
            0.0
        } else {
            graph_real(self.evaluate_value(rest)?)?
        };
        if !seconds.is_finite() || seconds < 0.0 {
            return Err(Error::IllegalQuantity);
        }
        if seconds == 0.0 {
            if !screen_attached() || !crate::screen::key_queue_attached() {
                return Ok(Control::Advance);
            }
            loop {
                if !crate::screen::pop_key().is_empty() {
                    return Ok(Control::Advance);
                }
                if take_interrupt() {
                    return Err(Error::Break);
                }
                std::thread::sleep(Duration::from_millis(10));
            }
        }
        let duration = Duration::try_from_secs_f64(seconds).map_err(|_| Error::IllegalQuantity)?;
        let Some(deadline) = Instant::now().checked_add(duration) else {
            return Err(Error::IllegalQuantity);
        };
        loop {
            if !crate::screen::pop_key().is_empty() {
                return Ok(Control::Advance);
            }
            if take_interrupt() {
                return Err(Error::Break);
            }
            let now = Instant::now();
            if now >= deadline {
                return Ok(Control::Advance);
            }
            std::thread::sleep((deadline - now).min(Duration::from_millis(10)));
        }
    }

    fn execute_text_color(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let arguments = split_graph_arguments(rest)?;
        if arguments.len() > 2 {
            return Err(Error::syntax(
                "TEXTCOLOR expects [foreground[, background]]",
            ));
        }
        let (foreground, background) = match arguments.as_slice() {
            [] => (DEFAULT_TEXT_COLOR_FG, DEFAULT_TEXT_COLOR_BG),
            [foreground] => (self.evaluate_text_color(foreground)?, self.text_color_bg),
            [foreground, background] => (
                self.evaluate_text_color(foreground)?,
                self.evaluate_text_color(background)?,
            ),
            _ => unreachable!(),
        };
        self.text_color_fg = foreground;
        self.text_color_bg = background;
        emit_screen_event(ScreenEvent::SetTextColors {
            foreground,
            background,
        });
        Ok(Control::Advance)
    }

    fn evaluate_text_color(&mut self, tokens: &[TokenInstance]) -> Result<i64, Error> {
        let color = self.evaluate_integer(tokens)?;
        if !(0..=0xff_ffff).contains(&color) {
            return Err(Error::IllegalQuantity);
        }
        Ok(color)
    }

    fn set_text_cursor(&mut self, row: usize, column: usize, visible: bool) {
        self.cursor_row = row.clamp(1, TEXT_SCREEN_ROWS);
        self.output_column = column.clamp(1, TEXT_SCREEN_COLUMNS) - 1;
        self.text_cursor_visible = visible;
        emit_screen_event(ScreenEvent::SetTextCursor {
            row: self.cursor_row,
            column: self.output_column + 1,
            visible,
        });
    }

    fn advance_text_row(&mut self) {
        if (self.view_print_top..=self.view_print_bottom).contains(&self.cursor_row) {
            if self.cursor_row < self.view_print_bottom {
                self.cursor_row += 1;
            }
        } else {
            self.cursor_row = self.cursor_row.saturating_add(1).min(TEXT_SCREEN_ROWS);
        }
    }

    fn execute_cmd<W: Write>(
        &mut self,
        rest: &[TokenInstance],
        writer: &mut W,
    ) -> Result<Control, Error> {
        let start = usize::from(matches!(rest.first(), Some(TokenInstance::Hash)));
        if start == rest.len() {
            return Err(Error::syntax("CMD requires a channel"));
        }
        let (value, position) = self.evaluate_value_at(rest, start)?;
        let channel = FileStore::channel(value.to_integer()?)?;
        if channel == 0 {
            self.cmd_channel = None;
        } else {
            self.files.ensure_writable(channel)?;
            self.cmd_channel = Some(channel);
        }
        if position == rest.len() {
            return Ok(Control::Advance);
        }
        if !matches!(rest.get(position), Some(TokenInstance::Comma)) {
            return Err(Error::syntax("CMD expects channel[, print-list]"));
        }
        self.execute_print(&rest[position + 1..], writer)?;
        Ok(Control::Advance)
    }

    fn execute_print_file(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (channel, pos) = self.evaluate_file_channel_prefix(rest, "PRINT#")?;
        self.files.ensure_writable(channel)?;
        let mut column = self.files.output_column(channel)?;
        let mut bytes = Vec::new();
        self.render_print(&rest[pos..], &mut bytes, &mut column)?;
        self.files.write(channel, &bytes)?;
        Ok(Control::Advance)
    }

    fn execute_write_file(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (channel, pos) = self.evaluate_file_channel_prefix(rest, "WRITE#")?;
        self.files.ensure_writable(channel)?;
        let mut bytes = Vec::new();
        self.render_write(&rest[pos..], &mut bytes)?;
        self.files.write(channel, &bytes)?;
        Ok(Control::Advance)
    }

    fn execute_input_file(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (channel, pos) = self.evaluate_file_channel_prefix(rest, "INPUT#")?;
        let destinations = self.resolve_destinations(parse_input_list(&rest[pos..])?)?;
        let line = self.files.read_line(channel, self.max_input_bytes)?;
        let fields = split_input_fields(&line);
        if fields.len() < destinations.len() {
            return Err(Error::BadFileData { channel });
        }
        let values = destinations
            .iter()
            .zip(fields.iter())
            .map(|(destination, field)| {
                convert_input_field(
                    field,
                    self.is_string_destination(&destination.name),
                    self.mode,
                    self.max_string_bytes,
                )
                .map_err(|_| Error::BadFileData { channel })
            })
            .collect::<Result<Vec<_>, _>>()?;
        self.store_destinations(&destinations, values)?;
        Ok(Control::Advance)
    }

    fn execute_line_input_file(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (channel, pos) = self.evaluate_file_channel_prefix(rest, "LINE INPUT#")?;
        let destinations = self.resolve_destinations(parse_input_list(&rest[pos..])?)?;
        if destinations.len() != 1 || !self.is_string_destination(&destinations[0].name) {
            return Err(Error::syntax("LINE INPUT# expects one string variable"));
        }
        let value = self.files.read_line(channel, self.max_input_bytes)?;
        self.store_destinations(&destinations, vec![Value::String(value)])?;
        Ok(Control::Advance)
    }

    fn evaluate_file_channel_prefix(
        &mut self,
        rest: &[TokenInstance],
        statement: &str,
    ) -> Result<(u8, usize), Error> {
        let (channel, position) = self.evaluate_file_channel_head(rest, statement)?;
        let position = position
            .ok_or_else(|| Error::syntax(format!("{statement} channel must be followed by ','")))?;
        Ok((channel, position))
    }

    fn evaluate_file_channel_head(
        &mut self,
        rest: &[TokenInstance],
        statement: &str,
    ) -> Result<(u8, Option<usize>), Error> {
        if rest.is_empty() {
            return Err(Error::syntax(format!("{statement} requires a channel")));
        }
        let start = usize::from(matches!(rest.first(), Some(TokenInstance::Hash)));
        if start == rest.len() {
            return Err(Error::syntax(format!("{statement} requires a channel")));
        }
        let mut paren_depth = 0usize;
        let mut brace_depth = 0usize;
        let mut separator = None;
        for (index, token) in rest.iter().enumerate().skip(start) {
            match token {
                TokenInstance::LParen => paren_depth = paren_depth.saturating_add(1),
                TokenInstance::RParen => {
                    paren_depth = paren_depth.checked_sub(1).ok_or_else(|| {
                        Error::syntax(format!("unexpected ')' in {statement} channel"))
                    })?;
                }
                TokenInstance::LBrace => brace_depth = brace_depth.saturating_add(1),
                TokenInstance::RBrace => {
                    brace_depth = brace_depth.checked_sub(1).ok_or_else(|| {
                        Error::syntax(format!("unexpected '}}' in {statement} channel"))
                    })?;
                }
                TokenInstance::Comma if paren_depth == 0 && brace_depth == 0 => {
                    separator = Some(index);
                    break;
                }
                _ => {}
            }
        }
        let pos = separator.unwrap_or(rest.len());
        if pos == start {
            return Err(Error::syntax(format!("{statement} requires a channel")));
        }
        let value = self.evaluate_value(&rest[start..pos])?;
        let value = BasicInteger::with_mode(self.mode, value.to_integer()?)?.value();
        let channel = FileStore::channel(value)?;
        Ok((channel, separator.map(|position| position + 1)))
    }

    fn execute_get<R: BufRead + ?Sized>(
        &mut self,
        rest: &[TokenInstance],
        line_number: u64,
        input: &mut R,
    ) -> Result<Control, Error> {
        let destinations = self.resolve_destinations(parse_get_list(rest)?)?;
        let mut values = Vec::with_capacity(destinations.len());
        for destination in &destinations {
            let byte = read_get_byte(input, line_number)?;
            values.push(convert_get_byte(
                byte,
                self.is_string_destination(&destination.name),
                self.mode,
                self.max_string_bytes,
                line_number,
            )?);
        }
        self.store_destinations(&destinations, values)?;
        Ok(Control::Advance)
    }

    fn execute_get_file(
        &mut self,
        rest: &[TokenInstance],
        line_number: u64,
    ) -> Result<Control, Error> {
        let (channel, position) = self.evaluate_file_channel_head(rest, "GET#")?;
        let binary = self.files.is_binary(channel)?;
        let random = self.files.is_random(channel)?;
        if let Some(position) = position {
            if let Some(transfer) = self.parse_direct_record_transfer(&rest[position..], "GET")? {
                if !binary && !random {
                    return Err(Error::FileModeMismatch { channel });
                }
                let record_or_position = transfer
                    .position
                    .map(|tokens| self.evaluate_integer(&tokens))
                    .transpose()?
                    .map(|value| usize::try_from(value).map_err(|_| Error::IllegalQuantity))
                    .transpose()?;
                let target = self.resolve_direct_record_target(&transfer.target, true)?;
                let expected = self.direct_record_len(&target.definition)?;
                let bytes = if binary {
                    if let Some(position) = record_or_position {
                        self.files.seek_binary(channel, position)?;
                    }
                    self.files.read_binary_exact(channel, expected)?
                } else {
                    if expected > self.files.random_record_len(channel)? {
                        return Err(Error::IllegalQuantity);
                    }
                    self.files.get_random_record(channel, record_or_position)?
                };
                let values = self.decode_direct_record(&target, &bytes, channel)?;
                self.store_direct_record(&target, values)?;
                return Ok(Control::Advance);
            }
        }
        if random {
            let (channel, record) = self.parse_random_channel_record(rest, "GET")?;
            let buffer = self.files.get_random_record(channel, record)?;
            let bindings = self
                .random_fields
                .get(&channel)
                .cloned()
                .unwrap_or_default();
            for (name, offset, width) in bindings {
                let value = String::from_utf8_lossy(&buffer[offset..offset + width]).into_owned();
                self.assign(name, Value::String(value))?;
            }
            return Ok(Control::Advance);
        }

        self.files.ensure_readable(channel)?;
        let position = position
            .ok_or_else(|| Error::syntax("GET# channel must be followed by a destination"))?;
        let destinations = self.resolve_destinations(parse_get_list(&rest[position..])?)?;
        let mut values = Vec::with_capacity(destinations.len());
        for destination in &destinations {
            let byte = self.files.read_byte(channel)?;
            let value = convert_get_byte(
                byte,
                self.is_string_destination(&destination.name),
                self.mode,
                self.max_string_bytes,
                line_number,
            )
            .map_err(|error| match error {
                Error::BadInput { .. } => Error::BadFileData { channel },
                other => other,
            })?;
            values.push(value);
        }
        self.store_destinations(&destinations, values)?;
        Ok(Control::Advance)
    }

    /// Resolve every subscript before runtime input is consumed.
    fn resolve_destinations(&mut self, lvalues: Vec<Lvalue>) -> Result<Vec<ResolvedLvalue>, Error> {
        let mut destinations = Vec::with_capacity(lvalues.len());
        for lvalue in lvalues {
            self.ensure_assignable(&lvalue.name)?;
            let indices = lvalue
                .subscripts
                .iter()
                .map(|subscript| self.evaluate_integer(subscript))
                .collect::<Result<Vec<_>, _>>()?;
            if !indices.is_empty() {
                self.arrays.ensure_element(&lvalue.name, &indices)?;
            }
            destinations.push(ResolvedLvalue {
                name: lvalue.name,
                indices,
            });
        }
        Ok(destinations)
    }

    /// Commit a fully converted input statement atomically.
    fn store_destinations(
        &mut self,
        destinations: &[ResolvedLvalue],
        values: Vec<Value>,
    ) -> Result<(), Error> {
        debug_assert_eq!(destinations.len(), values.len());
        let values = destinations
            .iter()
            .zip(values)
            .map(|(destination, value)| self.coerce_default_assignment(&destination.name, value))
            .collect::<Result<Vec<_>, _>>()?;
        let mut staged_storage = self.storage.clone();
        let mut staged_values: HashMap<&ResolvedLvalue, &Value> = HashMap::new();
        for (destination, value) in destinations.iter().zip(values.iter()) {
            let previous = if let Some(staged) = staged_values.get(destination) {
                Some((*staged).clone())
            } else if destination.indices.is_empty() {
                self.scalar_value(&destination.name)?
            } else {
                self.arrays
                    .stored_value(&destination.name, &destination.indices)?
                    .cloned()
            };
            staged_storage.replace(previous.as_ref(), value)?;
            staged_values.insert(destination, value);
        }

        for (destination, value) in destinations.iter().zip(values) {
            if destination.indices.is_empty() {
                self.assign(destination.name.clone(), value)?;
            } else {
                self.arrays.store_bounded(
                    &destination.name,
                    &destination.indices,
                    value,
                    &mut self.storage,
                )?;
            }
        }
        Ok(())
    }

    fn execute_restore(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            self.data_cursor.reset();
        } else {
            let line = parse_line_number(rest)?;
            self.data_cursor.restore_line(line);
        }
        Ok(Control::Advance)
    }

    fn execute_clear(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        expect_end_of_line(rest)?;
        if !self.procedure_stack.is_empty() {
            return Err(Error::syntax("CLEAR is not allowed inside SUB or FUNCTION"));
        }
        let constants = self.constants.clone();
        let values = constants
            .iter()
            .filter_map(|name| {
                self.vars
                    .get(name)
                    .map(|value| (name.clone(), value.clone()))
            })
            .collect::<Vec<_>>();
        self.clear_program_state();
        for (name, value) in values {
            Self::assign_to_store(&mut self.vars, &mut self.storage, name, value)?;
        }
        self.constants = constants;
        // The random generator belongs to the program run, not the variable
        // store. CLEAR therefore preserves sequence continuity.
        Ok(Control::Advance)
    }

    // ---- MS-BASIC extension statement implementations ----

    fn execute_select(&mut self, body: &[TokenInstance]) -> Result<Control, Error> {
        let expression = select_expression(body)?;
        let selector = self.evaluate_value(expression)?;
        if matches!(selector, Value::Complex(_) | Value::List(_)) {
            return Err(Error::TypeMismatch);
        }
        Ok(Control::Select(selector))
    }

    fn select_case_target<R: BufRead + ?Sized, W: Write>(
        &mut self,
        statements: &[Statement],
        select_pc: usize,
        selector: &Value,
        input: &mut R,
        writer: &mut W,
    ) -> Result<usize, Error> {
        let mut nested = 0usize;
        let mut default_branch = None;
        for (index, statement) in statements.iter().enumerate().skip(select_pc + 1) {
            if is_select_start(statement) {
                nested = nested.saturating_add(1);
                continue;
            }
            if is_select_end(statement) {
                if nested == 0 {
                    return Ok(default_branch.map_or(index + 1, |branch| branch + 1));
                }
                nested -= 1;
                continue;
            }
            if nested != 0 || !is_case_branch(statement) {
                continue;
            }
            if is_default_case(statement) {
                default_branch = Some(index);
                continue;
            }
            if self.case_clause_matches(selector, &statement.body[1..], input, writer)? {
                return Ok(index + 1);
            }
        }
        Err(Error::syntax("SELECT/CASE without matching end"))
    }

    fn case_clause_matches<R: BufRead + ?Sized, W: Write>(
        &mut self,
        selector: &Value,
        clause: &[TokenInstance],
        input: &mut R,
        writer: &mut W,
    ) -> Result<bool, Error> {
        let items = split_case_items(clause)?;
        for item in items {
            if self.case_item_matches(selector, item, input, writer)? {
                return Ok(true);
            }
        }
        Ok(false)
    }

    fn case_item_matches<R: BufRead + ?Sized, W: Write>(
        &mut self,
        selector: &Value,
        item: &[TokenInstance],
        input: &mut R,
        writer: &mut W,
    ) -> Result<bool, Error> {
        let relation_start =
            matches!(item.first(), Some(TokenInstance::Ident(name)) if name == "IS");
        let relation_tokens = if relation_start { &item[1..] } else { item };
        if let Some((relation, consumed)) = parse_case_relation(relation_tokens) {
            let expression = &relation_tokens[consumed..];
            if expression.is_empty() {
                return Err(Error::syntax("CASE relation requires an expression"));
            }
            let expression = self.resolve_function_calls(expression, input, writer)?;
            let candidate = self.evaluate_value(&expression)?;
            let ordering = eval::compare_case_values(selector, &candidate)?;
            return Ok(case_relation_matches(ordering, relation));
        }
        if relation_start {
            return Err(Error::syntax("CASE IS requires a comparison operator"));
        }

        if let Some(to) = top_level_case_to(item)? {
            let lower_tokens = &item[..to];
            let upper_tokens = &item[to + 1..];
            if lower_tokens.is_empty() || upper_tokens.is_empty() {
                return Err(Error::syntax("CASE range requires both bounds"));
            }
            let lower_tokens = self.resolve_function_calls(lower_tokens, input, writer)?;
            let upper_tokens = self.resolve_function_calls(upper_tokens, input, writer)?;
            let lower = self.evaluate_value(&lower_tokens)?;
            let upper = self.evaluate_value(&upper_tokens)?;
            let lower_order = eval::compare_case_values(selector, &lower)?;
            let upper_order = eval::compare_case_values(selector, &upper)?;
            return Ok(!lower_order.is_lt() && !upper_order.is_gt());
        }

        let item = self.resolve_function_calls(item, input, writer)?;
        let candidate = self.evaluate_value(&item)?;
        Ok(eval::compare_case_values(selector, &candidate)?.is_eq())
    }
    fn push_structured_loop(&mut self, marker: &str, pc: usize) -> Result<(), Error> {
        let reentering = self
            .loop_stack
            .last()
            .is_some_and(|frame| frame.var == marker && frame.resume_pc == pc);
        if reentering {
            return Ok(());
        }
        if self.loop_stack.len() >= self.max_loop_depth {
            return Err(Error::LoopStackExceeded {
                limit: self.max_loop_depth,
            });
        }
        self.loop_stack.push(LoopFrame {
            var: marker.to_string(),
            limit: 0,
            step: 0,
            resume_pc: pc,
        });
        Ok(())
    }

    fn execute_do<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        pc: usize,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        let condition = if rest.is_empty() {
            None
        } else {
            let until = match rest.first() {
                Some(TokenInstance::Keyword(Token::While)) => false,
                Some(TokenInstance::Ident(name)) if name == "UNTIL" => true,
                _ => return Err(Error::syntax("expected DO, DO WHILE, or DO UNTIL")),
            };
            let expression = &rest[1..];
            if expression.is_empty() {
                return Err(Error::syntax("DO condition is missing"));
            }
            Some((until, expression))
        };

        let marker = "\x00DO";
        let reentering = self
            .loop_stack
            .last()
            .is_some_and(|frame| frame.var == marker && frame.resume_pc == pc);
        if let Some((until, expression)) = condition {
            let expression = self.resolve_function_calls(expression, input, writer)?;
            let truth = self.evaluate_value(&expression)?.numeric_truth()?;
            let enter = if until { !truth } else { truth };
            if !enter {
                if reentering {
                    self.loop_stack.pop();
                }
                return Ok(Control::SkipDo);
            }
        }
        self.push_structured_loop(marker, pc)?;
        Ok(Control::Advance)
    }

    fn execute_loop<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        let condition = if rest.is_empty() {
            None
        } else {
            let until = match rest.first() {
                Some(TokenInstance::Keyword(Token::While)) => false,
                Some(TokenInstance::Ident(name)) if name == "UNTIL" => true,
                _ => return Err(Error::syntax("expected LOOP, LOOP WHILE, or LOOP UNTIL")),
            };
            let expression = &rest[1..];
            if expression.is_empty() {
                return Err(Error::syntax("LOOP condition is missing"));
            }
            Some((until, expression))
        };

        let Some(frame) = self.loop_stack.last() else {
            return Err(Error::syntax("LOOP without DO"));
        };
        if frame.var != "\x00DO" {
            return Err(Error::syntax("LOOP without DO"));
        }
        let resume_pc = frame.resume_pc;
        let repeat = if let Some((until, expression)) = condition {
            let expression = self.resolve_function_calls(expression, input, writer)?;
            let truth = self.evaluate_value(&expression)?.numeric_truth()?;
            if until {
                !truth
            } else {
                truth
            }
        } else {
            true
        };
        if repeat {
            Ok(Control::Resume {
                pc: resume_pc,
                loop_depth: self.loop_stack.len(),
            })
        } else {
            self.loop_stack.pop();
            Ok(Control::Advance)
        }
    }

    fn execute_repeat(&mut self, rest: &[TokenInstance], pc: usize) -> Result<Control, Error> {
        expect_end_of_line(rest)?;
        self.push_structured_loop("\x00REPEAT", pc)?;
        Ok(Control::Advance)
    }

    fn execute_until<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("UNTIL requires a condition"));
        }
        let Some(frame) = self.loop_stack.last() else {
            return Err(Error::syntax("UNTIL without REPEAT"));
        };
        if frame.var != "\x00REPEAT" {
            return Err(Error::syntax("UNTIL without REPEAT"));
        }
        let resume_pc = frame.resume_pc;
        let condition = self.resolve_function_calls(rest, input, writer)?;
        if self.evaluate_value(&condition)?.numeric_truth()? {
            self.loop_stack.pop();
            Ok(Control::Advance)
        } else {
            Ok(Control::Resume {
                pc: resume_pc,
                loop_depth: self.loop_stack.len(),
            })
        }
    }
    fn execute_exit_loop(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let kind = match rest {
            [TokenInstance::Ident(name)] if name == "DO" => LoopExitKind::Do,
            [TokenInstance::Keyword(Token::For)] => LoopExitKind::For,
            [TokenInstance::Keyword(Token::While)] => LoopExitKind::While,
            [TokenInstance::Ident(name)] if name == "REPEAT" => LoopExitKind::Repeat,
            _ => return Err(Error::syntax("EXIT expects DO, FOR, WHILE, or REPEAT")),
        };
        let position = self.loop_stack.iter().rposition(|frame| match kind {
            LoopExitKind::Do => frame.var == "\x00DO",
            LoopExitKind::For => !frame.var.starts_with('\x00'),
            LoopExitKind::While => frame.var == "\x00WHILE",
            LoopExitKind::Repeat => frame.var == "\x00REPEAT",
        });
        let Some(position) = position else {
            return Err(Error::syntax(format!("EXIT {kind:?} without active loop")));
        };
        self.loop_stack.truncate(position);
        Ok(Control::ExitLoop(kind))
    }

    fn execute_while<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        pc: usize,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("WHILE requires a condition"));
        }
        let condition = self.resolve_function_calls(rest, input, writer)?;
        let cond = self.evaluate_value(&condition)?;
        let is_true = match cond {
            Value::Integer(n) => n != 0,
            Value::Real(r) => r.value() != 0.0,
            _ => return Err(Error::TypeMismatch),
        };
        let reentering = self
            .loop_stack
            .last()
            .is_some_and(|frame| frame.var == "\x00WHILE" && frame.resume_pc == pc);
        if !is_true {
            if reentering {
                self.loop_stack.pop();
            }
            return Ok(Control::SkipWhile);
        }
        if !reentering {
            if self.loop_stack.len() >= self.max_loop_depth {
                return Err(Error::LoopStackExceeded {
                    limit: self.max_loop_depth,
                });
            }
            self.loop_stack.push(LoopFrame {
                var: "\x00WHILE".to_string(),
                limit: 0,
                step: 0,
                resume_pc: pc,
            });
        }
        Ok(Control::Advance)
    }

    fn execute_wend(&mut self) -> Result<Control, Error> {
        if self.loop_stack.is_empty() {
            return Err(Error::syntax("WEND without WHILE"));
        }
        let frame = self.loop_stack.last().unwrap();
        if frame.var != "\x00WHILE" {
            return Err(Error::syntax("WEND without WHILE"));
        }
        let resume_pc = frame.resume_pc;
        Ok(Control::Resume {
            pc: resume_pc,
            loop_depth: self.loop_stack.len(),
        })
    }

    fn execute_change(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let [TokenInstance::Ident(source), TokenInstance::Keyword(Token::To), TokenInstance::Ident(destination)] =
            rest
        else {
            return Err(Error::syntax("CHANGE expects source TO destination"));
        };
        if is_string_variable(destination) {
            self.ensure_assignable(destination)?;
        }

        match (is_string_variable(source), is_string_variable(destination)) {
            (true, false) => {
                let text = match self.scalar_value(source)? {
                    Some(Value::String(text)) => text,
                    None => String::new(),
                    Some(_) => return Err(Error::TypeMismatch),
                };
                let character_count = text.chars().count();
                let length = i64::try_from(character_count).map_err(|_| Error::ArrayTooLarge)?;
                let length = BasicInteger::with_mode(self.mode, length)?.value();
                let mut values =
                    Vec::with_capacity(character_count.checked_add(1).ok_or(Error::ArrayTooLarge)?);
                values.push(Value::Integer(length));
                for character in text.chars() {
                    let code = i64::from(character as u32);
                    if code > 255 {
                        return Err(Error::IllegalQuantity);
                    }
                    values.push(Value::Integer(
                        BasicInteger::with_mode(self.mode, code)?.value(),
                    ));
                }

                let mut arrays = self.arrays.clone();
                let mut storage = self.storage.clone();
                for (index, value) in values.into_iter().enumerate() {
                    arrays.store_bounded(destination, &[index as i64], value, &mut storage)?;
                }
                self.arrays = arrays;
                self.storage = storage;
            }
            (false, true) => {
                let mut arrays = self.arrays.clone();
                let length = arrays.load(source, &[0])?.to_integer()?;
                let length = usize::try_from(length).map_err(|_| Error::IllegalQuantity)?;
                if length > self.max_string_bytes {
                    return Err(Error::StringTooLong {
                        length,
                        limit: self.max_string_bytes,
                    });
                }
                let mut text = String::with_capacity(length);
                for index in 1..=length {
                    let code = arrays.load(source, &[index as i64])?.to_integer()?;
                    if !(0..=255).contains(&code) {
                        return Err(Error::IllegalQuantity);
                    }
                    text.push(char::from_u32(code as u32).ok_or(Error::IllegalQuantity)?);
                    if text.len() > self.max_string_bytes {
                        return Err(Error::StringTooLong {
                            length: text.len(),
                            limit: self.max_string_bytes,
                        });
                    }
                }

                self.assign(destination.clone(), Value::String(text))?;
                self.arrays = arrays;
            }
            _ => return Err(Error::TypeMismatch),
        }
        Ok(Control::Advance)
    }

    fn execute_swap(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let comma = rest
            .iter()
            .position(|t| matches!(t, TokenInstance::Comma))
            .ok_or_else(|| Error::syntax("SWAP requires two variables separated by comma"))?;
        let (a_tokens, b_tokens) = rest.split_at(comma);
        let b_tokens = &b_tokens[1..]; // skip comma
        let a_name = match a_tokens {
            [TokenInstance::Ident(name)] => name.clone(),
            _ => return Err(Error::syntax("SWAP requires variable names")),
        };
        let b_name = match b_tokens {
            [TokenInstance::Ident(name)] => name.clone(),
            _ => return Err(Error::syntax("SWAP requires variable names")),
        };
        self.ensure_assignable(&a_name)?;
        self.ensure_assignable(&b_name)?;
        let a_val = self.scalar_value(&a_name)?.unwrap_or(Value::Integer(0));
        let b_val = self.scalar_value(&b_name)?.unwrap_or(Value::Integer(0));
        self.assign(b_name, a_val)?;
        self.assign(a_name, b_val)?;
        Ok(Control::Advance)
    }

    fn execute_write<W: Write>(
        &mut self,
        rest: &[TokenInstance],
        writer: &mut W,
    ) -> Result<Control, Error> {
        let mut bytes = Vec::new();
        self.render_write(rest, &mut bytes)?;
        writer.write_all(&bytes)?;
        for _ in bytes.iter().filter(|byte| **byte == b'\n') {
            self.advance_text_row();
        }
        self.output_column = 0;
        Ok(Control::Advance)
    }

    fn render_write<W: Write>(
        &mut self,
        rest: &[TokenInstance],
        writer: &mut W,
    ) -> Result<(), Error> {
        let items = split_write_items(rest)?;
        let mut first = true;
        for item in &items {
            if !first {
                write!(writer, ",").map_err(|e| Error::Io(e.to_string()))?;
            }
            first = false;
            if item.is_empty() {
                continue;
            }
            let value = self.evaluate_value(item)?;
            match &value {
                Value::String(s) => {
                    let escaped = s.replace('"', "\"\"");
                    write!(writer, "\"{escaped}\"").map_err(|e| Error::Io(e.to_string()))?;
                }
                _ => {
                    write!(writer, "{}", value).map_err(|e| Error::Io(e.to_string()))?;
                }
            }
        }
        writeln!(writer).map_err(|e| Error::Io(e.to_string()))?;
        Ok(())
    }

    fn execute_randomize(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            // Seed from system time
            let seed = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_nanos() as u64)
                .unwrap_or(0);
            self.rng.reseed(seed);
        } else {
            let seed = self.evaluate_integer(rest)? as u64;
            self.rng.reseed(seed);
        }
        Ok(Control::Advance)
    }

    fn execute_option_base(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let base = self.evaluate_integer(rest)?;
        if base != 0 && base != 1 {
            return Err(Error::syntax("OPTION BASE requires 0 or 1"));
        }
        self.arrays.set_option_base(base as usize);
        Ok(Control::Advance)
    }

    fn execute_kill(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let value = self.evaluate_value(rest)?;
        let filename = match value {
            Value::String(s) => s,
            _ => return Err(Error::TypeMismatch),
        };
        let path = self.files.resolve(&filename, true)?;
        std::fs::remove_file(&path).map_err(|e| Error::Io(e.to_string()))?;
        Ok(Control::Advance)
    }

    fn execute_name(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        // NAME "old" AS "new"
        let as_pos = rest
            .iter()
            .position(|t| matches!(t, TokenInstance::Ident(s) if s == "AS"))
            .ok_or_else(|| Error::syntax("NAME requires AS"))?;
        let old_val = self.evaluate_value(&rest[..as_pos])?;
        let new_val = self.evaluate_value(&rest[as_pos + 1..])?;
        let old_name = match old_val {
            Value::String(s) => s,
            _ => return Err(Error::TypeMismatch),
        };
        let new_name = match new_val {
            Value::String(s) => s,
            _ => return Err(Error::TypeMismatch),
        };
        let old_path = self.files.resolve(&old_name, true)?;
        let new_path = self.files.resolve(&new_name, false)?;
        std::fs::rename(&old_path, &new_path).map_err(|e| Error::Io(e.to_string()))?;
        Ok(Control::Advance)
    }

    fn execute_mid_statement(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        // MID$(A$, start, len) = replacement$
        // Parse: ( var$ , start , len ) = replacement
        if !matches!(rest.first(), Some(TokenInstance::LParen)) {
            return Err(Error::syntax("MID$ statement requires ("));
        }
        // Find matching )
        let mut depth = 0i32;
        let mut rparen = 0;
        for (i, tok) in rest.iter().enumerate() {
            match tok {
                TokenInstance::LParen => depth += 1,
                TokenInstance::RParen => {
                    depth -= 1;
                    if depth == 0 {
                        rparen = i;
                        break;
                    }
                }
                _ => {}
            }
        }
        if rparen == 0 {
            return Err(Error::syntax("MID$ statement: missing )"));
        }
        // Split args by commas inside parens
        let inner = &rest[1..rparen];
        let mut args: Vec<&[TokenInstance]> = Vec::new();
        let mut start_idx = 0;
        for (i, tok) in inner.iter().enumerate() {
            if matches!(tok, TokenInstance::Comma) {
                args.push(&inner[start_idx..i]);
                start_idx = i + 1;
            }
        }
        if start_idx < inner.len() {
            args.push(&inner[start_idx..]);
        }
        if args.len() < 2 || args.len() > 3 {
            return Err(Error::syntax("MID$ statement requires 2 or 3 arguments"));
        }
        // First arg is the string variable name
        let var_name = match args[0] {
            [TokenInstance::Ident(name)] => name.clone(),
            _ => {
                return Err(Error::syntax(
                    "MID$ statement: first arg must be a variable",
                ))
            }
        };
        if !is_string_variable(&var_name) {
            return Err(Error::TypeMismatch);
        }
        let start_pos = self.evaluate_integer(args[1])?;
        let length = if args.len() == 3 {
            self.evaluate_integer(args[2])?
        } else {
            i64::MAX
        };
        // After ) there must be = then replacement expression
        let after_rparen = &rest[rparen + 1..];
        if !matches!(
            after_rparen.first(),
            Some(TokenInstance::Keyword(Token::Equal))
        ) {
            return Err(Error::syntax("MID$ statement requires = after ()"));
        }
        let replacement_val = self.evaluate_value(&after_rparen[1..])?;
        let replacement = match replacement_val {
            Value::String(s) => s,
            _ => return Err(Error::TypeMismatch),
        };
        // Get the current string value
        let current = self
            .vars
            .get(&var_name)
            .cloned()
            .map(|v| match v {
                Value::String(s) => s,
                _ => String::new(),
            })
            .unwrap_or_default();
        if start_pos <= 0 || length < 0 {
            return Err(Error::IllegalQuantity);
        }

        // MID$ overwrites an existing character range; it never grows or
        // shrinks the target string.
        let mut current_chars = current.chars().collect::<Vec<_>>();
        let start_index = usize::try_from(start_pos - 1).map_err(|_| Error::IllegalQuantity)?;
        if start_index >= current_chars.len() {
            return Err(Error::IllegalQuantity);
        }
        let replacement_chars = replacement.chars().collect::<Vec<_>>();
        let requested = usize::try_from(length).unwrap_or(usize::MAX);
        let count = requested
            .min(replacement_chars.len())
            .min(current_chars.len().saturating_sub(start_index));
        current_chars[start_index..start_index + count]
            .copy_from_slice(&replacement_chars[..count]);

        self.assign(var_name, Value::String(current_chars.into_iter().collect()))?;
        Ok(Control::Advance)
    }

    fn execute_default_type_text(
        &mut self,
        text: &str,
        declaration: VariableType,
    ) -> Result<Control, Error> {
        let bytes = text.as_bytes();
        if bytes.len() != 3
            || !bytes[0].is_ascii_alphabetic()
            || bytes[1] != b'-'
            || !bytes[2].is_ascii_alphabetic()
        {
            return Err(Error::syntax("type declaration expects a letter range"));
        }
        let start = bytes[0].to_ascii_uppercase();
        let end = bytes[2].to_ascii_uppercase();
        if end < start {
            return Err(Error::IllegalQuantity);
        }
        for letter in start..=end {
            self.default_types[(letter - b'A') as usize] = declaration;
        }
        Ok(Control::Advance)
    }

    fn execute_default_type(
        &mut self,
        rest: &[TokenInstance],
        declaration: VariableType,
    ) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("type declaration requires a letter range"));
        }
        let mut pos = 0;
        while pos < rest.len() {
            let start = match rest.get(pos) {
                Some(TokenInstance::Ident(name)) if name.len() == 1 => {
                    name.as_bytes()[0].to_ascii_uppercase()
                }
                _ => return Err(Error::syntax("type declaration expects letters")),
            };
            if !start.is_ascii_alphabetic() {
                return Err(Error::syntax("type declaration expects letters"));
            }
            let end = if matches!(
                rest.get(pos + 1),
                Some(TokenInstance::Keyword(Token::Minus))
            ) {
                match rest.get(pos + 2) {
                    Some(TokenInstance::Ident(name)) if name.len() == 1 => {
                        name.as_bytes()[0].to_ascii_uppercase()
                    }
                    _ => return Err(Error::syntax("type declaration expects a range end")),
                }
            } else {
                start
            };
            if end < start {
                return Err(Error::IllegalQuantity);
            }
            for letter in start..=end {
                self.default_types[(letter - b'A') as usize] = declaration;
            }
            pos += if end == start { 1 } else { 3 };
            if pos == rest.len() {
                break;
            }
            if !matches!(rest.get(pos), Some(TokenInstance::Comma)) {
                return Err(Error::syntax(
                    "type declaration expects comma-separated ranges",
                ));
            }
            pos += 1;
        }
        self.sync_default_types();
        Ok(Control::Advance)
    }

    fn sync_default_types(&mut self) {
        let types = self
            .default_types
            .iter()
            .map(|kind| match kind {
                VariableType::String => 'S',
                VariableType::Single => 'F',
                VariableType::Double => 'D',
                _ => 'I',
            })
            .collect::<String>();
        let _ = Self::assign_to_store(
            &mut self.vars,
            &mut self.storage,
            "__DEF_TYPES$".to_string(),
            Value::String(types),
        );
    }

    fn execute_erase(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if rest.is_empty() {
            return Err(Error::syntax("ERASE requires at least one array"));
        }
        let mut names = Vec::new();
        for item in split_graph_arguments(rest)? {
            let [TokenInstance::Ident(name)] = item else {
                return Err(Error::syntax("ERASE expects array names"));
            };
            names.push(name.clone());
        }
        let mut arrays = self.arrays.clone();
        let mut storage = self.storage.clone();
        let mut declared_types = self.declared_value_types.clone();
        let mut instances = self.record_instances.clone();
        let mut erased_same_name_aliases = Vec::new();
        for name in names {
            if instances.contains_key(&name) {
                let actual_base = self
                    .procedure_stack
                    .last()
                    .and_then(|frame| frame.record_byref.get(&name))
                    .cloned()
                    .unwrap_or_else(|| name.clone());
                let prefix = format!("{name}.");
                let fields = declared_types
                    .keys()
                    .filter(|field| {
                        field.starts_with(&prefix) && arrays.get(field.as_str()).is_some()
                    })
                    .cloned()
                    .collect::<Vec<_>>();
                if fields.is_empty() {
                    continue;
                }
                for field in fields {
                    arrays.remove_bounded(&field, &mut storage)?;
                    declared_types.remove(&field);
                }
                instances.retain(|instance, _| instance != &name && !instance.starts_with(&prefix));
                if actual_base != name {
                    let actual_prefix = format!("{actual_base}.");
                    declared_types.retain(|field, _| !field.starts_with(&actual_prefix));
                    instances.retain(|instance, _| {
                        instance != &actual_base && !instance.starts_with(&actual_prefix)
                    });
                } else if self
                    .procedure_stack
                    .last()
                    .is_some_and(|frame| frame.record_byref.get(&name) == Some(&actual_base))
                {
                    erased_same_name_aliases.push(name);
                }
            } else {
                arrays.remove_bounded(&name, &mut storage)?;
            }
        }
        self.arrays = arrays;
        self.storage = storage;
        self.declared_value_types = declared_types;
        self.record_instances = instances;
        for name in erased_same_name_aliases {
            let prefix = format!("{name}.");
            for frame in &mut self.procedure_stack {
                if frame.record_byref.get(&name) != Some(&name) {
                    continue;
                }
                for (record, previous) in &mut frame.local_record_types {
                    if record == &name || record.starts_with(&prefix) {
                        *previous = None;
                    }
                }
                for (field, previous) in &mut frame.local_array_types {
                    if field.starts_with(&prefix) {
                        *previous = None;
                    }
                }
            }
        }
        Ok(Control::Advance)
    }

    fn is_string_destination(&self, name: &str) -> bool {
        self.declared_value_types
            .get(name)
            .is_some_and(|declared| declared.declaration == VariableType::String)
            || (!self.declared_value_types.contains_key(name) && is_string_variable(name))
    }

    fn ensure_assignable(&self, name: &str) -> Result<(), Error> {
        if name.contains('.') && !self.declared_value_types.contains_key(name) {
            return Err(Error::syntax(format!("undefined TYPE field {name}")));
        }
        let function_return = matches!(
            self.procedure_stack.last(),
            Some(frame) if frame.kind == StructuredKind::Function && frame.name == name
        );
        if self.constants.contains(name) && !function_return {
            return Err(Error::syntax(format!("cannot assign to constant {name}")));
        }
        Ok(())
    }

    fn effective_variable_type(&self, name: &str) -> VariableType {
        if let Some(declared) = self.declared_value_types.get(name) {
            return declared.declaration;
        }
        let suffix_type = variable_type(name);
        if suffix_type != VariableType::Numeric {
            return suffix_type;
        }
        name.bytes()
            .next()
            .filter(u8::is_ascii_alphabetic)
            .map(|letter| self.default_types[(letter.to_ascii_uppercase() - b'A') as usize])
            .unwrap_or(VariableType::Numeric)
    }

    fn resolve_scalar_reference(&self, name: &str) -> VariableReference {
        let Some((frame_index, frame)) = self.procedure_stack.iter().enumerate().next_back() else {
            return VariableReference::Scalar(ScalarReference::Global(name.to_string()));
        };
        if let Some(reference) = frame.byref.get(name) {
            return reference.clone();
        }
        if procedure_scope_contains(&frame.shared, name)
            || self.constants.contains(name)
            || is_runtime_system_scalar(name)
        {
            return VariableReference::Scalar(ScalarReference::Global(name.to_string()));
        }
        if procedure_scope_contains(&frame.statics, name) {
            return VariableReference::Scalar(ScalarReference::Static {
                procedure: frame.name.clone(),
                name: name.to_string(),
            });
        }
        VariableReference::Scalar(ScalarReference::Local {
            frame_index,
            name: name.to_string(),
        })
    }

    fn variable_reference_value(
        &self,
        reference: &VariableReference,
    ) -> Result<Option<Value>, Error> {
        match reference {
            VariableReference::Scalar(ScalarReference::Global(name)) => {
                Ok(self.vars.get(name).cloned())
            }
            VariableReference::Scalar(ScalarReference::Static { procedure, name }) => Ok(self
                .static_vars
                .get(procedure)
                .and_then(|values| values.get(name))
                .cloned()),
            VariableReference::Scalar(ScalarReference::Local { frame_index, name }) => Ok(self
                .procedure_stack
                .get(*frame_index)
                .and_then(|frame| frame.locals.get(name))
                .cloned()),
            VariableReference::ArrayElement { name, indices } => self
                .arrays
                .get(name)
                .ok_or_else(|| Error::syntax(format!("BYREF array {name} no longer exists")))
                .and_then(|array| array.load(indices))
                .map(Some),
        }
    }

    fn assign_variable_reference(
        &mut self,
        reference: VariableReference,
        value: Value,
    ) -> Result<(), Error> {
        let name = reference.name().to_string();
        let value = self.coerce_default_assignment(&name, value)?;
        match reference {
            VariableReference::Scalar(ScalarReference::Global(name)) => {
                if name.starts_with("__DEF_FN_PARAM_") {
                    self.vars.insert(name, value);
                    Ok(())
                } else {
                    Self::store_coerced_value(&mut self.vars, &mut self.storage, name, value)
                }
            }
            VariableReference::Scalar(ScalarReference::Static { procedure, name }) => {
                let vars = self.static_vars.entry(procedure).or_default();
                Self::store_coerced_value(vars, &mut self.storage, name, value)
            }
            VariableReference::Scalar(ScalarReference::Local { frame_index, name }) => {
                let vars = &mut self
                    .procedure_stack
                    .get_mut(frame_index)
                    .ok_or_else(|| Error::syntax("invalid BYREF local frame"))?
                    .locals;
                Self::store_coerced_value(vars, &mut self.storage, name, value)
            }
            VariableReference::ArrayElement { name, indices } => {
                self.arrays
                    .store_bounded(&name, &indices, value, &mut self.storage)
            }
        }
    }

    fn assign(&mut self, name: String, value: Value) -> Result<(), Error> {
        self.ensure_assignable(&name)?;
        let byref = self
            .procedure_stack
            .last()
            .and_then(|frame| frame.byref.get(&name))
            .cloned();
        if let Some(reference) = byref {
            return self.assign_variable_reference(reference, value);
        }
        let value = self.coerce_default_assignment(&name, value)?;
        let Some(frame) = self.procedure_stack.last() else {
            return Self::store_coerced_value(&mut self.vars, &mut self.storage, name, value);
        };
        if procedure_scope_contains(&frame.shared, &name) {
            return Self::store_coerced_value(&mut self.vars, &mut self.storage, name, value);
        }
        if procedure_scope_contains(&frame.statics, &name) {
            let procedure = frame.name.clone();
            let vars = self.static_vars.entry(procedure).or_default();
            return Self::store_coerced_value(vars, &mut self.storage, name, value);
        }
        let vars = &mut self
            .procedure_stack
            .last_mut()
            .expect("active procedure frame")
            .locals;
        Self::store_coerced_value(vars, &mut self.storage, name, value)
    }

    fn scalar_value(&self, name: &str) -> Result<Option<Value>, Error> {
        let Some(frame) = self.procedure_stack.last() else {
            return Ok(self.vars.get(name).cloned());
        };
        if let Some(reference) = frame.byref.get(name) {
            return self.variable_reference_value(reference);
        }
        let function_return = frame.kind == StructuredKind::Function && frame.name == name;
        if procedure_scope_contains(&frame.shared, name)
            || (self.constants.contains(name) && !function_return)
            || is_runtime_system_scalar(name)
        {
            return Ok(self.vars.get(name).cloned());
        }
        if procedure_scope_contains(&frame.statics, name) {
            return Ok(self
                .static_vars
                .get(&frame.name)
                .and_then(|values| values.get(name))
                .cloned());
        }
        Ok(frame.locals.get(name).cloned())
    }

    fn procedure_visible_variables(&self) -> Result<Variables, Error> {
        let Some(frame) = self.procedure_stack.last() else {
            return Ok(self.vars.clone());
        };
        let mut visible = Variables::new();
        for (name, value) in &self.vars {
            let function_return = frame.kind == StructuredKind::Function && frame.name == *name;
            if procedure_scope_contains(&frame.shared, name)
                || (self.constants.contains(name) && !function_return)
                || is_runtime_system_scalar(name)
            {
                visible.insert(name.clone(), value.clone());
            }
        }
        if let Some(statics) = self.static_vars.get(&frame.name) {
            for (name, value) in statics {
                visible.insert(name.clone(), value.clone());
            }
        }
        visible.extend(frame.locals.clone());
        for (name, reference) in &frame.byref {
            let value = self
                .variable_reference_value(reference)?
                .unwrap_or_else(|| self.default_scalar_value(reference.name()));
            visible.insert(name.clone(), value);
        }
        Ok(visible)
    }

    fn enter_sub(
        &mut self,
        definition: &ProcedureDefinition,
        arguments: Vec<ProcedureArgument>,
        return_pc: usize,
    ) -> Result<(), Error> {
        if self.call_stack.len() + self.procedure_stack.len() >= self.max_call_depth {
            return Err(Error::CallStackExceeded {
                limit: self.max_call_depth,
            });
        }
        if arguments.len() != definition.parameters.len() {
            return Err(Error::syntax(format!(
                "SUB {} expects {} arguments, got {}",
                definition.name,
                definition.parameters.len(),
                arguments.len()
            )));
        }
        if let Some(parameter) = definition
            .parameters
            .iter()
            .find(|parameter| self.constants.contains(&parameter.name))
        {
            return Err(Error::syntax(format!(
                "SUB parameter {} conflicts with a CONST",
                parameter.name
            )));
        }

        let mut locals = Variables::new();
        let mut byref = HashMap::new();
        let mut array_aliases = HashMap::new();
        let mut declared_overlays = Vec::new();
        let mut record_overlays = Vec::new();
        let mut storage = self.storage.clone();
        declared_overlays.extend(
            definition
                .parameters
                .iter()
                .filter(|parameter| {
                    parameter.record_type.is_none()
                        && parameter.declaration != VariableType::Numeric
                })
                .map(|parameter| {
                    (
                        parameter.name.clone(),
                        DeclaredValueType {
                            declaration: parameter.declaration,
                            fixed_string_bytes: None,
                        },
                    )
                }),
        );
        for (parameter, argument) in definition.parameters.iter().zip(arguments) {
            match (parameter.shape, parameter.mode, argument) {
                (
                    ParameterShape::Scalar,
                    ParameterMode::ByVal,
                    ProcedureArgument::Value(argument),
                ) => {
                    let argument = self.coerce_parameter_assignment(parameter, argument)?;
                    Self::assign_to_store(
                        &mut locals,
                        &mut storage,
                        parameter.name.clone(),
                        argument,
                    )?;
                }
                (
                    ParameterShape::Scalar,
                    ParameterMode::ByRef,
                    ProcedureArgument::Reference(reference),
                ) => {
                    byref.insert(parameter.name.clone(), reference);
                }
                (
                    ParameterShape::Array,
                    ParameterMode::ByRef,
                    ProcedureArgument::ArrayReference(name),
                ) => {
                    array_aliases.insert(parameter.name.clone(), name);
                }
                (
                    ParameterShape::Array,
                    ParameterMode::ByRef,
                    ProcedureArgument::RecordArrayReference {
                        record_type,
                        actual_base,
                        fields,
                    },
                ) => {
                    let record = self
                        .structured_definitions
                        .types
                        .get(&record_type)
                        .ok_or_else(|| Error::syntax(format!("undefined TYPE {record_type}")))?;
                    if fields.len() != record.fields.len() {
                        return Err(Error::syntax("internal record-array field mismatch"));
                    }
                    for (field, (actual_field, canonical)) in record.fields.iter().zip(fields) {
                        if field.name != actual_field {
                            return Err(Error::syntax("internal record-array field mismatch"));
                        }
                        let formal = format!("{}.{}", parameter.name, field.name);
                        array_aliases.insert(formal.clone(), canonical);
                        declared_overlays.push((
                            formal,
                            DeclaredValueType {
                                declaration: field.declaration,
                                fixed_string_bytes: field.fixed_string_bytes,
                            },
                        ));
                    }
                    record_overlays.push((
                        parameter.name.clone(),
                        record_type,
                        actual_base.clone(),
                    ));
                    record_overlays.extend(record.nested_fields.iter().map(|field| {
                        (
                            format!("{}.{}", parameter.name, field.name),
                            field.type_name.clone(),
                            format!("{actual_base}.{}", field.name),
                        )
                    }));
                }
                _ => return Err(Error::syntax("internal procedure argument mode mismatch")),
            }
        }
        let mut local_array_types = HashMap::new();
        for (name, declared) in declared_overlays {
            let previous = self.declared_value_types.insert(name.clone(), declared);
            local_array_types.insert(name, previous);
        }
        let mut local_record_types = HashMap::new();
        let mut record_byref = HashMap::new();
        for (name, record_type, actual_base) in record_overlays {
            let previous = self.record_instances.insert(name.clone(), record_type);
            local_record_types.insert(name.clone(), previous);
            record_byref.insert(name, actual_base);
        }
        self.storage = storage;
        self.arrays.push_alias_scope(array_aliases);
        self.procedure_stack.push(ProcedureFrame {
            name: definition.name.clone(),
            kind: StructuredKind::Sub,
            return_pc,
            loop_depth: self.loop_stack.len(),
            gosub_depth: self.call_stack.len(),
            locals,
            byref,
            local_arrays: HashSet::new(),
            local_array_types,
            local_record_types,
            record_byref,
            shared: definition.shared.clone(),
            statics: definition.statics.clone(),
        });
        Ok(())
    }

    fn enter_function(
        &mut self,
        definition: &ProcedureDefinition,
        arguments: Vec<ProcedureArgument>,
    ) -> Result<(), Error> {
        let function_depth = self
            .procedure_stack
            .iter()
            .filter(|frame| frame.kind == StructuredKind::Function)
            .count();
        if function_depth >= self.max_function_depth {
            return Err(Error::FunctionStackExceeded {
                limit: self.max_function_depth,
            });
        }
        if self.call_stack.len() + self.procedure_stack.len() >= self.max_call_depth {
            return Err(Error::CallStackExceeded {
                limit: self.max_call_depth,
            });
        }
        if arguments.len() != definition.parameters.len() {
            return Err(Error::syntax(format!(
                "FUNCTION {} expects {} arguments, got {}",
                definition.name,
                definition.parameters.len(),
                arguments.len()
            )));
        }
        if let Some(parameter) = definition
            .parameters
            .iter()
            .find(|parameter| self.constants.contains(&parameter.name))
        {
            return Err(Error::syntax(format!(
                "FUNCTION parameter {} conflicts with a CONST",
                parameter.name
            )));
        }
        let mut locals = Variables::new();
        let mut byref = HashMap::new();
        let mut array_aliases = HashMap::new();
        let mut declared_overlays = Vec::new();
        let mut record_overlays = Vec::new();
        let mut storage = self.storage.clone();
        declared_overlays.extend(
            definition
                .parameters
                .iter()
                .filter(|parameter| {
                    parameter.record_type.is_none()
                        && parameter.declaration != VariableType::Numeric
                })
                .map(|parameter| {
                    (
                        parameter.name.clone(),
                        DeclaredValueType {
                            declaration: parameter.declaration,
                            fixed_string_bytes: None,
                        },
                    )
                }),
        );
        if let Some(return_type) = definition
            .return_type
            .filter(|return_type| *return_type != VariableType::Numeric)
        {
            declared_overlays.push((
                definition.name.clone(),
                DeclaredValueType {
                    declaration: return_type,
                    fixed_string_bytes: None,
                },
            ));
        }
        for (parameter, argument) in definition.parameters.iter().zip(arguments) {
            match (parameter.shape, parameter.mode, argument) {
                (
                    ParameterShape::Scalar,
                    ParameterMode::ByVal,
                    ProcedureArgument::Value(argument),
                ) => {
                    let argument = self.coerce_parameter_assignment(parameter, argument)?;
                    Self::assign_to_store(
                        &mut locals,
                        &mut storage,
                        parameter.name.clone(),
                        argument,
                    )?;
                }
                (
                    ParameterShape::Scalar,
                    ParameterMode::ByRef,
                    ProcedureArgument::Reference(reference),
                ) => {
                    byref.insert(parameter.name.clone(), reference);
                }
                (
                    ParameterShape::Array,
                    ParameterMode::ByRef,
                    ProcedureArgument::ArrayReference(name),
                ) => {
                    array_aliases.insert(parameter.name.clone(), name);
                }
                (
                    ParameterShape::Array,
                    ParameterMode::ByRef,
                    ProcedureArgument::RecordArrayReference {
                        record_type,
                        actual_base,
                        fields,
                    },
                ) => {
                    let record = self
                        .structured_definitions
                        .types
                        .get(&record_type)
                        .ok_or_else(|| Error::syntax(format!("undefined TYPE {record_type}")))?;
                    if fields.len() != record.fields.len() {
                        return Err(Error::syntax("internal record-array field mismatch"));
                    }
                    for (field, (actual_field, canonical)) in record.fields.iter().zip(fields) {
                        if field.name != actual_field {
                            return Err(Error::syntax("internal record-array field mismatch"));
                        }
                        let formal = format!("{}.{}", parameter.name, field.name);
                        array_aliases.insert(formal.clone(), canonical);
                        declared_overlays.push((
                            formal,
                            DeclaredValueType {
                                declaration: field.declaration,
                                fixed_string_bytes: field.fixed_string_bytes,
                            },
                        ));
                    }
                    record_overlays.push((
                        parameter.name.clone(),
                        record_type,
                        actual_base.clone(),
                    ));
                    record_overlays.extend(record.nested_fields.iter().map(|field| {
                        (
                            format!("{}.{}", parameter.name, field.name),
                            field.type_name.clone(),
                            format!("{actual_base}.{}", field.name),
                        )
                    }));
                }
                _ => return Err(Error::syntax("internal procedure argument mode mismatch")),
            }
        }
        let mut local_array_types = HashMap::new();
        for (name, declared) in declared_overlays {
            let previous = self.declared_value_types.insert(name.clone(), declared);
            local_array_types.insert(name, previous);
        }
        let mut local_record_types = HashMap::new();
        let mut record_byref = HashMap::new();
        for (name, record_type, actual_base) in record_overlays {
            let previous = self.record_instances.insert(name.clone(), record_type);
            local_record_types.insert(name.clone(), previous);
            record_byref.insert(name, actual_base);
        }
        self.storage = storage;
        self.arrays.push_alias_scope(array_aliases);
        self.procedure_stack.push(ProcedureFrame {
            name: definition.name.clone(),
            kind: StructuredKind::Function,
            return_pc: usize::MAX,
            loop_depth: self.loop_stack.len(),
            gosub_depth: self.call_stack.len(),
            locals,
            byref,
            local_arrays: HashSet::new(),
            local_array_types,
            local_record_types,
            record_byref,
            shared: definition.shared.clone(),
            statics: definition.statics.clone(),
        });
        Ok(())
    }

    fn leave_sub(&mut self) -> Result<(usize, usize), Error> {
        if !matches!(
            self.procedure_stack.last(),
            Some(frame) if frame.kind == StructuredKind::Sub
        ) {
            return Err(Error::syntax("END SUB without active SUB"));
        }
        let mut arrays = self.arrays.clone();
        let mut storage = self.storage.clone();
        for name in &self
            .procedure_stack
            .last()
            .expect("validated active SUB")
            .local_arrays
        {
            arrays.remove_bounded(name, &mut storage)?;
        }
        arrays.pop_alias_scope()?;
        let frame = self
            .procedure_stack
            .pop()
            .ok_or_else(|| Error::syntax("END SUB without active SUB"))?;
        for value in frame.locals.values() {
            storage.remove(value)?;
        }
        self.restore_procedure_array_types(&frame);
        self.arrays = arrays;
        self.storage = storage;
        self.call_stack.truncate(frame.gosub_depth);
        Ok((frame.return_pc, frame.loop_depth))
    }

    fn leave_function(&mut self) -> Result<Value, Error> {
        let Some(frame) = self.procedure_stack.last() else {
            return Err(Error::syntax("END FUNCTION without active FUNCTION"));
        };
        if frame.kind != StructuredKind::Function {
            return Err(Error::syntax("END FUNCTION without active FUNCTION"));
        }
        let name = frame.name.clone();
        let value = self
            .scalar_value(&name)?
            .unwrap_or_else(|| self.default_scalar_value(&name));
        let value = self.coerce_default_assignment(&name, value)?;
        let mut arrays = self.arrays.clone();
        let mut storage = self.storage.clone();
        for name in &frame.local_arrays {
            arrays.remove_bounded(name, &mut storage)?;
        }
        arrays.pop_alias_scope()?;
        let frame = self
            .procedure_stack
            .pop()
            .expect("validated active FUNCTION frame");
        for value in frame.locals.values() {
            storage.remove(value)?;
        }
        self.restore_procedure_array_types(&frame);
        self.arrays = arrays;
        self.storage = storage;
        self.call_stack.truncate(frame.gosub_depth);
        self.loop_stack.truncate(frame.loop_depth);
        Ok(value)
    }

    fn restore_procedure_array_types(&mut self, frame: &ProcedureFrame) {
        for (name, previous) in &frame.local_array_types {
            if let Some(previous) = previous {
                self.declared_value_types.insert(name.clone(), *previous);
            } else {
                self.declared_value_types.remove(name);
            }
        }
        for (name, previous) in &frame.local_record_types {
            if let Some(previous) = previous {
                self.record_instances.insert(name.clone(), previous.clone());
            } else {
                self.record_instances.remove(name);
            }
        }
    }

    fn default_scalar_value(&self, name: &str) -> Value {
        if let Some(declared) = self.declared_value_types.get(name) {
            return match declared.declaration {
                VariableType::String => Value::String(
                    declared
                        .fixed_string_bytes
                        .map_or_else(String::new, |length| " ".repeat(length)),
                ),
                VariableType::Single | VariableType::Double => Value::Real(BasicReal::zero()),
                _ => Value::Integer(0),
            };
        }
        if is_string_variable(name) {
            return Value::String(String::new());
        }
        let Some(letter) = name.bytes().next().filter(u8::is_ascii_alphabetic) else {
            return Value::Integer(0);
        };
        match self.default_types[(letter.to_ascii_uppercase() - b'A') as usize] {
            VariableType::String => Value::String(String::new()),
            VariableType::Single | VariableType::Double => Value::Real(BasicReal::zero()),
            _ => Value::Integer(0),
        }
    }

    fn coerce_default_assignment(&self, name: &str, value: Value) -> Result<Value, Error> {
        if let Some(declared) = self.declared_value_types.get(name) {
            let suffix = match declared.declaration {
                VariableType::String => "$",
                VariableType::Integer => "%",
                VariableType::Long => "&",
                VariableType::Single => "!",
                VariableType::Double => "#",
                VariableType::Numeric => "",
            };
            let mut value = Self::coerce_assignment_value(&format!("{name}{suffix}"), value)?;
            if let (Some(length), Value::String(text)) = (declared.fixed_string_bytes, &mut value) {
                while text.len() > length {
                    text.pop();
                }
                if text.len() < length {
                    text.push_str(&" ".repeat(length - text.len()));
                }
            }
            return Ok(value);
        }
        if variable_type(name) != VariableType::Numeric {
            return Self::coerce_assignment_value(name, value);
        }
        let Some(letter) = name.bytes().next().filter(u8::is_ascii_alphabetic) else {
            return Ok(value);
        };
        let declaration = self.default_types[(letter.to_ascii_uppercase() - b'A') as usize];
        let suffix = match declaration {
            VariableType::Integer => "%",
            VariableType::Single => "!",
            VariableType::Double => "#",
            VariableType::String => "$",
            VariableType::Numeric | VariableType::Long => {
                return Self::coerce_assignment_value(name, value)
            }
        };
        Self::coerce_assignment_value(&format!("{name}{suffix}"), value)
    }

    fn coerce_parameter_assignment(
        &self,
        parameter: &ProcedureParameter,
        value: Value,
    ) -> Result<Value, Error> {
        let suffix = match parameter.declaration {
            VariableType::String => "$",
            VariableType::Integer => "%",
            VariableType::Long => "&",
            VariableType::Single => "!",
            VariableType::Double => "#",
            VariableType::Numeric => "",
        };
        Self::coerce_assignment_value(&format!("{}{suffix}", parameter.name), value)
    }

    fn assign_to_store(
        vars: &mut Variables,
        storage: &mut StorageBudget,
        name: String,
        value: Value,
    ) -> Result<(), Error> {
        let value = Self::coerce_assignment_value(&name, value)?;
        Self::store_coerced_value(vars, storage, name, value)
    }

    fn store_coerced_value(
        vars: &mut Variables,
        storage: &mut StorageBudget,
        name: String,
        value: Value,
    ) -> Result<(), Error> {
        storage.replace(vars.get(&name), &value)?;
        vars.insert(name, value);
        Ok(())
    }

    /// Apply Microsoft BASIC suffix typing before a value enters storage.
    /// ModernBASIC keeps `%` as a signed 32-bit integer, `&` as a signed 64-bit
    /// integer, `!` as binary32-rounded real, `#` as binary64 real, and `$` as
    /// string. Unsuffixed numeric variables retain the evaluator's exact type.
    fn coerce_assignment_value(name: &str, value: Value) -> Result<Value, Error> {
        match variable_type(name) {
            VariableType::String => match value {
                Value::String(_) => Ok(value),
                _ => Err(Error::TypeMismatch),
            },
            VariableType::Integer => {
                let value = value.to_integer()?;
                let value = i32::try_from(value).map_err(|_| {
                    if value < 0 {
                        Error::IntegerUnderflow
                    } else {
                        Error::IntegerOverflow
                    }
                })?;
                Ok(Value::Integer(i64::from(value)))
            }
            VariableType::Long => Ok(Value::Integer(value.to_integer()?)),
            VariableType::Single => {
                let value = match value {
                    Value::Integer(value) => value as f64,
                    Value::Real(value) => value.value(),
                    Value::Complex(_) | Value::List(_) | Value::String(_) => {
                        return Err(Error::TypeMismatch)
                    }
                };
                Ok(Value::Real(BasicReal::new((value as f32) as f64)?))
            }
            VariableType::Double => {
                let value = match value {
                    Value::Integer(value) => value as f64,
                    Value::Real(value) => value.value(),
                    Value::Complex(_) | Value::List(_) | Value::String(_) => {
                        return Err(Error::TypeMismatch)
                    }
                };
                Ok(Value::Real(BasicReal::new(value)?))
            }
            VariableType::Numeric => match value {
                Value::String(_) if is_ti_equation_variable(name) => Ok(value),
                Value::String(_) => Err(Error::TypeMismatch),
                _ => Ok(value),
            },
        }
    }

    fn execute_value_assignment(&mut self, tokens: &[TokenInstance]) -> Result<(), Error> {
        let (destination, expression) = parse_lvalue(tokens)?;
        if self.try_assign_record_value(&destination, expression)? {
            return Ok(());
        }
        let value = self.evaluate_value(expression)?;
        self.assign_lvalue(destination, value)
    }

    fn try_assign_record_value(
        &mut self,
        destination: &Lvalue,
        expression: &[TokenInstance],
    ) -> Result<bool, Error> {
        let Some(destination_type) = self.record_instances.get(&destination.name).cloned() else {
            return Ok(false);
        };
        let source =
            parse_list_lvalue(expression, "record assignment").map_err(|_| Error::TypeMismatch)?;
        let Some(source_type) = self.record_instances.get(&source.name).cloned() else {
            return Err(Error::TypeMismatch);
        };
        if source_type != destination_type {
            return Err(Error::TypeMismatch);
        }
        let definition = self
            .structured_definitions
            .types
            .get(&destination_type)
            .cloned()
            .ok_or_else(|| Error::syntax(format!("undefined TYPE {destination_type}")))?;
        let destination_indices = self.evaluate_lvalue_indices(destination)?;
        let source_indices = self.evaluate_lvalue_indices(&source)?;
        let mut assignments = Vec::with_capacity(definition.fields.len());
        for field in &definition.fields {
            let destination_field = format!("{}.{}", destination.name, field.name);
            let source_field = format!("{}.{}", source.name, field.name);
            self.ensure_assignable(&destination_field)?;
            let destination_is_array = self.arrays.get(&destination_field).is_some();
            let source_is_array = self.arrays.get(&source_field).is_some();
            if destination_is_array == destination_indices.is_empty()
                || source_is_array == source_indices.is_empty()
            {
                return Err(Error::BadSubscript);
            }
            let value = if source_indices.is_empty() {
                self.scalar_value(&source_field)?
                    .unwrap_or_else(|| self.default_scalar_value(&source_field))
            } else {
                self.arrays
                    .get(&source_field)
                    .ok_or(Error::BadSubscript)?
                    .load(&source_indices)?
            };
            assignments.push((
                destination_field.clone(),
                self.coerce_default_assignment(&destination_field, value)?,
            ));
        }

        let original_vars = self.vars.clone();
        let original_static_vars = self.static_vars.clone();
        let original_locals = self
            .procedure_stack
            .iter()
            .map(|frame| frame.locals.clone())
            .collect::<Vec<_>>();
        let original_arrays = self.arrays.clone();
        let original_storage = self.storage.clone();
        let result = (|| {
            for (field, value) in assignments {
                if destination_indices.is_empty() {
                    self.assign(field, value)?;
                } else {
                    self.arrays.store_bounded(
                        &field,
                        &destination_indices,
                        value,
                        &mut self.storage,
                    )?;
                }
            }
            Ok(())
        })();
        if result.is_err() {
            self.vars = original_vars;
            self.static_vars = original_static_vars;
            for (frame, locals) in self.procedure_stack.iter_mut().zip(original_locals) {
                frame.locals = locals;
            }
            self.arrays = original_arrays;
            self.storage = original_storage;
        }
        result.map(|()| true)
    }

    fn evaluate_lvalue_indices(&mut self, lvalue: &Lvalue) -> Result<Vec<i64>, Error> {
        lvalue
            .subscripts
            .iter()
            .map(|subscript| self.evaluate_integer(subscript))
            .collect()
    }

    fn assign_lvalue(&mut self, lvalue: Lvalue, value: Value) -> Result<(), Error> {
        if lvalue.subscripts.is_empty() {
            return self.assign(lvalue.name, value);
        }
        self.ensure_assignable(&lvalue.name)?;
        let value = self.coerce_default_assignment(&lvalue.name, value)?;
        let mut indices = Vec::with_capacity(lvalue.subscripts.len());
        for sub in &lvalue.subscripts {
            indices.push(self.evaluate_integer(sub)?);
        }
        if let Some(Value::List(existing)) = self.scalar_value(&lvalue.name)? {
            let [index] = indices.as_slice() else {
                return Err(Error::BadSubscript);
            };
            let index = usize::try_from(*index).map_err(|_| Error::BadSubscript)?;
            if index == 0 || index > existing.len() {
                return Err(Error::BadSubscript);
            }
            if !matches!(
                value,
                Value::Integer(_) | Value::Real(_) | Value::Complex(_)
            ) {
                return Err(Error::TypeMismatch);
            }
            let mut replacement = existing;
            replacement[index - 1] = value;
            return self.assign(lvalue.name, Value::List(replacement));
        }
        self.arrays
            .store_bounded(&lvalue.name, &indices, value, &mut self.storage)
    }

    fn execute_dim(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let rest = match rest.split_first() {
            Some((TokenInstance::Ident(name), rest)) if name == "SHARED" => rest,
            _ => rest,
        };
        self.execute_dimension_declarations(parse_dim_list(rest)?)
    }

    fn execute_static_arrays(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let mut declarations = Vec::new();
        for argument in split_graph_arguments(rest)? {
            if matches!(argument, [TokenInstance::Ident(_)]) {
                continue;
            }
            let parsed = parse_dim_list(argument)?;
            if parsed.len() != 1 || (parsed[0].bounds.is_empty() && parsed[0].as_type.is_none()) {
                return Err(Error::syntax(
                    "STATIC typed scalars require name AS type; arrays require name(bounds)",
                ));
            }
            declarations.extend(parsed);
        }
        if declarations.is_empty() {
            return Ok(Control::Advance);
        }
        self.execute_dimension_declarations(declarations)
    }

    fn execute_dimension_declarations(&mut self, decls: Vec<DimDecl>) -> Result<Control, Error> {
        let mut evaluated = Vec::with_capacity(decls.len());
        for decl in decls {
            let mut bounds = Vec::with_capacity(decl.bounds.len());
            for bound_tokens in &decl.bounds {
                bounds.push(self.evaluate_integer(bound_tokens)?);
            }
            evaluated.push((decl, bounds));
        }

        let original_vars = self.vars.clone();
        let original_static_vars = self.static_vars.clone();
        let original_locals = self
            .procedure_stack
            .iter()
            .map(|frame| frame.locals.clone())
            .collect::<Vec<_>>();
        let original_arrays = self.arrays.clone();
        let original_storage = self.storage.clone();
        let original_declared_types = self.declared_value_types.clone();
        let original_instances = self.record_instances.clone();
        let original_static_declared_types = self.static_declared_types.clone();
        let mut local_arrays = Vec::new();
        let mut static_arrays = Vec::new();
        let mut local_array_types = HashMap::new();
        let mut local_record_types = HashMap::new();
        let static_procedure = self.procedure_stack.last().map(|frame| frame.name.clone());
        let result = (|| {
            for (decl, bounds) in evaluated {
                let ownership = self.prepare_procedure_array_dimension(&decl)?;
                if ownership
                    .as_ref()
                    .is_some_and(|ownership| ownership.is_static)
                {
                    let procedure = static_procedure
                        .as_ref()
                        .expect("STATIC ownership requires an active procedure");
                    let key = format!("{procedure}.{}", decl.name);
                    let declared_kind = decl.as_type.clone().unwrap_or_else(|| {
                        format!("IMPLICIT:{:?}", self.effective_variable_type(&decl.name))
                    });
                    if self
                        .static_declared_types
                        .get(&key)
                        .is_some_and(|existing| existing != &declared_kind)
                    {
                        return Err(Error::syntax(format!(
                            "STATIC {} in {} is already declared with another type",
                            decl.name, procedure
                        )));
                    }
                    self.static_declared_types.insert(key, declared_kind);
                }
                if let Some(ownership) = &ownership {
                    for name in &ownership.declared_names {
                        local_array_types
                            .entry(name.clone())
                            .or_insert_with(|| self.declared_value_types.remove(name));
                    }
                    for name in &ownership.record_names {
                        local_record_types
                            .entry(name.clone())
                            .or_insert_with(|| self.record_instances.remove(name));
                    }
                }
                let reuse_static = ownership.as_ref().is_some_and(|ownership| {
                    if !ownership.is_static {
                        return false;
                    }
                    if !ownership.canonical_names.is_empty() {
                        return ownership
                            .canonical_names
                            .iter()
                            .all(|name| self.arrays.get(name).is_some());
                    }
                    static_procedure.as_ref().is_some_and(|procedure| {
                        self.static_vars.get(procedure).is_some_and(|values| {
                            ownership
                                .scalar_names
                                .iter()
                                .all(|name| values.contains_key(name))
                        })
                    })
                });
                if !reuse_static {
                    self.dimension_value(decl.clone(), &bounds)?;
                } else if let Some(record_type) = ownership
                    .as_ref()
                    .and_then(|ownership| ownership.record_type.as_ref())
                {
                    let definition = self
                        .structured_definitions
                        .types
                        .get(record_type)
                        .ok_or_else(|| Error::syntax(format!("undefined TYPE {record_type}")))?;
                    for field in &definition.fields {
                        self.declared_value_types.insert(
                            format!("{}.{}", decl.name, field.name),
                            DeclaredValueType {
                                declaration: field.declaration,
                                fixed_string_bytes: field.fixed_string_bytes,
                            },
                        );
                    }
                    for (name, type_name) in record_instance_declarations(&decl.name, definition) {
                        self.record_instances.insert(name, type_name);
                    }
                } else if let Some(as_type) = &decl.as_type {
                    let declaration = parse_primitive_as_type(as_type)
                        .ok_or_else(|| Error::syntax(format!("undefined TYPE {as_type}")))?;
                    self.declared_value_types.insert(
                        decl.name.clone(),
                        DeclaredValueType {
                            declaration,
                            fixed_string_bytes: None,
                        },
                    );
                }
                if let Some(ownership) = ownership {
                    if ownership.is_static {
                        static_arrays.extend(ownership.canonical_names);
                    } else {
                        local_arrays.extend(ownership.canonical_names);
                    }
                }
            }
            Ok(Control::Advance)
        })();
        if result.is_err() {
            self.vars = original_vars;
            self.static_vars = original_static_vars;
            for (frame, locals) in self.procedure_stack.iter_mut().zip(original_locals) {
                frame.locals = locals;
            }
            self.arrays = original_arrays;
            self.storage = original_storage;
            self.declared_value_types = original_declared_types;
            self.record_instances = original_instances;
            self.static_declared_types = original_static_declared_types;
        } else if !local_arrays.is_empty()
            || !static_arrays.is_empty()
            || !local_array_types.is_empty()
            || !local_record_types.is_empty()
        {
            self.procedure_stack
                .last_mut()
                .expect("scoped DIM requires an active procedure")
                .local_arrays
                .extend(local_arrays);
            self.procedure_stack
                .last_mut()
                .expect("scoped DIM requires an active procedure")
                .local_array_types
                .extend(local_array_types);
            self.procedure_stack
                .last_mut()
                .expect("scoped DIM requires an active procedure")
                .local_record_types
                .extend(local_record_types);
            self.static_arrays.extend(static_arrays);
        }
        result
    }

    fn prepare_procedure_array_dimension(
        &mut self,
        decl: &DimDecl,
    ) -> Result<Option<ProcedureArrayOwnership>, Error> {
        if self.procedure_stack.is_empty() {
            return Ok(None);
        }
        let record_definition = decl
            .as_type
            .as_ref()
            .and_then(|name| self.structured_definitions.types.get(name))
            .cloned();
        let already_scoped = !decl.bounds.is_empty()
            && record_definition.as_ref().map_or_else(
                || self.arrays.active_alias(&decl.name).is_some(),
                |definition| {
                    definition.fields.iter().any(|field| {
                        self.arrays
                            .active_alias(&format!("{}.{}", decl.name, field.name))
                            .is_some()
                    })
                },
            );
        if already_scoped {
            return Ok(None);
        }
        let frame = self
            .procedure_stack
            .last()
            .expect("validated active procedure");
        if frame.shared.contains(&decl.name) {
            return Ok(None);
        }
        let is_static = frame.statics.contains(&decl.name);
        let canonical_base = if is_static {
            format!("__STATIC.{}.{}", frame.name, decl.name)
        } else {
            format!(
                "__LOCAL.{}.{}.{}",
                self.procedure_stack.len(),
                frame.name,
                decl.name
            )
        };
        if let Some(definition) = record_definition {
            let record_names = record_instance_declarations(&decl.name, &definition)
                .into_iter()
                .map(|(name, _)| name)
                .collect::<Vec<_>>();
            if decl.bounds.is_empty() {
                let scalar_names = definition
                    .fields
                    .iter()
                    .map(|field| format!("{}.{}", decl.name, field.name))
                    .collect::<Vec<_>>();
                return Ok(Some(ProcedureArrayOwnership {
                    canonical_names: Vec::new(),
                    declared_names: scalar_names.clone(),
                    scalar_names,
                    record_names,
                    record_type: Some(definition.name),
                    is_static,
                }));
            }
            let mut canonical_names = Vec::with_capacity(definition.fields.len());
            let mut declared_names = Vec::with_capacity(definition.fields.len());
            for field in &definition.fields {
                let declared = format!("{}.{}", decl.name, field.name);
                let canonical = format!("{canonical_base}.{}", field.name);
                self.arrays
                    .insert_active_alias(declared.clone(), canonical.clone())?;
                declared_names.push(declared);
                canonical_names.push(canonical);
            }
            Ok(Some(ProcedureArrayOwnership {
                canonical_names,
                scalar_names: Vec::new(),
                declared_names,
                record_names,
                record_type: Some(definition.name),
                is_static,
            }))
        } else {
            if decl.bounds.is_empty() {
                return Ok(Some(ProcedureArrayOwnership {
                    canonical_names: Vec::new(),
                    scalar_names: vec![decl.name.clone()],
                    declared_names: vec![decl.name.clone()],
                    record_names: Vec::new(),
                    record_type: None,
                    is_static,
                }));
            }
            self.arrays
                .insert_active_alias(decl.name.clone(), canonical_base.clone())?;
            Ok(Some(ProcedureArrayOwnership {
                canonical_names: vec![canonical_base],
                scalar_names: Vec::new(),
                declared_names: vec![decl.name.clone()],
                record_names: Vec::new(),
                record_type: None,
                is_static,
            }))
        }
    }

    fn dimension_value(&mut self, decl: DimDecl, bounds: &[i64]) -> Result<(), Error> {
        let Some(as_type) = decl.as_type else {
            return self.arrays.dim(&decl.name, bounds);
        };
        if let Some(definition) = self.structured_definitions.types.get(&as_type).cloned() {
            if variable_type(&decl.name) != VariableType::Numeric || decl.name.contains('.') {
                return Err(Error::syntax("record variable name must be unsuffixed"));
            }
            if self
                .record_instances
                .get(&decl.name)
                .is_some_and(|existing| existing != &as_type)
            {
                return Err(Error::syntax(format!(
                    "{} is already declared as another TYPE",
                    decl.name
                )));
            }
            if definition.name != as_type {
                return Err(Error::syntax("internal TYPE definition mismatch"));
            }
            for field in &definition.fields {
                if let Some(length) = field.fixed_string_bytes {
                    if length > self.max_string_bytes {
                        return Err(Error::StringTooLong {
                            length,
                            limit: self.max_string_bytes,
                        });
                    }
                }
                let qualified = format!("{}.{}", decl.name, field.name);
                let declared = DeclaredValueType {
                    declaration: field.declaration,
                    fixed_string_bytes: field.fixed_string_bytes,
                };
                self.declared_value_types
                    .insert(qualified.clone(), declared);
                if bounds.is_empty() {
                    self.assign(qualified, self.default_declared_value(declared))?;
                } else {
                    self.arrays.dim_typed_fixed(
                        &qualified,
                        bounds,
                        field.declaration == VariableType::String,
                        field.fixed_string_bytes,
                    )?;
                }
            }
            for (name, type_name) in record_instance_declarations(&decl.name, &definition) {
                self.record_instances.insert(name, type_name);
            }
            return Ok(());
        }

        let declaration = parse_primitive_as_type(&as_type)
            .ok_or_else(|| Error::syntax(format!("undefined TYPE {as_type}")))?;
        let declared = DeclaredValueType {
            declaration,
            fixed_string_bytes: None,
        };
        if variable_type(&decl.name) != VariableType::Numeric {
            return Err(Error::syntax(
                "a suffixed DIM variable cannot also have an AS kind",
            ));
        }
        self.declared_value_types
            .insert(decl.name.clone(), declared);
        if bounds.is_empty() {
            self.assign(decl.name, self.default_declared_value(declared))
        } else {
            self.arrays
                .dim_typed(&decl.name, bounds, declaration == VariableType::String)
        }
    }

    fn default_declared_value(&self, declared: DeclaredValueType) -> Value {
        match declared.declaration {
            VariableType::String => Value::String(
                declared
                    .fixed_string_bytes
                    .map_or_else(String::new, |length| " ".repeat(length)),
            ),
            VariableType::Single | VariableType::Double => Value::Real(BasicReal::zero()),
            VariableType::Numeric | VariableType::Integer | VariableType::Long => Value::Integer(0),
        }
    }

    fn execute_redim(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (preserve, declarations) = match rest.split_first() {
            Some((TokenInstance::Ident(name), rest)) if name == "PRESERVE" => (true, rest),
            _ => (false, rest),
        };
        let decls = parse_dim_list(declarations)?;
        let mut evaluated = Vec::with_capacity(decls.len());
        for decl in decls {
            let mut bounds = Vec::with_capacity(decl.bounds.len());
            for bound_tokens in &decl.bounds {
                bounds.push(self.evaluate_integer(bound_tokens)?);
            }
            evaluated.push((decl, bounds));
        }

        let mut arrays = self.arrays.clone();
        let mut storage = self.storage.clone();
        let mut declared_types = self.declared_value_types.clone();
        let mut instances = self.record_instances.clone();
        for (decl, bounds) in evaluated {
            let as_type = decl
                .as_type
                .clone()
                .or_else(|| instances.get(&decl.name).cloned());
            if let Some(as_type) = as_type {
                if let Some(definition) = self.structured_definitions.types.get(&as_type) {
                    if instances
                        .get(&decl.name)
                        .is_some_and(|existing| existing != &as_type)
                    {
                        return Err(Error::syntax(format!(
                            "{} is already dimensioned as another TYPE",
                            decl.name
                        )));
                    }
                    for field in &definition.fields {
                        let qualified = format!("{}.{}", decl.name, field.name);
                        arrays.redim_bounded_typed_fixed(
                            &qualified,
                            &bounds,
                            preserve,
                            &mut storage,
                            field.declaration == VariableType::String,
                            field.fixed_string_bytes,
                        )?;
                        declared_types.insert(
                            qualified,
                            DeclaredValueType {
                                declaration: field.declaration,
                                fixed_string_bytes: field.fixed_string_bytes,
                            },
                        );
                    }
                    for (name, type_name) in record_instance_declarations(&decl.name, definition) {
                        instances.insert(name, type_name);
                    }
                    continue;
                }
                let declaration = parse_primitive_as_type(&as_type)
                    .ok_or_else(|| Error::syntax(format!("undefined TYPE {as_type}")))?;
                arrays.redim_bounded_typed(
                    &decl.name,
                    &bounds,
                    preserve,
                    &mut storage,
                    declaration == VariableType::String,
                )?;
                declared_types.insert(
                    decl.name,
                    DeclaredValueType {
                        declaration,
                        fixed_string_bytes: None,
                    },
                );
                continue;
            }
            arrays.redim_bounded(&decl.name, &bounds, preserve, &mut storage)?;
        }
        self.arrays = arrays;
        self.storage = storage;
        self.declared_value_types = declared_types;
        self.record_instances = instances;
        Ok(Control::Advance)
    }

    fn execute_const(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if !self.procedure_stack.is_empty() {
            return Err(Error::syntax("CONST is not allowed inside SUB or FUNCTION"));
        }
        if rest.is_empty() {
            return Err(Error::syntax("CONST requires at least one declaration"));
        }
        let original_vars = self.vars.clone();
        let original_arrays = self.arrays.clone();
        let original_storage = self.storage.clone();
        let original_constants = self.constants.clone();
        let original_rng = self.rng.clone();

        let result = (|| {
            for declaration in split_graph_arguments(rest)? {
                let Some(TokenInstance::Ident(name)) = declaration.first() else {
                    return Err(Error::syntax("CONST expects a name"));
                };
                if declaration.len() < 3
                    || !matches!(
                        declaration.get(1),
                        Some(TokenInstance::Keyword(Token::Equal))
                    )
                {
                    return Err(Error::syntax("CONST expects name = expression"));
                }
                if self.constants.contains(name) || self.vars.contains_key(name) {
                    return Err(Error::syntax(format!("constant {name} is already defined")));
                }
                let value = self.evaluate_value(&declaration[2..])?;
                let value = self.coerce_default_assignment(name, value)?;
                Self::assign_to_store(&mut self.vars, &mut self.storage, name.clone(), value)?;
                self.constants.insert(name.clone());
            }
            Ok(Control::Advance)
        })();
        if result.is_err() {
            self.vars = original_vars;
            self.arrays = original_arrays;
            self.storage = original_storage;
            self.constants = original_constants;
            self.rng = original_rng;
        }
        result
    }

    fn execute_def(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (name, mut pos) = match rest {
            [TokenInstance::Keyword(Token::Fn), TokenInstance::Ident(name), ..] => {
                (name.clone(), 2)
            }
            [TokenInstance::Ident(identifier), ..] => {
                let name = compact_function_name(identifier)
                    .ok_or_else(|| Error::syntax("DEF requires an FN function name"))?;
                (name.to_string(), 1)
            }
            _ => return Err(Error::syntax("DEF requires an FN function name")),
        };
        if is_string_variable(&name) {
            return Err(Error::TypeMismatch);
        }
        if !matches!(rest.get(pos), Some(TokenInstance::LParen)) {
            return Err(Error::syntax("DEF FN requires '('"));
        }
        pos += 1;
        let mut parameters = Vec::new();
        loop {
            let parameter = match rest.get(pos) {
                Some(TokenInstance::Ident(parameter)) if !is_string_variable(parameter) => {
                    parameter.clone()
                }
                Some(TokenInstance::Ident(_)) => return Err(Error::TypeMismatch),
                _ => return Err(Error::syntax("DEF FN requires a numeric parameter")),
            };
            if parameters.contains(&parameter) {
                return Err(Error::syntax("DEF FN parameter names must be unique"));
            }
            parameters.push(parameter);
            pos += 1;
            match rest.get(pos) {
                Some(TokenInstance::Comma) => {
                    pos += 1;
                }
                Some(TokenInstance::RParen) => {
                    pos += 1;
                    break;
                }
                _ => return Err(Error::syntax("DEF FN parameters require ',' or ')'")),
            }
        }
        if !matches!(rest.get(pos), Some(TokenInstance::Keyword(Token::Equal))) {
            return Err(Error::syntax("DEF FN requires '='"));
        }
        pos += 1;
        if pos >= rest.len() {
            return Err(Error::syntax("DEF FN requires an expression"));
        }
        self.user_functions
            .define(name, parameters, rest[pos..].to_vec());
        Ok(Control::Advance)
    }

    fn execute_gosub(
        &mut self,
        rest: &[TokenInstance],
        return_pc: usize,
    ) -> Result<Control, Error> {
        let target = parse_line_number(rest)?;
        self.gosub_target(target, return_pc)
    }

    fn gosub_target(&mut self, target: u64, return_pc: usize) -> Result<Control, Error> {
        if self.call_stack.len() + self.procedure_stack.len() >= self.max_call_depth {
            return Err(Error::CallStackExceeded {
                limit: self.max_call_depth,
            });
        }
        self.call_stack.push(CallFrame {
            return_pc,
            loop_depth: self.loop_stack.len(),
            event: None,
        });
        Ok(Control::Gosub(target))
    }

    fn pending_event(&mut self) -> Result<Option<(EventKind, u64)>, Error> {
        let mut com_ports = self.com_traps.keys().copied().collect::<Vec<_>>();
        com_ports.sort_unstable();
        for port in &com_ports {
            if let Some(error) = self
                .com_traps
                .get_mut(port)
                .and_then(|trap| trap.latched_error.take())
            {
                return Err(error);
            }
        }

        if !self.procedure_stack.is_empty()
            || self.call_stack.iter().any(|frame| frame.event.is_some())
            || self.timer_trap.active
            || self.collision_trap.active
            || self.key_trap.active
            || self.pen_trap.active
            || self.strig_trap.active
            || self.com_traps.values().any(|trap| trap.active)
        {
            return Ok(None);
        }

        if self.key_trap.mode == EventMode::On {
            if let (Some(keycode), Some(target)) = (self.key_trap.keycode, self.key_trap.target) {
                if crate::screen::take_key_press(keycode) {
                    return Ok(Some((EventKind::Key, target)));
                }
            }
        }

        if self.pen_trap.mode == EventMode::On {
            let generation = crate::screen::pointer_state().press_generation;
            if generation != self.pen_trap.last_generation {
                self.pen_trap.last_generation = generation;
                if let Some(target) = self.pen_trap.target {
                    return Ok(Some((EventKind::Pen, target)));
                }
            }
        }

        if self.strig_trap.mode == EventMode::On {
            if let Some(selector) = self.strig_trap.selector {
                if let Ok(generation) = crate::devices::strig_generation(selector) {
                    if generation != self.strig_trap.last_generation {
                        self.strig_trap.last_generation = generation;
                        if let Some(target) = self.strig_trap.target {
                            return Ok(Some((EventKind::Strig, target)));
                        }
                    }
                }
            }
        }

        for port in com_ports {
            let Some(trap) = self.com_traps.get(&port) else {
                continue;
            };
            let (mode, active, channel, target) =
                (trap.mode, trap.active, trap.channel, trap.target);
            if mode == EventMode::On && !active {
                if let Some(target) = target {
                    match self.files.serial_data_available(channel) {
                        Ok(true) => return Ok(Some((EventKind::Com(port), target))),
                        Ok(false) => {}
                        Err(error) => {
                            if let Some(trap) = self.com_traps.get_mut(&port) {
                                trap.mode = EventMode::Off;
                                trap.active = false;
                                trap.latched_error = Some(error);
                            }
                        }
                    }
                }
            }
        }

        if self.collision_trap.mode == EventMode::On {
            let colliding = self.graphics.any_sprite_collision();
            if !colliding {
                self.collision_trap.collision_latched = false;
            } else if !self.collision_trap.collision_latched {
                self.collision_trap.collision_latched = true;
                if let Some(target) = self.collision_trap.target {
                    return Ok(Some((EventKind::Collision, target)));
                }
            }
        }

        if self.timer_trap.mode == EventMode::On {
            let now = Instant::now();
            if self.timer_trap.next_due.is_some_and(|due| now >= due) {
                self.timer_trap.next_due = Some(now + self.timer_trap.interval);
                if let Some(target) = self.timer_trap.target {
                    return Ok(Some((EventKind::Timer, target)));
                }
            }
        }
        Ok(None)
    }

    fn begin_event(&mut self, event: EventKind, return_pc: usize) -> Result<(), Error> {
        if self.call_stack.len() + self.procedure_stack.len() >= self.max_call_depth {
            return Err(Error::CallStackExceeded {
                limit: self.max_call_depth,
            });
        }
        match event {
            EventKind::Timer => self.timer_trap.active = true,
            EventKind::Collision => self.collision_trap.active = true,
            EventKind::Key => self.key_trap.active = true,
            EventKind::Com(port) => {
                if let Some(trap) = self.com_traps.get_mut(&port) {
                    trap.active = true;
                }
            }
            EventKind::Pen => self.pen_trap.active = true,
            EventKind::Strig => self.strig_trap.active = true,
        }
        self.call_stack.push(CallFrame {
            return_pc,
            loop_depth: self.loop_stack.len(),
            event: Some(event),
        });
        Ok(())
    }

    fn execute_return(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        expect_end_of_line(rest)?;
        let frame = self.call_stack.pop().ok_or(Error::ReturnWithoutGosub)?;
        match frame.event {
            Some(EventKind::Timer) => self.timer_trap.active = false,
            Some(EventKind::Collision) => self.collision_trap.active = false,
            Some(EventKind::Key) => self.key_trap.active = false,
            Some(EventKind::Com(port)) => {
                if let Some(trap) = self.com_traps.get_mut(&port) {
                    trap.active = false;
                }
            }
            Some(EventKind::Pen) => self.pen_trap.active = false,
            Some(EventKind::Strig) => self.strig_trap.active = false,
            None => {}
        }
        Ok(Control::Resume {
            pc: frame.return_pc,
            loop_depth: frame.loop_depth,
        })
    }

    fn execute_for(
        &mut self,
        rest: &[TokenInstance],
        for_pc: usize,
        resume_pc: usize,
    ) -> Result<Control, Error> {
        if rest.len() < 4 {
            return Err(Error::syntax("incomplete FOR statement"));
        }

        let var = match &rest[0] {
            TokenInstance::Ident(name) => name.clone(),
            _ => return Err(Error::syntax("expected variable in FOR")),
        };

        if is_string_variable(&var) {
            return Err(Error::TypeMismatch);
        }

        if !matches!(rest[1], TokenInstance::Keyword(Token::Equal)) {
            return Err(Error::syntax("expected = in FOR"));
        }

        let to_pos = rest
            .iter()
            .position(|t| matches!(t, TokenInstance::Keyword(Token::To)))
            .ok_or_else(|| Error::syntax("expected TO in FOR"))?;
        if to_pos < 2 {
            return Err(Error::syntax("missing start value in FOR"));
        }

        let start_tokens = &rest[2..to_pos];
        let step_pos = rest[to_pos + 1..]
            .iter()
            .position(|t| matches!(t, TokenInstance::Keyword(Token::Step)));
        let step_pos = step_pos.map(|pos| to_pos + 1 + pos);
        let limit_end = step_pos.unwrap_or(rest.len());
        let limit_tokens = &rest[to_pos + 1..limit_end];
        let step_tokens = step_pos.map(|sp| &rest[sp + 1..]);

        if limit_tokens.is_empty() {
            return Err(Error::syntax("missing limit value in FOR"));
        }
        if let Some(tokens) = step_tokens {
            if tokens.is_empty() {
                return Err(Error::syntax("missing STEP value in FOR"));
            }
        }

        let start = self.evaluate_integer(start_tokens)?;
        let limit = self.evaluate_integer(limit_tokens)?;
        let step = if let Some(tokens) = step_tokens {
            self.evaluate_integer(tokens)?
        } else {
            1
        };
        if step == 0 {
            return Err(Error::IllegalQuantity);
        }

        self.assign(var.clone(), Value::Integer(start))?;

        // BASIC checks the termination condition at FOR, not at NEXT.
        // If the loop should not execute at all, skip past the matching NEXT.
        let should_enter = if step > 0 {
            start <= limit
        } else {
            start >= limit
        };

        if !should_enter {
            let (statements, _) = build_statements(&self.current_program);
            let next_pc = matching_next(&statements, for_pc)?;
            if let Some(pos) = self.loop_stack.iter().position(|f| f.var == var) {
                self.loop_stack.truncate(pos);
            }
            let after_next = next_pc + 1;
            let loop_depth = self.loop_stack.len();
            if after_next >= statements.len() {
                return Ok(Control::Terminate(RunTermination::Exhausted));
            }
            return Ok(Control::Resume {
                pc: after_next,
                loop_depth,
            });
        }

        self.push_loop_frame(LoopFrame {
            var,
            limit,
            step,
            resume_pc,
        })?;

        Ok(Control::Advance)
    }

    fn push_loop_frame(&mut self, frame: LoopFrame) -> Result<(), Error> {
        // Re-entering a `FOR` for a variable that is already active replaces that
        // frame and discards any inner frames, matching the stack-renewal
        // behaviour of Microsoft BASIC.
        if let Some(pos) = self.loop_stack.iter().position(|f| f.var == frame.var) {
            self.loop_stack.truncate(pos + 1);
            let slot = self
                .loop_stack
                .last_mut()
                .ok_or_else(|| Error::syntax("internal loop frame missing after truncation"))?;
            *slot = frame;
            return Ok(());
        }

        if self.loop_stack.len() >= self.max_loop_depth {
            return Err(Error::LoopStackExceeded {
                limit: self.max_loop_depth,
            });
        }
        self.loop_stack.push(frame);
        Ok(())
    }

    fn execute_next(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let targets = parse_next_variables(rest)?;
        for target in targets {
            let control = self.advance_next_variable(target)?;
            if matches!(control, Control::Resume { .. }) {
                return Ok(control);
            }
        }
        Ok(Control::Advance)
    }

    fn advance_next_variable(&mut self, target: Option<String>) -> Result<Control, Error> {
        if let Some(ref name) = target {
            if is_string_variable(name) {
                return Err(Error::TypeMismatch);
            }
        }

        let pos = match &target {
            Some(name) => self.loop_stack.iter().rposition(|f| f.var == *name),
            None => {
                if self.loop_stack.is_empty() {
                    None
                } else {
                    Some(self.loop_stack.len() - 1)
                }
            }
        };

        let pos = pos.ok_or_else(|| Error::NextWithoutFor {
            variable: target.clone(),
        })?;

        // Named `NEXT` discards any inner loop frames above the matching one.
        self.loop_stack.truncate(pos + 1);
        let (var_name, step, limit, resume_pc) = {
            let frame = self
                .loop_stack
                .last()
                .ok_or_else(|| Error::NextWithoutFor {
                    variable: target.clone(),
                })?;
            (frame.var.clone(), frame.step, frame.limit, frame.resume_pc)
        };

        let current = match self.scalar_value(&var_name)? {
            Some(Value::Integer(n)) => n,
            Some(Value::Real(n)) => BasicInteger::with_mode(self.mode, n.to_integer()?)?.value(),
            Some(Value::Complex(_) | Value::List(_) | Value::String(_)) => {
                return Err(Error::TypeMismatch)
            }
            None => 0,
        };
        let new_value = BasicInteger::with_mode(self.mode, current)?
            .add(BasicInteger::with_mode(self.mode, step)?)?
            .value();
        self.assign(var_name, Value::Integer(new_value))?;

        let repeat = if step >= 0 {
            new_value <= limit
        } else {
            new_value >= limit
        };

        if repeat {
            let loop_depth = self.loop_stack.len();
            Ok(Control::Resume {
                pc: resume_pc,
                loop_depth,
            })
        } else {
            self.loop_stack.pop();
            Ok(Control::Advance)
        }
    }

    fn execute_if<R: BufRead + ?Sized, W: Write>(
        &mut self,
        rest: &[TokenInstance],
        line_number: u64,
        pc: usize,
        input: &mut R,
        writer: &mut W,
    ) -> Result<Control, Error> {
        // The historical parser accepts either IF expr THEN ... or the shorter
        // IF expr GOTO line form.  The delimiter terminates the condition.
        let branch_pos = rest
            .iter()
            .position(|token| matches!(token, TokenInstance::Keyword(Token::Then | Token::Goto)))
            .ok_or_else(|| Error::syntax("IF without THEN or GOTO"))?;

        if branch_pos == 0 {
            return Err(Error::syntax("IF requires a condition"));
        }
        let block_form = branch_pos + 1 == rest.len()
            && matches!(rest[branch_pos], TokenInstance::Keyword(Token::Then));
        if branch_pos + 1 >= rest.len() && !block_form {
            return Err(Error::syntax("IF branch requires a target or statement"));
        }

        let condition = self.resolve_function_calls(&rest[..branch_pos], input, writer)?;
        let cond_value = self.evaluate_value(&condition)?;
        if !cond_value.numeric_truth()? {
            return Ok(Control::SkipIfFalse);
        }
        if block_form {
            return Ok(Control::Advance);
        }

        let branch = &rest[branch_pos + 1..];
        if matches!(rest[branch_pos], TokenInstance::Keyword(Token::Goto))
            || matches!(branch.first(), Some(TokenInstance::Number(_)))
            || matches!(
                branch,
                [
                    TokenInstance::Keyword(Token::Minus),
                    TokenInstance::Number(_),
                    ..
                ]
            )
        {
            return Ok(Control::Goto(parse_line_number(branch)?));
        }

        // Execute an inline THEN body through the normal native dispatcher.
        // It remains part of this single flattened statement, so it does not
        // consume another step or disturb same-line return addresses.
        let inline = Statement {
            line_number,
            body: branch.to_vec(),
        };
        self.execute_statement(&inline, pc, input, writer)
    }

    fn execute_on(&mut self, rest: &[TokenInstance], return_pc: usize) -> Result<Control, Error> {
        if matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == "TIMER") {
            return self.execute_on_timer(rest);
        }
        if matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == "COLLISION") {
            return self.execute_on_collision(rest);
        }
        if matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == "KEY") {
            return self.execute_on_key(rest);
        }
        if matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == "COM") {
            return self.execute_on_com(rest);
        }
        if matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == "STRIG") {
            return self.execute_on_strig(rest);
        }
        if matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == "PEN") {
            return self.execute_on_pen(rest);
        }
        // ON ERROR GOTO line -- set up error trap
        let is_on_error = match rest.first() {
            Some(TokenInstance::Keyword(Token::ErrorStmt)) => true,
            Some(TokenInstance::Ident(s)) if matches!(s.as_str(), "ERROR" | "ERR") => true,
            _ => false,
        };
        if is_on_error {
            if !matches!(rest.get(1), Some(TokenInstance::Keyword(Token::Goto))) {
                return Err(Error::syntax("ON ERROR/ERR requires GOTO"));
            }
            let target = parse_line_number(&rest[2..])?;
            self.on_error_goto = (target != 0).then_some(target);
            self.error_handler_active = false;
            self.resume_pc = None;
            return Ok(Control::Advance);
        }
        let branch_pos = rest
            .iter()
            .position(|token| matches!(token, TokenInstance::Keyword(Token::Goto | Token::Gosub)))
            .ok_or_else(|| Error::syntax("ON requires GOTO or GOSUB"))?;
        if branch_pos == 0 {
            return Err(Error::syntax("ON requires a selector expression"));
        }

        let selector = self.evaluate_integer(&rest[..branch_pos])?;
        if selector < 0 {
            return Err(Error::IllegalQuantity);
        }
        let targets = parse_line_number_list(&rest[branch_pos + 1..])?;
        let Ok(index) = usize::try_from(selector) else {
            return Ok(Control::Advance);
        };
        let Some(target) = index.checked_sub(1).and_then(|index| targets.get(index)) else {
            return Ok(Control::Advance);
        };

        if matches!(rest[branch_pos], TokenInstance::Keyword(Token::Gosub)) {
            self.gosub_target(*target, return_pc)
        } else {
            Ok(Control::Goto(*target))
        }
    }

    fn execute_on_timer(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if !matches!(rest.get(1), Some(TokenInstance::LParen)) {
            return Err(Error::syntax("ON TIMER requires TIMER(seconds) GOSUB line"));
        }
        let mut depth = 1usize;
        let mut end = None;
        for (index, token) in rest.iter().enumerate().skip(2) {
            match token {
                TokenInstance::LParen => depth += 1,
                TokenInstance::RParen => {
                    depth -= 1;
                    if depth == 0 {
                        end = Some(index);
                        break;
                    }
                }
                _ => {}
            }
        }
        let end = end.ok_or_else(|| Error::syntax("expected ')' in ON TIMER"))?;
        if end == 2
            || !matches!(
                rest.get(end + 1),
                Some(TokenInstance::Keyword(Token::Gosub))
            )
        {
            return Err(Error::syntax("ON TIMER requires TIMER(seconds) GOSUB line"));
        }
        let interval = self.evaluate_graph_real(&rest[2..end])?;
        if !interval.is_finite() || interval <= 0.0 || interval > 86_400.0 {
            return Err(Error::IllegalQuantity);
        }
        let target = parse_line_number(&rest[end + 2..])?;
        self.timer_trap.target = Some(target);
        self.timer_trap.interval = Duration::from_secs_f64(interval);
        if self.timer_trap.mode == EventMode::On {
            self.timer_trap.next_due = Some(Instant::now() + self.timer_trap.interval);
        }
        Ok(Control::Advance)
    }

    fn execute_on_collision(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if !matches!(rest.get(1), Some(TokenInstance::Keyword(Token::Gosub))) {
            return Err(Error::syntax("ON COLLISION requires GOSUB line"));
        }
        let target = parse_line_number(&rest[2..])?;
        self.collision_trap.target = Some(target);
        self.collision_trap.collision_latched = false;
        Ok(Control::Advance)
    }

    fn execute_on_key(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (keycode, end) = self.parse_key_selector(rest, "ON KEY")?;
        if !matches!(rest.get(end), Some(TokenInstance::Keyword(Token::Gosub))) {
            return Err(Error::syntax("ON KEY requires KEY(n) GOSUB line"));
        }
        let target = parse_line_number(&rest[end + 1..])?;
        self.key_trap.target = Some(target);
        self.key_trap.keycode = Some(keycode);
        Ok(Control::Advance)
    }

    fn execute_on_com(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (port, end) = self.parse_event_selector(rest, "COM", 1, 255)?;
        if !matches!(rest.get(end), Some(TokenInstance::Keyword(Token::Gosub))) {
            return Err(Error::syntax("ON COM(n) requires GOSUB line"));
        }
        let target = parse_line_number(&rest[end + 1..])?;
        let port = port as u8;
        let channel = self.files.serial_channel_for_port(port).unwrap_or(port);
        let trap = self.com_traps.entry(port).or_default();
        trap.target = Some(target);
        trap.channel = channel;
        Ok(Control::Advance)
    }

    fn execute_on_strig(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        let (selector, end) = self.parse_event_selector(rest, "STRIG", 0, 7)?;
        if !matches!(rest.get(end), Some(TokenInstance::Keyword(Token::Gosub))) {
            return Err(Error::syntax("ON STRIG(n) requires GOSUB line"));
        }
        let target = parse_line_number(&rest[end + 1..])?;
        let selector = selector as u8;
        self.strig_trap.target = Some(target);
        self.strig_trap.selector = Some(selector);
        self.strig_trap.last_generation = crate::devices::strig_generation(selector)?;
        Ok(Control::Advance)
    }

    fn execute_on_pen(&mut self, rest: &[TokenInstance]) -> Result<Control, Error> {
        if !matches!(rest.get(1), Some(TokenInstance::Keyword(Token::Gosub))) {
            return Err(Error::syntax("ON PEN requires GOSUB line"));
        }
        self.pen_trap.target = Some(parse_line_number(&rest[2..])?);
        self.pen_trap.last_generation = crate::screen::pointer_state().press_generation;
        Ok(Control::Advance)
    }

    fn parse_event_selector(
        &mut self,
        rest: &[TokenInstance],
        event: &str,
        minimum: i64,
        maximum: i64,
    ) -> Result<(i64, usize), Error> {
        if !matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == event)
            || !matches!(rest.get(1), Some(TokenInstance::LParen))
        {
            return Err(Error::syntax(format!("{event} requires {event}(n)")));
        }
        let mut depth = 1usize;
        let mut close = None;
        for (index, token) in rest.iter().enumerate().skip(2) {
            match token {
                TokenInstance::LParen => depth += 1,
                TokenInstance::RParen => {
                    depth -= 1;
                    if depth == 0 {
                        close = Some(index);
                        break;
                    }
                }
                _ => {}
            }
        }
        let close = close.ok_or_else(|| Error::syntax(format!("{event}(n) requires ')'")))?;
        if close == 2 {
            return Err(Error::syntax(format!("{event}(n) requires a selector")));
        }
        let selector = self.evaluate_integer(&rest[2..close])?;
        if !(minimum..=maximum).contains(&selector) {
            return Err(Error::IllegalQuantity);
        }
        Ok((selector, close + 1))
    }

    fn parse_key_selector(
        &mut self,
        rest: &[TokenInstance],
        statement: &str,
    ) -> Result<(u8, usize), Error> {
        if !matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == "KEY")
            || !matches!(rest.get(1), Some(TokenInstance::LParen))
        {
            return Err(Error::syntax(format!("{statement} requires KEY(n)")));
        }
        let mut depth = 1usize;
        let mut close = None;
        for (index, token) in rest.iter().enumerate().skip(2) {
            match token {
                TokenInstance::LParen => depth += 1,
                TokenInstance::RParen => {
                    depth -= 1;
                    if depth == 0 {
                        close = Some(index);
                        break;
                    }
                }
                _ => {}
            }
        }
        let close = close.ok_or_else(|| Error::syntax(format!("{statement} requires ')'")))?;
        if close == 2 {
            return Err(Error::syntax(format!("{statement} requires a keycode")));
        }
        let keycode = self.evaluate_integer(&rest[2..close])?;
        if !(1..=255).contains(&keycode) {
            return Err(Error::IllegalQuantity);
        }
        Ok((keycode as u8, close + 1))
    }

    fn execute_event_control(
        &mut self,
        event: &str,
        rest: &[TokenInstance],
    ) -> Result<Control, Error> {
        if event == "COM" {
            let mut selector = Vec::with_capacity(rest.len() + 1);
            selector.push(TokenInstance::Ident("COM".to_string()));
            selector.extend_from_slice(rest);
            let (port, end) = self.parse_event_selector(&selector, "COM", 1, 255)?;
            let mode = parse_event_mode(&selector[end..], "COM")?;
            let port = port as u8;
            let channel = self.files.serial_channel_for_port(port).unwrap_or(port);
            let trap = self.com_traps.entry(port).or_default();
            if mode == EventMode::On && trap.target.is_none() {
                return Err(Error::syntax(
                    "COM(n) ON requires matching ON COM(n) GOSUB first",
                ));
            }
            if mode == EventMode::Off {
                trap.active = false;
            }
            trap.channel = channel;
            trap.mode = mode;
            return Ok(Control::Advance);
        }
        if event == "STRIG" {
            let (selector, mode) = if matches!(rest.first(), Some(TokenInstance::LParen)) {
                let mut tokens = Vec::with_capacity(rest.len() + 1);
                tokens.push(TokenInstance::Ident("STRIG".to_string()));
                tokens.extend_from_slice(rest);
                let (selector, end) = self.parse_event_selector(&tokens, "STRIG", 0, 7)?;
                (selector as u8, parse_event_mode(&tokens[end..], "STRIG")?)
            } else {
                (
                    self.strig_trap.selector.unwrap_or(0),
                    parse_event_mode(rest, "STRIG")?,
                )
            };
            if mode == EventMode::On
                && (self.strig_trap.target.is_none() || self.strig_trap.selector != Some(selector))
            {
                return Err(Error::syntax(
                    "STRIG ON requires matching ON STRIG(n) GOSUB first",
                ));
            }
            if mode == EventMode::Off {
                self.strig_trap.active = false;
            }
            self.strig_trap.selector = Some(selector);
            self.strig_trap.last_generation = crate::devices::strig_generation(selector)?;
            self.strig_trap.mode = mode;
            return Ok(Control::Advance);
        }
        if event == "KEY" {
            let mut selector = Vec::with_capacity(rest.len() + 1);
            selector.push(TokenInstance::Ident("KEY".to_string()));
            selector.extend_from_slice(rest);
            let (keycode, end) = self.parse_key_selector(&selector, "KEY")?;
            let mode = parse_event_mode(&selector[end..], "KEY")?;
            if mode == EventMode::On
                && (self.key_trap.target.is_none() || self.key_trap.keycode != Some(keycode))
            {
                return Err(Error::syntax(
                    "KEY(n) ON requires matching ON KEY(n) GOSUB first",
                ));
            }
            if mode == EventMode::Off {
                crate::screen::clear_key_presses(keycode);
                self.key_trap.active = false;
            }
            self.key_trap.keycode = Some(keycode);
            self.key_trap.mode = mode;
            return Ok(Control::Advance);
        }
        let mode = parse_event_mode(rest, event)?;
        match event {
            "TIMER" => {
                if mode == EventMode::On && self.timer_trap.target.is_none() {
                    return Err(Error::syntax("TIMER ON requires ON TIMER(...) GOSUB first"));
                }
                if mode == EventMode::On && self.timer_trap.mode == EventMode::Off {
                    self.timer_trap.next_due = Some(Instant::now() + self.timer_trap.interval);
                } else if mode == EventMode::Off {
                    self.timer_trap.next_due = None;
                    self.timer_trap.active = false;
                }
                self.timer_trap.mode = mode;
            }
            "COLLISION" => {
                if mode == EventMode::On && self.collision_trap.target.is_none() {
                    return Err(Error::syntax(
                        "COLLISION ON requires ON COLLISION GOSUB first",
                    ));
                }
                if mode != EventMode::Stopped {
                    self.collision_trap.collision_latched = false;
                }
                if mode == EventMode::Off {
                    self.collision_trap.active = false;
                }
                self.collision_trap.mode = mode;
            }
            "PEN" => {
                if mode == EventMode::On && self.pen_trap.target.is_none() {
                    return Err(Error::syntax("PEN ON requires ON PEN GOSUB first"));
                }
                if mode == EventMode::Off {
                    self.pen_trap.active = false;
                }
                if mode != EventMode::Stopped {
                    self.pen_trap.last_generation = crate::screen::pointer_state().press_generation;
                }
                self.pen_trap.mode = mode;
            }
            _ => return Err(Error::syntax("internal event kind mismatch")),
        }
        Ok(Control::Advance)
    }

    fn execute_print<W: Write>(
        &mut self,
        rest: &[TokenInstance],
        writer: &mut W,
    ) -> Result<(), Error> {
        if let Some(channel) = self.cmd_channel {
            self.files.ensure_writable(channel)?;
            let mut column = self.files.output_column(channel)?;
            let mut bytes = Vec::new();
            self.render_print(rest, &mut bytes, &mut column)?;
            return self.files.write(channel, &bytes);
        }
        let mut logical_column = self.output_column;
        let mut bytes = Vec::new();
        self.render_print(rest, &mut bytes, &mut logical_column)?;
        let rendered = String::from_utf8(bytes)
            .map_err(|error| Error::Io(format!("PRINT produced invalid UTF-8: {error}")))?;
        let mut column = self.output_column;
        let mut wrapped = String::with_capacity(rendered.len());
        for character in rendered.chars() {
            if character == '\n' {
                wrapped.push(character);
                column = 0;
                continue;
            }
            if self.output_width.is_some_and(|width| column >= width) {
                wrapped.push('\n');
                column = 0;
            }
            wrapped.push(character);
            column += 1;
        }
        writer.write_all(wrapped.as_bytes())?;
        for _ in wrapped.chars().filter(|character| *character == '\n') {
            self.advance_text_row();
        }
        if !matches!(
            rest.last(),
            Some(TokenInstance::Semicolon | TokenInstance::Comma)
        ) && self.null_padding > 0
        {
            writer.write_all(&vec![0; self.null_padding])?;
        }
        self.output_column = column;
        Ok(())
    }

    fn execute_lprint(&mut self, rest: &[TokenInstance]) -> Result<(), Error> {
        let mut bytes = Vec::new();
        if matches!(rest.first(), Some(TokenInstance::Keyword(Token::Using))) {
            let rest = &rest[1..];
            let sep = find_print_using_separator(rest).unwrap_or(rest.len());
            let format_str = self
                .evaluate_value(&rest[..sep])?
                .into_string()
                .ok_or(Error::TypeMismatch)?;
            let mut values = Vec::new();
            let mut start = sep.saturating_add(1);
            while start < rest.len() {
                if matches!(rest[start], TokenInstance::Semicolon | TokenInstance::Comma) {
                    start += 1;
                    continue;
                }
                let next = find_print_using_separator(&rest[start..])
                    .map(|position| start + position)
                    .unwrap_or(rest.len());
                values.push(self.evaluate_value(&rest[start..next])?);
                start = next.saturating_add(1);
            }
            let output = format_using(&format_str, &values)?;
            bytes.extend_from_slice(output.as_bytes());
            self.lprint_column = advance_column(self.lprint_column, &output);
            if !matches!(rest.last(), Some(TokenInstance::Semicolon)) {
                bytes.push(b'\n');
                self.lprint_column = 0;
            }
        } else {
            let mut column = self.lprint_column;
            self.render_print(rest, &mut bytes, &mut column)?;
            self.lprint_column = column;
        }
        crate::devices::write_printer(self.print_spool_path.as_deref(), &bytes)
    }

    /// PRINT USING format$; expr [; expr ...]
    /// Format placeholders: # digit, . decimal, , thousands, $$ dollar,
    /// ** fill, + - sign, ^ exponent, ! single char, & entire string,
    /// \\...\\ fixed-width string field, _ literal next char.
    fn execute_print_using<W: Write>(
        &mut self,
        rest: &[TokenInstance],
        writer: &mut W,
    ) -> Result<(), Error> {
        // First item is the format string
        let sep = find_print_using_separator(rest).unwrap_or(rest.len());
        let fmt_val = self.evaluate_value(&rest[..sep])?;
        let format_str = match fmt_val {
            Value::String(s) => s,
            _ => return Err(Error::TypeMismatch),
        };
        // Remaining items after separator are the values to format
        let mut value_tokens: Vec<&[TokenInstance]> = Vec::new();
        let mut start = sep + 1;
        while start < rest.len() {
            // Skip separators
            if matches!(rest[start], TokenInstance::Semicolon | TokenInstance::Comma) {
                start += 1;
                continue;
            }
            let next_sep = find_print_using_separator(&rest[start..])
                .map(|p| start + p)
                .unwrap_or(rest.len());
            value_tokens.push(&rest[start..next_sep]);
            start = next_sep + 1;
        }
        // Evaluate all values
        let values: Vec<Value> = value_tokens
            .iter()
            .map(|t| self.evaluate_value(t))
            .collect::<Result<Vec<_>, _>>()?;
        // Parse format string and fill with values
        let output = format_using(&format_str, &values)?;
        // Trailing semicolon suppresses newline
        let trailing_sep = matches!(rest.last(), Some(TokenInstance::Semicolon));
        if let Some(channel) = self.cmd_channel {
            let mut bytes = output.into_bytes();
            if !trailing_sep {
                bytes.push(b'\n');
            }
            self.files.write(channel, &bytes)?;
            return Ok(());
        }
        let mut column = self.output_column;
        let mut wrapped = String::with_capacity(output.len() + usize::from(!trailing_sep));
        for character in output.chars() {
            if character == '\n' {
                wrapped.push(character);
                column = 0;
                continue;
            }
            if self.output_width.is_some_and(|width| column >= width) {
                wrapped.push('\n');
                column = 0;
            }
            wrapped.push(character);
            column += 1;
        }
        if !trailing_sep {
            wrapped.push('\n');
            column = 0;
        }
        writer.write_all(wrapped.as_bytes())?;
        for _ in wrapped.chars().filter(|character| *character == '\n') {
            self.advance_text_row();
        }
        if !trailing_sep && self.null_padding > 0 {
            writer.write_all(&vec![0; self.null_padding])?;
        }
        self.output_column = column;
        Ok(())
    }

    fn render_print<W: Write>(
        &mut self,
        rest: &[TokenInstance],
        writer: &mut W,
        column: &mut usize,
    ) -> Result<(), Error> {
        let mut pos = 0;
        let mut trailing_separator = false;

        while pos < rest.len() {
            match &rest[pos] {
                TokenInstance::Semicolon => {
                    pos += 1;
                    trailing_separator = true;
                    continue;
                }
                TokenInstance::Comma => {
                    let spaces = spaces_to_next_zone(*column);
                    self.write_print_spaces(writer, spaces, column)?;
                    pos += 1;
                    trailing_separator = true;
                    continue;
                }
                TokenInstance::Keyword(token @ (Token::Tab | Token::Spc)) => {
                    let argument_start = pos + 1;
                    if matches!(rest.get(argument_start), Some(TokenInstance::RParen) | None) {
                        return Err(Error::syntax(format!(
                            "{} requires a numeric argument",
                            token.to_text()
                        )));
                    }
                    let (value, next) =
                        self.evaluate_value_at_column(rest, argument_start, *column)?;
                    if !matches!(rest.get(next), Some(TokenInstance::RParen)) {
                        return Err(Error::syntax(format!(
                            "{} requires closing ')'",
                            token.to_text()
                        )));
                    }
                    let count = self.print_format_count(value)?;
                    let spaces = if *token == Token::Tab {
                        count.saturating_sub(*column)
                    } else {
                        count
                    };
                    self.write_print_spaces(writer, spaces, column)?;
                    pos = next + 1;
                    trailing_separator = false;
                }
                _ => {
                    let (value, new_pos) = self.evaluate_value_at_column(rest, pos, *column)?;
                    let text = value.to_string();
                    writer.write_all(text.as_bytes())?;
                    *column = advance_column(*column, &text);
                    pos = new_pos;
                    trailing_separator = false;
                }
            }

            if pos < rest.len()
                && !matches!(rest[pos], TokenInstance::Semicolon | TokenInstance::Comma)
            {
                return Err(Error::syntax("expected ';' or ',' between PRINT items"));
            }
        }

        if !trailing_separator {
            writer.write_all(b"\n")?;
            *column = 0;
        }
        Ok(())
    }

    fn print_format_count(&self, value: Value) -> Result<usize, Error> {
        let value = BasicInteger::with_mode(self.mode, value.to_integer()?)?.value();
        if value < 0 || (self.mode == NumericMode::Legacy6502 && value > 255) {
            return Err(Error::IllegalQuantity);
        }
        usize::try_from(value).map_err(|_| Error::IllegalQuantity)
    }

    fn write_print_spaces<W: Write>(
        &self,
        writer: &mut W,
        spaces: usize,
        column: &mut usize,
    ) -> Result<(), Error> {
        if spaces > self.max_print_padding {
            return Err(Error::PrintLimitExceeded {
                limit: self.max_print_padding,
            });
        }
        const SPACE_CHUNK: [u8; 256] = [b' '; 256];
        let mut remaining = spaces;
        while remaining > 0 {
            let count = remaining.min(SPACE_CHUNK.len());
            writer.write_all(&SPACE_CHUNK[..count])?;
            *column = (*column).saturating_add(count);
            remaining -= count;
        }
        Ok(())
    }

    fn write_terminal_text<W: Write>(&mut self, writer: &mut W, text: &str) -> Result<(), Error> {
        writer.write_all(text.as_bytes())?;
        for _ in text.chars().filter(|character| *character == '\n') {
            self.advance_text_row();
        }
        self.output_column = advance_column(self.output_column, text);
        Ok(())
    }

    fn write_terminal_line<W: Write>(&mut self, writer: &mut W, text: &str) -> Result<(), Error> {
        self.write_terminal_text(writer, text)?;
        writer.write_all(b"\n")?;
        self.output_column = 0;
        self.advance_text_row();
        Ok(())
    }

    fn evaluate_value(&mut self, tokens: &[TokenInstance]) -> Result<Value, Error> {
        self.validate_type_field_references(tokens)?;
        if expression_queries_graphics(tokens) {
            self.graphics.rasterize_if_dirty()?;
        }
        let uses_sadd = expression_uses_sadd(tokens);
        let mut scoped_vars = if !self.procedure_stack.is_empty() {
            Some(self.procedure_visible_variables()?)
        } else if uses_sadd {
            Some(self.vars.clone())
        } else {
            None
        };
        if uses_sadd {
            self.materialize_sadd_addresses(
                tokens,
                scoped_vars
                    .as_mut()
                    .expect("SADD evaluation owns a variable snapshot"),
            )?;
        }
        let session_clock = self.current_session_time();
        let variables = scoped_vars.as_ref().unwrap_or(&self.vars);
        eval::evaluate_value_tokens_with_user_functions(
            self.mode,
            tokens,
            variables,
            &mut self.arrays,
            self.max_string_bytes,
            &mut self.rng,
            eval::ExpressionRuntime::new(
                &self.user_functions,
                self.max_function_depth,
                self.output_column,
                self.storage.remaining_bytes(),
            )
            .with_cursor_row(self.cursor_row)
            .with_graph(&self.graph)
            .with_graphics(&self.graphics)
            .with_virtual_memory(&self.virtual_memory, self.memory_segment)
            .with_virtual_ports(&self.virtual_ports)
            .with_files(&self.files)
            .with_process_context(
                &self.command_line,
                &self.environment,
                &self.session_env,
                Some(&session_clock),
            )
            .with_system_services(&self.system_services, &self.usr_addresses),
        )
    }

    fn evaluate_integer(&mut self, tokens: &[TokenInstance]) -> Result<i64, Error> {
        let value = self.evaluate_value(tokens)?.to_integer()?;
        Ok(BasicInteger::with_mode(self.mode, value)?.value())
    }

    /// Evaluate an expression starting at `pos` and return the value plus the
    /// index of the first token after the expression.
    fn evaluate_value_at(
        &mut self,
        tokens: &[TokenInstance],
        pos: usize,
    ) -> Result<(Value, usize), Error> {
        self.evaluate_value_at_column(tokens, pos, self.output_column)
    }

    fn evaluate_value_at_column(
        &mut self,
        tokens: &[TokenInstance],
        pos: usize,
        output_column: usize,
    ) -> Result<(Value, usize), Error> {
        self.validate_type_field_references(&tokens[pos..])?;
        if expression_queries_graphics(&tokens[pos..]) {
            self.graphics.rasterize_if_dirty()?;
        }
        let uses_sadd = expression_uses_sadd(&tokens[pos..]);
        let mut scoped_vars = if !self.procedure_stack.is_empty() {
            Some(self.procedure_visible_variables()?)
        } else if uses_sadd {
            Some(self.vars.clone())
        } else {
            None
        };
        if uses_sadd {
            self.materialize_sadd_addresses(
                &tokens[pos..],
                scoped_vars
                    .as_mut()
                    .expect("SADD evaluation owns a variable snapshot"),
            )?;
        }
        let session_clock = self.current_session_time();
        let variables = scoped_vars.as_ref().unwrap_or(&self.vars);
        let (value, consumed) = eval::evaluate_prefix_with_user_functions(
            self.mode,
            &tokens[pos..],
            variables,
            &mut self.arrays,
            self.max_string_bytes,
            &mut self.rng,
            eval::ExpressionRuntime::new(
                &self.user_functions,
                self.max_function_depth,
                output_column,
                self.storage.remaining_bytes(),
            )
            .with_cursor_row(self.cursor_row)
            .with_graph(&self.graph)
            .with_graphics(&self.graphics)
            .with_virtual_memory(&self.virtual_memory, self.memory_segment)
            .with_virtual_ports(&self.virtual_ports)
            .with_files(&self.files)
            .with_process_context(
                &self.command_line,
                &self.environment,
                &self.session_env,
                Some(&session_clock),
            )
            .with_system_services(&self.system_services, &self.usr_addresses),
        )?;
        Ok((value, pos + consumed))
    }

    fn materialize_sadd_addresses(
        &mut self,
        tokens: &[TokenInstance],
        variables: &mut Variables,
    ) -> Result<(), Error> {
        let mut position = 0usize;
        while position < tokens.len() {
            if !matches!(tokens.get(position), Some(TokenInstance::Ident(name)) if name == "SADD")
                || !matches!(tokens.get(position + 1), Some(TokenInstance::LParen))
            {
                position += 1;
                continue;
            }
            let Some(TokenInstance::Ident(name)) = tokens.get(position + 2) else {
                return Err(Error::syntax("SADD expects a string variable"));
            };
            if !is_string_variable(name) {
                return Err(Error::syntax("SADD expects a string variable"));
            }
            if !matches!(tokens.get(position + 3), Some(TokenInstance::RParen)) {
                return Err(Error::syntax("SADD expects exactly one string variable"));
            }
            let text = match variables.get(name) {
                Some(Value::String(text)) => text.clone(),
                None => String::new(),
                Some(_) => return Err(Error::TypeMismatch),
            };
            let bytes = basic_string_memory_bytes(&text);
            let required = bytes.len().checked_add(1).ok_or(Error::IllegalQuantity)?;
            let key = (self.memory_segment, name.clone());
            let allocation = match self.string_allocations.get(&key).copied() {
                Some(allocation) if allocation.capacity >= required => allocation,
                _ => {
                    let next = self
                        .next_string_addresses
                        .get(&self.memory_segment)
                        .copied()
                        .unwrap_or(0);
                    let end = next.checked_add(required).ok_or(Error::IllegalQuantity)?;
                    if end > 65_536 {
                        return Err(Error::IllegalQuantity);
                    }
                    self.next_string_addresses.insert(self.memory_segment, end);
                    let allocation = StringAllocation {
                        address: next,
                        capacity: required,
                    };
                    self.string_allocations.insert(key, allocation);
                    allocation
                }
            };

            let physical = self
                .memory_segment
                .checked_mul(16)
                .and_then(|base| base.checked_add(allocation.address))
                .ok_or(Error::IllegalQuantity)?;
            let physical_end = physical
                .checked_add(allocation.capacity)
                .ok_or(Error::IllegalQuantity)?;
            let destination = self
                .virtual_memory
                .get_mut(physical..physical_end)
                .ok_or(Error::IllegalQuantity)?;
            destination.fill(0);
            destination[..bytes.len()].copy_from_slice(&bytes);
            variables.insert(
                eval::sadd_address_key(name),
                Value::Integer(allocation.address as i64),
            );
            position += 4;
        }
        Ok(())
    }

    fn validate_type_field_references(&self, tokens: &[TokenInstance]) -> Result<(), Error> {
        if let Some(name) = tokens.iter().find_map(|token| match token {
            TokenInstance::Ident(name)
                if name.contains('.') && !self.declared_value_types.contains_key(name) =>
            {
                Some(name)
            }
            _ => None,
        }) {
            return Err(Error::syntax(format!("undefined TYPE field {name}")));
        }
        Ok(())
    }
}

fn expression_queries_graphics(tokens: &[TokenInstance]) -> bool {
    tokens.windows(2).any(|tokens| {
        matches!(&tokens[0], TokenInstance::Ident(name) if matches!(name.as_str(), "POINT" | "SCRN"))
            && matches!(tokens[1], TokenInstance::LParen)
    })
}

fn expression_uses_sadd(tokens: &[TokenInstance]) -> bool {
    tokens.windows(2).any(|tokens| {
        matches!(&tokens[0], TokenInstance::Ident(name) if name == "SADD")
            && matches!(tokens[1], TokenInstance::LParen)
    })
}

fn basic_string_memory_bytes(text: &str) -> Vec<u8> {
    let mut bytes = Vec::with_capacity(text.len());
    for character in text.chars() {
        let code = u32::from(character);
        if let Ok(byte) = u8::try_from(code) {
            bytes.push(byte);
        } else {
            let mut encoded = [0u8; 4];
            bytes.extend_from_slice(character.encode_utf8(&mut encoded).as_bytes());
        }
    }
    bytes
}

pub(crate) fn is_graphics_statement(name: &str) -> bool {
    matches!(
        name,
        "SCREEN"
            | "CLS"
            | "COLOR"
            | "PALETTE"
            | "PSET"
            | "PRESET"
            | "LINE"
            | "BRUSH"
            | "RECT"
            | "RECTANGLE"
            | "CIRCLE"
            | "ELLIPSE"
            | "OVAL"
            | "PAINT"
            | "MOVE"
            | "DRAWTO"
            | "DRAW"
            | "POLYGON"
            | "GRADIENT"
            | "RADIALGRADIENT"
            | "ARC"
            | "BEZIER"
            | "ROUNDEDRECT"
            | "OPACITY"
            | "BLEND"
            | "TRANSLATE"
            | "ROTATE"
            | "SCALE"
            | "NGON"
            | "STAR"
            | "PATH"
            | "BITMAP"
            | "PERSPECTIVE"
            | "OBJECT"
            | "LIGHT"
            | "DEPTHGRID"
            | "DEPTHPERCEPTION"
            | "GRIDON"
            | "GRIDOFF"
            | "GRIDPOINT"
            | "LAYER"
            | "BEGINLAYER"
            | "ENDLAYER"
            | "GROUP"
            | "BEGINGROUP"
            | "ENDGROUP"
            | "TEXT"
            | "SPRITE"
            | "BLIT"
            | "MOVESPRITE"
            | "SPRITEMOTION"
            | "ADVANCESPRITES"
            | "BUFFER"
            | "FLIP"
            | "FRAME"
            | "SCREENSHOT"
            | "FLIPBOOK"
            | "VIDEO"
            | "SAVEIMAGE"
            | "RENDER"
            | "DISPLAY"
    )
}

fn is_synth_statement(name: &str) -> bool {
    matches!(
        name,
        "SYNTHPROFILE"
            | "VOICES"
            | "OSCILLATORS"
            | "TEMPO"
            | "VOICE"
            | "WAVEFORM"
            | "WAVE"
            | "OSCILLATOR"
            | "WAVEFILE"
            | "ADSR"
            | "ENVELOPE"
            | "VOL"
            | "PULSEWIDTH"
            | "STEREO"
            | "MIXER"
            | "PAN"
            | "FILTER"
            | "FILTERADSR"
            | "LFO"
            | "GLIDE"
            | "DRIVE"
            | "EXPRESSION"
            | "MODULATION"
            | "SUSTAIN"
            | "PITCHBEND"
            | "REVERB"
            | "CHORUS"
            | "DSP"
            | "PLAY"
            | "SAY"
            | "SING"
            | "SOUND"
            | "BEEP"
            | "INSTRUMENT"
            | "SOUNDFONT"
    )
}

fn is_ti_graph_statement(name: &str) -> bool {
    matches!(
        name,
        "CLRDRAW"
            | "DISPGRAPH"
            | "ZSTANDARD"
            | "ZTRIG"
            | "ZDECIMAL"
            | "ZSQUARE"
            | "AXESON"
            | "AXESOFF"
            | "GRIDON"
            | "GRIDOFF"
            | "LABELON"
            | "LABELOFF"
            | "COORDON"
            | "COORDOFF"
            | "GLINE"
            | "HORIZONTAL"
            | "VERTICAL"
            | "GCIRCLE"
            | "DRAWF"
            | "DRAWINV"
            | "TANGENT"
            | "SHADE"
            | "FNON"
            | "FNOFF"
            | "GRAPHSTYLE"
            | "PXL-ON"
            | "PXL-OFF"
            | "PXL-CHANGE"
            | "PT-ON"
            | "PT-OFF"
            | "PT-CHANGE"
            | "GTEXT"
    )
}

fn is_ti_equation_variable(name: &str) -> bool {
    matches!(
        name,
        "Y0" | "Y1" | "Y2" | "Y3" | "Y4" | "Y5" | "Y6" | "Y7" | "Y8" | "Y9"
    )
}

fn token_command_word(token: &TokenInstance) -> Option<&str> {
    match token {
        TokenInstance::Ident(name) => Some(name.as_str()),
        TokenInstance::Keyword(token) => Some(token.to_text().trim_end_matches('(')),
        _ => None,
    }
}

fn literal_asset_string(
    tokens: &[TokenInstance],
    line_number: u64,
    description: &str,
) -> Result<String, Error> {
    match tokens {
        [TokenInstance::String(value)] => Ok(value.clone()),
        [TokenInstance::Number(_) | TokenInstance::Real(_)] => Err(Error::TypeMismatch),
        _ => Err(Error::syntax(format!(
            "line {line_number}: stored {description} must be a string literal so LOAD can prepare it"
        ))),
    }
}

fn literal_asset_integer(
    tokens: &[TokenInstance],
    line_number: u64,
    description: &str,
) -> Result<i64, Error> {
    match tokens {
        [TokenInstance::Number(value)] => Ok(*value),
        _ => Err(Error::syntax(format!(
            "line {line_number}: stored {description} must be an integer literal so LOAD can prepare it"
        ))),
    }
}

fn parse_graphics_coordinate(
    tokens: &[TokenInstance],
    start: usize,
) -> Result<(Vec<&[TokenInstance]>, usize), Error> {
    if !matches!(tokens.get(start), Some(TokenInstance::LParen)) {
        return Err(Error::syntax("graphics coordinate requires parentheses"));
    }
    let mut depth = 0usize;
    for index in start..tokens.len() {
        match &tokens[index] {
            TokenInstance::LParen => depth = depth.saturating_add(1),
            TokenInstance::RParen => {
                depth = depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched closing graphics coordinate"))?;
                if depth == 0 {
                    let coordinates = split_graph_arguments(&tokens[start + 1..index])?;
                    if coordinates.iter().any(|coordinate| coordinate.is_empty()) {
                        return Err(Error::syntax("graphics coordinate cannot be empty"));
                    }
                    return Ok((coordinates, index + 1));
                }
            }
            _ => {}
        }
    }
    Err(Error::syntax("unterminated graphics coordinate"))
}

fn parse_graphics_point(
    tokens: &[TokenInstance],
    start: usize,
) -> Result<(&[TokenInstance], &[TokenInstance], usize), Error> {
    let (coordinates, after) = parse_graphics_coordinate(tokens, start)?;
    let [x, y] = coordinates.as_slice() else {
        return Err(Error::syntax("graphics coordinate requires exactly x,y"));
    };
    Ok((*x, *y, after))
}

fn parse_complete_graphics_xyz(tokens: &[TokenInstance]) -> Result<[&[TokenInstance]; 3], Error> {
    let (coordinates, after) = parse_graphics_coordinate(tokens, 0)?;
    if after != tokens.len() {
        return Err(Error::syntax(
            "XYZ coordinate must be one parenthesized value",
        ));
    }
    let [x, y, z] = coordinates.as_slice() else {
        return Err(Error::syntax("XYZ coordinate requires exactly x,y,z"));
    };
    Ok([*x, *y, *z])
}

fn graphics_tail_arguments(
    tokens: &[TokenInstance],
    after: usize,
) -> Result<Vec<&[TokenInstance]>, Error> {
    if after == tokens.len() {
        return Ok(Vec::new());
    }
    if !matches!(tokens.get(after), Some(TokenInstance::Comma)) {
        return Err(Error::syntax("expected ',' after graphics coordinate"));
    }
    split_graph_arguments(&tokens[after + 1..])
}

fn graphics_mode_word(tokens: &[TokenInstance]) -> Option<&str> {
    match tokens {
        [TokenInstance::Ident(word)] | [TokenInstance::String(word)] => Some(word.as_str()),
        [TokenInstance::Keyword(token)] => Some(token.to_text().trim_end_matches('(')),
        _ => None,
    }
}

fn graphics_array_name<'a>(tokens: &'a [TokenInstance], statement: &str) -> Result<&'a str, Error> {
    match tokens {
        [TokenInstance::Ident(name)]
        | [TokenInstance::Ident(name), TokenInstance::LParen, TokenInstance::RParen] => Ok(name),
        _ => Err(Error::syntax(format!(
            "graphics {statement} requires a bare array name"
        ))),
    }
}

fn starts_graphics_point(tokens: &[TokenInstance]) -> bool {
    parse_graphics_point(tokens, 0).is_ok()
}

fn starts_graphics_get(tokens: &[TokenInstance]) -> bool {
    let Ok((_, _, after_first)) = parse_graphics_point(tokens, 0) else {
        return false;
    };
    matches!(
        tokens.get(after_first),
        Some(TokenInstance::Keyword(Token::Minus))
    ) && parse_graphics_point(tokens, after_first + 1).is_ok()
}

fn parse_draw_optional_number(bytes: &[u8], position: &mut usize) -> Result<Option<f64>, Error> {
    while *position < bytes.len() && bytes[*position].is_ascii_whitespace() {
        *position += 1;
    }
    if *position >= bytes.len()
        || (!bytes[*position].is_ascii_digit() && !matches!(bytes[*position], b'+' | b'-' | b'.'))
    {
        return Ok(None);
    }
    parse_draw_number(bytes, position).map(Some)
}

fn parse_draw_number(bytes: &[u8], position: &mut usize) -> Result<f64, Error> {
    while *position < bytes.len() && bytes[*position].is_ascii_whitespace() {
        *position += 1;
    }
    let start = *position;
    if *position < bytes.len() && matches!(bytes[*position], b'+' | b'-') {
        *position += 1;
    }
    let mut digits = false;
    while *position < bytes.len() && bytes[*position].is_ascii_digit() {
        digits = true;
        *position += 1;
    }
    if *position < bytes.len() && bytes[*position] == b'.' {
        *position += 1;
        while *position < bytes.len() && bytes[*position].is_ascii_digit() {
            digits = true;
            *position += 1;
        }
    }
    if !digits {
        return Err(Error::syntax("DRAW command requires a number"));
    }
    let text = std::str::from_utf8(&bytes[start..*position])
        .map_err(|_| Error::syntax("DRAW command contains invalid text"))?;
    let value = text
        .parse::<f64>()
        .map_err(|_| Error::syntax("DRAW command contains an invalid number"))?;
    if !value.is_finite() {
        return Err(Error::RealOverflow);
    }
    Ok(value)
}

fn parse_draw_integer(bytes: &[u8], position: &mut usize) -> Result<i64, Error> {
    let value = parse_draw_number(bytes, position)?;
    if value.fract() != 0.0 || value < i64::MIN as f64 || value > i64::MAX as f64 {
        return Err(Error::IllegalQuantity);
    }
    Ok(value as i64)
}

fn parse_draw_identifier(bytes: &[u8], position: &mut usize) -> Result<String, Error> {
    while *position < bytes.len() && bytes[*position].is_ascii_whitespace() {
        *position += 1;
    }
    let start = *position;
    if *position >= bytes.len()
        || (!bytes[*position].is_ascii_alphabetic() && bytes[*position] != b'_')
    {
        return Err(Error::syntax("DRAW X requires a string variable"));
    }
    *position += 1;
    while *position < bytes.len()
        && (bytes[*position].is_ascii_alphanumeric()
            || matches!(bytes[*position], b'_' | b'$' | b'%' | b'&' | b'!' | b'#'))
    {
        *position += 1;
    }
    let name = std::str::from_utf8(&bytes[start..*position])
        .map_err(|_| Error::syntax("DRAW X variable name is invalid"))?;
    Ok(name.to_ascii_uppercase())
}

fn parse_mml_optional_number(bytes: &[u8], position: &mut usize) -> Result<Option<u16>, Error> {
    let start = *position;
    while *position < bytes.len() && bytes[*position].is_ascii_digit() {
        *position += 1;
    }
    if start == *position {
        return Ok(None);
    }
    let text = std::str::from_utf8(&bytes[start..*position])
        .map_err(|_| Error::syntax("PLAY MML contains invalid numeric text"))?;
    text.parse::<u16>()
        .map(Some)
        .map_err(|_| Error::IllegalQuantity)
}

fn parse_mml_number(bytes: &[u8], position: &mut usize) -> Result<u16, Error> {
    parse_mml_optional_number(bytes, position)?
        .ok_or_else(|| Error::syntax("PLAY MML command requires a number"))
}

fn parse_mml_identifier(bytes: &[u8], position: &mut usize) -> Result<String, Error> {
    while *position < bytes.len() && bytes[*position].is_ascii_whitespace() {
        *position += 1;
    }
    let start = *position;
    if *position >= bytes.len()
        || (!bytes[*position].is_ascii_alphabetic() && bytes[*position] != b'_')
    {
        return Err(Error::syntax("PLAY MML X requires a string variable"));
    }
    *position += 1;
    while *position < bytes.len()
        && (bytes[*position].is_ascii_alphanumeric()
            || matches!(bytes[*position], b'_' | b'$' | b'%' | b'&' | b'!' | b'#'))
    {
        *position += 1;
    }
    let name = std::str::from_utf8(&bytes[start..*position])
        .map_err(|_| Error::syntax("PLAY MML X variable name is invalid"))?;
    Ok(name.to_ascii_uppercase())
}

fn synth_word(tokens: &[TokenInstance], interpreter: &mut Interpreter) -> Result<String, Error> {
    match tokens {
        [TokenInstance::Ident(word)] => Ok(word.clone()),
        [TokenInstance::Keyword(token)] => Ok(token.to_text().trim_end_matches('(').to_string()),
        _ => interpreter
            .evaluate_value(tokens)?
            .into_string()
            .ok_or(Error::TypeMismatch),
    }
}

fn normalized_midi_level(value: f64) -> Result<u8, Error> {
    if !value.is_finite() || !(0.0..=1.0).contains(&value) {
        return Err(Error::IllegalQuantity);
    }
    Ok((value * 127.0).round() as u8)
}

fn normalized_midi_pitch_bend(value: f64) -> Result<u16, Error> {
    if !value.is_finite() || !(-1.0..=1.0).contains(&value) {
        return Err(Error::IllegalQuantity);
    }
    let bend = if value < 0.0 {
        8_192.0 + value * 8_192.0
    } else {
        8_192.0 + value * 8_191.0
    };
    Ok(bend.round() as u16)
}

/// Convert a numeric waveform id to its string name.
/// 0=triangle, 1=saw, 2=pulse, 3=sine, 4=noise.
fn waveform_from_numeric(n: i64) -> Result<String, Error> {
    match n {
        0 => Ok("TRIANGLE".to_string()),
        1 => Ok("SAW".to_string()),
        2 => Ok("PULSE".to_string()),
        3 => Ok("SINE".to_string()),
        4 => Ok("NOISE".to_string()),
        _ => Err(Error::IllegalQuantity),
    }
}

fn parse_wave_samples(text: &str) -> Result<Vec<f64>, Error> {
    let samples = text
        .split(|character: char| character == ',' || character == ';' || character.is_whitespace())
        .filter(|sample| !sample.is_empty())
        .map(|sample| {
            sample
                .parse::<f64>()
                .map_err(|_| Error::syntax("WAVE samples must be numbers from -1 to 1"))
        })
        .collect::<Result<Vec<_>, _>>()?;
    if samples.len() < 2
        || samples.len() > 65_536
        || samples
            .iter()
            .any(|sample| !sample.is_finite() || !(-1.0..=1.0).contains(sample))
    {
        return Err(Error::IllegalQuantity);
    }
    Ok(samples)
}

fn split_write_items(tokens: &[TokenInstance]) -> Result<Vec<&[TokenInstance]>, Error> {
    if tokens.is_empty() {
        return Ok(Vec::new());
    }
    let mut items = Vec::new();
    let mut start = 0usize;
    let mut paren_depth = 0usize;
    let mut brace_depth = 0usize;
    for (index, token) in tokens.iter().enumerate() {
        match token {
            TokenInstance::LParen => paren_depth = paren_depth.saturating_add(1),
            TokenInstance::RParen => {
                paren_depth = paren_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched ')' in WRITE"))?;
            }
            TokenInstance::LBrace => brace_depth = brace_depth.saturating_add(1),
            TokenInstance::RBrace => {
                brace_depth = brace_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched '}' in WRITE"))?;
            }
            TokenInstance::Comma | TokenInstance::Semicolon
                if paren_depth == 0 && brace_depth == 0 =>
            {
                items.push(&tokens[start..index]);
                start = index + 1;
            }
            _ => {}
        }
    }
    if paren_depth != 0 || brace_depth != 0 {
        return Err(Error::syntax("unclosed expression in WRITE"));
    }
    items.push(&tokens[start..]);
    Ok(items)
}

fn split_graph_arguments(tokens: &[TokenInstance]) -> Result<Vec<&[TokenInstance]>, Error> {
    // A leading parenthesis is not necessarily a wrapper around the complete
    // argument list. Microsoft-style graphics statements commonly begin with
    // a coordinate such as `(x,y)`, and POLYGON begins with several of them.
    // Strip parentheses only when the first opening parenthesis matches the
    // final token; otherwise retain the complete token slice and let the
    // depth-aware comma splitter preserve each coordinate expression.
    let inside = if matches!(tokens.first(), Some(TokenInstance::LParen)) {
        let mut depth = 0usize;
        let mut matching_close = None;
        for (index, token) in tokens.iter().enumerate() {
            match token {
                TokenInstance::LParen => depth = depth.saturating_add(1),
                TokenInstance::RParen => {
                    depth = depth
                        .checked_sub(1)
                        .ok_or_else(|| Error::syntax("unmatched ')' in graphics command"))?;
                    if depth == 0 {
                        matching_close = Some(index);
                        break;
                    }
                }
                _ => {}
            }
        }
        match matching_close {
            Some(index) if index == tokens.len() - 1 => &tokens[1..index],
            Some(_) => tokens,
            None => return Err(Error::syntax("unterminated graphics command arguments")),
        }
    } else {
        tokens
    };
    if inside.is_empty() {
        return Ok(Vec::new());
    }

    let mut arguments = Vec::new();
    let mut start = 0usize;
    let mut paren_depth = 0usize;
    let mut brace_depth = 0usize;
    for (index, token) in inside.iter().enumerate() {
        match token {
            TokenInstance::LParen => paren_depth = paren_depth.saturating_add(1),
            TokenInstance::RParen => {
                paren_depth = paren_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched ')' in graphics command"))?;
            }
            TokenInstance::LBrace => brace_depth = brace_depth.saturating_add(1),
            TokenInstance::RBrace => {
                brace_depth = brace_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched '}' in graphics command"))?;
            }
            TokenInstance::Comma if paren_depth == 0 && brace_depth == 0 => {
                if start == index {
                    return Err(Error::syntax("empty graphics command argument"));
                }
                arguments.push(&inside[start..index]);
                start = index + 1;
            }
            _ => {}
        }
    }
    if paren_depth != 0 || brace_depth != 0 {
        return Err(Error::syntax("unclosed graphics command expression"));
    }
    if start == inside.len() {
        return Err(Error::syntax("empty graphics command argument"));
    }
    arguments.push(&inside[start..]);
    Ok(arguments)
}

fn split_optional_arguments<'a>(
    tokens: &'a [TokenInstance],
    statement: &str,
) -> Result<Vec<&'a [TokenInstance]>, Error> {
    if tokens.is_empty() {
        return Ok(Vec::new());
    }
    let mut arguments = Vec::new();
    let mut start = 0usize;
    let mut paren_depth = 0usize;
    let mut brace_depth = 0usize;
    for (index, token) in tokens.iter().enumerate() {
        match token {
            TokenInstance::LParen => paren_depth = paren_depth.saturating_add(1),
            TokenInstance::RParen => {
                paren_depth = paren_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax(format!("unmatched ')' in {statement}")))?;
            }
            TokenInstance::LBrace => brace_depth = brace_depth.saturating_add(1),
            TokenInstance::RBrace => {
                brace_depth = brace_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax(format!("unmatched '}}' in {statement}")))?;
            }
            TokenInstance::Comma if paren_depth == 0 && brace_depth == 0 => {
                arguments.push(&tokens[start..index]);
                start = index + 1;
            }
            _ => {}
        }
    }
    if paren_depth != 0 || brace_depth != 0 {
        return Err(Error::syntax(format!("unclosed expression in {statement}")));
    }
    arguments.push(&tokens[start..]);
    Ok(arguments)
}

fn expect_graph_arity(
    name: &str,
    arguments: &[&[TokenInstance]],
    minimum: usize,
    maximum: usize,
) -> Result<(), Error> {
    if (minimum..=maximum).contains(&arguments.len()) {
        Ok(())
    } else {
        Err(Error::syntax(format!(
            "{name} expects {minimum}..={maximum} arguments, got {}",
            arguments.len()
        )))
    }
}

fn graph_real(value: Value) -> Result<f64, Error> {
    match value {
        Value::Integer(value) => Ok(BasicReal::from_integer(value)?.value()),
        Value::Real(value) => Ok(value.value()),
        Value::Complex(value) if value.is_real() => Ok(value.real().value()),
        Value::Complex(_) | Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn graph_variable(vars: &Variables, name: &str, fallback: f64) -> Result<f64, Error> {
    vars.get(name)
        .cloned()
        .map(graph_real)
        .unwrap_or(Ok(fallback))
}

fn graph_system_variables(graph: &TiGraphState) -> Result<Variables, Error> {
    let mut variables = Variables::new();
    install_graph_system_variables(&mut variables, graph)?;
    Ok(variables)
}

fn is_runtime_system_scalar(name: &str) -> bool {
    name.starts_with("__")
        || matches!(
            name,
            "ERR" | "ERL" | "DET" | "NUM" | "XMIN" | "XMAX" | "XSCL" | "YMIN" | "YMAX" | "YSCL"
        )
}

fn procedure_scope_contains(names: &HashSet<String>, name: &str) -> bool {
    names.contains(name)
        || name
            .split_once('.')
            .is_some_and(|(record, _)| names.contains(record))
}

fn install_graph_system_variables(
    variables: &mut Variables,
    graph: &TiGraphState,
) -> Result<(), Error> {
    for (name, value) in [
        ("XMIN", graph.x_min),
        ("XMAX", graph.x_max),
        ("XSCL", graph.x_scale),
        ("YMIN", graph.y_min),
        ("YMAX", graph.y_max),
        ("YSCL", graph.y_scale),
    ] {
        variables.insert(name.into(), Value::Real(BasicReal::new(value)?));
    }
    Ok(())
}

/// Flatten a program into executable statement entries and a line-number lookup.
fn build_statements(program: &Program) -> (Vec<Statement>, BTreeMap<u64, usize>) {
    let mut statements = Vec::new();
    let mut line_first = BTreeMap::new();

    for (&line_number, body) in program.iter() {
        let first_idx = statements.len();
        let split = split_line_statements(line_number, body);
        line_first.insert(line_number, first_idx);
        statements.extend(split);
    }

    (statements, line_first)
}

/// Split a line body on [`TokenInstance::Colon`], preserving empty segments.
///
/// Because `REM` text and quoted strings keep their colons inside opaque
/// token variants, this only sees statement-separator colons.
fn split_line_statements(line_number: u64, body: &[TokenInstance]) -> Vec<Statement> {
    let mut statements = Vec::new();
    let mut start = 0;

    for (i, tok) in body.iter().enumerate() {
        if matches!(tok, TokenInstance::Colon) {
            statements.push(Statement {
                line_number,
                body: body[start..i].to_vec(),
            });
            start = i + 1;
        }
    }

    statements.push(Statement {
        line_number,
        body: body[start..].to_vec(),
    });

    expand_inline_else(statements)
}
fn expand_inline_else(statements: Vec<Statement>) -> Vec<Statement> {
    let has_if = statements.iter().any(|statement| {
        matches!(
            statement.body.first(),
            Some(TokenInstance::Keyword(Token::If))
        )
    });
    let mut expanded = Vec::new();

    for statement in statements {
        let starts_else = is_ident_statement(&statement, "ELSE");
        let is_case_else = is_ident_statement(&statement, "CASE");
        if is_case_else || (!has_if && !starts_else) {
            expanded.push(statement);
            continue;
        }

        let positions = statement
            .body
            .iter()
            .enumerate()
            .filter_map(|(index, token)| {
                matches!(token, TokenInstance::Ident(name) if name == "ELSE").then_some(index)
            })
            .collect::<Vec<_>>();
        if positions.is_empty() {
            expanded.push(statement);
            continue;
        }

        let mut start = 0;
        for position in positions {
            if position > start {
                expanded.push(Statement {
                    line_number: statement.line_number,
                    body: statement.body[start..position].to_vec(),
                });
            }
            expanded.push(Statement {
                line_number: statement.line_number,
                body: vec![TokenInstance::Ident("ELSE".to_string())],
            });
            start = position + 1;
        }
        if start < statement.body.len() {
            let mut body = statement.body[start..].to_vec();
            if matches!(body.first(), Some(TokenInstance::Number(_))) {
                body.insert(0, TokenInstance::Keyword(Token::Goto));
            }
            expanded.push(Statement {
                line_number: statement.line_number,
                body,
            });
        }
    }

    expanded
}

#[derive(Debug, Clone, Copy)]
enum CaseRelation {
    Equal,
    NotEqual,
    Less,
    LessEqual,
    Greater,
    GreaterEqual,
}

fn parse_case_relation(tokens: &[TokenInstance]) -> Option<(CaseRelation, usize)> {
    use CaseRelation::*;
    match (tokens.first(), tokens.get(1)) {
        (Some(TokenInstance::Keyword(Token::Less)), Some(TokenInstance::Keyword(Token::Equal))) => {
            Some((LessEqual, 2))
        }
        (
            Some(TokenInstance::Keyword(Token::Less)),
            Some(TokenInstance::Keyword(Token::Greater)),
        ) => Some((NotEqual, 2)),
        (
            Some(TokenInstance::Keyword(Token::Greater)),
            Some(TokenInstance::Keyword(Token::Equal)),
        ) => Some((GreaterEqual, 2)),
        (Some(TokenInstance::Keyword(Token::Equal)), _) => Some((Equal, 1)),
        (Some(TokenInstance::Keyword(Token::Less)), _) => Some((Less, 1)),
        (Some(TokenInstance::Keyword(Token::Greater)), _) => Some((Greater, 1)),
        _ => None,
    }
}

fn case_relation_matches(ordering: std::cmp::Ordering, relation: CaseRelation) -> bool {
    match relation {
        CaseRelation::Equal => ordering.is_eq(),
        CaseRelation::NotEqual => !ordering.is_eq(),
        CaseRelation::Less => ordering.is_lt(),
        CaseRelation::LessEqual => !ordering.is_gt(),
        CaseRelation::Greater => ordering.is_gt(),
        CaseRelation::GreaterEqual => !ordering.is_lt(),
    }
}

fn is_bbc_case_start(statement: &Statement) -> bool {
    statement.body.len() >= 3
        && matches!(
            statement.body.first(),
            Some(TokenInstance::Ident(name)) if name == "CASE"
        )
        && matches!(
            statement.body.last(),
            Some(TokenInstance::Ident(name)) if name == "OF"
        )
}

fn is_select_start(statement: &Statement) -> bool {
    matches!(
        statement.body.first(),
        Some(TokenInstance::Ident(name)) if name == "SELECT"
    ) || is_bbc_case_start(statement)
}

fn is_select_end(statement: &Statement) -> bool {
    matches!(
        statement.body.as_slice(),
        [TokenInstance::Keyword(Token::End), TokenInstance::Ident(name)]
            if matches!(name.as_str(), "SELECT" | "CASE")
    ) || matches!(
        statement.body.as_slice(),
        [TokenInstance::Ident(name)]
            if matches!(name.as_str(), "ENDSELECT" | "ENDCASE" | "CEND")
    )
}

fn is_case_branch(statement: &Statement) -> bool {
    if is_bbc_case_start(statement) {
        return false;
    }
    matches!(
        statement.body.first(),
        Some(TokenInstance::Ident(name))
            if matches!(name.as_str(), "CASE" | "WHEN" | "OTHERWISE")
    )
}

fn is_default_case(statement: &Statement) -> bool {
    matches!(
        statement.body.as_slice(),
        [TokenInstance::Ident(name)] if name == "OTHERWISE"
    ) || matches!(
        statement.body.as_slice(),
        [TokenInstance::Ident(name), TokenInstance::Ident(alternate)]
            if matches!(name.as_str(), "CASE" | "WHEN") && alternate == "ELSE"
    )
}

fn select_expression(body: &[TokenInstance]) -> Result<&[TokenInstance], Error> {
    let expression = match body.first() {
        Some(TokenInstance::Ident(name)) if name == "SELECT" => {
            let rest = &body[1..];
            if matches!(rest.first(), Some(TokenInstance::Ident(name)) if name == "CASE") {
                &rest[1..]
            } else {
                rest
            }
        }
        Some(TokenInstance::Ident(name))
            if name == "CASE"
                && matches!(body.last(), Some(TokenInstance::Ident(of)) if of == "OF") =>
        {
            &body[1..body.len() - 1]
        }
        _ => return Err(Error::syntax("invalid SELECT/CASE start")),
    };
    if expression.is_empty() {
        return Err(Error::syntax("SELECT/CASE requires an expression"));
    }
    Ok(expression)
}

fn split_case_items(tokens: &[TokenInstance]) -> Result<Vec<&[TokenInstance]>, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax("CASE requires a value"));
    }
    let mut items = Vec::new();
    let mut start = 0usize;
    let mut paren_depth = 0usize;
    let mut brace_depth = 0usize;
    for (index, token) in tokens.iter().enumerate() {
        match token {
            TokenInstance::LParen => paren_depth = paren_depth.saturating_add(1),
            TokenInstance::RParen => {
                paren_depth = paren_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched ')' in CASE"))?;
            }
            TokenInstance::LBrace => brace_depth = brace_depth.saturating_add(1),
            TokenInstance::RBrace => {
                brace_depth = brace_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched '}' in CASE"))?;
            }
            TokenInstance::Comma if paren_depth == 0 && brace_depth == 0 => {
                if start == index {
                    return Err(Error::syntax("empty CASE item"));
                }
                items.push(&tokens[start..index]);
                start = index + 1;
            }
            _ => {}
        }
    }
    if paren_depth != 0 || brace_depth != 0 {
        return Err(Error::syntax("unclosed expression in CASE"));
    }
    if start == tokens.len() {
        return Err(Error::syntax("empty CASE item"));
    }
    items.push(&tokens[start..]);
    Ok(items)
}

fn top_level_case_to(tokens: &[TokenInstance]) -> Result<Option<usize>, Error> {
    let mut found = None;
    let mut paren_depth = 0usize;
    let mut brace_depth = 0usize;
    for (index, token) in tokens.iter().enumerate() {
        match token {
            TokenInstance::LParen => paren_depth = paren_depth.saturating_add(1),
            TokenInstance::RParen => {
                paren_depth = paren_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched ')' in CASE range"))?;
            }
            TokenInstance::LBrace => brace_depth = brace_depth.saturating_add(1),
            TokenInstance::RBrace => {
                brace_depth = brace_depth
                    .checked_sub(1)
                    .ok_or_else(|| Error::syntax("unmatched '}' in CASE range"))?;
            }
            TokenInstance::Keyword(Token::To) if paren_depth == 0 && brace_depth == 0 => {
                if found.replace(index).is_some() {
                    return Err(Error::syntax("CASE range has more than one TO"));
                }
            }
            _ => {}
        }
    }
    if paren_depth != 0 || brace_depth != 0 {
        return Err(Error::syntax("unclosed expression in CASE range"));
    }
    Ok(found)
}
fn is_ident_statement(statement: &Statement, name: &str) -> bool {
    matches!(
        statement.body.first(),
        Some(TokenInstance::Ident(statement_name)) if statement_name == name
    )
}

fn inline_else_after(statements: &[Statement], pc: usize) -> Option<usize> {
    let line_number = statements.get(pc)?.line_number;
    statements
        .iter()
        .enumerate()
        .skip(pc + 1)
        .take_while(|(_, statement)| statement.line_number == line_number)
        .find_map(|(index, statement)| is_ident_statement(statement, "ELSE").then_some(index))
}
fn is_block_if(statement: &Statement) -> bool {
    matches!(
        statement.body.first(),
        Some(TokenInstance::Keyword(Token::If))
    ) && matches!(
        statement.body.last(),
        Some(TokenInstance::Keyword(Token::Then))
    )
}

fn is_block_if_end(statement: &Statement) -> bool {
    matches!(
        statement.body.as_slice(),
        [TokenInstance::Ident(name)] if matches!(name.as_str(), "ENDIF" | "IFEND")
    ) || matches!(
        statement.body.as_slice(),
        [
            TokenInstance::Keyword(Token::End),
            TokenInstance::Keyword(Token::If)
        ]
    ) || matches!(
        statement.body.as_slice(),
        [
            TokenInstance::Keyword(Token::If),
            TokenInstance::Keyword(Token::End)
        ]
    )
}

fn is_inline_else(statements: &[Statement], else_pc: usize) -> bool {
    let Some(else_statement) = statements.get(else_pc) else {
        return false;
    };
    if !is_ident_statement(else_statement, "ELSE") {
        return false;
    }
    statements[..else_pc].iter().rev().any(|statement| {
        statement.line_number == else_statement.line_number
            && matches!(
                statement.body.first(),
                Some(TokenInstance::Keyword(Token::If))
            )
            && !is_block_if(statement)
    })
}

fn block_if_false_target(statements: &[Statement], if_pc: usize) -> Result<usize, Error> {
    let mut nested = 0usize;
    for (index, statement) in statements.iter().enumerate().skip(if_pc + 1) {
        if is_block_if(statement) {
            nested = nested.saturating_add(1);
        } else if is_block_if_end(statement) {
            if nested == 0 {
                return Ok(index + 1);
            }
            nested -= 1;
        } else if is_ident_statement(statement, "ELSE")
            && !is_inline_else(statements, index)
            && nested == 0
        {
            return Ok(index + 1);
        }
    }
    Err(Error::syntax("block IF without matching END IF"))
}

fn matching_block_if_end(statements: &[Statement], else_pc: usize) -> Result<usize, Error> {
    let mut nested = 0usize;
    for (index, statement) in statements.iter().enumerate().skip(else_pc + 1) {
        if is_block_if(statement) {
            nested = nested.saturating_add(1);
        } else if is_block_if_end(statement) {
            if nested == 0 {
                return Ok(index);
            }
            nested -= 1;
        }
    }
    Err(Error::syntax("ELSE without matching END IF"))
}

/// Return the first statement index after the physical line containing `pc`.
fn first_statement_after_line(statements: &[Statement], pc: usize) -> usize {
    let current_line = statements[pc].line_number;
    statements[pc + 1..]
        .iter()
        .position(|s| s.line_number != current_line)
        .map_or(statements.len(), |offset| pc + 1 + offset)
}

fn matching_wend(statements: &[Statement], while_pc: usize) -> Result<usize, Error> {
    let mut nested = 0usize;
    for (index, statement) in statements.iter().enumerate().skip(while_pc + 1) {
        match statement.body.first() {
            Some(TokenInstance::Keyword(Token::While)) => {
                nested = nested.saturating_add(1);
            }
            Some(TokenInstance::Keyword(Token::Wend)) if nested == 0 => return Ok(index),
            Some(TokenInstance::Keyword(Token::Wend)) => nested -= 1,
            _ => {}
        }
    }
    Err(Error::syntax("WHILE without matching WEND"))
}

/// Find the statement index of the NEXT matching the FOR at `for_pc`.
/// Handles nested FOR/NEXT and multi-variable NEXT (NEXT I, J).
fn matching_next(statements: &[Statement], for_pc: usize) -> Result<usize, Error> {
    let mut nested = 0usize;
    for (index, statement) in statements.iter().enumerate().skip(for_pc + 1) {
        match statement.body.first() {
            Some(TokenInstance::Keyword(Token::For)) => {
                nested = nested.saturating_add(1);
            }
            Some(TokenInstance::Keyword(Token::Next)) => {
                if nested == 0 {
                    return Ok(index);
                }
                // NEXT with multiple variables (NEXT I, J) pops multiple frames.
                let var_count = parse_next_variables(&statement.body[1..])
                    .map(|v| v.len())
                    .unwrap_or(1);
                nested = nested.saturating_sub(var_count);
                if nested == 0 && var_count > 0 {
                    return Ok(index);
                }
            }
            _ => {}
        }
    }
    Err(Error::syntax("FOR without matching NEXT"))
}

fn matching_loop(statements: &[Statement], do_pc: usize) -> Result<usize, Error> {
    let mut nested = 0usize;
    for (index, statement) in statements.iter().enumerate().skip(do_pc + 1) {
        if is_ident_statement(statement, "DO") {
            nested = nested.saturating_add(1);
        } else if is_ident_statement(statement, "LOOP") {
            if nested == 0 {
                return Ok(index);
            }
            nested -= 1;
        }
    }
    Err(Error::syntax("DO without matching LOOP"))
}
fn matching_loop_exit(
    statements: &[Statement],
    exit_pc: usize,
    kind: LoopExitKind,
) -> Result<usize, Error> {
    let mut nested = 0usize;
    for (index, statement) in statements.iter().enumerate().skip(exit_pc + 1) {
        let starts = match kind {
            LoopExitKind::Do => is_ident_statement(statement, "DO"),
            LoopExitKind::For => matches!(
                statement.body.first(),
                Some(TokenInstance::Keyword(Token::For))
            ),
            LoopExitKind::While => matches!(
                statement.body.first(),
                Some(TokenInstance::Keyword(Token::While))
            ),
            LoopExitKind::Repeat => is_ident_statement(statement, "REPEAT"),
        };
        if starts {
            nested = nested.saturating_add(1);
            continue;
        }
        let closes = match kind {
            LoopExitKind::Do if is_ident_statement(statement, "LOOP") => 1,
            LoopExitKind::For
                if matches!(
                    statement.body.first(),
                    Some(TokenInstance::Keyword(Token::Next))
                ) =>
            {
                statement
                    .body
                    .iter()
                    .filter(|token| matches!(token, TokenInstance::Comma))
                    .count()
                    .saturating_add(1)
            }
            LoopExitKind::While
                if matches!(
                    statement.body.first(),
                    Some(TokenInstance::Keyword(Token::Wend))
                ) =>
            {
                1
            }
            LoopExitKind::Repeat if is_ident_statement(statement, "UNTIL") => 1,
            _ => 0,
        };
        if closes > nested {
            return Ok(index);
        }
        nested -= closes;
    }
    Err(Error::syntax(format!(
        "EXIT {kind:?} without matching loop terminator"
    )))
}
fn matching_select_end(statements: &[Statement], branch_pc: usize) -> Result<usize, Error> {
    let mut nested = 0usize;
    for (index, statement) in statements.iter().enumerate().skip(branch_pc + 1) {
        if is_select_start(statement) {
            nested = nested.saturating_add(1);
        } else if is_select_end(statement) {
            if nested == 0 {
                return Ok(index);
            }
            nested -= 1;
        }
    }
    Err(Error::syntax("CASE/WHEN without matching SELECT end"))
}
fn validate_control_structures(statements: &[Statement]) -> Result<StructuredDefinitions, Error> {
    let subs = collect_sub_definitions(statements)?;
    let functions = collect_function_definitions(statements)?;
    let types = collect_type_definitions(statements)?;
    if let Some(name) = subs.keys().find(|name| functions.contains_key(*name)) {
        return Err(Error::syntax(format!(
            "structured declaration name {name} is used by both SUB and FUNCTION"
        )));
    }
    if let Some(name) = types
        .keys()
        .find(|name| subs.contains_key(*name) || functions.contains_key(*name))
    {
        return Err(Error::syntax(format!(
            "structured declaration name {name} is also used by a TYPE"
        )));
    }
    let definitions = StructuredDefinitions {
        subs,
        functions,
        types,
    };
    for definition in definitions
        .subs
        .values()
        .chain(definitions.functions.values())
    {
        for parameter in &definition.parameters {
            let Some(record_type) = &parameter.record_type else {
                continue;
            };
            if !definitions.types.contains_key(record_type) {
                return Err(Error::syntax(format!(
                    "line {}: undefined TYPE {record_type} in {} parameter {}",
                    statements[definition.start_pc].line_number, definition.name, parameter.name
                )));
            }
        }
    }
    let mut procedure_regions = definitions
        .subs
        .values()
        .chain(definitions.functions.values())
        .collect::<Vec<_>>();
    procedure_regions.sort_by_key(|definition| definition.start_pc);
    let mut declaration_ranges = procedure_regions
        .iter()
        .map(|definition| (definition.start_pc, definition.end_pc))
        .chain(
            definitions
                .types
                .values()
                .map(|definition| (definition.start_pc, definition.end_pc)),
        )
        .collect::<Vec<_>>();
    declaration_ranges.sort_unstable();
    if declaration_ranges
        .windows(2)
        .any(|pair| pair[1].0 <= pair[0].1)
    {
        return Err(Error::syntax(
            "SUB, FUNCTION, and TYPE declarations cannot be nested",
        ));
    }
    validate_procedure_declarations(statements, &definitions)?;

    for (pc, statement) in statements.iter().enumerate() {
        if let Some(TokenInstance::Ident(name)) = statement.body.first() {
            if matches!(name.as_str(), "SHARED" | "STATIC")
                && procedure_at_pc(&definitions, pc).is_none()
            {
                return Err(Error::syntax(format!(
                    "line {}: {name} is only valid inside SUB or FUNCTION",
                    statement.line_number
                )));
            }
        }
        if matches!(
            statement.body.first(),
            Some(TokenInstance::Keyword(Token::Dim))
        ) && matches!(statement.body.get(1), Some(TokenInstance::Ident(name)) if name == "SHARED")
            && procedure_at_pc(&definitions, pc).is_none()
        {
            return Err(Error::syntax(format!(
                "line {}: DIM SHARED is only valid inside SUB or FUNCTION",
                statement.line_number
            )));
        }
    }

    let main = statements
        .iter()
        .enumerate()
        .filter(|(pc, _)| {
            !declaration_ranges
                .iter()
                .any(|(start, end)| (*start..=*end).contains(pc))
        })
        .map(|(_, statement)| statement.clone())
        .collect::<Vec<_>>();
    validate_control_region(&main)?;
    for definition in procedure_regions {
        validate_control_region(&statements[definition.start_pc + 1..definition.end_pc])?;
    }
    Ok(definitions)
}

fn procedure_signatures_match(
    declared: &[ProcedureParameter],
    defined: &[ProcedureParameter],
) -> bool {
    declared.len() == defined.len()
        && declared.iter().zip(defined).all(|(declared, defined)| {
            declared.mode == defined.mode
                && declared.shape == defined.shape
                && declared.declaration == defined.declaration
                && declared.record_type == defined.record_type
        })
}

fn validate_procedure_declarations(
    statements: &[Statement],
    definitions: &StructuredDefinitions,
) -> Result<(), Error> {
    let mut declared = HashSet::new();
    for (pc, statement) in statements.iter().enumerate() {
        if !matches!(statement.body.first(), Some(TokenInstance::Ident(name)) if name == "DECLARE")
        {
            continue;
        }
        if structured_declaration_at_pc(definitions, pc).is_some() {
            return Err(Error::syntax(format!(
                "line {}: DECLARE is only valid outside SUB, FUNCTION, and TYPE bodies",
                statement.line_number
            )));
        }
        let Some(TokenInstance::Ident(kind)) = statement.body.get(1) else {
            return Err(Error::syntax(format!(
                "line {}: DECLARE requires SUB or FUNCTION",
                statement.line_number
            )));
        };
        let header = Statement {
            line_number: statement.line_number,
            body: statement.body[1..].to_vec(),
        };
        match kind.as_str() {
            "SUB" => {
                let (name, parameters) = parse_sub_header(&header)?;
                if !declared.insert((kind.clone(), name.clone())) {
                    return Err(Error::syntax(format!(
                        "line {}: duplicate DECLARE SUB {name}",
                        statement.line_number
                    )));
                }
                let definition = definitions.subs.get(&name).ok_or_else(|| {
                    Error::syntax(format!(
                        "line {}: DECLARE SUB {name} has no matching definition",
                        statement.line_number
                    ))
                })?;
                if !procedure_signatures_match(&parameters, &definition.parameters) {
                    return Err(Error::syntax(format!(
                        "line {}: DECLARE SUB {name} signature does not match its definition",
                        statement.line_number
                    )));
                }
            }
            "FUNCTION" => {
                let parsed = parse_function_header_details(&header)?;
                if !parsed.explicit_return_type {
                    return Err(Error::syntax(format!(
                        "line {}: DECLARE FUNCTION requires AS type",
                        statement.line_number
                    )));
                }
                if !declared.insert((kind.clone(), parsed.name.clone())) {
                    return Err(Error::syntax(format!(
                        "line {}: duplicate DECLARE FUNCTION {}",
                        statement.line_number, parsed.name
                    )));
                }
                let definition = definitions.functions.get(&parsed.name).ok_or_else(|| {
                    Error::syntax(format!(
                        "line {}: DECLARE FUNCTION {} has no matching definition",
                        statement.line_number, parsed.name
                    ))
                })?;
                if !procedure_signatures_match(&parsed.parameters, &definition.parameters)
                    || definition.return_type != Some(parsed.return_type)
                {
                    return Err(Error::syntax(format!(
                        "line {}: DECLARE FUNCTION {} signature does not match its definition",
                        statement.line_number, parsed.name
                    )));
                }
            }
            _ => {
                return Err(Error::syntax(format!(
                    "line {}: DECLARE requires SUB or FUNCTION",
                    statement.line_number
                )))
            }
        }
    }
    Ok(())
}

fn validate_control_region(statements: &[Statement]) -> Result<(), Error> {
    validate_while_structure(statements)?;
    validate_block_if_structure(statements)?;
    validate_do_loop_structure(statements)?;
    validate_repeat_until_structure(statements)?;
    validate_select_structure(statements)
}

fn is_sub_start(statement: &Statement) -> bool {
    matches!(
        statement.body.first(),
        Some(TokenInstance::Ident(name)) if name == "SUB"
    )
}

fn is_sub_end(statement: &Statement) -> bool {
    matches!(
        statement.body.as_slice(),
        [TokenInstance::Keyword(Token::End), TokenInstance::Ident(name)] if name == "SUB"
    )
}

fn is_function_start(statement: &Statement) -> bool {
    matches!(
        statement.body.first(),
        Some(TokenInstance::Ident(name)) if name == "FUNCTION"
    )
}

fn is_function_end(statement: &Statement) -> bool {
    matches!(
        statement.body.as_slice(),
        [TokenInstance::Keyword(Token::End), TokenInstance::Ident(name)] if name == "FUNCTION"
    )
}

fn is_type_start(statement: &Statement) -> bool {
    matches!(
        statement.body.first(),
        Some(TokenInstance::Ident(name)) if name == "TYPE"
    )
}

fn is_type_end(statement: &Statement) -> bool {
    matches!(
        statement.body.as_slice(),
        [TokenInstance::Keyword(Token::End), TokenInstance::Ident(name)] if name == "TYPE"
    )
}

fn parse_type_header(statement: &Statement) -> Result<String, Error> {
    match statement.body.as_slice() {
        [TokenInstance::Ident(keyword), TokenInstance::Ident(name)]
            if keyword == "TYPE"
                && !name.contains('.')
                && variable_type(name) == VariableType::Numeric =>
        {
            if parse_primitive_as_type(name).is_some() {
                Err(Error::syntax(format!(
                    "line {}: TYPE name cannot shadow a primitive AS kind",
                    statement.line_number
                )))
            } else {
                Ok(name.clone())
            }
        }
        _ => Err(Error::syntax(format!(
            "line {}: TYPE expects one unsuffixed type name",
            statement.line_number
        ))),
    }
}

fn parse_type_field(statement: &Statement) -> Result<UnresolvedTypeField, Error> {
    let Some(TokenInstance::Ident(name)) = statement.body.first() else {
        return Err(Error::syntax(format!(
            "line {}: TYPE field requires a name",
            statement.line_number
        )));
    };
    if name.contains('.') {
        return Err(Error::syntax(format!(
            "line {}: TYPE field name cannot contain '.'",
            statement.line_number
        )));
    }
    if !matches!(statement.body.get(1), Some(TokenInstance::Ident(keyword)) if keyword == "AS") {
        return Err(Error::syntax(format!(
            "line {}: TYPE field requires AS",
            statement.line_number
        )));
    }
    let spelling = detokenize(&statement.body[2..])
        .chars()
        .filter(|character| !character.is_whitespace())
        .collect::<String>()
        .to_ascii_uppercase();
    let kind = if let Some(length) = spelling.strip_prefix("STRING*") {
        let length = length.parse::<usize>().map_err(|_| {
            Error::syntax(format!(
                "line {}: fixed STRING length must be a positive integer",
                statement.line_number
            ))
        })?;
        if length == 0 {
            return Err(Error::syntax(format!(
                "line {}: fixed STRING length must be positive",
                statement.line_number
            )));
        }
        UnresolvedTypeFieldKind::Primitive {
            declaration: VariableType::String,
            fixed_string_bytes: Some(length),
        }
    } else {
        match spelling.as_str() {
            "STRING" => UnresolvedTypeFieldKind::Primitive {
                declaration: VariableType::String,
                fixed_string_bytes: None,
            },
            "INTEGER" => UnresolvedTypeFieldKind::Primitive {
                declaration: VariableType::Integer,
                fixed_string_bytes: None,
            },
            "LONG" => UnresolvedTypeFieldKind::Primitive {
                declaration: VariableType::Long,
                fixed_string_bytes: None,
            },
            "SINGLE" => UnresolvedTypeFieldKind::Primitive {
                declaration: VariableType::Single,
                fixed_string_bytes: None,
            },
            "DOUBLE" => UnresolvedTypeFieldKind::Primitive {
                declaration: VariableType::Double,
                fixed_string_bytes: None,
            },
            _ => match &statement.body[2..] {
                [TokenInstance::Ident(type_name)]
                    if !type_name.contains('.')
                        && variable_type(type_name) == VariableType::Numeric =>
                {
                    UnresolvedTypeFieldKind::Nested(type_name.clone())
                }
                _ => {
                    return Err(Error::syntax(format!(
                        "line {}: TYPE field AS kind must be a primitive or user-defined TYPE name",
                        statement.line_number
                    )))
                }
            },
        }
    };
    let suffix_type = variable_type(name);
    match &kind {
        UnresolvedTypeFieldKind::Primitive { declaration, .. }
            if suffix_type != VariableType::Numeric && suffix_type != *declaration =>
        {
            return Err(Error::syntax(format!(
                "line {}: TYPE field suffix conflicts with its AS kind",
                statement.line_number
            )));
        }
        UnresolvedTypeFieldKind::Nested(_) if suffix_type != VariableType::Numeric => {
            return Err(Error::syntax(format!(
                "line {}: nested TYPE field name must be unsuffixed",
                statement.line_number
            )));
        }
        _ => {}
    }
    Ok(UnresolvedTypeField {
        name: name.clone(),
        kind,
        line_number: statement.line_number,
    })
}

const MAX_NESTED_TYPE_DEPTH: usize = 256;
const MAX_FLATTENED_TYPE_FIELDS: usize = 65_536;

fn resolve_type_definition(
    name: &str,
    unresolved: &HashMap<String, UnresolvedTypeDefinition>,
    resolved: &mut HashMap<String, TypeDefinition>,
    active: &mut Vec<String>,
) -> Result<TypeDefinition, Error> {
    if let Some(definition) = resolved.get(name) {
        return Ok(definition.clone());
    }
    if let Some(cycle_start) = active.iter().position(|active_name| active_name == name) {
        let mut cycle = active[cycle_start..].to_vec();
        cycle.push(name.to_string());
        return Err(Error::syntax(format!(
            "cyclic TYPE definition: {}",
            cycle.join(" -> ")
        )));
    }
    if active.len() >= MAX_NESTED_TYPE_DEPTH {
        return Err(Error::syntax(format!(
            "TYPE {name} exceeds the maximum nesting depth of {MAX_NESTED_TYPE_DEPTH}"
        )));
    }
    let raw = unresolved
        .get(name)
        .cloned()
        .ok_or_else(|| Error::syntax(format!("undefined TYPE {name}")))?;
    active.push(name.to_string());
    let result = (|| {
        let mut fields = Vec::new();
        let mut nested_fields = Vec::new();
        for field in raw.fields {
            match field.kind {
                UnresolvedTypeFieldKind::Primitive {
                    declaration,
                    fixed_string_bytes,
                } => fields.push(TypeField {
                    name: field.name,
                    declaration,
                    fixed_string_bytes,
                }),
                UnresolvedTypeFieldKind::Nested(type_name) => {
                    let nested = unresolved.get(&type_name).ok_or_else(|| {
                        Error::syntax(format!(
                            "line {}: undefined TYPE {type_name} for field {}.{}",
                            field.line_number, raw.name, field.name
                        ))
                    })?;
                    let nested_name = nested.name.clone();
                    let nested =
                        resolve_type_definition(&nested_name, unresolved, resolved, active)?;
                    nested_fields.push(NestedTypeField {
                        name: field.name.clone(),
                        type_name: type_name.clone(),
                    });
                    nested_fields.extend(nested.nested_fields.iter().map(|nested_field| {
                        NestedTypeField {
                            name: format!("{}.{}", field.name, nested_field.name),
                            type_name: nested_field.type_name.clone(),
                        }
                    }));
                    if fields.len().saturating_add(nested.fields.len()) > MAX_FLATTENED_TYPE_FIELDS
                    {
                        return Err(Error::syntax(format!(
                            "TYPE {} exceeds the maximum of {MAX_FLATTENED_TYPE_FIELDS} flattened fields",
                            raw.name
                        )));
                    }
                    fields.extend(nested.fields.into_iter().map(|nested_field| TypeField {
                        name: format!("{}.{}", field.name, nested_field.name),
                        declaration: nested_field.declaration,
                        fixed_string_bytes: nested_field.fixed_string_bytes,
                    }));
                }
            }
            if fields.len() > MAX_FLATTENED_TYPE_FIELDS {
                return Err(Error::syntax(format!(
                    "TYPE {} exceeds the maximum of {MAX_FLATTENED_TYPE_FIELDS} flattened fields",
                    raw.name
                )));
            }
        }
        Ok(TypeDefinition {
            name: raw.name,
            fields,
            nested_fields,
            start_pc: raw.start_pc,
            end_pc: raw.end_pc,
        })
    })();
    active.pop();
    let definition = result?;
    resolved.insert(name.to_string(), definition.clone());
    Ok(definition)
}

fn collect_type_definitions(
    statements: &[Statement],
) -> Result<HashMap<String, TypeDefinition>, Error> {
    let mut unresolved = HashMap::new();
    let mut active: Option<(String, usize, Vec<UnresolvedTypeField>)> = None;
    for (pc, statement) in statements.iter().enumerate() {
        if is_type_start(statement) {
            if active.is_some() {
                return Err(Error::syntax(format!(
                    "line {}: nested TYPE declarations are not allowed",
                    statement.line_number
                )));
            }
            let name = parse_type_header(statement)?;
            if unresolved.contains_key(&name) {
                return Err(Error::syntax(format!(
                    "line {}: duplicate TYPE {name}",
                    statement.line_number
                )));
            }
            active = Some((name, pc, Vec::new()));
            continue;
        }
        if is_type_end(statement) {
            let Some((name, start_pc, fields)) = active.take() else {
                return Err(Error::syntax(format!(
                    "line {}: END TYPE without TYPE",
                    statement.line_number
                )));
            };
            if fields.is_empty() {
                return Err(Error::syntax(format!(
                    "line {}: TYPE {name} requires at least one field",
                    statements[start_pc].line_number
                )));
            }
            unresolved.insert(
                name.clone(),
                UnresolvedTypeDefinition {
                    name,
                    fields,
                    start_pc,
                    end_pc: pc,
                },
            );
            continue;
        }
        let Some((_, _, fields)) = active.as_mut() else {
            continue;
        };
        let field = parse_type_field(statement)?;
        if fields.iter().any(|existing| existing.name == field.name) {
            return Err(Error::syntax(format!(
                "line {}: duplicate TYPE field {}",
                statement.line_number, field.name
            )));
        }
        fields.push(field);
    }
    if let Some((name, start_pc, _)) = active {
        return Err(Error::syntax(format!(
            "line {}: TYPE {name} without matching END TYPE",
            statements[start_pc].line_number
        )));
    }
    let mut declaration_order = unresolved
        .values()
        .map(|definition| (definition.start_pc, definition.name.clone()))
        .collect::<Vec<_>>();
    declaration_order.sort_unstable();
    let mut types = HashMap::new();
    for (_, name) in declaration_order {
        resolve_type_definition(&name, &unresolved, &mut types, &mut Vec::new())?;
    }
    Ok(types)
}

fn parse_procedure_parameter(
    argument: &[TokenInstance],
    line_number: u64,
    kind: &str,
) -> Result<ProcedureParameter, Error> {
    let mut position = 0usize;
    let mut explicit_mode = false;
    let mode = match argument.get(position) {
        Some(TokenInstance::Ident(word)) if word == "BYVAL" => {
            explicit_mode = true;
            position += 1;
            ParameterMode::ByVal
        }
        Some(TokenInstance::Ident(word)) if word == "BYREF" => {
            explicit_mode = true;
            position += 1;
            ParameterMode::ByRef
        }
        _ => ParameterMode::ByVal,
    };
    let Some(TokenInstance::Ident(name)) = argument.get(position) else {
        return Err(Error::syntax(format!(
            "line {line_number}: {kind} parameter requires a name"
        )));
    };
    position += 1;
    let shape = if matches!(argument.get(position), Some(TokenInstance::LParen)) {
        if !matches!(argument.get(position + 1), Some(TokenInstance::RParen)) {
            return Err(Error::syntax(format!(
                "line {line_number}: {kind} whole-array parameter marker must be empty ()"
            )));
        }
        position += 2;
        ParameterShape::Array
    } else {
        ParameterShape::Scalar
    };
    if shape == ParameterShape::Array && (!explicit_mode || mode != ParameterMode::ByRef) {
        return Err(Error::syntax(format!(
            "line {line_number}: {kind} whole-array parameters require explicit BYREF"
        )));
    }
    let as_type = if position == argument.len() {
        None
    } else if let [TokenInstance::Ident(as_word), TokenInstance::Ident(as_type)] =
        &argument[position..]
    {
        if as_word != "AS" {
            return Err(Error::syntax(format!(
                "line {line_number}: {kind} parameter type requires AS"
            )));
        }
        Some(as_type.clone())
    } else {
        return Err(Error::syntax(format!(
            "line {line_number}: malformed {kind} parameter"
        )));
    };
    if name.contains('.') {
        return Err(Error::syntax(format!(
            "line {line_number}: {kind} parameter names cannot be TYPE fields"
        )));
    }
    let suffix_type = variable_type(name);
    let (declaration, record_type) = match as_type {
        Some(as_type) => match parse_primitive_as_type(&as_type) {
            Some(declaration) => {
                if suffix_type != VariableType::Numeric && suffix_type != declaration {
                    return Err(Error::syntax(format!(
                        "line {line_number}: {kind} parameter suffix conflicts with its AS type"
                    )));
                }
                (declaration, None)
            }
            None if shape == ParameterShape::Array => (VariableType::Numeric, Some(as_type)),
            None => {
                return Err(Error::syntax(format!(
                    "line {line_number}: scalar {kind} parameter AS type must be primitive"
                )))
            }
        },
        None => (suffix_type, None),
    };
    if record_type.is_some() && suffix_type != VariableType::Numeric {
        return Err(Error::syntax(format!(
            "line {line_number}: {kind} record-array parameter name must be unsuffixed"
        )));
    }
    Ok(ProcedureParameter {
        name: name.clone(),
        mode,
        shape,
        declaration,
        record_type,
    })
}

fn parse_sub_header(statement: &Statement) -> Result<(String, Vec<ProcedureParameter>), Error> {
    let body = &statement.body;
    let Some(TokenInstance::Ident(name)) = body.get(1) else {
        return Err(Error::syntax(format!(
            "line {}: SUB requires a procedure name",
            statement.line_number
        )));
    };
    let mut parameters = Vec::new();
    match &body[2..] {
        [] => {}
        [TokenInstance::LParen, inside @ .., TokenInstance::RParen] => {
            if !inside.is_empty() {
                for argument in split_graph_arguments(inside)? {
                    let parameter =
                        parse_procedure_parameter(argument, statement.line_number, "SUB")?;
                    if parameters
                        .iter()
                        .any(|existing: &ProcedureParameter| existing.name == parameter.name)
                    {
                        return Err(Error::syntax(format!(
                            "line {}: duplicate SUB parameter {}",
                            statement.line_number, parameter.name
                        )));
                    }
                    parameters.push(parameter);
                }
            }
        }
        _ => {
            return Err(Error::syntax(format!(
                "line {}: SUB expects name or name(parameter, ...)",
                statement.line_number
            )))
        }
    }
    Ok((name.clone(), parameters))
}

fn parse_function_header(
    statement: &Statement,
) -> Result<(String, Vec<ProcedureParameter>), Error> {
    let header = parse_function_header_details(statement)?;
    Ok((header.name, header.parameters))
}

struct ParsedFunctionHeader {
    name: String,
    parameters: Vec<ProcedureParameter>,
    return_type: VariableType,
    explicit_return_type: bool,
}

fn parse_function_header_details(statement: &Statement) -> Result<ParsedFunctionHeader, Error> {
    let body = &statement.body;
    let Some(TokenInstance::Ident(name)) = body.get(1) else {
        return Err(Error::syntax(format!(
            "line {}: FUNCTION requires a function name",
            statement.line_number
        )));
    };
    let mut parameters = Vec::new();
    let mut tail = &body[2..];
    if matches!(tail.first(), Some(TokenInstance::LParen)) {
        let mut depth = 0usize;
        let mut close = None;
        for (index, token) in tail.iter().enumerate() {
            match token {
                TokenInstance::LParen => depth += 1,
                TokenInstance::RParen => {
                    depth = depth.checked_sub(1).ok_or_else(|| {
                        Error::syntax(format!(
                            "line {}: unexpected ')' in FUNCTION header",
                            statement.line_number
                        ))
                    })?;
                    if depth == 0 {
                        close = Some(index);
                        break;
                    }
                }
                _ => {}
            }
        }
        let close = close.ok_or_else(|| {
            Error::syntax(format!(
                "line {}: FUNCTION parameter list is missing ')'",
                statement.line_number
            ))
        })?;
        let inside = &tail[1..close];
        if !inside.is_empty() {
            for argument in split_graph_arguments(inside)? {
                let parameter =
                    parse_procedure_parameter(argument, statement.line_number, "FUNCTION")?;
                if parameters
                    .iter()
                    .any(|existing: &ProcedureParameter| existing.name == parameter.name)
                {
                    return Err(Error::syntax(format!(
                        "line {}: duplicate FUNCTION parameter {}",
                        statement.line_number, parameter.name
                    )));
                }
                parameters.push(parameter);
            }
        }
        tail = &tail[close + 1..];
    }
    let (return_type, explicit_return_type) = match tail {
        [] => (variable_type(name), false),
        [TokenInstance::Ident(as_word), TokenInstance::Ident(as_type)] if as_word == "AS" => {
            let return_type = parse_primitive_as_type(as_type).ok_or_else(|| {
                Error::syntax(format!(
                    "line {}: FUNCTION return AS type must be primitive",
                    statement.line_number
                ))
            })?;
            let suffix_type = variable_type(name);
            if suffix_type != VariableType::Numeric && suffix_type != return_type {
                return Err(Error::syntax(format!(
                    "line {}: FUNCTION name suffix conflicts with its AS type",
                    statement.line_number
                )));
            }
            (return_type, true)
        }
        _ => {
            return Err(Error::syntax(format!(
                "line {}: FUNCTION expects name[(parameter, ...)] [AS type]",
                statement.line_number
            )))
        }
    };
    Ok(ParsedFunctionHeader {
        name: name.clone(),
        parameters,
        return_type,
        explicit_return_type,
    })
}

trait InsertUnique<T> {
    fn insert_unique(&mut self, value: T) -> bool;
}

impl<T: PartialEq> InsertUnique<T> for Vec<T> {
    fn insert_unique(&mut self, value: T) -> bool {
        if self.contains(&value) {
            false
        } else {
            self.push(value);
            true
        }
    }
}

fn parse_procedure_scalar_names(
    statement: &Statement,
    keyword: &str,
) -> Result<Vec<String>, Error> {
    if statement.body.len() == 1 {
        return Err(Error::syntax(format!(
            "line {}: {keyword} requires at least one name",
            statement.line_number
        )));
    }
    let mut names = Vec::new();
    for argument in split_graph_arguments(&statement.body[1..])? {
        let name = if let [TokenInstance::Ident(name)] = argument {
            name.clone()
        } else {
            let declarations = parse_dim_list(argument)?;
            if declarations.len() != 1 {
                return Err(Error::syntax(format!(
                    "line {}: malformed {keyword} declaration",
                    statement.line_number
                )));
            }
            declarations[0].name.clone()
        };
        if !names.insert_unique(name.clone()) {
            return Err(Error::syntax(format!(
                "line {}: duplicate {keyword} name {}",
                statement.line_number, name
            )));
        }
    }
    Ok(names)
}

fn parse_dim_shared_names(statement: &Statement) -> Result<Vec<String>, Error> {
    let declarations = parse_dim_list(&statement.body[2..])?;
    let mut names = Vec::with_capacity(declarations.len());
    for declaration in declarations {
        if !names.insert_unique(declaration.name.clone()) {
            return Err(Error::syntax(format!(
                "line {}: duplicate DIM SHARED name {}",
                statement.line_number, declaration.name
            )));
        }
    }
    Ok(names)
}

fn collect_sub_definitions(
    statements: &[Statement],
) -> Result<HashMap<String, ProcedureDefinition>, Error> {
    let mut procedures = HashMap::new();
    let mut active: Option<PendingProcedure> = None;

    for (pc, statement) in statements.iter().enumerate() {
        if is_sub_start(statement) {
            if active.is_some() {
                return Err(Error::syntax(format!(
                    "line {}: nested SUB declarations are not allowed",
                    statement.line_number
                )));
            }
            let (name, parameters) = parse_sub_header(statement)?;
            if procedures.contains_key(&name) {
                return Err(Error::syntax(format!(
                    "line {}: duplicate SUB {name}",
                    statement.line_number
                )));
            }
            active = Some(PendingProcedure {
                name,
                parameters,
                return_type: None,
                start_pc: pc,
                shared: HashSet::new(),
                statics: HashSet::new(),
            });
            continue;
        }

        if is_function_start(statement) && active.is_some() {
            return Err(Error::syntax(format!(
                "line {}: FUNCTION cannot be nested inside SUB",
                statement.line_number
            )));
        }

        if is_sub_end(statement) {
            let Some(pending) = active.take() else {
                return Err(Error::syntax(format!(
                    "line {}: END SUB without SUB",
                    statement.line_number
                )));
            };
            if pending.parameters.iter().any(|parameter| {
                pending.shared.contains(&parameter.name)
                    || pending.statics.contains(&parameter.name)
            }) {
                return Err(Error::syntax(format!(
                    "line {}: SUB parameters cannot be SHARED or STATIC",
                    statements[pending.start_pc].line_number
                )));
            }
            if pending
                .shared
                .iter()
                .any(|name| pending.statics.contains(name))
            {
                return Err(Error::syntax(format!(
                    "line {}: a SUB scalar cannot be both SHARED and STATIC",
                    statements[pending.start_pc].line_number
                )));
            }
            procedures.insert(
                pending.name.clone(),
                ProcedureDefinition {
                    name: pending.name,
                    parameters: pending.parameters,
                    return_type: pending.return_type,
                    start_pc: pending.start_pc,
                    end_pc: pc,
                    shared: pending.shared,
                    statics: pending.statics,
                },
            );
            continue;
        }

        let Some(pending) = active.as_mut() else {
            continue;
        };
        match statement.body.first() {
            Some(TokenInstance::Ident(keyword)) if keyword == "SHARED" => {
                pending
                    .shared
                    .extend(parse_procedure_scalar_names(statement, keyword)?);
            }
            Some(TokenInstance::Ident(keyword)) if keyword == "STATIC" => {
                pending
                    .statics
                    .extend(parse_procedure_scalar_names(statement, keyword)?);
            }
            Some(TokenInstance::Keyword(Token::Dim)) if matches!(statement.body.get(1), Some(TokenInstance::Ident(word)) if word == "SHARED") =>
            {
                pending.shared.extend(parse_dim_shared_names(statement)?);
            }
            _ => {}
        }
    }

    if let Some(pending) = active {
        return Err(Error::syntax(format!(
            "line {}: SUB without matching END SUB",
            statements[pending.start_pc].line_number
        )));
    }
    Ok(procedures)
}

fn collect_function_definitions(
    statements: &[Statement],
) -> Result<HashMap<String, ProcedureDefinition>, Error> {
    let mut functions = HashMap::new();
    let mut active: Option<PendingProcedure> = None;

    for (pc, statement) in statements.iter().enumerate() {
        if is_function_start(statement) {
            if active.is_some() {
                return Err(Error::syntax(format!(
                    "line {}: nested FUNCTION declarations are not allowed",
                    statement.line_number
                )));
            }
            let header = parse_function_header_details(statement)?;
            let name = header.name;
            let parameters = header.parameters;
            if functions.contains_key(&name) {
                return Err(Error::syntax(format!(
                    "line {}: duplicate FUNCTION {name}",
                    statement.line_number
                )));
            }
            active = Some(PendingProcedure {
                name,
                parameters,
                return_type: Some(header.return_type),
                start_pc: pc,
                shared: HashSet::new(),
                statics: HashSet::new(),
            });
            continue;
        }
        if is_sub_start(statement) && active.is_some() {
            return Err(Error::syntax(format!(
                "line {}: SUB cannot be nested inside FUNCTION",
                statement.line_number
            )));
        }
        if is_function_end(statement) {
            let Some(pending) = active.take() else {
                return Err(Error::syntax(format!(
                    "line {}: END FUNCTION without FUNCTION",
                    statement.line_number
                )));
            };
            if pending.parameters.iter().any(|parameter| {
                pending.shared.contains(&parameter.name)
                    || pending.statics.contains(&parameter.name)
            }) {
                return Err(Error::syntax(format!(
                    "line {}: FUNCTION parameters cannot be SHARED or STATIC",
                    statements[pending.start_pc].line_number
                )));
            }
            if pending
                .shared
                .iter()
                .any(|name| pending.statics.contains(name))
            {
                return Err(Error::syntax(format!(
                    "line {}: a FUNCTION scalar cannot be both SHARED and STATIC",
                    statements[pending.start_pc].line_number
                )));
            }
            if pending.shared.contains(&pending.name) || pending.statics.contains(&pending.name) {
                return Err(Error::syntax(format!(
                    "line {}: FUNCTION return name cannot be SHARED or STATIC",
                    statements[pending.start_pc].line_number
                )));
            }
            if pending
                .parameters
                .iter()
                .any(|parameter| parameter.name == pending.name)
            {
                return Err(Error::syntax(format!(
                    "line {}: FUNCTION parameter cannot use return name {}",
                    statements[pending.start_pc].line_number, pending.name
                )));
            }
            functions.insert(
                pending.name.clone(),
                ProcedureDefinition {
                    name: pending.name,
                    parameters: pending.parameters,
                    return_type: pending.return_type,
                    start_pc: pending.start_pc,
                    end_pc: pc,
                    shared: pending.shared,
                    statics: pending.statics,
                },
            );
            continue;
        }
        let Some(pending) = active.as_mut() else {
            continue;
        };
        match statement.body.first() {
            Some(TokenInstance::Ident(keyword)) if keyword == "SHARED" => pending
                .shared
                .extend(parse_procedure_scalar_names(statement, keyword)?),
            Some(TokenInstance::Ident(keyword)) if keyword == "STATIC" => pending
                .statics
                .extend(parse_procedure_scalar_names(statement, keyword)?),
            Some(TokenInstance::Keyword(Token::Dim)) if matches!(statement.body.get(1), Some(TokenInstance::Ident(word)) if word == "SHARED") =>
            {
                pending.shared.extend(parse_dim_shared_names(statement)?);
            }
            _ => {}
        }
    }
    if let Some(pending) = active {
        return Err(Error::syntax(format!(
            "line {}: FUNCTION without matching END FUNCTION",
            statements[pending.start_pc].line_number
        )));
    }
    Ok(functions)
}

fn procedure_at_pc(definitions: &StructuredDefinitions, pc: usize) -> Option<&str> {
    definitions
        .subs
        .values()
        .chain(definitions.functions.values())
        .find(|definition| (definition.start_pc..=definition.end_pc).contains(&pc))
        .map(|definition| definition.name.as_str())
}

fn structured_declaration_at_pc(definitions: &StructuredDefinitions, pc: usize) -> Option<&str> {
    procedure_at_pc(definitions, pc).or_else(|| {
        definitions
            .types
            .values()
            .find(|definition| (definition.start_pc..=definition.end_pc).contains(&pc))
            .map(|definition| definition.name.as_str())
    })
}

fn validate_block_if_structure(statements: &[Statement]) -> Result<(), Error> {
    let mut stack: Vec<(u64, bool)> = Vec::new();
    for (index, statement) in statements.iter().enumerate() {
        if is_block_if(statement) {
            stack.push((statement.line_number, false));
        } else if is_ident_statement(statement, "ELSE") && !is_inline_else(statements, index) {
            let Some((_, seen_else)) = stack.last_mut() else {
                return Err(Error::syntax(format!(
                    "line {}: ELSE without block IF",
                    statement.line_number
                )));
            };
            if *seen_else {
                return Err(Error::syntax(format!(
                    "line {}: duplicate ELSE in block IF",
                    statement.line_number
                )));
            }
            *seen_else = true;
        } else if is_block_if_end(statement) && stack.pop().is_none() {
            return Err(Error::syntax(format!(
                "line {}: END IF without block IF",
                statement.line_number
            )));
        }
    }
    if let Some((line_number, _)) = stack.last() {
        return Err(Error::syntax(format!(
            "line {line_number}: block IF without matching END IF"
        )));
    }
    Ok(())
}
fn validate_while_structure(statements: &[Statement]) -> Result<(), Error> {
    let mut stack = Vec::new();
    for statement in statements {
        match statement.body.first() {
            Some(TokenInstance::Keyword(Token::While)) => stack.push(statement.line_number),
            Some(TokenInstance::Keyword(Token::Wend)) => {
                if stack.pop().is_none() {
                    return Err(Error::syntax(format!(
                        "line {}: WEND without WHILE",
                        statement.line_number
                    )));
                }
            }
            _ => {}
        }
    }
    if let Some(line_number) = stack.last() {
        return Err(Error::syntax(format!(
            "line {line_number}: WHILE without matching WEND"
        )));
    }
    Ok(())
}

fn validate_do_loop_structure(statements: &[Statement]) -> Result<(), Error> {
    let mut stack = Vec::new();
    for statement in statements {
        if is_ident_statement(statement, "DO") {
            stack.push(statement.line_number);
        } else if is_ident_statement(statement, "LOOP") && stack.pop().is_none() {
            return Err(Error::syntax(format!(
                "line {}: LOOP without DO",
                statement.line_number
            )));
        }
    }
    if let Some(line_number) = stack.last() {
        return Err(Error::syntax(format!(
            "line {line_number}: DO without matching LOOP"
        )));
    }
    Ok(())
}

fn validate_repeat_until_structure(statements: &[Statement]) -> Result<(), Error> {
    let mut stack = Vec::new();
    for statement in statements {
        if is_ident_statement(statement, "REPEAT") {
            stack.push(statement.line_number);
        } else if is_ident_statement(statement, "UNTIL") && stack.pop().is_none() {
            return Err(Error::syntax(format!(
                "line {}: UNTIL without REPEAT",
                statement.line_number
            )));
        }
    }
    if let Some(line_number) = stack.last() {
        return Err(Error::syntax(format!(
            "line {line_number}: REPEAT without matching UNTIL"
        )));
    }
    Ok(())
}
fn validate_select_structure(statements: &[Statement]) -> Result<(), Error> {
    let mut stack: Vec<(u64, bool)> = Vec::new();
    for statement in statements {
        if is_select_start(statement) {
            select_expression(&statement.body)
                .map_err(|error| annotate(statement.line_number, error))?;
            stack.push((statement.line_number, false));
        } else if is_case_branch(statement) {
            let Some((_, seen_default)) = stack.last_mut() else {
                return Err(Error::syntax(format!(
                    "line {}: CASE/WHEN without SELECT/CASE",
                    statement.line_number
                )));
            };
            if is_default_case(statement) {
                if *seen_default {
                    return Err(Error::syntax(format!(
                        "line {}: duplicate CASE ELSE/OTHERWISE",
                        statement.line_number
                    )));
                }
                *seen_default = true;
            } else {
                if matches!(
                    statement.body.get(1),
                    Some(TokenInstance::Ident(name)) if name == "ELSE"
                ) {
                    return Err(Error::syntax(format!(
                        "line {}: extra characters after CASE ELSE",
                        statement.line_number
                    )));
                }
                split_case_items(&statement.body[1..])
                    .map_err(|error| annotate(statement.line_number, error))?;
            }
        } else if is_select_end(statement) && stack.pop().is_none() {
            return Err(Error::syntax(format!(
                "line {}: SELECT/CASE end without matching start",
                statement.line_number
            )));
        }
    }
    if let Some((line_number, _)) = stack.last() {
        return Err(Error::syntax(format!(
            "line {line_number}: SELECT/CASE without matching end"
        )));
    }
    Ok(())
}
fn annotate(line_number: u64, err: Error) -> Error {
    if line_number == 0 {
        return err;
    }
    match err {
        Error::Syntax { msg } => {
            let prefix = format!("line {line_number}: ");
            if msg.starts_with(&prefix) {
                Error::Syntax { msg }
            } else {
                Error::syntax(format!("{prefix}{msg}"))
            }
        }
        other => other,
    }
}

fn text_coordinate(value: i64, limit: usize) -> Result<usize, Error> {
    usize::try_from(value)
        .ok()
        .filter(|value| (1..=limit).contains(value))
        .ok_or(Error::IllegalQuantity)
}

fn expect_end_of_line(rest: &[TokenInstance]) -> Result<(), Error> {
    if !rest.is_empty() {
        return Err(Error::syntax("extra characters after statement"));
    }
    Ok(())
}

fn parse_line_number(tokens: &[TokenInstance]) -> Result<u64, Error> {
    match tokens {
        [TokenInstance::Number(n)] => {
            let line = u64::try_from(*n).map_err(|_| Error::IllegalQuantity)?;
            (line <= MAX_BASIC_LINE_NUMBER)
                .then_some(line)
                .ok_or(Error::IllegalQuantity)
        }
        [TokenInstance::Keyword(Token::Minus), TokenInstance::Number(_)] => {
            Err(Error::IllegalQuantity)
        }
        [TokenInstance::Number(_), ..]
        | [TokenInstance::Keyword(Token::Minus), TokenInstance::Number(_), ..] => {
            Err(Error::syntax("extra characters after line number"))
        }
        _ => Err(Error::syntax("expected line number")),
    }
}

/// Parse the traditional `LIST [start][-end]` literal range syntax.
fn parse_list_range(tokens: &[TokenInstance]) -> Result<(u64, u64), Error> {
    let number = |value: i64| u64::try_from(value).map_err(|_| Error::IllegalQuantity);
    match tokens {
        [] | [TokenInstance::Keyword(Token::Minus)] => Ok((0, u64::MAX)),
        [TokenInstance::Number(line)] => {
            let line = number(*line)?;
            Ok((line, line))
        }
        [TokenInstance::Keyword(Token::Minus), TokenInstance::Number(end)] => {
            Ok((0, number(*end)?))
        }
        [TokenInstance::Number(start), TokenInstance::Keyword(Token::Minus)] => {
            Ok((number(*start)?, u64::MAX))
        }
        [TokenInstance::Number(start), TokenInstance::Keyword(Token::Minus), TokenInstance::Number(end)] => {
            Ok((number(*start)?, number(*end)?))
        }
        _ => Err(Error::syntax("LIST expects [start][-end]")),
    }
}

fn parse_line_number_list(tokens: &[TokenInstance]) -> Result<Vec<u64>, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax("branch requires at least one line number"));
    }

    let mut targets = Vec::new();
    let mut pos = 0;
    loop {
        match tokens.get(pos) {
            Some(TokenInstance::Number(n)) => {
                targets.push(u64::try_from(*n).map_err(|_| Error::IllegalQuantity)?);
                pos += 1;
            }
            Some(TokenInstance::Keyword(Token::Minus))
                if matches!(tokens.get(pos + 1), Some(TokenInstance::Number(_))) =>
            {
                return Err(Error::IllegalQuantity);
            }
            _ => return Err(Error::syntax("expected line number in branch list")),
        }

        if pos == tokens.len() {
            return Ok(targets);
        }
        if !matches!(tokens.get(pos), Some(TokenInstance::Comma)) {
            return Err(Error::syntax("expected ',' in branch list"));
        }
        pos += 1;
        if pos == tokens.len() {
            return Err(Error::syntax("branch list cannot end with ','"));
        }
    }
}

fn parse_next_variables(rest: &[TokenInstance]) -> Result<Vec<Option<String>>, Error> {
    if rest.is_empty() {
        return Ok(vec![None]);
    }

    let mut variables = Vec::new();
    let mut pos = 0;
    loop {
        match rest.get(pos) {
            Some(TokenInstance::Ident(name)) => {
                variables.push(Some(name.clone()));
                pos += 1;
            }
            _ => return Err(Error::syntax("expected variable after NEXT or ','")),
        }

        if pos == rest.len() {
            return Ok(variables);
        }
        if !matches!(rest.get(pos), Some(TokenInstance::Comma)) {
            return Err(Error::syntax("expected ',' between NEXT variables"));
        }
        pos += 1;
        if pos == rest.len() {
            return Err(Error::syntax("NEXT variable list cannot end with ','"));
        }
    }
}

/// An assignment target: a scalar variable or an indexed array element.
#[derive(Debug, Clone)]
struct Lvalue {
    name: String,
    subscripts: Vec<Vec<TokenInstance>>,
}

#[derive(Debug, Clone)]
struct DirectRecordTransfer {
    position: Option<Vec<TokenInstance>>,
    target: Lvalue,
}

/// An assignment target whose array subscript expressions have been resolved.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct ResolvedLvalue {
    name: String,
    indices: Vec<i64>,
}

#[derive(Debug, Clone)]
struct ResolvedRecordTarget {
    base: String,
    indices: Vec<i64>,
    definition: TypeDefinition,
}

fn parse_lvalue(tokens: &[TokenInstance]) -> Result<(Lvalue, &[TokenInstance]), Error> {
    if tokens.is_empty() {
        return Err(Error::syntax("expected variable name in assignment"));
    }
    let name = match &tokens[0] {
        TokenInstance::Ident(name) => name.clone(),
        _ => return Err(Error::syntax("expected variable name in assignment")),
    };

    let mut pos = 1;
    let mut subscripts = Vec::new();
    if matches!(tokens.get(pos), Some(TokenInstance::LParen)) {
        pos += 1;
        let mut start = pos;
        let mut depth = 1;
        while pos < tokens.len() {
            match &tokens[pos] {
                TokenInstance::LParen => depth += 1,
                TokenInstance::RParen => {
                    depth -= 1;
                    if depth == 0 {
                        if start == pos {
                            return Err(Error::syntax("missing array subscript"));
                        }
                        subscripts.push(tokens[start..pos].to_vec());
                        pos += 1;
                        break;
                    }
                }
                TokenInstance::Comma if depth == 1 => {
                    if start == pos {
                        return Err(Error::syntax("missing array subscript"));
                    }
                    subscripts.push(tokens[start..pos].to_vec());
                    pos += 1;
                    start = pos;
                }
                _ => {}
            }
            pos += 1;
        }
        if depth != 0 {
            return Err(Error::syntax("expected ')' in array subscript"));
        }
    }

    match tokens.get(pos) {
        Some(TokenInstance::Keyword(Token::Equal)) => {}
        _ => return Err(Error::syntax("expected = in assignment")),
    }

    Ok((Lvalue { name, subscripts }, &tokens[pos + 1..]))
}

/// A single `DIM` declaration.
#[derive(Debug, Clone)]
struct DimDecl {
    name: String,
    bounds: Vec<Vec<TokenInstance>>,
    as_type: Option<String>,
}

fn parse_list_lvalue(tokens: &[TokenInstance], statement: &str) -> Result<Lvalue, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax(format!("expected variable in {statement}")));
    }
    let name = match &tokens[0] {
        TokenInstance::Ident(name) => name.clone(),
        _ => {
            return Err(Error::syntax(format!(
                "expected variable name in {statement}"
            )))
        }
    };

    let mut pos = 1;
    let mut subscripts = Vec::new();
    if matches!(tokens.get(pos), Some(TokenInstance::LParen)) {
        pos += 1;
        let mut start = pos;
        let mut depth = 1;
        while pos < tokens.len() {
            match &tokens[pos] {
                TokenInstance::LParen => depth += 1,
                TokenInstance::RParen => {
                    depth -= 1;
                    if depth == 0 {
                        if start == pos {
                            return Err(Error::syntax("missing array subscript"));
                        }
                        subscripts.push(tokens[start..pos].to_vec());
                        pos += 1;
                        break;
                    }
                }
                TokenInstance::Comma if depth == 1 => {
                    if start == pos {
                        return Err(Error::syntax("missing array subscript"));
                    }
                    subscripts.push(tokens[start..pos].to_vec());
                    pos += 1;
                    start = pos;
                }
                _ => {}
            }
            pos += 1;
        }
        if depth != 0 {
            return Err(Error::syntax("expected ')' in array subscript"));
        }
    }

    if pos != tokens.len() {
        return Err(Error::syntax(format!(
            "extra characters after {statement} variable"
        )));
    }
    Ok(Lvalue { name, subscripts })
}

fn parse_common_names(tokens: &[TokenInstance]) -> Result<Vec<String>, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax("COMMON requires at least one variable"));
    }
    let mut names = Vec::new();
    let mut pos = 0;
    loop {
        let name = match tokens.get(pos) {
            Some(TokenInstance::Ident(name)) => name.clone(),
            _ => return Err(Error::syntax("COMMON expects a variable name")),
        };
        pos += 1;
        if matches!(tokens.get(pos), Some(TokenInstance::LParen)) {
            if !matches!(tokens.get(pos + 1), Some(TokenInstance::RParen)) {
                return Err(Error::syntax("COMMON array marker must be empty ()"));
            }
            pos += 2;
        }
        names.push(name);
        match tokens.get(pos) {
            None => break,
            Some(TokenInstance::Comma) => {
                pos += 1;
                if pos == tokens.len() {
                    return Err(Error::syntax("COMMON has a trailing comma"));
                }
            }
            _ => return Err(Error::syntax("COMMON variables must be comma-separated")),
        }
    }
    Ok(names)
}

fn parse_lvalue_list(tokens: &[TokenInstance], statement: &str) -> Result<Vec<Lvalue>, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax(format!(
            "{statement} requires at least one variable"
        )));
    }
    let mut lvalues = Vec::new();
    let mut start = 0;
    let mut depth: usize = 0;
    for (i, tok) in tokens.iter().enumerate() {
        match tok {
            TokenInstance::LParen => depth += 1,
            TokenInstance::RParen => {
                if depth == 0 {
                    return Err(Error::syntax(format!("unexpected ')' in {statement} list")));
                }
                depth -= 1;
            }
            TokenInstance::Comma if depth == 0 => {
                if start == i {
                    return Err(Error::syntax(format!("empty {statement} variable")));
                }
                lvalues.push(parse_list_lvalue(&tokens[start..i], statement)?);
                start = i + 1;
            }
            _ => {}
        }
    }
    if depth != 0 {
        return Err(Error::syntax(format!("expected ')' in {statement} list")));
    }
    if start == tokens.len() {
        return Err(Error::syntax(format!("empty {statement} variable")));
    }
    lvalues.push(parse_list_lvalue(&tokens[start..], statement)?);
    Ok(lvalues)
}

fn parse_read_list(tokens: &[TokenInstance]) -> Result<Vec<Lvalue>, Error> {
    parse_lvalue_list(tokens, "READ")
}

fn parse_input_list(tokens: &[TokenInstance]) -> Result<Vec<Lvalue>, Error> {
    parse_lvalue_list(tokens, "INPUT")
}

fn parse_get_list(tokens: &[TokenInstance]) -> Result<Vec<Lvalue>, Error> {
    parse_lvalue_list(tokens, "GET")
}

fn parse_dim_list(tokens: &[TokenInstance]) -> Result<Vec<DimDecl>, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax("DIM requires an array declaration"));
    }

    let mut decls = Vec::new();
    let mut start = 0;
    let mut depth: usize = 0;

    for (i, tok) in tokens.iter().enumerate() {
        match tok {
            TokenInstance::LParen => depth += 1,
            TokenInstance::RParen => {
                if depth == 0 {
                    return Err(Error::syntax("unexpected ')' in DIM declaration"));
                }
                depth -= 1;
            }
            TokenInstance::Comma if depth == 0 => {
                if start == i {
                    return Err(Error::syntax("empty DIM declaration"));
                }
                decls.push(parse_dim_decl(&tokens[start..i])?);
                start = i + 1;
            }
            _ => {}
        }
    }

    if depth != 0 {
        return Err(Error::syntax("expected ')' in DIM declaration"));
    }
    if start == tokens.len() {
        return Err(Error::syntax("empty DIM declaration"));
    }
    decls.push(parse_dim_decl(&tokens[start..])?);

    Ok(decls)
}

fn parse_dim_decl(tokens: &[TokenInstance]) -> Result<DimDecl, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax("empty DIM declaration"));
    }
    let as_pos = tokens
        .iter()
        .enumerate()
        .find(|(_, token)| matches!(token, TokenInstance::Ident(name) if name == "AS"))
        .map(|(index, _)| index);
    let (declaration, as_type) = if let Some(as_pos) = as_pos {
        if as_pos + 1 >= tokens.len() {
            return Err(Error::syntax("DIM AS requires a type name"));
        }
        let spelling = detokenize(&tokens[as_pos + 1..])
            .chars()
            .filter(|character| !character.is_whitespace())
            .collect::<String>()
            .to_ascii_uppercase();
        if spelling.is_empty() {
            return Err(Error::syntax("DIM AS requires a type name"));
        }
        (&tokens[..as_pos], Some(spelling))
    } else {
        (tokens, None)
    };
    let name = match declaration.first() {
        Some(TokenInstance::Ident(name)) => name.clone(),
        _ => return Err(Error::syntax("expected array name in DIM")),
    };

    if declaration.len() == 1 {
        if as_type.is_none() {
            return Err(Error::syntax("scalar DIM requires AS type"));
        }
        return Ok(DimDecl {
            name,
            bounds: Vec::new(),
            as_type,
        });
    }
    if declaration.len() < 3 || !matches!(declaration[1], TokenInstance::LParen) {
        return Err(Error::syntax("expected '(' in DIM declaration"));
    }

    // Find the matching ')' for the dimension list.
    let mut depth = 1;
    let mut paren_end = None;
    for (i, tok) in declaration.iter().enumerate().skip(2) {
        match tok {
            TokenInstance::LParen => depth += 1,
            TokenInstance::RParen => {
                depth -= 1;
                if depth == 0 {
                    paren_end = Some(i);
                    break;
                }
            }
            _ => {}
        }
    }
    let paren_end = paren_end.ok_or_else(|| Error::syntax("expected ')' in DIM declaration"))?;

    // Split the inside of the parentheses on commas at depth 1.
    let mut bounds = Vec::new();
    let mut start = 2;
    let mut depth = 1;
    for i in 2..paren_end {
        match &declaration[i] {
            TokenInstance::LParen => depth += 1,
            TokenInstance::RParen => depth -= 1,
            TokenInstance::Comma if depth == 1 => {
                bounds.push(declaration[start..i].to_vec());
                start = i + 1;
            }
            _ => {}
        }
    }
    if start < paren_end {
        bounds.push(declaration[start..paren_end].to_vec());
    } else {
        return Err(Error::syntax("missing dimension bound in DIM"));
    }

    if paren_end + 1 != declaration.len() {
        return Err(Error::syntax("extra characters after DIM declaration"));
    }

    Ok(DimDecl {
        name,
        bounds,
        as_type,
    })
}

fn parse_primitive_as_type(name: &str) -> Option<VariableType> {
    match name {
        "STRING" => Some(VariableType::String),
        "INTEGER" => Some(VariableType::Integer),
        "LONG" => Some(VariableType::Long),
        "SINGLE" => Some(VariableType::Single),
        "DOUBLE" => Some(VariableType::Double),
        _ => None,
    }
}

// ---- PRINT USING format engine ----

fn find_print_using_separator(tokens: &[TokenInstance]) -> Option<usize> {
    let mut parentheses = 0usize;
    let mut braces = 0usize;
    for (index, token) in tokens.iter().enumerate() {
        match token {
            TokenInstance::LParen => parentheses += 1,
            TokenInstance::RParen => parentheses = parentheses.saturating_sub(1),
            TokenInstance::LBrace => braces += 1,
            TokenInstance::RBrace => braces = braces.saturating_sub(1),
            TokenInstance::Semicolon | TokenInstance::Comma if parentheses == 0 && braces == 0 => {
                return Some(index);
            }
            _ => {}
        }
    }
    None
}

fn parse_session_date(text: &str) -> Result<(u32, u32, u32), Error> {
    let fields = text.split('-').collect::<Vec<_>>();
    if fields.len() != 3 || fields.iter().any(|field| field.is_empty()) {
        return Err(Error::syntax("DATE$ expects MM-DD-YYYY"));
    }
    let month = fields[0]
        .parse::<u32>()
        .map_err(|_| Error::syntax("DATE$ expects MM-DD-YYYY"))?;
    let day = fields[1]
        .parse::<u32>()
        .map_err(|_| Error::syntax("DATE$ expects MM-DD-YYYY"))?;
    let year = fields[2]
        .parse::<u32>()
        .map_err(|_| Error::syntax("DATE$ expects MM-DD-YYYY"))?;
    if !(1970..=9999).contains(&year) || !(1..=12).contains(&month) {
        return Err(Error::IllegalQuantity);
    }
    let month_days: [u32; 12] = [
        31,
        if is_leap_year(year) { 29 } else { 28 },
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31,
    ];
    if day == 0 || day > month_days[(month - 1) as usize] {
        return Err(Error::IllegalQuantity);
    }
    Ok((month, day, year))
}

fn parse_session_time(text: &str) -> Result<(u32, u32, u32), Error> {
    let fields = text.split(':').collect::<Vec<_>>();
    if fields.len() != 3 || fields.iter().any(|field| field.is_empty()) {
        return Err(Error::syntax("TIME$ expects HH:MM:SS"));
    }
    let hour = fields[0]
        .parse::<u32>()
        .map_err(|_| Error::syntax("TIME$ expects HH:MM:SS"))?;
    let minute = fields[1]
        .parse::<u32>()
        .map_err(|_| Error::syntax("TIME$ expects HH:MM:SS"))?;
    let second = fields[2]
        .parse::<u32>()
        .map_err(|_| Error::syntax("TIME$ expects HH:MM:SS"))?;
    if hour > 23 || minute > 59 || second > 59 {
        return Err(Error::IllegalQuantity);
    }
    Ok((hour, minute, second))
}

fn is_leap_year(year: u32) -> bool {
    (year % 4 == 0 && year % 100 != 0) || year % 400 == 0
}

/// Format a list of values using a MS-BASIC PRINT USING format string.
///
/// Number placeholders:
///   #   digit position (space-padded)
///   .   decimal point
///   ,   thousands separator
///   $$  floating dollar sign
///   **  asterisk fill
///   +   force sign (before or after)
///   -   trailing minus for negatives
///       ^^^^  exponential notation
///
/// String placeholders:
///   !       first character only
///   &       entire string
///   \\ \\  fixed-width field (2 backslashes = 2 chars, +1 per space between)
///
/// _ escapes the next character as literal.
pub(crate) fn format_using(format_str: &str, values: &[Value]) -> Result<String, Error> {
    let parts = parse_using_format(format_str);
    let field_count = parts
        .iter()
        .filter(|part| !matches!(part, UsingPart::Literal(_)))
        .count();
    if field_count == 0 {
        return Ok(parts
            .into_iter()
            .filter_map(|part| match part {
                UsingPart::Literal(text) => Some(text),
                _ => None,
            })
            .collect());
    }

    let mut output = String::new();
    let mut value_index = 0usize;
    loop {
        for part in &parts {
            match part {
                UsingPart::Literal(text) => output.push_str(text),
                UsingPart::FirstCharacter => {
                    if let Some(value) = values.get(value_index) {
                        output.push(value_as_string(value).chars().next().unwrap_or(' '));
                        value_index += 1;
                    } else {
                        output.push(' ');
                    }
                }
                UsingPart::EntireString => {
                    if let Some(value) = values.get(value_index) {
                        output.push_str(&value_as_string(value));
                        value_index += 1;
                    } else {
                        output.push(' ');
                    }
                }
                UsingPart::FixedString(width) => {
                    if let Some(value) = values.get(value_index) {
                        let text = value_as_string(value);
                        let length = text.chars().count();
                        output.extend(text.chars().take(*width));
                        if length < *width {
                            output.push_str(&" ".repeat(*width - length));
                        }
                        value_index += 1;
                    } else {
                        output.push_str(&" ".repeat(*width));
                    }
                }
                UsingPart::RightString(width) => {
                    if let Some(value) = values.get(value_index) {
                        let text = value_as_string(value);
                        let text = text.chars().take(*width).collect::<String>();
                        output.push_str(&" ".repeat(width.saturating_sub(text.chars().count())));
                        output.push_str(&text);
                        value_index += 1;
                    } else {
                        output.push_str(&" ".repeat(*width));
                    }
                }
                UsingPart::Number(format) => {
                    if let Some(value) = values.get(value_index) {
                        output.push_str(&format_using_number(value, format)?);
                        value_index += 1;
                    } else {
                        output.push_str(&" ".repeat(format.width));
                    }
                }
            }
        }
        if value_index >= values.len() {
            break;
        }
    }
    Ok(output)
}

enum UsingPart {
    Literal(String),
    FirstCharacter,
    EntireString,
    FixedString(usize),
    RightString(usize),
    Number(UsingNumberFormat),
}

#[derive(Debug, Clone, Copy)]
struct UsingNumberFormat {
    width: usize,
    integer_digits: usize,
    mandatory_integer_digits: usize,
    fractional_digits: usize,
    comma: bool,
    exponential_width: Option<usize>,
    dollar: bool,
    asterisk_fill: bool,
    leading_plus: bool,
    trailing_sign: Option<char>,
}

fn parse_using_format(format_str: &str) -> Vec<UsingPart> {
    let chars = format_str.chars().collect::<Vec<_>>();
    let mut parts = Vec::new();
    let mut literal = String::new();
    let mut position = 0usize;
    while position < chars.len() {
        if chars[position] == '_' && position + 1 < chars.len() {
            literal.push(chars[position + 1]);
            position += 2;
            continue;
        }
        let field = match chars[position] {
            '!' => Some((UsingPart::FirstCharacter, position + 1)),
            '&' => Some((UsingPart::EntireString, position + 1)),
            '\\' => chars[position + 1..]
                .iter()
                .position(|character| *character == '\\')
                .map(|relative| {
                    let end = position + relative + 1;
                    (UsingPart::FixedString(end - position + 1), end + 1)
                }),
            '@' => {
                let width = chars[position..]
                    .iter()
                    .take_while(|character| **character == '@')
                    .count();
                Some((UsingPart::RightString(width), position + width))
            }
            _ => parse_using_number(&chars, position)
                .map(|(format, next)| (UsingPart::Number(format), next)),
        };
        if let Some((field, next)) = field {
            if !literal.is_empty() {
                parts.push(UsingPart::Literal(std::mem::take(&mut literal)));
            }
            parts.push(field);
            position = next;
        } else {
            literal.push(chars[position]);
            position += 1;
        }
    }
    if !literal.is_empty() {
        parts.push(UsingPart::Literal(literal));
    }
    parts
}

fn parse_using_number(chars: &[char], start: usize) -> Option<(UsingNumberFormat, usize)> {
    let mut position = start;
    let mut leading_plus = false;
    let mut dollar = false;
    let mut asterisk_fill = false;
    if chars.get(position) == Some(&'+') {
        leading_plus = true;
        position += 1;
    }
    if chars.get(position) == Some(&'$') {
        dollar = true;
        position += 1;
        if chars.get(position) == Some(&'$') {
            position += 1;
        }
    } else if chars.get(position) == Some(&'*') {
        asterisk_fill = true;
        position += 1;
        if chars.get(position) == Some(&'*') {
            position += 1;
        }
        if chars.get(position) == Some(&'$') {
            dollar = true;
            position += 1;
        }
    }

    let mut integer_digits = 0usize;
    let mut mandatory_integer_digits = 0usize;
    let mut comma = false;
    while position < chars.len() {
        if matches!(chars[position], '#' | '0') {
            integer_digits += 1;
            mandatory_integer_digits += usize::from(chars[position] == '0');
            position += 1;
        } else if chars[position] == ','
            && chars
                .get(position + 1)
                .is_some_and(|character| matches!(character, '#' | '0'))
        {
            comma = true;
            position += 1;
        } else {
            break;
        }
    }
    if integer_digits == 0 {
        return None;
    }

    let mut fractional_digits = 0usize;
    if chars.get(position) == Some(&'.') {
        position += 1;
        while chars
            .get(position)
            .is_some_and(|character| matches!(character, '#' | '0'))
        {
            fractional_digits += 1;
            position += 1;
        }
    }
    let exponent_start = position;
    while chars.get(position) == Some(&'^') {
        position += 1;
    }
    let exponential_width = (position - exponent_start >= 2).then_some(position - exponent_start);
    if exponential_width.is_none() {
        position = exponent_start;
    }
    let trailing_sign = chars
        .get(position)
        .copied()
        .filter(|character| matches!(character, '+' | '-'));
    if trailing_sign.is_some() {
        position += 1;
    }
    Some((
        UsingNumberFormat {
            width: position - start,
            integer_digits,
            mandatory_integer_digits,
            fractional_digits,
            comma,
            exponential_width,
            dollar,
            asterisk_fill,
            leading_plus,
            trailing_sign,
        },
        position,
    ))
}

fn value_as_string(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        Value::Integer(n) => n.to_string(),
        Value::Real(r) => r.value().to_string(),
        _ => format!("{}", v),
    }
}

fn value_as_f64(v: &Value) -> Result<f64, Error> {
    match v {
        Value::Integer(n) => Ok(*n as f64),
        Value::Real(r) => Ok(r.value()),
        Value::String(_) | Value::Complex(_) | Value::List(_) => Err(Error::TypeMismatch),
    }
}

fn format_using_number(value: &Value, format: &UsingNumberFormat) -> Result<String, Error> {
    let direct_integer = matches!(value, Value::Integer(_))
        && format.fractional_digits == 0
        && format.exponential_width.is_none();
    let number = (!direct_integer).then(|| value_as_f64(value)).transpose()?;
    if number.is_some_and(|number| !number.is_finite()) {
        return Ok(format!("%{}", value_as_string(value)));
    }
    let negative = match value {
        Value::Integer(integer) if direct_integer => *integer < 0,
        _ => number.is_some_and(|number| number.is_sign_negative() && number != 0.0),
    };
    let mut digits = if let Value::Integer(integer) = value {
        if direct_integer {
            let integer = integer.unsigned_abs().to_string();
            if integer.len() > format.integer_digits {
                return Ok(format!("%{}", value_as_string(value)));
            }
            let integer = if integer.len() < format.mandatory_integer_digits {
                format!(
                    "{}{}",
                    "0".repeat(format.mandatory_integer_digits - integer.len()),
                    integer
                )
            } else {
                integer
            };
            if format.comma {
                insert_numeric_commas(&integer)
            } else {
                integer
            }
        } else if let Some(exponent_width) = format.exponential_width {
            match format_scientific(
                number
                    .expect("non-direct integer has a real conversion")
                    .abs(),
                format.fractional_digits,
                exponent_width,
            ) {
                Ok(scientific) => scientific,
                Err(Error::IllegalQuantity) => {
                    return Ok(format!("%{}", value_as_string(value)));
                }
                Err(error) => return Err(error),
            }
        } else {
            format_fixed_using_number(
                number.expect("non-direct integer has a real conversion"),
                format,
                value,
            )?
        }
    } else {
        let number = number.expect("non-integer value has a real conversion");
        if let Some(exponent_width) = format.exponential_width {
            match format_scientific(number.abs(), format.fractional_digits, exponent_width) {
                Ok(scientific) => scientific,
                Err(Error::IllegalQuantity) => {
                    return Ok(format!("%{}", value_as_string(value)));
                }
                Err(error) => return Err(error),
            }
        } else {
            format_fixed_using_number(number, format, value)?
        }
    };

    if format.dollar {
        digits.insert(0, '$');
    }
    let trailing = match format.trailing_sign {
        Some('+') => Some(if negative { '-' } else { '+' }),
        Some('-') => Some(if negative { '-' } else { ' ' }),
        _ => None,
    };
    if trailing.is_none() {
        if negative {
            digits.insert(0, '-');
        } else if format.leading_plus {
            digits.insert(0, '+');
        }
    }
    if let Some(sign) = trailing {
        digits.push(sign);
    }

    let length = digits.chars().count();
    if length > format.width {
        return Ok(format!("%{}", value_as_string(value)));
    }
    let fill = if format.asterisk_fill { '*' } else { ' ' };
    Ok(format!(
        "{}{}",
        fill.to_string().repeat(format.width - length),
        digits
    ))
}

fn format_fixed_using_number(
    number: f64,
    format: &UsingNumberFormat,
    original: &Value,
) -> Result<String, Error> {
    let fixed = format!("{:.*}", format.fractional_digits, number.abs());
    let (integer, fraction) = fixed.split_once('.').unwrap_or((&fixed, ""));
    if integer.len() > format.integer_digits {
        return Ok(format!("%{}", value_as_string(original)));
    }
    let integer = if integer.len() < format.mandatory_integer_digits {
        format!(
            "{}{}",
            "0".repeat(format.mandatory_integer_digits - integer.len()),
            integer
        )
    } else {
        integer.to_string()
    };
    let integer = if format.comma {
        insert_numeric_commas(&integer)
    } else {
        integer
    };
    Ok(if format.fractional_digits == 0 {
        integer
    } else {
        format!("{integer}.{fraction}")
    })
}

/// General single-value formatter used by `FORMAT$`.
///
/// This is intentionally a bounded hybrid grammar rather than an implementation
/// of every platform's FORMAT dialect. Numeric fields use PRINT USING's
/// `#`, `0`, `.`, `,`, `$$`, `**`, signs, and `^^` exponential forms. Strings
/// use `!`, `&`, `@...@`, and backslash-delimited fixed fields. Date/time-shaped
/// strings recognize `YYYY`, `YY`, `MM`, `DD`, `HH`, `NN`, `SS`, `AMPM`, and
/// `am/pm`. A backslash before a special placeholder emits that character
/// literally, and `%%` emits one literal percent sign.
pub(crate) fn format_value(value: &Value, format: &str) -> Result<String, Error> {
    if format_contains_date_time_token(format) {
        if let Value::String(text) = value {
            if let Some(formatted) = format_date_time(text, format) {
                return Ok(formatted);
            }
            if looks_like_date_time_value(text) {
                return Err(Error::IllegalQuantity);
            }
        }
    }
    let format = prepare_general_format(format);
    format_using(&format, std::slice::from_ref(value))
}

#[derive(Debug, Clone, Copy)]
struct FormatDateTime {
    date: Option<(u32, u32, u32)>,
    time: Option<(u32, u32, u32)>,
}

fn format_date_time(value: &str, format: &str) -> Option<String> {
    let fields = if let Some((date, time)) = value.split_once(' ') {
        FormatDateTime {
            date: Some(parse_format_date(date)?),
            time: Some(parse_format_time(time)?),
        }
    } else if value.contains(':') {
        FormatDateTime {
            date: None,
            time: Some(parse_format_time(value)?),
        }
    } else {
        FormatDateTime {
            date: Some(parse_format_date(value)?),
            time: None,
        }
    };
    let twelve_hour = format_contains_ampm_token(format);
    let mut output = String::with_capacity(format.len());
    let mut position = 0usize;
    while position < format.len() {
        let remaining = &format[position..];
        if let Some(escaped) = remaining.strip_prefix('\\') {
            if let Some(character) = escaped.chars().next() {
                output.push(character);
                position += 1 + character.len_utf8();
            } else {
                output.push('\\');
                position += 1;
            }
            continue;
        }
        if remaining.starts_with("%%") {
            output.push('%');
            position += 2;
            continue;
        }
        let Some((token, width)) = date_time_token(remaining) else {
            let character = remaining.chars().next()?;
            output.push(character);
            position += character.len_utf8();
            continue;
        };
        let replacement = match token {
            "YYYY" => fields.date.map(|(year, _, _)| format!("{year:04}")),
            "YY" => fields.date.map(|(year, _, _)| format!("{:02}", year % 100)),
            "MM" => fields.date.map(|(_, month, _)| format!("{month:02}")),
            "DD" => fields.date.map(|(_, _, day)| format!("{day:02}")),
            "HH" => fields.time.map(|(hour, _, _)| {
                let hour = if twelve_hour {
                    match hour % 12 {
                        0 => 12,
                        hour => hour,
                    }
                } else {
                    hour
                };
                format!("{hour:02}")
            }),
            "NN" => fields.time.map(|(_, minute, _)| format!("{minute:02}")),
            "SS" => fields.time.map(|(_, _, second)| format!("{second:02}")),
            "AMPM" => fields
                .time
                .map(|(hour, _, _)| if hour < 12 { "AM" } else { "PM" }.to_string()),
            "am/pm" => fields
                .time
                .map(|(hour, _, _)| if hour < 12 { "am" } else { "pm" }.to_string()),
            _ => None,
        };
        if let Some(replacement) = replacement {
            output.push_str(&replacement);
        } else {
            output.push_str(token);
        }
        position += width;
    }
    Some(output)
}

fn looks_like_date_time_value(value: &str) -> bool {
    if let Some((date, time)) = value.split_once(' ') {
        return looks_like_date_time_value(date) && looks_like_date_time_value(time);
    }
    let separator = if value.contains(':') {
        ':'
    } else if value.contains('-') {
        '-'
    } else if value.contains('/') {
        '/'
    } else {
        return false;
    };
    let parts = value.split(separator).collect::<Vec<_>>();
    parts.len() == 3
        && parts.iter().all(|part| {
            !part.is_empty() && part.chars().all(|character| character.is_ascii_digit())
        })
}

fn parse_format_date(value: &str) -> Option<(u32, u32, u32)> {
    let parts = value.split(['-', '/']).collect::<Vec<_>>();
    if parts.len() != 3 || parts.iter().any(|part| part.is_empty()) {
        return None;
    }
    let numbers = parts
        .iter()
        .map(|part| part.parse::<u32>().ok())
        .collect::<Option<Vec<_>>>()?;
    let (year, month, day) = if parts[0].len() == 4 {
        (numbers[0], numbers[1], numbers[2])
    } else {
        (numbers[2], numbers[0], numbers[1])
    };
    if !(1..=9999).contains(&year) || !(1..=12).contains(&month) {
        return None;
    }
    let month_days = [
        31,
        if is_leap_year(year) { 29 } else { 28 },
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31,
    ];
    (day > 0 && day <= month_days[(month - 1) as usize]).then_some((year, month, day))
}

fn parse_format_time(value: &str) -> Option<(u32, u32, u32)> {
    let parts = value.split(':').collect::<Vec<_>>();
    if parts.len() != 3 || parts.iter().any(|part| part.is_empty()) {
        return None;
    }
    let numbers = parts
        .iter()
        .map(|part| part.parse::<u32>().ok())
        .collect::<Option<Vec<_>>>()?;
    let (hour, minute, second) = (numbers[0], numbers[1], numbers[2]);
    (hour <= 23 && minute <= 59 && second <= 59).then_some((hour, minute, second))
}

fn date_time_token(value: &str) -> Option<(&'static str, usize)> {
    ["YYYY", "AMPM", "am/pm", "YY", "MM", "DD", "HH", "NN", "SS"]
        .into_iter()
        .find(|token| value.starts_with(token))
        .map(|token| (token, token.len()))
}

fn format_contains_date_time_token(format: &str) -> bool {
    scan_format_for_token(format, |_| true)
}

fn format_contains_ampm_token(format: &str) -> bool {
    scan_format_for_token(format, |token| matches!(token, "AMPM" | "am/pm"))
}

fn scan_format_for_token(format: &str, matches: impl Fn(&str) -> bool) -> bool {
    let mut position = 0usize;
    while position < format.len() {
        let remaining = &format[position..];
        if let Some(escaped) = remaining.strip_prefix('\\') {
            position += 1 + escaped.chars().next().map_or(0, char::len_utf8);
            continue;
        }
        if remaining.starts_with("%%") {
            position += 2;
            continue;
        }
        if let Some((token, width)) = date_time_token(remaining) {
            if matches(token) {
                return true;
            }
            position += width;
        } else if let Some(character) = remaining.chars().next() {
            position += character.len_utf8();
        }
    }
    false
}

fn prepare_general_format(format: &str) -> String {
    let mut output = String::with_capacity(format.len());
    let mut chars = format.chars().peekable();
    while let Some(character) = chars.next() {
        if character == '%' && chars.peek() == Some(&'%') {
            chars.next();
            output.push('%');
        } else if character == '\\'
            && chars.peek().is_some_and(|next| {
                matches!(
                    next,
                    '!' | '&'
                        | '@'
                        | '#'
                        | '0'
                        | '.'
                        | '$'
                        | '*'
                        | '+'
                        | '-'
                        | ','
                        | '^'
                        | '%'
                        | '_'
                        | '\\'
                )
            })
        {
            output.push('_');
            output.push(chars.next().expect("escaped format character exists"));
        } else {
            output.push(character);
        }
    }
    output
}

fn insert_numeric_commas(integer: &str) -> String {
    let mut output = String::with_capacity(integer.len() + integer.len() / 3);
    for (index, character) in integer.chars().enumerate() {
        if index != 0 && (integer.len() - index) % 3 == 0 {
            output.push(',');
        }
        output.push(character);
    }
    output
}

fn format_scientific(
    number: f64,
    fractional_digits: usize,
    exponent_width: usize,
) -> Result<String, Error> {
    let scientific = format!("{:.*E}", fractional_digits, number);
    let (mantissa, exponent) = scientific
        .split_once('E')
        .ok_or_else(|| Error::syntax("PRINT USING exponential conversion failed"))?;
    let exponent = exponent
        .parse::<i32>()
        .map_err(|_| Error::syntax("PRINT USING exponential conversion failed"))?;
    let exponent_digits = exponent_width.saturating_sub(2);
    let magnitude = exponent.unsigned_abs().to_string();
    if exponent_digits == 0 || magnitude.len() > exponent_digits {
        return Err(Error::IllegalQuantity);
    }
    Ok(format!(
        "{mantissa}E{}{}",
        if exponent < 0 { '-' } else { '+' },
        "0".repeat(exponent_digits - magnitude.len()) + &magnitude
    ))
}

/// Map an Error to a numeric code for the ERR variable.
fn error_code(e: &Error) -> i64 {
    match e {
        Error::DivideByZero => 11,
        Error::IntegerOverflow => 6,
        Error::IntegerUnderflow => 6,
        Error::RealOverflow => 6,
        Error::MathDomain { .. } => 5,
        Error::IntegerRequired => 163,
        Error::TypeMismatch => 13,
        Error::NextWithoutFor { .. } => 1,
        Error::ReturnWithoutGosub => 3,
        Error::OutOfData { .. } => 4,
        Error::Syntax { .. } => 2,
        Error::UserError { code } => *code,
        Error::IllegalQuantity => 5,
        Error::BadSubscript => 9,
        _ => 51,
    }
}

#[cfg(test)]
mod session_interrupt_tests {
    use super::*;
    use std::sync::atomic::{AtomicBool, Ordering};
    use std::sync::Arc;
    use std::time::Duration;

    #[test]
    fn break_stops_execution_but_preserves_program_and_ram() {
        let mut program = Program::new();
        program.insert_line("10 A=42").unwrap();
        program.insert_line("20 WAIT 5000").unwrap();
        program.insert_line("30 END").unwrap();

        let interrupt = Arc::new(AtomicBool::new(false));
        set_thread_interrupt_flag(Some(Arc::clone(&interrupt)));
        let request = Arc::clone(&interrupt);
        let requester = std::thread::spawn(move || {
            std::thread::sleep(Duration::from_millis(20));
            request.store(true, Ordering::SeqCst);
        });

        let mut session = ExecutionSession::new(&program, RunOptions::modern()).unwrap();
        let mut run_output = Vec::new();
        let result = session.run(&mut run_output);
        requester.join().unwrap();
        set_thread_interrupt_flag(None);

        assert_eq!(result, Err(Error::Break));
        assert_eq!(session.active_program(), &program);
        let mut direct_output = Vec::new();
        session
            .execute_direct("PRINT A", &mut direct_output)
            .unwrap();
        assert_eq!(direct_output, b"42\n");
    }
}

#[cfg(test)]
mod device_event_tests {
    use super::*;
    use std::fs::OpenOptions;
    use std::sync::atomic::{AtomicU64, Ordering};

    fn program(lines: &[&str]) -> Program {
        let mut program = Program::new();
        for line in lines {
            program.insert_line(line).unwrap();
        }
        program
    }

    #[test]
    fn mock_serial_data_fires_com_trap_and_obeys_control_modes() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-com-trap-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir(&root).unwrap();
        let path = root.join("serial.mock");
        std::fs::write(&path, b"Q").unwrap();
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .open(&path)
            .unwrap();

        let program = program(&[
            "10 ON COM(1) GOSUB 100",
            "20 COM(1) ON",
            r#"30 PRINT "MAIN""#,
            "40 COM(1) STOP",
            "50 COM(1) ON",
            "60 COM(1) OFF",
            "70 END",
            "100 GET# 7,A$",
            "110 PRINT A$",
            "120 RETURN",
        ]);
        let mut session = ExecutionSession::new(&program, RunOptions::modern()).unwrap();
        session.interpreter.files.insert_serial(7, 1, path, file);
        let mut output = Vec::new();
        let result = session.run(&mut output).unwrap();
        assert_eq!(result.state, SessionState::Terminated(RunTermination::End));
        assert_eq!(String::from_utf8(output).unwrap(), "Q\nMAIN\n");
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn com_poll_errors_are_latched_then_disable_the_trap() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let path = std::env::temp_dir().join(format!(
            "modernbasic-com-error-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let file = OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)
            .open(&path)
            .unwrap();
        let mut session = ExecutionSession::new(&Program::new(), RunOptions::modern()).unwrap();
        session
            .interpreter
            .files
            .insert_serial(7, 1, path.clone(), file);
        session.interpreter.com_traps.insert(
            1,
            ComEventTrap {
                target: Some(100),
                channel: 7,
                mode: EventMode::On,
                active: false,
                latched_error: None,
            },
        );

        assert_eq!(session.interpreter.pending_event().unwrap(), None);
        assert!(matches!(
            session.interpreter.pending_event(),
            Err(Error::Io(_))
        ));
        assert_eq!(session.interpreter.com_traps[&1].mode, EventMode::Off);
        assert!(session.interpreter.com_traps[&1].latched_error.is_none());
        std::fs::remove_file(path).unwrap();
    }

    #[test]
    fn failed_presentations_remain_dirty_and_report_a_screen_error() {
        let (sender, receiver) = std::sync::mpsc::channel();
        crate::screen::set_thread_screen_sender(Some(sender));
        let mut session = ExecutionSession::new(&Program::new(), RunOptions::modern()).unwrap();
        session
            .interpreter
            .graphics
            .set_screen(8, 8, "#000000")
            .unwrap();
        session
            .interpreter
            .graphics
            .scene_mut()
            .raw_command("definitely-not-an-artist-command")
            .unwrap();
        session.interpreter.presentation_dirty = true;

        assert!(!session
            .interpreter
            .present_graphics_scene(false, ScreenView::Graphics));
        assert!(session.interpreter.presentation_dirty);
        assert!(session.interpreter.presentation_render_failed);
        assert!(session.interpreter.graphics.scene_is_dirty());

        // Automatic presentation must retry through the checked renderer and
        // must not enqueue a source-only frame that marks the scene clean.
        session.interpreter.present_dirty_graphics_scene();
        assert!(session.interpreter.presentation_dirty);
        assert!(session.interpreter.graphics.scene_is_dirty());
        crate::screen::set_thread_screen_sender(None);

        let events = receiver.try_iter().collect::<Vec<_>>();
        assert!(events
            .iter()
            .any(|event| matches!(event, ScreenEvent::SetError(_))));
        assert!(!events
            .iter()
            .any(|event| matches!(event, ScreenEvent::Present { .. })));
    }

    #[test]
    fn mock_joystick_press_fires_strig_trap_and_obeys_control_modes() {
        crate::devices::close_joysticks();
        let program = program(&[
            "10 ON STRIG(0) GOSUB 100",
            "20 STRIG ON",
            r#"30 PRINT "MAIN""#,
            "40 STRIG STOP",
            "50 STRIG ON",
            "60 STRIG OFF",
            "70 END",
            r#"100 PRINT "TRIG""#,
            "110 RETURN",
        ]);
        let mut session = ExecutionSession::new(&program, RunOptions::modern()).unwrap();
        let mut output = Vec::new();
        assert_eq!(
            session.step(&mut output).unwrap().state,
            SessionState::Paused
        );
        assert_eq!(
            session.step(&mut output).unwrap().state,
            SessionState::Paused
        );
        crate::devices::mock_strig_button(0, true);
        assert_eq!(
            session.resume(&mut output).unwrap().state,
            SessionState::Terminated(RunTermination::End)
        );
        assert_eq!(String::from_utf8(output).unwrap(), "TRIG\nMAIN\n");
    }
}
