//! Deterministic native output-column accounting for BASIC formatting.

/// Native comma-separated `PRINT` zone width.
pub(crate) const PRINT_ZONE_WIDTH: usize = 14;

/// Advance a zero-based output column through UTF-8 text.
///
/// Newline and carriage-return characters reset the column. Every other
/// Unicode scalar occupies one deterministic column; terminal-specific width
/// tables and control-sequence interpretation are deliberately not used.
pub(crate) fn advance_column(mut column: usize, text: &str) -> usize {
    for character in text.chars() {
        if matches!(character, '\n' | '\r') {
            column = 0;
        } else {
            column = column.saturating_add(1);
        }
    }
    column
}

/// Advance through bytes already present in an append target.
///
/// Valid UTF-8 uses scalar-column accounting. Invalid legacy data falls back
/// to one column per byte while retaining newline reset behavior.
pub(crate) fn advance_column_bytes(column: usize, bytes: &[u8]) -> usize {
    match std::str::from_utf8(bytes) {
        Ok(text) => advance_column(column, text),
        Err(_) => bytes.iter().fold(column, |column, byte| {
            if matches!(byte, b'\n' | b'\r') {
                0
            } else {
                column.saturating_add(1)
            }
        }),
    }
}

/// Spaces needed to enter the next fixed-width comma zone.
pub(crate) fn spaces_to_next_zone(column: usize) -> usize {
    PRINT_ZONE_WIDTH - (column % PRINT_ZONE_WIDTH)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn columns_count_scalars_and_reset_on_line_controls() {
        assert_eq!(advance_column(2, "Aé"), 4);
        assert_eq!(advance_column(8, "A\nBC"), 2);
        assert_eq!(advance_column_bytes(0, &[0xff, b'A', b'\n', b'B']), 1);
    }

    #[test]
    fn comma_zones_always_advance_to_the_next_zone() {
        assert_eq!(spaces_to_next_zone(0), 14);
        assert_eq!(spaces_to_next_zone(1), 13);
        assert_eq!(spaces_to_next_zone(14), 14);
        assert_eq!(spaces_to_next_zone(27), 1);
    }
}
