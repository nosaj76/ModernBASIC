use std::fs::File;
use std::io::{self, BufReader, Write};
use std::path::{Path, PathBuf};

use modernbasic::error::Error;
use modernbasic::eval::evaluate_value_direct;
use modernbasic::graph::{
    export_functions_csv, render_function_svg, render_functions_svg, render_histogram_svg,
    render_parametric_svg, render_polar_svg, render_scatter_svg, GraphOptions, GraphPalette,
    HistogramOptions,
};
use modernbasic::integer::NumericMode;
use modernbasic::interpreter::{run, run_with_input, ExecutionSession, RunOptions, SessionState};
use modernbasic::program::{Program, DEFAULT_MAX_SOURCE_LINE_BYTES};
use modernbasic::real::BasicReal;
use modernbasic::repl::run_repl;
use modernbasic::shell::{run_shell, ColorPrefs, GraphicsScaleMode, ShellOptions};
use modernbasic::synth::{scan_audio_hardware, SynthProfile, MAX_OSCILLATOR_COUNT, VOICE_COUNT};
use modernbasic::tokens::{detokenize, tokenize};
use modernbasic::value::Value;

const HELP: &str = r#"modernbasic - classic line-numbered BASIC with modern capabilities

USAGE:
  modernbasic
  modernbasic <command> [arguments]

DEFAULT:
  With no arguments, open the native ModernBASIC graphical shell.

COMMANDS:
  shell [options] [program.bas]
      Open the frameless system hub and independent BASIC program windows.
  repl [run options]
      Open the terminal READY. environment.
  eval <expression>
      Evaluate one ModernBASIC expression.
  tokenize <line>
      Tokenize and print one numbered BASIC source line.
  list
      Read a BASIC program from standard input and print its canonical listing.
  run [options] [program.bas|-] [-- arguments...]
      Execute a numbered program file, or standard input when omitted or '-'.
  graph <expr> <output.svg> <xmin> <xmax> <ymin> <ymax> [options]
      Render a function of X as deterministic SVG.
  graph-multi <output.svg> <xmin> <xmax> <ymin> <ymax> <expr>... [options]
      Render up to 16 functions of X in one SVG file.
  graph-parametric <x-expr> <y-expr> <output.svg> <tmin> <tmax> <xmin> <xmax> <ymin> <ymax> [options]
      Render X=f(T), Y=g(T).
  graph-polar <r-expr> <output.svg> <tmin> <tmax> <xmin> <xmax> <ymin> <ymax> [options]
      Render R=f(T), with T measured in radians.
  graph-scatter <x-list> <y-list> <output.svg> <xmin> <xmax> <ymin> <ymax> [options]
      Render two BASIC list expressions as paired points.
  graph-histogram <list> <output.svg> <bins> <xmin> <xmax> [options]
      Render a BASIC list expression with automatic count scaling.
  graph-data <output.csv> <xmin> <xmax> <samples> <expr>...
      Export sampled functions as deterministic CSV.
  audio-profile
      Scan host PCM playback and recommend a software-synthesis profile.
  version
      Show the build version.
  help
      Show this help.

Shell/program-window options:
  --graphics-scale <fit|stretch>
  --screen-color <#rrggbb>  --text-color <#rrggbb>
  --mixed-case  --uppercase
  The packaged programs directory is the default BASIC user root.
  Sandboxed file and directory lookup is case-insensitive.
  Hub commands: LOAD, NEW, DELETE, STOP, CLOSE, FOCUS, TASKS, DIR, CD, COLOR,
                RESTART, SHUTDOWN.
  Ctrl+F1 switches between the System Command Interface and Program Manager.
  In Program Manager: S or Ctrl+Escape stops; Delete closes; Enter focuses.
  DIR groups folders, .bas programs, and other files in that order.
  Program windows provide READY., RUN, LIST, EDIT, SAVE, STEP, CONT,
  RENUM, numbered-line entry, direct statements, and expressions.
  Up/Down browse history; EDIT changes them to stored-line navigation.
  Ctrl+Escape requests BREAK in a program window; Escape exits EDIT.
  Ctrl+V or Shift+Insert pastes the clipboard; middle-click pastes PRIMARY.

Run options:
  --continue-on-stop  --start-line <u64>  --seed <u64>
  --max-steps <usize>
  --max-storage-bytes <usize>  --max-matrix-operations <usize>
  --synth-profile <auto|compact|standard|extended|maximum>
  --synth-voices <1..16>  --synth-oscillators <1..8>
  --file-root <dir>  --output-root <dir>  --soundfont-root <dir>
  --network  --max-network-bytes <usize>
  --graph-output <file.svg>
  --env <NAME=VALUE> (repeatable; no ambient environment is inherited)
  --open-graph

Graph options:
  --width <64..8192>  --height <64..8192>  --samples <2..1000000>
  --grid <0..100>  --palette <classic|contrast|mono>
"#;

fn main() {
    if let Err(e) = run_cli() {
        eprintln!("error: {e}");
        std::process::exit(1);
    }
}

fn run_cli() -> Result<(), Error> {
    let arguments = std::env::args().skip(1).collect::<Vec<_>>();
    if arguments.is_empty() {
        return execute_default_shell();
    }
    let mut args = arguments.into_iter();
    let cmd = args.next().expect("checked non-empty arguments");

    match cmd.as_str() {
        "help" | "--help" | "-h" => print!("{HELP}"),
        "version" | "--version" | "-V" => println!("ModernBASIC {}", env!("CARGO_PKG_VERSION")),
        "audio-profile" => {
            if args.next().is_some() {
                return Err(Error::syntax("usage: modernbasic audio-profile"));
            }
            let hardware = scan_audio_hardware();
            let arrangement = hardware.recommended.arrangement();
            let memory = hardware
                .memory_mib
                .map(|value| format!("{value} MiB"))
                .unwrap_or_else(|| "UNKNOWN".to_string());
            println!("PLAYBACK BACKEND: {}", hardware.playback_backend.name());
            println!("LOGICAL CPUS: {}", hardware.logical_cpus);
            println!("MEMORY: {memory}");
            println!("RECOMMENDED SYNTH PROFILE: {}", hardware.recommended.name());
            println!(
                "ARRANGEMENT: {} VOICES X {} OSCILLATORS",
                arrangement.voices, arrangement.oscillators
            );
        }
        "eval" => {
            let expr = args.collect::<Vec<_>>().join(" ");
            if expr.trim().is_empty() {
                return Err(Error::syntax("usage: eval <expression>"));
            }
            let value = evaluate_value_direct(NumericMode::Modern, &expr)?;
            println!("{value}");
        }
        "tokenize" => {
            let line = args.collect::<Vec<_>>().join(" ");
            if line.trim().is_empty() {
                return Err(Error::syntax("usage: tokenize <line>"));
            }
            let tokens = tokenize(&line)?;
            let text = detokenize(&tokens);
            println!("{text}");
        }
        "list" => {
            let mut prog = Program::new();
            read_program_from_stdin(&mut prog)?;
            let stdout = io::stdout();
            let mut handle = stdout.lock();
            for (n, body) in prog.list() {
                writeln!(handle, "{n} {body}")?;
            }
        }
        "graph" => execute_graph_command(&mut args)?,
        "graph-multi" => execute_multi_graph_command(&mut args)?,
        "graph-parametric" => execute_parametric_graph_command(&mut args)?,
        "graph-polar" => execute_polar_graph_command(&mut args)?,
        "graph-scatter" => execute_scatter_graph_command(&mut args)?,
        "graph-histogram" => execute_histogram_graph_command(&mut args)?,
        "graph-data" => execute_graph_data_command(&mut args)?,
        "shell" | "gui" => execute_shell_command(&mut args)?,
        "repl" | "--text" => execute_repl_command(&mut args)?,
        "run" => {
            let (mut options, program_path, continue_on_stop) = parse_run_args(&mut args)?;
            if options.file_root.is_none() {
                options.file_root = Some(default_file_root(program_path.as_deref())?);
            }
            if let Some(path) = program_path.as_deref().filter(|path| *path != "-") {
                let canonical = std::fs::canonicalize(path)?;
                options.asset_root = Some(
                    canonical
                        .parent()
                        .ok_or(Error::InvalidFilePath)?
                        .to_path_buf(),
                );
            }
            configure_default_output_paths(&mut options);
            let mut prog = Program::new();
            let file_backed = program_path.as_deref().is_some_and(|path| path != "-");
            if let Some(path) = program_path.filter(|path| path != "-") {
                let file = File::open(path)?;
                let mut source = BufReader::new(file);
                prog.read_from(&mut source, DEFAULT_MAX_SOURCE_LINE_BYTES)?;
            } else {
                read_program_from_stdin(&mut prog)?;
            }
            let stdout = io::stdout();
            let mut handle = stdout.lock();
            if file_backed {
                let stdin = io::stdin();
                let mut runtime_input = stdin.lock();
                if continue_on_stop {
                    run_continuing(&prog, options, &mut runtime_input, &mut handle)?;
                } else {
                    run_with_input(&prog, options, &mut runtime_input, &mut handle)?;
                }
            } else if continue_on_stop {
                let mut runtime_input = io::empty();
                run_continuing(&prog, options, &mut runtime_input, &mut handle)?;
            } else {
                run(&prog, options, &mut handle)?;
            }
        }
        _ => return Err(Error::syntax(format!("unknown command: {cmd}"))),
    }
    Ok(())
}

fn execute_default_shell() -> Result<(), Error> {
    let mut run_options = RunOptions::modern();
    let root = default_file_root(None)?;
    run_options.file_root = Some(root);
    configure_default_output_paths(&mut run_options);
    run_options.open_graph_window = false;
    let color_prefs = ColorPrefs::load(run_options.file_root.as_deref())?;
    let mut shell_options = ShellOptions::new(run_options.clone());
    shell_options.screen_color = color_prefs.screen_color;
    shell_options.text_color = color_prefs.text_color;
    match run_shell(shell_options) {
        Ok(()) => Ok(()),
        Err(error) => {
            eprintln!("graphical shell unavailable: {error}");
            eprintln!("falling back to terminal READY. mode");
            run_terminal_repl(run_options)
        }
    }
}

fn run_terminal_repl(mut options: RunOptions) -> Result<(), Error> {
    if options.file_root.is_none() {
        options.file_root = Some(default_file_root(None)?);
    }
    configure_default_output_paths(&mut options);
    options.open_graph_window = true;
    let stdin = io::stdin();
    let stdout = io::stdout();
    run_repl(&mut stdin.lock(), &mut stdout.lock(), options)
}

fn execute_repl_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    let (options, path, continue_on_stop) = parse_run_args(args)?;
    if path.is_some() || continue_on_stop {
        return Err(Error::syntax(
            "usage: repl [--start-line <u64>] [--seed <u64>] [--max-steps <usize>] [--max-storage-bytes <usize>] [--max-matrix-operations <usize>] [--synth-profile <auto|compact|standard|extended|maximum>] [--synth-voices <1..16>] [--synth-oscillators <1..8>] [--file-root <dir>] [--output-root <dir>] [--soundfont-root <dir>] [--network] [--max-network-bytes <usize>] [--graph-output <file.svg>]",
        ));
    }
    run_terminal_repl(options)
}

fn execute_shell_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    run_shell(parse_shell_args(args)?)
}

fn parse_shell_args(args: &mut impl Iterator<Item = String>) -> Result<ShellOptions, Error> {
    const USAGE: &str = "usage: shell [--fullscreen|--windowed] [--width <640..8192>] [--height <400..8192>] [--display-profile <compact|desktop|hd|fullhd>] [--graphics-scale <fit|stretch>] [--screen-color <#rrggbb>] [--text-color <#rrggbb>] [--mixed-case|--uppercase] [run options] [program.bas]\n       (F11 runtime fullscreen toggle is disabled)";
    let mut forwarded = Vec::new();
    let mut width = None;
    let mut height = None;
    let mut display_profile = None;
    let mut graphics_scale = None;
    let mut screen_color = None;
    let mut text_color = None;
    let mut fullscreen = false;
    let mut uppercase = true;
    let values = args.collect::<Vec<_>>();
    let mut index = 0;
    while index < values.len() {
        match values[index].as_str() {
            "--fullscreen" => fullscreen = true,
            "--windowed" => fullscreen = false,
            "--mixed-case" => uppercase = false,
            "--uppercase" => uppercase = true,
            "--screen-color" if screen_color.is_none() => {
                index += 1;
                let value = values.get(index).ok_or_else(|| Error::syntax(USAGE))?;
                screen_color = Some(ColorPrefs::normalize_hex(value)?);
            }
            "--text-color" if text_color.is_none() => {
                index += 1;
                let value = values.get(index).ok_or_else(|| Error::syntax(USAGE))?;
                text_color = Some(ColorPrefs::normalize_hex(value)?);
            }
            "--width" => {
                index += 1;
                let value = values.get(index).ok_or_else(|| Error::syntax(USAGE))?;
                let value = value.parse::<u32>().map_err(|_| Error::syntax(USAGE))?;
                if !(640..=8192).contains(&value) {
                    return Err(Error::syntax("shell width must be in 640..=8192"));
                }
                width = Some(value);
            }
            "--height" => {
                index += 1;
                let value = values.get(index).ok_or_else(|| Error::syntax(USAGE))?;
                let value = value.parse::<u32>().map_err(|_| Error::syntax(USAGE))?;
                if !(400..=8192).contains(&value) {
                    return Err(Error::syntax("shell height must be in 400..=8192"));
                }
                height = Some(value);
            }
            "--display-profile" if display_profile.is_none() => {
                index += 1;
                let value = values.get(index).ok_or_else(|| Error::syntax(USAGE))?;
                display_profile = Some(match value.as_str() {
                    "compact" => (800, 600),
                    "desktop" => (1_100, 760),
                    "hd" => (1_280, 720),
                    "fullhd" => (1_920, 1_080),
                    _ => return Err(Error::syntax(USAGE)),
                });
            }
            "--graphics-scale" if graphics_scale.is_none() => {
                index += 1;
                let value = values.get(index).ok_or_else(|| Error::syntax(USAGE))?;
                graphics_scale = Some(match value.as_str() {
                    "fit" => GraphicsScaleMode::Fit,
                    "stretch" => GraphicsScaleMode::Stretch,
                    _ => return Err(Error::syntax(USAGE)),
                });
            }
            value => forwarded.push(value.to_string()),
        }
        index += 1;
    }

    let (mut run_options, path, continue_on_stop) = parse_run_args(&mut forwarded.into_iter())?;
    if continue_on_stop {
        return Err(Error::syntax(USAGE));
    }
    if run_options.file_root.is_none() {
        run_options.file_root = Some(default_file_root(path.as_deref())?);
    }
    configure_default_output_paths(&mut run_options);
    run_options.open_graph_window = false;

    let mut color_prefs = ColorPrefs::load(run_options.file_root.as_deref())?;
    if let Some(color) = screen_color {
        color_prefs.screen_color = color;
    }
    if let Some(color) = text_color {
        color_prefs.text_color = color;
    }
    let mut options = ShellOptions::new(run_options);
    if let Some((profile_width, profile_height)) = display_profile {
        options.width = profile_width;
        options.height = profile_height;
    }
    if let Some(width) = width {
        options.width = width;
    }
    if let Some(height) = height {
        options.height = height;
    }
    options.fullscreen = fullscreen;
    if let Some(scale) = graphics_scale {
        options.graphics_scale = scale;
    }
    options.uppercase_input = uppercase;
    options.initial_program = path;
    options.screen_color = color_prefs.screen_color;
    options.text_color = color_prefs.text_color;
    Ok(options)
}

fn execute_graph_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    const USAGE: &str = "usage: graph <expr> <output.svg> <xmin> <xmax> <ymin> <ymax> [--width <64..8192>] [--height <64..8192>] [--samples <2..1000000>] [--grid <0..100>] [--palette <classic|contrast|mono>]";
    let mode = NumericMode::Modern;
    let expression = required_argument(args, USAGE)?;
    let output = required_argument(args, USAGE)?;
    let mut options = graph_bounds(args, USAGE)?;
    parse_graph_options(args, &mut options, USAGE)?;
    let svg = render_function_svg(mode, &expression, options)?;
    std::fs::write(output, svg)?;
    Ok(())
}

fn execute_multi_graph_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    const USAGE: &str = "usage: graph-multi <output.svg> <xmin> <xmax> <ymin> <ymax> <expr>... [--width <64..8192>] [--height <64..8192>] [--samples <2..1000000>] [--grid <0..100>] [--palette <classic|contrast|mono>]";
    let mode = NumericMode::Modern;
    let output = required_argument(args, USAGE)?;
    let mut options = graph_bounds(args, USAGE)?;
    let mut expressions = Vec::new();
    while let Some(argument) = args.next() {
        if argument.starts_with("--") {
            let value = required_argument(args, USAGE)?;
            apply_graph_option(&argument, &value, &mut options, USAGE)?;
        } else {
            expressions.push(argument);
        }
    }
    let expression_refs = expressions.iter().map(String::as_str).collect::<Vec<_>>();
    let svg = render_functions_svg(mode, &expression_refs, options)?;
    std::fs::write(output, svg)?;
    Ok(())
}

fn execute_parametric_graph_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    const USAGE: &str = "usage: graph-parametric <x-expr> <y-expr> <output.svg> <tmin> <tmax> <xmin> <xmax> <ymin> <ymax> [--width <64..8192>] [--height <64..8192>] [--samples <2..1000000>] [--grid <0..100>] [--palette <classic|contrast|mono>]";
    let mode = NumericMode::Modern;
    let x_expression = required_argument(args, USAGE)?;
    let y_expression = required_argument(args, USAGE)?;
    let output = required_argument(args, USAGE)?;
    let parameter_min = required_f64(args, USAGE)?;
    let parameter_max = required_f64(args, USAGE)?;
    let mut options = graph_bounds(args, USAGE)?;
    parse_graph_options(args, &mut options, USAGE)?;
    let svg = render_parametric_svg(
        mode,
        &x_expression,
        &y_expression,
        parameter_min,
        parameter_max,
        options,
    )?;
    std::fs::write(output, svg)?;
    Ok(())
}

fn execute_polar_graph_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    const USAGE: &str = "usage: graph-polar <r-expr> <output.svg> <tmin> <tmax> <xmin> <xmax> <ymin> <ymax> [--width <64..8192>] [--height <64..8192>] [--samples <2..1000000>] [--grid <0..100>] [--palette <classic|contrast|mono>]";
    let mode = NumericMode::Modern;
    let radius_expression = required_argument(args, USAGE)?;
    let output = required_argument(args, USAGE)?;
    let angle_min = required_f64(args, USAGE)?;
    let angle_max = required_f64(args, USAGE)?;
    let mut options = graph_bounds(args, USAGE)?;
    parse_graph_options(args, &mut options, USAGE)?;
    let svg = render_polar_svg(mode, &radius_expression, angle_min, angle_max, options)?;
    std::fs::write(output, svg)?;
    Ok(())
}

fn execute_scatter_graph_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    const USAGE: &str = "usage: graph-scatter <x-list> <y-list> <output.svg> <xmin> <xmax> <ymin> <ymax> [--width <64..8192>] [--height <64..8192>] [--samples <2..1000000>] [--grid <0..100>] [--palette <classic|contrast|mono>]";
    let mode = NumericMode::Modern;
    let x_expression = required_argument(args, USAGE)?;
    let y_expression = required_argument(args, USAGE)?;
    let output = required_argument(args, USAGE)?;
    let mut options = graph_bounds(args, USAGE)?;
    parse_graph_options(args, &mut options, USAGE)?;
    let x_values = evaluate_real_list(mode, &x_expression)?;
    let y_values = evaluate_real_list(mode, &y_expression)?;
    let svg = render_scatter_svg(&x_values, &y_values, options)?;
    std::fs::write(output, svg)?;
    Ok(())
}

fn execute_histogram_graph_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    const USAGE: &str = "usage: graph-histogram <list> <output.svg> <bins> <xmin> <xmax> [--width <64..8192>] [--height <64..8192>] [--grid <0..100>] [--palette <classic|contrast|mono>]";
    let mode = NumericMode::Modern;
    let expression = required_argument(args, USAGE)?;
    let output = required_argument(args, USAGE)?;
    let bins = required_usize(args, USAGE)?;
    let mut options =
        HistogramOptions::new(required_f64(args, USAGE)?, required_f64(args, USAGE)?, bins);
    while let Some(flag) = args.next() {
        let value = required_argument(args, USAGE)?;
        match flag.as_str() {
            "--width" => options.width = parse_usize(&value, USAGE)?,
            "--height" => options.height = parse_usize(&value, USAGE)?,
            "--grid" => options.grid_lines = parse_usize(&value, USAGE)?,
            "--palette" => options.palette = parse_graph_palette(&value, USAGE)?,
            _ => return Err(Error::syntax(USAGE)),
        }
    }
    let values = evaluate_real_list(mode, &expression)?;
    let svg = render_histogram_svg(&values, options)?;
    std::fs::write(output, svg)?;
    Ok(())
}

fn execute_graph_data_command(args: &mut impl Iterator<Item = String>) -> Result<(), Error> {
    const USAGE: &str = "usage: graph-data <output.csv> <xmin> <xmax> <samples> <expr>...";
    let mode = NumericMode::Modern;
    let output = required_argument(args, USAGE)?;
    let x_min = required_f64(args, USAGE)?;
    let x_max = required_f64(args, USAGE)?;
    let samples = required_usize(args, USAGE)?;
    let expressions = args.collect::<Vec<_>>();
    let expression_refs = expressions.iter().map(String::as_str).collect::<Vec<_>>();
    let csv = export_functions_csv(mode, &expression_refs, x_min, x_max, samples)?;
    std::fs::write(output, csv)?;
    Ok(())
}

fn graph_bounds(
    args: &mut impl Iterator<Item = String>,
    usage: &'static str,
) -> Result<GraphOptions, Error> {
    Ok(GraphOptions::new(
        required_f64(args, usage)?,
        required_f64(args, usage)?,
        required_f64(args, usage)?,
        required_f64(args, usage)?,
    ))
}

fn parse_graph_options(
    args: &mut impl Iterator<Item = String>,
    options: &mut GraphOptions,
    usage: &'static str,
) -> Result<(), Error> {
    while let Some(flag) = args.next() {
        let value = required_argument(args, usage)?;
        apply_graph_option(&flag, &value, options, usage)?;
    }
    Ok(())
}

fn apply_graph_option(
    flag: &str,
    value: &str,
    options: &mut GraphOptions,
    usage: &'static str,
) -> Result<(), Error> {
    match flag {
        "--width" => options.width = parse_usize(value, usage)?,
        "--height" => options.height = parse_usize(value, usage)?,
        "--samples" => options.samples = parse_usize(value, usage)?,
        "--grid" => options.grid_lines = parse_usize(value, usage)?,
        "--palette" => options.palette = parse_graph_palette(value, usage)?,
        _ => return Err(Error::syntax(usage)),
    }
    Ok(())
}

fn required_argument(
    args: &mut impl Iterator<Item = String>,
    usage: &'static str,
) -> Result<String, Error> {
    args.next().ok_or_else(|| Error::syntax(usage))
}

fn required_f64(
    args: &mut impl Iterator<Item = String>,
    usage: &'static str,
) -> Result<f64, Error> {
    required_argument(args, usage)?
        .parse::<f64>()
        .map_err(|_| Error::syntax(usage))
}

fn required_usize(
    args: &mut impl Iterator<Item = String>,
    usage: &'static str,
) -> Result<usize, Error> {
    required_argument(args, usage)?
        .parse::<usize>()
        .map_err(|_| Error::syntax(usage))
}

fn parse_usize(value: &str, usage: &'static str) -> Result<usize, Error> {
    value.parse::<usize>().map_err(|_| Error::syntax(usage))
}

fn parse_graph_palette(value: &str, usage: &'static str) -> Result<GraphPalette, Error> {
    match value.to_ascii_lowercase().as_str() {
        "classic" => Ok(GraphPalette::Classic),
        "contrast" => Ok(GraphPalette::Contrast),
        "mono" | "monochrome" => Ok(GraphPalette::Monochrome),
        _ => Err(Error::syntax(usage)),
    }
}

fn evaluate_real_list(mode: NumericMode, expression: &str) -> Result<Vec<f64>, Error> {
    let Value::List(values) = evaluate_value_direct(mode, expression)? else {
        return Err(Error::TypeMismatch);
    };
    values
        .into_iter()
        .map(|value| match value {
            Value::Integer(value) => BasicReal::from_integer(value).map(BasicReal::value),
            Value::Real(value) => Ok(value.value()),
            Value::Complex(value) if value.is_real() => Ok(value.real().value()),
            Value::Complex(_) | Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
        })
        .collect()
}

fn read_program_from_stdin(prog: &mut Program) -> Result<(), Error> {
    let stdin = io::stdin();
    prog.read_from(&mut stdin.lock(), DEFAULT_MAX_SOURCE_LINE_BYTES)
}

fn default_file_root(program_path: Option<&str>) -> Result<PathBuf, Error> {
    let programs_root = discover_programs_root();
    if let Some(path) = program_path.filter(|path| *path != "-") {
        let path = Path::new(path);
        if let (Some(root), Ok(program)) = (&programs_root, std::fs::canonicalize(path)) {
            let root = std::fs::canonicalize(root)?;
            if program.starts_with(&root) {
                return Ok(root);
            }
        }
        if let Some(parent) = path
            .parent()
            .filter(|parent| !parent.as_os_str().is_empty())
        {
            return Ok(parent.to_path_buf());
        }
    }
    if let Some(root) = programs_root {
        return Ok(root);
    }
    std::env::current_dir().map_err(Error::from)
}

fn discover_programs_root() -> Option<PathBuf> {
    let current = std::env::current_dir().ok()?;
    if current.file_name().is_some_and(|name| name == "programs") && current.is_dir() {
        return Some(current);
    }
    let direct = current.join("programs");
    if direct.is_dir() {
        return Some(direct);
    }
    let executable = std::env::current_exe().ok()?;
    for ancestor in executable.ancestors().skip(1) {
        let candidate = ancestor.join("programs");
        if candidate.is_dir() {
            return Some(candidate);
        }
    }
    None
}

fn configure_default_output_paths(options: &mut RunOptions) {
    if options.output_root.is_none() {
        options.output_root = options.file_root.as_deref().map(|file_root| {
            if file_root.file_name().is_some_and(|name| name == "programs") {
                if let Some(parent) = file_root.parent() {
                    let output = parent.join("output");
                    if output.is_dir() {
                        return output;
                    }
                }
            }
            file_root.to_path_buf()
        });
    }
    if options.graph_output.is_none() {
        options.graph_output = options
            .output_root
            .as_ref()
            .map(|root| root.join("modernbasic-graph.svg"));
    }
}

fn parse_run_args(
    args: &mut impl Iterator<Item = String>,
) -> Result<(RunOptions, Option<String>, bool), Error> {
    const USAGE: &str =
        "usage: modernbasic run [--continue-on-stop] [--start-line <u64>] [--seed <u64>] [--max-steps <usize>] [--max-storage-bytes <usize>] [--max-matrix-operations <usize>] [--file-root <dir>] [--output-root <dir>] [--soundfont-root <dir>] [--network] [--max-network-bytes <usize>] [--graph-output <file.svg>] [--env <NAME=VALUE>]... [--open-graph] [program.bas|-] [-- arguments...]";

    let mut options = RunOptions::modern();
    let mut start_line = None;
    let mut random_seed = None;
    let mut max_steps = None;
    let mut max_storage_bytes = None;
    let mut max_matrix_operations = None;
    let mut network_enabled = false;
    let mut max_network_bytes = None;
    let mut synth_profile = None;
    let mut synth_voice_count = None;
    let mut synth_oscillator_count = None;
    let mut file_root = None;
    let mut output_root = None;
    let mut soundfont_root = None;
    let mut graph_output = None;
    let mut open_graph_window = false;
    let mut continue_on_stop = false;
    let mut environment = Vec::new();
    let mut command_line = String::new();
    let mut path = None;
    while let Some(argument) = args.next() {
        match argument.as_str() {
            "modern" | "modernbasic" | "legacy" => {
                return Err(Error::syntax(
                    "ModernBASIC is the only language; do not pass a dialect argument",
                ));
            }
            "--seed" if random_seed.is_none() => {
                let seed = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let seed = seed
                    .parse::<u64>()
                    .map_err(|_| Error::syntax("random seed must be an unsigned 64-bit integer"))?;
                random_seed = Some(seed);
            }
            "--start-line" if start_line.is_none() => {
                let line = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let line = line
                    .parse::<u64>()
                    .map_err(|_| Error::syntax("start line must be an unsigned 64-bit integer"))?;
                start_line = Some(line);
            }
            "--max-steps" if max_steps.is_none() => {
                let steps = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let steps = steps.parse::<usize>().map_err(|_| {
                    Error::syntax("step limit must be a positive native step count")
                })?;
                if steps == 0 {
                    return Err(Error::syntax(
                        "step limit must be a positive native step count",
                    ));
                }
                max_steps = Some(steps);
            }
            "--max-storage-bytes" if max_storage_bytes.is_none() => {
                let bytes = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let bytes = bytes.parse::<usize>().map_err(|_| {
                    Error::syntax("storage limit must be a non-negative native byte count")
                })?;
                max_storage_bytes = Some(bytes);
            }
            "--max-matrix-operations" if max_matrix_operations.is_none() => {
                let operations = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let operations = operations.parse::<usize>().map_err(|_| {
                    Error::syntax("matrix operation limit must be a non-negative native step count")
                })?;
                max_matrix_operations = Some(operations);
            }
            "--network" if !network_enabled => network_enabled = true,
            "--max-network-bytes" if max_network_bytes.is_none() => {
                let bytes = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let bytes = bytes.parse::<usize>().map_err(|_| {
                    Error::syntax("network limit must be a positive native byte count")
                })?;
                if bytes == 0 {
                    return Err(Error::syntax(
                        "network limit must be a positive native byte count",
                    ));
                }
                max_network_bytes = Some(bytes);
            }
            "--synth-profile" if synth_profile.is_none() => {
                let value = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                synth_profile = Some(SynthProfile::parse(&value)?);
            }
            "--synth-voices" if synth_voice_count.is_none() => {
                let value = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let count = value
                    .parse::<usize>()
                    .map_err(|_| Error::syntax("synth voice count must be in 1..=16"))?;
                if !(1..=VOICE_COUNT).contains(&count) {
                    return Err(Error::syntax("synth voice count must be in 1..=16"));
                }
                synth_voice_count = Some(count);
            }
            "--synth-oscillators" if synth_oscillator_count.is_none() => {
                let value = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let count = value
                    .parse::<usize>()
                    .map_err(|_| Error::syntax("synth oscillator count must be in 1..=8"))?;
                if !(1..=MAX_OSCILLATOR_COUNT).contains(&count) {
                    return Err(Error::syntax("synth oscillator count must be in 1..=8"));
                }
                synth_oscillator_count = Some(count);
            }
            "--continue-on-stop" if !continue_on_stop => continue_on_stop = true,
            "--file-root" if file_root.is_none() => {
                file_root = Some(args.next().ok_or_else(|| Error::syntax(USAGE))?.into());
            }
            "--output-root" if output_root.is_none() => {
                output_root = Some(args.next().ok_or_else(|| Error::syntax(USAGE))?.into());
            }
            "--soundfont-root" if soundfont_root.is_none() => {
                soundfont_root = Some(args.next().ok_or_else(|| Error::syntax(USAGE))?.into());
            }
            "--graph-output" if graph_output.is_none() => {
                graph_output = Some(args.next().ok_or_else(|| Error::syntax(USAGE))?.into());
            }
            "--env" => {
                let entry = args.next().ok_or_else(|| Error::syntax(USAGE))?;
                let (name, value) = entry
                    .split_once('=')
                    .filter(|(name, _)| !name.is_empty())
                    .ok_or_else(|| Error::syntax("--env requires a non-empty NAME=VALUE"))?;
                environment.push((name.to_string(), value.to_string()));
            }
            "--" => {
                command_line = args.collect::<Vec<_>>().join(" ");
                break;
            }
            "--open-graph" if !open_graph_window => open_graph_window = true,
            value if value.starts_with("--") => return Err(Error::syntax(USAGE)),
            value if path.is_none() => path = Some(value.to_string()),
            _ => return Err(Error::syntax(USAGE)),
        }
    }
    if let Some(seed) = random_seed {
        options.random_seed = seed;
    }
    if let Some(steps) = max_steps {
        options.max_steps = steps;
    }
    if let Some(bytes) = max_storage_bytes {
        options.max_storage_bytes = bytes;
    }
    if let Some(operations) = max_matrix_operations {
        options.max_matrix_operations = operations;
    }
    options.network_enabled = network_enabled;
    if let Some(bytes) = max_network_bytes {
        options.max_network_bytes = bytes;
    }
    if let Some(profile) = synth_profile {
        options.synth_profile = profile;
    }
    options.synth_voice_count = synth_voice_count;
    options.synth_oscillator_count = synth_oscillator_count;
    options.start_line = start_line;
    options.command_line = command_line;
    options.environment = environment;
    options.file_root = file_root;
    options.output_root = output_root;
    options.soundfont_root = soundfont_root;
    options.graph_output = graph_output;
    options.open_graph_window = open_graph_window;
    Ok((options, path, continue_on_stop))
}

fn run_continuing<R: io::BufRead + ?Sized, W: Write>(
    program: &Program,
    options: RunOptions,
    input: &mut R,
    writer: &mut W,
) -> Result<(), Error> {
    let mut session = ExecutionSession::new(program, options)?;
    let mut result = session.run_with_input(input, writer)?;
    while result.state == SessionState::Stopped {
        result = session.resume_with_input(input, writer)?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn run_args(args: &[&str]) -> Result<(RunOptions, Option<String>, bool), Error> {
        parse_run_args(&mut args.iter().map(|value| value.to_string()))
    }

    fn shell_args(args: &[&str]) -> Result<ShellOptions, Error> {
        parse_shell_args(&mut args.iter().map(|value| value.to_string()))
    }

    #[test]
    fn run_arguments_accept_modernbasic_options_and_path() {
        let (options, path, continue_on_stop) = run_args(&[
            "--continue-on-stop",
            "--seed",
            "42",
            "--start-line",
            "20",
            "--max-steps",
            "400000",
            "--max-storage-bytes",
            "1234",
            "--max-matrix-operations",
            "5678",
            "--synth-profile",
            "extended",
            "--synth-voices",
            "12",
            "--synth-oscillators",
            "6",
            "--file-root",
            "sandbox",
            "--output-root",
            "generated",
            "--soundfont-root",
            "instruments",
            "--network",
            "--max-network-bytes",
            "8192",
            "--graph-output",
            "graph.svg",
            "--env",
            "Mode=checked",
            "--open-graph",
            "program.bas",
            "--",
            "alpha",
            "two words",
        ])
        .unwrap();
        assert_eq!(options.mode, NumericMode::Modern);
        assert!(continue_on_stop);
        assert_eq!(options.random_seed, 42);
        assert_eq!(options.start_line, Some(20));
        assert_eq!(options.max_steps, 400_000);
        assert_eq!(options.max_storage_bytes, 1234);
        assert_eq!(options.max_matrix_operations, 5678);
        assert!(options.network_enabled);
        assert_eq!(options.max_network_bytes, 8192);
        assert_eq!(options.synth_profile, SynthProfile::Extended);
        assert_eq!(options.synth_voice_count, Some(12));
        assert_eq!(options.synth_oscillator_count, Some(6));
        assert_eq!(
            options.file_root.as_deref(),
            Some(std::path::Path::new("sandbox"))
        );
        assert_eq!(
            options.output_root.as_deref(),
            Some(std::path::Path::new("generated"))
        );
        assert_eq!(
            options.soundfont_root.as_deref(),
            Some(std::path::Path::new("instruments"))
        );
        assert_eq!(
            options.graph_output.as_deref(),
            Some(std::path::Path::new("graph.svg"))
        );
        assert!(options.open_graph_window);
        assert_eq!(
            options.environment,
            vec![("Mode".to_string(), "checked".to_string())]
        );
        assert_eq!(options.command_line, "alpha two words");
        assert_eq!(path.as_deref(), Some("program.bas"));
    }

    #[test]
    fn run_arguments_reject_modes_bad_or_duplicate_options() {
        for args in [
            vec!["legacy"],
            vec!["modern", "program.bas"],
            vec!["--seed"],
            vec!["--seed", "nope"],
            vec!["--seed", "1", "--seed", "2"],
            vec!["--start-line"],
            vec!["--start-line", "nope"],
            vec!["--start-line", "10", "--start-line", "20"],
            vec!["--max-steps"],
            vec!["--max-steps", "nope"],
            vec!["--max-steps", "0"],
            vec!["--max-steps", "1", "--max-steps", "2"],
            vec!["--max-storage-bytes"],
            vec!["--max-storage-bytes", "nope"],
            vec!["--max-storage-bytes", "1", "--max-storage-bytes", "2"],
            vec!["--max-matrix-operations"],
            vec!["--max-matrix-operations", "nope"],
            vec![
                "--max-matrix-operations",
                "1",
                "--max-matrix-operations",
                "2",
            ],
            vec!["--network", "--network"],
            vec!["--max-network-bytes"],
            vec!["--max-network-bytes", "nope"],
            vec!["--max-network-bytes", "0"],
            vec!["--max-network-bytes", "1", "--max-network-bytes", "2"],
            vec!["--synth-profile"],
            vec!["--synth-profile", "unknown"],
            vec!["--synth-profile", "compact", "--synth-profile", "standard"],
            vec!["--synth-voices"],
            vec!["--synth-voices", "0"],
            vec!["--synth-voices", "17"],
            vec!["--synth-voices", "12", "--synth-voices", "8"],
            vec!["--synth-oscillators"],
            vec!["--synth-oscillators", "0"],
            vec!["--synth-oscillators", "9"],
            vec!["--synth-oscillators", "6", "--synth-oscillators", "4"],
            vec!["--continue-on-stop", "--continue-on-stop"],
            vec!["--unknown"],
            vec!["--file-root"],
            vec!["--file-root", "one", "--file-root", "two"],
            vec!["--output-root"],
            vec!["--output-root", "one", "--output-root", "two"],
            vec!["--soundfont-root"],
            vec!["--soundfont-root", "one", "--soundfont-root", "two"],
            vec!["--graph-output"],
            vec!["--graph-output", "one", "--graph-output", "two"],
            vec!["--env"],
            vec!["--env", "missing-equals"],
            vec!["--env", "=missing-name"],
            vec!["--open-graph", "--open-graph"],
            vec!["one.bas", "two.bas"],
        ] {
            assert!(matches!(run_args(&args), Err(Error::Syntax { .. })));
        }
    }

    #[test]
    fn shell_arguments_build_a_graphical_session_without_changing_the_language() {
        let options = shell_args(&[
            "--fullscreen",
            "--display-profile",
            "hd",
            "--graphics-scale",
            "stretch",
            "--width",
            "1200",
            "--height",
            "800",
            "--mixed-case",
            "--screen-color",
            "#112233",
            "--text-color",
            "#AaBbCc",
            "--seed",
            "77",
            "--network",
            "--file-root",
            "sandbox",
            "program.bas",
        ])
        .unwrap();
        assert_eq!(options.width, 1200);
        assert_eq!(options.height, 800);
        assert!(options.fullscreen);
        assert_eq!(options.graphics_scale, GraphicsScaleMode::Stretch);
        assert!(!options.uppercase_input);
        assert_eq!(options.screen_color, "#112233");
        assert_eq!(options.text_color, "#aabbcc");
        assert_eq!(options.initial_program.as_deref(), Some("program.bas"));
        assert_eq!(options.run_options.random_seed, 77);
        assert!(options.run_options.network_enabled);
        assert_eq!(
            options.run_options.file_root.as_deref(),
            Some(std::path::Path::new("sandbox"))
        );
        assert!(!options.run_options.open_graph_window);
        assert_eq!(
            options.run_options.max_steps,
            modernbasic::interpreter::UNLIMITED_STEPS
        );
    }

    #[test]
    fn shell_arguments_reject_bad_geometry_and_run_only_flags() {
        for args in [
            vec!["--width", "639"],
            vec!["--width", "8193"],
            vec!["--height", "399"],
            vec!["--height", "8193"],
            vec!["--width"],
            vec!["--height"],
            vec!["--display-profile"],
            vec!["--display-profile", "unknown"],
            vec!["--display-profile", "hd", "--display-profile", "compact"],
            vec!["--graphics-scale"],
            vec!["--graphics-scale", "nearest"],
            vec!["--graphics-scale", "fit", "--graphics-scale", "stretch"],
            vec!["--screen-color"],
            vec!["--screen-color", "green"],
            vec!["--screen-color", "#000000", "--screen-color", "#ffffff"],
            vec!["--text-color"],
            vec!["--text-color", "#12345g"],
            vec!["--text-color", "#000000", "--text-color", "#ffffff"],
            vec!["--continue-on-stop"],
            vec!["one.bas", "two.bas"],
        ] {
            assert!(matches!(shell_args(&args), Err(Error::Syntax { .. })));
        }
    }

    #[test]
    fn shell_display_profiles_have_stable_sizes_and_fit_by_default() {
        for (profile, expected) in [
            ("compact", (800, 600)),
            ("desktop", (1_100, 760)),
            ("hd", (1_280, 720)),
            ("fullhd", (1_920, 1_080)),
        ] {
            let options = shell_args(&["--display-profile", profile]).unwrap();
            assert_eq!((options.width, options.height), expected);
            assert_eq!(options.graphics_scale, GraphicsScaleMode::Fit);
        }
    }

    #[test]
    fn shell_loads_saved_colors_before_applying_cli_overrides() {
        let root = std::env::temp_dir().join(format!(
            "modernbasic-shell-colors-{}-{:?}",
            std::process::id(),
            std::thread::current().id()
        ));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir(&root).unwrap();
        std::fs::write(
            root.join("modernbasic.cfg"),
            "screen_color=#123456\ntext_color=#abcdef\n",
        )
        .unwrap();
        let root_string = root.to_string_lossy().into_owned();
        let options =
            shell_args(&["--file-root", &root_string, "--text-color", "#FEDCBA"]).unwrap();
        assert_eq!(options.screen_color, "#123456");
        assert_eq!(options.text_color, "#fedcba");
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn default_file_root_tracks_program_directory() {
        assert_eq!(
            default_file_root(Some("examples/part1.bas")).unwrap(),
            PathBuf::from("examples")
        );
        assert!(default_file_root(Some("part1.bas")).unwrap().is_absolute());
        let root = default_file_root(None).unwrap();
        assert_eq!(root.file_name(), Some(std::ffi::OsStr::new("programs")));
        assert!(root.is_dir());
        assert_eq!(
            default_file_root(Some("programs/examples/hello.bas")).unwrap(),
            std::fs::canonicalize("programs").unwrap()
        );
    }
}
