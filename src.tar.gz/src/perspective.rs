//! Retained point-perspective world projected onto ModernBASIC's 2D canvas.
//!
//! Pixels, objects, and sprites keep world-space coordinates and dimensions.
//! Rendering projects them toward one vanishing point, sorts every entity from
//! far to near, and shades their colors with bounded point lights.

use std::collections::BTreeMap;
use std::fmt::Write as _;

use crate::artist_renderer::{parse_color, Color};
use crate::error::Error;

pub(crate) const MAX_PERSPECTIVE_ENTITIES: usize = 65_536;
pub(crate) const MAX_PERSPECTIVE_LIGHTS: usize = 256;

#[derive(Debug, Clone, Copy, PartialEq)]
struct Projection {
    horizon_x: f64,
    horizon_y: f64,
    focal_length: f64,
    near: f64,
    far: f64,
    ambient: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum EntityKind {
    Object,
    Sprite,
    Pixel,
}

#[derive(Debug, Clone, PartialEq)]
struct WorldTexture {
    path: String,
    transparent: Option<Color>,
}

#[derive(Debug, Clone, PartialEq)]
struct WorldEntity {
    kind: EntityKind,
    id: String,
    x: f64,
    y: f64,
    z: f64,
    width: f64,
    height: f64,
    fill: Color,
    stroke: Option<Color>,
    texture: Option<WorldTexture>,
    horizon_aligned: bool,
    velocity: [f64; 3],
    acceleration: [f64; 3],
}

#[derive(Debug, Clone, PartialEq)]
struct WorldLight {
    x: f64,
    y: f64,
    z: f64,
    intensity: f64,
    range: f64,
    color: Color,
}

#[derive(Debug, Clone, PartialEq)]
pub(crate) struct PerspectiveWorld {
    projection: Option<Projection>,
    camera: [f64; 3],
    objects: BTreeMap<String, WorldEntity>,
    sprites: BTreeMap<String, WorldEntity>,
    pixels: BTreeMap<String, WorldEntity>,
    lights: BTreeMap<String, WorldLight>,
}

impl Default for PerspectiveWorld {
    fn default() -> Self {
        Self {
            projection: None,
            camera: [0.0; 3],
            objects: BTreeMap::new(),
            sprites: BTreeMap::new(),
            pixels: BTreeMap::new(),
            lights: BTreeMap::new(),
        }
    }
}

impl PerspectiveWorld {
    pub(crate) fn configure(
        &mut self,
        horizon_x: f64,
        horizon_y: f64,
        focal_length: f64,
        near: f64,
        far: f64,
        ambient: f64,
    ) -> Result<(), Error> {
        require_finite(&[horizon_x, horizon_y, focal_length, near, far, ambient])?;
        if focal_length <= 0.0 || near <= 0.0 || far <= near || !(0.0..=1.0).contains(&ambient) {
            return Err(Error::IllegalQuantity);
        }
        self.projection = Some(Projection {
            horizon_x,
            horizon_y,
            focal_length,
            near,
            far,
            ambient,
        });
        Ok(())
    }

    pub(crate) fn set_camera(&mut self, x: f64, y: f64, z: f64) -> Result<(), Error> {
        require_finite(&[x, y, z])?;
        self.camera = [x, y, z];
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn define_object(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
        width: f64,
        height: f64,
        fill: &str,
        stroke: &str,
    ) -> Result<(), Error> {
        self.define_entity(EntityKind::Object, id, x, y, z, width, height, fill, stroke)
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn define_sprite(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
        width: f64,
        height: f64,
        fill: &str,
        stroke: &str,
    ) -> Result<(), Error> {
        self.define_entity(EntityKind::Sprite, id, x, y, z, width, height, fill, stroke)
    }
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn define_image_sprite(
        &mut self,
        id: &str,
        path: &str,
        x: f64,
        y: f64,
        z: f64,
        width: f64,
        height: f64,
        transparent: Option<&str>,
    ) -> Result<(), Error> {
        if path.is_empty() || path.len() > 4096 || path.contains('"') {
            return Err(Error::InvalidFilePath);
        }
        let transparent = transparent.map(parse_color).transpose()?;
        self.define_entity(
            EntityKind::Sprite,
            id,
            x,
            y,
            z,
            width,
            height,
            "white",
            "none",
        )?;
        let sprite = self.entity_mut(EntityKind::Sprite, id)?;
        sprite.texture = Some(WorldTexture {
            path: path.to_string(),
            transparent,
        });
        Ok(())
    }

    pub(crate) fn set_pixel(&mut self, x: f64, y: f64, z: f64, fill: &str) -> Result<(), Error> {
        let id = pixel_key(x, y, z);
        self.define_entity(EntityKind::Pixel, &id, x, y, z, 1.0, 1.0, fill, "none")
    }

    pub(crate) fn unset_pixel(&mut self, x: f64, y: f64, z: f64) -> Result<(), Error> {
        self.require_projection()?;
        require_finite(&[x, y, z])?;
        self.pixels.remove(&pixel_key(x, y, z));
        Ok(())
    }

    pub(crate) fn move_object(&mut self, id: &str, x: f64, y: f64, z: f64) -> Result<(), Error> {
        self.move_entity(EntityKind::Object, id, x, y, z)
    }

    pub(crate) fn move_sprite(&mut self, id: &str, x: f64, y: f64, z: f64) -> Result<(), Error> {
        self.move_entity(EntityKind::Sprite, id, x, y, z)
    }

    pub(crate) fn scale_object(&mut self, id: &str, width: f64, height: f64) -> Result<(), Error> {
        require_finite(&[width, height])?;
        if width <= 0.0 || height <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        let object = self.entity_mut(EntityKind::Object, id)?;
        object.width = width;
        object.height = height;
        Ok(())
    }

    pub(crate) fn set_sprite_motion(
        &mut self,
        id: &str,
        velocity: [f64; 3],
        acceleration: [f64; 3],
    ) -> Result<(), Error> {
        require_finite(&velocity)?;
        require_finite(&acceleration)?;
        let sprite = self.entity_mut(EntityKind::Sprite, id)?;
        sprite.velocity = velocity;
        sprite.acceleration = acceleration;
        Ok(())
    }

    pub(crate) fn set_sprite_horizon_alignment(
        &mut self,
        id: &str,
        enabled: bool,
    ) -> Result<(), Error> {
        let sprite = self.entity_mut(EntityKind::Sprite, id)?;
        if sprite.texture.is_none() {
            return Err(Error::syntax(
                "SPRITE ORIENT requires a mapped SPRITE IMAGE",
            ));
        }
        sprite.horizon_aligned = enabled;
        Ok(())
    }

    pub(crate) fn advance_sprites(&mut self, seconds: f64) -> Result<(), Error> {
        require_finite(&[seconds])?;
        if !(0.0..=60.0).contains(&seconds) {
            return Err(Error::IllegalQuantity);
        }
        let mut updates = Vec::with_capacity(self.sprites.len());
        for (id, sprite) in &self.sprites {
            let mut position = [sprite.x, sprite.y, sprite.z];
            let mut velocity = sprite.velocity;
            for axis in 0..3 {
                position[axis] +=
                    velocity[axis] * seconds + 0.5 * sprite.acceleration[axis] * seconds * seconds;
                velocity[axis] += sprite.acceleration[axis] * seconds;
            }
            require_finite(&position)?;
            require_finite(&velocity)?;
            updates.push((id.clone(), position, velocity));
        }
        for (id, position, velocity) in updates {
            let sprite = self
                .sprites
                .get_mut(&id)
                .expect("validated perspective sprite");
            [sprite.x, sprite.y, sprite.z] = position;
            sprite.velocity = velocity;
        }
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn define_light(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
        intensity: f64,
        range: f64,
        color: &str,
    ) -> Result<(), Error> {
        self.require_projection()?;
        validate_id(id)?;
        require_finite(&[x, y, z, intensity, range])?;
        if !(0.0..=100.0).contains(&intensity) || range <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        let key = id.to_ascii_uppercase();
        if !self.lights.contains_key(&key) && self.lights.len() >= MAX_PERSPECTIVE_LIGHTS {
            return Err(Error::syntax("perspective light limit exceeded"));
        }
        self.lights.insert(
            key,
            WorldLight {
                x,
                y,
                z,
                intensity,
                range,
                color: parse_color(color)?,
            },
        );
        Ok(())
    }

    pub(crate) fn remove_object(&mut self, id: &str) -> Result<(), Error> {
        if self.objects.remove(&id.to_ascii_uppercase()).is_none() {
            return Err(Error::syntax(format!("undefined perspective object {id}")));
        }
        Ok(())
    }

    pub(crate) fn has_sprite(&self, id: &str) -> bool {
        self.sprites.contains_key(&id.to_ascii_uppercase())
    }

    pub(crate) fn clear(&mut self) {
        self.objects.clear();
        self.sprites.clear();
        self.pixels.clear();
        self.lights.clear();
    }

    pub(crate) fn object_state(&self, id: &str) -> Option<[f64; 6]> {
        let object = self.objects.get(&id.to_ascii_uppercase())?;
        Some([
            object.x,
            object.y,
            object.z,
            self.entity_scale(object),
            object.width,
            object.height,
        ])
    }

    pub(crate) fn sprite_state(&self, id: &str) -> Option<[f64; 12]> {
        let sprite = self.sprites.get(&id.to_ascii_uppercase())?;
        Some([
            sprite.x,
            sprite.y,
            sprite.z,
            self.entity_scale(sprite),
            sprite.width,
            sprite.height,
            sprite.velocity[0],
            sprite.velocity[1],
            sprite.velocity[2],
            sprite.acceleration[0],
            sprite.acceleration[1],
            sprite.acceleration[2],
        ])
    }

    pub(crate) fn projected_sprites(&self) -> Vec<(String, [f64; 4])> {
        let Some(projection) = self.projection else {
            return Vec::new();
        };
        self.sprites
            .values()
            .filter_map(|sprite| {
                self.project_entity(sprite, projection)
                    .map(|(_, bounds)| (sprite.id.clone(), bounds))
            })
            .collect()
    }

    pub(crate) fn to_artist_commands(&self) -> String {
        let Some(projection) = self.projection else {
            return String::new();
        };
        let mut visible = self
            .objects
            .values()
            .chain(self.sprites.values())
            .chain(self.pixels.values())
            .filter_map(|entity| {
                self.project_entity(entity, projection)
                    .map(|(depth, bounds)| (entity, depth, bounds))
            })
            .collect::<Vec<_>>();
        visible.sort_by(|(left, left_depth, _), (right, right_depth, _)| {
            right_depth
                .total_cmp(left_depth)
                .then_with(|| left.kind.cmp(&right.kind))
                .then_with(|| left.id.cmp(&right.id))
        });

        let mut source = String::with_capacity(visible.len().saturating_mul(144));
        for (entity, _, [left, top, screen_width, screen_height]) in visible {
            let shaded = self.shaded_color(entity.fill, entity, projection.ambient);
            if let Some(texture) = &entity.texture {
                let mut command = format!(
                    "bitmap_sprite {} \"{}\" {left} {top} {screen_width} {screen_height} tint={}",
                    entity.id,
                    texture.path,
                    color_hex(shaded)
                );
                if let Some(transparent) = texture.transparent {
                    let _ = write!(command, " key={}", color_hex(transparent));
                }
                if entity.horizon_aligned {
                    let anchor_x = left + screen_width * 0.5;
                    let anchor_y = top + screen_height;
                    let rise = anchor_y - projection.horizon_y;
                    let aim = if rise.abs() <= f64::EPSILON {
                        0.0
                    } else {
                        ((projection.horizon_x - anchor_x) / rise).clamp(-2.0, 2.0)
                    };
                    let _ = write!(command, " aim={aim}");
                }
                source.push_str(&command);
                source.push('\n');
                continue;
            }
            let stroke = entity
                .stroke
                .map(|color| color_hex(self.shaded_color(color, entity, projection.ambient)))
                .unwrap_or_else(|| "none".to_string());
            let _ = writeln!(
                source,
                "rectangle {left} {top} {screen_width} {screen_height} fill={} stroke={stroke} stroke-width=1",
                color_hex(shaded)
            );
        }
        source
    }

    fn shaded_color(&self, base: Color, object: &WorldEntity, ambient: f64) -> Color {
        let mut red = f64::from(base.r) * ambient;
        let mut green = f64::from(base.g) * ambient;
        let mut blue = f64::from(base.b) * ambient;
        for light in self.lights.values() {
            let dx = object.x - light.x;
            let dy = object.y - light.y;
            let dz = object.z - light.z;
            let distance_squared = dx * dx + dy * dy + dz * dz;
            let attenuation =
                light.intensity / (1.0 + distance_squared / (light.range * light.range));
            red += f64::from(base.r) * (f64::from(light.color.r) / 255.0) * attenuation;
            green += f64::from(base.g) * (f64::from(light.color.g) / 255.0) * attenuation;
            blue += f64::from(base.b) * (f64::from(light.color.b) / 255.0) * attenuation;
        }
        Color::rgba(
            red.round().clamp(0.0, 255.0) as u8,
            green.round().clamp(0.0, 255.0) as u8,
            blue.round().clamp(0.0, 255.0) as u8,
            base.a,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn define_entity(
        &mut self,
        kind: EntityKind,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
        width: f64,
        height: f64,
        fill: &str,
        stroke: &str,
    ) -> Result<(), Error> {
        self.require_projection()?;
        validate_id(id)?;
        require_finite(&[x, y, z, width, height])?;
        if width <= 0.0 || height <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        let key = id.to_ascii_uppercase();
        let exists = match kind {
            EntityKind::Object => self.objects.contains_key(&key),
            EntityKind::Sprite => self.sprites.contains_key(&key),
            EntityKind::Pixel => self.pixels.contains_key(&key),
        };
        let entity_count = self.objects.len() + self.sprites.len() + self.pixels.len();
        if !exists && entity_count >= MAX_PERSPECTIVE_ENTITIES {
            return Err(Error::syntax("perspective entity limit exceeded"));
        }
        let entity = WorldEntity {
            kind,
            id: key.clone(),
            x,
            y,
            z,
            width,
            height,
            fill: parse_color(fill)?,
            stroke: if stroke.eq_ignore_ascii_case("none") {
                None
            } else {
                Some(parse_color(stroke)?)
            },
            texture: None,
            horizon_aligned: false,
            velocity: [0.0; 3],
            acceleration: [0.0; 3],
        };
        match kind {
            EntityKind::Object => self.objects.insert(key, entity),
            EntityKind::Sprite => self.sprites.insert(key, entity),
            EntityKind::Pixel => self.pixels.insert(key, entity),
        };
        Ok(())
    }

    fn move_entity(
        &mut self,
        kind: EntityKind,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
    ) -> Result<(), Error> {
        require_finite(&[x, y, z])?;
        let entity = self.entity_mut(kind, id)?;
        entity.x = x;
        entity.y = y;
        entity.z = z;
        Ok(())
    }

    fn entity_mut(&mut self, kind: EntityKind, id: &str) -> Result<&mut WorldEntity, Error> {
        let key = id.to_ascii_uppercase();
        let entity = match kind {
            EntityKind::Object => self.objects.get_mut(&key),
            EntityKind::Sprite => self.sprites.get_mut(&key),
            EntityKind::Pixel => self.pixels.get_mut(&key),
        };
        entity.ok_or_else(|| {
            let label = match kind {
                EntityKind::Object => "object",
                EntityKind::Sprite => "sprite",
                EntityKind::Pixel => "pixel",
            };
            Error::syntax(format!("undefined perspective {label} {id}"))
        })
    }

    fn entity_scale(&self, entity: &WorldEntity) -> f64 {
        self.projection
            .filter(|projection| {
                let depth = entity.z - self.camera[2];
                (projection.near..=projection.far).contains(&depth)
            })
            .map(|projection| projection.focal_length / (entity.z - self.camera[2]))
            .unwrap_or(0.0)
    }

    fn project_entity(
        &self,
        entity: &WorldEntity,
        projection: Projection,
    ) -> Option<(f64, [f64; 4])> {
        let depth = entity.z - self.camera[2];
        if !(projection.near..=projection.far).contains(&depth) {
            return None;
        }
        let scale = projection.focal_length / depth;
        let screen_x = projection.horizon_x + (entity.x - self.camera[0]) * scale;
        let screen_y = projection.horizon_y - (entity.y - self.camera[1]) * scale;
        let (left, top, width, height) = match entity.kind {
            EntityKind::Pixel => {
                let size = scale;
                (screen_x - size * 0.5, screen_y - size * 0.5, size, size)
            }
            EntityKind::Object | EntityKind::Sprite => {
                let width = entity.width * scale;
                let height = entity.height * scale;
                (screen_x - width * 0.5, screen_y - height, width, height)
            }
        };
        Some((depth, [left, top, width, height]))
    }

    fn require_projection(&self) -> Result<Projection, Error> {
        self.projection
            .ok_or_else(|| Error::syntax("PERSPECTIVE must be configured before 3D graphics"))
    }
}

fn require_finite(values: &[f64]) -> Result<(), Error> {
    if values.iter().all(|value| value.is_finite()) {
        Ok(())
    } else {
        Err(Error::RealOverflow)
    }
}

fn validate_id(id: &str) -> Result<(), Error> {
    if id.is_empty()
        || id.len() > 128
        || !id
            .chars()
            .all(|character| character.is_ascii_alphanumeric() || matches!(character, '_' | '-'))
    {
        return Err(Error::syntax("invalid perspective entity identifier"));
    }
    Ok(())
}

fn pixel_key(x: f64, y: f64, z: f64) -> String {
    format!(
        "{:016X}_{:016X}_{:016X}",
        x.to_bits(),
        y.to_bits(),
        z.to_bits()
    )
}

fn color_hex(color: Color) -> String {
    if color.a == 255 {
        format!("#{:02x}{:02x}{:02x}", color.r, color.g, color.b)
    } else {
        format!(
            "#{:02x}{:02x}{:02x}{:02x}",
            color.r, color.g, color.b, color.a
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn perspective_world_retains_projects_sorts_scales_and_lights_objects() {
        let mut world = PerspectiveWorld::default();
        world
            .configure(100.0, 50.0, 100.0, 1.0, 1000.0, 0.2)
            .unwrap();
        world
            .define_object("NEAR", 0.0, 0.0, 10.0, 2.0, 4.0, "red", "none")
            .unwrap();
        world
            .define_object("FAR", 0.0, 0.0, 20.0, 2.0, 4.0, "blue", "white")
            .unwrap();

        let unlit = world.to_artist_commands();
        let far = unlit.find("fill=#000033").unwrap();
        let near = unlit.find("fill=#330000").unwrap();
        assert!(far < near);
        assert!(unlit.contains("rectangle 90 10 20 40"));
        assert!(unlit.contains("rectangle 95 30 10 20"));
        assert_eq!(world.object_state("near").unwrap()[3], 10.0);

        world
            .define_light("SUN", 0.0, 0.0, 10.0, 1.0, 10.0, "white")
            .unwrap();
        assert!(world.to_artist_commands().contains("fill=#ff0000"));
        world.move_object("near", 5.0, 1.0, 25.0).unwrap();
        world.scale_object("near", 4.0, 8.0).unwrap();
        assert_eq!(
            world.object_state("near").unwrap(),
            [5.0, 1.0, 25.0, 4.0, 4.0, 8.0]
        );
    }

    #[test]
    fn pixels_objects_and_sprites_share_depth_sort_scale_light_and_motion() {
        let mut world = PerspectiveWorld::default();
        world
            .configure(100.0, 50.0, 100.0, 1.0, 1000.0, 1.0)
            .unwrap();
        world
            .define_object("FAR", 0.0, 0.0, 30.0, 2.0, 4.0, "blue", "none")
            .unwrap();
        world.set_pixel(-10.0, 0.0, 20.0, "green").unwrap();
        world
            .define_sprite("SHIP", 0.0, 0.0, 10.0, 2.0, 4.0, "red", "none")
            .unwrap();

        let source = world.to_artist_commands();
        let far = source.find("fill=#0000ff").unwrap();
        let pixel = source.find("fill=#00ff00").unwrap();
        let sprite = source.find("fill=#ff0000").unwrap();
        assert!(far < pixel && pixel < sprite);
        assert!(source.contains("rectangle 47.5 47.5 5 5"));
        assert!(source.contains("rectangle 90 10 20 40"));
        assert_eq!(world.sprite_state("ship").unwrap()[3], 10.0);

        world
            .set_sprite_motion("SHIP", [1.0, 2.0, -5.0], [0.0, 0.0, 1.0])
            .unwrap();
        world.advance_sprites(1.0).unwrap();
        let state = world.sprite_state("SHIP").unwrap();
        assert_eq!(state[0], 1.0);
        assert_eq!(state[1], 2.0);
        assert_eq!(state[2], 5.5);
        assert_eq!(state[8], -4.0);
        assert_eq!(state[11], 1.0);
        assert!((state[3] - 100.0 / 5.5).abs() < 1.0e-12);
        assert_eq!(world.projected_sprites().len(), 1);

        world
            .configure(100.0, 50.0, 100.0, 1.0, 1000.0, 0.2)
            .unwrap();
        world
            .define_light("PIXELLIGHT", -10.0, 0.0, 20.0, 1.0, 10.0, "white")
            .unwrap();
        assert!(world.to_artist_commands().contains("fill=#00ff00"));
        world.unset_pixel(-10.0, 0.0, 20.0).unwrap();
        assert!(!world.to_artist_commands().contains("fill=#00ff00"));
    }

    #[test]
    fn mapped_image_sprites_remain_world_entities_and_emit_projected_texture_commands() {
        let mut world = PerspectiveWorld::default();
        world.configure(10.0, 8.0, 10.0, 1.0, 100.0, 0.5).unwrap();
        world
            .define_image_sprite(
                "HERO",
                "/__modernbasic_memory_image__/hero.ppm",
                0.0,
                0.0,
                10.0,
                4.0,
                2.0,
                Some("black"),
            )
            .unwrap();

        let source = world.to_artist_commands();
        assert!(source
            .contains("bitmap_sprite HERO \"/__modernbasic_memory_image__/hero.ppm\" 8 6 4 2"));
        assert!(source.contains("tint=#808080"));
        assert!(source.contains("key=#000000"));
        assert_eq!(
            world.sprite_state("hero").unwrap()[0..6],
            [0.0, 0.0, 10.0, 1.0, 4.0, 2.0]
        );
    }

    #[test]
    fn mapped_sprite_horizon_alignment_tracks_its_projected_anchor_and_can_reset() {
        let mut world = PerspectiveWorld::default();
        world
            .configure(100.0, 50.0, 100.0, 1.0, 1000.0, 1.0)
            .unwrap();
        world
            .define_image_sprite(
                "SHIP",
                "/__modernbasic_memory_image__/ship.ppm",
                2.0,
                -2.0,
                10.0,
                4.0,
                2.0,
                Some("black"),
            )
            .unwrap();

        world.set_sprite_horizon_alignment("ship", true).unwrap();
        let aligned = world.to_artist_commands();
        assert!(aligned.contains("aim=-1"), "{aligned}");

        world.set_sprite_horizon_alignment("SHIP", false).unwrap();
        assert!(!world.to_artist_commands().contains(" aim="));
        assert!(world.set_sprite_horizon_alignment("missing", true).is_err());
    }

    #[test]
    fn chase_camera_steering_preserves_sprite_shape_and_screen_position() {
        let mut world = PerspectiveWorld::default();
        world
            .configure(480.0, 270.0, 500.0, 5.0, 3000.0, 1.0)
            .unwrap();
        world
            .define_image_sprite(
                "PLAYER",
                "/__modernbasic_memory_image__/ship.ppm",
                84.0,
                -52.0,
                100.0,
                12.0,
                10.0,
                Some("black"),
            )
            .unwrap();
        world.set_camera(84.0, 0.0, 0.0).unwrap();

        let first_bounds = world.projected_sprites()[0].1;
        assert_eq!(first_bounds, [450.0, 480.0, 60.0, 50.0]);
        let first_frame = world.to_artist_commands();
        assert!(!first_frame.contains(" angle="));
        assert!(!first_frame.contains(" aim="));

        world.move_sprite("PLAYER", -84.0, -52.0, 100.0).unwrap();
        world.set_camera(-84.0, 0.0, 0.0).unwrap();

        assert_eq!(world.projected_sprites()[0].1, first_bounds);
        assert_eq!(world.to_artist_commands(), first_frame);
    }

    #[test]
    fn perspective_configuration_and_world_limits_are_validated() {
        let mut world = PerspectiveWorld::default();
        assert!(world
            .define_object("A", 0.0, 0.0, 10.0, 1.0, 1.0, "red", "none")
            .is_err());
        assert!(world.set_pixel(0.0, 0.0, 10.0, "white").is_err());
        assert!(world.unset_pixel(0.0, 0.0, 10.0).is_err());
        assert!(world.configure(0.0, 0.0, 0.0, 1.0, 10.0, 0.2).is_err());
        world.configure(0.0, 0.0, 10.0, 1.0, 10.0, 0.2).unwrap();
        assert!(world
            .define_light("SUN", 0.0, 0.0, 1.0, -1.0, 10.0, "white")
            .is_err());
        assert!(world.move_object("missing", 0.0, 0.0, 2.0).is_err());
    }
}
