#![allow(dead_code)]

use super::error::SoundFontError;
use super::instrument::Instrument;
use super::preset_info::PresetInfo;
use super::preset_region::PresetRegion;
use super::zone::Zone;

/// Represents a preset in the SoundFont.
#[derive(Debug)]
#[non_exhaustive]
pub struct Preset {
    pub(crate) name: String,
    pub(crate) patch_number: i32,
    pub(crate) bank_number: i32,
    pub(crate) library: i32,
    pub(crate) genre: i32,
    pub(crate) morphology: i32,
    pub(crate) regions: Vec<PresetRegion>,
}

impl Preset {
    fn new(
        info: &PresetInfo,
        preset_id: usize,
        zones: &[Zone],
        instruments: &[Instrument],
    ) -> Result<Self, SoundFontError> {
        let name = info.name.clone();

        let zone_count = info.zone_end_index - info.zone_start_index + 1;
        if zone_count <= 0 {
            return Err(SoundFontError::InvalidPreset(preset_id));
        }

        let span_start = usize::try_from(info.zone_start_index)
            .map_err(|_| SoundFontError::InvalidPreset(preset_id))?;
        let zone_count =
            usize::try_from(zone_count).map_err(|_| SoundFontError::InvalidPreset(preset_id))?;
        let span_end = span_start
            .checked_add(zone_count)
            .filter(|end| *end <= zones.len())
            .ok_or(SoundFontError::InvalidPreset(preset_id))?;
        let zone_span = &zones[span_start..span_end];
        let regions = PresetRegion::create(preset_id, zone_span, instruments)?;

        Ok(Self {
            name,
            patch_number: info.patch_number,
            bank_number: info.bank_number,
            library: info.library,
            genre: info.genre,
            morphology: info.morphology,
            regions,
        })
    }

    pub(crate) fn create(
        infos: &[PresetInfo],
        zones: &[Zone],
        instruments: &[Instrument],
    ) -> Result<Vec<Preset>, SoundFontError> {
        if infos.len() <= 1 {
            return Err(SoundFontError::PresetNotFound);
        }

        // The last one is the terminator.
        let count = infos.len() - 1;

        let mut presets: Vec<Preset> = Vec::new();
        for (preset_id, info) in infos.iter().take(count).enumerate() {
            presets.push(Preset::new(info, preset_id, zones, instruments)?);
        }

        Ok(presets)
    }

    /// Gets the name of the preset.
    pub fn get_name(&self) -> &str {
        &self.name
    }

    /// Gets the patch number of the preset.
    pub fn get_patch_number(&self) -> i32 {
        self.patch_number
    }

    /// Gets the bank number of the preset.
    pub fn get_bank_number(&self) -> i32 {
        self.bank_number
    }

    /// Gets the library info.
    pub fn get_library(&self) -> i32 {
        self.library
    }

    /// Gets the genre info.
    pub fn get_genre(&self) -> i32 {
        self.genre
    }

    /// Gets the morphology info.
    pub fn get_morphology(&self) -> i32 {
        self.morphology
    }

    /// Gets the regions of the preset.
    pub fn get_regions(&self) -> &[PresetRegion] {
        &self.regions[..]
    }
}

#[cfg(test)]
mod tests {
    use super::{Preset, PresetInfo, SoundFontError};

    fn info(zone_start_index: i32, zone_end_index: i32) -> PresetInfo {
        PresetInfo {
            name: "test".to_string(),
            patch_number: 0,
            bank_number: 0,
            zone_start_index,
            zone_end_index,
            library: 0,
            genre: 0,
            morphology: 0,
        }
    }

    #[test]
    fn preset_zone_spans_are_bounds_checked() {
        assert!(matches!(
            Preset::new(&info(0, 0), 7, &[], &[]),
            Err(SoundFontError::InvalidPreset(7))
        ));
        assert!(matches!(
            Preset::new(&info(-1, 0), 8, &[], &[]),
            Err(SoundFontError::InvalidPreset(8))
        ));
    }
}
