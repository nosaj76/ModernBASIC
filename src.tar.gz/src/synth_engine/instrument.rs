#![allow(dead_code)]

use super::error::SoundFontError;
use super::instrument_info::InstrumentInfo;
use super::instrument_region::InstrumentRegion;
use super::sample_header::SampleHeader;
use super::zone::Zone;

/// Represents an instrument in the SoundFont.
#[derive(Debug)]
#[non_exhaustive]
pub struct Instrument {
    pub(crate) name: String,
    pub(crate) regions: Vec<InstrumentRegion>,
}

impl Instrument {
    fn new(
        info: &InstrumentInfo,
        instrument_id: usize,
        zones: &[Zone],
        samples: &[SampleHeader],
    ) -> Result<Self, SoundFontError> {
        let name = info.name.clone();

        let zone_count = info.zone_end_index - info.zone_start_index + 1;
        if zone_count <= 0 {
            return Err(SoundFontError::InvalidInstrument(instrument_id));
        }

        let span_start = usize::try_from(info.zone_start_index)
            .map_err(|_| SoundFontError::InvalidInstrument(instrument_id))?;
        let zone_count = usize::try_from(zone_count)
            .map_err(|_| SoundFontError::InvalidInstrument(instrument_id))?;
        let span_end = span_start
            .checked_add(zone_count)
            .filter(|end| *end <= zones.len())
            .ok_or(SoundFontError::InvalidInstrument(instrument_id))?;
        let zone_span = &zones[span_start..span_end];
        let regions = InstrumentRegion::create(instrument_id, zone_span, samples)?;

        Ok(Self { name, regions })
    }

    pub(crate) fn create(
        infos: &[InstrumentInfo],
        zones: &[Zone],
        samples: &[SampleHeader],
    ) -> Result<Vec<Instrument>, SoundFontError> {
        if infos.len() <= 1 {
            return Err(SoundFontError::InstrumentNotFound);
        }

        // The last one is the terminator.
        let count = infos.len() - 1;

        let mut instruments: Vec<Instrument> = Vec::new();
        for (instrument_id, info) in infos.iter().take(count).enumerate() {
            instruments.push(Instrument::new(info, instrument_id, zones, samples)?);
        }

        Ok(instruments)
    }

    /// Gets the name of the instrument.
    pub fn get_name(&self) -> &str {
        &self.name
    }

    /// Gets the regions of the instrument.
    pub fn get_regions(&self) -> &[InstrumentRegion] {
        &self.regions[..]
    }
}

#[cfg(test)]
mod tests {
    use super::{Instrument, InstrumentInfo, SoundFontError};

    fn info(zone_start_index: i32, zone_end_index: i32) -> InstrumentInfo {
        InstrumentInfo {
            name: "test".to_string(),
            zone_start_index,
            zone_end_index,
        }
    }

    #[test]
    fn instrument_zone_spans_are_bounds_checked() {
        assert!(matches!(
            Instrument::new(&info(0, 0), 7, &[], &[]),
            Err(SoundFontError::InvalidInstrument(7))
        ));
        assert!(matches!(
            Instrument::new(&info(-1, 0), 8, &[], &[]),
            Err(SoundFontError::InvalidInstrument(8))
        ));
    }
}
