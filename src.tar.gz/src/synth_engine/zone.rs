use super::error::SoundFontError;
use super::generator::Generator;
use super::zone_info::ZoneInfo;

#[non_exhaustive]
pub(crate) struct Zone {
    pub(crate) generators: Vec<Generator>,
}

impl Zone {
    pub(crate) fn empty() -> Self {
        Self {
            generators: Vec::new(),
        }
    }

    fn new(info: &ZoneInfo, generators: &[Generator]) -> Result<Self, SoundFontError> {
        let start =
            usize::try_from(info.generator_index).map_err(|_| SoundFontError::InvalidZoneList)?;
        let count =
            usize::try_from(info.generator_count).map_err(|_| SoundFontError::InvalidZoneList)?;
        let end = start
            .checked_add(count)
            .filter(|end| *end <= generators.len())
            .ok_or(SoundFontError::InvalidZoneList)?;

        Ok(Self {
            generators: generators[start..end].to_vec(),
        })
    }

    pub(crate) fn create(
        infos: &[ZoneInfo],
        generators: &[Generator],
    ) -> Result<Vec<Zone>, SoundFontError> {
        if infos.len() <= 1 {
            return Err(SoundFontError::ZoneNotFound);
        }

        // The last one is the terminator.
        let count = infos.len() - 1;

        let mut zones: Vec<Zone> = Vec::new();
        for info in infos.iter().take(count) {
            zones.push(Zone::new(info, generators)?);
        }

        Ok(zones)
    }
}

#[cfg(test)]
mod tests {
    use super::{Generator, SoundFontError, Zone, ZoneInfo};

    fn info(generator_index: i32, generator_count: i32) -> ZoneInfo {
        ZoneInfo {
            generator_index,
            modulator_index: 0,
            generator_count,
            modulator_count: 0,
        }
    }

    #[test]
    fn zone_generator_spans_are_bounds_checked() {
        let generators = [Generator {
            generator_type: 1,
            value: 2,
        }];

        let zone = Zone::new(&info(0, 1), &generators).unwrap();
        assert_eq!(zone.generators.len(), 1);

        assert!(matches!(
            Zone::new(&info(1, 1), &generators),
            Err(SoundFontError::InvalidZoneList)
        ));
        assert!(matches!(
            Zone::new(&info(-1, 1), &generators),
            Err(SoundFontError::InvalidZoneList)
        ));
        assert!(matches!(
            Zone::new(&info(0, -1), &generators),
            Err(SoundFontError::InvalidZoneList)
        ));
    }
}
