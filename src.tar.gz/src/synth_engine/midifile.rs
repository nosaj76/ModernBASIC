#![allow(dead_code)]

use std::cmp::Reverse;
use std::collections::BinaryHeap;
use std::io::Read;

use super::binary_reader::BinaryReader;
use super::four_cc::FourCC;
use super::read_counter::ReadCounter;
use super::MidiFileError;
use super::MidiFileLoopType;

const MAX_MIDI_TRACKS: u16 = 256;
const MAX_MIDI_TRACK_BYTES: u32 = 16 * 1_024 * 1_024;
const MAX_MIDI_TOTAL_TRACK_BYTES: u64 = 32 * 1_024 * 1_024;

#[derive(Clone, Copy, Debug)]
#[non_exhaustive]
pub(crate) enum Message {
    Normal { status: u8, data1: u8, data2: u8 },
    TempoChange { bytes: [u8; 3] },
    LoopStart,
    LoopEnd,
    EndOfTrack,
}

impl Message {
    pub(crate) fn common1(status: u8, data1: u8) -> Self {
        Self::Normal {
            status,
            data1,
            data2: 0,
        }
    }

    pub(crate) fn common2(status: u8, data1: u8, data2: u8, loop_type: MidiFileLoopType) -> Self {
        let command = status & 0xF0;

        if command == 0xB0 {
            match loop_type {
                MidiFileLoopType::RpgMaker => {
                    if data1 == 111 {
                        return Message::LoopStart;
                    }
                }

                MidiFileLoopType::IncredibleMachine => {
                    if data1 == 110 {
                        return Message::LoopStart;
                    }
                    if data1 == 111 {
                        return Message::LoopEnd;
                    }
                }

                MidiFileLoopType::FinalFantasy => {
                    if data1 == 116 {
                        return Message::LoopStart;
                    }
                    if data1 == 117 {
                        return Message::LoopEnd;
                    }
                }

                _ => (),
            }
        }

        Self::Normal {
            status,
            data1,
            data2,
        }
    }

    pub(crate) fn tempo_change(tempo: i32) -> Self {
        // Truncate to u24
        let raw = tempo.to_be_bytes();
        let bytes = [raw[1], raw[2], raw[3]];
        Self::TempoChange { bytes }
    }
}

/// Represents a standard MIDI file.
#[derive(Debug)]
#[non_exhaustive]
pub struct MidiFile {
    pub(crate) messages: Vec<Message>,
    pub(crate) times: Vec<f64>,
}

impl MidiFile {
    /// Loads a MIDI file from the stream.
    ///
    /// # Arguments
    ///
    /// * `reader` - The data stream used to load the MIDI file.
    pub fn new<R: Read>(reader: &mut R) -> Result<Self, MidiFileError> {
        MidiFile::new_with_loop_type(reader, MidiFileLoopType::LoopPoint(0))
    }

    /// Loads a MIDI file from the stream with a specified loop type.
    ///
    /// # Arguments
    ///
    /// * `reader` - The data stream used to load the MIDI file.
    /// * `loop_type` - The type of the loop extension to be used.
    ///
    /// # Remarks
    ///
    /// `MidiFileLoopType` has the following variants:
    /// * `LoopPoint(usize)` - Specifies the loop start point by a tick value.
    /// * `RpgMaker` - The RPG Maker style loop.
    ///   CC #111 will be the loop start point.
    /// * `IncredibleMachine` - The Incredible Machine style loop.
    ///   CC #110 and #111 will be the start and end points of the loop.
    /// * `FinalFantasy` - The Final Fantasy style loop.
    ///   CC #116 and #117 will be the start and end points of the loop.
    pub fn new_with_loop_type<R: Read>(
        reader: &mut R,
        loop_type: MidiFileLoopType,
    ) -> Result<Self, MidiFileError> {
        let chunk_type = BinaryReader::read_four_cc(reader)?;
        if chunk_type != b"MThd" {
            return Err(MidiFileError::InvalidChunkType {
                expected: FourCC::from_bytes(*b"MThd"),
                actual: chunk_type,
            });
        }

        let size = BinaryReader::read_i32_big_endian(reader)?;
        if size != 6 {
            return Err(MidiFileError::InvalidChunkData(FourCC::from_bytes(
                *b"MThd",
            )));
        }

        let format = BinaryReader::read_i16_big_endian(reader)?;
        if !(format == 0 || format == 1) {
            return Err(MidiFileError::UnsupportedFormat(format));
        }

        let track_count = BinaryReader::read_u16_big_endian(reader)?;
        if track_count == 0 || track_count > MAX_MIDI_TRACKS || (format == 0 && track_count != 1) {
            return Err(MidiFileError::InvalidTrackCount(track_count));
        }
        let time_division = BinaryReader::read_i16_big_endian(reader)?;
        // SMPTE time divisions have the high bit set. This engine currently
        // supports only positive pulses-per-quarter-note divisions.
        if time_division <= 0 {
            return Err(MidiFileError::InvalidTimeDivision(time_division));
        }
        let resolution = i32::from(time_division);

        let mut message_lists: Vec<Vec<Message>> = Vec::new();
        let mut tick_lists: Vec<Vec<i32>> = Vec::new();
        let mut total_track_bytes = 0_u64;

        for _ in 0..track_count {
            let (message_list, tick_list) =
                MidiFile::read_track(reader, loop_type, &mut total_track_bytes)?;
            message_lists.push(message_list);
            tick_lists.push(tick_list);
        }

        match loop_type {
            MidiFileLoopType::LoopPoint(loop_point) if loop_point != 0 => {
                let loop_point = i32::try_from(loop_point)
                    .map_err(|_| MidiFileError::InvalidLoopPoint(loop_point))?;
                let tick_list = tick_lists
                    .first_mut()
                    .ok_or(MidiFileError::InvalidTrackCount(0))?;
                let message_list = message_lists
                    .first_mut()
                    .ok_or(MidiFileError::InvalidTrackCount(0))?;

                if loop_point <= tick_list.last().copied().unwrap_or(0) {
                    for i in 0..tick_list.len() {
                        if tick_list[i] >= loop_point {
                            tick_list.insert(i, loop_point);
                            message_list.insert(i, Message::LoopStart);
                            break;
                        }
                    }
                } else {
                    tick_list.push(loop_point);
                    message_list.push(Message::LoopStart);
                }
            }
            _ => (),
        }

        let (messages, times) = MidiFile::merge_tracks(&message_lists, &tick_lists, resolution);

        Ok(Self { messages, times })
    }

    fn discard_data<R: Read>(reader: &mut R) -> Result<(), MidiFileError> {
        let size = BinaryReader::read_i32_variable_length(reader)? as usize;
        BinaryReader::discard_data(reader, size)?;
        Ok(())
    }

    fn read_tempo<R: Read>(reader: &mut R) -> Result<i32, MidiFileError> {
        let size = BinaryReader::read_i32_variable_length(reader)?;
        if size != 3 {
            return Err(MidiFileError::InvalidTempoValue);
        }

        let b1 = BinaryReader::read_u8(reader)? as i32;
        let b2 = BinaryReader::read_u8(reader)? as i32;
        let b3 = BinaryReader::read_u8(reader)? as i32;

        let tempo = (b1 << 16) | (b2 << 8) | b3;
        if tempo == 0 {
            return Err(MidiFileError::InvalidTempoValue);
        }
        Ok(tempo)
    }

    fn read_track<R: Read>(
        reader: &mut R,
        loop_type: MidiFileLoopType,
        total_track_bytes: &mut u64,
    ) -> Result<(Vec<Message>, Vec<i32>), MidiFileError> {
        let chunk_type = BinaryReader::read_four_cc(reader)?;
        if chunk_type != b"MTrk" {
            return Err(MidiFileError::InvalidChunkType {
                expected: FourCC::from_bytes(*b"MTrk"),
                actual: chunk_type,
            });
        }

        let size = BinaryReader::read_u32_big_endian(reader)?;
        if size > MAX_MIDI_TRACK_BYTES {
            return Err(MidiFileError::InvalidTrackSize(size));
        }
        *total_track_bytes = total_track_bytes
            .checked_add(u64::from(size))
            .ok_or(MidiFileError::InvalidTrackSize(size))?;
        if *total_track_bytes > MAX_MIDI_TOTAL_TRACK_BYTES {
            return Err(MidiFileError::InvalidTrackSize(size));
        }
        let size = size as usize;
        let mut limited = reader.take(size as u64);
        let reader = &mut ReadCounter::new(&mut limited);

        let mut messages: Vec<Message> = Vec::new();
        let mut ticks: Vec<i32> = Vec::new();

        let mut tick: i32 = 0;
        let mut last_status: u8 = 0;

        loop {
            let delta = BinaryReader::read_i32_variable_length(reader)?;
            let first = BinaryReader::read_u8(reader)?;

            tick = tick
                .checked_add(delta)
                .ok_or(MidiFileError::InvalidTickValue)?;

            if (first & 128) == 0 {
                if last_status == 0 {
                    return Err(MidiFileError::InvalidRunningStatus);
                }
                let command = last_status & 0xF0;
                if command == 0xC0 || command == 0xD0 {
                    messages.push(Message::common1(last_status, first));
                    ticks.push(tick);
                } else {
                    let data2 = BinaryReader::read_u8(reader)?;
                    messages.push(Message::common2(last_status, first, data2, loop_type));
                    ticks.push(tick);
                }

                continue;
            }

            match first {
                0xF0 => MidiFile::discard_data(reader)?,
                0xF7 => MidiFile::discard_data(reader)?,
                0xFF => match BinaryReader::read_u8(reader)? {
                    0x2F => {
                        if BinaryReader::read_u8(reader)? != 0 {
                            return Err(MidiFileError::InvalidChunkData(FourCC::from_bytes(
                                *b"MTrk",
                            )));
                        }
                        messages.push(Message::EndOfTrack);
                        ticks.push(tick);

                        // Some MIDI files may have events inserted after the EOT.
                        // Such events should be ignored.
                        if reader.bytes_read() < size {
                            BinaryReader::discard_data(reader, size - reader.bytes_read())?;
                        }

                        return Ok((messages, ticks));
                    }
                    0x51 => {
                        messages.push(Message::tempo_change(MidiFile::read_tempo(reader)?));
                        ticks.push(tick);
                    }
                    _ => MidiFile::discard_data(reader)?,
                },
                _ => {
                    let command = first & 0xF0;
                    if command == 0xC0 || command == 0xD0 {
                        let data1 = BinaryReader::read_u8(reader)?;
                        messages.push(Message::common1(first, data1));
                        ticks.push(tick);
                    } else {
                        let data1 = BinaryReader::read_u8(reader)?;
                        let data2 = BinaryReader::read_u8(reader)?;
                        messages.push(Message::common2(first, data1, data2, loop_type));
                        ticks.push(tick);
                    }
                }
            }

            last_status = first
        }
    }

    fn merge_tracks(
        message_lists: &[Vec<Message>],
        tick_lists: &[Vec<i32>],
        resolution: i32,
    ) -> (Vec<Message>, Vec<f64>) {
        let mut merged_messages: Vec<Message> = Vec::new();
        let mut merged_times: Vec<f64> = Vec::new();

        let mut indices: Vec<usize> = vec![0; message_lists.len()];
        let mut pending = BinaryHeap::new();
        for (track, ticks) in tick_lists.iter().enumerate() {
            if let Some(tick) = ticks.first() {
                pending.push(Reverse((*tick, track)));
            }
        }

        let mut current_tick: i32 = 0;
        let mut current_time: f64 = 0.0;

        let mut tempo: f64 = 120.0;

        while let Some(Reverse((next_tick, track))) = pending.pop() {
            let delta_tick = next_tick - current_tick;
            let delta_time = 60.0 / (resolution as f64 * tempo) * delta_tick as f64;

            current_tick += delta_tick;
            current_time += delta_time;

            let message = message_lists[track][indices[track]];
            if let Message::TempoChange { bytes } = message {
                let tempo_i32 = i32::from_be_bytes([0, bytes[0], bytes[1], bytes[2]]);
                tempo = 60000000.0 / tempo_i32 as f64;
            } else {
                merged_messages.push(message);
                merged_times.push(current_time);
            }

            indices[track] += 1;
            if let Some(tick) = tick_lists[track].get(indices[track]) {
                pending.push(Reverse((*tick, track)));
            }
        }

        (merged_messages, merged_times)
    }

    /// Get the length of the MIDI file in seconds.
    pub fn get_length(&self) -> f64 {
        self.times.last().copied().unwrap_or(0.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    fn header(format: u16, tracks: u16, division: u16) -> Vec<u8> {
        let mut bytes = b"MThd\0\0\0\x06".to_vec();
        bytes.extend_from_slice(&format.to_be_bytes());
        bytes.extend_from_slice(&tracks.to_be_bytes());
        bytes.extend_from_slice(&division.to_be_bytes());
        bytes
    }

    fn one_track(events: &[u8]) -> Vec<u8> {
        let mut bytes = header(0, 1, 96);
        bytes.extend_from_slice(b"MTrk");
        bytes.extend_from_slice(&(events.len() as u32).to_be_bytes());
        bytes.extend_from_slice(events);
        bytes
    }

    #[test]
    fn test_message_size() {
        // Avoid increasing the size of the Message type
        assert_eq!(std::mem::size_of::<Message>(), 4);
    }

    #[test]
    fn zero_track_file_is_rejected_without_panicking() {
        let mut input = Cursor::new(header(1, 0, 96));
        assert!(matches!(
            MidiFile::new(&mut input),
            Err(MidiFileError::InvalidTrackCount(0))
        ));
    }

    #[test]
    fn format_zero_requires_exactly_one_track() {
        let mut input = Cursor::new(header(0, 2, 96));
        assert!(matches!(
            MidiFile::new(&mut input),
            Err(MidiFileError::InvalidTrackCount(2))
        ));
    }

    #[test]
    fn invalid_time_divisions_are_rejected() {
        for division in [0_u16, 0x8001] {
            let mut input = Cursor::new(header(0, 1, division));
            assert!(matches!(
                MidiFile::new(&mut input),
                Err(MidiFileError::InvalidTimeDivision(_))
            ));
        }
    }

    #[test]
    fn empty_track_has_a_finite_zero_length() {
        let mut input = Cursor::new(one_track(&[0, 0xff, 0x2f, 0]));
        let midi = MidiFile::new(&mut input).unwrap();
        assert_eq!(midi.get_length(), 0.0);
        assert!(midi.get_length().is_finite());
    }

    #[test]
    fn excessive_loop_point_is_rejected_without_panicking() {
        let mut input = Cursor::new(one_track(&[0, 0xff, 0x2f, 0]));
        assert!(matches!(
            MidiFile::new_with_loop_type(&mut input, MidiFileLoopType::LoopPoint(usize::MAX)),
            Err(MidiFileError::InvalidLoopPoint(_))
        ));
    }

    #[test]
    fn zero_tempo_and_uninitialized_running_status_are_rejected() {
        let mut zero_tempo = Cursor::new(one_track(&[0, 0xff, 0x51, 3, 0, 0, 0, 0, 0xff, 0x2f, 0]));
        assert!(matches!(
            MidiFile::new(&mut zero_tempo),
            Err(MidiFileError::InvalidTempoValue)
        ));

        let mut running = Cursor::new(one_track(&[0, 60, 100, 0, 0xff, 0x2f, 0]));
        assert!(matches!(
            MidiFile::new(&mut running),
            Err(MidiFileError::InvalidRunningStatus)
        ));
    }

    #[test]
    fn events_cannot_read_past_the_declared_track_chunk() {
        let mut bytes = header(0, 1, 96);
        bytes.extend_from_slice(b"MTrk\0\0\0\x02\0\x90");
        // Bytes after the declared chunk must not satisfy the incomplete event.
        bytes.extend_from_slice(&[60, 100, 0, 0xff, 0x2f, 0]);
        let mut input = Cursor::new(bytes);
        assert!(matches!(
            MidiFile::new(&mut input),
            Err(MidiFileError::IoError(_))
        ));
    }

    #[test]
    fn oversized_track_is_rejected_before_payload_allocation() {
        let mut bytes = header(0, 1, 96);
        bytes.extend_from_slice(b"MTrk");
        bytes.extend_from_slice(&(MAX_MIDI_TRACK_BYTES + 1).to_be_bytes());
        let mut input = Cursor::new(bytes);
        assert!(matches!(
            MidiFile::new(&mut input),
            Err(MidiFileError::InvalidTrackSize(_))
        ));
    }

    #[test]
    fn heap_merge_preserves_tick_then_track_order() {
        let tracks = vec![
            vec![Message::common1(0xc0, 1), Message::common1(0xc0, 2)],
            vec![Message::common1(0xc1, 3), Message::common1(0xc1, 4)],
        ];
        let ticks = vec![vec![0, 10], vec![0, 5]];
        let (messages, times) = MidiFile::merge_tracks(&tracks, &ticks, 100);
        let statuses = messages
            .into_iter()
            .map(|message| match message {
                Message::Normal { status, data1, .. } => (status, data1),
                _ => unreachable!(),
            })
            .collect::<Vec<_>>();
        assert_eq!(statuses, vec![(0xc0, 1), (0xc1, 3), (0xc1, 4), (0xc0, 2)]);
        assert!(times.windows(2).all(|window| window[0] <= window[1]));
    }
}
