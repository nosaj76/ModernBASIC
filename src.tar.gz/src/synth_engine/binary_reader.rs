#![allow(dead_code)]

use std::io;
use std::io::ErrorKind;
use std::io::Read;
use std::str;

use super::four_cc::FourCC;

const MAX_METADATA_STRING_BYTES: usize = 1_048_576;
const MAX_WAVE_DATA_BYTES: usize = 512 * 1_048_576;
const WAVE_READ_CHUNK_BYTES: usize = 64 * 1_024;

#[allow(unused)]
#[non_exhaustive]
pub(crate) struct BinaryReader {}

impl BinaryReader {
    pub(crate) fn read_i8<R: Read>(reader: &mut R) -> Result<i8, io::Error> {
        let mut data: [u8; 1] = [0; 1];
        reader.read_exact(&mut data)?;
        Ok(i8::from_le_bytes(data))
    }

    pub(crate) fn read_u8<R: Read>(reader: &mut R) -> Result<u8, io::Error> {
        let mut data: [u8; 1] = [0; 1];
        reader.read_exact(&mut data)?;
        Ok(u8::from_le_bytes(data))
    }

    pub(crate) fn read_i16<R: Read>(reader: &mut R) -> Result<i16, io::Error> {
        let mut data: [u8; 2] = [0; 2];
        reader.read_exact(&mut data)?;
        Ok(i16::from_le_bytes(data))
    }

    pub(crate) fn read_u16<R: Read>(reader: &mut R) -> Result<u16, io::Error> {
        let mut data: [u8; 2] = [0; 2];
        reader.read_exact(&mut data)?;
        Ok(u16::from_le_bytes(data))
    }

    pub(crate) fn read_i32<R: Read>(reader: &mut R) -> Result<i32, io::Error> {
        let mut data: [u8; 4] = [0; 4];
        reader.read_exact(&mut data)?;
        Ok(i32::from_le_bytes(data))
    }

    pub(crate) fn read_u32<R: Read>(reader: &mut R) -> Result<u32, io::Error> {
        let mut data: [u8; 4] = [0; 4];
        reader.read_exact(&mut data)?;
        Ok(u32::from_le_bytes(data))
    }

    pub(crate) fn read_i16_big_endian<R: Read>(reader: &mut R) -> Result<i16, io::Error> {
        let mut data: [u8; 2] = [0; 2];
        reader.read_exact(&mut data)?;
        Ok(i16::from_be_bytes(data))
    }

    pub(crate) fn read_u16_big_endian<R: Read>(reader: &mut R) -> Result<u16, io::Error> {
        let mut data: [u8; 2] = [0; 2];
        reader.read_exact(&mut data)?;
        Ok(u16::from_be_bytes(data))
    }

    pub(crate) fn read_i32_big_endian<R: Read>(reader: &mut R) -> Result<i32, io::Error> {
        let mut data: [u8; 4] = [0; 4];
        reader.read_exact(&mut data)?;
        Ok(i32::from_be_bytes(data))
    }

    pub(crate) fn read_u32_big_endian<R: Read>(reader: &mut R) -> Result<u32, io::Error> {
        let mut data: [u8; 4] = [0; 4];
        reader.read_exact(&mut data)?;
        Ok(u32::from_be_bytes(data))
    }

    pub(crate) fn read_i32_variable_length<R: Read>(reader: &mut R) -> Result<i32, io::Error> {
        let mut acc: i32 = 0;
        let mut count: i32 = 0;

        loop {
            let value = BinaryReader::read_u8(reader)? as i32;
            acc = (acc << 7) | (value & 127);
            if (value & 128) == 0 {
                break;
            }
            count += 1;
            if count == 4 {
                return Err(io::Error::new(
                    ErrorKind::InvalidData,
                    "the length of the value must be equal to or less than 4",
                ));
            }
        }

        Ok(acc)
    }

    pub(crate) fn read_four_cc<R: Read>(reader: &mut R) -> Result<FourCC, io::Error> {
        let mut data: [u8; 4] = [0; 4];
        reader.read_exact(&mut data)?;
        Ok(FourCC::from_bytes(data))
    }

    pub(crate) fn read_fixed_length_string<R: Read>(
        reader: &mut R,
        length: usize,
    ) -> Result<String, io::Error> {
        if length > MAX_METADATA_STRING_BYTES {
            return Err(io::Error::new(
                ErrorKind::InvalidData,
                "SoundFont metadata string exceeds the supported size",
            ));
        }

        let mut data: Vec<u8> = vec![0; length];
        reader.read_exact(&mut data)?;

        let mut actual_length: usize = 0;
        for value in &mut data {
            if *value == 0 {
                break;
            }
            actual_length += 1;
        }

        // Replace non-ASCII characters with '?'.
        // Tabs and returns are preserved.
        for value in &mut data[0..actual_length] {
            if !(9..=126).contains(value) {
                *value = 63; // '?'
            }
        }

        Ok(str::from_utf8(&data[0..actual_length]).unwrap().to_string())
    }

    pub(crate) fn discard_data<R: Read>(reader: &mut R, size: usize) -> Result<(), io::Error> {
        let mut buffer = [0_u8; 16 * 1_024];
        let mut remaining = size;
        while remaining > 0 {
            let chunk = remaining.min(buffer.len());
            reader.read_exact(&mut buffer[..chunk])?;
            remaining -= chunk;
        }
        Ok(())
    }

    pub(crate) fn read_wave_data<R: Read>(
        reader: &mut R,
        size: usize,
    ) -> Result<Vec<i16>, io::Error> {
        if size % 2 != 0 {
            return Err(io::Error::new(
                ErrorKind::InvalidData,
                "16-bit SoundFont sample data must contain an even byte count",
            ));
        }
        if size > MAX_WAVE_DATA_BYTES {
            return Err(io::Error::new(
                ErrorKind::InvalidData,
                "SoundFont sample data exceeds the supported size",
            ));
        }

        // Read incrementally so a small, truncated file cannot force a
        // full-size allocation merely by declaring a large chunk size.
        let mut samples = Vec::with_capacity((size / 2).min(WAVE_READ_CHUNK_BYTES / 2));
        let mut buffer = [0_u8; WAVE_READ_CHUNK_BYTES];
        let mut remaining = size;
        while remaining > 0 {
            let chunk = remaining.min(buffer.len());
            reader.read_exact(&mut buffer[..chunk])?;
            samples.extend(
                buffer[..chunk]
                    .chunks_exact(2)
                    .map(|bytes| i16::from_le_bytes([bytes[0], bytes[1]])),
            );
            remaining -= chunk;
        }

        Ok(samples)
    }
}

#[cfg(test)]
mod tests {
    use super::BinaryReader;
    use std::io::{Cursor, ErrorKind};

    #[test]
    fn wave_data_is_decoded_as_little_endian_i16() {
        let mut input = Cursor::new(vec![0x34, 0x12, 0x00, 0x80]);
        let samples = BinaryReader::read_wave_data(&mut input, 4).unwrap();
        assert_eq!(samples, vec![0x1234, i16::MIN]);
    }

    #[test]
    fn odd_wave_data_size_is_rejected_before_reading() {
        let mut input = Cursor::new(vec![0_u8; 3]);
        let error = BinaryReader::read_wave_data(&mut input, 3).unwrap_err();
        assert_eq!(error.kind(), ErrorKind::InvalidData);
    }

    #[test]
    fn oversized_declared_lengths_are_rejected_before_allocation() {
        let mut input = Cursor::new(Vec::<u8>::new());

        let string_error = BinaryReader::read_fixed_length_string(
            &mut input,
            super::MAX_METADATA_STRING_BYTES + 1,
        )
        .unwrap_err();
        assert_eq!(string_error.kind(), ErrorKind::InvalidData);

        let wave_error =
            BinaryReader::read_wave_data(&mut input, super::MAX_WAVE_DATA_BYTES + 2).unwrap_err();
        assert_eq!(wave_error.kind(), ErrorKind::InvalidData);
    }

    #[test]
    fn truncated_wave_data_does_not_preallocate_the_declared_size() {
        let mut input = Cursor::new(Vec::<u8>::new());
        let error = BinaryReader::read_wave_data(&mut input, 64 * 1_024).unwrap_err();
        assert_eq!(error.kind(), ErrorKind::UnexpectedEof);
    }
}
