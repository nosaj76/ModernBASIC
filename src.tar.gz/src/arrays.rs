//! Native sparse array storage for the ModernBASIC interpreter.
//!
//! This module corresponds to the array handling in the original
//! `array.s` / `var.s` files, but uses a Rust-native side-by-side design:
//! arrays are stored as sparse hash maps keyed by a row-major offset, and
//! every dimension / subscript calculation is checked.  No 6502 memory
//! layout or emulator is used.

use std::collections::{HashMap, HashSet};

use crate::error::Error;
use crate::storage::StorageBudget;
use crate::value::{is_string_variable, Value};

/// Default inclusive upper bound for an array dimension referenced before
/// an explicit `DIM`.
pub const IMPLICIT_UPPER_BOUND: i64 = 10;
/// Default size (`upper_bound + 1`) of an implicitly dimensioned dimension.
const IMPLICIT_SIZE: usize = (IMPLICIT_UPPER_BOUND + 1) as usize;

/// Default maximum logical array element count for modern 64-bit mode.
pub const DEFAULT_MAX_ARRAY_ELEMENTS: usize = 1_000_000;
/// Tighter default for legacy 6502-compatible mode, matching the original
/// 16-bit address-space expectations.
pub const LEGACY_MAX_ARRAY_ELEMENTS: usize = 65_536;

/// A single dimensioned BASIC array.
#[derive(Debug, Clone)]
pub struct BasicArray {
    /// Per-dimension size (`upper_bound + 1`).
    dims: Vec<usize>,
    /// Total slots reserved by the original `DIM` or implicit allocation.
    /// Dartmouth MAT may reshape the active dimensions within this capacity.
    capacity: usize,
    /// Whether this array stores strings (name ends in `$`).
    lower_bound: usize,
    is_string: bool,
    fixed_string_bytes: Option<usize>,
    /// Sparse element storage keyed by row-major offset.
    elements: HashMap<usize, Value>,
}

impl BasicArray {
    /// Create an array with the given per-dimension sizes and element type.
    #[cfg(test)]
    fn new(dims: Vec<usize>, is_string: bool) -> Self {
        let capacity = dims.iter().copied().product();
        Self::with_capacity_and_lower_bound(dims, capacity, is_string, 0)
    }

    fn with_capacity(dims: Vec<usize>, capacity: usize, is_string: bool) -> Self {
        Self::with_capacity_and_lower_bound(dims, capacity, is_string, 0)
    }

    fn with_capacity_and_lower_bound(
        dims: Vec<usize>,
        capacity: usize,
        is_string: bool,
        lower_bound: usize,
    ) -> Self {
        Self::with_declared_string_width(dims, capacity, is_string, lower_bound, None)
    }

    fn with_declared_string_width(
        dims: Vec<usize>,
        capacity: usize,
        is_string: bool,
        lower_bound: usize,
        fixed_string_bytes: Option<usize>,
    ) -> Self {
        Self {
            dims,
            capacity,
            lower_bound,
            is_string,
            fixed_string_bytes,
            elements: HashMap::new(),
        }
    }

    /// Whether the array stores strings.
    pub fn is_string(&self) -> bool {
        self.is_string
    }

    /// The per-dimension sizes (`upper_bound + 1` for each dimension).
    pub fn dims(&self) -> &[usize] {
        &self.dims
    }

    /// Return one dimension's declared lower or upper bound. BASIC dimension
    /// numbers are one-based even when the array's subscripts start at zero.
    fn bound(&self, dimension: usize, upper: bool) -> Result<i64, Error> {
        let index = dimension.checked_sub(1).ok_or(Error::BadSubscript)?;
        let size = *self.dims.get(index).ok_or(Error::BadSubscript)?;
        let bound = if upper {
            self.lower_bound
                .checked_add(size)
                .and_then(|exclusive| exclusive.checked_sub(1))
                .ok_or(Error::ArrayTooLarge)?
        } else {
            self.lower_bound
        };
        i64::try_from(bound).map_err(|_| Error::ArrayTooLarge)
    }

    /// Total number of logical elements in the array.
    pub fn logical_len(&self) -> usize {
        self.dims.iter().product()
    }

    /// Total physical slots reserved for this array.
    pub fn reserved_len(&self) -> usize {
        self.capacity
    }

    /// Read an element, returning the appropriate default if it has never
    /// been written.
    pub fn load(&self, indices: &[i64]) -> Result<Value, Error> {
        let offset = self.compute_offset(indices)?;
        Ok(self
            .elements
            .get(&offset)
            .cloned()
            .unwrap_or_else(|| self.default_value()))
    }

    fn load_linear(&self, offset: usize) -> Result<Value, Error> {
        if offset >= self.logical_len() {
            return Err(Error::BadSubscript);
        }
        Ok(self
            .elements
            .get(&offset)
            .cloned()
            .unwrap_or_else(|| self.default_value()))
    }

    /// Write an element, enforcing the array's element type.
    pub fn store(&mut self, indices: &[i64], value: Value) -> Result<(), Error> {
        let value = self.coerce_value(value)?;
        let offset = self.compute_offset(indices)?;
        self.elements.insert(offset, value);
        Ok(())
    }

    /// Write an element while atomically updating a shared payload budget.
    fn store_bounded(
        &mut self,
        indices: &[i64],
        value: Value,
        storage: &mut StorageBudget,
    ) -> Result<(), Error> {
        let value = self.coerce_value(value)?;
        let offset = self.compute_offset(indices)?;
        storage.replace(self.elements.get(&offset), &value)?;
        self.elements.insert(offset, value);
        Ok(())
    }

    fn coerce_value(&self, mut value: Value) -> Result<Value, Error> {
        if (self.is_string && !value.is_string()) || (!self.is_string && !value.is_numeric()) {
            return Err(Error::TypeMismatch);
        }
        if let (Some(length), Value::String(text)) = (self.fixed_string_bytes, &mut value) {
            while text.len() > length {
                text.pop();
            }
            if text.len() < length {
                text.push_str(&" ".repeat(length - text.len()));
            }
        }
        Ok(value)
    }

    /// The default value for an unwritten element.
    fn default_value(&self) -> Value {
        if self.is_string {
            Value::String(
                self.fixed_string_bytes
                    .map_or_else(String::new, |length| " ".repeat(length)),
            )
        } else {
            Value::Integer(0)
        }
    }

    /// Checked row-major offset calculation.
    fn compute_offset(&self, indices: &[i64]) -> Result<usize, Error> {
        if indices.len() != self.dims.len() {
            return Err(Error::BadSubscript);
        }

        let mut offset: usize = 0;
        for (&size, &index) in self.dims.iter().zip(indices.iter()) {
            if index < 0 {
                return Err(Error::IllegalQuantity);
            }
            let index = usize::try_from(index).map_err(|_| Error::BadSubscript)?;
            let idx = index
                .checked_sub(self.lower_bound)
                .ok_or(Error::BadSubscript)?;
            if idx >= size {
                return Err(Error::BadSubscript);
            }
            offset = offset.checked_mul(size).ok_or(Error::ArrayTooLarge)?;
            offset = offset.checked_add(idx).ok_or(Error::ArrayTooLarge)?;
        }
        Ok(offset)
    }

    /// Recover BASIC subscripts from a sparse row-major offset.
    fn indices_for_offset(&self, mut offset: usize) -> Vec<i64> {
        let mut indices = vec![0; self.dims.len()];
        for dimension in (0..self.dims.len()).rev() {
            let size = self.dims[dimension];
            indices[dimension] = (offset % size + self.lower_bound) as i64;
            offset /= size;
        }
        indices
    }
}

/// A collection of dimensioned arrays with a configurable logical-size cap.
#[derive(Debug, Clone)]
pub struct ArrayStore {
    arrays: HashMap<String, BasicArray>,
    /// Procedure-local array-name aliases. Only the active procedure scope is
    /// consulted, matching scalar procedure isolation.
    alias_scopes: Vec<HashMap<String, String>>,
    max_elements: usize,
    total_elements: usize,
    option_base: usize,
}

impl Default for ArrayStore {
    fn default() -> Self {
        Self::new(DEFAULT_MAX_ARRAY_ELEMENTS)
    }
}

impl ArrayStore {
    /// Create an empty store with the given total element limit.
    pub fn new(max_elements: usize) -> Self {
        Self {
            arrays: HashMap::new(),
            alias_scopes: Vec::new(),
            max_elements,
            total_elements: 0,
            option_base: 0,
        }
    }

    /// The configured total logical element limit.
    pub fn max_elements(&self) -> usize {
        self.max_elements
    }

    /// Resolve a name in the active procedure's array-alias scope.
    pub(crate) fn canonical_name(&self, name: &str) -> String {
        self.alias_scopes
            .last()
            .and_then(|scope| scope.get(name))
            .cloned()
            .unwrap_or_else(|| name.to_string())
    }

    /// Enter one structured procedure's array-alias scope. An empty scope is
    /// significant because it hides aliases belonging to its caller.
    pub(crate) fn push_alias_scope(&mut self, aliases: HashMap<String, String>) {
        self.alias_scopes.push(aliases);
    }

    /// Return the active procedure's explicit mapping for `name`.
    pub(crate) fn active_alias(&self, name: &str) -> Option<&str> {
        self.alias_scopes
            .last()
            .and_then(|scope| scope.get(name))
            .map(String::as_str)
    }

    /// Register one array name in the active procedure scope.
    pub(crate) fn insert_active_alias(
        &mut self,
        name: String,
        canonical: String,
    ) -> Result<(), Error> {
        let scope = self
            .alias_scopes
            .last_mut()
            .ok_or_else(|| Error::syntax("local array declaration without procedure scope"))?;
        scope.insert(name, canonical);
        Ok(())
    }

    /// Leave the active structured procedure's array-alias scope.
    pub(crate) fn pop_alias_scope(&mut self) -> Result<(), Error> {
        self.alias_scopes
            .pop()
            .map(|_| ())
            .ok_or_else(|| Error::syntax("array alias scope underflow"))
    }

    /// Discard procedure alias state without changing physical arrays.
    pub(crate) fn clear_alias_scopes(&mut self) {
        self.alias_scopes.clear();
    }

    /// Borrow an existing array by name, if any.
    pub fn get(&self, name: &str) -> Option<&BasicArray> {
        self.arrays.get(&self.canonical_name(name))
    }

    /// Query a declared array bound without implicitly allocating an array.
    pub(crate) fn bound(&self, name: &str, dimension: usize, upper: bool) -> Result<i64, Error> {
        self.get(name)
            .ok_or(Error::BadSubscript)?
            .bound(dimension, upper)
    }

    /// Ensure a numeric Dartmouth vector or matrix exists.
    ///
    /// A missing name receives the traditional implicit upper bound of ten in
    /// each requested dimension. Existing arrays retain their active rank;
    /// `default_rank` only resolves an otherwise ambiguous new name.
    pub(crate) fn ensure_numeric_mat(
        &mut self,
        name: &str,
        default_rank: usize,
    ) -> Result<(), Error> {
        let name = self.canonical_name(name);
        if !(1..=2).contains(&default_rank) {
            return Err(Error::MatrixRankUnsupported {
                dimensions: default_rank,
            });
        }
        if !self.arrays.contains_key(&name) {
            let dims = vec![IMPLICIT_SIZE; default_rank];
            self.insert_array_with_lower_bound(name.to_string(), dims, false, 0)?;
        }
        let array = self
            .arrays
            .get(&name)
            .ok_or_else(|| Error::syntax("internal MAT array missing after dimensioning"))?;
        if array.is_string {
            return Err(Error::TypeMismatch);
        }
        if !(1..=2).contains(&array.dims.len()) {
            return Err(Error::MatrixRankUnsupported {
                dimensions: array.dims.len(),
            });
        }
        Ok(())
    }

    /// Atomically replace the logical contents and active shape of a numeric
    /// Dartmouth vector or matrix.
    ///
    /// `upper_bounds` are also the MAT-visible component counts. `[n]` stores
    /// components 1 through n; `[rows, columns]` excludes row and column zero.
    /// The physical shape therefore has one extra slot in every dimension.
    pub(crate) fn replace_numeric_mat(
        &mut self,
        name: &str,
        upper_bounds: &[usize],
        values: &[Value],
        storage: &mut StorageBudget,
    ) -> Result<(), Error> {
        let name = self.canonical_name(name);
        if !(1..=2).contains(&upper_bounds.len()) {
            return Err(Error::MatrixRankUnsupported {
                dimensions: upper_bounds.len(),
            });
        }
        if is_string_variable(&name) || values.iter().any(|value| !value.is_numeric()) {
            return Err(Error::TypeMismatch);
        }

        let mut dims = Vec::with_capacity(upper_bounds.len());
        let mut physical_len = 1usize;
        let row_vector = matches!(upper_bounds, [0, _]);
        let mut logical_len = if row_vector { upper_bounds[1] } else { 1 };
        for &bound in upper_bounds {
            let size = bound.checked_add(1).ok_or(Error::ArrayTooLarge)?;
            physical_len = physical_len.checked_mul(size).ok_or(Error::ArrayTooLarge)?;
            if !row_vector {
                logical_len = logical_len.checked_mul(bound).ok_or(Error::ArrayTooLarge)?;
            }
            dims.push(size);
        }
        if values.len() != logical_len {
            return Err(Error::syntax(
                "internal MAT value count does not match its dimensions",
            ));
        }

        let existing = self.arrays.get(&name);
        if existing.is_some_and(BasicArray::is_string) {
            return Err(Error::TypeMismatch);
        }
        if let Some(array) = existing {
            if !(1..=2).contains(&array.dims.len()) {
                return Err(Error::MatrixRankUnsupported {
                    dimensions: array.dims.len(),
                });
            }
        }
        let reserved = existing.map_or_else(
            || {
                (0..upper_bounds.len()).try_fold(1usize, |product, _| {
                    product
                        .checked_mul(IMPLICIT_SIZE)
                        .ok_or(Error::ArrayTooLarge)
                })
            },
            |array| Ok(array.capacity),
        )?;
        if physical_len > reserved {
            return Err(Error::MatrixCapacityExceeded {
                requested: physical_len,
                reserved,
            });
        }

        if existing.is_none() {
            let total = self
                .total_elements
                .checked_add(reserved)
                .ok_or(Error::ArrayTooLarge)?;
            if reserved > self.max_elements || total > self.max_elements {
                return Err(Error::ArrayTooLarge);
            }
        }

        let mut staged_storage = storage.clone();
        let preserved_fringe = existing
            .filter(|array| array.dims == dims)
            .map(|array| {
                array
                    .elements
                    .iter()
                    .filter(|(offset, _)| !mat_logical_offset(&array.dims, **offset))
                    .map(|(offset, value)| (*offset, value.clone()))
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        if let Some(array) = existing {
            for value in array.elements.values() {
                staged_storage.remove(value)?;
            }
        }

        let mut replacement = BasicArray::with_capacity(dims, reserved, false);
        for (offset, value) in preserved_fringe {
            staged_storage.replace(None, &value)?;
            replacement.elements.insert(offset, value);
        }
        match upper_bounds {
            [length] => {
                for (index, value) in (1..=*length).zip(values) {
                    if numeric_zero(value) {
                        continue;
                    }
                    staged_storage.replace(None, value)?;
                    replacement.store(&[index as i64], value.clone())?;
                }
            }
            [0, columns] => {
                for (column, value) in (1..=*columns).zip(values) {
                    if numeric_zero(value) {
                        continue;
                    }
                    staged_storage.replace(None, value)?;
                    replacement.store(&[0, column as i64], value.clone())?;
                }
            }
            [rows, columns] => {
                let mut values = values.iter();
                for row in 1..=*rows {
                    for column in 1..=*columns {
                        let value = values.next().ok_or_else(|| {
                            Error::syntax("internal MAT value traversal ended early")
                        })?;
                        if numeric_zero(value) {
                            continue;
                        }
                        staged_storage.replace(None, value)?;
                        replacement.store(&[row as i64, column as i64], value.clone())?;
                    }
                }
            }
            _ => unreachable!("MAT rank validated above"),
        }

        if existing.is_none() {
            self.total_elements += reserved;
        }
        self.arrays.insert(name, replacement);
        *storage = staged_storage;
        Ok(())
    }

    /// Clone only arrays whose names are declared COMMON for a CHAIN.
    pub(crate) fn clone_selected(&self, names: &HashSet<String>) -> Self {
        let names = names
            .iter()
            .map(|name| self.canonical_name(name))
            .collect::<HashSet<_>>();
        let arrays = self
            .arrays
            .iter()
            .filter(|(name, _)| names.contains(*name))
            .map(|(name, array)| (name.clone(), array.clone()))
            .collect::<HashMap<_, _>>();
        let total_elements = arrays.values().map(BasicArray::reserved_len).sum();
        Self {
            arrays,
            alias_scopes: Vec::new(),
            max_elements: self.max_elements,
            total_elements,
            option_base: self.option_base,
        }
    }

    /// Iterate over explicitly stored element values for storage accounting.
    pub(crate) fn stored_values(&self) -> impl Iterator<Item = &Value> {
        self.arrays
            .values()
            .flat_map(|array| array.elements.values())
    }

    /// Store a graphics GET image in row-major array storage. The first two
    /// logical elements contain width and height; ARGB pixels follow. Existing
    /// one- and two-dimensional arrays keep their declared shape, while a
    /// missing array is created as an exactly-sized vector.
    pub(crate) fn store_graphics_image(
        &mut self,
        name: &str,
        width: usize,
        height: usize,
        pixels: &[u32],
        storage: &mut StorageBudget,
    ) -> Result<(), Error> {
        let pixel_count = width.checked_mul(height).ok_or(Error::ArrayTooLarge)?;
        if width == 0 || height == 0 || pixels.len() != pixel_count {
            return Err(Error::IllegalQuantity);
        }
        let required = pixel_count.checked_add(2).ok_or(Error::ArrayTooLarge)?;
        let name = self.canonical_name(name);
        if is_string_variable(&name) {
            return Err(Error::TypeMismatch);
        }

        let existing = self.arrays.get(&name);
        if existing.is_some_and(BasicArray::is_string) {
            return Err(Error::TypeMismatch);
        }
        if existing.is_some_and(|array| !(1..=2).contains(&array.dims.len())) {
            return Err(Error::BadSubscript);
        }
        if existing.is_some_and(|array| array.logical_len() < required) {
            return Err(Error::BadSubscript);
        }
        if existing.is_none() {
            let total = self
                .total_elements
                .checked_add(required)
                .ok_or(Error::ArrayTooLarge)?;
            if required > self.max_elements || total > self.max_elements {
                return Err(Error::ArrayTooLarge);
            }
        }

        let mut replacement = existing.cloned().unwrap_or_else(|| {
            BasicArray::with_capacity_and_lower_bound(
                vec![required],
                required,
                false,
                self.option_base,
            )
        });
        let mut staged_storage = storage.clone();
        let values = std::iter::once(width as u32)
            .chain(std::iter::once(height as u32))
            .chain(pixels.iter().copied());
        for (offset, value) in values.enumerate() {
            let value = Value::Integer(i64::from(value));
            if value == Value::Integer(0) {
                if let Some(previous) = replacement.elements.remove(&offset) {
                    staged_storage.remove(&previous)?;
                }
            } else {
                staged_storage.replace(replacement.elements.get(&offset), &value)?;
                replacement.elements.insert(offset, value);
            }
        }
        if existing.is_none() {
            self.total_elements += required;
        }
        self.arrays.insert(name, replacement);
        *storage = staged_storage;
        Ok(())
    }

    pub(crate) fn load_graphics_image(
        &self,
        name: &str,
    ) -> Result<(usize, usize, Vec<u32>), Error> {
        let array = self.get(name).ok_or(Error::BadSubscript)?;
        if array.is_string || !(1..=2).contains(&array.dims.len()) {
            return Err(if array.is_string {
                Error::TypeMismatch
            } else {
                Error::BadSubscript
            });
        }
        let width = usize::try_from(array.load_linear(0)?.to_integer()?)
            .map_err(|_| Error::IllegalQuantity)?;
        let height = usize::try_from(array.load_linear(1)?.to_integer()?)
            .map_err(|_| Error::IllegalQuantity)?;
        let pixel_count = width.checked_mul(height).ok_or(Error::ArrayTooLarge)?;
        let required = pixel_count.checked_add(2).ok_or(Error::ArrayTooLarge)?;
        if width == 0 || height == 0 || required > array.logical_len() {
            return Err(Error::BadSubscript);
        }
        let pixels = (0..pixel_count)
            .map(|offset| {
                let value = array.load_linear(offset + 2)?.to_integer()?;
                u32::try_from(value).map_err(|_| Error::IllegalQuantity)
            })
            .collect::<Result<Vec<_>, Error>>()?;
        Ok((width, height, pixels))
    }

    /// Remove every array while preserving the configured capacity limit.
    pub fn clear(&mut self) {
        self.arrays.clear();
        self.alias_scopes.clear();
        self.total_elements = 0;
    }

    /// Remove a single named array and atomically release both its reserved
    /// element capacity and every explicitly stored value payload.
    pub(crate) fn remove_bounded(
        &mut self,
        name: &str,
        storage: &mut StorageBudget,
    ) -> Result<(), Error> {
        let name = self.canonical_name(name);
        let Some(array) = self.arrays.get(&name) else {
            return Ok(());
        };
        let mut staged_storage = storage.clone();
        for value in array.elements.values() {
            staged_storage.remove(value)?;
        }
        let reserved = array.reserved_len();
        self.arrays.remove(&name);
        self.total_elements = self.total_elements.saturating_sub(reserved);
        *storage = staged_storage;
        Ok(())
    }

    /// Set the implicit lower bound for future DIM statements (0 or 1).
    pub fn set_option_base(&mut self, base: usize) {
        self.option_base = base;
    }

    /// Explicitly dimension an array.  Upper bounds are inclusive and must
    /// be non-negative.  Redimensioning an existing array is an error.
    pub fn dim(&mut self, name: &str, upper_bounds: &[i64]) -> Result<(), Error> {
        let name = self.canonical_name(name);
        self.dim_typed(&name, upper_bounds, is_string_variable(&name))
    }

    /// Explicitly dimension an array whose element kind comes from an `AS`
    /// declaration rather than a variable-name suffix.
    pub(crate) fn dim_typed(
        &mut self,
        name: &str,
        upper_bounds: &[i64],
        is_string: bool,
    ) -> Result<(), Error> {
        self.dim_typed_fixed(name, upper_bounds, is_string, None)
    }

    /// Explicitly dimension an array with an optional fixed string width.
    pub(crate) fn dim_typed_fixed(
        &mut self,
        name: &str,
        upper_bounds: &[i64],
        is_string: bool,
        fixed_string_bytes: Option<usize>,
    ) -> Result<(), Error> {
        let name = self.canonical_name(name);
        if upper_bounds.is_empty() {
            return Err(Error::syntax("DIM requires at least one dimension"));
        }
        if upper_bounds
            .iter()
            .any(|&bound| bound < self.option_base as i64)
        {
            return Err(Error::IllegalQuantity);
        }
        if self.arrays.contains_key(&name) {
            return Err(Error::RedimensionedArray);
        }
        let mut dims = Vec::with_capacity(upper_bounds.len());
        for &bound in upper_bounds {
            let bound = usize::try_from(bound).map_err(|_| Error::ArrayTooLarge)?;
            // Any single dimension larger than the configured limit would
            // exceed the total anyway.
            if bound > self.max_elements {
                return Err(Error::ArrayTooLarge);
            }
            let size = bound
                .checked_add(1)
                .and_then(|size| size.checked_sub(self.option_base))
                .ok_or(Error::ArrayTooLarge)?;
            dims.push(size);
        }
        self.insert_array_with_lower_bound_and_width(
            name,
            dims,
            is_string,
            self.option_base,
            fixed_string_bytes,
        )
    }

    /// Resize an array. Without `preserve`, all values are reset to their
    /// defaults. With `preserve`, explicitly stored values whose coordinates
    /// remain inside the new shape survive. Rank changes while preserving are
    /// rejected because coordinates would be ambiguous.
    ///
    /// Capacity checks, sparse values, and retained-value storage accounting
    /// are staged so every failure leaves the original array untouched.
    pub(crate) fn redim_bounded(
        &mut self,
        name: &str,
        upper_bounds: &[i64],
        preserve: bool,
        storage: &mut StorageBudget,
    ) -> Result<(), Error> {
        let name = self.canonical_name(name);
        self.redim_bounded_typed(
            &name,
            upper_bounds,
            preserve,
            storage,
            is_string_variable(&name),
        )
    }

    /// Resize an array whose element kind comes from an explicit `AS`
    /// declaration rather than a name suffix.
    pub(crate) fn redim_bounded_typed(
        &mut self,
        name: &str,
        upper_bounds: &[i64],
        preserve: bool,
        storage: &mut StorageBudget,
        is_string: bool,
    ) -> Result<(), Error> {
        self.redim_bounded_typed_fixed(name, upper_bounds, preserve, storage, is_string, None)
    }

    /// Resize an explicitly typed array with an optional fixed string width.
    pub(crate) fn redim_bounded_typed_fixed(
        &mut self,
        name: &str,
        upper_bounds: &[i64],
        preserve: bool,
        storage: &mut StorageBudget,
        is_string: bool,
        fixed_string_bytes: Option<usize>,
    ) -> Result<(), Error> {
        let name = self.canonical_name(name);
        if upper_bounds.is_empty() {
            return Err(Error::syntax("REDIM requires at least one dimension"));
        }
        if upper_bounds
            .iter()
            .any(|&bound| bound < self.option_base as i64)
        {
            return Err(Error::IllegalQuantity);
        }

        let mut dims = Vec::with_capacity(upper_bounds.len());
        let mut replacement_len = 1usize;
        for &bound in upper_bounds {
            let bound = usize::try_from(bound).map_err(|_| Error::ArrayTooLarge)?;
            if bound > self.max_elements {
                return Err(Error::ArrayTooLarge);
            }
            let size = bound
                .checked_add(1)
                .and_then(|size| size.checked_sub(self.option_base))
                .ok_or(Error::ArrayTooLarge)?;
            replacement_len = replacement_len
                .checked_mul(size)
                .ok_or(Error::ArrayTooLarge)?;
            if replacement_len > self.max_elements {
                return Err(Error::ArrayTooLarge);
            }
            dims.push(size);
        }

        let existing = self.arrays.get(&name);
        if preserve && existing.is_some_and(|array| array.dims.len() != dims.len()) {
            return Err(Error::syntax("REDIM PRESERVE cannot change array rank"));
        }
        let previous_len = existing.map_or(0, BasicArray::reserved_len);
        let next_total = self
            .total_elements
            .checked_sub(previous_len)
            .and_then(|total| total.checked_add(replacement_len))
            .ok_or(Error::ArrayTooLarge)?;
        if next_total > self.max_elements {
            return Err(Error::ArrayTooLarge);
        }

        let mut staged_storage = storage.clone();
        if let Some(array) = existing {
            for value in array.elements.values() {
                staged_storage.remove(value)?;
            }
        }
        let capacity = dims.iter().copied().product();
        let fixed_string_bytes =
            fixed_string_bytes.or_else(|| existing.and_then(|array| array.fixed_string_bytes));
        let mut replacement = BasicArray::with_declared_string_width(
            dims,
            capacity,
            is_string,
            self.option_base,
            fixed_string_bytes,
        );
        if preserve {
            if let Some(array) = existing {
                for (&offset, value) in &array.elements {
                    let indices = array.indices_for_offset(offset);
                    if let Ok(new_offset) = replacement.compute_offset(&indices) {
                        staged_storage.replace(None, value)?;
                        replacement.elements.insert(new_offset, value.clone());
                    }
                }
            }
        }

        self.arrays.insert(name, replacement);
        self.total_elements = next_total;
        *storage = staged_storage;
        Ok(())
    }

    /// Read an element, implicitly creating the array on first reference
    /// with each dimension sized for the default upper bound.
    pub fn load(&mut self, name: &str, indices: &[i64]) -> Result<Value, Error> {
        let name = self.canonical_name(name);
        self.ensure_element(&name, indices)?;
        let array = self
            .arrays
            .get(&name)
            .ok_or_else(|| Error::syntax("internal array missing after dimensioning"))?;
        array.load(indices)
    }

    /// Write an element, implicitly creating a default array on first use.
    pub fn store(&mut self, name: &str, indices: &[i64], value: Value) -> Result<(), Error> {
        let name = self.canonical_name(name);
        self.ensure_element(&name, indices)?;
        let array = self
            .arrays
            .get_mut(&name)
            .ok_or_else(|| Error::syntax("internal array missing after dimensioning"))?;
        array.store(indices, value)
    }

    /// Write an element and account for its retained value payload.
    ///
    /// Type and subscript errors, as well as storage-limit failures, leave any
    /// existing element and its payload charge unchanged.
    pub(crate) fn store_bounded(
        &mut self,
        name: &str,
        indices: &[i64],
        value: Value,
        storage: &mut StorageBudget,
    ) -> Result<(), Error> {
        let name = self.canonical_name(name);
        self.ensure_element(&name, indices)?;
        let array = self
            .arrays
            .get_mut(&name)
            .ok_or_else(|| Error::syntax("internal array missing after dimensioning"))?;
        array.store_bounded(indices, value, storage)
    }

    /// Borrow an explicitly written value for transaction preflight.
    pub(crate) fn stored_value(
        &self,
        name: &str,
        indices: &[i64],
    ) -> Result<Option<&Value>, Error> {
        let name = self.canonical_name(name);
        let array = self
            .arrays
            .get(&name)
            .ok_or_else(|| Error::syntax("internal array missing after dimensioning"))?;
        let offset = array.compute_offset(indices)?;
        Ok(array.elements.get(&offset))
    }

    /// Validate an element reference, implicitly dimensioning the array if
    /// needed, without reading or writing the element.
    ///
    /// `READ` uses this before consuming a DATA item so an invalid destination
    /// subscript is reported first, matching the original evaluation order.
    pub fn ensure_element(&mut self, name: &str, indices: &[i64]) -> Result<(), Error> {
        let name = self.canonical_name(name);
        validate_indices(indices)?;
        if !self.arrays.contains_key(&name) {
            self.create_implicit(&name, indices.len())?;
        }
        let array = self
            .arrays
            .get(&name)
            .ok_or_else(|| Error::syntax("internal array missing after dimensioning"))?;
        array.compute_offset(indices).map(|_| ())
    }

    /// Create an implicitly dimensioned array with `num_dims` default-sized
    /// dimensions.
    fn create_implicit(&mut self, name: &str, num_dims: usize) -> Result<(), Error> {
        if num_dims == 0 {
            return Err(Error::BadSubscript);
        }
        let implicit_size = IMPLICIT_SIZE
            .checked_sub(self.option_base)
            .ok_or(Error::ArrayTooLarge)?;
        let dims = vec![implicit_size; num_dims];
        self.insert_array(name.to_string(), dims, is_string_variable(name))
    }

    /// Insert an array and account for its logical element count.
    fn insert_array(
        &mut self,
        name: String,
        dims: Vec<usize>,
        is_string: bool,
    ) -> Result<(), Error> {
        self.insert_array_with_lower_bound(name, dims, is_string, self.option_base)
    }

    fn insert_array_with_lower_bound(
        &mut self,
        name: String,
        dims: Vec<usize>,
        is_string: bool,
        lower_bound: usize,
    ) -> Result<(), Error> {
        self.insert_array_with_lower_bound_and_width(name, dims, is_string, lower_bound, None)
    }

    fn insert_array_with_lower_bound_and_width(
        &mut self,
        name: String,
        dims: Vec<usize>,
        is_string: bool,
        lower_bound: usize,
        fixed_string_bytes: Option<usize>,
    ) -> Result<(), Error> {
        let mut product: usize = 1;
        for &size in &dims {
            product = product.checked_mul(size).ok_or(Error::ArrayTooLarge)?;
            if product > self.max_elements {
                return Err(Error::ArrayTooLarge);
            }
        }
        let total = self
            .total_elements
            .checked_add(product)
            .ok_or(Error::ArrayTooLarge)?;
        if total > self.max_elements {
            return Err(Error::ArrayTooLarge);
        }

        self.total_elements = total;
        self.arrays.insert(
            name,
            BasicArray::with_declared_string_width(
                dims,
                product,
                is_string,
                lower_bound,
                fixed_string_bytes,
            ),
        );
        Ok(())
    }
}

/// Validate errors that must occur before implicit array creation.
fn validate_indices(indices: &[i64]) -> Result<(), Error> {
    if indices.is_empty() {
        return Err(Error::BadSubscript);
    }
    if indices.iter().any(|&index| index < 0) {
        return Err(Error::IllegalQuantity);
    }
    Ok(())
}

fn numeric_zero(value: &Value) -> bool {
    match value {
        Value::Integer(value) => *value == 0,
        Value::Real(value) => value.is_zero(),
        Value::Complex(value) => value.is_zero(),
        Value::List(_) | Value::String(_) => false,
    }
}

fn mat_logical_offset(dims: &[usize], offset: usize) -> bool {
    match dims {
        [_] => offset != 0,
        [1, columns] => offset % columns != 0,
        [_, columns] => offset / columns != 0 && offset % columns != 0,
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn row_major_offset_for_one_and_two_dimensions() {
        let a = BasicArray::new(vec![3], false);
        assert_eq!(a.compute_offset(&[0]).unwrap(), 0);
        assert_eq!(a.compute_offset(&[2]).unwrap(), 2);

        // A(2,3) has sizes 3 and 4.
        let b = BasicArray::new(vec![3, 4], false);
        assert_eq!(b.compute_offset(&[0, 0]).unwrap(), 0);
        assert_eq!(b.compute_offset(&[1, 0]).unwrap(), 4);
        assert_eq!(b.compute_offset(&[0, 1]).unwrap(), 1);
        assert_eq!(b.compute_offset(&[2, 3]).unwrap(), 11);
    }

    #[test]
    fn bad_subscript_for_wrong_dimension_count() {
        let a = BasicArray::new(vec![3, 4], false);
        assert_eq!(a.compute_offset(&[1]).unwrap_err(), Error::BadSubscript);
        assert_eq!(
            a.compute_offset(&[1, 2, 3]).unwrap_err(),
            Error::BadSubscript
        );
    }

    #[test]
    fn bad_subscript_for_index_above_upper_bound() {
        let a = BasicArray::new(vec![3], false);
        assert_eq!(a.compute_offset(&[3]).unwrap_err(), Error::BadSubscript);
    }

    #[test]
    fn illegal_quantity_for_negative_index() {
        let a = BasicArray::new(vec![3], false);
        assert_eq!(a.compute_offset(&[-1]).unwrap_err(), Error::IllegalQuantity);

        let mut store = ArrayStore::new(100);
        assert_eq!(store.load("A", &[-1]).unwrap_err(), Error::IllegalQuantity);
        assert!(store.get("A").is_none());
    }

    #[test]
    fn option_base_one_changes_explicit_and_implicit_bounds() {
        let mut store = ArrayStore::new(100);
        store.set_option_base(1);
        store.dim("A", &[2, 3]).unwrap();

        assert_eq!(store.get("A").unwrap().dims(), &[2, 3]);
        store.store("A", &[1, 1], Value::Integer(11)).unwrap();
        store.store("A", &[2, 3], Value::Integer(23)).unwrap();
        assert_eq!(store.load("A", &[1, 1]).unwrap(), Value::Integer(11));
        assert_eq!(store.load("A", &[2, 3]).unwrap(), Value::Integer(23));
        assert_eq!(store.load("A", &[0, 1]).unwrap_err(), Error::BadSubscript);

        assert_eq!(store.load("B", &[1]).unwrap(), Value::Integer(0));
        assert_eq!(store.load("B", &[10]).unwrap(), Value::Integer(0));
        assert_eq!(store.load("B", &[0]).unwrap_err(), Error::BadSubscript);
    }

    #[test]
    fn dim_creates_numeric_and_string_arrays() {
        let mut store = ArrayStore::new(100);
        store.dim("A", &[2]).unwrap();
        store.dim("B$", &[4]).unwrap();

        assert_eq!(store.get("A").unwrap().dims(), &[3]);
        assert_eq!(store.get("B$").unwrap().dims(), &[5]);
        assert!(!store.get("A").unwrap().is_string());
        assert!(store.get("B$").unwrap().is_string());
    }

    #[test]
    fn implicit_dimensioning_uses_default_bound() {
        let mut store = ArrayStore::new(1000);
        let value = store.load("A", &[5]).unwrap();
        assert_eq!(value, Value::Integer(0));
        assert_eq!(store.get("A").unwrap().dims(), &[IMPLICIT_SIZE]);

        let s = store.load("S$", &[0, 10]).unwrap();
        assert_eq!(s, Value::String(String::new()));
        assert_eq!(
            store.get("S$").unwrap().dims(),
            &[IMPLICIT_SIZE, IMPLICIT_SIZE]
        );
    }

    #[test]
    fn ensure_element_validates_without_writing() {
        let mut store = ArrayStore::new(100);
        store.dim("A", &[2]).unwrap();
        store.ensure_element("A", &[2]).unwrap();
        assert_eq!(store.load("A", &[2]).unwrap(), Value::Integer(0));
        assert_eq!(
            store.ensure_element("A", &[3]).unwrap_err(),
            Error::BadSubscript
        );
    }

    #[test]
    fn store_and_load_round_trip() {
        let mut store = ArrayStore::new(100);
        store.dim("A", &[2]).unwrap();
        store.store("A", &[1], Value::Integer(42)).unwrap();
        assert_eq!(store.load("A", &[1]).unwrap(), Value::Integer(42));
        assert_eq!(store.load("A", &[0]).unwrap(), Value::Integer(0));
    }

    #[test]
    fn redim_preserves_the_overlap_and_is_atomic_on_failure() {
        let mut store = ArrayStore::new(12);
        let mut storage = StorageBudget::new(64);
        store.dim("A", &[1, 1]).unwrap();
        store
            .store_bounded("A", &[0, 0], Value::Integer(11), &mut storage)
            .unwrap();
        store
            .store_bounded("A", &[1, 1], Value::Integer(22), &mut storage)
            .unwrap();

        store
            .redim_bounded("A", &[2, 2], true, &mut storage)
            .unwrap();
        assert_eq!(store.load("A", &[0, 0]).unwrap(), Value::Integer(11));
        assert_eq!(store.load("A", &[1, 1]).unwrap(), Value::Integer(22));
        assert_eq!(store.load("A", &[2, 2]).unwrap(), Value::Integer(0));
        assert_eq!(storage.used_bytes(), 16);

        assert_eq!(
            store
                .redim_bounded("A", &[12], true, &mut storage)
                .unwrap_err(),
            Error::ArrayTooLarge
        );
        assert_eq!(store.get("A").unwrap().dims(), &[3, 3]);
        assert_eq!(store.load("A", &[1, 1]).unwrap(), Value::Integer(22));
        assert_eq!(storage.used_bytes(), 16);
    }

    #[test]
    fn redim_without_preserve_and_erase_release_stored_payloads_and_capacity() {
        let mut store = ArrayStore::new(3);
        let mut storage = StorageBudget::new(16);
        store.dim("A$", &[2]).unwrap();
        store
            .store_bounded("A$", &[1], Value::String("abcdefgh".into()), &mut storage)
            .unwrap();

        store
            .redim_bounded("A$", &[2], false, &mut storage)
            .unwrap();
        assert_eq!(storage.used_bytes(), 0);
        assert_eq!(
            store.load("A$", &[1]).unwrap(),
            Value::String(String::new())
        );

        store
            .store_bounded("A$", &[0], Value::String("xy".into()), &mut storage)
            .unwrap();
        store.remove_bounded("A$", &mut storage).unwrap();
        assert_eq!(storage.used_bytes(), 0);
        store.dim("B", &[2]).unwrap();
    }

    #[test]
    fn redim_preserve_rejects_rank_changes_without_mutation() {
        let mut store = ArrayStore::new(100);
        let mut storage = StorageBudget::new(16);
        store.dim("A", &[2]).unwrap();
        store
            .store_bounded("A", &[2], Value::Integer(7), &mut storage)
            .unwrap();

        let error = store
            .redim_bounded("A", &[2, 2], true, &mut storage)
            .unwrap_err();
        assert!(matches!(error, Error::Syntax { .. }));
        assert_eq!(store.get("A").unwrap().dims(), &[3]);
        assert_eq!(store.load("A", &[2]).unwrap(), Value::Integer(7));
        assert_eq!(storage.used_bytes(), 8);
    }

    #[test]
    fn bounded_store_releases_replacements_and_preserves_failed_values() {
        let mut store = ArrayStore::new(100);
        store.dim("A$", &[2]).unwrap();
        let mut storage = StorageBudget::new(4);
        store
            .store_bounded("A$", &[1], Value::String("ABCD".into()), &mut storage)
            .unwrap();
        assert_eq!(storage.remaining_bytes(), 0);
        assert_eq!(
            store
                .store_bounded("A$", &[1], Value::String("TOO-LONG".into()), &mut storage)
                .unwrap_err(),
            Error::StorageLimitExceeded { limit: 4 }
        );
        assert_eq!(
            store.load("A$", &[1]).unwrap(),
            Value::String("ABCD".into())
        );
        assert_eq!(storage.used_bytes(), 4);

        store
            .store_bounded("A$", &[1], Value::String("X".into()), &mut storage)
            .unwrap();
        assert_eq!(storage.used_bytes(), 1);
    }

    #[test]
    fn type_mismatch_on_wrong_element_type() {
        let mut store = ArrayStore::new(100);
        store.dim("A", &[2]).unwrap();
        assert_eq!(
            store
                .store("A", &[0], Value::String("x".to_string()))
                .unwrap_err(),
            Error::TypeMismatch
        );

        store.dim("B$", &[2]).unwrap();
        assert_eq!(
            store.store("B$", &[0], Value::Integer(1)).unwrap_err(),
            Error::TypeMismatch
        );
        assert_eq!(
            store
                .store("A", &[0], Value::List(vec![Value::Integer(1)]))
                .unwrap_err(),
            Error::TypeMismatch
        );
    }

    #[test]
    fn redimensioning_existing_array_is_an_error() {
        let mut store = ArrayStore::new(100);
        store.dim("A", &[2]).unwrap();
        assert_eq!(store.dim("A", &[2]).unwrap_err(), Error::RedimensionedArray);
    }

    #[test]
    fn negative_bound_is_illegal_quantity() {
        let mut store = ArrayStore::new(100);
        assert_eq!(store.dim("A", &[-1]).unwrap_err(), Error::IllegalQuantity);

        store.dim("A", &[1]).unwrap();
        assert_eq!(store.dim("A", &[-1]).unwrap_err(), Error::IllegalQuantity);
    }

    #[test]
    fn array_capacity_limit_is_enforced() {
        let mut store = ArrayStore::new(100);
        assert_eq!(store.dim("A", &[100]).unwrap_err(), Error::ArrayTooLarge);

        let mut store = ArrayStore::new(6);
        assert_eq!(store.dim("A", &[2, 3]).unwrap_err(), Error::ArrayTooLarge); // 3*4 = 12 > 6
        assert!(store.dim("B", &[6]).is_err());
    }

    #[test]
    fn capacity_tracks_total_logical_elements() {
        let mut store = ArrayStore::new(10);
        store.dim("A", &[2]).unwrap(); // size 3
        store.dim("B", &[1]).unwrap(); // size 2 -> total 5
        store.dim("C", &[2]).unwrap(); // size 3 -> total 8
        assert_eq!(store.dim("D", &[2]).unwrap_err(), Error::ArrayTooLarge); // size 3 -> total 11 > 10
    }

    #[test]
    fn clear_releases_capacity_without_changing_the_limit() {
        let mut store = ArrayStore::new(3);
        store.dim("A", &[2]).unwrap();
        assert_eq!(store.dim("B", &[0]).unwrap_err(), Error::ArrayTooLarge);

        store.clear();
        assert_eq!(store.max_elements(), 3);
        assert!(store.get("A").is_none());
        store.dim("B", &[2]).unwrap();
    }

    #[test]
    fn mat_reshape_uses_reserved_total_capacity_not_per_axis_bounds() {
        let mut store = ArrayStore::new(1_000);
        store.dim("M", &[20, 7]).unwrap(); // (20+1)*(7+1) = 168 slots
        let mut storage = StorageBudget::new(2_000);
        let values = vec![Value::Integer(1); 25 * 5];
        store
            .replace_numeric_mat("M", &[25, 5], &values, &mut storage)
            .unwrap();
        let matrix = store.get("M").unwrap();
        assert_eq!(matrix.dims(), &[26, 6]);
        assert_eq!(matrix.reserved_len(), 168);
        assert_eq!(matrix.load(&[25, 5]).unwrap(), Value::Integer(1));

        assert_eq!(
            store
                .replace_numeric_mat("M", &[16, 10], &vec![Value::Integer(0); 160], &mut storage,)
                .unwrap_err(),
            Error::MatrixCapacityExceeded {
                requested: 187,
                reserved: 168,
            }
        );
        assert_eq!(store.get("M").unwrap().dims(), &[26, 6]);
    }

    #[test]
    fn mat_row_vector_uses_dartmouth_zero_row_storage() {
        let mut store = ArrayStore::new(100);
        store.dim("R", &[0, 3]).unwrap();
        let mut storage = StorageBudget::new(100);
        store
            .replace_numeric_mat(
                "R",
                &[0, 3],
                &[Value::Integer(4), Value::Integer(5), Value::Integer(6)],
                &mut storage,
            )
            .unwrap();
        let row = store.get("R").unwrap();
        assert_eq!(row.load(&[0, 1]).unwrap(), Value::Integer(4));
        assert_eq!(row.load(&[0, 3]).unwrap(), Value::Integer(6));
    }

    #[test]
    fn mat_preserves_zero_fringe_without_reshape_and_clears_it_on_reshape() {
        let mut store = ArrayStore::new(100);
        store.dim("M", &[2, 2]).unwrap();
        let mut storage = StorageBudget::new(100);
        store
            .store_bounded("M", &[0, 1], Value::Integer(9), &mut storage)
            .unwrap();
        store
            .store_bounded("M", &[1, 0], Value::Integer(8), &mut storage)
            .unwrap();
        store
            .replace_numeric_mat("M", &[2, 2], &vec![Value::Integer(1); 4], &mut storage)
            .unwrap();
        assert_eq!(
            store.get("M").unwrap().load(&[0, 1]).unwrap(),
            Value::Integer(9)
        );
        assert_eq!(
            store.get("M").unwrap().load(&[1, 0]).unwrap(),
            Value::Integer(8)
        );

        store
            .replace_numeric_mat("M", &[1, 2], &vec![Value::Integer(1); 2], &mut storage)
            .unwrap();
        assert_eq!(
            store.get("M").unwrap().load(&[0, 1]).unwrap(),
            Value::Integer(0)
        );
        assert_eq!(
            store.get("M").unwrap().load(&[1, 0]).unwrap(),
            Value::Integer(0)
        );
    }

    #[test]
    fn scoped_aliases_mutate_canonical_arrays_and_hide_caller_aliases() {
        let mut store = ArrayStore::new(100);
        let mut storage = StorageBudget::new(100);
        store.dim("ACTUAL", &[2]).unwrap();
        store
            .store_bounded("ACTUAL", &[1], Value::Integer(7), &mut storage)
            .unwrap();

        store.push_alias_scope(HashMap::from([(
            "FORMAL".to_string(),
            "ACTUAL".to_string(),
        )]));
        assert_eq!(store.load("FORMAL", &[1]).unwrap(), Value::Integer(7));
        store
            .store_bounded("FORMAL", &[1], Value::Integer(9), &mut storage)
            .unwrap();

        store.push_alias_scope(HashMap::new());
        store
            .store_bounded("FORMAL", &[1], Value::Integer(3), &mut storage)
            .unwrap();
        assert_eq!(store.load("FORMAL", &[1]).unwrap(), Value::Integer(3));
        store.pop_alias_scope().unwrap();

        assert_eq!(store.load("FORMAL", &[1]).unwrap(), Value::Integer(9));
        store.pop_alias_scope().unwrap();
        assert_eq!(store.load("ACTUAL", &[1]).unwrap(), Value::Integer(9));
        assert_eq!(store.load("FORMAL", &[1]).unwrap(), Value::Integer(3));
        assert!(matches!(store.pop_alias_scope(), Err(Error::Syntax { .. })));
    }

    #[test]
    fn graphics_images_round_trip_through_vectors_and_matrices() {
        let pixels = [0xff000001, 0xff000002, 0xff000003, 0xff000004];
        let mut storage = StorageBudget::new(1_024);
        let mut store = ArrayStore::new(100);
        store
            .store_graphics_image("AUTO", 2, 2, &pixels, &mut storage)
            .unwrap();
        assert_eq!(
            store.load_graphics_image("AUTO").unwrap(),
            (2, 2, pixels.to_vec())
        );

        store.dim("M", &[1, 3]).unwrap();
        store
            .store_graphics_image("M", 2, 2, &pixels, &mut storage)
            .unwrap();
        assert_eq!(
            store.load_graphics_image("M").unwrap(),
            (2, 2, pixels.to_vec())
        );
        assert_eq!(
            store.get("M").unwrap().load(&[0, 0]).unwrap(),
            Value::Integer(2)
        );
        assert_eq!(
            store.get("M").unwrap().load(&[0, 1]).unwrap(),
            Value::Integer(2)
        );
    }
}
