//! Deterministic native random-number state for BASIC `RND`.
//!
//! This is deliberately not host entropy and does not emulate a machine timer
//! or the original 6502 floating-point seed bytes. A small fixed-state
//! SplitMix64 generator gives every run a reproducible sequence. BASIC's
//! argument convention is preserved: positive advances, zero repeats, and a
//! negative value deterministically reseeds before advancing.

use crate::error::Error;
use crate::real::BasicReal;

/// Default seed used by a new expression evaluator or program run.
pub const DEFAULT_RANDOM_SEED: u64 = 0x0000_0080_4fc7_5259;

const STEP: u64 = 0x9e37_79b9_7f4a_7c15;
const MIX_1: u64 = 0xbf58_476d_1ce4_e5b9;
const MIX_2: u64 = 0x94d0_49bb_1331_11eb;
const RESEED_SALT: u64 = 0xd1b5_4a32_d192_ed03;
const UNIT_SCALE: f64 = 1.0 / 9_007_199_254_740_992.0;

/// Reproducible random-number state owned by one evaluator or interpreter.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BasicRng {
    state: u64,
    last_fraction_bits: u64,
}

impl BasicRng {
    /// Construct state from an explicit seed.
    pub fn new(seed: u64) -> Self {
        Self {
            state: seed,
            last_fraction_bits: mix(seed) >> 11,
        }
    }

    /// Re-seed the generator with a new seed value.
    pub fn reseed(&mut self, seed: u64) {
        self.state = seed;
        self.last_fraction_bits = mix(seed) >> 11;
    }

    /// Evaluate BASIC `RND` for one finite real argument.
    pub fn rnd(&mut self, argument: BasicReal) -> Result<BasicReal, Error> {
        let argument = argument.value();
        if argument < 0.0 {
            self.state = argument.to_bits() ^ RESEED_SALT;
            self.advance();
        } else if argument > 0.0 {
            self.advance();
        }
        BasicReal::new(self.last_fraction_bits as f64 * UNIT_SCALE)
    }

    /// Advance once and return a unit-interval value.
    pub fn unit(&mut self) -> Result<BasicReal, Error> {
        self.advance();
        BasicReal::new(self.last_fraction_bits as f64 * UNIT_SCALE)
    }

    /// Return one uniformly distributed integer from an inclusive range.
    pub fn integer_inclusive(&mut self, lower: i64, upper: i64) -> Result<i64, Error> {
        if lower > upper {
            return Err(Error::IllegalQuantity);
        }
        let span = (i128::from(upper) - i128::from(lower) + 1) as u128;
        let full_range = u128::from(u64::MAX) + 1;
        let cutoff = full_range - (full_range % span);
        let sample = loop {
            let candidate = u128::from(self.advance());
            if candidate < cutoff {
                break candidate % span;
            }
        };
        i64::try_from(i128::from(lower) + sample as i128).map_err(|_| Error::IntegerOverflow)
    }

    /// Return one normally distributed finite real using Box-Muller.
    pub fn normal(&mut self, mean: BasicReal, deviation: BasicReal) -> Result<BasicReal, Error> {
        if deviation.value() <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        let first = 1.0 - self.unit()?.value();
        let second = self.unit()?.value();
        let standard = (-2.0 * first.ln()).sqrt() * (2.0 * std::f64::consts::PI * second).cos();
        BasicReal::new(mean.value() + deviation.value() * standard)
    }

    /// Return one binomial sample with a bounded number of trials.
    pub fn binomial(&mut self, trials: u64, probability: BasicReal) -> Result<u64, Error> {
        const MAX_TRIALS: u64 = 1_000_000;
        if trials > MAX_TRIALS || !(0.0..=1.0).contains(&probability.value()) {
            return Err(Error::IllegalQuantity);
        }
        let mut successes = 0_u64;
        for _ in 0..trials {
            successes += u64::from(self.unit()?.value() < probability.value());
        }
        Ok(successes)
    }

    fn advance(&mut self) -> u64 {
        self.state = self.state.wrapping_add(STEP);
        let mixed = mix(self.state);
        self.last_fraction_bits = mixed >> 11;
        mixed
    }
}

impl Default for BasicRng {
    fn default() -> Self {
        Self::new(DEFAULT_RANDOM_SEED)
    }
}

fn mix(mut value: u64) -> u64 {
    value = (value ^ (value >> 30)).wrapping_mul(MIX_1);
    value = (value ^ (value >> 27)).wrapping_mul(MIX_2);
    value ^ (value >> 31)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn real(value: f64) -> BasicReal {
        BasicReal::new(value).unwrap()
    }

    #[test]
    fn identical_seeds_produce_identical_bounded_sequences() {
        let mut left = BasicRng::new(42);
        let mut right = BasicRng::new(42);
        for _ in 0..16 {
            let left_value = left.rnd(real(1.0)).unwrap();
            let right_value = right.rnd(real(1.0)).unwrap();
            assert_eq!(left_value, right_value);
            assert!((0.0..1.0).contains(&left_value.value()));
        }
    }

    #[test]
    fn zero_repeats_and_negative_reseeds() {
        let mut rng = BasicRng::default();
        let first = rng.rnd(real(1.0)).unwrap();
        assert_eq!(rng.rnd(real(0.0)).unwrap(), first);
        let seeded = rng.rnd(real(-7.0)).unwrap();
        assert_ne!(rng.rnd(real(1.0)).unwrap(), seeded);
        assert_eq!(rng.rnd(real(-7.0)).unwrap(), seeded);
    }

    #[test]
    fn different_explicit_seeds_diverge() {
        let mut left = BasicRng::new(1);
        let mut right = BasicRng::new(2);
        assert_ne!(left.rnd(real(1.0)).unwrap(), right.rnd(real(1.0)).unwrap());
    }

    #[test]
    fn seeded_sequence_is_a_stable_public_contract() {
        let mut rng = BasicRng::new(42);
        assert_eq!(rng.rnd(real(1.0)).unwrap(), real(0.741_564_878_771_823_3));
        assert_eq!(rng.rnd(real(1.0)).unwrap(), real(0.159_910_392_876_920_1));
    }

    #[test]
    fn ti_scalar_random_generators_are_reproducible_and_bounded() {
        let mut left = BasicRng::new(99);
        let mut right = BasicRng::new(99);
        for _ in 0..64 {
            let left_value = left.integer_inclusive(-3, 7).unwrap();
            let right_value = right.integer_inclusive(-3, 7).unwrap();
            assert_eq!(left_value, right_value);
            assert!((-3..=7).contains(&left_value));
        }

        let mut full_left = BasicRng::new(1);
        let mut full_right = BasicRng::new(1);
        assert_eq!(
            full_left.integer_inclusive(i64::MIN, i64::MAX).unwrap(),
            full_right.integer_inclusive(i64::MIN, i64::MAX).unwrap()
        );

        let mut normal_left = BasicRng::new(7);
        let mut normal_right = BasicRng::new(7);
        assert_eq!(
            normal_left.normal(real(10.0), real(2.0)).unwrap(),
            normal_right.normal(real(10.0), real(2.0)).unwrap()
        );
        assert_eq!(
            normal_left.normal(real(0.0), real(0.0)).unwrap_err(),
            Error::IllegalQuantity
        );

        let mut binomial = BasicRng::new(5);
        assert_eq!(binomial.binomial(20, real(0.0)).unwrap(), 0);
        assert_eq!(binomial.binomial(20, real(1.0)).unwrap(), 20);
        assert_eq!(
            binomial.binomial(1_000_001, real(0.5)).unwrap_err(),
            Error::IllegalQuantity
        );
    }
}
