//! Linux device adapters used by ModernBASIC input and output functions.
//!
//! Joystick descriptors are retained per interpreter thread so `STICK` and
//! `STRIG` share one coherent event stream. Explicit host-approved printer
//! writes are short-lived and reject symbolic-link targets.

use std::cell::RefCell;
use std::fs::{File, OpenOptions};
use std::io::{self, Read, Write};
use std::path::Path;

use crate::error::Error;

#[cfg(target_os = "linux")]
use std::os::unix::fs::OpenOptionsExt;

#[cfg(target_os = "linux")]
const O_NONBLOCK: i32 = 0x800;
#[cfg(target_os = "linux")]
const O_NOFOLLOW: i32 = 0o400000;
#[cfg(target_os = "linux")]
const O_CLOEXEC: i32 = 0o2000000;
const JS_EVENT_BUTTON: u8 = 0x01;
const JS_EVENT_AXIS: u8 = 0x02;
const JS_EVENT_INIT: u8 = 0x80;
const JOYSTICK_EVENT_BYTES: usize = 8;
const CONTROLLER_COUNT: usize = 2;
const AXES_PER_CONTROLLER: usize = 2;
const BUTTONS_PER_CONTROLLER: usize = 4;

#[derive(Default)]
struct JoystickDevice {
    file: Option<File>,
    axes: [i16; AXES_PER_CONTROLLER],
    buttons: [bool; BUTTONS_PER_CONTROLLER],
    button_generations: [u64; BUTTONS_PER_CONTROLLER],
    reported_generations: [u64; BUTTONS_PER_CONTROLLER],
}

#[derive(Default)]
struct JoystickManager {
    devices: [JoystickDevice; CONTROLLER_COUNT],
}

impl JoystickManager {
    fn poll(&mut self) {
        for controller in 0..CONTROLLER_COUNT {
            self.open_if_available(controller);
            self.poll_controller(controller);
        }
    }

    #[cfg(target_os = "linux")]
    fn open_if_available(&mut self, controller: usize) {
        if self.devices[controller].file.is_some() {
            return;
        }
        let path = format!("/dev/input/js{controller}");
        self.devices[controller].file = OpenOptions::new()
            .read(true)
            .custom_flags(O_NONBLOCK)
            .open(path)
            .ok();
    }

    #[cfg(not(target_os = "linux"))]
    fn open_if_available(&mut self, _controller: usize) {}

    fn poll_controller(&mut self, controller: usize) {
        loop {
            let mut bytes = [0u8; JOYSTICK_EVENT_BYTES];
            let read = match self.devices[controller].file.as_mut() {
                Some(file) => file.read(&mut bytes),
                None => return,
            };
            match read {
                Ok(JOYSTICK_EVENT_BYTES) => self.apply_event(controller, bytes),
                Ok(0) => {
                    self.disconnect(controller);
                    return;
                }
                Ok(_) => return,
                Err(error) if error.kind() == io::ErrorKind::WouldBlock => return,
                Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
                Err(_) => {
                    self.disconnect(controller);
                    return;
                }
            }
        }
    }

    fn disconnect(&mut self, controller: usize) {
        let device = &mut self.devices[controller];
        device.file = None;
        device.axes = [0; AXES_PER_CONTROLLER];
        device.buttons = [false; BUTTONS_PER_CONTROLLER];
    }

    fn apply_event(&mut self, controller: usize, bytes: [u8; JOYSTICK_EVENT_BYTES]) {
        let value = i16::from_ne_bytes([bytes[4], bytes[5]]);
        let event_type = bytes[6];
        let number = usize::from(bytes[7]);
        let initial = event_type & JS_EVENT_INIT != 0;
        match event_type & !JS_EVENT_INIT {
            JS_EVENT_AXIS if number < AXES_PER_CONTROLLER => {
                self.devices[controller].axes[number] = value;
            }
            JS_EVENT_BUTTON if number < BUTTONS_PER_CONTROLLER => {
                let pressed = value != 0;
                let device = &mut self.devices[controller];
                if !initial && pressed && !device.buttons[number] {
                    device.button_generations[number] =
                        device.button_generations[number].wrapping_add(1);
                }
                device.buttons[number] = pressed;
            }
            _ => {}
        }
    }

    fn axis(&self, selector: usize) -> i64 {
        let controller = selector / AXES_PER_CONTROLLER;
        let axis = selector % AXES_PER_CONTROLLER;
        // Linux exposes signed 16-bit axes. Shifting the biased value by eight
        // gives the classic 0..255 range exactly, including 128 at center.
        i64::from((i32::from(self.devices[controller].axes[axis]) + 32_768) >> 8)
    }

    fn button(&self, selector: usize) -> i64 {
        let controller = selector / BUTTONS_PER_CONTROLLER;
        let button = selector % BUTTONS_PER_CONTROLLER;
        if self.devices[controller].buttons[button] {
            -1
        } else {
            0
        }
    }

    fn button_generation(&self, selector: usize) -> u64 {
        let controller = selector / BUTTONS_PER_CONTROLLER;
        let button = selector % BUTTONS_PER_CONTROLLER;
        self.devices[controller].button_generations[button]
    }

    fn take_button_edge(&mut self, selector: usize) -> i64 {
        let controller = selector / BUTTONS_PER_CONTROLLER;
        let button = selector % BUTTONS_PER_CONTROLLER;
        let device = &mut self.devices[controller];
        let generation = device.button_generations[button];
        if generation == device.reported_generations[button] {
            0
        } else {
            device.reported_generations[button] = generation;
            -1
        }
    }
}

std::thread_local! {
    static JOYSTICKS: RefCell<JoystickManager> = RefCell::new(JoystickManager::default());
}

pub(crate) fn stick(selector: i64) -> Result<i64, Error> {
    let selector = usize::try_from(selector).map_err(|_| Error::IllegalQuantity)?;
    if selector >= CONTROLLER_COUNT * AXES_PER_CONTROLLER {
        return Err(Error::IllegalQuantity);
    }
    JOYSTICKS.with(|manager| {
        let mut manager = manager.borrow_mut();
        manager.poll();
        Ok(manager.axis(selector))
    })
}

pub(crate) fn strig(selector: i64) -> Result<i64, Error> {
    let selector = validate_strig_selector(selector)?;
    JOYSTICKS.with(|manager| {
        let mut manager = manager.borrow_mut();
        manager.poll();
        let button = selector / 2;
        // Modern64 maps selectors 0..7 as four current/edge pairs: even
        // selectors report the current button state, while odd selectors
        // consume one press edge for the same physical button.
        Ok(if selector % 2 == 0 {
            manager.button(button)
        } else {
            manager.take_button_edge(button)
        })
    })
}

pub(crate) fn strig_generation(selector: u8) -> Result<u64, Error> {
    let selector = validate_strig_selector(i64::from(selector))?;
    JOYSTICKS.with(|manager| {
        let mut manager = manager.borrow_mut();
        manager.poll();
        Ok(manager.button_generation(selector / 2))
    })
}

fn validate_strig_selector(selector: i64) -> Result<usize, Error> {
    let selector = usize::try_from(selector).map_err(|_| Error::IllegalQuantity)?;
    if selector >= CONTROLLER_COUNT * BUTTONS_PER_CONTROLLER {
        return Err(Error::IllegalQuantity);
    }
    Ok(selector)
}

pub(crate) fn close_joysticks() {
    JOYSTICKS.with(|manager| *manager.borrow_mut() = JoystickManager::default());
}

#[cfg(test)]
pub(crate) fn mock_strig_button(selector: u8, pressed: bool) {
    let selector = usize::from(selector);
    let controller = selector / BUTTONS_PER_CONTROLLER;
    let button = selector % BUTTONS_PER_CONTROLLER;
    let mut bytes = [0u8; JOYSTICK_EVENT_BYTES];
    bytes[4..6].copy_from_slice(&i16::from(pressed).to_ne_bytes());
    bytes[6] = JS_EVENT_BUTTON;
    bytes[7] = button as u8;
    JOYSTICKS.with(|manager| manager.borrow_mut().apply_event(controller, bytes));
}

pub(crate) fn write_printer(path: &Path, bytes: &[u8], max_bytes: usize) -> Result<(), Error> {
    match std::fs::symlink_metadata(path) {
        Ok(metadata) if metadata.file_type().is_symlink() => {
            return Err(Error::InvalidFilePath);
        }
        Ok(_) => {}
        Err(error) if error.kind() == io::ErrorKind::NotFound => {}
        Err(error) => return Err(error.into()),
    }
    let mut options = OpenOptions::new();
    options.write(true).create(true).append(true);
    #[cfg(target_os = "linux")]
    {
        options.custom_flags(O_NOFOLLOW | O_CLOEXEC).mode(0o600);
    }
    let mut file = options.open(path)?;
    let existing = usize::try_from(file.metadata()?.len()).unwrap_or(usize::MAX);
    let total = existing
        .checked_add(bytes.len())
        .ok_or(Error::FileLimitExceeded { limit: max_bytes })?;
    if total > max_bytes {
        return Err(Error::FileLimitExceeded { limit: max_bytes });
    }
    file.write_all(bytes)?;
    file.flush()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn event(value: i16, event_type: u8, number: u8) -> [u8; JOYSTICK_EVENT_BYTES] {
        let mut bytes = [0u8; JOYSTICK_EVENT_BYTES];
        bytes[4..6].copy_from_slice(&value.to_ne_bytes());
        bytes[6] = event_type;
        bytes[7] = number;
        bytes
    }

    #[test]
    fn mock_joystick_events_map_axes_and_button_edges() {
        let mut manager = JoystickManager::default();
        assert_eq!(manager.axis(0), 128);
        manager.apply_event(0, event(i16::MIN, JS_EVENT_AXIS, 0));
        manager.apply_event(0, event(i16::MAX, JS_EVENT_AXIS, 1));
        assert_eq!(manager.axis(0), 0);
        assert_eq!(manager.axis(1), 255);

        manager.apply_event(1, event(1, JS_EVENT_BUTTON | JS_EVENT_INIT, 0));
        assert_eq!(manager.button(4), -1);
        assert_eq!(manager.button_generation(4), 0);
        manager.apply_event(1, event(0, JS_EVENT_BUTTON, 0));
        manager.apply_event(1, event(1, JS_EVENT_BUTTON, 0));
        assert_eq!(manager.button_generation(4), 1);
    }

    #[test]
    fn strig_pairs_current_state_with_consumable_press_edges() {
        let mut manager = JoystickManager::default();
        manager.apply_event(0, event(1, JS_EVENT_BUTTON, 2));
        assert_eq!(manager.button(2), -1);
        assert_eq!(manager.take_button_edge(2), -1);
        assert_eq!(manager.take_button_edge(2), 0);
        manager.apply_event(0, event(0, JS_EVENT_BUTTON, 2));
        assert_eq!(manager.button(2), 0);
        assert_eq!(manager.take_button_edge(2), 0);
        manager.apply_event(0, event(1, JS_EVENT_BUTTON, 2));
        assert_eq!(manager.take_button_edge(2), -1);
    }

    #[test]
    fn printer_spools_to_an_explicit_temporary_file() {
        let path = std::env::temp_dir().join(format!(
            "modernbasic-printer-{}-{}.spool",
            std::process::id(),
            std::thread::current().name().unwrap_or("test")
        ));
        let _ = std::fs::remove_file(&path);
        write_printer(&path, b"FIRST\n", 64).unwrap();
        write_printer(&path, b"SECOND\n", 64).unwrap();
        assert_eq!(std::fs::read(&path).unwrap(), b"FIRST\nSECOND\n");
        std::fs::remove_file(path).unwrap();
    }
}
