//! Bounded program-driven animation recording for ModernBASIC.
//!
//! BASIC supplies complete raster frames. FFmpeg is only an encoder boundary;
//! no shell, editor, decoder, camera, or arbitrary filter interface is exposed.

use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdin, Command, Stdio};

use crate::error::Error;

pub const MAX_VIDEO_FPS: u32 = 120;
pub const MAX_VIDEO_SECONDS: u32 = 1_800;

pub struct VideoRecorder {
    output: PathBuf,
    extension: String,
    fps: u32,
    max_frames: usize,
    frames: usize,
    dimensions: Option<(u32, u32)>,
    audio: Option<crate::media::MediaSource>,
    audio_feeder: Option<std::thread::JoinHandle<()>>,
    ffmpeg: Option<PathBuf>,
    child: Option<Child>,
    input: Option<ChildStdin>,
}

impl VideoRecorder {
    pub(crate) fn start(
        output: PathBuf,
        fps: i64,
        audio: Option<crate::media::MediaSource>,
    ) -> Result<Self, Error> {
        let fps = u32::try_from(fps).map_err(|_| Error::IllegalQuantity)?;
        if !(1..=MAX_VIDEO_FPS).contains(&fps) {
            return Err(Error::IllegalQuantity);
        }
        let extension = output
            .extension()
            .and_then(|extension| extension.to_str())
            .map(str::to_ascii_lowercase)
            .ok_or_else(|| Error::syntax("VIDEO output must end in .mp4, .webm, or .gif"))?;
        if !matches!(extension.as_str(), "mp4" | "webm" | "gif") {
            return Err(Error::syntax(
                "VIDEO output must end in .mp4, .webm, or .gif",
            ));
        }
        if let Some(audio) = &audio {
            if Path::new(audio.name())
                .extension()
                .and_then(|extension| extension.to_str())
                .map_or(true, |extension| !extension.eq_ignore_ascii_case("wav"))
            {
                return Err(Error::syntax("VIDEO soundtrack must end in .wav"));
            }
            if extension == "gif" {
                return Err(Error::syntax(
                    "GIF VIDEO output cannot contain a soundtrack",
                ));
            }
            crate::media::validate_audio_source(audio)?;
        }
        let headless = std::env::var("MODERNBASIC_NO_VIDEO").is_ok();
        let ffmpeg = if headless {
            None
        } else {
            Some(find_ffmpeg().ok_or_else(|| {
                Error::Io("VIDEO recording requires FFmpeg on the host system".to_string())
            })?)
        };
        Ok(Self {
            output,
            extension,
            fps,
            max_frames: fps as usize * MAX_VIDEO_SECONDS as usize,
            frames: 0,
            dimensions: None,
            audio,
            audio_feeder: None,
            ffmpeg,
            child: None,
            input: None,
        })
    }

    pub fn write_ppm_frame(&mut self, ppm: &[u8]) -> Result<(), Error> {
        if crate::interpreter::take_interrupt() {
            return Err(Error::Break);
        }
        if self.frames >= self.max_frames {
            return Err(Error::syntax("VIDEO duration exceeds 30 minutes"));
        }
        let dimensions = validate_ppm_frame(ppm)?;
        match self.dimensions {
            Some(expected) if expected != dimensions => {
                return Err(Error::syntax(
                    "VIDEO frames must keep the dimensions used by the first frame",
                ))
            }
            None => {
                self.dimensions = Some(dimensions);
                self.start_encoder()?;
            }
            _ => {}
        }
        let encoder_status = match self.child.as_mut() {
            Some(child) => child.try_wait()?,
            None => None,
        };
        if let Some(status) = encoder_status {
            self.input = None;
            let mut child = self
                .child
                .take()
                .expect("encoder status came from the active child");
            let error = encoder_failure(&mut child, &status);
            self.join_audio_feeder();
            return Err(error);
        }
        if let Some(input) = self.input.as_mut() {
            input
                .write_all(ppm)
                .map_err(|error| Error::Io(format!("cannot stream VIDEO frame: {error}")))?;
        }
        self.frames += 1;
        Ok(())
    }

    pub fn frame_count(&self) -> usize {
        self.frames
    }

    pub fn finish(mut self) -> Result<usize, Error> {
        if self.frames == 0 {
            return Err(Error::syntax(
                "VIDEO STOP requires at least one VIDEO FRAME",
            ));
        }
        self.input.take();
        if let Some(mut child) = self.child.take() {
            let status = loop {
                if crate::interpreter::take_interrupt() {
                    let _ = child.kill();
                    let _ = child.wait();
                    self.join_audio_feeder();
                    return Err(Error::Break);
                }
                if let Some(status) = child.try_wait()? {
                    break status;
                }
                std::thread::sleep(std::time::Duration::from_millis(10));
            };
            let error = (!status.success()).then(|| encoder_failure(&mut child, &status));
            self.join_audio_feeder();
            if let Some(error) = error {
                return Err(error);
            }
        }
        Ok(self.frames)
    }

    fn start_encoder(&mut self) -> Result<(), Error> {
        let Some(ffmpeg) = self.ffmpeg.as_ref() else {
            return Ok(());
        };
        let mut command = Command::new(ffmpeg);
        command
            .arg("-nostdin")
            .arg("-loglevel")
            .arg("error")
            .arg("-y")
            .arg("-f")
            .arg("image2pipe")
            .arg("-framerate")
            .arg(self.fps.to_string())
            .arg("-vcodec")
            .arg("ppm")
            .arg("-i")
            .arg("pipe:0");
        #[cfg(unix)]
        let mut audio_pipe = None;
        if let Some(audio) = &self.audio {
            #[cfg(not(unix))]
            return Err(Error::Io(
                "in-memory VIDEO soundtracks require a Unix host".to_string(),
            ));
            #[cfg(unix)]
            {
                use std::os::fd::AsRawFd;
                let (reader, writer) = std::os::unix::net::UnixStream::pair()?;
                clear_close_on_exec(reader.as_raw_fd())?;
                command.arg("-i").arg(ffmpeg_pipe_input(reader.as_raw_fd()));
                audio_pipe = Some((reader, writer, audio.bytes()));
            }
            command
                .arg("-map")
                .arg("0:v:0")
                .arg("-map")
                .arg("1:a:0")
                // Pad a short soundtrack with silence so the streamed video
                // controls EOF. Without this, equal nominal durations can
                // differ by one codec timebase tick and FFmpeg may close the
                // frame pipe while BASIC is writing its final complete frame.
                .arg("-af")
                .arg("apad")
                .arg("-shortest");
        } else {
            command.arg("-an");
        }
        match self.extension.as_str() {
            "mp4" => {
                command
                    .arg("-c:v")
                    .arg("libx264")
                    .arg("-preset")
                    // VIDEO is a live program-output boundary, so favor the
                    // real-time x264 preset. CRF 17 still controls visual
                    // quality; veryfast trades a larger file for far lower
                    // latency and bounded encoder buffering.
                    .arg("veryfast")
                    .arg("-threads")
                    .arg("8")
                    .arg("-crf")
                    .arg("17")
                    .arg("-vf")
                    .arg("pad=ceil(iw/2)*2:ceil(ih/2)*2")
                    .arg("-pix_fmt")
                    .arg("yuv420p")
                    .arg("-movflags")
                    .arg("+faststart");
                if self.audio.is_some() {
                    command.arg("-c:a").arg("aac").arg("-b:a").arg("192k");
                }
            }
            "webm" => {
                command
                    .arg("-c:v")
                    .arg("libvpx-vp9")
                    .arg("-crf")
                    .arg("30")
                    .arg("-b:v")
                    .arg("0")
                    .arg("-vf")
                    .arg("pad=ceil(iw/2)*2:ceil(ih/2)*2")
                    .arg("-pix_fmt")
                    .arg("yuv420p");
                if self.audio.is_some() {
                    command.arg("-c:a").arg("libopus").arg("-b:a").arg("160k");
                }
            }
            "gif" => {}
            _ => unreachable!("VIDEO extension was validated"),
        }
        let mut child = command
            .arg(&self.output)
            .stdin(Stdio::piped())
            .stdout(Stdio::null())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|error| Error::Io(format!("cannot start video encoder: {error}")))?;
        #[cfg(unix)]
        if let Some((reader, mut writer, bytes)) = audio_pipe.take() {
            drop(reader);
            self.audio_feeder = Some(std::thread::spawn(move || {
                let _ = writer.write_all(bytes.as_ref());
            }));
        }
        let input = child
            .stdin
            .take()
            .ok_or_else(|| Error::Io("cannot open video encoder input".to_string()))?;
        self.input = Some(input);
        self.child = Some(child);
        Ok(())
    }

    fn join_audio_feeder(&mut self) {
        if let Some(feeder) = self.audio_feeder.take() {
            let _ = feeder.join();
        }
    }
}

impl Drop for VideoRecorder {
    fn drop(&mut self) {
        self.input.take();
        if let Some(mut child) = self.child.take() {
            if child.try_wait().ok().flatten().is_none() {
                let _ = child.kill();
            }
            let _ = child.wait();
        }
        self.join_audio_feeder();
    }
}

const MAX_ENCODER_DIAGNOSTIC_BYTES: u64 = 16 * 1_024;

fn encoder_failure(child: &mut Child, status: &std::process::ExitStatus) -> Error {
    let mut diagnostics = Vec::new();
    let truncated = if let Some(stderr) = child.stderr.take() {
        let mut limited = stderr.take(MAX_ENCODER_DIAGNOSTIC_BYTES + 1);
        let _ = limited.read_to_end(&mut diagnostics);
        diagnostics.len() as u64 > MAX_ENCODER_DIAGNOSTIC_BYTES
    } else {
        false
    };
    diagnostics.truncate(MAX_ENCODER_DIAGNOSTIC_BYTES as usize);
    let detail = String::from_utf8_lossy(&diagnostics);
    let detail = detail.trim();
    if detail.is_empty() {
        Error::Io(format!("video encoder exited with {status}"))
    } else if truncated {
        Error::Io(format!(
            "video encoder exited with {status}: {detail} [diagnostic truncated]"
        ))
    } else {
        Error::Io(format!("video encoder exited with {status}: {detail}"))
    }
}

#[cfg(unix)]
fn clear_close_on_exec(fd: std::os::fd::RawFd) -> Result<(), Error> {
    const F_SETFD: i32 = 2;
    extern "C" {
        fn fcntl(fd: i32, command: i32, argument: i32) -> i32;
    }
    if unsafe { fcntl(fd, F_SETFD, 0) } == -1 {
        Err(std::io::Error::last_os_error().into())
    } else {
        Ok(())
    }
}

#[cfg(unix)]
fn ffmpeg_pipe_input(fd: std::os::fd::RawFd) -> String {
    format!("pipe:{fd}")
}

fn find_ffmpeg() -> Option<PathBuf> {
    ["/usr/bin/ffmpeg", "/bin/ffmpeg"]
        .into_iter()
        .map(PathBuf::from)
        .find(|path| Path::new(path).is_file())
}

fn validate_ppm_frame(ppm: &[u8]) -> Result<(u32, u32), Error> {
    let mut cursor = 0_usize;
    if ppm_token(ppm, &mut cursor)? != b"P6" {
        return Err(Error::Io(
            "VIDEO renderer produced a non-P6 frame".to_string(),
        ));
    }
    let width = parse_ppm_number(ppm_token(ppm, &mut cursor)?)?;
    let height = parse_ppm_number(ppm_token(ppm, &mut cursor)?)?;
    if ppm_token(ppm, &mut cursor)? != b"255" || width == 0 || height == 0 {
        return Err(Error::Io(
            "VIDEO renderer produced an invalid PPM frame".to_string(),
        ));
    }
    if cursor >= ppm.len() || !ppm[cursor].is_ascii_whitespace() {
        return Err(Error::Io(
            "VIDEO PPM frame has no pixel separator".to_string(),
        ));
    }
    cursor += usize::from(ppm[cursor] == b'\r' && ppm.get(cursor + 1) == Some(&b'\n')) + 1;
    let pixels = width
        .checked_mul(height)
        .and_then(|pixels| pixels.checked_mul(3))
        .ok_or(Error::IllegalQuantity)? as usize;
    if ppm.len().saturating_sub(cursor) != pixels {
        return Err(Error::Io(
            "VIDEO PPM frame has the wrong pixel length".to_string(),
        ));
    }
    Ok((width, height))
}

fn ppm_token<'a>(bytes: &'a [u8], cursor: &mut usize) -> Result<&'a [u8], Error> {
    while bytes.get(*cursor).is_some_and(u8::is_ascii_whitespace) {
        *cursor += 1;
    }
    let start = *cursor;
    while bytes
        .get(*cursor)
        .is_some_and(|byte| !byte.is_ascii_whitespace())
    {
        *cursor += 1;
    }
    if start == *cursor {
        return Err(Error::Io(
            "VIDEO renderer produced a truncated PPM frame".to_string(),
        ));
    }
    Ok(&bytes[start..*cursor])
}

fn parse_ppm_number(token: &[u8]) -> Result<u32, Error> {
    std::str::from_utf8(token)
        .ok()
        .and_then(|text| text.parse::<u32>().ok())
        .ok_or_else(|| Error::Io("VIDEO renderer produced an invalid PPM dimension".to_string()))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ppm(width: u32, height: u32) -> Vec<u8> {
        let mut bytes = format!("P6\n{width} {height}\n255\n").into_bytes();
        bytes.resize(bytes.len() + width as usize * height as usize * 3, 0x55);
        bytes
    }

    #[test]
    fn ppm_frames_are_strictly_validated() {
        assert_eq!(validate_ppm_frame(&ppm(3, 2)).unwrap(), (3, 2));
        assert!(validate_ppm_frame(b"P3\n1 1\n255\n0 0 0").is_err());
        assert!(validate_ppm_frame(b"P6\n1 1\n255\n\0\0").is_err());
        assert!(validate_ppm_frame(b"P6\n0 1\n255\n").is_err());
    }

    #[cfg(unix)]
    #[test]
    fn soundtrack_stream_uses_ffmpegs_inherited_pipe_protocol() {
        assert_eq!(ffmpeg_pipe_input(37), "pipe:37");
    }
}
