use crate::error::Error;
use crate::real::BasicReal;

/// Token byte codes, assigned in the same order as the keywords appear in
/// `token.s` and starting at `0x80`, matching the original Microsoft BASIC
/// macro `define_token`. Most platform-conditional tokens remain omitted.
/// Native file tokens are appended after the stable core range so enabling
/// them cannot renumber existing tokenized programs.
///
/// Statement keywords (`keyword_rts`) are first, followed by the operator
/// keywords (`keyword`), and finally the function keywords (`keyword_addr`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[repr(u16)]
pub enum Token {
    // Statement keywords: 0x80 .. 0x9B
    End = 0x80,
    For,
    Next,
    Data,
    Input,
    Dim,
    Read,
    Let,
    Goto,
    Run,
    If,
    Restore,
    Gosub,
    Return,
    Rem,
    Stop,
    On,
    Wait,
    Load,
    Save,
    Def,
    Poke,
    Print,
    Cont,
    List,
    Clear,
    Get,
    New,

    // Operator keywords: 0x9C .. 0xAC
    Tab = 0x9C,
    To,
    Fn,
    Spc,
    Then,
    Not,
    Step,
    Plus,
    Minus,
    Mul,
    Div,
    Pow,
    And,
    Or,
    Greater,
    Equal,
    Less,

    // Function keywords: 0xAD .. 0xC4
    Sgn = 0xAD,
    Int,
    Abs,
    Usr,
    Fre,
    Pos,
    Sqr,
    Rnd,
    Log,
    Exp,
    Cos,
    Sin,
    Tan,
    Atn,
    Peek,
    Len,
    Str,
    Val,
    Asc,
    Chr,
    Left,
    Right,
    Mid,
    Go,

    // Native extension tokens. Appended so enabling them does not renumber
    // the stable original-token subset above.
    InputFile,
    PrintFile,
    Open,
    Close,
    GetFile,
    Verify,
    Cmd,
    Sys,
    /// Dartmouth BASIC matrix statement extension.
    Mat,
    /// Portable scalar functions from the TI-BASIC NUM menu.
    Round,
    Ipart,
    Fpart,
    Min,
    Max,
    Lcm,
    Gcd,
    Remainder,
    /// Checked integer remainder operator from later Microsoft BASICs.
    Mod,
    Asin,
    Acos,
    Sinh,
    Cosh,
    Tanh,
    Asinh,
    Acosh,
    Atanh,
    Ln,
    Log10,
    LogBase,
    Cbrt,
    Root,
    Cube,
    Fact,
    /// TI-BASIC postfix factorial operator.
    Factorial,
    Npr,
    Ncr,
    Deg,
    Rad,
    Pi,
    Rand,
    RandInt,
    RandNorm,
    RandBin,
    Fmin,
    Fmax,
    Nderiv,
    Fnint,
    Sum,
    Solve,
    Piecewise,
    FracString,
    Complex,
    RealPart,
    Imag,
    Conj,
    Angle,
    RandIntNoRep,
    Mean,
    Median,
    // MS-BASIC extension statements (identifier-encoded, no byte code).
    // These are parsed as keywords via from_text but have no classic byte.
    While,
    Wend,
    Swap,
    WriteStmt,
    Randomize,
    OptionBase,
    Width,
    Kill,
    Name,
    Tron,
    Troff,
    DefType,
    Erase,
    LineInput,
    Lprint,
    Using,
    // Additional MS-BASIC statements
    Renum,
    Resume,
    Llist,
    Delete,
    Field,
    Lset,
    Rset,
    Null,
    Edit,
    Auto,
    Call,
    ErrorStmt,
    Out,
    Put,
}

impl Token {
    /// The original Microsoft BASIC token byte.
    pub fn to_byte(self) -> u8 {
        self as u8
    }

    /// Look up a token by its byte code.
    pub fn from_byte(b: u8) -> Option<Self> {
        use Token::*;
        Some(match b {
            0x80 => End,
            0x81 => For,
            0x82 => Next,
            0x83 => Data,
            0x84 => Input,
            0x85 => Dim,
            0x86 => Read,
            0x87 => Let,
            0x88 => Goto,
            0x89 => Run,
            0x8A => If,
            0x8B => Restore,
            0x8C => Gosub,
            0x8D => Return,
            0x8E => Rem,
            0x8F => Stop,
            0x90 => On,
            0x91 => Wait,
            0x92 => Load,
            0x93 => Save,
            0x94 => Def,
            0x95 => Poke,
            0x96 => Print,
            0x97 => Cont,
            0x98 => List,
            0x99 => Clear,
            0x9A => Get,
            0x9B => New,

            0x9C => Tab,
            0x9D => To,
            0x9E => Fn,
            0x9F => Spc,
            0xA0 => Then,
            0xA1 => Not,
            0xA2 => Step,
            0xA3 => Plus,
            0xA4 => Minus,
            0xA5 => Mul,
            0xA6 => Div,
            0xA7 => Pow,
            0xA8 => And,
            0xA9 => Or,
            0xAA => Greater,
            0xAB => Equal,
            0xAC => Less,

            0xAD => Sgn,
            0xAE => Int,
            0xAF => Abs,
            0xB0 => Usr,
            0xB1 => Fre,
            0xB2 => Pos,
            0xB3 => Sqr,
            0xB4 => Rnd,
            0xB5 => Log,
            0xB6 => Exp,
            0xB7 => Cos,
            0xB8 => Sin,
            0xB9 => Tan,
            0xBA => Atn,
            0xBB => Peek,
            0xBC => Len,
            0xBD => Str,
            0xBE => Val,
            0xBF => Asc,
            0xC0 => Chr,
            0xC1 => Left,
            0xC2 => Right,
            0xC3 => Mid,
            0xC4 => Go,
            0xC5 => InputFile,
            0xC6 => PrintFile,
            0xC7 => Open,
            0xC8 => Close,
            0xC9 => GetFile,
            0xCA => Verify,
            0xCB => Cmd,
            0xCC => Sys,
            0xCD => Mat,
            0xCE => Round,
            0xCF => Ipart,
            0xD0 => Fpart,
            0xD1 => Min,
            0xD2 => Max,
            0xD3 => Lcm,
            0xD4 => Gcd,
            0xD5 => Remainder,
            0xD6 => Mod,
            0xD7 => Asin,
            0xD8 => Acos,
            0xD9 => Sinh,
            0xDA => Cosh,
            0xDB => Tanh,
            0xDC => Asinh,
            0xDD => Acosh,
            0xDE => Atanh,
            0xDF => Ln,
            0xE0 => Log10,
            0xE1 => LogBase,
            0xE2 => Cbrt,
            0xE3 => Root,
            0xE4 => Cube,
            0xE5 => Fact,
            0xE6 => Factorial,
            0xE7 => Npr,
            0xE8 => Ncr,
            0xE9 => Deg,
            0xEA => Rad,
            0xEB => Pi,
            0xEC => Rand,
            0xED => RandInt,
            0xEE => RandNorm,
            0xEF => RandBin,
            0xF0 => Fmin,
            0xF1 => Fmax,
            0xF2 => Nderiv,
            0xF3 => Fnint,
            0xF4 => Sum,
            0xF5 => Solve,
            0xF6 => Piecewise,
            0xF7 => FracString,
            0xF8 => Complex,
            0xF9 => RealPart,
            0xFA => Imag,
            0xFB => Conj,
            0xFC => Angle,
            0xFD => RandIntNoRep,
            0xFE => Mean,
            0xFF => Median,
            _ => return None,
        })
    }

    fn from_code(code: u16) -> Option<Self> {
        if code <= u16::from(u8::MAX) {
            return Self::from_byte(code as u8);
        }
        use Token::*;
        const EXTENSIONS: &[Token] = &[
            While, Wend, Swap, WriteStmt, Randomize, OptionBase, Width, Kill, Name, Tron, Troff,
            DefType, Erase, LineInput, Lprint, Using, Renum, Resume, Llist, Delete, Field, Lset,
            Rset, Null, Edit, Auto, Call, ErrorStmt, Out, Put,
        ];
        EXTENSIONS
            .iter()
            .copied()
            .find(|token| *token as u16 == code)
    }

    /// The text form used by the detokeniser.
    pub fn to_text(self) -> &'static str {
        use Token::*;
        match self {
            End => "END",
            For => "FOR",
            Next => "NEXT",
            Data => "DATA",
            Input => "INPUT",
            Dim => "DIM",
            Read => "READ",
            Let => "LET",
            Goto => "GOTO",
            Run => "RUN",
            If => "IF",
            Restore => "RESTORE",
            Gosub => "GOSUB",
            Return => "RETURN",
            Rem => "REM",
            Stop => "STOP",
            On => "ON",
            Wait => "WAIT",
            Load => "LOAD",
            Save => "SAVE",
            Def => "DEF",
            Poke => "POKE",
            Print => "PRINT",
            Cont => "CONT",
            List => "LIST",
            Clear => "CLEAR",
            Get => "GET",
            New => "NEW",

            Tab => "TAB(",
            To => "TO",
            Fn => "FN",
            Spc => "SPC(",
            Then => "THEN",
            Not => "NOT",
            Step => "STEP",
            Plus => "+",
            Minus => "-",
            Mul => "*",
            Div => "/",
            Pow => "^",
            And => "AND",
            Or => "OR",
            Greater => ">",
            Equal => "=",
            Less => "<",

            Sgn => "SGN",
            Int => "INT",
            Abs => "ABS",
            Usr => "USR",
            Fre => "FRE",
            Pos => "POS",
            Sqr => "SQR",
            Rnd => "RND",
            Log => "LOG",
            Exp => "EXP",
            Cos => "COS",
            Sin => "SIN",
            Tan => "TAN",
            Atn => "ATN",
            Peek => "PEEK",
            Len => "LEN",
            Str => "STR$",
            Val => "VAL",
            Asc => "ASC",
            Chr => "CHR$",
            Left => "LEFT$",
            Right => "RIGHT$",
            Mid => "MID$",
            Go => "GO",
            InputFile => "INPUT#",
            PrintFile => "PRINT#",
            Open => "OPEN",
            Close => "CLOSE",
            GetFile => "GET#",
            Verify => "VERIFY",
            Cmd => "CMD",
            Sys => "SYS",
            Mat => "MAT",
            Round => "ROUND",
            Ipart => "IPART",
            Fpart => "FPART",
            Min => "MIN",
            Max => "MAX",
            Lcm => "LCM",
            Gcd => "GCD",
            Remainder => "REMAINDER",
            Mod => "MOD",
            Asin => "ASIN",
            Acos => "ACOS",
            Sinh => "SINH",
            Cosh => "COSH",
            Tanh => "TANH",
            Asinh => "ASINH",
            Acosh => "ACOSH",
            Atanh => "ATANH",
            Ln => "LN",
            Log10 => "LOG10",
            LogBase => "LOGBASE",
            Cbrt => "CBRT",
            Root => "ROOT",
            Cube => "CUBE",
            Fact => "FACT",
            Factorial => "!",
            Npr => "NPR",
            Ncr => "NCR",
            Deg => "DEG",
            Rad => "RAD",
            Pi => "PI",
            Rand => "RAND",
            RandInt => "RANDINT",
            RandNorm => "RANDNORM",
            RandBin => "RANDBIN",
            Fmin => "FMIN",
            Fmax => "FMAX",
            Nderiv => "NDERIV",
            Fnint => "FNINT",
            Sum => "SUM",
            Solve => "SOLVE",
            Piecewise => "PIECEWISE",
            FracString => "FRAC$",
            Complex => "COMPLEX",
            RealPart => "REAL",
            Imag => "IMAG",
            Conj => "CONJ",
            Angle => "ANGLE",
            RandIntNoRep => "RANDINTNOREP",
            Mean => "MEAN",
            Median => "MEDIAN",
            While => "WHILE",
            Wend => "WEND",
            Swap => "SWAP",
            WriteStmt => "WRITE",
            Randomize => "RANDOMIZE",
            OptionBase => "OPTION",
            Width => "WIDTH",
            Kill => "KILL",
            Name => "NAME",
            Tron => "TRON",
            Troff => "TROFF",
            DefType => "DEFTYPE",
            Erase => "ERASE",
            LineInput => "LINEINPUT",
            Lprint => "LPRINT",
            Using => "USING",
            Renum => "RENUM",
            Resume => "RESUME",
            Llist => "LLIST",
            Delete => "DELETE",
            Field => "FIELD",
            Lset => "LSET",
            Rset => "RSET",
            Null => "NULL",
            Edit => "EDIT",
            Auto => "AUTO",
            Call => "CALL",
            ErrorStmt => "ERROR",
            Out => "OUT",
            Put => "PUT",
        }
    }

    /// Parse a keyword token from text.  This is the inverse of [`Token::to_text`].
    pub fn from_text(text: &str) -> Option<Self> {
        use Token::*;
        Some(match text {
            "END" => End,
            "FOR" => For,
            "NEXT" => Next,
            "DATA" => Data,
            "INPUT" => Input,
            "DIM" => Dim,
            "READ" => Read,
            "LET" => Let,
            "GOTO" => Goto,
            "RUN" => Run,
            "IF" => If,
            "RESTORE" => Restore,
            "GOSUB" => Gosub,
            "RETURN" => Return,
            "REM" => Rem,
            "STOP" => Stop,
            "ON" => On,
            "WAIT" => Wait,
            "LOAD" => Load,
            "SAVE" => Save,
            "DEF" => Def,
            "POKE" => Poke,
            "PRINT" => Print,
            "CONT" => Cont,
            "LIST" => List,
            "CLEAR" | "CLR" => Clear,
            "GET" => Get,
            "NEW" => New,

            "TAB(" => Tab,
            "TO" => To,
            "FN" => Fn,
            "SPC(" => Spc,
            "THEN" => Then,
            "NOT" => Not,
            "STEP" => Step,
            "+" => Plus,
            "-" => Minus,
            "*" => Mul,
            "/" => Div,
            "^" => Pow,
            "AND" => And,
            "OR" => Or,
            ">" => Greater,
            "=" => Equal,
            "<" => Less,

            "SGN" => Sgn,
            "INT" => Int,
            "ABS" => Abs,
            "USR" => Usr,
            "FRE" => Fre,
            "POS" => Pos,
            "SQR" => Sqr,
            "RND" => Rnd,
            "LOG" => Log,
            "EXP" => Exp,
            "COS" => Cos,
            "SIN" => Sin,
            "TAN" => Tan,
            "ATN" => Atn,
            "PEEK" => Peek,
            "LEN" => Len,
            "STR$" => Str,
            "VAL" => Val,
            "ASC" => Asc,
            "CHR$" => Chr,
            "LEFT$" => Left,
            "RIGHT$" => Right,
            "MID$" => Mid,
            "GO" => Go,
            "INPUT#" => InputFile,
            "PRINT#" => PrintFile,
            "OPEN" => Open,
            "CLOSE" => Close,
            "GET#" => GetFile,
            "VERIFY" => Verify,
            "CMD" => Cmd,
            "SYS" => Sys,
            "MAT" => Mat,
            "ROUND" => Round,
            "IPART" => Ipart,
            "FPART" => Fpart,
            "MIN" => Min,
            "MAX" => Max,
            "LCM" => Lcm,
            "GCD" => Gcd,
            "REMAINDER" => Remainder,
            "MOD" => Mod,
            "ASIN" => Asin,
            "ACOS" => Acos,
            "SINH" => Sinh,
            "COSH" => Cosh,
            "TANH" => Tanh,
            "ASINH" => Asinh,
            "ACOSH" => Acosh,
            "ATANH" => Atanh,
            "LN" => Ln,
            "LOG10" => Log10,
            "LOGBASE" => LogBase,
            "CBRT" => Cbrt,
            "ROOT" => Root,
            "CUBE" => Cube,
            "FACT" => Fact,
            "!" => Factorial,
            "NPR" => Npr,
            "NCR" => Ncr,
            "DEG" => Deg,
            "RAD" => Rad,
            "PI" => Pi,
            "RAND" => Rand,
            "RANDINT" => RandInt,
            "RANDNORM" => RandNorm,
            "RANDBIN" => RandBin,
            "FMIN" => Fmin,
            "FMAX" => Fmax,
            "NDERIV" => Nderiv,
            "FNINT" => Fnint,
            "SUM" => Sum,
            "SOLVE" => Solve,
            "PIECEWISE" => Piecewise,
            "FRAC$" => FracString,
            "COMPLEX" => Complex,
            "REAL" => RealPart,
            "IMAG" => Imag,
            "CONJ" => Conj,
            "ANGLE" => Angle,
            "RANDINTNOREP" => RandIntNoRep,
            "MEAN" => Mean,
            "MEDIAN" => Median,
            "WHILE" => While,
            "WEND" => Wend,
            "SWAP" => Swap,
            "WRITE" => WriteStmt,
            "RANDOMIZE" => Randomize,
            "OPTION" => OptionBase,
            "WIDTH" => Width,
            "KILL" => Kill,
            "NAME" => Name,
            "TRON" => Tron,
            "TROFF" => Troff,
            "DEFTYPE" => DefType,
            "ERASE" => Erase,
            "LINEINPUT" | "LINE INPUT" => LineInput,
            "LPRINT" => Lprint,
            "USING" => Using,
            "RENUM" => Renum,
            "RENUMBER" => Renum,
            "RESUME" => Resume,
            "LLIST" => Llist,
            "DELETE" => Delete,
            "FIELD" => Field,
            "LSET" => Lset,
            "RSET" => Rset,
            "NULL" => Null,
            "EDIT" => Edit,
            "AUTO" => Auto,
            "CALL" => Call,
            "ERROR" => ErrorStmt,
            "OUT" => Out,
            "PUT" => Put,
            _ => return None,
        })
    }
}

/// A token instance, including runtime values (numbers, identifiers, strings).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TokenInstance {
    Keyword(Token),
    Number(i64),
    Real(String),
    Ident(String),
    String(String),
    Rem(String),
    Data(String),
    Colon,
    Comma,
    Semicolon,
    LParen,
    RParen,
    LBrace,
    RBrace,
    /// Classic Microsoft BASIC file-channel marker used by forms such as
    /// `PRINT #1`, `INPUT #1`, `CLOSE #1`, and `OPEN ... AS #1`.
    Hash,
    /// Microsoft-family integer-division operator (`\\`).  This remains
    /// punctuation rather than consuming an extension keyword byte, whose
    /// historical one-byte range is already full.
    IntegerDiv,
    /// TI-BASIC store arrow (`→` or ASCII-compatible `->`).
    StoreArrow,
}

/// Tokenise a single line of BASIC text.
///
/// The first numeric token is treated as a line number if it appears at the
/// very start of the line. Keywords are recognised case-insensitively with
/// classic Microsoft BASIC compact matching and converted to their token codes.
/// Quoted strings, apostrophe comments, and `REM` text are preserved exactly.
pub fn tokenize(line: &str) -> Result<Vec<TokenInstance>, Error> {
    let mut out = Vec::new();
    let mut chars = line.chars().peekable();
    let mut first_number = true;
    let mut expect_fn_name = false;

    while let Some(&c) = chars.peek() {
        if c.is_whitespace() {
            chars.next();
            continue;
        }

        // Line number: digits at the very beginning of the line.
        if first_number && c.is_ascii_digit() {
            out.push(scan_numeric_literal(&mut chars)?);
            first_number = false;
            continue;
        }
        first_number = false;

        // Microsoft-family BASIC radix literals. Keep them numeric internally;
        // LIST may canonicalize them to decimal without changing their value.
        if c == '&' {
            let mut probe = chars.clone();
            probe.next();
            if matches!(probe.next(), Some('H' | 'h' | 'O' | 'o' | 'B' | 'b')) {
                out.push(scan_radix_literal(&mut chars)?);
                continue;
            }
        }

        // A compact or spaced DEF FN name is an identifier even when its
        // suffix is also a built-in keyword (for example FNCUBE).  Reserving
        // the leading FN token while protecting the following name preserves
        // classic user functions as the extension keyword table grows.
        if expect_fn_name {
            expect_fn_name = false;
            if c.is_ascii_alphabetic() {
                out.push(TokenInstance::Ident(
                    scan_identifier(&mut chars).to_ascii_uppercase(),
                ));
                continue;
            }
        }

        // Later Microsoft BASICs accept apostrophe as a compact REM.
        if c == '\'' {
            chars.next();
            let rest: String = chars.by_ref().collect();
            out.push(TokenInstance::Rem(
                rest.strip_prefix(' ').unwrap_or(&rest).to_string(),
            ));
            break;
        }

        // Quoted string literal. Two consecutive quotes encode one literal
        // quote, matching Microsoft BASIC source conventions.
        if c == '"' {
            chars.next();
            let mut s = String::new();
            loop {
                match chars.next() {
                    Some('"') if matches!(chars.peek(), Some('"')) => {
                        chars.next();
                        s.push('"');
                    }
                    Some('"') => break,
                    Some(ch) => s.push(ch),
                    None => return Err(Error::syntax("unterminated string literal")),
                }
            }
            out.push(TokenInstance::String(s));
            continue;
        }

        // Advanced mathematical functions remain identifier-encoded because
        // the historical one-byte token table is full. Protect a known
        // function name only when it is followed by a call parenthesis; this
        // preserves compact classic forms such as PRINTA and GOTO100 while
        // preventing TOTAL(...), EXP2(...), and CIRCLEAREA(...) from being
        // split into shorter statement/operator keywords.
        if let Some(name) = try_math_function_identifier(&mut chars) {
            out.push(TokenInstance::Ident(name));
            continue;
        }

        // A longer variable name must not be broken apart merely because it
        // starts with a compact keyword (TOTALPOP, MAXENT, STARVED, and so on).
        // Preserve classic forms such as IFA=1THEN... and FORI=1TO... at the
        // beginning of a statement, while using the surrounding token stream
        // to recognize assignment targets and expression operands.
        if c.is_ascii_alphabetic() {
            if let Some(name) = try_prefixed_variable_identifier(&mut chars, &out) {
                out.push(TokenInstance::Ident(name));
                continue;
            }
        }

        // ModernBASIC statements added beyond the historical one-byte token
        // table remain identifier-encoded. They still use classic compact
        // keyword matching, so CHAIN"NEXT.BAS" and COMMona are split exactly
        // like native Microsoft BASIC statement names.
        if let Some(name) = try_native_statement_identifier(&mut chars) {
            out.push(TokenInstance::Ident(name));
            continue;
        }

        // TI-BASIC graph commands use hyphenated catalog spellings. They are
        // identifier-encoded because the historical one-byte token space is
        // already full, but must be recognized before '-' becomes an
        // arithmetic operator.
        if let Some(name) = try_extended_identifier(&mut chars) {
            out.push(TokenInstance::Ident(name));
            continue;
        }

        // Multi-character operators and punctuation.
        let two: String = chars.clone().take(2).collect();
        let single = c;

        if two == "<=" || two == ">=" || two == "<>" || two == "->" {
            if two == "->" {
                chars.next();
                chars.next();
                out.push(TokenInstance::StoreArrow);
                continue;
            }
            if two == "<=" || two == ">=" || two == "<>" {
                chars.next();
                chars.next();
                let (first, second) = match two.as_str() {
                    "<=" => (Token::Less, Token::Equal),
                    ">=" => (Token::Greater, Token::Equal),
                    "<>" => (Token::Less, Token::Greater),
                    _ => unreachable!(),
                };
                out.push(TokenInstance::Keyword(first));
                out.push(TokenInstance::Keyword(second));
                continue;
            }
        }

        // RANDOM is an OPEN mode word. Recognize it as one identifier before
        // classic RAND matching can split it into RAND + OM.
        if ascii_prefix_matches(&chars, "RANDOM")
            && !chars
                .clone()
                .nth("RANDOM".len())
                .is_some_and(|next| next.is_ascii_alphanumeric() || is_identifier_suffix(next))
        {
            for _ in 0.."RANDOM".len() {
                chars.next();
            }
            out.push(TokenInstance::Ident("RANDOM".to_string()));
            continue;
        }

        // OUT and PUT require boundary-aware matching so OUTPUT remains one
        // identifier in OPEN ... FOR OUTPUT while OUT77 and PUT#1 still work.
        if let Some(tok) = try_line_input(&mut chars).or_else(|| {
            try_boundary_statement_keyword(&mut chars).or_else(|| try_keyword(&mut chars))
        }) {
            // REM consumes the rest of the line as a single Rem token.
            if tok == Token::Rem {
                let rest: String = chars.by_ref().collect();
                let rest = rest.strip_prefix(' ').unwrap_or(&rest).to_string();
                out.push(TokenInstance::Rem(rest));
                break;
            }
            // DATA captures everything up to the next unquoted colon or EOL as
            // an opaque payload. Keywords and punctuation inside the payload
            // are left untokenized, matching the original DATAFLG behavior in
            // program.s.
            if tok == Token::Data {
                let payload = capture_data_payload(&mut chars);
                out.push(TokenInstance::Keyword(tok));
                out.push(TokenInstance::Data(payload));
                continue;
            }
            out.push(TokenInstance::Keyword(tok));
            expect_fn_name = tok == Token::Fn;
            continue;
        }

        match single {
            '?' => {
                // The original program tokenizer expands `?` to the PRINT
                // token before keyword lookup (program.s). Keep the encoded
                // and detokenized form canonical rather than retaining an
                // alias-only punctuation token.
                chars.next();
                out.push(TokenInstance::Keyword(Token::Print));
            }
            '\\' => {
                chars.next();
                out.push(TokenInstance::IntegerDiv);
            }
            ':' => {
                chars.next();
                out.push(TokenInstance::Colon);
            }
            ',' => {
                chars.next();
                out.push(TokenInstance::Comma);
            }
            ';' => {
                chars.next();
                out.push(TokenInstance::Semicolon);
            }
            '(' => {
                chars.next();
                out.push(TokenInstance::LParen);
            }
            ')' => {
                chars.next();
                out.push(TokenInstance::RParen);
            }
            '{' => {
                chars.next();
                out.push(TokenInstance::LBrace);
            }
            '}' => {
                chars.next();
                out.push(TokenInstance::RBrace);
            }
            '.' if chars
                .clone()
                .nth(1)
                .is_some_and(|next| next.is_ascii_alphabetic()) =>
            {
                chars.next();
                let field = scan_identifier(&mut chars).to_ascii_uppercase();
                let target = match out.last() {
                    Some(TokenInstance::Ident(_)) => out.len() - 1,
                    Some(TokenInstance::RParen) => {
                        let mut depth = 0usize;
                        let mut open = None;
                        for index in (0..out.len()).rev() {
                            match out[index] {
                                TokenInstance::RParen => depth = depth.saturating_add(1),
                                TokenInstance::LParen => {
                                    depth = depth.checked_sub(1).ok_or_else(|| {
                                        Error::syntax("unexpected '.' after expression")
                                    })?;
                                    if depth == 0 {
                                        open = Some(index);
                                        break;
                                    }
                                }
                                _ => {}
                            }
                        }
                        open.and_then(|index| index.checked_sub(1)).ok_or_else(|| {
                            Error::syntax("record field requires a variable before '.'")
                        })?
                    }
                    _ => return Err(Error::syntax("record field requires a variable before '.'")),
                };
                let Some(TokenInstance::Ident(name)) = out.get_mut(target) else {
                    return Err(Error::syntax("record field requires a variable before '.'"));
                };
                name.push('.');
                name.push_str(&field);
            }
            '#' => {
                chars.next();
                out.push(TokenInstance::Hash);
            }
            '→' => {
                chars.next();
                out.push(TokenInstance::StoreArrow);
            }
            '+' | '-' | '*' | '/' | '^' | '=' | '<' | '>' => {
                chars.next();
                let tok = match single {
                    '+' => Token::Plus,
                    '-' => Token::Minus,
                    '*' => Token::Mul,
                    '/' => Token::Div,
                    '^' => Token::Pow,
                    '=' => Token::Equal,
                    '<' => Token::Less,
                    '>' => Token::Greater,
                    _ => unreachable!(),
                };
                out.push(TokenInstance::Keyword(tok));
            }
            _ => {
                if c.is_ascii_alphabetic() {
                    out.push(TokenInstance::Ident(
                        scan_identifier(&mut chars).to_ascii_uppercase(),
                    ));
                } else if c.is_ascii_digit()
                    || (c == '.'
                        && chars
                            .clone()
                            .nth(1)
                            .is_some_and(|next| next.is_ascii_digit()))
                {
                    out.push(scan_numeric_literal(&mut chars)?);
                } else {
                    return Err(Error::syntax(format!("unexpected character '{c}'")));
                }
            }
        }
    }

    Ok(out)
}

fn is_identifier_suffix(ch: char) -> bool {
    matches!(ch, '$' | '%' | '&' | '!' | '#')
}

fn scan_identifier(chars: &mut std::iter::Peekable<std::str::Chars>) -> String {
    let mut name = String::new();
    while let Some(&ch) = chars.peek() {
        if ch.is_ascii_alphanumeric() {
            name.push(ch);
            chars.next();
        } else {
            break;
        }
    }
    if let Some(&suffix) = chars.peek().filter(|&&ch| is_identifier_suffix(ch)) {
        name.push(suffix);
        chars.next();
    }
    name
}

fn ascii_prefix_matches(chars: &std::iter::Peekable<std::str::Chars>, prefix: &str) -> bool {
    chars
        .clone()
        .take(prefix.len())
        .map(|character| character.to_ascii_uppercase())
        .eq(prefix.chars())
}

fn try_prefixed_variable_identifier(
    chars: &mut std::iter::Peekable<std::str::Chars>,
    out: &[TokenInstance],
) -> Option<String> {
    let mut word_end = chars.clone();
    let name = scan_identifier(&mut word_end).to_ascii_uppercase();
    if name.is_empty() {
        return None;
    }

    let mut after_word = word_end;
    while after_word.peek().is_some_and(|ch| ch.is_whitespace()) {
        after_word.next();
    }
    if name.starts_with("FN") && name.len() > "FN".len() && matches!(after_word.peek(), Some('(')) {
        return None;
    }
    let assignment = matches!(after_word.peek(), Some('='));
    let statement_start = out.is_empty()
        || matches!(
            out.last(),
            Some(TokenInstance::Number(_))
                | Some(TokenInstance::Colon)
                | Some(TokenInstance::Keyword(Token::Then))
        );
    let expression_operand = out.is_empty()
        || matches!(
            out.last(),
            Some(TokenInstance::LParen)
                | Some(TokenInstance::LBrace)
                | Some(TokenInstance::Comma)
                | Some(TokenInstance::Semicolon)
                | Some(TokenInstance::Keyword(
                    Token::Print
                        | Token::Call
                        | Token::If
                        | Token::On
                        | Token::To
                        | Token::Step
                        | Token::Not
                        | Token::Plus
                        | Token::Minus
                        | Token::Mul
                        | Token::Div
                        | Token::Pow
                        | Token::Equal
                        | Token::Less
                        | Token::Greater
                        | Token::And
                        | Token::Or
                        | Token::Mod
                ))
                | Some(TokenInstance::Ident(_))
        );

    // Identifier-encoded extensions remain legal variable names. Protect
    // their complete spelling in assignment position before classic compact
    // keyword matching can split FORMAT$ into FOR + MAT$, or turn LPRINT into
    // a statement token.
    let extension_variable_name = matches!(
        name.as_str(),
        "COMPILE" | "LOADB" | "SAVEB" | "LPRINT" | "STRIG" | "PEN" | "FORMAT$"
    );
    if extension_variable_name
        && ((assignment && statement_start) || (expression_operand && !statement_start))
    {
        for _ in 0..name.len() {
            chars.next();
        }
        return Some(name);
    }

    if identifier_is_exact_reserved(chars, name.len()) {
        return None;
    }

    // These prefixes are the ambiguous compact control forms exercised by
    // classic Microsoft BASIC source. Other names followed by '=' are
    // unambiguously assignment destinations in ModernBASIC.
    if assignment
        && statement_start
        && ["IF", "FOR", "LET", "ON"]
            .iter()
            .any(|prefix| name.starts_with(prefix) && name.len() > prefix.len())
    {
        return None;
    }

    if !assignment && !expression_operand {
        return None;
    }

    for _ in 0..name.len() {
        chars.next();
    }
    Some(name)
}

fn identifier_is_exact_reserved(
    chars: &std::iter::Peekable<std::str::Chars>,
    identifier_len: usize,
) -> bool {
    let name = chars
        .clone()
        .take(identifier_len)
        .map(|character| character.to_ascii_uppercase())
        .collect::<String>();
    if name == "FACTORIAL"
        || Token::from_text(&name).is_some()
        || (chars.clone().nth(identifier_len) == Some('(')
            && Token::from_text(&format!("{name}(")).is_some())
    {
        return true;
    }

    let mut probe = chars.clone();
    if try_native_statement_identifier(&mut probe).as_deref() == Some(name.as_str()) {
        return true;
    }
    let mut probe = chars.clone();
    try_extended_identifier(&mut probe).as_deref() == Some(name.as_str())
}

fn try_math_function_identifier(
    chars: &mut std::iter::Peekable<std::str::Chars>,
) -> Option<String> {
    let mut probe = chars.clone();
    let mut name = String::new();
    while let Some(&character) = probe.peek() {
        if character.is_ascii_alphanumeric() {
            name.push(character.to_ascii_uppercase());
            probe.next();
        } else {
            break;
        }
    }
    if name.is_empty() || !crate::math_engine::is_builtin(&name) {
        return None;
    }
    while probe
        .peek()
        .is_some_and(|character| character.is_whitespace())
    {
        probe.next();
    }
    if !matches!(probe.peek(), Some('(')) {
        return None;
    }
    for _ in 0..name.len() {
        chars.next();
    }
    Some(name)
}

fn try_native_statement_identifier(
    chars: &mut std::iter::Peekable<std::str::Chars>,
) -> Option<String> {
    // Text-terminal extensions require a complete identifier. Unlike the
    // compact historical token spellings below, HOME must not split HOMES(0)
    // and VIEW must not split an ordinary VIEWPORT variable.
    const EXACT_NAMES: &[&str] = &[
        "SCREENCONTROL",
        "SCREENUNLOCK",
        "SCREENLOCK",
        "TEXTCOLOR",
        "COMPILE",
        "LOADB",
        "SAVEB",
        "LOCATE",
        "SLEEP",
        "HTAB",
        "VTAB",
        "HOME",
        "VIEW",
    ];
    for name in EXACT_NAMES {
        if ascii_prefix_matches(chars, name)
            && !chars.clone().nth(name.len()).is_some_and(|character| {
                character.is_ascii_alphanumeric() || is_identifier_suffix(character)
            })
        {
            for _ in 0..name.len() {
                chars.next();
            }
            return Some((*name).to_string());
        }
    }

    // Longest spellings must appear before shorter classic prefixes.  In
    // particular, DRAWF/DRAWINV must be protected before DRAW, TANGENT before
    // TAN, and CLRDRAW before the CLR alias.  These commands remain ordinary
    // ModernBASIC statements even though their capabilities come from the
    // TI graph subsystem.
    const NAMES: &[&str] = &[
        "FUNCTION",
        "PRESERVE",
        "BYREF",
        "BYVAL",
        "SHARED",
        "STATIC",
        "REDIM",
        "CONST",
        "SUB",
        "TYPE",
        "RADIALGRADIENT",
        "PERSPECTIVE",
        "MODULATION",
        "EXPRESSION",
        "PITCHBEND",
        "SOUNDFONT",
        "DSP",
        "SUSTAIN",
        "REVERB",
        "CHORUS",
        "SING",
        "DEPTHGRID",
        "DEPTHPERCEPTION",
        "GRIDON",
        "GRIDOFF",
        "GRIDPOINT",
        "ENDLAYER",
        "ENDGROUP",
        "BEGINGROUP",
        "BEGINLAYER",
        "LAYER",
        "GROUP",
        "LIGHT",
        "NGON",
        "STAR",
        "PATH",
        "BITMAP",
        "ADVANCESPRITES",
        "SPRITEMOTION",
        "MOVESPRITE",
        "ZSTANDARD",
        "DISPGRAPH",
        "GRAPHSTYLE",
        "GRAPHICS",
        "HORIZONTAL",
        "SCREENSHOT",
        "VIDEO",
        "SAVEIMAGE",
        "ROUNDEDRECT",
        "BLEND",
        "TRANSLATE",
        "ROTATE",
        "SCALE",
        "BEZIER",
        "GRADIENT",
        "ARC",
        "RECTANGLE",
        "DRAWINV",
        "TANGENT",
        "COORDOFF",
        "COORDON",
        "LABELON",
        "LABELOFF",
        "AXESOFF",
        "AXESON",
        "GRIDOFF",
        "GRIDON",
        "ZDECIMAL",
        "ZSQUARE",
        "POLYGON",
        "VERTICAL",
        "CLRDRAW",
        "GCIRCLE",
        "PRESET",
        "PALETTE",
        "ELLIPSE",
        "DRAWTO",
        "DISPLAY",
        "SPRITE",
        "SCREEN",
        "CIRCLE",
        "COMMON",
        "CHAIN",
        "MERGE",
        "DRAWF",
        "SHADE",
        "ZTRIG",
        "BRUSH",
        "BUFFER",
        "FLIPBOOK",
        "FLIP",
        "COLOR",
        "PSET",
        "PAINT",
        "DRAW",
        "MOVE",
        "TEXT",
        "RECT",
        "RENDER",
        "WEB",
        "GRAPH",
        "GLINE",
        "GTEXT",
        "BLIT",
        "CLS",
    ];
    for name in NAMES {
        if ascii_prefix_matches(chars, name) {
            for _ in 0..name.len() {
                chars.next();
            }
            return Some((*name).to_string());
        }
    }
    None
}

fn try_extended_identifier(chars: &mut std::iter::Peekable<std::str::Chars>) -> Option<String> {
    const NAMES: &[&str] = &[
        "PXL-CHANGE",
        "PXL-TEST",
        "PXL-OFF",
        "PXL-ON",
        "PT-CHANGE",
        "PT-TEST",
        "PT-OFF",
        "PT-ON",
        "FNOFF",
        "FNON",
    ];
    for name in NAMES {
        if !ascii_prefix_matches(chars, name) {
            continue;
        }
        if chars.clone().nth(name.len()).is_some_and(|next| {
            next.is_ascii_alphanumeric() || is_identifier_suffix(next) || next == '-'
        }) {
            continue;
        }
        for _ in 0..name.len() {
            chars.next();
        }
        return Some((*name).to_string());
    }
    None
}

fn scan_radix_literal(
    chars: &mut std::iter::Peekable<std::str::Chars>,
) -> Result<TokenInstance, Error> {
    chars.next(); // '&'
    let marker = chars
        .next()
        .ok_or_else(|| Error::syntax("radix literal requires H, O, or B"))?;
    let radix = match marker.to_ascii_uppercase() {
        'H' => 16,
        'O' => 8,
        'B' => 2,
        _ => return Err(Error::syntax("radix literal requires H, O, or B")),
    };
    let mut digits = String::new();
    while let Some(&character) = chars.peek() {
        if character.is_digit(radix) {
            digits.push(character);
            chars.next();
        } else {
            break;
        }
    }
    if digits.is_empty() {
        return Err(Error::syntax("radix literal requires digits"));
    }
    let number = i64::from_str_radix(&digits, radix)
        .map_err(|_| Error::syntax(format!("bad radix number &{marker}{digits}")))?;
    Ok(TokenInstance::Number(number))
}

fn scan_numeric_literal(
    chars: &mut std::iter::Peekable<std::str::Chars>,
) -> Result<TokenInstance, Error> {
    let mut text = String::new();
    let mut real = false;

    while chars.peek().is_some_and(|ch| ch.is_ascii_digit()) {
        text.push(chars.next().expect("peeked digit"));
    }
    if matches!(chars.peek(), Some('.')) {
        real = true;
        text.push(chars.next().expect("peeked decimal point"));
        while chars.peek().is_some_and(|ch| ch.is_ascii_digit()) {
            text.push(chars.next().expect("peeked digit"));
        }
    }
    if matches!(chars.peek(), Some('e' | 'E')) {
        real = true;
        chars.next();
        text.push('E');
        if matches!(chars.peek(), Some('+' | '-')) {
            text.push(chars.next().expect("peeked exponent sign"));
        }
        let exponent_start = text.len();
        while chars.peek().is_some_and(|ch| ch.is_ascii_digit()) {
            text.push(chars.next().expect("peeked exponent digit"));
        }
        if text.len() == exponent_start {
            return Err(Error::syntax("exponent requires digits"));
        }
    }

    if real {
        BasicReal::parse(&text)?;
        Ok(TokenInstance::Real(text))
    } else {
        let number = text
            .parse::<i64>()
            .map_err(|_| Error::syntax(format!("bad number {text}")))?;
        Ok(TokenInstance::Number(number))
    }
}

/// Capture a DATA payload up to the next unquoted colon or end of line.
///
/// A single leading space after the keyword is stripped, matching the
/// canonicalizing behavior used for `REM`.
fn capture_data_payload(chars: &mut std::iter::Peekable<std::str::Chars>) -> String {
    let mut payload = String::new();
    let mut in_quote = false;
    while let Some(&c) = chars.peek() {
        if c == '"' {
            in_quote = !in_quote;
            payload.push(c);
            chars.next();
        } else if c == ':' && !in_quote {
            break;
        } else {
            payload.push(c);
            chars.next();
        }
    }
    payload.strip_prefix(' ').unwrap_or(&payload).to_string()
}

/// Match classic statements whose names collide with longer mode words.
fn try_boundary_statement_keyword(
    chars: &mut std::iter::Peekable<std::str::Chars>,
) -> Option<Token> {
    for (name, token) in [("OUT", Token::Out), ("PUT", Token::Put)] {
        if !ascii_prefix_matches(chars, name) {
            continue;
        }
        if chars
            .clone()
            .nth(name.len())
            .is_some_and(|next| next.is_ascii_alphabetic() || matches!(next, '$' | '%' | '&' | '!'))
        {
            continue;
        }
        for _ in 0..name.len() {
            chars.next();
        }
        return Some(token);
    }
    None
}

/// Consume the Microsoft `LINE INPUT` compound keyword in either its
/// traditional spaced spelling or the compact token spelling.
fn try_line_input(chars: &mut std::iter::Peekable<std::str::Chars>) -> Option<Token> {
    let consumed = if ascii_prefix_matches(chars, "LINEINPUT") {
        Some("LINEINPUT".len())
    } else {
        let mut probe = chars.clone();
        if !ascii_prefix_matches(&probe, "LINE") {
            return None;
        }
        for _ in 0.."LINE".len() {
            probe.next();
        }
        let mut whitespace = 0;
        while probe
            .peek()
            .is_some_and(|character| character.is_whitespace())
        {
            whitespace += 1;
            probe.next();
        }
        (whitespace > 0 && ascii_prefix_matches(&probe, "INPUT"))
            .then_some("LINE".len() + whitespace + "INPUT".len())
    }?;
    for _ in 0..consumed {
        chars.next();
    }
    Some(Token::LineInput)
}

/// Consume a keyword from the front of the iterator, if one matches.
fn try_keyword(chars: &mut std::iter::Peekable<std::str::Chars>) -> Option<Token> {
    // Longest keywords first so that "SPC(" beats "SPC" and "TAB(" beats "TAB".
    const KEYWORDS: &[(&str, Token)] = &[
        ("FACTORIAL", Token::Fact),
        ("RANDOMIZE", Token::Randomize),
        ("RENUMBER", Token::Renum),
        ("RANDNORM", Token::RandNorm),
        ("RANDINTNOREP", Token::RandIntNoRep),
        ("RANDINT", Token::RandInt),
        ("RANDBIN", Token::RandBin),
        ("LOGBASE", Token::LogBase),
        ("PIECEWISE", Token::Piecewise),
        ("COMPLEX", Token::Complex),
        ("FRAC$", Token::FracString),
        ("MEDIAN", Token::Median),
        ("NDERIV", Token::Nderiv),
        ("LEFT$", Token::Left),
        ("RIGHT$", Token::Right),
        ("REMAINDER", Token::Remainder),
        ("ASINH", Token::Asinh),
        ("ACOSH", Token::Acosh),
        ("ATANH", Token::Atanh),
        ("MID$", Token::Mid),
        ("CHR$", Token::Chr),
        ("STR$", Token::Str),
        ("GOSUB", Token::Gosub),
        ("GOTO", Token::Goto),
        ("RESTORE", Token::Restore),
        ("RETURN", Token::Return),
        ("VERIFY", Token::Verify),
        ("INPUT#", Token::InputFile),
        ("PRINT#", Token::PrintFile),
        ("GET#", Token::GetFile),
        ("INPUT", Token::Input),
        ("PRINT", Token::Print),
        ("THEN", Token::Then),
        ("STEP", Token::Step),
        ("WAIT", Token::Wait),
        ("LOAD", Token::Load),
        ("SAVE", Token::Save),
        ("POKE", Token::Poke),
        ("LIST", Token::List),
        ("CLEAR", Token::Clear),
        ("IPART", Token::Ipart),
        ("FPART", Token::Fpart),
        ("ROUND", Token::Round),
        ("ANGLE", Token::Angle),
        ("LOG10", Token::Log10),
        ("RAND", Token::Rand),
        ("FNINT", Token::Fnint),
        ("SOLVE", Token::Solve),
        ("FMIN", Token::Fmin),
        ("FMAX", Token::Fmax),
        ("SUM", Token::Sum),
        ("CLR", Token::Clear),
        ("CONT", Token::Cont),
        ("CLOSE", Token::Close),
        ("OPEN", Token::Open),
        ("CMD", Token::Cmd),
        ("SYS", Token::Sys),
        ("MAT", Token::Mat),
        ("MOD", Token::Mod),
        ("ASIN", Token::Asin),
        ("ACOS", Token::Acos),
        ("SINH", Token::Sinh),
        ("COSH", Token::Cosh),
        ("TANH", Token::Tanh),
        ("CBRT", Token::Cbrt),
        ("ROOT", Token::Root),
        ("REAL", Token::RealPart),
        ("IMAG", Token::Imag),
        ("CONJ", Token::Conj),
        ("MEAN", Token::Mean),
        ("CUBE", Token::Cube),
        ("FACT", Token::Fact),
        ("NPR", Token::Npr),
        ("NCR", Token::Ncr),
        ("DEG", Token::Deg),
        ("RAD", Token::Rad),
        ("PI", Token::Pi),
        ("LN", Token::Ln),
        ("LCM", Token::Lcm),
        ("GCD", Token::Gcd),
        ("MIN", Token::Min),
        ("MAX", Token::Max),
        ("NEXT", Token::Next),
        ("READ", Token::Read),
        ("DATA", Token::Data),
        ("STOP", Token::Stop),
        ("SPC(", Token::Spc),
        ("TAB(", Token::Tab),
        ("REM", Token::Rem),
        ("END", Token::End),
        ("FOR", Token::For),
        ("DIM", Token::Dim),
        ("LET", Token::Let),
        ("RUN", Token::Run),
        ("IF", Token::If),
        ("ON", Token::On),
        ("DEF", Token::Def),
        ("GET", Token::Get),
        ("NEW", Token::New),
        ("NOT", Token::Not),
        ("AND", Token::And),
        ("OR", Token::Or),
        ("TO", Token::To),
        ("FN", Token::Fn),
        ("SGN", Token::Sgn),
        ("INT", Token::Int),
        ("ABS", Token::Abs),
        ("USR", Token::Usr),
        ("FRE", Token::Fre),
        ("POS", Token::Pos),
        ("SQR", Token::Sqr),
        ("RND", Token::Rnd),
        ("LOG", Token::Log),
        ("EXP", Token::Exp),
        ("COS", Token::Cos),
        ("SIN", Token::Sin),
        ("TAN", Token::Tan),
        ("ATN", Token::Atn),
        ("PEEK", Token::Peek),
        ("LEN", Token::Len),
        ("VAL", Token::Val),
        ("ASC", Token::Asc),
        ("GO", Token::Go),
        ("RESUME", Token::Resume),
        ("LLIST", Token::Llist),
        ("DELETE", Token::Delete),
        ("FIELD", Token::Field),
        ("LSET", Token::Lset),
        ("RSET", Token::Rset),
        ("NULL", Token::Null),
        ("RENUM", Token::Renum),
        ("EDIT", Token::Edit),
        ("AUTO", Token::Auto),
        ("CALL", Token::Call),
        ("ERROR", Token::ErrorStmt),
        // MS-BASIC extension statements
        ("OPTION", Token::OptionBase),
        ("WHILE", Token::While),
        ("WEND", Token::Wend),
        ("SWAP", Token::Swap),
        ("WRITE", Token::WriteStmt),
        ("WIDTH", Token::Width),
        ("KILL", Token::Kill),
        ("NAME", Token::Name),
        ("TRON", Token::Tron),
        ("TROFF", Token::Troff),
        ("ERASE", Token::Erase),
        ("LPRINT", Token::Lprint),
        ("USING", Token::Using),
    ];

    for (kw, tok) in KEYWORDS {
        if ascii_prefix_matches(chars, kw) {
            // PI is a common variable name in classic BASIC. Reserve it only
            // for the explicit TI extension spelling PI().
            if matches!(tok, Token::Pi | Token::RealPart) {
                let mut after = chars.clone();
                for _ in 0..kw.len() {
                    after.next();
                }
                while after
                    .peek()
                    .is_some_and(|character| character.is_whitespace())
                {
                    after.next();
                }
                if !matches!(after.peek(), Some('(')) {
                    continue;
                }
            }
            // Classic Microsoft BASIC tokenization is intentionally compact:
            // keywords do not require a trailing word boundary.  This is what
            // makes forms such as GOTO100, IFA=1THENPRINTA, and FORI=1TO10
            // legal.  As on the original systems, identifiers beginning with
            // a reserved word are split at that word.
            for _ in 0..kw.len() {
                chars.next();
            }
            return Some(*tok);
        }
    }
    None
}

/// Render a token stream back to canonical BASIC text.
pub fn detokenize(tokens: &[TokenInstance]) -> String {
    let mut s = String::new();
    let mut first = true;
    let mut index = 0;
    while index < tokens.len() {
        if !first {
            // Avoid adding a separator before a colon (it would re-enter DATA
            // payloads on round-trip) and before an empty DATA payload.
            if !matches!(tokens.get(index), Some(TokenInstance::Colon))
                && !matches!(
                    tokens.get(index),
                    Some(TokenInstance::Data(txt)) if txt.is_empty()
                )
            {
                s.push(' ');
            }
        }
        let compound = match (tokens.get(index), tokens.get(index + 1)) {
            (
                Some(TokenInstance::Keyword(Token::Less)),
                Some(TokenInstance::Keyword(Token::Equal)),
            ) => Some("<="),
            (
                Some(TokenInstance::Keyword(Token::Less)),
                Some(TokenInstance::Keyword(Token::Greater)),
            ) => Some("<>"),
            (
                Some(TokenInstance::Keyword(Token::Greater)),
                Some(TokenInstance::Keyword(Token::Equal)),
            ) => Some(">="),
            _ => None,
        };
        if let Some(text) = compound {
            s.push_str(text);
            index += 2;
            first = false;
            continue;
        }

        match &tokens[index] {
            TokenInstance::Keyword(tok) => s.push_str(tok.to_text()),
            TokenInstance::Number(n) => s.push_str(&n.to_string()),
            TokenInstance::Real(number) => s.push_str(number),
            TokenInstance::Ident(name) => s.push_str(name),
            TokenInstance::String(txt) => {
                s.push('"');
                s.push_str(&txt.replace('"', "\"\""));
                s.push('"');
            }
            TokenInstance::Rem(txt) => {
                s.push_str("REM ");
                s.push_str(txt);
            }
            TokenInstance::Data(txt) => {
                s.push_str(txt);
            }
            TokenInstance::Colon => s.push(':'),
            TokenInstance::Comma => s.push(','),
            TokenInstance::Semicolon => s.push(';'),
            TokenInstance::LParen => s.push('('),
            TokenInstance::RParen => s.push(')'),
            TokenInstance::LBrace => s.push('{'),
            TokenInstance::RBrace => s.push('}'),
            TokenInstance::Hash => s.push('#'),
            TokenInstance::IntegerDiv => s.push('\\'),
            TokenInstance::StoreArrow => s.push('→'),
        }
        index += 1;
        first = false;
    }
    s
}

/// Encode a token stream to bytes, using the original Microsoft BASIC token
/// codes for keywords and ASCII for literals.  This is intentionally a simple
/// serialisation: numbers are wrapped in `[`/`]`, identifiers are `I`-prefixed
/// and NUL-terminated, and strings/DATA payloads are length-prefixed.
pub fn encode(tokens: &[TokenInstance]) -> Vec<u8> {
    let mut out = Vec::new();
    for t in tokens {
        match t {
            TokenInstance::Keyword(tok) => {
                let code = *tok as u16;
                if code <= u16::from(u8::MAX) {
                    out.push(code as u8);
                } else {
                    out.push(0x01);
                    out.extend_from_slice(&code.to_be_bytes());
                }
            }
            TokenInstance::Number(n) => {
                out.push(b'[');
                out.extend_from_slice(n.to_string().as_bytes());
                out.push(b']');
            }
            TokenInstance::Real(number) => {
                out.push(b'[');
                out.extend_from_slice(number.as_bytes());
                out.push(b']');
            }
            TokenInstance::Ident(name) => {
                out.push(b'I');
                out.extend_from_slice(name.as_bytes());
                out.push(0);
            }
            TokenInstance::String(txt) => {
                out.push(b'S');
                out.extend_from_slice(txt.len().to_string().as_bytes());
                out.push(b':');
                out.extend_from_slice(txt.as_bytes());
            }
            TokenInstance::Rem(txt) => {
                out.push(Token::Rem.to_byte());
                out.extend_from_slice(txt.as_bytes());
                out.push(0);
            }
            TokenInstance::Data(txt) => {
                out.push(b'D');
                out.extend_from_slice(txt.len().to_string().as_bytes());
                out.push(b':');
                out.extend_from_slice(txt.as_bytes());
            }
            TokenInstance::Colon => out.push(b':'),
            TokenInstance::Comma => out.push(b','),
            TokenInstance::Semicolon => out.push(b';'),
            TokenInstance::LParen => out.push(b'('),
            TokenInstance::RParen => out.push(b')'),
            TokenInstance::LBrace => out.push(b'{'),
            TokenInstance::RBrace => out.push(b'}'),
            TokenInstance::Hash => out.push(b'#'),
            TokenInstance::IntegerDiv => out.push(b'\\'),
            TokenInstance::StoreArrow => out.extend_from_slice(b"->"),
        }
    }
    out
}

/// Decode a byte stream produced by [`encode`] back into token instances.
pub fn decode(bytes: &[u8]) -> Result<Vec<TokenInstance>, Error> {
    decode_with_limit(bytes, usize::MAX)
}

/// Decode at most `max_tokens`, rejecting the stream before another token is
/// allocated once that quota has been reached.
pub(crate) fn decode_with_limit(
    bytes: &[u8],
    max_tokens: usize,
) -> Result<Vec<TokenInstance>, Error> {
    let mut out = Vec::new();
    out.try_reserve(bytes.len().min(max_tokens))
        .map_err(|_| Error::ProgramTokenLimitExceeded { limit: max_tokens })?;
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b == 0x01 {
            let payload = bytes
                .get(i + 1..i + 3)
                .ok_or_else(|| Error::syntax("truncated encoded extension token"))?;
            let code = u16::from_be_bytes([payload[0], payload[1]]);
            let token = Token::from_code(code)
                .ok_or_else(|| Error::syntax(format!("unknown extension token 0x{code:04X}")))?;
            push_decoded_token(&mut out, TokenInstance::Keyword(token), max_tokens)?;
            i += 3;
            continue;
        }
        if let Some(tok) = Token::from_byte(b) {
            if tok == Token::Rem {
                // REM text runs until NUL.
                let start = i + 1;
                let end = bytes[start..]
                    .iter()
                    .position(|&x| x == 0)
                    .map(|p| start + p)
                    .unwrap_or(bytes.len());
                let txt = String::from_utf8_lossy(&bytes[start..end]).into_owned();
                push_decoded_token(&mut out, TokenInstance::Rem(txt), max_tokens)?;
                i = end + 1;
                continue;
            }
            push_decoded_token(&mut out, TokenInstance::Keyword(tok), max_tokens)?;
            i += 1;
            continue;
        }
        match b {
            b'[' => {
                let end = bytes[i + 1..]
                    .iter()
                    .position(|x| *x == b']')
                    .map(|p| i + 1 + p)
                    .ok_or_else(|| Error::syntax("unterminated encoded number"))?;
                let digits = std::str::from_utf8(&bytes[i + 1..end])
                    .map_err(|_| Error::syntax("invalid encoded number"))?;
                if digits.contains(['.', 'e', 'E']) {
                    BasicReal::parse(digits)?;
                    push_decoded_token(
                        &mut out,
                        TokenInstance::Real(digits.to_string()),
                        max_tokens,
                    )?;
                } else {
                    let n: i64 = digits
                        .parse()
                        .map_err(|_| Error::syntax(format!("bad encoded number {digits}")))?;
                    push_decoded_token(&mut out, TokenInstance::Number(n), max_tokens)?;
                }
                i = end + 1;
            }
            b'I' => {
                let end = bytes[i + 1..]
                    .iter()
                    .position(|x| *x == 0)
                    .map(|p| i + 1 + p)
                    .unwrap_or(bytes.len());
                let name = String::from_utf8_lossy(&bytes[i + 1..end]).into_owned();
                push_decoded_token(&mut out, TokenInstance::Ident(name), max_tokens)?;
                i = end + 1;
            }
            b'"' => {
                let end = bytes[i + 1..]
                    .iter()
                    .position(|x| *x == b'"')
                    .map(|p| i + 1 + p)
                    .ok_or_else(|| Error::syntax("unterminated encoded string"))?;
                let txt = String::from_utf8_lossy(&bytes[i + 1..end]).into_owned();
                push_decoded_token(&mut out, TokenInstance::String(txt), max_tokens)?;
                i = end + 1;
            }
            b'S' => {
                // Length-prefixed UTF-8 string payload. This permits embedded
                // quote characters without making the token stream ambiguous.
                let colon = bytes[i + 1..]
                    .iter()
                    .position(|&x| x == b':')
                    .map(|p| i + 1 + p)
                    .ok_or_else(|| Error::syntax("invalid encoded string payload"))?;
                let len_str = std::str::from_utf8(&bytes[i + 1..colon])
                    .map_err(|_| Error::syntax("invalid encoded string length"))?;
                let len: usize = len_str
                    .parse()
                    .map_err(|_| Error::syntax(format!("bad encoded string length {len_str}")))?;
                let start = colon + 1;
                let end = start
                    .checked_add(len)
                    .ok_or_else(|| Error::syntax("encoded string length overflow"))?;
                if end > bytes.len() {
                    return Err(Error::syntax("encoded string payload truncated"));
                }
                let txt = std::str::from_utf8(&bytes[start..end])
                    .map_err(|_| Error::syntax("invalid encoded UTF-8 string"))?
                    .to_string();
                push_decoded_token(&mut out, TokenInstance::String(txt), max_tokens)?;
                i = end;
            }
            b'D' => {
                // Length-prefixed DATA payload: decimal length, then ':', then bytes.
                let colon = bytes[i + 1..]
                    .iter()
                    .position(|&x| x == b':')
                    .map(|p| i + 1 + p)
                    .ok_or_else(|| Error::syntax("invalid encoded DATA payload"))?;
                let len_str = std::str::from_utf8(&bytes[i + 1..colon])
                    .map_err(|_| Error::syntax("invalid encoded DATA length"))?;
                let len: usize = len_str
                    .parse()
                    .map_err(|_| Error::syntax(format!("bad encoded DATA length {len_str}")))?;
                let start = colon + 1;
                let end = start
                    .checked_add(len)
                    .ok_or_else(|| Error::syntax("encoded DATA length overflow"))?;
                if end > bytes.len() {
                    return Err(Error::syntax("encoded DATA payload truncated"));
                }
                let txt = String::from_utf8_lossy(&bytes[start..end]).into_owned();
                push_decoded_token(&mut out, TokenInstance::Data(txt), max_tokens)?;
                i = end;
            }
            b':' => {
                push_decoded_token(&mut out, TokenInstance::Colon, max_tokens)?;
                i += 1;
            }
            b',' => {
                push_decoded_token(&mut out, TokenInstance::Comma, max_tokens)?;
                i += 1;
            }
            b';' => {
                push_decoded_token(&mut out, TokenInstance::Semicolon, max_tokens)?;
                i += 1;
            }
            b'(' => {
                push_decoded_token(&mut out, TokenInstance::LParen, max_tokens)?;
                i += 1;
            }
            b')' => {
                push_decoded_token(&mut out, TokenInstance::RParen, max_tokens)?;
                i += 1;
            }
            b'{' => {
                push_decoded_token(&mut out, TokenInstance::LBrace, max_tokens)?;
                i += 1;
            }
            b'}' => {
                push_decoded_token(&mut out, TokenInstance::RBrace, max_tokens)?;
                i += 1;
            }
            b'#' => {
                push_decoded_token(&mut out, TokenInstance::Hash, max_tokens)?;
                i += 1;
            }
            b'\\' => {
                push_decoded_token(&mut out, TokenInstance::IntegerDiv, max_tokens)?;
                i += 1;
            }
            b'-' if bytes.get(i + 1) == Some(&b'>') => {
                push_decoded_token(&mut out, TokenInstance::StoreArrow, max_tokens)?;
                i += 2;
            }
            _ => return Err(Error::UnknownToken(b)),
        }
    }
    Ok(out)
}

fn push_decoded_token(
    output: &mut Vec<TokenInstance>,
    token: TokenInstance,
    max_tokens: usize,
) -> Result<(), Error> {
    if output.len() >= max_tokens {
        return Err(Error::ProgramTokenLimitExceeded { limit: max_tokens });
    }
    if output.len() == output.capacity() {
        output
            .try_reserve(1)
            .map_err(|_| Error::ProgramTokenLimitExceeded { limit: max_tokens })?;
    }
    output.push(token);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn token_round_trip() {
        let line = "10 PRINT \"HELLO, WORLD\"";
        let tokens = tokenize(line).unwrap();
        let text = detokenize(&tokens);
        let again = tokenize(&text).unwrap();
        assert_eq!(tokens, again);

        let bytes = encode(&tokens);
        let decoded = decode(&bytes).unwrap();
        assert_eq!(tokens, decoded);
    }

    #[test]
    fn bounded_decode_stops_before_excess_token_allocation() {
        assert_eq!(
            decode_with_limit(b",,,", 2).unwrap_err(),
            Error::ProgramTokenLimitExceeded { limit: 2 }
        );
    }

    #[test]
    fn every_statement_token_has_an_inverse_text_mapping() {
        let statements = [
            Token::End,
            Token::For,
            Token::Next,
            Token::Data,
            Token::Input,
            Token::Dim,
            Token::Read,
            Token::Let,
            Token::Goto,
            Token::Run,
            Token::If,
            Token::Restore,
            Token::Gosub,
            Token::Return,
            Token::Rem,
            Token::Stop,
            Token::On,
            Token::Wait,
            Token::Load,
            Token::Save,
            Token::Def,
            Token::Poke,
            Token::Print,
            Token::Cont,
            Token::List,
            Token::Clear,
            Token::Get,
            Token::New,
            Token::InputFile,
            Token::PrintFile,
            Token::Open,
            Token::Close,
            Token::GetFile,
            Token::Verify,
            Token::Cmd,
            Token::Sys,
            Token::Mat,
            Token::While,
            Token::Wend,
            Token::Swap,
            Token::WriteStmt,
            Token::Randomize,
            Token::OptionBase,
            Token::Width,
            Token::Kill,
            Token::Name,
            Token::Tron,
            Token::Troff,
            Token::DefType,
            Token::Erase,
            Token::LineInput,
            Token::Lprint,
            Token::Using,
            Token::Renum,
            Token::Resume,
            Token::Llist,
            Token::Delete,
            Token::Field,
            Token::Lset,
            Token::Rset,
            Token::Null,
            Token::Edit,
            Token::Auto,
            Token::Call,
            Token::ErrorStmt,
            Token::Out,
            Token::Put,
        ];
        for token in statements {
            assert_eq!(
                Token::from_text(token.to_text()),
                Some(token),
                "missing inverse mapping for {}",
                token.to_text()
            );
        }
    }

    #[test]
    fn ti_graph_identifiers_and_store_arrow_round_trip() {
        let ascii = tokenize("10 \"SIN(X)\"->Y1:PXL-ON(2,3,11)").unwrap();
        assert!(ascii.contains(&TokenInstance::StoreArrow));
        assert!(ascii.contains(&TokenInstance::Ident("PXL-ON".into())));
        let canonical = detokenize(&ascii);
        assert!(canonical.contains('→'));
        assert_eq!(decode(&encode(&ascii)).unwrap(), ascii);

        let unicode = tokenize("10 \"COS(X)\"→Y2").unwrap();
        assert!(unicode.contains(&TokenInstance::StoreArrow));
    }

    #[test]
    fn print_format_tokens_accept_arguments_starting_with_digits() {
        let tokens = tokenize("10 PRINT SPC(2);TAB(12)").unwrap();
        assert!(tokens
            .iter()
            .any(|token| matches!(token, TokenInstance::Keyword(Token::Spc))));
        assert!(tokens
            .iter()
            .any(|token| matches!(token, TokenInstance::Keyword(Token::Tab))));
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
    }

    #[test]
    fn direct_control_command_tokens_are_source_recognized_and_round_trip() {
        let tokens = tokenize("10 RUN 20:STOP:CONT:LIST 10-30:NEW").unwrap();
        for keyword in [
            Token::Run,
            Token::Stop,
            Token::Cont,
            Token::List,
            Token::New,
        ] {
            assert!(tokens.contains(&TokenInstance::Keyword(keyword)));
        }
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
    }

    #[test]
    fn compact_user_function_names_reserve_and_round_trip_the_fn_prefix() {
        let tokens =
            tokenize("10 DEF FNSQUARE(X)=X*X:DEF FNCUBE(X)=X*X*X:PRINT FNSQUARE(4),FNCUBE(3)")
                .unwrap();
        let fn_count = tokens
            .iter()
            .filter(|token| matches!(token, TokenInstance::Keyword(Token::Fn)))
            .count();
        assert_eq!(fn_count, 4);
        assert!(!tokens
            .iter()
            .any(|token| matches!(token, TokenInstance::Ident(name) if name == "FNSQUARE")));
        assert!(tokens
            .iter()
            .any(|token| matches!(token, TokenInstance::Ident(name) if name == "CUBE")));
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
    }

    #[test]
    fn out_and_put_are_boundary_aware_without_splitting_output() {
        let output = tokenize(r#"10 OPEN "X" FOR OUTPUT AS #1"#).unwrap();
        assert!(output
            .iter()
            .any(|token| matches!(token, TokenInstance::Ident(name) if name == "OUTPUT")));
        assert!(!output.contains(&TokenInstance::Keyword(Token::Out)));

        let out = tokenize("20 OUT77,42").unwrap();
        assert!(out.contains(&TokenInstance::Keyword(Token::Out)));
        let put = tokenize("30 PUT#1,2").unwrap();
        assert!(put.contains(&TokenInstance::Keyword(Token::Put)));
    }

    #[test]
    fn classic_compact_syntax_tokenizes_without_spaces() {
        let compact = tokenize("10 IFA=1THENPRINTA:GOTO100:FORI=1TO10:PRINTI:NEXTI").unwrap();
        let spaced =
            tokenize("10 IF A=1 THEN PRINT A:GOTO 100:FOR I=1 TO 10:PRINT I:NEXT I").unwrap();
        assert_eq!(compact, spaced);
        for token in [
            Token::If,
            Token::Then,
            Token::Print,
            Token::Goto,
            Token::For,
            Token::To,
            Token::Next,
        ] {
            assert!(
                compact.contains(&TokenInstance::Keyword(token)),
                "{token:?}"
            );
        }
    }

    #[test]
    fn microsoft_type_suffixes_remain_part_of_identifiers() {
        let tokens = tokenize(r#"10 A%=1:B&=2:C!=3:D#=4:E$="X""#).unwrap();
        for name in ["A%", "B&", "C!", "D#", "E$"] {
            assert!(tokens
                .iter()
                .any(|token| matches!(token, TokenInstance::Ident(found) if found == name)));
        }
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
    }

    #[test]
    fn apostrophe_comments_and_doubled_quotes_round_trip() {
        let tokens = tokenize(r#"10 PRINT "HE SAID ""HELLO""":' COMMENT"#).unwrap();
        assert!(tokens.iter().any(
            |token| matches!(token, TokenInstance::String(value) if value == r#"HE SAID "HELLO""#)
        ));
        assert!(tokens
            .iter()
            .any(|token| matches!(token, TokenInstance::Rem(value) if value == "COMMENT")));
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
    }

    #[test]
    fn native_statements_use_compact_classic_matching() {
        let tokens = tokenize(r#"10 COMMONA,B$:CHAIN"NEXT.BAS":MERGE"LIB.BAS""#).unwrap();
        for name in ["COMMON", "CHAIN", "MERGE"] {
            assert!(tokens
                .iter()
                .any(|token| matches!(token, TokenInstance::Ident(found) if found == name)));
        }
        assert!(tokens
            .iter()
            .any(|token| matches!(token, TokenInstance::Ident(found) if found == "A")));
    }

    #[test]
    fn text_terminal_statements_remain_identifier_encoded() {
        for (source, expected) in [
            ("10 LOCATE 2,3", "LOCATE"),
            ("20 VIEW PRINT 2 TO 20", "VIEW"),
            ("30 HOME", "HOME"),
            ("40 HTAB 4", "HTAB"),
            ("50 VTAB 5", "VTAB"),
            ("60 SLEEP .1", "SLEEP"),
            ("70 TEXTCOLOR 10,0", "TEXTCOLOR"),
        ] {
            let tokens = tokenize(source).unwrap();
            assert!(tokens
                .iter()
                .any(|token| matches!(token, TokenInstance::Ident(name) if name == expected)));
            assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        }
    }

    #[test]
    fn modern_declaration_statements_round_trip_as_extension_identifiers() {
        for source in [
            "10 REDIM PRESERVE A(20),B$(30)",
            r#"20 CONST LIMIT=20,TITLE$="MODERN""#,
            "30 SUB UPDATE(BYREF N,BYVAL SCALE,BYREF VALUES()):SHARED TOTAL:STATIC CALLS,CACHE(4):END SUB",
            "40 FUNCTION DOUBLE(BYREF N):DOUBLE=N*2:END FUNCTION",
            "50 TYPE PERSON:FULLNAME AS STRING:AGE AS INTEGER:END TYPE",
            r#"60 DIM P AS PERSON:P.FULLNAME="ADA":PRINT P.FULLNAME"#,
            "70 DIM PEOPLE(10) AS PERSON:PEOPLE(2).AGE=42:PRINT PEOPLE(2).AGE",
        ] {
            let tokens = tokenize(source).unwrap();
            assert_eq!(decode(&encode(&tokens)).unwrap(), tokens, "{source}");
            assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens, "{source}");
        }
    }

    #[test]
    fn native_file_extension_tokens_round_trip_without_renumbering_core_tokens() {
        let tokens = tokenize(
            r#"10 OPEN 1,"data.txt","WRITE":PRINT# 1,"OK":CLOSE 1:INPUT# 2,A:GET# 2,A$:VERIFY "copy.bas":CMD 1:SYS 1"#,
        )
        .unwrap();
        assert!(tokens.contains(&TokenInstance::Keyword(Token::Open)));
        assert!(tokens.contains(&TokenInstance::Keyword(Token::PrintFile)));
        assert!(tokens.contains(&TokenInstance::Keyword(Token::Close)));
        assert!(tokens.contains(&TokenInstance::Keyword(Token::InputFile)));
        assert!(tokens.contains(&TokenInstance::Keyword(Token::GetFile)));
        assert!(tokens.contains(&TokenInstance::Keyword(Token::Verify)));
        assert!(tokens.contains(&TokenInstance::Keyword(Token::Cmd)));
        assert!(tokens.contains(&TokenInstance::Keyword(Token::Sys)));
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
        assert_eq!(Token::Go.to_byte(), 0xC4);
        assert_eq!(Token::InputFile.to_byte(), 0xC5);
        assert_eq!(Token::GetFile.to_byte(), 0xC9);
        assert_eq!(Token::Verify.to_byte(), 0xCA);
        assert_eq!(Token::Sys.to_byte(), 0xCC);
        assert_eq!(Token::Mat.to_byte(), 0xCD);
    }

    #[test]
    fn binary_program_and_compile_statements_remain_identifier_encoded() {
        for (source, expected) in [
            (r#"10 LOADB "program.m64b""#, "LOADB"),
            (r#"20 SAVEB "program.m64b""#, "SAVEB"),
            (r#"30 COMPILE "program""#, "COMPILE"),
        ] {
            let tokens = tokenize(source).unwrap();
            assert!(
                matches!(tokens.get(1), Some(TokenInstance::Ident(name)) if name == expected),
                "{source}: {tokens:?}"
            );
            assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
            assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
        }
    }

    #[test]
    fn extension_statement_names_remain_whole_assignment_identifiers() {
        for name in [
            "COMPILE", "LOADB", "SAVEB", "LPRINT", "STRIG", "PEN", "FORMAT$",
        ] {
            let source = format!("10 {name}=1");
            let tokens = tokenize(&source).unwrap();
            assert!(
                matches!(tokens.get(1), Some(TokenInstance::Ident(found)) if found == name),
                "{source}: {tokens:?}"
            );
            assert!(matches!(
                tokens.get(2),
                Some(TokenInstance::Keyword(Token::Equal))
            ));
        }
    }

    #[test]
    fn dartmouth_mat_token_round_trips_as_an_appended_extension() {
        let tokens = tokenize("10 MAT C=TRN(A):MAT PRINT C;").unwrap();
        assert!(tokens.contains(&TokenInstance::Keyword(Token::Mat)));
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
        assert_eq!(Token::Sys.to_byte(), 0xCC);
        assert_eq!(Token::Mat.to_byte(), 0xCD);
    }

    #[test]
    fn ti_basic_scalar_function_tokens_round_trip_as_extensions() {
        let tokens = tokenize(
            "10 X=ROUND(FPART(3.25),1):Y=IPART(X):PRINT MIN(X,Y),MAX(X,Y),LCM(6,8),GCD(18,12),REMAINDER(17,5)",
        )
        .unwrap();
        for token in [
            Token::Round,
            Token::Fpart,
            Token::Ipart,
            Token::Min,
            Token::Max,
            Token::Lcm,
            Token::Gcd,
            Token::Remainder,
        ] {
            assert!(tokens.contains(&TokenInstance::Keyword(token)));
        }
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
        assert_eq!(Token::Mat.to_byte(), 0xCD);
        assert_eq!(Token::Round.to_byte(), 0xCE);
        assert_eq!(Token::Remainder.to_byte(), 0xD5);
        assert_eq!(Token::Mod.to_byte(), 0xD6);
    }

    #[test]
    fn mod_operator_and_integer_suffix_are_unambiguous() {
        let named = tokenize("10 X=17 MOD 5:A%=17").unwrap();
        assert!(named.contains(&TokenInstance::Keyword(Token::Mod)));
        assert!(named
            .iter()
            .any(|token| matches!(token, TokenInstance::Ident(name) if name == "A%")));
        assert_eq!(tokenize(&detokenize(&named)).unwrap(), named);
        assert!(tokenize("10 X=17%5").is_err());
    }

    #[test]
    fn extended_ti_scalar_math_tokens_round_trip() {
        let tokens = tokenize(
            "10 X=ASIN(1)+ACOS(1)+SINH(0)+COSH(0)+TANH(0)+ASINH(0)+ACOSH(1)+ATANH(0):Y=LN(1)+LOG10(10)+LOGBASE(8,2)+CBRT(8)+ROOT(16,2)+CUBE(2):Z=FACT(5)+NPR(5,2)+5 NPR 2+NCR(5,2)+5 NCR 2+DEG(PI())+RAD(180)+RAND()+RANDINT(1,2)+RANDNORM(0,1)+RANDBIN(2,.5)",
        )
        .unwrap();
        for token in [
            Token::Asin,
            Token::Acos,
            Token::Sinh,
            Token::Cosh,
            Token::Tanh,
            Token::Asinh,
            Token::Acosh,
            Token::Atanh,
            Token::Ln,
            Token::Log10,
            Token::LogBase,
            Token::Cbrt,
            Token::Root,
            Token::Cube,
            Token::Fact,
            Token::Npr,
            Token::Ncr,
            Token::Deg,
            Token::Rad,
            Token::Pi,
            Token::Rand,
            Token::RandInt,
            Token::RandNorm,
            Token::RandBin,
        ] {
            assert!(tokens.contains(&TokenInstance::Keyword(token)), "{token:?}");
        }
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
        assert_eq!(Token::Asin.to_byte(), 0xD7);
        assert_eq!(Token::RandBin.to_byte(), 0xEF);
    }

    #[test]
    fn pi_function_does_not_reserve_the_classic_pi_variable() {
        assert!(matches!(
            tokenize("10 PI=4*ATN(1)").unwrap().get(1),
            Some(TokenInstance::Ident(name)) if name == "PI"
        ));
        assert!(tokenize("10 X=PI()")
            .unwrap()
            .contains(&TokenInstance::Keyword(Token::Pi)));
    }

    #[test]
    fn bounded_ti_numerical_function_tokens_round_trip() {
        let tokens = tokenize(
            "10 A=FMIN((X-2)^2,X,-5,5):B=FMAX(-X^2,X,-5,5):C=NDERIV(X^2,X,3):D=FNINT(X^2,X,0,3):E=SUM(X,X,1,3):F=SOLVE(X^2-2,X,0,2):G=PIECEWISE(A<0,-1,A>0,1,0)",
        )
        .unwrap();
        for token in [
            Token::Fmin,
            Token::Fmax,
            Token::Nderiv,
            Token::Fnint,
            Token::Sum,
            Token::Solve,
            Token::Piecewise,
        ] {
            assert!(tokens.contains(&TokenInstance::Keyword(token)), "{token:?}");
        }
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
        assert_eq!(Token::Fmin.to_byte(), 0xF0);
        assert_eq!(Token::Piecewise.to_byte(), 0xF6);
    }

    #[test]
    fn ti_complex_list_and_probability_extensions_round_trip() {
        let tokens = tokenize(
            "10 A={1,2,COMPLEX(3,4)}:B$=FRAC$(1/3):C=REAL(A(3))+IMAG(A(3))+CONJ(A(3))+ANGLE(A(3)):D=RANDINTNOREP(1,9,3):E=MEAN(A)+MEDIAN(A)",
        )
        .unwrap();
        for token in [
            Token::FracString,
            Token::Complex,
            Token::RealPart,
            Token::Imag,
            Token::Conj,
            Token::Angle,
            Token::RandIntNoRep,
            Token::Mean,
            Token::Median,
        ] {
            assert!(tokens.contains(&TokenInstance::Keyword(token)), "{token:?}");
        }
        assert!(tokens.contains(&TokenInstance::LBrace));
        assert!(tokens.contains(&TokenInstance::RBrace));
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
        assert_eq!(Token::FracString.to_byte(), 0xF7);
        assert_eq!(Token::Median.to_byte(), 0xFF);
        assert!(matches!(
            tokenize("10 REAL=7").unwrap().get(1),
            Some(TokenInstance::Ident(name)) if name == "REAL"
        ));
    }

    #[test]
    fn named_math_calls_are_not_split_by_compact_keyword_matching() {
        for (source, expected) in [
            ("10 A=TOTAL({1,2,3})", "TOTAL"),
            ("20 A=MODE({1,1,2})", "MODE"),
            ("30 A=EXP2(8)", "EXP2"),
            ("40 A=LOG2(8)", "LOG2"),
            ("50 A=NEXTPRIME(100)", "NEXTPRIME"),
            ("60 A=LINSPACE(0,1,5)", "LINSPACE"),
            ("70 A=CIRCLEAREA(2)", "CIRCLEAREA"),
            ("80 A=TOPOLAR(3,4)", "TOPOLAR"),
            ("90 A=SOLVELINEAR({{2,1},{1,3}},{5,6})", "SOLVELINEAR"),
        ] {
            let tokens = tokenize(source).unwrap();
            assert!(
                tokens
                    .iter()
                    .any(|token| matches!(token, TokenInstance::Ident(name) if name == expected)),
                "{source}"
            );
            assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens, "{source}");
        }
    }

    #[test]
    fn variable_names_are_not_split_at_reserved_prefixes() {
        let source = "10 TOTAL=1:TOTALPOP=2:MAXENT=3:FREQSUM=4:STARVED=5";
        let tokens = tokenize(source).unwrap();
        for name in ["TOTAL", "TOTALPOP", "MAXENT", "FREQSUM", "STARVED"] {
            assert!(tokens
                .iter()
                .any(|token| matches!(token, TokenInstance::Ident(found) if found == name)));
        }
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);

        let compact = tokenize("20 IFA=1THENPRINTA:FORI=1TO2:NEXTI").unwrap();
        for token in [
            Token::If,
            Token::Then,
            Token::Print,
            Token::For,
            Token::To,
            Token::Next,
        ] {
            assert!(
                compact.contains(&TokenInstance::Keyword(token)),
                "{token:?}"
            );
        }

        let print_functions = tokenize("30 PRINT SPC(2);TAB(12)").unwrap();
        assert!(print_functions.contains(&TokenInstance::Keyword(Token::Spc)));
        assert!(print_functions.contains(&TokenInstance::Keyword(Token::Tab)));
    }

    #[test]
    fn call_procedure_names_are_not_split_at_reserved_prefixes() {
        let source = "10 CALL SCALEALL(A()):CALL FORWARD(A(),1):CALL MODIFY";
        let tokens = tokenize(source).unwrap();
        for name in ["SCALEALL", "FORWARD", "MODIFY"] {
            assert!(
                tokens
                    .iter()
                    .any(|token| matches!(token, TokenInstance::Ident(found) if found == name)),
                "{name}: {tokens:?}"
            );
        }
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
    }

    #[test]
    fn nested_record_fields_preserve_qualified_identifiers_and_round_trip() {
        let tokens = tokenize("10 P.HOME.POS.X=R(2).HOME.POS.X").unwrap();
        for name in ["P.HOME.POS.X", "R.HOME.POS.X"] {
            assert!(
                tokens
                    .iter()
                    .any(|token| matches!(token, TokenInstance::Ident(found) if found == name)),
                "{name}: {tokens:?}"
            );
        }
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);
    }

    #[test]
    fn deterministic_ascii_stress_corpus_never_breaks_binary_round_trip() {
        const ALPHABET: &[u8] =
            b" ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-*/^=<>(){},:;.$!?_\\\"'";
        let mut state = 0x4d59_5df4_d0f3_3173_u64;
        for case in 0..20_000 {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            let length = (state as usize % 96) + 1;
            let mut source = String::with_capacity(length);
            for _ in 0..length {
                state ^= state << 13;
                state ^= state >> 7;
                state ^= state << 17;
                source.push(ALPHABET[state as usize % ALPHABET.len()] as char);
            }
            if let Ok(tokens) = tokenize(&source) {
                let encoded = encode(&tokens);
                let decoded = decode(&encoded).unwrap_or_else(|error| {
                    panic!("stress case {case}, source {source:?}, encoded {encoded:?}: {error}")
                });
                assert_eq!(decoded, tokens, "stress case {case}, source {source:?}");
            }
        }
    }

    #[test]
    fn decimal_and_exponent_literals_round_trip() {
        let tokens = tokenize("10 X=.5+1.25E+2").unwrap();
        assert_eq!(
            tokens,
            vec![
                TokenInstance::Number(10),
                TokenInstance::Ident("X".to_string()),
                TokenInstance::Keyword(Token::Equal),
                TokenInstance::Real(".5".to_string()),
                TokenInstance::Keyword(Token::Plus),
                TokenInstance::Real("1.25E+2".to_string()),
            ]
        );
        assert_eq!(decode(&encode(&tokens)).unwrap(), tokens);
        assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens);

        assert_eq!(
            tokenize("1.5").unwrap(),
            vec![TokenInstance::Real("1.5".to_string())]
        );
    }

    #[test]
    fn malformed_or_nonfinite_real_literals_are_rejected() {
        assert!(matches!(tokenize("1E"), Err(Error::Syntax { .. })));
        assert_eq!(tokenize("1E999").unwrap_err(), Error::RealOverflow);
    }

    #[test]
    fn rem_preserves_text() {
        let line = "20 REM this is a comment";
        let tokens = tokenize(line).unwrap();
        assert_eq!(
            tokens,
            vec![
                TokenInstance::Number(20),
                TokenInstance::Rem("this is a comment".to_string()),
            ]
        );
        let text = detokenize(&tokens);
        assert_eq!(text, "20 REM this is a comment");
    }

    #[test]
    fn compound_relations_round_trip_canonically() {
        for line in [
            "10 IF A<=B THEN 20",
            "10 IF A>=B THEN 20",
            "10 IF A<>B THEN 20",
        ] {
            let tokens = tokenize(line).unwrap();
            let listed = detokenize(&tokens);
            assert!(listed.contains(
                ["<=", ">=", "<>"]
                    .into_iter()
                    .find(|operator| line.contains(operator))
                    .unwrap()
            ));
            assert_eq!(tokenize(&listed).unwrap(), tokens);
        }
    }

    #[test]
    fn data_payload_is_not_keyword_tokenized() {
        let tokens = tokenize("10 DATA FOR, NEXT, 123").unwrap();
        assert_eq!(
            tokens,
            vec![
                TokenInstance::Number(10),
                TokenInstance::Keyword(Token::Data),
                TokenInstance::Data("FOR, NEXT, 123".to_string()),
            ]
        );
    }

    #[test]
    fn data_quoted_comma_and_colon_are_preserved() {
        let line = r#"10 DATA "A,B", "C:D": PRINT 1"#;
        let tokens = tokenize(line).unwrap();
        assert_eq!(
            tokens,
            vec![
                TokenInstance::Number(10),
                TokenInstance::Keyword(Token::Data),
                TokenInstance::Data(r#""A,B", "C:D""#.to_string()),
                TokenInstance::Colon,
                TokenInstance::Keyword(Token::Print),
                TokenInstance::Number(1),
            ]
        );
    }

    #[test]
    fn bare_data_round_trip() {
        let line = "10 DATA";
        let tokens = tokenize(line).unwrap();
        let text = detokenize(&tokens);
        assert_eq!(text, "10 DATA");
        assert_eq!(tokenize(&text).unwrap(), tokens);

        let bytes = encode(&tokens);
        assert_eq!(decode(&bytes).unwrap(), tokens);
    }

    #[test]
    fn data_payload_round_trip() {
        let line = r#"10 DATA "HELLO, WORLD", 42: PRINT X"#;
        let tokens = tokenize(line).unwrap();
        let text = detokenize(&tokens);
        let again = tokenize(&text).unwrap();
        assert_eq!(tokens, again);

        let bytes = encode(&tokens);
        let decoded = decode(&bytes).unwrap();
        assert_eq!(tokens, decoded);
    }

    #[test]
    fn encoded_data_length_overflow_is_rejected() {
        let bytes = format!("D{}:", usize::MAX).into_bytes();
        let error = decode(&bytes).unwrap_err();
        assert!(matches!(error, Error::Syntax { .. }));
    }
    #[test]
    fn ti_graph_statement_names_are_not_split_by_classic_prefix_keywords() {
        for (source, expected) in [
            ("10 DRAWF SIN(X),10", "DRAWF"),
            ("20 DRAWINV X^2,13", "DRAWINV"),
            ("30 TANGENT(SIN(X),0,11)", "TANGENT"),
            ("40 CLRDRAW", "CLRDRAW"),
            ("50 DISPGRAPH", "DISPGRAPH"),
            ("60 SHADE(-1,1,-3,3,1,1)", "SHADE"),
        ] {
            let tokens = tokenize(source).unwrap();
            assert!(
                matches!(tokens.get(1), Some(TokenInstance::Ident(name)) if name == expected),
                "{source}: {tokens:?}"
            );
            assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens, "{source}");
        }
    }

    #[test]
    fn modernbasic_capability_statements_tokenize_in_compact_numbered_lines() {
        for source in [
            "10 SCREEN13",
            "20 LINE(0,0)-(10,10),15",
            "30 GRAPHWINDOW -10,10,1,-10,10,1",
            "40 TEMPO120",
            "50 WAVE1,SAW",
            r#"60 INSTRUMENT1,"ELECTRIC PIANO 1""#,
            r#"70 SOUNDFONT"soundfont/MuseScore_General.sf2""#,
            "71 EXPRESSION1,.8",
            "72 MODULATION1,.2",
            "73 SUSTAIN1,1",
            "74 PITCHBEND1,-.25",
            "75 REVERB1,.3",
            "76 CHORUS1,.15",
            "77 DSP1,.5,.6,.7,.2,.4",
            r#"78 SING"la-la","C4/4 D4/4""#,
            "80 BUFFER1:FLIP",
            "90 SCREEN GRAPHICS",
            "100 SCREEN SPLIT",
            "110 SCREEN TEXT",
            "120 SCREEN GRAPHICS2D",
            "130 SCREEN GRAPHICS3D",
            "140 PERSPECTIVE 400,300,500,.1,10000,.3",
            r#"150 OBJECT SHAPE TREE,0,0,100,20,50,"GREEN","NONE""#,
            "160 OBJECT MOVE TREE,10,0,120",
            "170 OBJECT SCALE TREE,30,60",
            r#"180 OBJECT LIGHT SUN,0,50,50,1,500,"WHITE""#,
            r#"190 PSET (1,2,30),"WHITE""#,
            r#"200 SPRITE SHIP,(1,2,30),8,12,"RED","NONE""#,
            "210 MOVESPRITE SHIP,3,4,20",
            "220 SPRITEMOTION SHIP,1,2,-3,0,0,1",
        ] {
            let tokens = tokenize(source).unwrap();
            assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens, "{source}");
        }
    }

    #[test]
    fn classic_microsoft_file_channel_syntax_round_trips() {
        for source in [
            r#"10 OPEN F$ FOR OUTPUT AS #1"#,
            r#"20 PRINT #1,"HELLO",42"#,
            r#"30 CLOSE #1"#,
            r#"40 OPEN F$ FOR INPUT AS #1"#,
            r#"50 INPUT #1,A$,B"#,
            r#"60 GET #1,C$"#,
        ] {
            let tokens = tokenize(source).unwrap();
            assert!(tokens.contains(&TokenInstance::Hash), "{source}");
            assert_eq!(decode(&encode(&tokens)).unwrap(), tokens, "{source}");
            assert_eq!(tokenize(&detokenize(&tokens)).unwrap(), tokens, "{source}");
        }
    }
}
