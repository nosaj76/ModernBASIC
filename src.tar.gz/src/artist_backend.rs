//! Internal Artist graphics renderer.
//!
//! The Artist Script renderer is now built into the BASIC binary in pure Rust.
//! No external graphics executable is required: `ArtistBackend` renders through
//! `artist_renderer` in process.

use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use crate::artist_renderer;
use crate::error::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct ArtistBackend;

impl ArtistBackend {
    pub fn new() -> Self {
        Self
    }

    /// Render Artist Script to a file. SVG, PPM, HTML, and JSON are produced
    /// internally; PNG uses an optional host SVG converter.
    pub fn render_output(
        &self,
        artist_source: &str,
        output_path: &Path,
        open_after_render: bool,
    ) -> Result<PathBuf, Error> {
        if output_path.as_os_str().is_empty() {
            return Err(Error::InvalidFilePath);
        }

        let extension = output_path
            .extension()
            .and_then(|value| value.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();

        match extension.as_str() {
            "svg" => {
                let svg = artist_renderer::render_svg(artist_source)?;
                std::fs::write(output_path, svg)?;
            }
            "ppm" => {
                let ppm = artist_renderer::render_ppm(artist_source)?;
                std::fs::write(output_path, ppm)?;
            }
            "png" => {
                let ppm = artist_renderer::render_ppm(artist_source)?;
                if convert_ppm_to_png(&ppm, output_path).is_err() {
                    let svg = artist_renderer::render_svg(artist_source)?;
                    convert_svg_to_png(&svg, output_path)?;
                }
            }
            "html" | "htm" => {
                let svg = artist_renderer::render_svg(artist_source)?;
                let html = format!(
                    "<!DOCTYPE html>\n<html>\n<head><meta charset=\"UTF-8\"></head>\n<body style=\"margin:0;padding:0\">\n{}\n</body>\n</html>",
                    svg
                );
                std::fs::write(output_path, html)?;
            }
            "json" => {
                let svg = artist_renderer::render_svg(artist_source)?;
                let json = format!("{{\"svg\":{}}}", serde_json_quote(&svg));
                std::fs::write(output_path, json)?;
            }
            _ => {
                return Err(Error::syntax(
                    "graphics output must end in .svg, .png, .html, .ppm, or .json",
                ))
            }
        }

        if open_after_render {
            open_rendered_file(output_path)?;
        }
        Ok(output_path.to_path_buf())
    }

    /// Compatibility helper for graphing code that always writes SVG.
    pub fn render_svg(
        &self,
        artist_source: &str,
        svg_path: &Path,
        open_after_render: bool,
    ) -> Result<PathBuf, Error> {
        self.render_output(artist_source, svg_path, open_after_render)
    }

    /// Render Artist Script to an SVG string in memory (no file I/O).
    /// Used by the integrated graphics screen for direct display.
    pub fn render_svg_string(&self, artist_source: &str) -> Result<String, Error> {
        artist_renderer::render_svg(artist_source)
    }
}

fn convert_ppm_to_png(ppm: &[u8], output_path: &Path) -> Result<(), Error> {
    let ffmpeg = crate::image_codec::find_ffmpeg().ok_or_else(|| {
        Error::Io("PNG output requires FFmpeg, Python CairoSVG, or rsvg-convert".into())
    })?;
    let mut command = Command::new(ffmpeg);
    command
        .arg("-nostdin")
        .arg("-loglevel")
        .arg("error")
        .arg("-y")
        .arg("-f")
        .arg("image2pipe")
        .arg("-vcodec")
        .arg("ppm")
        .arg("-i")
        .arg("pipe:0")
        .arg("-frames:v")
        .arg("1")
        .arg("-vcodec")
        .arg("png")
        .arg(output_path)
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    let mut child = command
        .spawn()
        .map_err(|error| Error::Io(format!("cannot start PNG converter: {error}")))?;
    child
        .stdin
        .take()
        .ok_or_else(|| Error::Io("cannot open PNG converter input".into()))?
        .write_all(ppm)?;
    let status = child.wait()?;
    if status.success() && output_path.is_file() {
        Ok(())
    } else {
        Err(Error::Io(format!("PNG converter exited with {status}")))
    }
}
const CAIROSVG_SCRIPT: &str =
    "import sys,cairosvg; cairosvg.svg2png(bytestring=sys.stdin.buffer.read(), write_to=sys.argv[1])";

fn cairosvg_command(output_path: &Path) -> Command {
    let mut command = Command::new("python3");
    command.arg("-c").arg(CAIROSVG_SCRIPT).arg(output_path);
    command
}

fn converter_succeeded(mut command: Command, svg: &str, output_path: &Path) -> bool {
    command
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    let Ok(mut child) = command.spawn() else {
        return false;
    };
    let wrote_input = child
        .stdin
        .take()
        .is_some_and(|mut input| input.write_all(svg.as_bytes()).is_ok());
    let exited_successfully = child.wait().is_ok_and(|status| status.success());
    wrote_input && exited_successfully && output_path.is_file()
}

/// Convert in-memory SVG to a real PNG using an optional host converter.
fn convert_svg_to_png(svg: &str, output_path: &Path) -> Result<(), Error> {
    if converter_succeeded(cairosvg_command(output_path), svg, output_path) {
        return Ok(());
    }

    let mut rsvg = Command::new("rsvg-convert");
    rsvg.arg("--format=png").arg("-o").arg(output_path);
    if converter_succeeded(rsvg, svg, output_path) {
        return Ok(());
    }

    Err(Error::Io(
        "PNG output requires Python CairoSVG or rsvg-convert".to_string(),
    ))
}

fn serde_json_quote(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for ch in s.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c <= '\u{1f}' => {
                let _ =
                    std::fmt::Write::write_fmt(&mut out, format_args!("\\u{:04x}", u32::from(c)));
            }
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

#[cfg(target_os = "windows")]
fn open_rendered_file(path: &Path) -> Result<(), Error> {
    let child = Command::new("cmd")
        .args(["/C", "start", ""])
        .arg(path)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot open rendered graphics: {error}")))?;
    crate::host_process::reap_child(child, "cannot open rendered graphics")
}

#[cfg(target_os = "macos")]
fn open_rendered_file(path: &Path) -> Result<(), Error> {
    let child = Command::new("open")
        .arg(path)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot open rendered graphics: {error}")))?;
    crate::host_process::reap_child(child, "cannot open rendered graphics")
}

#[cfg(all(unix, not(target_os = "macos")))]
fn open_rendered_file(path: &Path) -> Result<(), Error> {
    let child = Command::new("xdg-open")
        .arg(path)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot open rendered graphics: {error}")))?;
    crate::host_process::reap_child(child, "cannot open rendered graphics")
}

#[cfg(not(any(target_os = "windows", target_os = "macos", unix)))]
fn open_rendered_file(_path: &Path) -> Result<(), Error> {
    Err(Error::Io(
        "opening rendered graphics is unsupported on this platform".into(),
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn internal_renderer_produces_svg() {
        let backend = ArtistBackend::new();
        let svg = backend
            .render_svg_string(
                "canvas 400 300 #000000\nline 10 10 100 100 stroke=#ffffff stroke-width=2\n",
            )
            .unwrap();
        assert!(svg.contains("width=\"400\""));
        assert!(svg.contains("<line"));
    }

    #[test]
    fn converter_keeps_output_paths_out_of_python_source() {
        let path = Path::new("x');__import__('os').system('false');#.png");
        let command = cairosvg_command(path);
        let arguments = command.get_args().collect::<Vec<_>>();
        assert_eq!(arguments.len(), 3);
        assert_eq!(arguments[0], "-c");
        assert_eq!(arguments[1], CAIROSVG_SCRIPT);
        assert_eq!(arguments[2], path.as_os_str());
        assert!(!CAIROSVG_SCRIPT.contains("__import__"));
    }

    #[test]
    fn html_json_and_control_character_exports_are_well_formed() {
        use std::sync::atomic::{AtomicU64, Ordering};
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-artist-output-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir(&root).unwrap();
        let backend = ArtistBackend::new();
        let source = "canvas 8 8 #000000\n";
        backend
            .render_output(source, &root.join("scene.html"), false)
            .unwrap();
        backend
            .render_output(source, &root.join("scene.json"), false)
            .unwrap();
        let html = std::fs::read_to_string(root.join("scene.html")).unwrap();
        let json = std::fs::read_to_string(root.join("scene.json")).unwrap();
        assert!(html.starts_with("<!DOCTYPE html>"));
        assert!(html.contains("<svg"));
        assert!(json.starts_with("{\"svg\":\"<?xml"));
        assert!(json.contains("<svg"));
        assert!(!root.join("scene.svg").exists());
        assert_eq!(
            serde_json_quote("\0\u{1f}\n\"\\é"),
            "\"\\u0000\\u001f\\n\\\"\\\\é\""
        );
        std::fs::remove_dir_all(root).unwrap();
    }
}
