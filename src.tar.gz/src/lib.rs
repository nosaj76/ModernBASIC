//! ModernBASIC -- classic line-numbered Microsoft BASIC for modern 64-bit hardware.
//!
//! See [`architecture`] for the documented mapping from the original 6502 source
//! files (`token.s`, `program.s`, `eval.s`, `memory.s`, `float.s`, `var.s`,
//! `array.s`, `misc2.s`, `print.s`) to this crate's modules.

pub mod address;
pub mod architecture;
pub mod arithmetic;
pub mod arrays;
pub mod artist_backend;
pub mod artist_renderer;
pub mod artist_scene;
mod bounded_line;
mod color_prefs;
pub mod compiler;
pub mod complex;
pub mod data;
mod devices;
pub mod error;
pub mod eval;
pub mod file_io;
mod flipbook;
pub mod framebuffer;
pub mod functions;
pub mod graph;
pub mod graphics;
mod image_codec;
pub mod input;
pub mod instrument_synth;
pub mod integer;
pub mod interpreter;
mod local_time;
mod mat;
mod math_engine;
mod matrix;
mod media;
mod network;
mod numerical;
mod output;
mod perspective;
pub mod program;
pub mod random;
pub mod real;
pub mod repl;
// The SoundFont engine is vendored as source so the runtime remains
// dependency-free. Its historical module name is retained for the public API.
#[path = "synth_engine/mod.rs"]
pub mod rustysynth;
pub mod screen;
pub mod sf_engine;
#[cfg(target_os = "linux")]
pub mod shell;
#[cfg(not(target_os = "linux"))]
pub mod shell {
    pub use crate::color_prefs::ColorPrefs;
    use crate::error::Error;
    use crate::interpreter::RunOptions;
    use crate::program::Program;

    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub enum GraphicsScaleMode {
        Fit,
        Stretch,
    }

    #[derive(Debug, Clone)]
    pub struct ShellOptions {
        pub run_options: RunOptions,
        pub width: u32,
        pub height: u32,
        pub fullscreen: bool,
        pub graphics_scale: GraphicsScaleMode,
        pub uppercase_input: bool,
        pub initial_program: Option<String>,
        pub initial_program_image: Option<Program>,
        pub screen_color: String,
        pub text_color: String,
    }

    impl ShellOptions {
        pub fn new(run_options: RunOptions) -> Self {
            let colors = ColorPrefs::default();
            Self {
                run_options,
                width: 1100,
                height: 760,
                fullscreen: false,
                graphics_scale: GraphicsScaleMode::Fit,
                uppercase_input: true,
                initial_program: None,
                initial_program_image: None,
                screen_color: colors.screen_color,
                text_color: colors.text_color,
            }
        }
    }

    pub fn run_shell(_options: ShellOptions) -> Result<(), Error> {
        Err(Error::Io(
            "the native graphical shell currently requires Linux with X11".into(),
        ))
    }
}
pub mod speech;
pub mod storage;
pub mod synth;
pub mod ti_graph;
pub mod tokens;
mod user_functions;
pub mod value;
pub mod video;
