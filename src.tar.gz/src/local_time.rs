//! Thread-safe conversion between `SystemTime` and the Linux host calendar.
//!
//! BASIC's `DATE$`, `TIME$`, and `TIMER` describe the user's local clock, so
//! UTC arithmetic is not an acceptable substitute. The graphical runtime is a
//! Linux target; `localtime_r` and `mktime` also honor the host timezone and
//! daylight-saving rules without spawning a process or changing global state.

use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::error::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct LocalCalendar {
    pub(crate) year: u32,
    pub(crate) month: u32,
    pub(crate) day: u32,
    pub(crate) hour: u32,
    pub(crate) minute: u32,
    pub(crate) second: u32,
}

#[cfg(target_os = "linux")]
#[repr(C)]
struct LinuxTm {
    second: i32,
    minute: i32,
    hour: i32,
    month_day: i32,
    month: i32,
    year: i32,
    week_day: i32,
    year_day: i32,
    is_dst: i32,
    utc_offset: i64,
    zone: *const std::ffi::c_char,
}

#[cfg(target_os = "linux")]
extern "C" {
    fn localtime_r(clock: *const i64, result: *mut LinuxTm) -> *mut LinuxTm;
    fn mktime(calendar: *mut LinuxTm) -> i64;
}

#[cfg(target_os = "linux")]
pub(crate) fn local_calendar_at(clock: SystemTime) -> Result<LocalCalendar, Error> {
    let (seconds, _) = unix_parts(clock)?;
    let mut result = std::mem::MaybeUninit::<LinuxTm>::uninit();
    // SAFETY: both pointers are valid for the call, and localtime_r writes one
    // complete Linux `struct tm` on success.
    if unsafe { localtime_r(&seconds, result.as_mut_ptr()) }.is_null() {
        return Err(Error::IllegalQuantity);
    }
    // SAFETY: a non-null localtime_r result initialized the complete structure.
    let result = unsafe { result.assume_init() };
    Ok(LocalCalendar {
        year: u32::try_from(result.year + 1_900).map_err(|_| Error::IllegalQuantity)?,
        month: u32::try_from(result.month + 1).map_err(|_| Error::IllegalQuantity)?,
        day: u32::try_from(result.month_day).map_err(|_| Error::IllegalQuantity)?,
        hour: u32::try_from(result.hour).map_err(|_| Error::IllegalQuantity)?,
        minute: u32::try_from(result.minute).map_err(|_| Error::IllegalQuantity)?,
        second: u32::try_from(result.second).map_err(|_| Error::IllegalQuantity)?,
    })
}

#[cfg(not(target_os = "linux"))]
pub(crate) fn local_calendar_at(clock: SystemTime) -> Result<LocalCalendar, Error> {
    // The native GUI currently targets Linux. Keep non-Linux library builds
    // functional with a clearly bounded UTC fallback until their host layer is
    // implemented.
    let (seconds, _) = unix_parts(clock)?;
    let seconds = u64::try_from(seconds).map_err(|_| Error::IllegalQuantity)?;
    let days = seconds / 86_400;
    let seconds = seconds % 86_400;
    let (year, month, day) = utc_days_to_calendar(days)?;
    Ok(LocalCalendar {
        year,
        month,
        day,
        hour: (seconds / 3_600) as u32,
        minute: ((seconds % 3_600) / 60) as u32,
        second: (seconds % 60) as u32,
    })
}

#[cfg(target_os = "linux")]
pub(crate) fn system_time_from_local(calendar: LocalCalendar) -> Result<SystemTime, Error> {
    let mut value = LinuxTm {
        second: i32::try_from(calendar.second).map_err(|_| Error::IllegalQuantity)?,
        minute: i32::try_from(calendar.minute).map_err(|_| Error::IllegalQuantity)?,
        hour: i32::try_from(calendar.hour).map_err(|_| Error::IllegalQuantity)?,
        month_day: i32::try_from(calendar.day).map_err(|_| Error::IllegalQuantity)?,
        month: i32::try_from(calendar.month)
            .map_err(|_| Error::IllegalQuantity)?
            .checked_sub(1)
            .ok_or(Error::IllegalQuantity)?,
        year: i32::try_from(calendar.year)
            .map_err(|_| Error::IllegalQuantity)?
            .checked_sub(1_900)
            .ok_or(Error::IllegalQuantity)?,
        week_day: 0,
        year_day: 0,
        is_dst: -1,
        utc_offset: 0,
        zone: std::ptr::null(),
    };
    // SAFETY: `value` is a fully initialized Linux `struct tm`; is_dst=-1 asks
    // the host to determine the applicable daylight-saving rule.
    let seconds = unsafe { mktime(&mut value) };
    // A negative result is valid for early 1970 local dates east of UTC.
    // Round-trip validation below distinguishes a real timestamp (including
    // -1) from mktime's otherwise ambiguous failure sentinel.
    let clock = if seconds >= 0 {
        UNIX_EPOCH.checked_add(Duration::from_secs(seconds as u64))
    } else {
        UNIX_EPOCH.checked_sub(Duration::from_secs(seconds.unsigned_abs()))
    }
    .ok_or(Error::IllegalQuantity)?;
    // mktime normalizes invalid or nonexistent wall-clock values. Reject those
    // normalizations so assignments mean exactly what the BASIC source wrote.
    if local_calendar_at(clock)? != calendar {
        return Err(Error::IllegalQuantity);
    }
    Ok(clock)
}

#[cfg(not(target_os = "linux"))]
pub(crate) fn system_time_from_local(calendar: LocalCalendar) -> Result<SystemTime, Error> {
    let days = utc_calendar_to_days(calendar.year, calendar.month, calendar.day)?;
    let seconds = days
        .checked_mul(86_400)
        .and_then(|value| value.checked_add(u64::from(calendar.hour) * 3_600))
        .and_then(|value| value.checked_add(u64::from(calendar.minute) * 60))
        .and_then(|value| value.checked_add(u64::from(calendar.second)))
        .ok_or(Error::IllegalQuantity)?;
    UNIX_EPOCH
        .checked_add(Duration::from_secs(seconds))
        .ok_or(Error::IllegalQuantity)
}

pub(crate) fn local_seconds_since_midnight_at(clock: SystemTime) -> Result<f64, Error> {
    let calendar = local_calendar_at(clock)?;
    let (_, nanos) = unix_parts(clock)?;
    Ok(
        f64::from(calendar.hour * 3_600 + calendar.minute * 60 + calendar.second)
            + f64::from(nanos) / 1_000_000_000.0,
    )
}

fn unix_parts(clock: SystemTime) -> Result<(i64, u32), Error> {
    match clock.duration_since(UNIX_EPOCH) {
        Ok(duration) => Ok((
            i64::try_from(duration.as_secs()).map_err(|_| Error::IllegalQuantity)?,
            duration.subsec_nanos(),
        )),
        Err(error) => {
            let duration = error.duration();
            let seconds = i64::try_from(duration.as_secs()).map_err(|_| Error::IllegalQuantity)?;
            if duration.subsec_nanos() == 0 {
                Ok((-seconds, 0))
            } else {
                Ok((
                    seconds
                        .checked_neg()
                        .and_then(|value| value.checked_sub(1))
                        .ok_or(Error::IllegalQuantity)?,
                    1_000_000_000 - duration.subsec_nanos(),
                ))
            }
        }
    }
}

#[cfg(not(target_os = "linux"))]
fn utc_days_to_calendar(days_since_epoch: u64) -> Result<(u32, u32, u32), Error> {
    let mut days = days_since_epoch;
    let mut year = 1970_u32;
    loop {
        let year_days = if is_leap_year(year) { 366 } else { 365 };
        if days < year_days {
            break;
        }
        days -= year_days;
        year = year.checked_add(1).ok_or(Error::IllegalQuantity)?;
    }
    let months = month_days(year);
    let mut month = 1_u32;
    for days_in_month in months {
        if days < u64::from(days_in_month) {
            break;
        }
        days -= u64::from(days_in_month);
        month += 1;
    }
    Ok((year, month, days as u32 + 1))
}

#[cfg(not(target_os = "linux"))]
fn utc_calendar_to_days(year: u32, month: u32, day: u32) -> Result<u64, Error> {
    if year < 1970 || !(1..=12).contains(&month) {
        return Err(Error::IllegalQuantity);
    }
    let months = month_days(year);
    if day == 0 || day > months[(month - 1) as usize] {
        return Err(Error::IllegalQuantity);
    }
    let years = (1970..year)
        .map(|candidate| if is_leap_year(candidate) { 366 } else { 365 })
        .sum::<u64>();
    Ok(years
        + months[..(month - 1) as usize]
            .iter()
            .map(|value| u64::from(*value))
            .sum::<u64>()
        + u64::from(day - 1))
}

#[cfg(not(target_os = "linux"))]
fn month_days(year: u32) -> [u32; 12] {
    [
        31,
        if is_leap_year(year) { 29 } else { 28 },
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31,
    ]
}

#[cfg(not(target_os = "linux"))]
fn is_leap_year(year: u32) -> bool {
    (year % 4 == 0 && year % 100 != 0) || year % 400 == 0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn local_calendar_round_trips_an_unambiguous_midday() {
        let calendar = LocalCalendar {
            year: 2024,
            month: 2,
            day: 29,
            hour: 12,
            minute: 34,
            second: 56,
        };
        let clock = system_time_from_local(calendar).unwrap();
        assert_eq!(local_calendar_at(clock).unwrap(), calendar);
        assert!((local_seconds_since_midnight_at(clock).unwrap() - 45_296.0).abs() < f64::EPSILON);
    }
}
