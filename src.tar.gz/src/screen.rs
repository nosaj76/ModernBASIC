//! Thread-local screen-control bridge between the interpreter and graphical shell.
//!
//! The language runtime remains usable without a GUI.  When the native shell is
//! active it installs a sender on the interpreter worker thread. Graphics and
//! graphing statements can then present Artist scenes inside that same window.

use std::cell::RefCell;
use std::collections::VecDeque;
use std::io::{self, Write};
use std::sync::{mpsc::Sender, mpsc::SyncSender, Arc, Mutex};

/// Which part of the native shell is visible.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScreenView {
    Text,
    Graphics,
    Split,
}

/// A request from the BASIC runtime to the native screen controller.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ScreenEvent {
    /// Change the visible shell screen without changing scene contents.
    SetView(ScreenView),
    /// Move the logical text cursor using one-based BASIC coordinates.
    SetTextCursor {
        row: usize,
        column: usize,
        visible: bool,
    },
    /// Restrict text clearing and newline scrolling to these one-based rows.
    SetPrintRegion { top: usize, bottom: usize },
    /// Change the palette codes used for subsequently rendered text.
    SetTextColors { foreground: i64, background: i64 },
    /// Retain the classic `COLOR` border selection. Rendering is shell-dependent.
    SetBorderColor(String),
    /// Display a renderer or screen-controller failure without presenting a
    /// stale scene as though it succeeded.
    SetError(String),
    /// Clear the graphical shell's text console without changing the program.
    ClearText,
    /// Render and present a complete Artist scene inside the shell window.
    Present {
        artist_source: String,
        /// Shared because a Full-HD frame may feed both the window and an
        /// active VIDEO recorder without a second render or a 6 MiB copy.
        raster_ppm: Option<Arc<[u8]>>,
        view: ScreenView,
    },
    /// Resize the host window so the logical BASIC screen fills it exactly.
    /// The shell adds its status-bar height to the requested raster height.
    Resize { width: u32, height: u32 },
    /// Inform the interpreter of the physical display dimensions so
    /// `SCREEN MAX` can resolve to real hardware.
    DisplaySize { width: u32, height: u32 },
    /// Set the title of the active BASIC program window.
    SetTitle(String),
    /// Request or leave fullscreen presentation.
    SetFullscreen(bool),
    /// Allow or prevent interactive window resizing.
    SetResizable(bool),
    /// Show or hide the graphical pointer over the program window.
    SetPointerVisible(bool),
}

/// One item in the ordered stream produced by an interactive interpreter.
///
/// Text and screen controls deliberately share this channel.  A statement such
/// as `LOCATE 5, 10: PRINT "X"` must be observed as a cursor move followed by
/// text, rather than as activity on two independently drained queues.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InterpreterEvent {
    Output(Vec<u8>),
    Screen(ScreenEvent),
    Ready,
}

/// `Write` adapter that places interpreter output on the ordered event stream.
pub struct InterpreterOutputWriter {
    sender: SyncSender<InterpreterEvent>,
}

impl InterpreterOutputWriter {
    pub fn new(sender: SyncSender<InterpreterEvent>) -> Self {
        Self { sender }
    }
}

impl Write for InterpreterOutputWriter {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.sender
            .send(InterpreterEvent::Output(bytes.to_vec()))
            .map_err(|_| io::Error::new(io::ErrorKind::BrokenPipe, "graphical shell closed"))?;
        Ok(bytes.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

/// Latest pointer state in logical BASIC-screen coordinates.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct PointerState {
    pub x: i64,
    pub y: i64,
    pub buttons: u8,
    pub inside: bool,
    pub last_press_x: i64,
    pub last_press_y: i64,
    pub last_release_x: i64,
    pub last_release_y: i64,
    /// Monotonic edge counter consumed by `ON PEN` without consuming state
    /// used by `PEN(n)` or the graphical shell.
    pub press_generation: u64,
}

impl PointerState {
    /// Apply one raster-relative pointer event. Presses outside the raster are
    /// ignored; releases there only clear a button that was already held.
    pub(crate) fn update(&mut self, logical: Option<(i64, i64)>, button: Option<(u32, bool)>) {
        if let Some((x, y)) = logical {
            self.x = x;
            self.y = y;
            self.inside = true;
        } else {
            self.inside = false;
        }

        let Some((button, pressed)) = button else {
            return;
        };
        let mask = match button {
            1 => 1,
            2 => 2,
            3 => 4,
            _ => 0,
        };
        if mask == 0 {
            return;
        }
        if logical.is_none() {
            if !pressed && self.buttons & mask != 0 {
                self.buttons &= !mask;
            }
            return;
        }
        if pressed {
            self.buttons |= mask;
            self.last_press_x = self.x;
            self.last_press_y = self.y;
            self.press_generation = self.press_generation.wrapping_add(1);
        } else {
            self.buttons &= !mask;
            self.last_release_x = self.x;
            self.last_release_y = self.y;
        }
    }
}

pub type SharedPointerState = Arc<Mutex<PointerState>>;
const MAX_PENDING_KEY_EVENTS: usize = 64;

/// Per-window physical keyboard state paired with the text-oriented key queue.
/// Press edges feed `ON KEY`, while held scancodes feed `MULTIKEY`; keeping
/// these separate from queued text prevents either feature consuming `INKEY$`.
#[derive(Debug)]
pub struct KeyState {
    press_events: VecDeque<u8>,
    held: [bool; 256],
}

impl Default for KeyState {
    fn default() -> Self {
        Self {
            press_events: VecDeque::new(),
            held: [false; 256],
        }
    }
}

impl KeyState {
    /// Record a physical press and return whether it was a new down edge.
    pub fn press(&mut self, keycode: u8) -> bool {
        let index = usize::from(keycode);
        if self.held[index] {
            return false;
        }
        self.held[index] = true;
        if self.press_events.len() == MAX_PENDING_KEY_EVENTS {
            self.press_events.pop_front();
        }
        self.press_events.push_back(keycode);
        true
    }

    pub fn release(&mut self, keycode: u8) {
        self.held[usize::from(keycode)] = false;
    }

    pub fn clear_held(&mut self) {
        self.held.fill(false);
    }

    pub fn is_held(&self, keycode: u8) -> bool {
        self.held[usize::from(keycode)]
    }

    fn take_press(&mut self, keycode: u8) -> bool {
        let Some(position) = self
            .press_events
            .iter()
            .position(|pending| *pending == keycode)
        else {
            return false;
        };
        self.press_events.remove(position);
        true
    }

    fn clear_presses(&mut self, keycode: u8) {
        self.press_events.retain(|pending| *pending != keycode);
    }
}

pub type SharedKeyQueue = Arc<Mutex<VecDeque<String>>>;
pub type SharedKeyState = Arc<Mutex<KeyState>>;

pub(crate) const TEXT_SCREEN_COLUMNS: usize = 80;
pub(crate) const TEXT_SCREEN_ROWS: usize = 25;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct TextCell {
    pub character: char,
    pub foreground: i64,
    pub background: i64,
}

/// Bounded, interpreter-owned view of the visible 80x25 text screen.
///
/// The graphical shells keep scrollback separately. This buffer deliberately
/// retains only addressable screen cells so a BASIC query cannot depend on a
/// particular host terminal or consume unbounded memory.
#[derive(Debug)]
pub(crate) struct TextScreenBuffer {
    cells: Vec<TextCell>,
    cursor_row: usize,
    cursor_column: usize,
    print_top: usize,
    print_bottom: usize,
    foreground: i64,
    background: i64,
}

impl TextScreenBuffer {
    pub fn new(foreground: i64, background: i64) -> Self {
        Self {
            cells: vec![
                TextCell {
                    character: ' ',
                    foreground,
                    background,
                };
                TEXT_SCREEN_ROWS * TEXT_SCREEN_COLUMNS
            ],
            cursor_row: 0,
            cursor_column: 0,
            print_top: 0,
            print_bottom: TEXT_SCREEN_ROWS - 1,
            foreground,
            background,
        }
    }

    pub fn cell(&self, row: usize, column: usize) -> Option<TextCell> {
        if row == 0 || column == 0 || row > TEXT_SCREEN_ROWS || column > TEXT_SCREEN_COLUMNS {
            return None;
        }
        self.cells
            .get((row - 1) * TEXT_SCREEN_COLUMNS + column - 1)
            .copied()
    }

    pub fn set_cursor(&mut self, row: usize, column: usize) {
        self.cursor_row = row.clamp(1, TEXT_SCREEN_ROWS) - 1;
        self.cursor_column = column.clamp(1, TEXT_SCREEN_COLUMNS) - 1;
    }

    pub fn set_print_region(&mut self, top: usize, bottom: usize) {
        self.print_top = top.clamp(1, TEXT_SCREEN_ROWS) - 1;
        self.print_bottom = bottom.clamp(top.clamp(1, TEXT_SCREEN_ROWS), TEXT_SCREEN_ROWS) - 1;
    }

    pub fn set_colors(&mut self, foreground: i64, background: i64) {
        self.foreground = foreground;
        self.background = background;
    }

    pub fn clear_print_region(&mut self) {
        let blank = self.blank_cell();
        for row in self.print_top..=self.print_bottom {
            self.row_mut(row).fill(blank);
        }
        self.cursor_row = self.print_top;
        self.cursor_column = 0;
    }

    pub fn push_bytes(&mut self, bytes: &[u8]) {
        for character in String::from_utf8_lossy(bytes).chars() {
            match character {
                '\n' => self.finish_line(),
                '\r' => self.cursor_column = 0,
                '\u{8}' => self.erase_previous_character(),
                '\t' => {
                    let spaces = 8 - (self.cursor_column % 8);
                    for _ in 0..spaces {
                        self.put_character(' ');
                    }
                }
                character if !character.is_control() => self.put_character(character),
                _ => {}
            }
        }
    }

    fn row_mut(&mut self, row: usize) -> &mut [TextCell] {
        let start = row * TEXT_SCREEN_COLUMNS;
        &mut self.cells[start..start + TEXT_SCREEN_COLUMNS]
    }

    fn blank_cell(&self) -> TextCell {
        TextCell {
            character: ' ',
            foreground: self.foreground,
            background: self.background,
        }
    }

    fn put_character(&mut self, character: char) {
        if self.cursor_column >= TEXT_SCREEN_COLUMNS {
            self.finish_line();
        }
        let index = self.cursor_row * TEXT_SCREEN_COLUMNS + self.cursor_column;
        self.cells[index] = TextCell {
            character,
            foreground: self.foreground,
            background: self.background,
        };
        self.cursor_column += 1;
    }

    fn finish_line(&mut self) {
        self.advance_line();
        self.cursor_column = 0;
    }

    fn advance_line(&mut self) {
        if self.cursor_row >= self.print_top && self.cursor_row == self.print_bottom {
            for row in self.print_top..self.print_bottom {
                let next_start = (row + 1) * TEXT_SCREEN_COLUMNS;
                let current_start = row * TEXT_SCREEN_COLUMNS;
                self.cells
                    .copy_within(next_start..next_start + TEXT_SCREEN_COLUMNS, current_start);
            }
            let blank = self.blank_cell();
            self.row_mut(self.print_bottom).fill(blank);
        } else {
            self.cursor_row = (self.cursor_row + 1).min(TEXT_SCREEN_ROWS - 1);
        }
    }

    fn erase_previous_character(&mut self) {
        if self.cursor_column == 0 {
            return;
        }
        self.cursor_column -= 1;
        let row_start = self.cursor_row * TEXT_SCREEN_COLUMNS;
        let column = self.cursor_column;
        self.cells.copy_within(
            row_start + column + 1..row_start + TEXT_SCREEN_COLUMNS,
            row_start + column,
        );
        self.cells[row_start + TEXT_SCREEN_COLUMNS - 1] = self.blank_cell();
    }
}

/// Physical display dimensions set by the shell so the interpreter can
/// resolve `SCREEN MAX` to the user's actual hardware resolution.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct DisplayInfo {
    pub width: u32,
    pub height: u32,
    pub color_depth: u32,
    pub scale: u32,
}

/// Shared display info — the shell writes it after probing X11, the
/// interpreter worker thread reads it when `SCREEN MAX` is evaluated.
pub type SharedDisplayInfo = Arc<std::sync::Mutex<DisplayInfo>>;

std::thread_local! {
    static INTERPRETER_EVENT_SENDER: RefCell<Option<SyncSender<InterpreterEvent>>> = const { RefCell::new(None) };
    static SCREEN_SENDER: RefCell<Option<Sender<ScreenEvent>>> = const { RefCell::new(None) };
    static POINTER_STATE: RefCell<Option<SharedPointerState>> = const { RefCell::new(None) };
    static KEY_QUEUE: RefCell<Option<SharedKeyQueue>> = const { RefCell::new(None) };
    static KEY_STATE: RefCell<Option<SharedKeyState>> = const { RefCell::new(None) };
    static DISPLAY_INFO: RefCell<Option<SharedDisplayInfo>> = const { RefCell::new(None) };
}

/// Install or remove the unified interpreter event sender for this thread.
pub fn set_thread_interpreter_event_sender(sender: Option<SyncSender<InterpreterEvent>>) {
    INTERPRETER_EVENT_SENDER.with(|slot| {
        *slot.borrow_mut() = sender;
    });
}

/// Install or remove the screen sender for the current interpreter thread.
pub fn set_thread_screen_sender(sender: Option<Sender<ScreenEvent>>) {
    SCREEN_SENDER.with(|slot| {
        *slot.borrow_mut() = sender;
    });
}

/// Set the physical display dimensions for the current interpreter thread.
/// The shell calls this so `SCREEN MAX` can resolve to real hardware.
pub fn set_thread_display_info(info: SharedDisplayInfo) {
    DISPLAY_INFO.with(|slot| {
        *slot.borrow_mut() = Some(info);
    });
}

/// Return the physical display dimensions (0,0 when headless).
pub fn display_info() -> DisplayInfo {
    DISPLAY_INFO.with(|slot| {
        slot.borrow()
            .as_ref()
            .and_then(|info| info.lock().ok().map(|info| *info))
            .unwrap_or_default()
    })
}

/// Send one screen event. Returns true when a graphical shell is attached.
pub fn emit_screen_event(event: ScreenEvent) -> bool {
    let unified_result = INTERPRETER_EVENT_SENDER.with(|slot| {
        slot.borrow()
            .as_ref()
            .map(|sender| sender.send(InterpreterEvent::Screen(event.clone())).is_ok())
    });
    if let Some(sent) = unified_result {
        return sent;
    }
    SCREEN_SENDER.with(|slot| {
        slot.borrow()
            .as_ref()
            .is_some_and(|sender| sender.send(event).is_ok())
    })
}

/// Return whether the current interpreter thread has a graphical shell sink.
/// Callers can use this before doing expensive raster work solely for a live
/// presentation; file rendering and explicit frame capture remain unaffected.
pub fn screen_attached() -> bool {
    INTERPRETER_EVENT_SENDER.with(|slot| slot.borrow().is_some())
        || SCREEN_SENDER.with(|slot| slot.borrow().is_some())
}

/// Install the shell-owned input state on the interpreter worker thread.
pub fn set_thread_pointer_state(state: Option<SharedPointerState>) {
    POINTER_STATE.with(|slot| {
        *slot.borrow_mut() = state;
    });
}

/// Read one coherent pointer snapshot. Batch and headless runs return zeros.
pub fn pointer_state() -> PointerState {
    POINTER_STATE.with(|slot| {
        slot.borrow()
            .as_ref()
            .and_then(|state| state.lock().ok().map(|state| *state))
            .unwrap_or_default()
    })
}

pub fn set_thread_key_queue(queue: Option<SharedKeyQueue>) {
    KEY_QUEUE.with(|slot| {
        *slot.borrow_mut() = queue;
    });
}

pub fn set_thread_key_state(state: Option<SharedKeyState>) {
    KEY_STATE.with(|slot| {
        *slot.borrow_mut() = state;
    });
}

/// Pop the oldest shell key without waiting. Headless runs return an empty string.
pub fn pop_key() -> String {
    KEY_QUEUE.with(|slot| {
        slot.borrow()
            .as_ref()
            .and_then(|queue| queue.lock().ok()?.pop_front())
            .unwrap_or_default()
    })
}

/// Return QB64 truth for a held scancode. Headless runs have no held keys.
pub fn multikey(keycode: u8) -> i64 {
    KEY_STATE.with(|slot| {
        slot.borrow()
            .as_ref()
            .and_then(|queue| queue.lock().ok().map(|state| state.is_held(keycode)))
            .map_or(0, |held| if held { -1 } else { 0 })
    })
}

/// Consume one press edge for a specific event trap without touching INKEY$.
pub(crate) fn take_key_press(keycode: u8) -> bool {
    KEY_STATE.with(|slot| {
        slot.borrow()
            .as_ref()
            .and_then(|queue| queue.lock().ok().map(|mut state| state.take_press(keycode)))
            .unwrap_or(false)
    })
}

pub(crate) fn clear_key_presses(keycode: u8) {
    KEY_STATE.with(|slot| {
        if let Some(queue) = slot.borrow().as_ref() {
            if let Ok(mut state) = queue.lock() {
                state.clear_presses(keycode);
            }
        }
    });
}

/// Map common X11 keysyms to the QB64/PC set-1 scancodes accepted by
/// `MULTIKEY` and `ON KEY`.
pub(crate) fn qb64_key_code(keysym: u64) -> Option<u8> {
    let keysym = match keysym {
        0x61..=0x7A => keysym - u64::from(b'a') + u64::from(b'A'),
        _ => keysym,
    };
    Some(match keysym {
        0xFF1B => 1, // Escape
        0x31 => 2,
        0x32 => 3,
        0x33 => 4,
        0x34 => 5,
        0x35 => 6,
        0x36 => 7,
        0x37 => 8,
        0x38 => 9,
        0x39 => 10,
        0x30 => 11,
        0xFF08 => 14, // Backspace
        0xFF09 => 15, // Tab
        0x51 => 16,
        0x57 => 17,
        0x45 => 18,
        0x52 => 19,
        0x54 => 20,
        0x59 => 21,
        0x55 => 22,
        0x49 => 23,
        0x4F => 24,
        0x50 => 25,
        0xFF0D => 28, // Enter
        0x41 => 30,
        0x53 => 31,
        0x44 => 32,
        0x46 => 33,
        0x47 => 34,
        0x48 => 35,
        0x4A => 36,
        0x4B => 37,
        0x4C => 38,
        0x5A => 44,
        0x58 => 45,
        0x43 => 46,
        0x56 => 47,
        0x42 => 48,
        0x4E => 49,
        0x4D => 50,
        0x20 => 57,                                      // Space
        0xFFBE..=0xFFC7 => (keysym - 0xFFBE) as u8 + 59, // F1-F10
        0xFF50 => 71,                                    // Home
        0xFF52 => 72,                                    // Up
        0xFF55 => 73,                                    // Page Up
        0xFF51 => 75,                                    // Left
        0xFF53 => 77,                                    // Right
        0xFF57 => 79,                                    // End
        0xFF54 => 80,                                    // Down
        0xFF56 => 81,                                    // Page Down
        0xFF63 => 82,                                    // Insert
        0xFFFF => 83,                                    // Delete
        _ => return None,
    })
}

/// Return whether the current interpreter thread has a live shell key queue.
pub(crate) fn key_queue_attached() -> bool {
    KEY_QUEUE.with(|slot| slot.borrow().is_some())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::mpsc;

    #[test]
    fn text_screen_cells_track_unicode_colors_controls_and_bounds() {
        let mut screen = TextScreenBuffer::new(10, 0);
        screen.set_cursor(2, 79);
        screen.push_bytes("AβC".as_bytes());
        assert_eq!(screen.cell(2, 79).unwrap().character, 'A');
        assert_eq!(screen.cell(2, 80).unwrap().character, 'β');
        assert_eq!(screen.cell(3, 1).unwrap().character, 'C');

        screen.set_colors(0x11_22_33, 7);
        screen.push_bytes(b"D\x08E\tF");
        let cell = screen.cell(3, 2).unwrap();
        assert_eq!(cell.character, 'E');
        assert_eq!((cell.foreground, cell.background), (0x11_22_33, 7));
        assert_eq!(screen.cell(3, 9).unwrap().character, 'F');
        assert!(screen.cell(0, 1).is_none());
        assert!(screen.cell(1, 81).is_none());
    }

    #[test]
    fn text_screen_scrolls_and_clears_only_the_print_region() {
        let mut screen = TextScreenBuffer::new(10, 0);
        screen.set_cursor(1, 1);
        screen.push_bytes(b"KEEP");
        screen.set_print_region(2, 3);
        screen.set_cursor(2, 1);
        screen.push_bytes(b"TOP");
        screen.set_cursor(3, 1);
        screen.push_bytes(b"BOTTOM\nNEXT");
        assert_eq!(screen.cell(1, 1).unwrap().character, 'K');
        assert_eq!(screen.cell(2, 1).unwrap().character, 'B');
        assert_eq!(screen.cell(3, 1).unwrap().character, 'N');

        screen.clear_print_region();
        assert_eq!(screen.cell(1, 1).unwrap().character, 'K');
        assert_eq!(screen.cell(2, 1).unwrap().character, ' ');
        assert_eq!(screen.cell(3, 1).unwrap().character, ' ');
    }

    #[test]
    fn events_are_thread_local_and_report_listener_presence() {
        set_thread_interpreter_event_sender(None);
        set_thread_screen_sender(None);
        assert!(!screen_attached());
        assert!(!emit_screen_event(ScreenEvent::SetView(ScreenView::Text)));

        let (sender, receiver) = mpsc::channel();
        set_thread_screen_sender(Some(sender));
        assert!(screen_attached());
        assert!(emit_screen_event(ScreenEvent::SetView(
            ScreenView::Graphics
        )));
        assert_eq!(
            receiver.recv().unwrap(),
            ScreenEvent::SetView(ScreenView::Graphics)
        );
        set_thread_screen_sender(None);
        assert!(!screen_attached());
    }

    #[test]
    fn output_and_screen_controls_share_one_ordered_stream() {
        set_thread_screen_sender(None);
        let (sender, receiver) = mpsc::sync_channel(16);
        set_thread_interpreter_event_sender(Some(sender.clone()));
        let mut output = InterpreterOutputWriter::new(sender);

        assert!(emit_screen_event(ScreenEvent::SetTextCursor {
            row: 3,
            column: 7,
            visible: true,
        }));
        write!(output, "FIRST").unwrap();
        assert!(emit_screen_event(ScreenEvent::ClearText));
        write!(output, "SECOND").unwrap();

        assert_eq!(
            receiver.try_iter().collect::<Vec<_>>(),
            vec![
                InterpreterEvent::Screen(ScreenEvent::SetTextCursor {
                    row: 3,
                    column: 7,
                    visible: true,
                }),
                InterpreterEvent::Output(b"FIRST".to_vec()),
                InterpreterEvent::Screen(ScreenEvent::ClearText),
                InterpreterEvent::Output(b"SECOND".to_vec()),
            ]
        );
        set_thread_interpreter_event_sender(None);
    }

    #[test]
    fn pointer_state_is_shared_but_defaults_safely_without_a_shell() {
        set_thread_pointer_state(None);
        assert_eq!(pointer_state(), PointerState::default());
        let shared = Arc::new(Mutex::new(PointerState {
            x: 12,
            y: 34,
            buttons: 5,
            inside: true,
            ..PointerState::default()
        }));
        set_thread_pointer_state(Some(shared));
        assert_eq!(pointer_state().x, 12);
        assert_eq!(pointer_state().buttons, 5);
        set_thread_pointer_state(None);
    }

    #[test]
    fn out_of_raster_presses_do_not_reuse_stale_pointer_coordinates() {
        let mut state = PointerState {
            x: 40,
            y: 50,
            inside: true,
            ..PointerState::default()
        };
        state.update(None, Some((1, true)));
        assert!(!state.inside);
        assert_eq!(state.buttons, 0);
        assert_eq!(state.press_generation, 0);
        assert_eq!((state.last_press_x, state.last_press_y), (0, 0));

        state.update(Some((7, 8)), Some((1, true)));
        state.update(None, Some((1, false)));
        assert_eq!(state.buttons, 0);
        assert_eq!(state.press_generation, 1);
        assert_eq!((state.last_release_x, state.last_release_y), (0, 0));
    }

    #[test]
    fn key_queue_is_nonblocking_and_fifo() {
        set_thread_key_queue(None);
        assert_eq!(pop_key(), "");
        let queue = Arc::new(Mutex::new(VecDeque::from([
            "A".to_string(),
            "LEFT".to_string(),
        ])));
        set_thread_key_queue(Some(queue));
        assert_eq!(pop_key(), "A");
        assert_eq!(pop_key(), "LEFT");
        assert_eq!(pop_key(), "");
        set_thread_key_queue(None);
    }

    #[test]
    fn held_keys_and_press_edges_are_independent_of_text_input() {
        let state = Arc::new(Mutex::new(KeyState::default()));
        set_thread_key_state(Some(Arc::clone(&state)));
        assert_eq!(multikey(30), 0);
        assert!(state.lock().unwrap().press(30));
        assert_eq!(multikey(30), -1);
        assert!(take_key_press(30));
        assert!(!take_key_press(30));
        state.lock().unwrap().release(30);
        assert_eq!(multikey(30), 0);
        set_thread_key_state(None);
    }

    #[test]
    fn common_keysyms_map_to_qb64_scancodes() {
        assert_eq!(qb64_key_code(u64::from(b'a')), Some(30));
        assert_eq!(qb64_key_code(u64::from(b'1')), Some(2));
        assert_eq!(qb64_key_code(0xFF52), Some(72));
        assert_eq!(qb64_key_code(0xFF0D), Some(28));
        assert_eq!(qb64_key_code(0x1008FF12), None);
    }
}
