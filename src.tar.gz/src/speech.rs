//! Optional host speech device used by the modern `SAY` statement.
//!
//! Speech is queued on a dedicated worker so BASIC execution remains
//! immediate. The implementation passes arguments directly to eSpeak NG (or
//! eSpeak) without a shell and never treats spoken text as a command line.

use std::collections::VecDeque;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver, RecvTimeoutError, Sender, SyncSender, TryRecvError};
use std::sync::Arc;
use std::time::{Duration, Instant};

use crate::error::Error;
use crate::synth::{parse_note, MAX_REST_BEATS, MAX_SYNTH_SECONDS};

/// Maximum combined note and rest events accepted by one `SING` statement.
pub const MAX_SING_EVENTS: usize = 4_096;
const MIN_SING_SECONDS: f64 = 0.02;
const MIN_SING_MIDI: f64 = 36.0;
const MAX_SING_MIDI: f64 = 84.0;
const SING_SAMPLE_RATE: u32 = 44_100;
const SING_CROSSFADE_MS: u32 = 15;
const SING_ATTACK_MS: u32 = 8;
const SING_RELEASE_MS: u32 = 24;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SpeechMode {
    Queue,
    Interrupt,
    Wait,
}

impl SpeechMode {
    pub fn parse(name: &str) -> Result<Self, Error> {
        match name.trim().to_ascii_uppercase().as_str() {
            "QUEUE" => Ok(Self::Queue),
            "INTERRUPT" => Ok(Self::Interrupt),
            "WAIT" => Ok(Self::Wait),
            _ => Err(Error::syntax("SAY mode must be QUEUE, INTERRUPT, or WAIT")),
        }
    }
}

type SpeechProducer = Box<dyn FnOnce(&mut dyn Write) -> Result<(), String> + Send>;

struct SpeechRequest {
    executable: Option<PathBuf>,
    arguments: Vec<String>,
    duration: Option<Duration>,
    interrupt: bool,
    producer: Option<SpeechProducer>,
    completion: Option<SyncSender<Result<(), String>>>,
}

enum SpeechCommand {
    Speak(SpeechRequest),
    Stop,
}

/// One interpreter task's speech queue and worker. A program can interrupt or
/// stop only the utterances owned by its own session.
pub(crate) struct SpeechSession {
    sender: Option<Sender<SpeechCommand>>,
    active: Arc<AtomicBool>,
}

impl Default for SpeechSession {
    fn default() -> Self {
        Self {
            sender: None,
            active: Arc::new(AtomicBool::new(false)),
        }
    }
}

impl SpeechSession {
    pub(crate) fn is_active(&self) -> bool {
        self.active.load(Ordering::SeqCst)
    }

    pub(crate) fn stop(&self) -> bool {
        self.sender
            .as_ref()
            .is_some_and(|sender| sender.send(SpeechCommand::Stop).is_ok())
    }

    fn sender(&mut self) -> Result<&Sender<SpeechCommand>, Error> {
        if self.sender.is_none() {
            let (sender, receiver) = mpsc::channel();
            let active = Arc::clone(&self.active);
            std::thread::Builder::new()
                .name("modernbasic-speech".to_string())
                .spawn(move || speech_worker(receiver, active))
                .map_err(|error| Error::Io(format!("cannot start speech worker: {error}")))?;
            self.sender = Some(sender);
        }
        self.sender
            .as_ref()
            .ok_or_else(|| Error::Io("cannot initialize speech worker".to_string()))
    }
}

impl Drop for SpeechSession {
    fn drop(&mut self) {
        self.stop();
    }
}

fn wait_for_speech(
    session: &SpeechSession,
    receiver: Receiver<Result<(), String>>,
) -> Result<(), Error> {
    loop {
        match receiver.recv_timeout(Duration::from_millis(20)) {
            Ok(result) => return result.map_err(Error::Io),
            Err(RecvTimeoutError::Timeout) => {
                if crate::interpreter::take_interrupt() {
                    session.stop();
                    return Err(Error::Break);
                }
            }
            Err(RecvTimeoutError::Disconnected) => {
                return Err(Error::Io("speech worker stopped unexpectedly".to_string()));
            }
        }
    }
}

struct ActiveSpeech {
    child: Option<Child>,
    deadline: Option<Instant>,
    producer_result: Option<Receiver<Result<(), String>>>,
    completion: Option<SyncSender<Result<(), String>>>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct SingingEvent {
    syllable: Option<String>,
    duration: Duration,
    rate_wpm: i64,
    pitch: i64,
    amplitude: i64,
}

/// A validated vocal score retained by the interpreter for `WAVEFILE` export.
#[derive(Debug, Clone)]
pub(crate) struct SingingScore {
    events: Vec<SingingEvent>,
    voice: String,
}

struct MonoPcm {
    sample_rate: u32,
    samples: Vec<f32>,
}

/// Queue text for the host speech device or wait for it explicitly.
pub(crate) fn speak(
    session: &mut SpeechSession,
    text: &str,
    rate_wpm: i64,
    pitch_hz: f64,
    volume: f64,
    voice: &str,
    mode: SpeechMode,
) -> Result<(), Error> {
    if text.is_empty()
        || text.len() > 32_767
        || !(40..=450).contains(&rate_wpm)
        || !pitch_hz.is_finite()
        || !(65.0..=320.0).contains(&pitch_hz)
        || !volume.is_finite()
        || !(0.0..=1.0).contains(&volume)
        || voice.is_empty()
        || voice.len() > 128
    {
        return Err(Error::IllegalQuantity);
    }
    if crate::synth::is_audio_disabled() {
        return Ok(());
    }

    let executable = speech_backend().ok_or_else(|| {
        Error::Io("SAY requires eSpeak NG or eSpeak on the host system".to_string())
    })?;
    let pitch = ((pitch_hz - 65.0) / (320.0 - 65.0) * 99.0).round() as i64;
    let amplitude = (volume * 200.0).round() as i64;
    let arguments = vec![
        "-s".to_string(),
        rate_wpm.to_string(),
        "-p".to_string(),
        pitch.to_string(),
        "-a".to_string(),
        amplitude.to_string(),
        "-v".to_string(),
        voice.to_string(),
        text.to_string(),
    ];

    let (completion, receiver) = if mode == SpeechMode::Wait {
        let (sender, receiver) = mpsc::sync_channel(1);
        (Some(sender), Some(receiver))
    } else {
        (None, None)
    };
    session
        .sender()?
        .send(SpeechCommand::Speak(SpeechRequest {
            executable: Some(executable),
            arguments,
            duration: None,
            interrupt: mode == SpeechMode::Interrupt,
            producer: None,
            completion,
        }))
        .map_err(|_| Error::Io("speech worker is unavailable".to_string()))?;

    if let Some(receiver) = receiver {
        wait_for_speech(session, receiver)?;
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn sing_with_score(
    session: &mut SpeechSession,
    lyrics: &str,
    sequence: &str,
    default_beats: f64,
    tempo_bpm: f64,
    volume: f64,
    voice: &str,
    mode: SpeechMode,
) -> Result<SingingScore, Error> {
    if !volume.is_finite()
        || !(0.0..=1.0).contains(&volume)
        || voice.is_empty()
        || voice.len() > 128
    {
        return Err(Error::IllegalQuantity);
    }
    let score = SingingScore {
        events: plan_singing(lyrics, sequence, default_beats, tempo_bpm, volume)?,
        voice: voice.to_string(),
    };
    if crate::synth::is_audio_disabled() {
        return Ok(score);
    }
    let executable = speech_backend().ok_or_else(|| {
        Error::Io("SING requires eSpeak NG or eSpeak on the host system".to_string())
    })?;
    let (player, player_arguments) = singing_pcm_player().ok_or_else(|| {
        Error::Io("smoothed SING playback requires paplay or aplay on the host system".to_string())
    })?;
    let (completion, receiver) = if mode == SpeechMode::Wait {
        let (sender, receiver) = mpsc::sync_channel(1);
        (Some(sender), Some(receiver))
    } else {
        (None, None)
    };
    let live_score = score.clone();
    let producer: SpeechProducer = Box::new(move |output| {
        render_smoothed_singing(&live_score.events, &executable, &live_score.voice, output)
    });
    session
        .sender()?
        .send(SpeechCommand::Speak(SpeechRequest {
            executable: Some(player),
            arguments: player_arguments,
            duration: None,
            interrupt: mode == SpeechMode::Interrupt,
            producer: Some(producer),
            completion,
        }))
        .map_err(|_| Error::Io("speech worker is unavailable".to_string()))?;

    if let Some(receiver) = receiver {
        wait_for_speech(session, receiver)?;
    }
    Ok(score)
}

/// Render retained `SING` statements as one sequential 44.1 kHz stereo WAV.
pub(crate) fn render_singing_scores_wav(scores: &[SingingScore]) -> Result<Vec<u8>, Error> {
    if scores.is_empty() {
        return Err(Error::syntax("no singing score has been created"));
    }
    let executable = speech_backend()
        .ok_or_else(|| Error::Io("singing WAV export requires eSpeak NG or eSpeak".to_string()))?;
    render_singing_scores_wav_with(scores, |voice, event| {
        render_espeak_syllable(&executable, voice, event)
    })
    .map_err(Error::Io)
}

fn render_singing_scores_wav_with<F>(
    scores: &[SingingScore],
    mut render: F,
) -> Result<Vec<u8>, String>
where
    F: FnMut(&str, &SingingEvent) -> Result<MonoPcm, String>,
{
    let total_frames = scores
        .iter()
        .flat_map(|score| score.events.iter())
        .try_fold(0_usize, |total, event| {
            let frames =
                (event.duration.as_secs_f64() * f64::from(SING_SAMPLE_RATE)).round() as usize;
            total
                .checked_add(frames)
                .ok_or_else(|| "singing PCM frame overflow".to_string())
        })?;
    let total_bytes = total_frames
        .checked_mul(4)
        .ok_or_else(|| "singing PCM byte overflow".to_string())?;
    let total_file_bytes = total_bytes
        .checked_add(44)
        .ok_or_else(|| "singing WAV size overflow".to_string())?;
    if total_file_bytes > crate::synth::MAX_WAV_BYTES {
        return Err("singing PCM exceeds the audio memory limit".to_string());
    }

    let mut pcm = Vec::with_capacity(total_bytes);
    for score in scores {
        render_smoothed_singing_with(&score.events, &mut pcm, |event| render(&score.voice, event))?;
    }
    debug_assert_eq!(pcm.len(), total_bytes);
    let mut wav = crate::synth::pcm_wav_header(total_bytes).map_err(|error| error.to_string())?;
    wav.extend_from_slice(&pcm);
    Ok(wav)
}

fn plan_singing(
    lyrics: &str,
    sequence: &str,
    default_beats: f64,
    tempo_bpm: f64,
    volume: f64,
) -> Result<Vec<SingingEvent>, Error> {
    if lyrics.is_empty()
        || lyrics.len() > 32_767
        || !default_beats.is_finite()
        || default_beats <= 0.0
        || default_beats > MAX_REST_BEATS
        || !tempo_bpm.is_finite()
        || !(1.0..=1_000.0).contains(&tempo_bpm)
    {
        return Err(Error::IllegalQuantity);
    }
    let mut syllables = Vec::new();
    for word in lyrics.split_whitespace() {
        for syllable in word.split('-') {
            if syllable.is_empty() {
                return Err(Error::syntax(
                    "SING lyric hyphens must separate non-empty syllables",
                ));
            }
            syllables.push(syllable.to_string());
        }
    }
    if syllables.is_empty() {
        return Err(Error::syntax("SING requires at least one lyric syllable"));
    }

    let note_tokens = sequence.split_whitespace().collect::<Vec<_>>();
    if note_tokens.is_empty() || note_tokens.len() > MAX_SING_EVENTS {
        return Err(if note_tokens.is_empty() {
            Error::syntax("SING requires at least one note")
        } else {
            Error::IllegalQuantity
        });
    }
    let mut events = Vec::with_capacity(note_tokens.len());
    let mut syllable_index = 0;
    let mut total_seconds = 0.0;
    for token in note_tokens {
        if token
            .strip_prefix('V')
            .or_else(|| token.strip_prefix('v'))
            .is_some_and(|voice| voice.parse::<i64>().is_ok())
        {
            return Err(Error::syntax("SING does not accept PLAY voice switches"));
        }
        let note = parse_note(token, default_beats)?;
        let seconds = note.beats * 60.0 / tempo_bpm;
        if !seconds.is_finite() || seconds < MIN_SING_SECONDS {
            return Err(Error::IllegalQuantity);
        }
        total_seconds += seconds;
        if total_seconds > MAX_SYNTH_SECONDS {
            return Err(Error::IllegalQuantity);
        }
        let duration = Duration::from_secs_f64(seconds);
        let (syllable, pitch, rate_wpm, amplitude) = if let Some(frequency) = note.frequency {
            let Some(syllable) = syllables.get(syllable_index).cloned() else {
                return Err(Error::syntax(
                    "SING requires exactly one lyric syllable per non-rest note",
                ));
            };
            syllable_index += 1;
            let midi = 69.0 + 12.0 * (frequency / 440.0).log2();
            if !(MIN_SING_MIDI..=MAX_SING_MIDI).contains(&midi) {
                return Err(Error::syntax(
                    "SING notes must be in the C2 through C6 range",
                ));
            }
            let pitch =
                ((midi - MIN_SING_MIDI) / (MAX_SING_MIDI - MIN_SING_MIDI) * 99.0).round() as i64;
            let rate_wpm = (60.0 / seconds).round().clamp(80.0, 450.0) as i64;
            let amplitude = (volume * 200.0 * f64::from(note.velocity) / 127.0).round() as i64;
            (Some(syllable), pitch, rate_wpm, amplitude)
        } else {
            (None, 0, 80, 0)
        };
        events.push(SingingEvent {
            syllable,
            duration,
            rate_wpm,
            pitch,
            amplitude,
        });
    }
    if syllable_index != syllables.len() {
        return Err(Error::syntax(
            "SING requires exactly one lyric syllable per non-rest note",
        ));
    }
    Ok(events)
}

fn speech_backend() -> Option<PathBuf> {
    [
        "/usr/bin/espeak-ng",
        "/bin/espeak-ng",
        "/usr/bin/espeak",
        "/bin/espeak",
    ]
    .into_iter()
    .map(PathBuf::from)
    .find(|path| Path::new(path).is_file())
}

fn singing_pcm_player() -> Option<(PathBuf, Vec<String>)> {
    for candidate in ["/usr/bin/paplay", "/bin/paplay"] {
        let path = PathBuf::from(candidate);
        if path.is_file() {
            return Some((
                path,
                vec![
                    "--raw".to_string(),
                    "--format".to_string(),
                    "s16le".to_string(),
                    "--rate".to_string(),
                    SING_SAMPLE_RATE.to_string(),
                    "--channels".to_string(),
                    "2".to_string(),
                ],
            ));
        }
    }
    for candidate in ["/usr/bin/aplay", "/bin/aplay"] {
        let path = PathBuf::from(candidate);
        if path.is_file() {
            return Some((
                path,
                vec![
                    "-q".to_string(),
                    "-t".to_string(),
                    "raw".to_string(),
                    "-f".to_string(),
                    "S16_LE".to_string(),
                    "-r".to_string(),
                    SING_SAMPLE_RATE.to_string(),
                    "-c".to_string(),
                    "2".to_string(),
                ],
            ));
        }
    }
    None
}

fn render_smoothed_singing(
    events: &[SingingEvent],
    executable: &Path,
    voice: &str,
    output: &mut dyn Write,
) -> Result<(), String> {
    render_smoothed_singing_with(events, output, |event| {
        render_espeak_syllable(executable, voice, event)
    })
}

fn render_espeak_syllable(
    executable: &Path,
    voice: &str,
    event: &SingingEvent,
) -> Result<MonoPcm, String> {
    let syllable = event
        .syllable
        .as_deref()
        .ok_or_else(|| "cannot render a silent singing event".to_string())?;
    let rendered = Command::new(executable)
        .arg("--stdout")
        .arg("-s")
        .arg(event.rate_wpm.to_string())
        .arg("-p")
        .arg(event.pitch.to_string())
        .arg("-a")
        .arg(event.amplitude.to_string())
        .arg("-g")
        .arg("0")
        .arg("-v")
        .arg(voice)
        .arg(syllable)
        .stdin(Stdio::null())
        .stderr(Stdio::null())
        .output()
        .map_err(|error| format!("cannot render singing voice: {error}"))?;
    if !rendered.status.success() {
        return Err(format!("singing voice exited with {}", rendered.status));
    }
    decode_pcm_wav(&rendered.stdout)
}

fn decode_pcm_wav(wav: &[u8]) -> Result<MonoPcm, String> {
    if wav.len() < 12 || &wav[..4] != b"RIFF" || &wav[8..12] != b"WAVE" {
        return Err("singing voice produced an invalid WAV header".to_string());
    }
    let mut offset = 12_usize;
    let mut format = None::<(u16, u16, u32, u16)>;
    let mut data = None::<&[u8]>;
    while offset.checked_add(8).is_some_and(|end| end <= wav.len()) {
        let name = &wav[offset..offset + 4];
        let declared = u32::from_le_bytes([
            wav[offset + 4],
            wav[offset + 5],
            wav[offset + 6],
            wav[offset + 7],
        ]) as usize;
        offset += 8;
        let available = wav.len() - offset;
        let actual = declared.min(available);
        if name == b"fmt " {
            if actual < 16 {
                return Err("singing voice produced an invalid WAV format".to_string());
            }
            format = Some((
                u16::from_le_bytes([wav[offset], wav[offset + 1]]),
                u16::from_le_bytes([wav[offset + 2], wav[offset + 3]]),
                u32::from_le_bytes([
                    wav[offset + 4],
                    wav[offset + 5],
                    wav[offset + 6],
                    wav[offset + 7],
                ]),
                u16::from_le_bytes([wav[offset + 14], wav[offset + 15]]),
            ));
        } else if name == b"data" {
            data = Some(&wav[offset..offset + actual]);
            break;
        }
        if declared > available {
            break;
        }
        offset = offset
            .checked_add(declared + (declared & 1))
            .ok_or_else(|| "singing WAV chunk size overflow".to_string())?;
    }
    let (encoding, channels, sample_rate, bits) =
        format.ok_or_else(|| "singing WAV has no format chunk".to_string())?;
    if encoding != 1
        || !(1..=2).contains(&channels)
        || bits != 16
        || !(8_000..=192_000).contains(&sample_rate)
    {
        return Err("singing voice must produce 16-bit mono or stereo PCM".to_string());
    }
    let data = data.ok_or_else(|| "singing WAV has no audio data".to_string())?;
    let frame_bytes = usize::from(channels) * 2;
    let mut samples = Vec::with_capacity(data.len() / frame_bytes);
    for frame in data.chunks_exact(frame_bytes) {
        let mut mixed = 0.0_f32;
        for channel in 0..usize::from(channels) {
            let index = channel * 2;
            mixed += i16::from_le_bytes([frame[index], frame[index + 1]]) as f32 / i16::MAX as f32;
        }
        samples.push(mixed / f32::from(channels));
    }
    if samples.is_empty() {
        return Err("singing voice produced no PCM samples".to_string());
    }
    Ok(MonoPcm {
        sample_rate,
        samples,
    })
}

fn render_smoothed_singing_with<F>(
    events: &[SingingEvent],
    output: &mut dyn Write,
    mut render: F,
) -> Result<(), String>
where
    F: FnMut(&SingingEvent) -> Result<MonoPcm, String>,
{
    let frame_counts = events
        .iter()
        .map(|event| (event.duration.as_secs_f64() * f64::from(SING_SAMPLE_RATE)).round() as usize)
        .collect::<Vec<_>>();
    let total_frames = frame_counts.iter().try_fold(0_usize, |total, frames| {
        total
            .checked_add(*frames)
            .ok_or("singing PCM frame overflow")
    })?;
    let total_bytes = total_frames
        .checked_mul(4)
        .ok_or("singing PCM byte overflow")?;
    if total_bytes > crate::synth::MAX_WAV_BYTES {
        return Err("singing PCM exceeds the audio memory limit".to_string());
    }

    let crossfade_frames =
        (u64::from(SING_SAMPLE_RATE) * u64::from(SING_CROSSFADE_MS) / 1_000) as usize;
    let attack_frames = (u64::from(SING_SAMPLE_RATE) * u64::from(SING_ATTACK_MS) / 1_000) as usize;
    let release_frames =
        (u64::from(SING_SAMPLE_RATE) * u64::from(SING_RELEASE_MS) / 1_000) as usize;
    let mut room = VocalRoomWriter::new(output);
    let mut previous_tail = Vec::<f32>::new();

    for (event, target_frames) in events.iter().zip(frame_counts) {
        let Some(_) = event.syllable else {
            previous_tail.clear();
            room.write_silence(target_frames)?;
            continue;
        };
        let clip = render(event)?;
        let samples = resample_and_trim(clip)?;
        let main_audible = samples.len().min(target_frames);
        let tail_available = samples.len().saturating_sub(target_frames);
        let tail_frames = tail_available.min(crossfade_frames);
        let attack = attack_frames.min(main_audible / 2);
        let release = if tail_frames == 0 {
            release_frames.min(main_audible / 2)
        } else {
            0
        };

        for index in 0..target_frames {
            let mut dry = samples.get(index).copied().unwrap_or(0.0);
            if attack > 0 && index < attack {
                dry *= (index + 1) as f32 / attack as f32;
            }
            if release > 0 && index + release >= main_audible && index < main_audible {
                dry *= (main_audible - index) as f32 / release as f32;
            }
            if let Some(tail) = previous_tail.get(index) {
                dry += *tail;
            }
            room.write_frame(dry)?;
        }

        previous_tail.clear();
        previous_tail.reserve(tail_frames);
        for index in 0..tail_frames {
            let gain = 1.0 - (index + 1) as f32 / (tail_frames + 1) as f32;
            previous_tail.push(samples[target_frames + index] * gain);
        }
    }
    room.finish()
}

fn resample_and_trim(clip: MonoPcm) -> Result<Vec<f32>, String> {
    let samples = if clip.sample_rate == SING_SAMPLE_RATE {
        clip.samples
    } else {
        let output_len = clip
            .samples
            .len()
            .checked_mul(SING_SAMPLE_RATE as usize)
            .ok_or("singing resample length overflow")?
            / clip.sample_rate as usize;
        if output_len == 0 {
            return Err("singing voice produced an empty resample".to_string());
        }
        let ratio = clip.sample_rate as f64 / f64::from(SING_SAMPLE_RATE);
        let mut converted = Vec::with_capacity(output_len);
        for index in 0..output_len {
            let position = index as f64 * ratio;
            let first = position.floor() as usize;
            let fraction = (position - first as f64) as f32;
            let left = clip.samples[first.min(clip.samples.len() - 1)];
            let right = clip.samples[(first + 1).min(clip.samples.len() - 1)];
            converted.push(left + (right - left) * fraction);
        }
        converted
    };
    let Some(first_voiced) = samples.iter().position(|sample| sample.abs() >= 0.001) else {
        return Err("singing voice produced only silence".to_string());
    };
    let last_voiced = samples
        .iter()
        .rposition(|sample| sample.abs() >= 0.001)
        .expect("a voiced sample exists");
    let preroll = (SING_SAMPLE_RATE as usize * 4) / 1_000;
    let release = (SING_SAMPLE_RATE as usize * 12) / 1_000;
    let start = first_voiced.saturating_sub(preroll);
    let end = (last_voiced + 1 + release).min(samples.len());
    Ok(samples[start..end].to_vec())
}

struct VocalRoomWriter<'a> {
    output: &'a mut dyn Write,
    history: Vec<f32>,
    cursor: usize,
    buffer: Vec<u8>,
}

impl<'a> VocalRoomWriter<'a> {
    fn new(output: &'a mut dyn Write) -> Self {
        let history_frames = (SING_SAMPLE_RATE as usize * 120) / 1_000;
        Self {
            output,
            history: vec![0.0; history_frames],
            cursor: 0,
            buffer: Vec::with_capacity(32_768),
        }
    }

    fn delayed(&self, milliseconds: usize) -> f32 {
        let frames = SING_SAMPLE_RATE as usize * milliseconds / 1_000;
        self.history[(self.cursor + self.history.len() - frames) % self.history.len()]
    }

    fn write_frame(&mut self, dry: f32) -> Result<(), String> {
        let left_wet =
            self.delayed(31) * 0.105 + self.delayed(67) * 0.060 + self.delayed(109) * 0.032;
        let right_wet =
            self.delayed(37) * 0.105 + self.delayed(73) * 0.060 + self.delayed(113) * 0.032;
        self.history[self.cursor] = (dry + (left_wet + right_wet) * 0.12).clamp(-1.0, 1.0);
        self.cursor = (self.cursor + 1) % self.history.len();
        for sample in [dry * 0.90 + left_wet, dry * 0.90 + right_wet] {
            let pcm = (sample.clamp(-1.0, 1.0) * i16::MAX as f32).round() as i16;
            self.buffer.extend_from_slice(&pcm.to_le_bytes());
        }
        if self.buffer.len() >= 32_768 {
            self.flush()?;
        }
        Ok(())
    }

    fn write_silence(&mut self, frames: usize) -> Result<(), String> {
        for _ in 0..frames {
            self.write_frame(0.0)?;
        }
        Ok(())
    }

    fn flush(&mut self) -> Result<(), String> {
        self.output
            .write_all(&self.buffer)
            .map_err(|error| format!("cannot stream smoothed singing: {error}"))?;
        self.buffer.clear();
        Ok(())
    }

    fn finish(mut self) -> Result<(), String> {
        self.flush()
    }
}

fn speech_worker(receiver: Receiver<SpeechCommand>, activity: Arc<AtomicBool>) {
    let mut queue = VecDeque::<SpeechRequest>::new();
    let mut active = None::<ActiveSpeech>;

    loop {
        if active.is_none() {
            if let Some(request) = queue.pop_front() {
                active = start_request(request);
                activity.store(active.is_some() || !queue.is_empty(), Ordering::SeqCst);
                continue;
            }
            activity.store(false, Ordering::SeqCst);
            match receiver.recv() {
                Ok(command) => handle_speech_command(command, &mut active, &mut queue),
                Err(_) => break,
            }
            activity.store(active.is_some() || !queue.is_empty(), Ordering::SeqCst);
            continue;
        }
        match receiver.recv_timeout(Duration::from_millis(20)) {
            Ok(command) => {
                handle_speech_command(command, &mut active, &mut queue);
                activity.store(active.is_some() || !queue.is_empty(), Ordering::SeqCst);
            }
            Err(RecvTimeoutError::Timeout) => {
                let outcome = active.as_mut().and_then(poll_active_speech);
                if let Some(result) = outcome {
                    let mut completed = active.take().expect("active speech exists");
                    if let Some(sender) = completed.completion.take() {
                        let _ = sender.send(result);
                    }
                    activity.store(!queue.is_empty(), Ordering::SeqCst);
                }
            }
            Err(RecvTimeoutError::Disconnected) => {
                cancel_active(&mut active, "speech worker stopped");
                cancel_queue(&mut queue, "speech worker stopped");
                activity.store(false, Ordering::SeqCst);
                break;
            }
        }
    }
}

fn handle_speech_command(
    command: SpeechCommand,
    active: &mut Option<ActiveSpeech>,
    queue: &mut VecDeque<SpeechRequest>,
) {
    match command {
        SpeechCommand::Speak(request) if request.interrupt => {
            cancel_active(active, "speech was interrupted");
            cancel_queue(queue, "speech queue was overridden");
            *active = start_request(request);
        }
        SpeechCommand::Speak(request) => queue.push_back(request),
        SpeechCommand::Stop => {
            cancel_active(active, "speech was stopped");
            cancel_queue(queue, "speech was stopped");
        }
    }
}

fn start_request(mut request: SpeechRequest) -> Option<ActiveSpeech> {
    let deadline = request.duration.map(|duration| Instant::now() + duration);
    let Some(executable) = request.executable.as_ref() else {
        return Some(ActiveSpeech {
            child: None,
            deadline,
            producer_result: None,
            completion: request.completion,
        });
    };
    let stdin = if request.producer.is_some() {
        Stdio::piped()
    } else {
        Stdio::null()
    };
    let mut child = match Command::new(executable)
        .args(&request.arguments)
        .stdin(stdin)
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
    {
        Ok(child) => child,
        Err(error) => {
            if let Some(sender) = request.completion.take() {
                let _ = sender.send(Err(format!("cannot start speech device: {error}")));
            }
            return None;
        }
    };
    let mut producer_result = None;
    if let Some(producer) = request.producer.take() {
        let Some(mut input) = child.stdin.take() else {
            let _ = child.kill();
            let _ = child.wait();
            if let Some(sender) = request.completion.take() {
                let _ = sender.send(Err("cannot open smoothed singing input".to_string()));
            }
            return None;
        };
        let (sender, receiver) = mpsc::sync_channel(1);
        if let Err(error) = std::thread::Builder::new()
            .name("modernbasic-singing".to_string())
            .spawn(move || {
                let result = producer(&mut input);
                drop(input);
                let _ = sender.send(result);
            })
        {
            let _ = child.kill();
            let _ = child.wait();
            if let Some(sender) = request.completion.take() {
                let _ = sender.send(Err(format!("cannot start singing renderer: {error}")));
            }
            return None;
        }
        producer_result = Some(receiver);
    }
    Some(ActiveSpeech {
        child: Some(child),
        deadline,
        producer_result,
        completion: request.completion,
    })
}

fn poll_active_speech(speech: &mut ActiveSpeech) -> Option<Result<(), String>> {
    if let Some(receiver) = speech.producer_result.as_ref() {
        match receiver.try_recv() {
            Ok(Ok(())) => speech.producer_result = None,
            Ok(Err(error)) => {
                speech.producer_result = None;
                if let Some(mut child) = speech.child.take() {
                    let _ = child.kill();
                    let _ = child.wait();
                }
                return Some(Err(error));
            }
            Err(TryRecvError::Empty) => {}
            Err(TryRecvError::Disconnected) => {
                speech.producer_result = None;
                if let Some(mut child) = speech.child.take() {
                    let _ = child.kill();
                    let _ = child.wait();
                }
                return Some(Err("singing renderer stopped unexpectedly".to_string()));
            }
        }
    }
    if let Some(child) = speech.child.as_mut() {
        match child.try_wait() {
            Ok(Some(status)) if !status.success() => {
                speech.child = None;
                return Some(Err(format!("speech device exited with {status}")));
            }
            Ok(Some(_)) => speech.child = None,
            Ok(None) => {}
            Err(error) => {
                if let Some(mut child) = speech.child.take() {
                    let _ = child.kill();
                    let _ = child.wait();
                }
                return Some(Err(format!("cannot query speech device: {error}")));
            }
        }
    }
    if let Some(deadline) = speech.deadline {
        if Instant::now() < deadline {
            return None;
        }
        if let Some(mut child) = speech.child.take() {
            let _ = child.kill();
            let _ = child.wait();
        }
        return Some(Ok(()));
    }
    (speech.child.is_none() && speech.producer_result.is_none()).then_some(Ok(()))
}

fn cancel_active(active: &mut Option<ActiveSpeech>, reason: &str) {
    let Some(mut speech) = active.take() else {
        return;
    };
    if let Some(mut child) = speech.child.take() {
        let _ = child.kill();
        let _ = child.wait();
    }
    if let Some(sender) = speech.completion.take() {
        let _ = sender.send(Err(reason.to_string()));
    }
}

fn cancel_queue(queue: &mut VecDeque<SpeechRequest>, reason: &str) {
    for mut request in queue.drain(..) {
        if let Some(sender) = request.completion.take() {
            let _ = sender.send(Err(reason.to_string()));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn speech_wait_observes_the_window_interrupt() {
        let interrupt = Arc::new(AtomicBool::new(true));
        crate::interpreter::set_thread_interrupt_flag(Some(Arc::clone(&interrupt)));
        let (_completion, receiver) = mpsc::sync_channel(1);

        assert_eq!(
            wait_for_speech(&SpeechSession::default(), receiver),
            Err(Error::Break)
        );
        assert!(!interrupt.load(Ordering::SeqCst));
        crate::interpreter::set_thread_interrupt_flag(None);
    }

    #[test]
    fn speech_sessions_keep_independent_queue_activity() {
        let first = SpeechSession::default();
        let second = SpeechSession::default();
        assert!(!Arc::ptr_eq(&first.active, &second.active));
        first.active.store(true, Ordering::SeqCst);
        assert!(first.is_active());
        assert!(!second.is_active());
        first.active.store(false, Ordering::SeqCst);
    }

    #[test]
    fn speech_modes_and_bounds_are_checked_without_playing_audio() {
        assert_eq!(SpeechMode::parse("queue").unwrap(), SpeechMode::Queue);
        assert_eq!(
            SpeechMode::parse("interrupt").unwrap(),
            SpeechMode::Interrupt
        );
        assert_eq!(SpeechMode::parse("wait").unwrap(), SpeechMode::Wait);
        for duplicate in ["async", "override", "sync", "unknown"] {
            assert!(SpeechMode::parse(duplicate).is_err());
        }
        let mut session = SpeechSession::default();
        assert_eq!(
            speak(
                &mut session,
                "test",
                39,
                110.0,
                1.0,
                "en-us",
                SpeechMode::Queue,
            )
            .unwrap_err(),
            Error::IllegalQuantity
        );
    }

    #[test]
    fn singing_plan_maps_syllables_rests_notes_velocity_and_tempo() {
        let events =
            plan_singing("Twin-kle star", "C4/4 R/8 D4/8. E4:2@64", 1.0, 120.0, 0.5).unwrap();
        assert_eq!(events.len(), 4);
        assert_eq!(events[0].syllable.as_deref(), Some("Twin"));
        assert_eq!(events[0].duration, Duration::from_millis(500));
        assert_eq!(
            (events[0].pitch, events[0].rate_wpm, events[0].amplitude),
            (50, 120, 100)
        );
        assert_eq!(events[1].syllable, None);
        assert_eq!(events[1].duration, Duration::from_millis(250));
        assert_eq!(events[2].syllable.as_deref(), Some("kle"));
        assert_eq!(events[2].duration, Duration::from_millis(375));
        assert_eq!((events[2].pitch, events[2].rate_wpm), (54, 160));
        assert_eq!(events[3].syllable.as_deref(), Some("star"));
        assert_eq!(events[3].duration, Duration::from_secs(1));
        assert_eq!(
            (events[3].pitch, events[3].rate_wpm, events[3].amplitude),
            (58, 80, 50)
        );
        assert!(plan_singing("low-high", "C2 C6", 1.0, 120.0, 1.0).is_ok());
    }

    #[test]
    fn singing_plan_rejects_ambiguous_unbounded_or_unvocal_scores() {
        for (lyrics, notes) in [
            ("la", "C4 D4"),
            ("la-la", "C4"),
            ("la--la", "C4 D4"),
            ("la", "V1 C4"),
            ("la", "C1"),
            ("la", "C7"),
            ("la", "C4:0.01"),
        ] {
            assert!(
                plan_singing(lyrics, notes, 1.0, 1_000.0, 1.0).is_err(),
                "{lyrics:?} {notes:?}"
            );
        }
        assert!(plan_singing("la", "C4:64", 1.0, 1.0, 1.0).is_err());

        let lyrics = vec!["la"; MAX_SING_EVENTS + 1].join("-");
        let notes = vec!["C4/64"; MAX_SING_EVENTS + 1].join(" ");
        assert_eq!(
            plan_singing(&lyrics, &notes, 1.0, 120.0, 1.0).unwrap_err(),
            Error::IllegalQuantity
        );
    }

    fn test_mono_wav(samples: &[i16], sample_rate: u32) -> Vec<u8> {
        let data_bytes = samples.len() * 2;
        let mut wav = Vec::with_capacity(44 + data_bytes);
        wav.extend_from_slice(b"RIFF");
        wav.extend_from_slice(&(36 + data_bytes as u32).to_le_bytes());
        wav.extend_from_slice(b"WAVEfmt ");
        wav.extend_from_slice(&16_u32.to_le_bytes());
        wav.extend_from_slice(&1_u16.to_le_bytes());
        wav.extend_from_slice(&1_u16.to_le_bytes());
        wav.extend_from_slice(&sample_rate.to_le_bytes());
        wav.extend_from_slice(&(sample_rate * 2).to_le_bytes());
        wav.extend_from_slice(&2_u16.to_le_bytes());
        wav.extend_from_slice(&16_u16.to_le_bytes());
        wav.extend_from_slice(b"data");
        wav.extend_from_slice(&(data_bytes as u32).to_le_bytes());
        for sample in samples {
            wav.extend_from_slice(&sample.to_le_bytes());
        }
        wav
    }

    #[test]
    fn singing_wav_decoder_accepts_pcm_and_rejects_invalid_audio() {
        let wav = test_mono_wav(&[i16::MIN, 0, i16::MAX], 22_050);
        let decoded = decode_pcm_wav(&wav).unwrap();
        assert_eq!(decoded.sample_rate, 22_050);
        assert_eq!(decoded.samples.len(), 3);
        assert!(decoded.samples[0] <= -1.0);
        assert_eq!(decoded.samples[1], 0.0);
        assert_eq!(decoded.samples[2], 1.0);
        assert!(decode_pcm_wav(b"not a wave").is_err());
    }

    #[test]
    fn smoothed_singing_preserves_timing_crossfades_and_reverb_decay() {
        let event = |syllable| SingingEvent {
            syllable,
            duration: Duration::from_millis(40),
            rate_wpm: 120,
            pitch: 50,
            amplitude: 100,
        };
        let events = vec![
            event(Some("one".to_string())),
            event(Some("two".to_string())),
            event(None),
        ];
        let clip_frames = SING_SAMPLE_RATE as usize * 60 / 1_000;
        let mut pcm = Vec::new();
        render_smoothed_singing_with(&events, &mut pcm, |_| {
            Ok(MonoPcm {
                sample_rate: SING_SAMPLE_RATE,
                samples: vec![0.4; clip_frames],
            })
        })
        .unwrap();

        let event_frames = SING_SAMPLE_RATE as usize * 40 / 1_000;
        assert_eq!(pcm.len(), event_frames * events.len() * 4);
        let left = |frame: usize| {
            let offset = frame * 4;
            i16::from_le_bytes([pcm[offset], pcm[offset + 1]]) as f32 / i16::MAX as f32
        };
        assert!(left(0).abs() < left(100).abs());
        assert!(left(event_frames).abs() > 0.2);
        assert!(left(event_frames * 2 + 800).abs() > 0.001);
    }

    #[test]
    fn retained_singing_scores_render_sequential_44khz_stereo_wav() {
        let event = |syllable: &str| SingingEvent {
            syllable: Some(syllable.to_string()),
            duration: Duration::from_millis(40),
            rate_wpm: 120,
            pitch: 50,
            amplitude: 100,
        };
        let scores = vec![
            SingingScore {
                events: vec![event("one")],
                voice: "voice-a".to_string(),
            },
            SingingScore {
                events: vec![event("two")],
                voice: "voice-b".to_string(),
            },
        ];
        let clip_frames = SING_SAMPLE_RATE as usize * 60 / 1_000;
        let mut rendered_voices = Vec::new();
        let wav = render_singing_scores_wav_with(&scores, |voice, _| {
            rendered_voices.push(voice.to_string());
            Ok(MonoPcm {
                sample_rate: SING_SAMPLE_RATE,
                samples: vec![0.25; clip_frames],
            })
        })
        .unwrap();

        let expected_frames = SING_SAMPLE_RATE as usize * 80 / 1_000;
        assert_eq!(&wav[..4], b"RIFF");
        assert_eq!(&wav[8..12], b"WAVE");
        assert_eq!(u32::from_le_bytes(wav[24..28].try_into().unwrap()), 44_100);
        assert_eq!(u16::from_le_bytes(wav[22..24].try_into().unwrap()), 2);
        assert_eq!(wav.len(), 44 + expected_frames * 4);
        assert!(wav[44..].iter().any(|byte| *byte != 0));
        assert_eq!(rendered_voices, ["voice-a", "voice-b"]);
    }

    #[test]
    fn singing_renderer_errors_reach_the_active_request() {
        let (sender, receiver) = mpsc::sync_channel(1);
        sender.send(Err("render failed".to_string())).unwrap();
        let mut active = ActiveSpeech {
            child: None,
            deadline: None,
            producer_result: Some(receiver),
            completion: None,
        };
        assert_eq!(
            poll_active_speech(&mut active),
            Some(Err("render failed".to_string()))
        );
    }

    #[test]
    fn timed_rest_completes_only_after_its_deadline() {
        let mut future = ActiveSpeech {
            child: None,
            deadline: Some(Instant::now() + Duration::from_secs(1)),
            producer_result: None,
            completion: None,
        };
        assert_eq!(poll_active_speech(&mut future), None);

        let mut expired = ActiveSpeech {
            child: None,
            deadline: Some(Instant::now() - Duration::from_millis(1)),
            producer_result: None,
            completion: None,
        };
        assert_eq!(poll_active_speech(&mut expired), Some(Ok(())));
    }
}
