//! Architecture mapping for the `modernbasic` side-by-side port of Microsoft BASIC.
//!
//! The original Microsoft BASIC for 6502 source tree is organised into files
//! that each own a distinct subsystem.  This crate keeps the same conceptual
//! boundaries but re-implements them with Rust-native 64-bit types, checked
//! arithmetic and explicit error handling instead of 6502 zero-page registers.
//!
//! | Original 6502 file | Responsibility in the original source            | `modernbasic` module |
//! |--------------------|--------------------------------------------------|-------------------|
//! | `token.s`          | Keyword tables, token-byte assignment and RTS/address vector tables. | [`crate::tokens`] |
//! | `program.s`        | Line input, tokenisation, detokenisation, numbered-line storage, `NEW`, `LIST`, `LOAD`, `SAVE`, `VERIFY`, error printing and warm restart. | [`crate::program`], [`crate::file_io`], [`crate::interpreter`] |
//! | `eval.s`           | Expression evaluation, operator precedence and relational operators. | [`crate::eval`] |
//! | `misc2.s`          | Numeric `DEF FN` definitions, scoped argument binding and invocation, plus `POS` and `FRE`. | `user_functions`, [`crate::functions`], [`crate::eval`], [`crate::interpreter`] |
//! | `flow1.s`, `flow2.s` | Statement dispatch, branching and program execution. | [`crate::interpreter`] (bounded native statement slice) |
//! | `memory.s`         | Generic block move (`BLTU`), stack/memory safety checks (`CHKMEM`, `REASON`), free-memory reporting, and `FOR`/`NEXT` frame scanning. | [`crate::address`], [`crate::storage`], and memory-safe helpers in [`crate::program`] |
//! | `float.s`          | Floating-point arithmetic, numeric formatting, `SGN`/`INT`/`ABS`, and transcendental helpers. | [`crate::real`], [`crate::arithmetic`], [`crate::integer`], [`crate::functions`] (checked native equivalents; original FP representation and algorithms remain out of scope) |
//! | `rnd.s`            | Stateful `RND`, seed storage and platform entropy variants. | [`crate::random`], [`crate::functions`], [`crate::eval`], [`crate::interpreter`] (explicitly seeded native state; no device entropy) |
//! | `input.s`          | `DATA`, `READ`, `RESTORE`, interactive `INPUT`/`GET`, and conditional `INPUT#`/`GET#`. | [`crate::data`], [`crate::input`], [`crate::file_io`], [`crate::interpreter`] (native injected readers and sandboxed files; no device emulation) |
//! | `print.s`, `misc2.s` | Value output, comma zones, `TAB`, `SPC`, and output-position tracking. | `output`, [`crate::functions`], [`crate::eval`], [`crate::interpreter`] (native columns; no display emulation) |
//! | `misc1.s`, `print.s` (`CONFIG_FILE`) | Device-channel `OPEN`, `CLOSE`, `PRINT#`, and KERNAL routing. | [`crate::file_io`], [`crate::interpreter`] (bounded host files under an explicit root) |
//! | `var.s`, `array.s` | Variable lookup, suffix-based typing, `DIM` and array subscript/offset handling. | [`crate::value`], [`crate::arrays`], [`crate::eval`], [`crate::interpreter`] |
//!
//! The mapping is deliberately a *side-by-side port*.  No existing `.s`, `.cfg`,
//! `.sh`, `README.md` or `orig/*.bin` file is modified; this crate lives in a new
//! `modernbasic/` directory and talks in 64-bit integers rather than trying to
//! widen the 6502 binary or zero-page layout.
//!
//! Numeric policy
//! --------------
//! * `token.s` token codes are preserved in spirit: keyword bytes start at
//!   `0x80` and follow the order shown in `token.s` for the tokens present in
//!   this slice.
//! * Exact integers use [`crate::integer::BasicInteger`] backed by checked
//!   `i64`; decimal/exponent values use finite [`crate::real::BasicReal`]
//!   binary64. Mixed operations require exact integer promotion, and all
//!   non-finite results are rejected.
//! * Core functions with deterministic numeric/string meanings live in
//!   [`crate::functions`]. Power and core mathematical functions use checked
//!   native operations. `RND` uses caller-owned deterministic state;
//!   host-memory and device functions return explicit unsupported errors.
//! * `misc2.s` user functions map to a dedicated definition store and native
//!   recursive expression evaluation with a configurable depth limit. Numeric
//!   parameters shadow variables only for the duration of one call.
//! * `memory.s` 16-bit pointers become [`crate::address::VirtualAddress`]
//!   (`u64`) which is only converted to `usize` through checked, bounds-checked
//!   APIs.
//! * `memory.s` free-space checks become a run-owned [`crate::storage::StorageBudget`]
//!   shared by retained scalar and sparse-array value payloads. Runtime `FRE`
//!   reports that deterministic quota rather than host or emulated memory;
//!   replacement and reset operations release charges exactly.
//! * `var.s` / `array.s` array handling is implemented natively in
//!   [`crate::arrays`] using sparse hash maps and checked row-major offset
//!   arithmetic.  No 6502 memory layout or emulator is used.
//! * `flow2.s` control flow maps to a native statement program counter:
//!   inline `IF` bodies reuse the checked statement dispatcher, while `ON`
//!   target lists use checked 64-bit selectors and the bounded Rust call stack.
//!   `RUN` rebuilds execution at the first or an exact line while preserving
//!   the enclosing step budget and other run-owned resources.
//! * `program.s` `CLEARC` maps to explicit collection resets that preserve
//!   configured limits and program execution state; no address-table or stack
//!   pointer manipulation is reproduced.
//! * `program.s` `LIST` and `NEW` operate on the active ordered [`crate::program::Program`]
//!   copy. Listing serialization is bounded before output, and successful runs
//!   return the final active store without an emulated prompt or monitor.
//! * One-shot completion reports why execution returned. A retained native
//!   execution session owns every runtime store and exact statement index so
//!   host `resume` can implement `CONT` semantics after `STOP`; no historical
//!   pointer, global prompt, or reconstructed state is used.
//! * Conditional file tokens are appended after the stable core token range.
//!   File channels are native bounded handles rooted under a caller-selected
//!   directory; device numbers and KERNAL vectors are not simulated.
//! * `print.s` formatting maps to independently tracked native stream columns,
//!   fixed 14-column zones, and bounded padding. No terminal width, cursor, or
//!   display device is queried or simulated.
//! * `LOAD`, `SAVE`, and `VERIFY` operate on bounded canonical numbered UTF-8 source in
//!   that same root. A successful load rebuilds native execution from the new
//!   program while preserving the enclosing run's limits, step budget, RNG,
//!   standard streams, and already-open channels.

#![allow(rustdoc::invalid_html_tags)]
