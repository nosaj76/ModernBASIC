//! Deterministic native BASIC built-in functions.
//!
//! This module implements deterministic numeric and string functions that fit
//! the current runtime value model. `RND` mutates explicitly supplied native
//! generator state. Runtime `POS` consumes an explicit native stream column,
//! while `FRE` reports a caller-owned deterministic storage quota. `PEEK`,
//! `INP`, `USR`, and related host-facing operations are connected to bounded
//! virtual memory, virtual ports, or explicitly registered native services by
//! the active execution session; raw host memory and privileged x86 ports are
//! never exposed directly.

use crate::complex::BasicComplex;
use crate::error::Error;
use crate::integer::{BasicInteger, NumericMode};
use crate::math_engine;
use crate::random::BasicRng;
use crate::real::BasicReal;
use crate::tokens::Token;
use crate::value::Value;

/// Whether a keyword is a built-in function token handled by expression
/// parsing.
pub(crate) fn is_builtin_function(token: Token) -> bool {
    matches!(
        token,
        Token::Sgn
            | Token::Int
            | Token::Abs
            | Token::Usr
            | Token::Fre
            | Token::Pos
            | Token::Sqr
            | Token::Rnd
            | Token::Log
            | Token::Exp
            | Token::Cos
            | Token::Sin
            | Token::Tan
            | Token::Atn
            | Token::Peek
            | Token::Len
            | Token::Str
            | Token::Val
            | Token::Asc
            | Token::Chr
            | Token::Left
            | Token::Right
            | Token::Mid
            | Token::Round
            | Token::Ipart
            | Token::Fpart
            | Token::Min
            | Token::Max
            | Token::Lcm
            | Token::Gcd
            | Token::Remainder
            | Token::Asin
            | Token::Acos
            | Token::Sinh
            | Token::Cosh
            | Token::Tanh
            | Token::Asinh
            | Token::Acosh
            | Token::Atanh
            | Token::Ln
            | Token::Log10
            | Token::LogBase
            | Token::Cbrt
            | Token::Root
            | Token::Cube
            | Token::Fact
            | Token::Npr
            | Token::Ncr
            | Token::Deg
            | Token::Rad
            | Token::Pi
            | Token::Rand
            | Token::RandInt
            | Token::RandNorm
            | Token::RandBin
            | Token::FracString
            | Token::Complex
            | Token::RealPart
            | Token::Imag
            | Token::Conj
            | Token::Angle
            | Token::RandIntNoRep
            | Token::Mean
            | Token::Median
    )
}

/// Named extensions intentionally remain identifier-encoded because the
/// historical one-byte token space is full. They still parse deterministically
/// and round-trip through the canonical program format.
pub(crate) fn is_named_builtin(name: &str) -> bool {
    math_engine::is_builtin(name)
        || matches!(
            name,
            "DEC"
                | "NORMALPDF"
                | "NORMALCDF"
                | "INVNORM"
                | "BINOMPDF"
                | "BINOMCDF"
                | "GEOMETPDF"
                | "GEOMETCDF"
                | "POISSONPDF"
                | "POISSONCDF"
                | "COMB"
                | "PERM"
                | "VARP"
                | "VARS"
                | "VARIANCE"
                | "STD"
                | "STDDEV"
                | "STDEV"
                | "STDEVP"
                | "STDEVS"
                | "CORREL"
                | "LINREG"
                | "INSTR"
                | "BIN$"
                | "HEX$"
                | "OCT$"
                | "MKI$"
                | "MKL$"
                | "MKD$"
                | "CVI"
                | "CVS"
                | "CVL"
                | "CVD"
                | "STRING$"
                | "SPACE$"
                | "UCASE$"
                | "LCASE$"
                | "LTRIM$"
                | "RTRIM$"
                | "TRIM$"
                | "CINT"
                | "FIX"
                | "CDBL"
                | "CSNG"
                | "VARPTR"
                | "CSRLIN"
                | "INKEY$"
                | "INPUT$"
                | "MULTIKEY"
                | "POINT"
                | "SCRN"
                | "PMAP"
                | "DATE$"
                | "TIME$"
                | "STICK"
                | "STRIG"
                | "PEN"
                | "FORMAT$"
                | "CURDIR$"
                | "SCREENINFO"
                | "RGB"
                | "RGBA"
        )
}

pub(crate) fn evaluate_named_builtin(
    name: &str,
    args: &[Value],
    max_string_bytes: usize,
) -> Result<Value, Error> {
    if math_engine::is_builtin(name) {
        return math_engine::evaluate(name, args);
    }
    if matches!(
        name,
        "VARP"
            | "VARS"
            | "VARIANCE"
            | "STD"
            | "STDDEV"
            | "STDEV"
            | "STDEVP"
            | "STDEVS"
            | "CORREL"
            | "LINREG"
    ) {
        return named_list_statistic(name, args);
    }
    if args.iter().any(|value| matches!(value, Value::List(_))) {
        let length = args
            .iter()
            .find_map(|value| match value {
                Value::List(values) => Some(values.len()),
                _ => None,
            })
            .unwrap_or(0);
        if args
            .iter()
            .any(|value| matches!(value, Value::List(values) if values.len() != length))
        {
            return Err(Error::IllegalQuantity);
        }
        let mut values = Vec::with_capacity(length);
        for index in 0..length {
            let scalar = args
                .iter()
                .map(|value| match value {
                    Value::List(values) => values[index].clone(),
                    value => value.clone(),
                })
                .collect::<Vec<_>>();
            let value = evaluate_named_builtin(name, &scalar, max_string_bytes)?;
            if matches!(value, Value::List(_) | Value::String(_)) {
                return Err(Error::TypeMismatch);
            }
            values.push(value);
        }
        return Ok(Value::List(values));
    }
    match name {
        "DEC" => decimal_conversion(args),
        "NORMALPDF" => normal_pdf(args),
        "NORMALCDF" => normal_cdf(args),
        "INVNORM" => inverse_normal(args),
        "BINOMPDF" => binomial_distribution(args, false),
        "BINOMCDF" => binomial_distribution(args, true),
        "GEOMETPDF" => geometric_distribution(args, false),
        "GEOMETCDF" => geometric_distribution(args, true),
        "POISSONPDF" => poisson_distribution(args, false),
        "POISSONCDF" => poisson_distribution(args, true),
        "COMB" => combinatoric(Token::Ncr, args, CombinatoricOperation::Combination),
        "PERM" => combinatoric(Token::Npr, args, CombinatoricOperation::Permutation),
        "INSTR" => eval_instr(args),
        "BIN$" => eval_bin(args),
        "HEX$" => eval_hex(args),
        "OCT$" => eval_oct(args),
        "MKI$" => eval_mki(args),
        "MKL$" => eval_mkl(args),
        "MKD$" => eval_mkd(args),
        "CVI" => eval_cvi(args),
        "CVS" => eval_cvs(args),
        "CVL" => eval_cvl(args),
        "CVD" => eval_cvd(args),
        "STRING$" => eval_string_func(args, max_string_bytes),
        "SPACE$" => eval_space(args, max_string_bytes),
        "UCASE$" => eval_ascii_case(args, "UCASE$", true),
        "LCASE$" => eval_ascii_case(args, "LCASE$", false),
        "LTRIM$" => eval_trim(args, "LTRIM$", TrimSide::Left),
        "RTRIM$" => eval_trim(args, "RTRIM$", TrimSide::Right),
        "TRIM$" => eval_trim(args, "TRIM$", TrimSide::Both),
        "CINT" => eval_cint(args),
        "FIX" => eval_fix(args),
        "CDBL" => eval_cdbl(args),
        "CSNG" => eval_csng(args),
        "VARPTR" => Ok(Value::Integer(0)),
        "CSRLIN" => {
            if !args.is_empty() {
                return Err(Error::syntax("CSRLIN expects no arguments"));
            }
            Ok(Value::Integer(1))
        }
        "INKEY$" => Ok(Value::String(String::new())),
        "INPUT$" => Err(Error::syntax("INPUT$ requires active statement input")),
        "MULTIKEY" => {
            let [keycode] = args else {
                return Err(Error::syntax("MULTIKEY expects one keycode"));
            };
            let keycode = keycode.to_integer()?;
            if !(1..=255).contains(&keycode) {
                return Err(Error::IllegalQuantity);
            }
            Ok(Value::Integer(crate::screen::multikey(keycode as u8)))
        }
        "POINT" | "SCRN" | "PMAP" => Err(Error::syntax(format!(
            "{name} requires an active graphics session"
        ))),
        "STICK" => {
            let [selector] = args else {
                return Err(Error::syntax("STICK expects one selector"));
            };
            Ok(Value::Integer(crate::devices::stick(
                selector.to_integer()?,
            )?))
        }
        "STRIG" => {
            let [selector] = args else {
                return Err(Error::syntax("STRIG expects one selector"));
            };
            Ok(Value::Integer(crate::devices::strig(
                selector.to_integer()?,
            )?))
        }
        "PEN" => {
            let [selector] = args else {
                return Err(Error::syntax("PEN expects one selector"));
            };
            let state = crate::screen::pointer_state();
            // Modern64-specific pointer mapping: 0 is any-button state, 1/2
            // current coordinates, 3 raster containment, 4/5 last press, 6/7
            // legacy last-release aliases, and 8/9 canonical last release.
            let value = match selector.to_integer()? {
                0 => -i64::from(state.buttons != 0),
                1 => state.x,
                2 => state.y,
                3 => -i64::from(state.inside),
                4 => state.last_press_x,
                5 => state.last_press_y,
                6 => state.last_release_x,
                7 => state.last_release_y,
                8 => state.last_release_x,
                9 => state.last_release_y,
                _ => return Err(Error::IllegalQuantity),
            };
            Ok(Value::Integer(value))
        }
        "FORMAT$" => {
            let [value, format] = args else {
                return Err(Error::syntax("FORMAT$ expects value, format-string"));
            };
            let format = format.as_str().ok_or(Error::TypeMismatch)?;
            Ok(Value::String(crate::interpreter::format_value(
                value, format,
            )?))
        }
        "RGB" => eval_color_constructor(args, false),
        "RGBA" => eval_color_constructor(args, true),
        "DATE$" => eval_date(),
        "TIME$" => eval_time(),
        _ => Err(Error::syntax(format!("unknown function {name}"))),
    }
}

/// Build the canonical true-color string consumed by every graphics
/// statement.  A string result deliberately keeps packed colors distinct
/// from classic numeric palette indices.
fn eval_color_constructor(args: &[Value], with_alpha: bool) -> Result<Value, Error> {
    let expected = if with_alpha { 4 } else { 3 };
    if args.len() != expected {
        let name = if with_alpha { "RGBA" } else { "RGB" };
        return Err(Error::syntax(format!(
            "{name} expects {expected} color channels"
        )));
    }
    let mut channels = [255_u8; 4];
    for (index, value) in args.iter().enumerate() {
        let channel = integer_arg(value).map_err(|error| match error {
            Error::IntegerRequired => Error::IllegalQuantity,
            other => other,
        })?;
        channels[index] = u8::try_from(channel).map_err(|_| Error::IllegalQuantity)?;
    }
    if with_alpha {
        Ok(Value::String(format!(
            "#{:02x}{:02x}{:02x}{:02x}",
            channels[0], channels[1], channels[2], channels[3]
        )))
    } else {
        Ok(Value::String(format!(
            "#{:02x}{:02x}{:02x}",
            channels[0], channels[1], channels[2]
        )))
    }
}

/// Evaluate a built-in after the parser has evaluated all argument
/// expressions.
pub(crate) fn evaluate_builtin(
    token: Token,
    args: Vec<Value>,
    mode: NumericMode,
    max_string_bytes: usize,
    rng: &mut BasicRng,
) -> Result<Value, Error> {
    use Token::*;

    if let Some(result) = evaluate_list_builtin(token, &args, mode, max_string_bytes, rng) {
        return result;
    }

    match token {
        Sgn => {
            let value = one_numeric(token, &args)?;
            let sign = match value {
                Value::Integer(value) => value.signum(),
                Value::Real(value) => value.signum(),
                Value::Complex(_) | Value::List(_) | Value::String(_) => {
                    return Err(Error::TypeMismatch)
                }
            };
            Ok(Value::Integer(sign))
        }
        Int => match one_numeric(token, &args)? {
            Value::Integer(value) => Ok(Value::Integer(*value)),
            Value::Real(value) => Ok(Value::Real(value.floor()?)),
            Value::Complex(_) | Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
        },
        Abs => match one_numeric(token, &args)? {
            Value::Integer(value) => {
                let absolute = value.checked_abs().ok_or(Error::IntegerOverflow)?;
                Ok(Value::Integer(
                    BasicInteger::with_mode(mode, absolute)?.value(),
                ))
            }
            Value::Real(value) => Ok(Value::Real(value.abs()?)),
            Value::Complex(value) => Ok(Value::Real(value.magnitude()?)),
            Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
        },
        Len => {
            let value = one_string(token, &args)?;
            let length =
                i64::try_from(value.chars().count()).map_err(|_| Error::IntegerOverflow)?;
            Ok(Value::Integer(
                BasicInteger::with_mode(mode, length)?.value(),
            ))
        }
        Str => {
            let value = one_numeric(token, &args)?;
            let negative = match value {
                Value::Integer(value) => *value < 0,
                Value::Real(value) => value.value() < 0.0,
                Value::Complex(_) | Value::List(_) | Value::String(_) => {
                    return Err(Error::TypeMismatch)
                }
            };
            let rendered = value.to_string();
            let text = if negative {
                rendered
            } else {
                format!(" {rendered}")
            };
            checked_string(text, max_string_bytes)
        }
        Val => {
            let text = one_string(token, &args)?;
            parse_numeric_prefix(text, mode)
        }
        Asc => {
            let text = one_string(token, &args)?;
            let code = text.chars().next().ok_or(Error::IllegalQuantity)? as u32;
            if code > 255 {
                return Err(Error::IllegalQuantity);
            }
            Ok(Value::Integer(
                BasicInteger::with_mode(mode, i64::from(code))?.value(),
            ))
        }
        Chr => {
            let code = one_integer(token, &args)?;
            if !(0..=255).contains(&code) {
                return Err(Error::IllegalQuantity);
            }
            let character = char::from_u32(code as u32).ok_or(Error::IllegalQuantity)?;
            checked_string(character.to_string(), max_string_bytes)
        }
        Left => {
            expect_arity(token, &args, 2, 2)?;
            let text = string_arg(&args[0])?;
            let count = nonnegative_count(integer_arg(&args[1])?)?;
            checked_string(left_chars(text, count), max_string_bytes)
        }
        Right => {
            expect_arity(token, &args, 2, 2)?;
            let text = string_arg(&args[0])?;
            let count = nonnegative_count(integer_arg(&args[1])?)?;
            checked_string(right_chars(text, count), max_string_bytes)
        }
        Mid => {
            expect_arity(token, &args, 2, 3)?;
            let text = string_arg(&args[0])?;
            let start = integer_arg(&args[1])?;
            if start <= 0 {
                return Err(Error::IllegalQuantity);
            }
            let length = args
                .get(2)
                .map(integer_arg)
                .transpose()?
                .map(nonnegative_count)
                .transpose()?;
            checked_string(mid_chars(text, start, length), max_string_bytes)
        }
        Sqr => complex_or_real_unary(token, &args, BasicComplex::sqrt, BasicReal::sqrt),
        Log => complex_or_real_unary(token, &args, BasicComplex::ln, BasicReal::ln),
        Exp => complex_or_real_unary(token, &args, BasicComplex::exp, BasicReal::exp),
        Cos => complex_or_real_unary(token, &args, BasicComplex::cos, BasicReal::cos),
        Sin => complex_or_real_unary(token, &args, BasicComplex::sin, BasicReal::sin),
        Tan => complex_or_real_unary(token, &args, BasicComplex::tan, BasicReal::tan),
        Atn => complex_or_real_unary(token, &args, BasicComplex::atan, BasicReal::atan),
        Asin => complex_or_real_unary(token, &args, BasicComplex::asin, BasicReal::asin),
        Acos => complex_or_real_unary(token, &args, BasicComplex::acos, BasicReal::acos),
        Sinh => complex_or_real_unary(token, &args, BasicComplex::sinh, BasicReal::sinh),
        Cosh => complex_or_real_unary(token, &args, BasicComplex::cosh, BasicReal::cosh),
        Tanh => complex_or_real_unary(token, &args, BasicComplex::tanh, BasicReal::tanh),
        Asinh => complex_or_real_unary(token, &args, BasicComplex::asinh, BasicReal::asinh),
        Acosh => complex_or_real_unary(token, &args, BasicComplex::acosh, BasicReal::acosh),
        Atanh => complex_or_real_unary(token, &args, BasicComplex::atanh, BasicReal::atanh),
        Ln => natural_log(&args),
        Log10 => complex_or_real_unary(token, &args, BasicComplex::log10, BasicReal::log10),
        LogBase => logarithm_with_base(&args),
        Cbrt => complex_or_real_unary(token, &args, complex_cbrt, BasicReal::cbrt),
        Root => nth_root(&args),
        Cube => cube(&args),
        Fact => factorial(&args),
        Npr => combinatoric(token, &args, CombinatoricOperation::Permutation),
        Ncr => combinatoric(token, &args, CombinatoricOperation::Combination),
        Deg => complex_angle_conversion(token, &args, 180.0 / std::f64::consts::PI),
        Rad => complex_angle_conversion(token, &args, std::f64::consts::PI / 180.0),
        Pi => {
            expect_arity(token, &args, 0, 0)?;
            Ok(Value::Real(BasicReal::new(std::f64::consts::PI)?))
        }
        Rand => random_units(&args, rng),
        RandInt => random_integer(&args, mode, rng),
        RandNorm => random_normal(&args, rng),
        RandBin => random_binomial(&args, mode, rng),
        FracString => fraction_string(&args, max_string_bytes),
        Complex => complex_value(&args),
        RealPart => real_part(&args),
        Imag => imaginary_part(&args),
        Conj => conjugate(&args),
        Angle => complex_angle(&args),
        RandIntNoRep => random_integer_without_replacement(&args, mode, rng),
        Mean | Median => Err(Error::TypeMismatch),
        Round => round_value(&args),
        Ipart => integer_part(&args),
        Fpart => fractional_part(&args),
        Min => numeric_extreme(token, &args, true),
        Max => numeric_extreme(token, &args, false),
        Lcm => integer_pair(token, &args, mode, IntegerPairOperation::Lcm),
        Gcd => integer_pair(token, &args, mode, IntegerPairOperation::Gcd),
        Remainder => integer_pair(token, &args, mode, IntegerPairOperation::Remainder),
        Rnd => Ok(Value::Real(rng.rnd(one_real(token, &args)?)?)),
        Usr => {
            expect_arity(token, &args, 1, 1)?;
            Err(Error::SystemServiceNotRegistered { address: 0 })
        }
        Fre => evaluate_free(&args, mode, max_string_bytes),
        Pos => evaluate_position(&args, mode, 0),
        Peek => {
            let address = one_integer(token, &args)?;
            if !(0..1_048_576).contains(&address) {
                return Err(Error::IllegalQuantity);
            }
            Ok(Value::Integer(0))
        }
        _ => Err(Error::syntax(format!(
            "{} is not a built-in function",
            token.to_text()
        ))),
    }
}

/// Evaluate runtime-backed `POS(dummy)` after its argument has been evaluated.
pub(crate) fn evaluate_position(
    args: &[Value],
    mode: NumericMode,
    column: usize,
) -> Result<Value, Error> {
    one_numeric(Token::Pos, args)?;
    let column = i64::try_from(column).map_err(|_| Error::IntegerOverflow)?;
    Ok(Value::Integer(
        BasicInteger::with_mode(mode, column)?.value(),
    ))
}

/// Evaluate runtime-backed `FRE(dummy)` against retained-value storage.
///
/// The argument is evaluated by the expression parser and otherwise ignored,
/// matching BASIC's query-style interface. The returned count is exact when it
/// fits the selected numeric mode.
pub(crate) fn evaluate_free(
    args: &[Value],
    mode: NumericMode,
    remaining_bytes: usize,
) -> Result<Value, Error> {
    expect_arity(Token::Fre, args, 1, 1)?;
    let remaining = i64::try_from(remaining_bytes).map_err(|_| Error::IntegerOverflow)?;
    Ok(Value::Integer(
        BasicInteger::with_mode(mode, remaining)?.value(),
    ))
}

#[allow(clippy::too_many_arguments)]
fn evaluate_list_builtin(
    token: Token,
    args: &[Value],
    mode: NumericMode,
    max_string_bytes: usize,
    rng: &mut BasicRng,
) -> Option<Result<Value, Error>> {
    if token == Token::Len {
        if let [Value::List(values)] = args {
            let length = i64::try_from(values.len()).map_err(|_| Error::IntegerOverflow);
            return Some(length.and_then(|length| {
                Ok(Value::Integer(
                    BasicInteger::with_mode(mode, length)?.value(),
                ))
            }));
        }
    }
    if matches!(token, Token::Mean | Token::Median) {
        return Some(list_statistic(token, args));
    }
    if matches!(token, Token::Min | Token::Max) {
        if let [Value::List(values)] = args {
            return Some(list_extreme(token, values));
        }
    }

    let list_compatible = matches!(
        token,
        Token::Sgn
            | Token::Int
            | Token::Abs
            | Token::Sqr
            | Token::Log
            | Token::Exp
            | Token::Cos
            | Token::Sin
            | Token::Tan
            | Token::Atn
            | Token::Round
            | Token::Ipart
            | Token::Fpart
            | Token::Min
            | Token::Max
            | Token::Lcm
            | Token::Gcd
            | Token::Remainder
            | Token::Asin
            | Token::Acos
            | Token::Sinh
            | Token::Cosh
            | Token::Tanh
            | Token::Asinh
            | Token::Acosh
            | Token::Atanh
            | Token::Ln
            | Token::Log10
            | Token::LogBase
            | Token::Cbrt
            | Token::Root
            | Token::Cube
            | Token::Fact
            | Token::Npr
            | Token::Ncr
            | Token::Deg
            | Token::Rad
            | Token::RealPart
            | Token::Imag
            | Token::Conj
            | Token::Angle
    );
    if !list_compatible || !args.iter().any(|value| matches!(value, Value::List(_))) {
        return None;
    }

    let length = args
        .iter()
        .filter_map(|value| match value {
            Value::List(values) => Some(values.len()),
            _ => None,
        })
        .next()
        .unwrap_or(0);
    if args
        .iter()
        .any(|value| matches!(value, Value::List(values) if values.len() != length))
    {
        return Some(Err(Error::IllegalQuantity));
    }
    let mut result = Vec::with_capacity(length);
    for index in 0..length {
        let scalar_args = args
            .iter()
            .map(|value| match value {
                Value::List(values) => values[index].clone(),
                value => value.clone(),
            })
            .collect();
        match evaluate_builtin(token, scalar_args, mode, max_string_bytes, rng) {
            Ok(Value::List(_) | Value::String(_)) => return Some(Err(Error::TypeMismatch)),
            Ok(value) => result.push(value),
            Err(error) => return Some(Err(error)),
        }
    }
    Some(Ok(Value::List(result)))
}

fn list_extreme(token: Token, values: &[Value]) -> Result<Value, Error> {
    let Some(mut selected) = values.first().cloned() else {
        return Err(Error::IllegalQuantity);
    };
    for value in &values[1..] {
        let ordering = compare_numeric_values(&selected, value)?;
        let replace = if token == Token::Min {
            ordering.is_gt()
        } else {
            ordering.is_lt()
        };
        if replace {
            selected = value.clone();
        }
    }
    Ok(selected)
}

fn list_statistic(token: Token, args: &[Value]) -> Result<Value, Error> {
    expect_arity(token, args, 1, 1)?;
    let Value::List(values) = &args[0] else {
        return Err(Error::TypeMismatch);
    };
    if values.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    let mut numbers = values.iter().map(real_arg).collect::<Result<Vec<_>, _>>()?;
    if token == Token::Mean {
        let mut total = BasicReal::zero();
        for value in numbers {
            total = total.add(value)?;
        }
        let count = BasicReal::from_integer(
            i64::try_from(values.len()).map_err(|_| Error::IntegerOverflow)?,
        )?;
        return Ok(Value::Real(total.div(count)?));
    }
    numbers.sort_by(|left, right| {
        left.value()
            .partial_cmp(&right.value())
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    let middle = numbers.len() / 2;
    if numbers.len() % 2 == 1 {
        Ok(Value::Real(numbers[middle]))
    } else {
        Ok(Value::Real(
            numbers[middle - 1]
                .add(numbers[middle])?
                .div(BasicReal::new(2.0)?)?,
        ))
    }
}

fn expect_arity(token: Token, args: &[Value], min: usize, max: usize) -> Result<(), Error> {
    if (min..=max).contains(&args.len()) {
        return Ok(());
    }
    let expected = if min == max {
        min.to_string()
    } else {
        format!("{min} or {max}")
    };
    Err(Error::syntax(format!(
        "{} expects {expected} argument(s), got {}",
        token.to_text(),
        args.len()
    )))
}

fn one_integer(token: Token, args: &[Value]) -> Result<i64, Error> {
    expect_arity(token, args, 1, 1)?;
    integer_arg(&args[0])
}

fn one_numeric(token: Token, args: &[Value]) -> Result<&Value, Error> {
    expect_arity(token, args, 1, 1)?;
    if args[0].is_numeric() {
        Ok(&args[0])
    } else {
        Err(Error::TypeMismatch)
    }
}

fn one_real(token: Token, args: &[Value]) -> Result<BasicReal, Error> {
    real_arg(one_numeric(token, args)?)
}

fn real_arg(value: &Value) -> Result<BasicReal, Error> {
    match value {
        Value::Integer(value) => BasicReal::from_integer(*value),
        Value::Real(value) => Ok(*value),
        Value::Complex(value) if value.is_real() => Ok(value.real()),
        Value::Complex(_) | Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn complex_or_real_unary(
    token: Token,
    args: &[Value],
    complex_operation: fn(BasicComplex) -> Result<BasicComplex, Error>,
    real_operation: fn(BasicReal) -> Result<BasicReal, Error>,
) -> Result<Value, Error> {
    expect_arity(token, args, 1, 1)?;
    match args[0] {
        Value::Complex(value) => Ok(Value::Complex(complex_operation(value)?)),
        Value::Integer(value) => Ok(Value::Real(real_operation(BasicReal::from_integer(
            value,
        )?)?)),
        Value::Real(value) => Ok(Value::Real(real_operation(value)?)),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn complex_cbrt(value: BasicComplex) -> Result<BasicComplex, Error> {
    value.pow(BasicComplex::new(1.0 / 3.0, 0.0)?)
}

fn complex_angle_conversion(token: Token, args: &[Value], factor: f64) -> Result<Value, Error> {
    expect_arity(token, args, 1, 1)?;
    let factor = BasicReal::new(factor)?;
    match args[0] {
        Value::Complex(value) => Ok(Value::Complex(value.scale(factor)?)),
        Value::Integer(value) => Ok(Value::Real(BasicReal::from_integer(value)?.mul(factor)?)),
        Value::Real(value) => Ok(Value::Real(value.mul(factor)?)),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn one_string(token: Token, args: &[Value]) -> Result<&str, Error> {
    expect_arity(token, args, 1, 1)?;
    string_arg(&args[0])
}

fn round_value(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::Round, args, 1, 2)?;
    if !args[0].is_numeric() {
        return Err(Error::TypeMismatch);
    }
    let decimal_places = args.get(1).map(integer_arg).transpose()?.unwrap_or(0);
    if !(0..=9).contains(&decimal_places) {
        return Err(Error::IllegalQuantity);
    }

    match args[0] {
        Value::Integer(value) => Ok(Value::Integer(value)),
        Value::Real(value) => {
            let scale = 10_f64.powi(decimal_places as i32);
            let scaled = value.value() * scale;
            // A finite value too large to scale already has no fractional
            // binary64 digits at this decimal precision, so it is unchanged.
            let rounded = if scaled.is_finite() {
                scaled.round() / scale
            } else {
                value.value()
            };
            Ok(Value::Real(BasicReal::new(rounded)?))
        }
        Value::Complex(value) => Ok(Value::Complex(BasicComplex::new(
            round_component(value.real().value(), decimal_places),
            round_component(value.imaginary().value(), decimal_places),
        )?)),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn round_component(value: f64, decimal_places: i64) -> f64 {
    let scale = 10_f64.powi(decimal_places as i32);
    let scaled = value * scale;
    if scaled.is_finite() {
        scaled.round() / scale
    } else {
        value
    }
}

fn natural_log(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::Ln, args, 1, 1)?;
    if let Value::Complex(value) = args[0] {
        return Ok(Value::Complex(value.ln()?));
    }
    let value = real_arg(&args[0])?;
    if value.value() <= 0.0 {
        return Err(Error::MathDomain { function: "LN" });
    }
    Ok(Value::Real(BasicReal::new(value.value().ln())?))
}

fn complex_value(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::Complex, args, 2, 2)?;
    Ok(Value::Complex(BasicComplex::new(
        real_arg(&args[0])?.value(),
        real_arg(&args[1])?.value(),
    )?))
}

fn real_part(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::RealPart, args, 1, 1)?;
    match args[0] {
        Value::Integer(value) => Ok(Value::Integer(value)),
        Value::Real(value) => Ok(Value::Real(value)),
        Value::Complex(value) => Ok(Value::Real(value.real())),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn imaginary_part(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::Imag, args, 1, 1)?;
    match args[0] {
        Value::Integer(_) => Ok(Value::Integer(0)),
        Value::Real(_) => Ok(Value::Real(BasicReal::zero())),
        Value::Complex(value) => Ok(Value::Real(value.imaginary())),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn conjugate(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::Conj, args, 1, 1)?;
    match args[0] {
        Value::Integer(value) => Ok(Value::Integer(value)),
        Value::Real(value) => Ok(Value::Real(value)),
        Value::Complex(value) => Ok(Value::Complex(value.conjugate()?)),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn complex_angle(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::Angle, args, 1, 1)?;
    let value = match args[0] {
        Value::Integer(value) => BasicComplex::from_real(BasicReal::from_integer(value)?),
        Value::Real(value) => BasicComplex::from_real(value),
        Value::Complex(value) => value,
        Value::List(_) | Value::String(_) => return Err(Error::TypeMismatch),
    };
    Ok(Value::Real(value.angle()?))
}

fn fraction_string(args: &[Value], max_string_bytes: usize) -> Result<Value, Error> {
    expect_arity(Token::FracString, args, 1, 2)?;
    let maximum_denominator = args
        .get(1)
        .map(integer_arg)
        .transpose()?
        .unwrap_or(1_000_000);
    if !(1..=1_000_000_000).contains(&maximum_denominator) {
        return Err(Error::IllegalQuantity);
    }
    let text = match args[0] {
        Value::Integer(value) => value.to_string(),
        Value::Real(value) => approximate_fraction(value.value(), maximum_denominator)?,
        Value::Complex(value) => {
            let real = approximate_fraction(value.real().value(), maximum_denominator)?;
            let imaginary =
                approximate_fraction(value.imaginary().value().abs(), maximum_denominator)?;
            if value.imaginary().is_zero() {
                real
            } else if value.real().is_zero() {
                if value.imaginary().value() < 0.0 {
                    format!("-{imaginary}i")
                } else {
                    format!("{imaginary}i")
                }
            } else if value.imaginary().value() < 0.0 {
                format!("{real}-{imaginary}i")
            } else {
                format!("{real}+{imaginary}i")
            }
        }
        Value::List(ref values) => {
            let mut output = String::from("{");
            for (index, value) in values.iter().enumerate() {
                if index > 0 {
                    output.push(',');
                }
                let Value::String(rendered) = fraction_string(
                    &[value.clone(), Value::Integer(maximum_denominator)],
                    max_string_bytes,
                )?
                else {
                    unreachable!("FRAC$ always returns a string")
                };
                output.push_str(&rendered);
                if output.len() > max_string_bytes {
                    return Err(Error::StringTooLong {
                        length: output.len(),
                        limit: max_string_bytes,
                    });
                }
            }
            output.push('}');
            output
        }
        Value::String(_) => return Err(Error::TypeMismatch),
    };
    checked_string(text, max_string_bytes)
}

fn approximate_fraction(value: f64, maximum_denominator: i64) -> Result<String, Error> {
    if value == 0.0 {
        return Ok("0".into());
    }
    let sign = if value < 0.0 { -1_i128 } else { 1_i128 };
    let mut remainder = value.abs();
    if remainder > i64::MAX as f64 {
        return Err(Error::IllegalQuantity);
    }
    let maximum_denominator = i128::from(maximum_denominator);
    let (mut previous_numerator, mut previous_denominator) = (0_i128, 1_i128);
    let (mut numerator, mut denominator) = (1_i128, 0_i128);
    for _ in 0..64 {
        let whole = remainder.floor() as i128;
        let next_numerator = whole
            .checked_mul(numerator)
            .and_then(|value| value.checked_add(previous_numerator))
            .ok_or(Error::IntegerOverflow)?;
        let next_denominator = whole
            .checked_mul(denominator)
            .and_then(|value| value.checked_add(previous_denominator))
            .ok_or(Error::IntegerOverflow)?;
        if next_denominator > maximum_denominator {
            let scale = (maximum_denominator - previous_denominator) / denominator;
            if scale > 0 {
                numerator = scale
                    .checked_mul(numerator)
                    .and_then(|value| value.checked_add(previous_numerator))
                    .ok_or(Error::IntegerOverflow)?;
                denominator = scale * denominator + previous_denominator;
            }
            break;
        }
        (previous_numerator, previous_denominator) = (numerator, denominator);
        (numerator, denominator) = (next_numerator, next_denominator);
        let fractional = remainder - whole as f64;
        if fractional.abs() <= f64::EPSILON {
            break;
        }
        remainder = 1.0 / fractional;
    }
    numerator *= sign;
    if denominator == 1 {
        Ok(numerator.to_string())
    } else {
        Ok(format!("{numerator}/{denominator}"))
    }
}

fn logarithm_with_base(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::LogBase, args, 2, 2)?;
    let base = real_arg(&args[1])?;
    if base.value() <= 0.0 || base.value() == 1.0 {
        return Err(Error::MathDomain {
            function: "LOGBASE",
        });
    }
    if let Value::Complex(value) = args[0] {
        return Ok(Value::Complex(
            value
                .ln()?
                .scale(BasicReal::new(1.0 / base.value().ln())?)?,
        ));
    }
    Ok(Value::Real(real_arg(&args[0])?.log_base(base)?))
}

fn nth_root(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::Root, args, 2, 2)?;
    let index = real_arg(&args[1])?;
    if index.is_zero() {
        return Err(Error::MathDomain { function: "ROOT" });
    }
    if let Value::Complex(value) = args[0] {
        return Ok(Value::Complex(
            value.pow(BasicComplex::new(1.0 / index.value(), 0.0)?)?,
        ));
    }
    Ok(Value::Real(real_arg(&args[0])?.root(index)?))
}

fn cube(args: &[Value]) -> Result<Value, Error> {
    expect_arity(Token::Cube, args, 1, 1)?;
    if let Value::Complex(value) = args[0] {
        return Ok(Value::Complex(value.mul(value)?.mul(value)?));
    }
    let value = real_arg(&args[0])?;
    Ok(Value::Real(value.mul(value)?.mul(value)?))
}

fn factorial(args: &[Value]) -> Result<Value, Error> {
    const MAX_FINITE_FACTORIAL: u64 = 170;
    let value = nonnegative_integer_arg(one_numeric(Token::Fact, args)?)?;
    if value > MAX_FINITE_FACTORIAL {
        return Err(Error::RealOverflow);
    }
    let mut result = 1.0;
    for factor in 2..=value {
        result *= factor as f64;
    }
    Ok(Value::Real(BasicReal::new(result)?))
}

#[derive(Debug, Clone, Copy)]
enum CombinatoricOperation {
    Permutation,
    Combination,
}

fn combinatoric(
    token: Token,
    args: &[Value],
    operation: CombinatoricOperation,
) -> Result<Value, Error> {
    const MAX_OPERATIONS: u64 = 1_000_000;
    expect_arity(token, args, 2, 2)?;
    let total = nonnegative_integer_arg(&args[0])?;
    let selected = nonnegative_integer_arg(&args[1])?;
    if selected > total {
        return Err(Error::IllegalQuantity);
    }
    let operations = match operation {
        CombinatoricOperation::Permutation => selected,
        CombinatoricOperation::Combination => selected.min(total - selected),
    };
    if operations > MAX_OPERATIONS {
        return Err(Error::IllegalQuantity);
    }

    let mut result = 1.0;
    match operation {
        CombinatoricOperation::Permutation => {
            for offset in 0..selected {
                result *= exact_u64_as_real(total - offset)?;
                if !result.is_finite() {
                    return Err(Error::RealOverflow);
                }
            }
        }
        CombinatoricOperation::Combination => {
            for step in 1..=operations {
                result *= exact_u64_as_real(total - operations + step)?;
                result /= exact_u64_as_real(step)?;
                if !result.is_finite() {
                    return Err(Error::RealOverflow);
                }
            }
        }
    }
    Ok(Value::Real(BasicReal::new(result)?))
}

fn exact_u64_as_real(value: u64) -> Result<f64, Error> {
    let value = i64::try_from(value).map_err(|_| Error::IntegerOverflow)?;
    Ok(BasicReal::from_integer(value)?.value())
}

const MAX_GENERATED_LIST_ELEMENTS: usize = 1_000_000;

fn random_units(args: &[Value], rng: &mut BasicRng) -> Result<Value, Error> {
    expect_arity(Token::Rand, args, 0, 1)?;
    let Some(count) = args.first() else {
        return Ok(Value::Real(rng.unit()?));
    };
    let count = list_count(count)?;
    let mut values = Vec::with_capacity(count);
    for _ in 0..count {
        values.push(Value::Real(rng.unit()?));
    }
    Ok(Value::List(values))
}

fn random_integer(args: &[Value], mode: NumericMode, rng: &mut BasicRng) -> Result<Value, Error> {
    expect_arity(Token::RandInt, args, 2, 3)?;
    let lower = integer_arg(&args[0])?;
    let upper = integer_arg(&args[1])?;
    let generate = |rng: &mut BasicRng| {
        let value = rng.integer_inclusive(lower, upper)?;
        Ok(Value::Integer(
            BasicInteger::with_mode(mode, value)?.value(),
        ))
    };
    if let Some(count) = args.get(2) {
        let count = list_count(count)?;
        let mut values = Vec::with_capacity(count);
        for _ in 0..count {
            values.push(generate(rng)?);
        }
        Ok(Value::List(values))
    } else {
        generate(rng)
    }
}

fn random_normal(args: &[Value], rng: &mut BasicRng) -> Result<Value, Error> {
    expect_arity(Token::RandNorm, args, 2, 3)?;
    let mean = real_arg(&args[0])?;
    let deviation = real_arg(&args[1])?;
    if let Some(count) = args.get(2) {
        let count = list_count(count)?;
        let mut values = Vec::with_capacity(count);
        for _ in 0..count {
            values.push(Value::Real(rng.normal(mean, deviation)?));
        }
        Ok(Value::List(values))
    } else {
        Ok(Value::Real(rng.normal(mean, deviation)?))
    }
}

fn random_binomial(args: &[Value], mode: NumericMode, rng: &mut BasicRng) -> Result<Value, Error> {
    expect_arity(Token::RandBin, args, 2, 3)?;
    let trials = nonnegative_integer_arg(&args[0])?;
    let probability = real_arg(&args[1])?;
    let generate = |rng: &mut BasicRng| {
        let successes = rng.binomial(trials, probability)?;
        let successes = i64::try_from(successes).map_err(|_| Error::IntegerOverflow)?;
        Ok(Value::Integer(
            BasicInteger::with_mode(mode, successes)?.value(),
        ))
    };
    if let Some(count) = args.get(2) {
        let count = list_count(count)?;
        let operations = count
            .checked_mul(usize::try_from(trials).map_err(|_| Error::IllegalQuantity)?)
            .ok_or(Error::IllegalQuantity)?;
        if operations > MAX_GENERATED_LIST_ELEMENTS {
            return Err(Error::IllegalQuantity);
        }
        let mut values = Vec::with_capacity(count);
        for _ in 0..count {
            values.push(generate(rng)?);
        }
        Ok(Value::List(values))
    } else {
        generate(rng)
    }
}

fn random_integer_without_replacement(
    args: &[Value],
    mode: NumericMode,
    rng: &mut BasicRng,
) -> Result<Value, Error> {
    expect_arity(Token::RandIntNoRep, args, 2, 3)?;
    let lower = integer_arg(&args[0])?;
    let upper = integer_arg(&args[1])?;
    if lower > upper {
        return Err(Error::IllegalQuantity);
    }
    let span = i128::from(upper) - i128::from(lower) + 1;
    let span = usize::try_from(span).map_err(|_| Error::IllegalQuantity)?;
    if span > MAX_GENERATED_LIST_ELEMENTS {
        return Err(Error::IllegalQuantity);
    }
    let count = args.get(2).map(list_count).transpose()?.unwrap_or(span);
    if count > span {
        return Err(Error::IllegalQuantity);
    }
    let mut values = (0..span)
        .map(|offset| {
            let value = i128::from(lower) + offset as i128;
            let value = i64::try_from(value).map_err(|_| Error::IntegerOverflow)?;
            Ok(Value::Integer(
                BasicInteger::with_mode(mode, value)?.value(),
            ))
        })
        .collect::<Result<Vec<_>, Error>>()?;
    for index in (1..values.len()).rev() {
        let swap = rng.integer_inclusive(0, index as i64)? as usize;
        values.swap(index, swap);
    }
    values.truncate(count);
    Ok(Value::List(values))
}

fn list_count(value: &Value) -> Result<usize, Error> {
    let count = nonnegative_integer_arg(value)?;
    let count = usize::try_from(count).map_err(|_| Error::IllegalQuantity)?;
    if count > MAX_GENERATED_LIST_ELEMENTS {
        return Err(Error::IllegalQuantity);
    }
    Ok(count)
}

fn integer_part(args: &[Value]) -> Result<Value, Error> {
    match one_numeric(Token::Ipart, args)? {
        Value::Integer(value) => Ok(Value::Integer(*value)),
        Value::Real(value) => Ok(Value::Real(BasicReal::new(value.value().trunc())?)),
        Value::Complex(value) => Ok(Value::Complex(BasicComplex::new(
            value.real().value().trunc(),
            value.imaginary().value().trunc(),
        )?)),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn fractional_part(args: &[Value]) -> Result<Value, Error> {
    match one_numeric(Token::Fpart, args)? {
        Value::Integer(_) => Ok(Value::Integer(0)),
        Value::Real(value) => Ok(Value::Real(BasicReal::new(value.value().fract())?)),
        Value::Complex(value) => Ok(Value::Complex(BasicComplex::new(
            value.real().value().fract(),
            value.imaginary().value().fract(),
        )?)),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn numeric_extreme(token: Token, args: &[Value], minimum: bool) -> Result<Value, Error> {
    expect_arity(token, args, 2, 2)?;
    if !args.iter().all(Value::is_numeric) {
        return Err(Error::TypeMismatch);
    }
    let ordering = compare_numeric_values(&args[0], &args[1])?;
    let choose_left = if minimum {
        !ordering.is_gt()
    } else {
        !ordering.is_lt()
    };
    Ok(args[usize::from(!choose_left)].clone())
}

fn compare_numeric_values(left: &Value, right: &Value) -> Result<std::cmp::Ordering, Error> {
    match (left, right) {
        (Value::Integer(left), Value::Integer(right)) => Ok(left.cmp(right)),
        (Value::Integer(left), Value::Real(right)) => BasicReal::from_integer(*left)?
            .value()
            .partial_cmp(&right.value())
            .ok_or(Error::RealOverflow),
        (Value::Real(left), Value::Integer(right)) => left
            .value()
            .partial_cmp(&BasicReal::from_integer(*right)?.value())
            .ok_or(Error::RealOverflow),
        (Value::Real(left), Value::Real(right)) => left
            .value()
            .partial_cmp(&right.value())
            .ok_or(Error::RealOverflow),
        (Value::Complex(left), Value::Complex(right)) => left
            .magnitude()?
            .value()
            .partial_cmp(&right.magnitude()?.value())
            .ok_or(Error::RealOverflow),
        (Value::Complex(left), right) if right.is_numeric() => left
            .magnitude()?
            .value()
            .partial_cmp(&real_arg(right)?.value().abs())
            .ok_or(Error::RealOverflow),
        (left, Value::Complex(right)) if left.is_numeric() => real_arg(left)?
            .value()
            .abs()
            .partial_cmp(&right.magnitude()?.value())
            .ok_or(Error::RealOverflow),
        _ => Err(Error::TypeMismatch),
    }
}

#[derive(Debug, Clone, Copy)]
enum IntegerPairOperation {
    Gcd,
    Lcm,
    Remainder,
}

fn integer_pair(
    token: Token,
    args: &[Value],
    mode: NumericMode,
    operation: IntegerPairOperation,
) -> Result<Value, Error> {
    expect_arity(token, args, 2, 2)?;
    let left = nonnegative_integer_arg(&args[0])?;
    let right = nonnegative_integer_arg(&args[1])?;

    let result = match operation {
        IntegerPairOperation::Gcd => greatest_common_divisor(left, right),
        IntegerPairOperation::Lcm => {
            if left == 0 || right == 0 {
                0
            } else {
                (left / greatest_common_divisor(left, right))
                    .checked_mul(right)
                    .ok_or(Error::IntegerOverflow)?
            }
        }
        IntegerPairOperation::Remainder => {
            if right == 0 {
                return Err(Error::DivideByZero);
            }
            left % right
        }
    };
    let result = i64::try_from(result).map_err(|_| Error::IntegerOverflow)?;
    Ok(Value::Integer(
        BasicInteger::with_mode(mode, result)?.value(),
    ))
}

fn nonnegative_integer_arg(value: &Value) -> Result<u64, Error> {
    let value = integer_arg(value).map_err(|error| match error {
        Error::IntegerRequired => Error::IllegalQuantity,
        other => other,
    })?;
    u64::try_from(value).map_err(|_| Error::IllegalQuantity)
}

fn greatest_common_divisor(mut left: u64, mut right: u64) -> u64 {
    while right != 0 {
        (left, right) = (right, left % right);
    }
    left
}

fn integer_arg(value: &Value) -> Result<i64, Error> {
    value.to_integer()
}

fn string_arg(value: &Value) -> Result<&str, Error> {
    value.as_str().ok_or(Error::TypeMismatch)
}

fn checked_string(text: String, limit: usize) -> Result<Value, Error> {
    if text.len() > limit {
        return Err(Error::StringTooLong {
            length: text.len(),
            limit,
        });
    }
    Ok(Value::String(text))
}

fn nonnegative_count(value: i64) -> Result<Option<usize>, Error> {
    if value < 0 {
        return Err(Error::IllegalQuantity);
    }
    Ok(usize::try_from(value).ok())
}

fn left_chars(text: &str, count: Option<usize>) -> String {
    let Some(count) = count else {
        return text.to_string();
    };
    let end = text
        .char_indices()
        .nth(count)
        .map_or(text.len(), |(index, _)| index);
    text[..end].to_string()
}

fn right_chars(text: &str, count: Option<usize>) -> String {
    let Some(count) = count else {
        return text.to_string();
    };
    let total = text.chars().count();
    let skip = total.saturating_sub(count);
    let start = text
        .char_indices()
        .nth(skip)
        .map_or(text.len(), |(index, _)| index);
    text[start..].to_string()
}

fn mid_chars(text: &str, start: i64, length: Option<Option<usize>>) -> String {
    let Ok(start) = usize::try_from(start - 1) else {
        return String::new();
    };
    let Some((start_byte, _)) = text.char_indices().nth(start) else {
        return String::new();
    };
    let tail = &text[start_byte..];
    match length {
        None | Some(None) => tail.to_string(),
        Some(Some(count)) => {
            let end = tail
                .char_indices()
                .nth(count)
                .map_or(tail.len(), |(index, _)| index);
            tail[..end].to_string()
        }
    }
}

fn parse_integer_prefix(text: &str, mode: NumericMode) -> Result<i64, Error> {
    let bytes = text.trim_start().as_bytes();
    let (negative, start) = match bytes.first() {
        Some(b'-') => (true, 1),
        Some(b'+') => (false, 1),
        _ => (false, 0),
    };

    let mut magnitude = 0i128;
    let mut digits = 0usize;
    for &byte in &bytes[start..] {
        if !byte.is_ascii_digit() {
            break;
        }
        magnitude = magnitude
            .checked_mul(10)
            .and_then(|value| value.checked_add(i128::from(byte - b'0')))
            .ok_or(if negative {
                Error::IntegerUnderflow
            } else {
                Error::IntegerOverflow
            })?;
        digits += 1;
    }
    if digits == 0 {
        return Ok(0);
    }

    let signed = if negative { -magnitude } else { magnitude };
    let value = i64::try_from(signed).map_err(|_| {
        if negative {
            Error::IntegerUnderflow
        } else {
            Error::IntegerOverflow
        }
    })?;
    Ok(BasicInteger::with_mode(mode, value)?.value())
}

fn parse_numeric_prefix(text: &str, mode: NumericMode) -> Result<Value, Error> {
    let text = text.trim_start();
    let bytes = text.as_bytes();
    let mut pos = usize::from(matches!(bytes.first(), Some(b'+' | b'-')));
    let mut digits = 0usize;

    while bytes.get(pos).is_some_and(u8::is_ascii_digit) {
        pos += 1;
        digits += 1;
    }

    let mut real = false;
    if matches!(bytes.get(pos), Some(b'.')) {
        real = true;
        pos += 1;
        while bytes.get(pos).is_some_and(u8::is_ascii_digit) {
            pos += 1;
            digits += 1;
        }
    }
    if digits == 0 {
        return Ok(Value::Integer(0));
    }

    if matches!(bytes.get(pos), Some(b'e' | b'E')) {
        let exponent_mark = pos;
        let mut exponent_pos = pos + 1;
        if matches!(bytes.get(exponent_pos), Some(b'+' | b'-')) {
            exponent_pos += 1;
        }
        let exponent_digits = exponent_pos;
        while bytes.get(exponent_pos).is_some_and(u8::is_ascii_digit) {
            exponent_pos += 1;
        }
        if exponent_pos > exponent_digits {
            real = true;
            pos = exponent_pos;
        } else {
            pos = exponent_mark;
        }
    }

    let prefix = &text[..pos];
    if real {
        Ok(Value::Real(BasicReal::parse(prefix)?))
    } else {
        Ok(Value::Integer(parse_integer_prefix(prefix, mode)?))
    }
}

fn expect_named_arity(name: &str, args: &[Value], min: usize, max: usize) -> Result<(), Error> {
    if (min..=max).contains(&args.len()) {
        Ok(())
    } else {
        Err(Error::syntax(format!(
            "{name} expects {min}..={max} argument(s), got {}",
            args.len()
        )))
    }
}

fn named_list_statistic(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "VARP" | "VARS" | "VARIANCE" | "STD" | "STDDEV" | "STDEV" | "STDEVP" | "STDEVS" => {
            expect_named_arity(name, args, 1, 1)?;
            let values = real_list_arg(&args[0])?;
            let (count, _, sum_of_squares) = univariate_moments(&values)?;
            let sample = matches!(
                name,
                "VARS" | "VARIANCE" | "STD" | "STDDEV" | "STDEV" | "STDEVS"
            );
            if sample && count < 2 {
                return Err(Error::IllegalQuantity);
            }
            let divisor = if sample { count - 1 } else { count } as f64;
            let variance = (sum_of_squares / divisor).max(0.0);
            let value = if matches!(name, "STD" | "STDDEV" | "STDEV" | "STDEVP" | "STDEVS") {
                variance.sqrt()
            } else {
                variance
            };
            Ok(Value::Real(BasicReal::new(value)?))
        }
        "CORREL" | "LINREG" => {
            expect_named_arity(name, args, 2, 2)?;
            let x_values = real_list_arg(&args[0])?;
            let y_values = real_list_arg(&args[1])?;
            let moments = bivariate_moments(&x_values, &y_values)?;
            let denominator = moments.x_sum_of_squares.sqrt() * moments.y_sum_of_squares.sqrt();
            if denominator == 0.0 || !denominator.is_finite() {
                return Err(Error::IllegalQuantity);
            }
            let mut correlation = (moments.cross_sum / denominator).clamp(-1.0, 1.0);
            if (1.0 - correlation.abs()).abs() <= 32.0 * f64::EPSILON {
                correlation = correlation.signum();
            }
            if name == "CORREL" {
                return Ok(Value::Real(BasicReal::new(correlation)?));
            }
            let slope = moments.cross_sum / moments.x_sum_of_squares;
            let intercept = moments.y_mean - slope * moments.x_mean;
            let r_squared = correlation * correlation;
            Ok(Value::List(
                [slope, intercept, correlation, r_squared]
                    .into_iter()
                    .map(BasicReal::new)
                    .map(|value| value.map(Value::Real))
                    .collect::<Result<Vec<_>, _>>()?,
            ))
        }
        _ => Err(Error::syntax(format!("unknown statistic {name}"))),
    }
}

fn real_list_arg(value: &Value) -> Result<Vec<f64>, Error> {
    let Value::List(values) = value else {
        return Err(Error::TypeMismatch);
    };
    if values.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    values
        .iter()
        .map(|value| real_arg(value).map(BasicReal::value))
        .collect()
}

fn univariate_moments(values: &[f64]) -> Result<(usize, f64, f64), Error> {
    let mut mean = 0.0;
    let mut sum_of_squares = 0.0;
    for (index, value) in values.iter().copied().enumerate() {
        let count = (index + 1) as f64;
        let delta = value - mean;
        mean += delta / count;
        sum_of_squares += delta * (value - mean);
        if !mean.is_finite() || !sum_of_squares.is_finite() {
            return Err(Error::RealOverflow);
        }
    }
    Ok((values.len(), mean, sum_of_squares))
}

#[derive(Debug, Clone, Copy)]
struct BivariateMoments {
    x_mean: f64,
    y_mean: f64,
    x_sum_of_squares: f64,
    y_sum_of_squares: f64,
    cross_sum: f64,
}

fn bivariate_moments(x_values: &[f64], y_values: &[f64]) -> Result<BivariateMoments, Error> {
    if x_values.len() != y_values.len() || x_values.len() < 2 {
        return Err(Error::IllegalQuantity);
    }
    let mut moments = BivariateMoments {
        x_mean: 0.0,
        y_mean: 0.0,
        x_sum_of_squares: 0.0,
        y_sum_of_squares: 0.0,
        cross_sum: 0.0,
    };
    for (index, (x, y)) in x_values
        .iter()
        .copied()
        .zip(y_values.iter().copied())
        .enumerate()
    {
        let count = (index + 1) as f64;
        let x_delta = x - moments.x_mean;
        let y_delta = y - moments.y_mean;
        moments.x_mean += x_delta / count;
        moments.y_mean += y_delta / count;
        moments.x_sum_of_squares += x_delta * (x - moments.x_mean);
        moments.y_sum_of_squares += y_delta * (y - moments.y_mean);
        moments.cross_sum += x_delta * (y - moments.y_mean);
        if !moments.x_mean.is_finite()
            || !moments.y_mean.is_finite()
            || !moments.x_sum_of_squares.is_finite()
            || !moments.y_sum_of_squares.is_finite()
            || !moments.cross_sum.is_finite()
        {
            return Err(Error::RealOverflow);
        }
    }
    if moments.x_sum_of_squares <= 0.0 || moments.y_sum_of_squares <= 0.0 {
        return Err(Error::IllegalQuantity);
    }
    Ok(moments)
}

fn decimal_conversion(args: &[Value]) -> Result<Value, Error> {
    expect_named_arity("DEC", args, 1, 1)?;
    match &args[0] {
        Value::Integer(value) => Ok(Value::Real(BasicReal::from_integer(*value)?)),
        Value::Real(value) => Ok(Value::Real(*value)),
        Value::Complex(value) => Ok(Value::Complex(*value)),
        Value::String(text) => {
            if let Some((numerator, denominator)) = text.split_once('/') {
                let numerator = BasicReal::parse(numerator.trim())?;
                let denominator = BasicReal::parse(denominator.trim())?;
                Ok(Value::Real(numerator.div(denominator)?))
            } else {
                let text = text.trim();
                match BasicReal::parse(text) {
                    Ok(value) => Ok(Value::Real(value)),
                    Err(_error)
                        if !text.is_empty()
                            && text.bytes().all(|byte| byte.is_ascii_hexdigit())
                            && text.bytes().any(|byte| byte.is_ascii_alphabetic()) =>
                    {
                        let value =
                            i64::from_str_radix(text, 16).map_err(|_| Error::IllegalQuantity)?;
                        Ok(Value::Integer(value))
                    }
                    Err(error) => Err(error),
                }
            }
        }
        Value::List(_) => unreachable!("named list dispatch maps DEC elementwise"),
    }
}

fn normal_pdf(args: &[Value]) -> Result<Value, Error> {
    expect_named_arity("NORMALPDF", args, 1, 3)?;
    let x = real_arg(&args[0])?.value();
    let mean = args
        .get(1)
        .map(real_arg)
        .transpose()?
        .map_or(0.0, BasicReal::value);
    let deviation = args
        .get(2)
        .map(real_arg)
        .transpose()?
        .map_or(1.0, BasicReal::value);
    if deviation <= 0.0 {
        return Err(Error::IllegalQuantity);
    }
    let standardized = (x - mean) / deviation;
    let density = (-0.5 * standardized * standardized).exp()
        / (deviation * (2.0 * std::f64::consts::PI).sqrt());
    Ok(Value::Real(BasicReal::new(density)?))
}

fn normal_cdf(args: &[Value]) -> Result<Value, Error> {
    expect_named_arity("NORMALCDF", args, 2, 4)?;
    let lower = real_arg(&args[0])?.value();
    let upper = real_arg(&args[1])?.value();
    let mean = args
        .get(2)
        .map(real_arg)
        .transpose()?
        .map_or(0.0, BasicReal::value);
    let deviation = args
        .get(3)
        .map(real_arg)
        .transpose()?
        .map_or(1.0, BasicReal::value);
    if deviation <= 0.0 || lower > upper {
        return Err(Error::IllegalQuantity);
    }
    let lower = standard_normal_cdf((lower - mean) / deviation);
    let upper = standard_normal_cdf((upper - mean) / deviation);
    Ok(Value::Real(BasicReal::new(
        (upper - lower).clamp(0.0, 1.0),
    )?))
}

fn inverse_normal(args: &[Value]) -> Result<Value, Error> {
    expect_named_arity("INVNORM", args, 1, 3)?;
    let probability = real_arg(&args[0])?.value();
    let mean = args
        .get(1)
        .map(real_arg)
        .transpose()?
        .map_or(0.0, BasicReal::value);
    let deviation = args
        .get(2)
        .map(real_arg)
        .transpose()?
        .map_or(1.0, BasicReal::value);
    if !(0.0..1.0).contains(&probability) || probability == 0.0 || deviation <= 0.0 {
        return Err(Error::IllegalQuantity);
    }
    Ok(Value::Real(BasicReal::new(
        mean + deviation * inverse_standard_normal(probability),
    )?))
}

fn standard_normal_cdf(value: f64) -> f64 {
    0.5 * (1.0 + error_function(value / std::f64::consts::SQRT_2))
}

fn error_function(value: f64) -> f64 {
    // Numerical Recipes erfc approximation; maximum error is about 1.2e-7.
    let magnitude = value.abs();
    let t = 1.0 / (1.0 + 0.5 * magnitude);
    let tau = t
        * (-magnitude * magnitude - 1.265_512_23
            + t * (1.000_023_68
                + t * (0.374_091_96
                    + t * (0.096_784_18
                        + t * (-0.186_288_06
                            + t * (0.278_868_07
                                + t * (-1.135_203_98
                                    + t * (1.488_515_87
                                        + t * (-0.822_152_23 + t * 0.170_872_77)))))))))
            .exp();
    if value >= 0.0 {
        1.0 - tau
    } else {
        tau - 1.0
    }
}

fn inverse_standard_normal(probability: f64) -> f64 {
    // Peter J. Acklam's rational approximation.
    const A: [f64; 6] = [
        -3.969_683_028_665_376e1,
        2.209_460_984_245_205e2,
        -2.759_285_104_469_687e2,
        1.383_577_518_672_69e2,
        -3.066_479_806_614_716e1,
        2.506_628_277_459_239,
    ];
    const B: [f64; 5] = [
        -5.447_609_879_822_406e1,
        1.615_858_368_580_409e2,
        -1.556_989_798_598_866e2,
        6.680_131_188_771_972e1,
        -1.328_068_155_288_572e1,
    ];
    const C: [f64; 6] = [
        -7.784_894_002_430_293e-3,
        -3.223_964_580_411_365e-1,
        -2.400_758_277_161_838,
        -2.549_732_539_343_734,
        4.374_664_141_464_968,
        2.938_163_982_698_783,
    ];
    const D: [f64; 4] = [
        7.784_695_709_041_462e-3,
        3.224_671_290_700_398e-1,
        2.445_134_137_142_996,
        3.754_408_661_907_416,
    ];
    const TAIL: f64 = 0.024_25;
    if probability < TAIL {
        let q = (-2.0 * probability.ln()).sqrt();
        return (((((C[0] * q + C[1]) * q + C[2]) * q + C[3]) * q + C[4]) * q + C[5])
            / ((((D[0] * q + D[1]) * q + D[2]) * q + D[3]) * q + 1.0);
    }
    if probability > 1.0 - TAIL {
        let q = (-2.0 * (1.0 - probability).ln()).sqrt();
        return -(((((C[0] * q + C[1]) * q + C[2]) * q + C[3]) * q + C[4]) * q + C[5])
            / ((((D[0] * q + D[1]) * q + D[2]) * q + D[3]) * q + 1.0);
    }
    let q = probability - 0.5;
    let r = q * q;
    (((((A[0] * r + A[1]) * r + A[2]) * r + A[3]) * r + A[4]) * r + A[5]) * q
        / (((((B[0] * r + B[1]) * r + B[2]) * r + B[3]) * r + B[4]) * r + 1.0)
}

fn binomial_distribution(args: &[Value], cumulative: bool) -> Result<Value, Error> {
    let name = if cumulative { "BINOMCDF" } else { "BINOMPDF" };
    expect_named_arity(name, args, 2, 3)?;
    let trials = nonnegative_integer_arg(&args[0])?;
    let probability = real_arg(&args[1])?.value();
    if !(0.0..=1.0).contains(&probability) || trials > MAX_GENERATED_LIST_ELEMENTS as u64 {
        return Err(Error::IllegalQuantity);
    }
    let probabilities = binomial_probabilities(trials as usize, probability)?;
    if let Some(successes) = args.get(2) {
        let successes = nonnegative_integer_arg(successes)?;
        if successes > trials {
            return Ok(Value::Real(BasicReal::new(if cumulative {
                1.0
            } else {
                0.0
            })?));
        }
        let index = successes as usize;
        let value = if cumulative {
            probabilities[..=index].iter().sum::<f64>().min(1.0)
        } else {
            probabilities[index]
        };
        Ok(Value::Real(BasicReal::new(value)?))
    } else {
        let mut running = 0.0;
        let values = probabilities
            .into_iter()
            .map(|probability| {
                let value = if cumulative {
                    running += probability;
                    running.min(1.0)
                } else {
                    probability
                };
                BasicReal::new(value).map(Value::Real)
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(Value::List(values))
    }
}

fn binomial_probabilities(trials: usize, probability: f64) -> Result<Vec<f64>, Error> {
    if trials == MAX_GENERATED_LIST_ELEMENTS {
        return Err(Error::IllegalQuantity);
    }
    let mut values = vec![0.0; trials + 1];
    if probability == 0.0 {
        values[0] = 1.0;
        return Ok(values);
    }
    if probability == 1.0 {
        values[trials] = 1.0;
        return Ok(values);
    }
    let mode = (((trials + 1) as f64 * probability).floor() as usize).min(trials);
    let log_mode = log_binomial_coefficient(trials, mode)
        + mode as f64 * probability.ln()
        + (trials - mode) as f64 * (-probability).ln_1p();
    values[mode] = log_mode.exp();
    for index in (1..=mode).rev() {
        values[index - 1] = values[index] * index as f64 / (trials - index + 1) as f64
            * (1.0 - probability)
            / probability;
    }
    for index in mode..trials {
        values[index + 1] = values[index] * (trials - index) as f64 / (index + 1) as f64
            * probability
            / (1.0 - probability);
    }
    let total: f64 = values.iter().sum();
    if !total.is_finite() || total <= 0.0 {
        return Err(Error::RealOverflow);
    }
    for value in &mut values {
        *value /= total;
    }
    Ok(values)
}

fn log_binomial_coefficient(total: usize, selected: usize) -> f64 {
    let selected = selected.min(total - selected);
    (1..=selected)
        .map(|step| ((total - selected + step) as f64).ln() - (step as f64).ln())
        .sum()
}

fn geometric_distribution(args: &[Value], cumulative: bool) -> Result<Value, Error> {
    let name = if cumulative { "GEOMETCDF" } else { "GEOMETPDF" };
    expect_named_arity(name, args, 2, 2)?;
    let probability = real_arg(&args[0])?.value();
    let trial = nonnegative_integer_arg(&args[1])?;
    if !(0.0..=1.0).contains(&probability) || trial == 0 {
        return Err(Error::IllegalQuantity);
    }
    let value = if cumulative {
        1.0 - (1.0 - probability).powf(trial as f64)
    } else {
        (1.0 - probability).powf((trial - 1) as f64) * probability
    };
    Ok(Value::Real(BasicReal::new(value.clamp(0.0, 1.0))?))
}

fn poisson_distribution(args: &[Value], cumulative: bool) -> Result<Value, Error> {
    let name = if cumulative {
        "POISSONCDF"
    } else {
        "POISSONPDF"
    };
    expect_named_arity(name, args, 2, 2)?;
    let mean = real_arg(&args[0])?.value();
    let count = nonnegative_integer_arg(&args[1])?;
    if mean < 0.0 || count > MAX_GENERATED_LIST_ELEMENTS as u64 {
        return Err(Error::IllegalQuantity);
    }
    if mean == 0.0 {
        return Ok(Value::Real(BasicReal::new(if cumulative || count == 0 {
            1.0
        } else {
            0.0
        })?));
    }
    if cumulative && mean > 700.0 {
        let approximation = standard_normal_cdf((count as f64 + 0.5 - mean) / mean.sqrt());
        return Ok(Value::Real(BasicReal::new(approximation.clamp(0.0, 1.0))?));
    }
    let value = if cumulative {
        let mut term = (-mean).exp();
        let mut total = term;
        for index in 1..=count {
            term *= mean / index as f64;
            total += term;
        }
        total.min(1.0)
    } else {
        let log_factorial: f64 = (1..=count).map(|value| (value as f64).ln()).sum();
        (-mean + count as f64 * mean.ln() - log_factorial).exp()
    };
    Ok(Value::Real(BasicReal::new(value)?))
}

// ---- MS-BASIC named function implementations ----

fn eval_instr(args: &[Value]) -> Result<Value, Error> {
    let (start, haystack, needle) = match args {
        [h, n] => (1usize, string_arg(h)?, string_arg(n)?),
        [s, h, n] => (
            integer_arg(s)?.max(1) as usize,
            string_arg(h)?,
            string_arg(n)?,
        ),
        _ => return Err(Error::syntax("INSTR expects 2 or 3 arguments")),
    };
    let start_byte_idx = haystack
        .char_indices()
        .nth(start.saturating_sub(1))
        .map(|(b, _)| b)
        .unwrap_or(haystack.len());
    if start_byte_idx > haystack.len() {
        return Ok(Value::Integer(0));
    }
    let found = haystack[start_byte_idx..].find(needle);
    let pos = found
        .map(|byte_pos| {
            let chars_before = haystack[start_byte_idx..start_byte_idx + byte_pos]
                .chars()
                .count();
            start + chars_before
        })
        .unwrap_or(0);
    Ok(Value::Integer(pos as i64))
}

fn eval_bin(args: &[Value]) -> Result<Value, Error> {
    let [value] = args else {
        return Err(Error::syntax("BIN$ expects 1 argument"));
    };
    let number = integer_arg(value)?;
    Ok(Value::String(format!("{number:b}")))
}

fn eval_hex(args: &[Value]) -> Result<Value, Error> {
    let n = integer_arg(
        args.first()
            .ok_or_else(|| Error::syntax("HEX$ expects 1 argument"))?,
    )?;
    Ok(Value::String(format!("{:X}", n as i64)))
}

fn eval_oct(args: &[Value]) -> Result<Value, Error> {
    let n = integer_arg(
        args.first()
            .ok_or_else(|| Error::syntax("OCT$ expects 1 argument"))?,
    )?;
    Ok(Value::String(format!("{:o}", n as i64)))
}

fn eval_mki(args: &[Value]) -> Result<Value, Error> {
    let n = integer_arg(
        args.first()
            .ok_or_else(|| Error::syntax("MKI$ expects 1 argument"))?,
    )?;
    let bytes = (n as i16).to_le_bytes();
    Ok(Value::String(pack_binary_string(&bytes)))
}

fn eval_mkl(args: &[Value]) -> Result<Value, Error> {
    let [value] = args else {
        return Err(Error::syntax("MKL$ expects 1 argument"));
    };
    Ok(Value::String(pack_binary_string(
        &integer_arg(value)?.to_le_bytes(),
    )))
}

fn eval_mkd(args: &[Value]) -> Result<Value, Error> {
    let [value] = args else {
        return Err(Error::syntax("MKD$ expects 1 argument"));
    };
    Ok(Value::String(pack_binary_string(
        &real_arg(value)?.value().to_le_bytes(),
    )))
}

fn eval_cvi(args: &[Value]) -> Result<Value, Error> {
    match args.first() {
        Some(Value::String(s)) => {
            let Some(bytes) = unpack_binary_string::<2>(s)? else {
                return Ok(Value::Integer(0));
            };
            Ok(Value::Integer(i16::from_le_bytes(bytes) as i64))
        }
        _ => Err(Error::syntax("CVI expects a string argument")),
    }
}

fn eval_cvs(args: &[Value]) -> Result<Value, Error> {
    match args.first() {
        Some(Value::String(s)) => {
            let Some(bytes) = unpack_binary_string::<4>(s)? else {
                return Ok(Value::Integer(0));
            };
            Ok(crate::value::Value::real(f32::from_le_bytes(bytes) as f64)?)
        }
        _ => Err(Error::syntax("CVS expects a string argument")),
    }
}

fn eval_cvl(args: &[Value]) -> Result<Value, Error> {
    match args {
        [Value::String(text)] => {
            let Some(bytes) = unpack_binary_string::<8>(text)? else {
                return Ok(Value::Integer(0));
            };
            Ok(Value::Integer(i64::from_le_bytes(bytes)))
        }
        [_] => Err(Error::syntax("CVL expects a string argument")),
        _ => Err(Error::syntax("CVL expects 1 argument")),
    }
}

fn eval_cvd(args: &[Value]) -> Result<Value, Error> {
    match args {
        [Value::String(text)] => {
            let Some(bytes) = unpack_binary_string::<8>(text)? else {
                return Ok(Value::Integer(0));
            };
            Value::real(f64::from_le_bytes(bytes))
        }
        [_] => Err(Error::syntax("CVD expects a string argument")),
        _ => Err(Error::syntax("CVD expects 1 argument")),
    }
}

/// Map raw bytes to the corresponding Unicode scalar values. This preserves
/// all 256 values while keeping BASIC's character-based `LEN`, `ASC`, and
/// substring functions byte-exact for packed binary strings.
fn pack_binary_string(bytes: &[u8]) -> String {
    bytes.iter().map(|byte| char::from(*byte)).collect()
}

fn unpack_binary_string<const N: usize>(text: &str) -> Result<Option<[u8; N]>, Error> {
    let mut bytes = [0u8; N];
    let mut characters = text.chars();
    for byte in &mut bytes {
        let Some(character) = characters.next() else {
            return Ok(None);
        };
        *byte = u8::try_from(u32::from(character)).map_err(|_| Error::IllegalQuantity)?;
    }
    Ok(Some(bytes))
}

fn eval_string_func(args: &[Value], max_string_bytes: usize) -> Result<Value, Error> {
    let count = integer_arg(
        args.first()
            .ok_or_else(|| Error::syntax("STRING$ expects 2 arguments"))?,
    )?;
    let count = usize::try_from(count.max(0)).unwrap_or(usize::MAX);
    let ch = match args.get(1) {
        Some(Value::String(s)) => s.chars().next().unwrap_or(' '),
        Some(v) => char::from_u32(integer_arg(v)? as u32).unwrap_or(' '),
        None => return Err(Error::syntax("STRING$ expects 2 arguments")),
    };
    let character = ch.to_string();
    let length = count
        .checked_mul(character.len())
        .ok_or(Error::StringTooLong {
            length: usize::MAX,
            limit: max_string_bytes,
        })?;
    if length > max_string_bytes {
        return Err(Error::StringTooLong {
            length,
            limit: max_string_bytes,
        });
    }
    Ok(Value::String(character.repeat(count)))
}

fn eval_space(args: &[Value], max_string_bytes: usize) -> Result<Value, Error> {
    let n = integer_arg(
        args.first()
            .ok_or_else(|| Error::syntax("SPACE$ expects 1 argument"))?,
    )?;
    let n = usize::try_from(n.max(0)).unwrap_or(usize::MAX);
    let length = n.checked_mul(' '.len_utf8()).ok_or(Error::StringTooLong {
        length: usize::MAX,
        limit: max_string_bytes,
    })?;
    if length > max_string_bytes {
        return Err(Error::StringTooLong {
            length,
            limit: max_string_bytes,
        });
    }
    Ok(Value::String(" ".repeat(n)))
}

fn eval_ascii_case(args: &[Value], name: &str, uppercase: bool) -> Result<Value, Error> {
    let [Value::String(text)] = args else {
        if args.len() != 1 {
            return Err(Error::syntax(format!("{name} expects 1 argument")));
        }
        return Err(Error::TypeMismatch);
    };
    let value = if uppercase {
        text.to_ascii_uppercase()
    } else {
        text.to_ascii_lowercase()
    };
    Ok(Value::String(value))
}

#[derive(Clone, Copy)]
enum TrimSide {
    Left,
    Right,
    Both,
}

fn eval_trim(args: &[Value], name: &str, side: TrimSide) -> Result<Value, Error> {
    let [Value::String(text)] = args else {
        if args.len() != 1 {
            return Err(Error::syntax(format!("{name} expects 1 argument")));
        }
        return Err(Error::TypeMismatch);
    };
    let value = match side {
        TrimSide::Left => text.trim_start().to_string(),
        TrimSide::Right => text.trim_end().to_string(),
        TrimSide::Both => text.trim().to_string(),
    };
    Ok(Value::String(value))
}

fn eval_cint(args: &[Value]) -> Result<Value, Error> {
    let [v] = args else {
        return Err(Error::syntax("CINT expects 1 argument"));
    };
    let n = match v {
        Value::Integer(i) => *i,
        Value::Real(r) => checked_real_to_integer(r.value().round())?,
        _ => return Err(Error::TypeMismatch),
    };
    Ok(Value::Integer(n))
}

fn eval_fix(args: &[Value]) -> Result<Value, Error> {
    let [v] = args else {
        return Err(Error::syntax("FIX expects 1 argument"));
    };
    let n = match v {
        Value::Integer(i) => *i,
        Value::Real(r) => checked_real_to_integer(r.value().trunc())?,
        _ => return Err(Error::TypeMismatch),
    };
    Ok(Value::Integer(n))
}

fn eval_cdbl(args: &[Value]) -> Result<Value, Error> {
    let [v] = args else {
        return Err(Error::syntax("CDBL expects 1 argument"));
    };
    let n = match v {
        Value::Integer(i) => *i as f64,
        Value::Real(r) => r.value(),
        _ => return Err(Error::TypeMismatch),
    };
    Ok(Value::Real(BasicReal::new(n)?))
}

fn eval_csng(args: &[Value]) -> Result<Value, Error> {
    let [v] = args else {
        return Err(Error::syntax("CSNG expects 1 argument"));
    };
    let n = match v {
        Value::Integer(i) => *i as f32,
        Value::Real(r) => r.value() as f32,
        _ => return Err(Error::TypeMismatch),
    };
    Ok(Value::Real(BasicReal::new(f64::from(n))?))
}

fn checked_real_to_integer(value: f64) -> Result<i64, Error> {
    const I64_LOWER: f64 = -9_223_372_036_854_775_808.0;
    const I64_UPPER_EXCLUSIVE: f64 = 9_223_372_036_854_775_808.0;
    if value < I64_LOWER {
        return Err(Error::IntegerUnderflow);
    }
    if value >= I64_UPPER_EXCLUSIVE {
        return Err(Error::IntegerOverflow);
    }
    Ok(value as i64)
}

fn eval_date() -> Result<Value, Error> {
    eval_date_at(std::time::SystemTime::now())
}

pub(crate) fn eval_date_at(clock: std::time::SystemTime) -> Result<Value, Error> {
    let calendar = crate::local_time::local_calendar_at(clock)?;
    Ok(Value::String(format!(
        "{:02}-{:02}-{:04}",
        calendar.month, calendar.day, calendar.year
    )))
}

fn eval_time() -> Result<Value, Error> {
    eval_time_at(std::time::SystemTime::now())
}

pub(crate) fn eval_time_at(clock: std::time::SystemTime) -> Result<Value, Error> {
    let calendar = crate::local_time::local_calendar_at(clock)?;
    Ok(Value::String(format!(
        "{:02}:{:02}:{:02}",
        calendar.hour, calendar.minute, calendar.second
    )))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn call(token: Token, args: Vec<Value>) -> Result<Value, Error> {
        evaluate_builtin(
            token,
            args,
            NumericMode::Modern,
            1024,
            &mut BasicRng::default(),
        )
    }

    #[test]
    fn numeric_functions_are_checked() {
        assert_eq!(
            call(Token::Sgn, vec![Value::Integer(-9)]).unwrap(),
            Value::Integer(-1)
        );
        assert_eq!(
            call(Token::Int, vec![Value::Integer(9)]).unwrap(),
            Value::Integer(9)
        );
        assert_eq!(
            call(Token::Abs, vec![Value::Integer(-9)]).unwrap(),
            Value::Integer(9)
        );
        assert_eq!(
            call(Token::Abs, vec![Value::Integer(i64::MIN)]).unwrap_err(),
            Error::IntegerOverflow
        );

        assert_eq!(
            call(Token::Sgn, vec![Value::real(-1.5).unwrap()]).unwrap(),
            Value::Integer(-1)
        );
        assert_eq!(
            call(Token::Int, vec![Value::real(-1.25).unwrap()]).unwrap(),
            Value::real(-2.0).unwrap()
        );
        assert_eq!(
            call(Token::Abs, vec![Value::real(-1.25).unwrap()]).unwrap(),
            Value::real(1.25).unwrap()
        );
    }

    #[test]
    fn runtime_position_is_numeric_mode_and_type_checked() {
        assert_eq!(
            evaluate_position(&[Value::Integer(0)], NumericMode::Modern, 70_000).unwrap(),
            Value::Integer(70_000)
        );
        assert!(matches!(
            evaluate_position(&[Value::Integer(0)], NumericMode::Legacy6502, 70_000),
            Err(Error::OutOfLegacyRange { .. })
        ));
        assert_eq!(
            evaluate_position(&[Value::String("X".into())], NumericMode::Modern, 0).unwrap_err(),
            Error::TypeMismatch
        );
    }

    #[test]
    fn runtime_free_reports_exact_quota_and_evaluates_any_argument_type() {
        assert_eq!(
            evaluate_free(&[Value::Integer(0)], NumericMode::Modern, 70_000).unwrap(),
            Value::Integer(70_000)
        );
        assert_eq!(
            evaluate_free(
                &[Value::String("ignored".into())],
                NumericMode::Legacy6502,
                32_767,
            )
            .unwrap(),
            Value::Integer(32_767)
        );
        assert!(matches!(
            evaluate_free(&[Value::Integer(0)], NumericMode::Legacy6502, 32_768),
            Err(Error::OutOfLegacyRange { .. })
        ));
    }

    #[test]
    fn native_math_functions_are_checked() {
        for (token, input, expected) in [
            (Token::Sqr, 9.0, 3.0),
            (Token::Log, 1.0, 0.0),
            (Token::Exp, 0.0, 1.0),
            (Token::Cos, 0.0, 1.0),
            (Token::Sin, 0.0, 0.0),
            (Token::Tan, 0.0, 0.0),
            (Token::Atn, 0.0, 0.0),
        ] {
            assert_eq!(
                call(token, vec![Value::real(input).unwrap()]).unwrap(),
                Value::real(expected).unwrap(),
                "{}",
                token.to_text()
            );
        }

        assert_eq!(
            call(Token::Sqr, vec![Value::Integer(9)]).unwrap(),
            Value::real(3.0).unwrap()
        );
        assert_eq!(
            call(Token::Sqr, vec![Value::Integer(-1)]).unwrap_err(),
            Error::MathDomain { function: "SQR" }
        );
        assert_eq!(
            call(Token::Log, vec![Value::Integer(0)]).unwrap_err(),
            Error::MathDomain { function: "LOG" }
        );
        assert_eq!(
            call(Token::Exp, vec![Value::Integer(1000)]).unwrap_err(),
            Error::RealOverflow
        );
        assert_eq!(
            call(Token::Sqr, vec![Value::Integer(9_007_199_254_740_993)]).unwrap_err(),
            Error::InexactRealConversion {
                value: 9_007_199_254_740_993
            }
        );
    }

    #[test]
    fn native_math_functions_produce_expected_nontrivial_values() {
        let cases = [
            (Token::Sqr, 2.0, std::f64::consts::SQRT_2),
            (Token::Log, 2.0, std::f64::consts::LN_2),
            (Token::Exp, 1.0, std::f64::consts::E),
            (Token::Sin, std::f64::consts::FRAC_PI_2, 1.0),
            (Token::Cos, std::f64::consts::PI, -1.0),
            (Token::Tan, std::f64::consts::FRAC_PI_4, 1.0),
            (Token::Atn, 1.0, std::f64::consts::FRAC_PI_4),
        ];
        for (token, input, expected) in cases {
            let Value::Real(actual) = call(token, vec![Value::real(input).unwrap()]).unwrap()
            else {
                panic!("{} did not return a real", token.to_text());
            };
            assert!(
                (actual.value() - expected).abs() < 1e-12,
                "{}({input}) returned {} instead of {expected}",
                token.to_text(),
                actual.value()
            );
        }
    }

    #[test]
    fn ti_basic_scalar_rounding_and_parts_are_checked() {
        assert_eq!(
            call(
                Token::Round,
                vec![Value::real(1.25).unwrap(), Value::Integer(1)]
            )
            .unwrap(),
            Value::real(1.3).unwrap()
        );
        assert_eq!(
            call(
                Token::Round,
                vec![Value::real(-1.25).unwrap(), Value::Integer(1)]
            )
            .unwrap(),
            Value::real(-1.3).unwrap()
        );
        assert_eq!(
            call(Token::Round, vec![Value::Integer(i64::MAX)]).unwrap(),
            Value::Integer(i64::MAX)
        );
        assert_eq!(
            call(Token::Ipart, vec![Value::real(-3.75).unwrap()]).unwrap(),
            Value::real(-3.0).unwrap()
        );
        assert_eq!(
            call(Token::Fpart, vec![Value::real(-3.75).unwrap()]).unwrap(),
            Value::real(-0.75).unwrap()
        );
        for places in [-1, 10] {
            assert_eq!(
                call(
                    Token::Round,
                    vec![Value::real(1.25).unwrap(), Value::Integer(places)]
                )
                .unwrap_err(),
                Error::IllegalQuantity
            );
        }
    }

    #[test]
    fn ti_basic_scalar_minimum_and_maximum_preserve_values() {
        assert_eq!(
            call(Token::Min, vec![Value::Integer(9), Value::Integer(-4)]).unwrap(),
            Value::Integer(-4)
        );
        assert_eq!(
            call(
                Token::Max,
                vec![Value::real(2.5).unwrap(), Value::Integer(2)]
            )
            .unwrap(),
            Value::real(2.5).unwrap()
        );
        assert_eq!(
            call(
                Token::Min,
                vec![
                    Value::Integer(9_007_199_254_740_993),
                    Value::real(1.0).unwrap()
                ]
            )
            .unwrap_err(),
            Error::InexactRealConversion {
                value: 9_007_199_254_740_993
            }
        );
    }

    #[test]
    fn ti_basic_integer_pair_functions_are_exact_and_bounded() {
        assert_eq!(
            call(Token::Gcd, vec![Value::Integer(54), Value::Integer(24)]).unwrap(),
            Value::Integer(6)
        );
        assert_eq!(
            call(Token::Lcm, vec![Value::Integer(54), Value::Integer(24)]).unwrap(),
            Value::Integer(216)
        );
        assert_eq!(
            call(
                Token::Remainder,
                vec![Value::Integer(17), Value::Integer(5)]
            )
            .unwrap(),
            Value::Integer(2)
        );
        assert_eq!(
            call(Token::Gcd, vec![Value::Integer(0), Value::Integer(0)]).unwrap(),
            Value::Integer(0)
        );
        assert_eq!(
            call(Token::Lcm, vec![Value::Integer(0), Value::Integer(9)]).unwrap(),
            Value::Integer(0)
        );
        assert_eq!(
            call(
                Token::Remainder,
                vec![Value::Integer(17), Value::Integer(0)]
            )
            .unwrap_err(),
            Error::DivideByZero
        );
        assert_eq!(
            call(Token::Gcd, vec![Value::Integer(-1), Value::Integer(1)]).unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            call(
                Token::Gcd,
                vec![Value::real(1.5).unwrap(), Value::Integer(1)]
            )
            .unwrap(),
            Value::Integer(1)
        );
        assert_eq!(
            call(
                Token::Lcm,
                vec![Value::Integer(i64::MAX), Value::Integer(2)]
            )
            .unwrap_err(),
            Error::IntegerOverflow
        );
    }

    #[test]
    fn ti_basic_extended_scalar_functions_cover_real_math() {
        let close = |token: Token, args: Vec<Value>, expected: f64| {
            let Value::Real(actual) = call(token, args).unwrap() else {
                panic!("{} did not return a real", token.to_text());
            };
            assert!(
                (actual.value() - expected).abs() < 1e-12,
                "{} returned {} instead of {expected}",
                token.to_text(),
                actual.value()
            );
        };

        close(
            Token::Asin,
            vec![Value::Integer(1)],
            std::f64::consts::FRAC_PI_2,
        );
        close(Token::Acos, vec![Value::Integer(1)], 0.0);
        close(Token::Sinh, vec![Value::Integer(0)], 0.0);
        close(Token::Cosh, vec![Value::Integer(0)], 1.0);
        close(Token::Tanh, vec![Value::Integer(0)], 0.0);
        close(Token::Asinh, vec![Value::Integer(0)], 0.0);
        close(Token::Acosh, vec![Value::Integer(1)], 0.0);
        close(Token::Atanh, vec![Value::Integer(0)], 0.0);
        close(
            Token::Ln,
            vec![Value::real(std::f64::consts::E).unwrap()],
            1.0,
        );
        close(Token::Log10, vec![Value::Integer(100)], 2.0);
        close(
            Token::LogBase,
            vec![Value::Integer(8), Value::Integer(2)],
            3.0,
        );
        close(Token::Cbrt, vec![Value::Integer(-8)], -2.0);
        close(
            Token::Root,
            vec![Value::Integer(-8), Value::Integer(3)],
            -2.0,
        );
        close(Token::Cube, vec![Value::Integer(-2)], -8.0);
        close(Token::Fact, vec![Value::Integer(5)], 120.0);
        close(Token::Npr, vec![Value::Integer(5), Value::Integer(2)], 20.0);
        close(Token::Ncr, vec![Value::Integer(5), Value::Integer(2)], 10.0);
        close(
            Token::Deg,
            vec![Value::real(std::f64::consts::PI).unwrap()],
            180.0,
        );
        close(Token::Rad, vec![Value::Integer(180)], std::f64::consts::PI);
        close(Token::Pi, vec![], std::f64::consts::PI);
    }

    #[test]
    fn ti_basic_extended_scalar_domains_are_structured() {
        for (token, args, expected) in [
            (
                Token::Asin,
                vec![Value::Integer(2)],
                Error::MathDomain { function: "ASIN" },
            ),
            (
                Token::Acosh,
                vec![Value::Integer(0)],
                Error::MathDomain { function: "ACOSH" },
            ),
            (
                Token::Atanh,
                vec![Value::Integer(1)],
                Error::MathDomain { function: "ATANH" },
            ),
            (
                Token::Ln,
                vec![Value::Integer(0)],
                Error::MathDomain { function: "LN" },
            ),
            (
                Token::LogBase,
                vec![Value::Integer(8), Value::Integer(1)],
                Error::MathDomain {
                    function: "LOGBASE",
                },
            ),
            (
                Token::Root,
                vec![Value::Integer(-8), Value::Integer(2)],
                Error::MathDomain { function: "ROOT" },
            ),
            (
                Token::Fact,
                vec![Value::Integer(-1)],
                Error::IllegalQuantity,
            ),
            (
                Token::Ncr,
                vec![Value::Integer(2), Value::Integer(3)],
                Error::IllegalQuantity,
            ),
        ] {
            assert_eq!(
                call(token, args).unwrap_err(),
                expected,
                "{}",
                token.to_text()
            );
        }
        assert_eq!(
            call(Token::Fact, vec![Value::Integer(171)]).unwrap_err(),
            Error::RealOverflow
        );
    }

    #[test]
    fn ti_basic_extended_random_functions_share_caller_owned_state() {
        let mut left = BasicRng::new(123);
        let mut right = BasicRng::new(123);
        for token_and_args in [
            (Token::Rand, vec![]),
            (Token::RandInt, vec![Value::Integer(-5), Value::Integer(5)]),
            (
                Token::RandNorm,
                vec![Value::Integer(10), Value::real(2.5).unwrap()],
            ),
            (
                Token::RandBin,
                vec![Value::Integer(20), Value::real(0.25).unwrap()],
            ),
        ] {
            let (token, args) = token_and_args;
            let first = evaluate_builtin(token, args.clone(), NumericMode::Modern, 1024, &mut left)
                .unwrap();
            let second =
                evaluate_builtin(token, args, NumericMode::Modern, 1024, &mut right).unwrap();
            assert_eq!(first, second, "{}", token.to_text());
        }
        assert_eq!(
            evaluate_builtin(
                Token::RandInt,
                vec![Value::Integer(2), Value::Integer(1)],
                NumericMode::Modern,
                1024,
                &mut left,
            )
            .unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            evaluate_builtin(
                Token::RandNorm,
                vec![Value::Integer(0), Value::Integer(0)],
                NumericMode::Modern,
                1024,
                &mut left,
            )
            .unwrap_err(),
            Error::IllegalQuantity
        );
    }

    #[test]
    fn rnd_uses_caller_owned_state_and_checks_its_argument() {
        let mut rng = BasicRng::default();
        let first = evaluate_builtin(
            Token::Rnd,
            vec![Value::Integer(1)],
            NumericMode::Modern,
            1024,
            &mut rng,
        )
        .unwrap();
        let repeated = evaluate_builtin(
            Token::Rnd,
            vec![Value::Integer(0)],
            NumericMode::Modern,
            1024,
            &mut rng,
        )
        .unwrap();
        assert_eq!(repeated, first);
        assert_eq!(
            evaluate_builtin(
                Token::Rnd,
                vec![Value::String("seed".to_string())],
                NumericMode::Modern,
                1024,
                &mut rng,
            )
            .unwrap_err(),
            Error::TypeMismatch
        );
    }

    #[test]
    fn val_uses_a_checked_decimal_prefix() {
        assert_eq!(
            call(Token::Val, vec![Value::String("  -123XYZ".to_string())]).unwrap(),
            Value::Integer(-123)
        );
        assert_eq!(
            call(Token::Val, vec![Value::String("NO NUMBER".to_string())]).unwrap(),
            Value::Integer(0)
        );
        assert_eq!(
            call(
                Token::Val,
                vec![Value::String(
                    "999999999999999999999999999999999999999999".to_string()
                )]
            )
            .unwrap_err(),
            Error::IntegerOverflow
        );
        assert_eq!(
            call(Token::Val, vec![Value::String(" -.25E2X".to_string())]).unwrap(),
            Value::real(-25.0).unwrap()
        );
        assert_eq!(
            call(Token::Str, vec![Value::real(1.5).unwrap()]).unwrap(),
            Value::String(" 1.5".to_string())
        );
    }

    #[test]
    fn unicode_substrings_use_character_positions() {
        let text = Value::String("AéB".to_string());
        assert_eq!(
            call(Token::Left, vec![text.clone(), Value::Integer(2)]).unwrap(),
            Value::String("Aé".to_string())
        );
        assert_eq!(
            call(Token::Right, vec![text.clone(), Value::Integer(2)]).unwrap(),
            Value::String("éB".to_string())
        );
        assert_eq!(
            call(Token::Mid, vec![text, Value::Integer(2), Value::Integer(1)]).unwrap(),
            Value::String("é".to_string())
        );
    }

    #[test]
    fn long_and_double_binary_conversions_are_little_endian_and_reversible() {
        let long = Value::Integer(0x0102_0304_0506_0708);
        let packed =
            evaluate_named_builtin("MKL$", std::slice::from_ref(&long), usize::MAX).unwrap();
        let Value::String(bytes) = &packed else {
            panic!("MKL$ did not produce a string");
        };
        assert_eq!(
            bytes.chars().map(u32::from).collect::<Vec<_>>(),
            vec![8, 7, 6, 5, 4, 3, 2, 1]
        );
        assert_eq!(
            evaluate_named_builtin("CVL", &[packed], usize::MAX).unwrap(),
            long
        );

        let double = Value::real(-12345.625).unwrap();
        let packed =
            evaluate_named_builtin("MKD$", std::slice::from_ref(&double), usize::MAX).unwrap();
        assert_eq!(packed.as_str().unwrap().chars().count(), 8);
        assert_eq!(
            evaluate_named_builtin("CVD", &[packed], usize::MAX).unwrap(),
            double
        );
    }

    #[test]
    fn packed_strings_preserve_high_bytes_and_short_inputs_convert_to_zero() {
        let packed = evaluate_named_builtin("MKI$", &[Value::Integer(-2)], usize::MAX).unwrap();
        assert_eq!(
            evaluate_named_builtin("CVI", &[packed], usize::MAX).unwrap(),
            Value::Integer(-2)
        );
        assert_eq!(
            evaluate_named_builtin("CVL", &[Value::String("short".into())], usize::MAX).unwrap(),
            Value::Integer(0)
        );
        assert_eq!(
            evaluate_named_builtin("CVD", &[Value::String("short".into())], usize::MAX).unwrap(),
            Value::Integer(0)
        );
    }

    #[test]
    fn numeric_conversions_require_one_argument_and_csng_rounds_to_binary32() {
        for name in ["CINT", "FIX", "CDBL", "CSNG"] {
            assert!(matches!(
                evaluate_named_builtin(name, &[Value::Integer(1), Value::Integer(2)], usize::MAX),
                Err(Error::Syntax { .. })
            ));
        }

        let input = Value::real(1.234_567_890_123).unwrap();
        assert_eq!(
            evaluate_named_builtin("CSNG", std::slice::from_ref(&input), usize::MAX).unwrap(),
            Value::real(f64::from(1.234_567_890_123_f64 as f32)).unwrap()
        );
        assert_eq!(
            evaluate_named_builtin("CDBL", std::slice::from_ref(&input), usize::MAX).unwrap(),
            input
        );
        assert_eq!(
            evaluate_named_builtin(
                "CINT",
                &[Value::real(9_223_372_036_854_775_808.0).unwrap()],
                usize::MAX
            ),
            Err(Error::IntegerOverflow)
        );
        assert_eq!(
            evaluate_named_builtin(
                "FIX",
                &[Value::real(-9_223_372_036_854_777_000.0).unwrap()],
                usize::MAX
            ),
            Err(Error::IntegerUnderflow)
        );
    }

    #[test]
    fn rgb_constructors_return_canonical_true_color_strings() {
        assert!(is_named_builtin("RGB"));
        assert!(is_named_builtin("RGBA"));
        assert_eq!(
            evaluate_named_builtin(
                "RGB",
                &[Value::Integer(255), Value::Integer(128), Value::Integer(0)],
                usize::MAX,
            )
            .unwrap(),
            Value::String("#ff8000".to_string())
        );
        assert_eq!(
            evaluate_named_builtin(
                "RGBA",
                &[
                    Value::Integer(1),
                    Value::Integer(2),
                    Value::Integer(3),
                    Value::Integer(128),
                ],
                usize::MAX,
            )
            .unwrap(),
            Value::String("#01020380".to_string())
        );
    }

    #[test]
    fn rgb_constructors_reject_invalid_channels_and_arity() {
        for channel in [-1, 256] {
            assert_eq!(
                evaluate_named_builtin(
                    "RGB",
                    &[
                        Value::Integer(channel),
                        Value::Integer(0),
                        Value::Integer(0)
                    ],
                    usize::MAX,
                )
                .unwrap_err(),
                Error::IllegalQuantity
            );
        }
        assert_eq!(
            evaluate_named_builtin(
                "RGB",
                &[
                    Value::real(1.5).unwrap(),
                    Value::Integer(0),
                    Value::Integer(0),
                ],
                usize::MAX,
            )
            .unwrap(),
            Value::String("#020000".to_string())
        );
        assert!(matches!(
            evaluate_named_builtin("RGB", &[Value::Integer(0)], usize::MAX),
            Err(Error::Syntax { .. })
        ));
    }
}
