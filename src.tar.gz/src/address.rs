use crate::error::Error;

/// A virtual address used by the `modernbasic` memory subsystem.
///
/// The original Microsoft BASIC for 6502 kept program and variable pointers in
/// 16-bit zero-page cells.  This port widens those pointers to 64 bits but
/// forbids implicit conversion to `usize`; all conversions must go through the
/// checked, bounds-checked helpers below.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct VirtualAddress(u64);

impl VirtualAddress {
    /// Create an address from an unsigned 64-bit value.
    pub const fn new(addr: u64) -> Self {
        VirtualAddress(addr)
    }

    /// Create an address from a signed value, rejecting negative values.
    pub fn from_i64(addr: i64) -> Result<Self, Error> {
        if addr < 0 {
            return Err(Error::NegativeVirtualAddress { value: addr });
        }
        Ok(VirtualAddress(addr as u64))
    }

    /// The raw 64-bit address.
    pub const fn as_u64(self) -> u64 {
        self.0
    }

    /// Add an unsigned offset, checking for `u64` overflow.
    pub fn checked_add_offset(self, offset: u64) -> Result<Self, Error> {
        let sum = self
            .0
            .checked_add(offset)
            .ok_or(Error::VirtualAddressOutOfBounds {
                address: u64::MAX,
                limit: u64::MAX,
            })?;
        Ok(VirtualAddress(sum))
    }

    /// Convert to `usize` only after verifying the address is within a region.
    pub fn to_usize_in_region(self, region: &[u8]) -> Result<usize, Error> {
        let len = region.len() as u64;
        if self.0 >= len {
            return Err(Error::VirtualAddressOutOfBounds {
                address: self.0,
                limit: len,
            });
        }
        Ok(self.0 as usize)
    }

    /// Convert to `usize` against an explicit length bound.
    pub fn to_usize(self, limit: usize) -> Result<usize, Error> {
        let limit_u64 = limit as u64;
        if self.0 >= limit_u64 {
            return Err(Error::VirtualAddressOutOfBounds {
                address: self.0,
                limit: limit_u64,
            });
        }
        Ok(self.0 as usize)
    }
}

impl From<u64> for VirtualAddress {
    fn from(addr: u64) -> Self {
        VirtualAddress::new(addr)
    }
}
