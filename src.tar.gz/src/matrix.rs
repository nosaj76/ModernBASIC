//! Checked Dartmouth BASIC vector and matrix arithmetic.
//!
//! MAT operates on components starting at one. Array element zero (and row or
//! column zero for matrices) remains available to ordinary BASIC expressions
//! but is deliberately excluded here, matching Dartmouth BASIC's convention.

use crate::arrays::ArrayStore;
use crate::complex::BasicComplex;
use crate::error::Error;
use crate::integer::{BasicInteger, NumericMode};
use crate::real::BasicReal;
use crate::storage::StorageBudget;
use crate::value::Value;

/// The active Dartmouth shape of an array.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum MatrixShape {
    /// A one-dimensional array, interpreted as a column vector.
    Vector(usize),
    /// Dartmouth's `DIM A(0,N)` representation of a one-row vector.
    RowVector(usize),
    /// A conventional rows-by-columns matrix.
    Matrix { rows: usize, columns: usize },
}

impl MatrixShape {
    pub(crate) fn rows_columns(self) -> (usize, usize) {
        match self {
            Self::Vector(length) => (length, 1),
            Self::RowVector(length) => (1, length),
            Self::Matrix { rows, columns } => (rows, columns),
        }
    }

    pub(crate) fn upper_bounds(self) -> Vec<usize> {
        match self {
            Self::Vector(length) => vec![length],
            Self::RowVector(length) => vec![0, length],
            Self::Matrix { rows, columns } => vec![rows, columns],
        }
    }

    pub(crate) fn logical_len(self) -> Result<usize, Error> {
        let (rows, columns) = self.rows_columns();
        rows.checked_mul(columns).ok_or(Error::ArrayTooLarge)
    }
}

/// Dense temporary value used to make MAT operations alias-safe and atomic.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Matrix {
    shape: MatrixShape,
    values: Vec<Value>,
}

impl Matrix {
    pub(crate) fn from_values(shape: MatrixShape, values: Vec<Value>) -> Result<Self, Error> {
        if values.len() != shape.logical_len()? {
            return Err(Error::syntax(
                "internal MAT value count does not match its dimensions",
            ));
        }
        if values.iter().any(|value| !value.is_numeric()) {
            return Err(Error::TypeMismatch);
        }
        Ok(Self { shape, values })
    }

    /// Snapshot a numeric BASIC array. A missing name becomes an implicit
    /// 10-by-10 matrix, as required by Dartmouth's default dimension rule.
    pub(crate) fn from_store(arrays: &mut ArrayStore, name: &str) -> Result<Self, Error> {
        arrays.ensure_numeric_mat(name, 2)?;
        let array = arrays
            .get(name)
            .ok_or_else(|| Error::syntax("internal MAT source array missing"))?;
        let shape = match array.dims() {
            [length] => MatrixShape::Vector(length.saturating_sub(1)),
            [1, columns] => MatrixShape::RowVector(columns.saturating_sub(1)),
            [rows, columns] => MatrixShape::Matrix {
                rows: rows.saturating_sub(1),
                columns: columns.saturating_sub(1),
            },
            dimensions => {
                return Err(Error::MatrixRankUnsupported {
                    dimensions: dimensions.len(),
                })
            }
        };

        let mut values = new_values(shape.logical_len()?, Value::Integer(0))?;
        match shape {
            MatrixShape::Vector(length) => {
                for index in 1..=length {
                    values[index - 1] = array.load(&[to_i64(index)?])?;
                }
            }
            MatrixShape::RowVector(length) => {
                for column in 1..=length {
                    values[column - 1] = array.load(&[0, to_i64(column)?])?;
                }
            }
            MatrixShape::Matrix { rows, columns } => {
                for row in 1..=rows {
                    for column in 1..=columns {
                        values[(row - 1) * columns + column - 1] =
                            array.load(&[to_i64(row)?, to_i64(column)?])?;
                    }
                }
            }
        }
        Ok(Self { shape, values })
    }

    pub(crate) fn filled(shape: MatrixShape, value: Value) -> Result<Self, Error> {
        if !value.is_numeric() {
            return Err(Error::TypeMismatch);
        }
        Ok(Self {
            shape,
            values: new_values(shape.logical_len()?, value)?,
        })
    }

    pub(crate) fn identity(shape: MatrixShape) -> Result<Self, Error> {
        let MatrixShape::Matrix { rows, columns } = shape else {
            return Err(Error::MatrixNotSquare {
                rows: shape.rows_columns().0,
                columns: shape.rows_columns().1,
            });
        };
        let mut result = Self::filled(shape, Value::Integer(0))?;
        for diagonal in 0..rows.min(columns) {
            result.values[diagonal * columns + diagonal] = Value::Integer(1);
        }
        Ok(result)
    }

    pub(crate) fn shape(&self) -> MatrixShape {
        self.shape
    }

    pub(crate) fn values(&self) -> &[Value] {
        &self.values
    }

    pub(crate) fn add(&self, rhs: &Self, mode: NumericMode) -> Result<Self, Error> {
        self.elementwise(rhs, mode, NumericOperation::Add)
    }

    pub(crate) fn subtract(&self, rhs: &Self, mode: NumericMode) -> Result<Self, Error> {
        self.elementwise(rhs, mode, NumericOperation::Subtract)
    }

    fn elementwise(
        &self,
        rhs: &Self,
        mode: NumericMode,
        operation: NumericOperation,
    ) -> Result<Self, Error> {
        if self.shape != rhs.shape {
            return Err(Error::MatrixDimensionMismatch);
        }
        let values = self
            .values
            .iter()
            .zip(&rhs.values)
            .map(|(left, right)| numeric_binary(left, right, mode, operation))
            .collect::<Result<Vec<_>, _>>()?;
        Ok(Self {
            shape: self.shape,
            values,
        })
    }

    pub(crate) fn multiply(
        &self,
        rhs: &Self,
        mode: NumericMode,
        operation_limit: usize,
    ) -> Result<Self, Error> {
        let (left_rows, left_columns) = self.shape.rows_columns();
        let (right_rows, right_columns) = rhs.shape.rows_columns();
        if left_columns != right_rows {
            return Err(Error::MatrixDimensionMismatch);
        }
        check_operation_limit(
            checked_operation_product(&[left_rows, right_columns, left_columns]),
            operation_limit,
        )?;
        let shape = match (self.shape, rhs.shape) {
            (MatrixShape::RowVector(_), MatrixShape::Vector(_)) => MatrixShape::Matrix {
                rows: 1,
                columns: 1,
            },
            (_, MatrixShape::Vector(_)) => MatrixShape::Vector(left_rows),
            (MatrixShape::RowVector(_), _) => MatrixShape::RowVector(right_columns),
            _ => MatrixShape::Matrix {
                rows: left_rows,
                columns: right_columns,
            },
        };
        let mut values = new_values(shape.logical_len()?, Value::Integer(0))?;
        for row in 0..left_rows {
            for column in 0..right_columns {
                let mut sum = Value::Integer(0);
                for inner in 0..left_columns {
                    let product = numeric_binary(
                        &self.values[row * left_columns + inner],
                        &rhs.values[inner * right_columns + column],
                        mode,
                        NumericOperation::Multiply,
                    )?;
                    sum = numeric_binary(&sum, &product, mode, NumericOperation::Add)?;
                }
                values[row * right_columns + column] = sum;
            }
        }
        Ok(Self { shape, values })
    }

    pub(crate) fn scale(&self, scalar: &Value, mode: NumericMode) -> Result<Self, Error> {
        if !scalar.is_numeric() {
            return Err(Error::TypeMismatch);
        }
        let values = self
            .values
            .iter()
            .map(|value| numeric_binary(scalar, value, mode, NumericOperation::Multiply))
            .collect::<Result<Vec<_>, _>>()?;
        Ok(Self {
            shape: self.shape,
            values,
        })
    }

    pub(crate) fn transpose(&self) -> Result<Self, Error> {
        let (rows, columns) = self.shape.rows_columns();
        let shape = match self.shape {
            MatrixShape::Vector(length) => MatrixShape::RowVector(length),
            MatrixShape::RowVector(length) => MatrixShape::Vector(length),
            MatrixShape::Matrix { .. } => MatrixShape::Matrix {
                rows: columns,
                columns: rows,
            },
        };
        let mut values = new_values(shape.logical_len()?, Value::Integer(0))?;
        for row in 0..rows {
            for column in 0..columns {
                values[column * rows + row] = self.values[row * columns + column].clone();
            }
        }
        Ok(Self { shape, values })
    }

    /// Invert a square matrix with Gauss-Jordan elimination and partial
    /// pivoting. A singular matrix succeeds with a zero result and `DET = 0`,
    /// matching Dartmouth BASIC rather than terminating the program.
    pub(crate) fn inverse(&self, operation_limit: usize) -> Result<(Self, Value), Error> {
        let MatrixShape::Matrix { rows, columns } = self.shape else {
            let (rows, columns) = self.shape.rows_columns();
            return Err(Error::MatrixNotSquare { rows, columns });
        };
        if rows != columns {
            return Err(Error::MatrixNotSquare { rows, columns });
        }
        let n = rows;
        let elimination_operations = checked_operation_product(&[2, n, n, n]);
        check_operation_limit(elimination_operations, operation_limit)?;
        if self
            .values
            .iter()
            .any(|value| matches!(value, Value::Complex(_)))
        {
            return self.inverse_complex(n);
        }
        let zero = BasicReal::new(0.0)?;
        let one = BasicReal::new(1.0)?;
        let mut left = self
            .values
            .iter()
            .map(value_to_real)
            .collect::<Result<Vec<_>, _>>()?;
        let mut right = new_reals(n.checked_mul(n).ok_or(Error::ArrayTooLarge)?, zero)?;
        for diagonal in 0..n {
            right[diagonal * n + diagonal] = one;
        }
        let mut determinant = one;

        for column in 0..n {
            let mut pivot_row = column;
            let mut pivot_magnitude = left[column * n + column].value().abs();
            for row in column + 1..n {
                let magnitude = left[row * n + column].value().abs();
                if magnitude > pivot_magnitude {
                    pivot_row = row;
                    pivot_magnitude = magnitude;
                }
            }
            if pivot_magnitude == 0.0 {
                return Ok((
                    Self::filled(self.shape, Value::Integer(0))?,
                    Value::Integer(0),
                ));
            }
            if pivot_row != column {
                for index in 0..n {
                    left.swap(column * n + index, pivot_row * n + index);
                    right.swap(column * n + index, pivot_row * n + index);
                }
                determinant = determinant.neg()?;
            }

            let pivot = left[column * n + column];
            determinant = determinant.mul(pivot)?;
            for index in 0..n {
                left[column * n + index] = left[column * n + index].div(pivot)?;
                right[column * n + index] = right[column * n + index].div(pivot)?;
            }

            for row in 0..n {
                if row == column {
                    continue;
                }
                let factor = left[row * n + column];
                for index in 0..n {
                    left[row * n + index] =
                        left[row * n + index].sub(factor.mul(left[column * n + index])?)?;
                    right[row * n + index] =
                        right[row * n + index].sub(factor.mul(right[column * n + index])?)?;
                }
            }
        }

        Ok((
            Self {
                shape: self.shape,
                values: right.into_iter().map(Value::Real).collect(),
            },
            Value::Real(determinant),
        ))
    }

    fn inverse_complex(&self, n: usize) -> Result<(Self, Value), Error> {
        let zero = BasicComplex::new(0.0, 0.0)?;
        let one = BasicComplex::new(1.0, 0.0)?;
        let mut left = self
            .values
            .iter()
            .map(value_to_complex)
            .collect::<Result<Vec<_>, _>>()?;
        let mut right = new_complexes(n.checked_mul(n).ok_or(Error::ArrayTooLarge)?, zero)?;
        for diagonal in 0..n {
            right[diagonal * n + diagonal] = one;
        }
        let mut determinant = one;

        for column in 0..n {
            let mut pivot_row = column;
            let mut pivot_magnitude = left[column * n + column].magnitude()?.value();
            for row in column + 1..n {
                let magnitude = left[row * n + column].magnitude()?.value();
                if magnitude > pivot_magnitude {
                    pivot_row = row;
                    pivot_magnitude = magnitude;
                }
            }
            if pivot_magnitude == 0.0 {
                return Ok((
                    Self::filled(self.shape, Value::Integer(0))?,
                    Value::Integer(0),
                ));
            }
            if pivot_row != column {
                for index in 0..n {
                    left.swap(column * n + index, pivot_row * n + index);
                    right.swap(column * n + index, pivot_row * n + index);
                }
                determinant = determinant.neg()?;
            }

            let pivot = left[column * n + column];
            determinant = determinant.mul(pivot)?;
            for index in 0..n {
                left[column * n + index] = left[column * n + index].div(pivot)?;
                right[column * n + index] = right[column * n + index].div(pivot)?;
            }

            for row in 0..n {
                if row == column {
                    continue;
                }
                let factor = left[row * n + column];
                for index in 0..n {
                    left[row * n + index] =
                        left[row * n + index].sub(factor.mul(left[column * n + index])?)?;
                    right[row * n + index] =
                        right[row * n + index].sub(factor.mul(right[column * n + index])?)?;
                }
            }
        }

        Ok((
            Self {
                shape: self.shape,
                values: right.into_iter().map(Value::Complex).collect(),
            },
            Value::Complex(determinant),
        ))
    }

    pub(crate) fn store_as(
        &self,
        arrays: &mut ArrayStore,
        storage: &mut StorageBudget,
        name: &str,
    ) -> Result<(), Error> {
        arrays.replace_numeric_mat(name, &self.shape.upper_bounds(), &self.values, storage)
    }
}

#[derive(Debug, Clone, Copy)]
enum NumericOperation {
    Add,
    Subtract,
    Multiply,
}

fn numeric_binary(
    left: &Value,
    right: &Value,
    mode: NumericMode,
    operation: NumericOperation,
) -> Result<Value, Error> {
    if let (Value::Integer(left), Value::Integer(right)) = (left, right) {
        let left = BasicInteger::with_mode(mode, *left)?;
        let right = BasicInteger::with_mode(mode, *right)?;
        let value = match operation {
            NumericOperation::Add => left.add(right),
            NumericOperation::Subtract => left.sub(right),
            NumericOperation::Multiply => left.mul(right),
        }?;
        return Ok(Value::Integer(value.value()));
    }

    if matches!(left, Value::Complex(_)) || matches!(right, Value::Complex(_)) {
        let left = value_to_complex(left)?;
        let right = value_to_complex(right)?;
        let value = match operation {
            NumericOperation::Add => left.add(right),
            NumericOperation::Subtract => left.sub(right),
            NumericOperation::Multiply => left.mul(right),
        }?;
        return Ok(Value::Complex(value));
    }

    let left = value_to_real(left)?;
    let right = value_to_real(right)?;
    let value = match operation {
        NumericOperation::Add => left.add(right),
        NumericOperation::Subtract => left.sub(right),
        NumericOperation::Multiply => left.mul(right),
    }?;
    Ok(Value::Real(value))
}

fn value_to_complex(value: &Value) -> Result<BasicComplex, Error> {
    match value {
        Value::Integer(value) => Ok(BasicComplex::from_real(BasicReal::from_integer(*value)?)),
        Value::Real(value) => Ok(BasicComplex::from_real(*value)),
        Value::Complex(value) => Ok(*value),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn value_to_real(value: &Value) -> Result<BasicReal, Error> {
    match value {
        Value::Integer(value) => BasicReal::from_integer(*value),
        Value::Real(value) => Ok(*value),
        Value::Complex(_) | Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn new_values(length: usize, value: Value) -> Result<Vec<Value>, Error> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(length)
        .map_err(|_| Error::ArrayTooLarge)?;
    values.resize(length, value);
    Ok(values)
}

fn new_reals(length: usize, value: BasicReal) -> Result<Vec<BasicReal>, Error> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(length)
        .map_err(|_| Error::ArrayTooLarge)?;
    values.resize(length, value);
    Ok(values)
}

fn new_complexes(length: usize, value: BasicComplex) -> Result<Vec<BasicComplex>, Error> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(length)
        .map_err(|_| Error::ArrayTooLarge)?;
    values.resize(length, value);
    Ok(values)
}

fn to_i64(value: usize) -> Result<i64, Error> {
    i64::try_from(value).map_err(|_| Error::ArrayTooLarge)
}

fn checked_operation_product(factors: &[usize]) -> usize {
    factors
        .iter()
        .try_fold(1usize, |product, factor| product.checked_mul(*factor))
        .unwrap_or(usize::MAX)
}

fn check_operation_limit(operations: usize, limit: usize) -> Result<(), Error> {
    if operations > limit {
        return Err(Error::MatrixOperationLimitExceeded { operations, limit });
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn matrix(rows: usize, columns: usize, values: &[i64]) -> Matrix {
        Matrix {
            shape: MatrixShape::Matrix { rows, columns },
            values: values.iter().copied().map(Value::Integer).collect(),
        }
    }

    #[test]
    fn checked_integer_matrix_arithmetic_preserves_exact_values() {
        let left = matrix(2, 2, &[1, 2, 3, 4]);
        let right = matrix(2, 2, &[5, 6, 7, 8]);
        assert_eq!(
            left.add(&right, NumericMode::Modern).unwrap().values,
            [6, 8, 10, 12].map(Value::Integer)
        );
        assert_eq!(
            left.multiply(&right, NumericMode::Modern, usize::MAX)
                .unwrap()
                .values,
            [19, 22, 43, 50].map(Value::Integer)
        );
    }

    #[test]
    fn integer_overflow_is_never_hidden_by_matrix_arithmetic() {
        let left = matrix(1, 1, &[i64::MAX]);
        let right = matrix(1, 1, &[1]);
        assert_eq!(
            left.add(&right, NumericMode::Modern).unwrap_err(),
            Error::IntegerOverflow
        );
    }

    #[test]
    fn inverse_returns_determinant_and_identity_product() -> Result<(), Error> {
        let source = matrix(2, 2, &[4, 7, 2, 6]);
        let (inverse, determinant) = source.inverse(usize::MAX).unwrap();
        assert_eq!(determinant, Value::real(10.0).unwrap());
        let product = source
            .multiply(&inverse, NumericMode::Modern, usize::MAX)
            .unwrap();
        let actual = product
            .values
            .iter()
            .map(value_to_real)
            .collect::<Result<Vec<_>, _>>()?;
        let expected = [1.0, 0.0, 0.0, 1.0];
        for (actual, expected) in actual.iter().zip(expected) {
            assert!((actual.value() - expected).abs() < 1e-12);
        }
        Ok(())
    }

    #[test]
    fn singular_inverse_sets_zero_determinant_without_error() {
        let source = matrix(2, 2, &[1, 2, 2, 4]);
        let (inverse, determinant) = source.inverse(usize::MAX).unwrap();
        assert_eq!(determinant, Value::Integer(0));
        assert!(inverse
            .values
            .iter()
            .all(|value| *value == Value::Integer(0)));
    }

    #[test]
    fn transpose_preserves_dartmouth_column_and_row_vector_kinds() {
        let column = Matrix::from_values(
            MatrixShape::Vector(3),
            vec![Value::Integer(1), Value::Integer(2), Value::Integer(3)],
        )
        .unwrap();
        let row = column.transpose().unwrap();
        assert_eq!(row.shape, MatrixShape::RowVector(3));
        assert_eq!(row.transpose().unwrap().shape, MatrixShape::Vector(3));
    }

    #[test]
    fn expensive_multiply_and_inverse_are_rejected_before_work_begins() {
        let value = matrix(2, 2, &[1, 0, 0, 1]);
        assert_eq!(
            value.multiply(&value, NumericMode::Modern, 7).unwrap_err(),
            Error::MatrixOperationLimitExceeded {
                operations: 8,
                limit: 7,
            }
        );
        assert_eq!(
            value.inverse(15).unwrap_err(),
            Error::MatrixOperationLimitExceeded {
                operations: 16,
                limit: 15,
            }
        );
    }

    #[test]
    fn complex_matrix_arithmetic_and_inverse_are_checked() {
        let source = Matrix::from_values(
            MatrixShape::Matrix {
                rows: 2,
                columns: 2,
            },
            vec![
                Value::Complex(BasicComplex::new(1.0, 1.0).unwrap()),
                Value::Integer(0),
                Value::Integer(0),
                Value::Complex(BasicComplex::new(2.0, -1.0).unwrap()),
            ],
        )
        .unwrap();
        let product = source
            .multiply(&source, NumericMode::Modern, usize::MAX)
            .unwrap();
        assert_eq!(
            product.values,
            vec![
                Value::Complex(BasicComplex::new(0.0, 2.0).unwrap()),
                Value::Complex(BasicComplex::new(0.0, 0.0).unwrap()),
                Value::Complex(BasicComplex::new(0.0, 0.0).unwrap()),
                Value::Complex(BasicComplex::new(3.0, -4.0).unwrap()),
            ]
        );

        let (inverse, determinant) = source.inverse(usize::MAX).unwrap();
        let Value::Complex(determinant) = determinant else {
            panic!("complex inverse did not return a complex determinant")
        };
        assert!((determinant.real().value() - 3.0).abs() < 1e-12);
        assert!((determinant.imaginary().value() - 1.0).abs() < 1e-12);
        let identity = source
            .multiply(&inverse, NumericMode::Modern, usize::MAX)
            .unwrap();
        for (index, value) in identity.values.iter().enumerate() {
            let value = value_to_complex(value).unwrap();
            let expected = if index == 0 || index == 3 { 1.0 } else { 0.0 };
            assert!((value.real().value() - expected).abs() < 1e-12);
            assert!(value.imaginary().value().abs() < 1e-12);
        }
    }
}
