//! Retained, bounded still-frame sequences for movie playback and export.
//!
//! A flipbook is deliberately not a second drawing engine. Each frame is a
//! complete still image produced by ModernBASIC painting statements or loaded
//! from a sandboxed image asset. PLAY and VIDEO consume this same sequence.

#[cfg(test)]
use std::path::PathBuf;
use std::sync::Arc;

use crate::error::Error;
#[cfg(test)]
use crate::image_codec::decode_image;
use crate::image_codec::fit_letterboxed;
use crate::video::{MAX_VIDEO_FPS, MAX_VIDEO_SECONDS};

pub(crate) const MAX_FLIPBOOK_FRAMES: usize = MAX_VIDEO_FPS as usize * MAX_VIDEO_SECONDS as usize;

#[derive(Debug, Clone)]
pub(crate) struct FlipbookSequence {
    id: String,
    frames: Vec<Arc<crate::image_codec::RgbImage>>,
    fps: u32,
    native_dimensions: (usize, usize),
}

impl FlipbookSequence {
    #[cfg(test)]
    pub(crate) fn new(id: &str, frames: Vec<PathBuf>, fps: i64) -> Result<Self, Error> {
        let frames = frames
            .iter()
            .map(|path| decode_image(path).map(Arc::new))
            .collect::<Result<Vec<_>, _>>()?;
        Self::from_images(id, frames, fps)
    }

    /// Build a retained sequence from images decoded at the program LOAD
    /// boundary. Playback and export never reopen the original frame files.
    pub(crate) fn from_images(
        id: &str,
        frames: Vec<Arc<crate::image_codec::RgbImage>>,
        fps: i64,
    ) -> Result<Self, Error> {
        validate_id(id)?;
        let fps = u32::try_from(fps).map_err(|_| Error::IllegalQuantity)?;
        if !(1..=MAX_VIDEO_FPS).contains(&fps) || frames.is_empty() {
            return Err(Error::IllegalQuantity);
        }
        if frames.len() > MAX_FLIPBOOK_FRAMES {
            return Err(Error::syntax("FLIPBOOK duration exceeds 30 minutes"));
        }
        let native_dimensions = (frames[0].width, frames[0].height);
        Ok(Self {
            id: id.to_ascii_uppercase(),
            frames,
            fps,
            native_dimensions,
        })
    }

    pub(crate) fn id(&self) -> &str {
        &self.id
    }

    pub(crate) fn fps(&self) -> u32 {
        self.fps
    }

    pub(crate) fn native_dimensions(&self) -> (usize, usize) {
        self.native_dimensions
    }

    /// Decode complete frames in order and letterbox them to the configured
    /// screen. Only one decoded still is retained at a time.
    pub(crate) fn stream_frames<F>(
        &self,
        target_width: usize,
        target_height: usize,
        mut consume: F,
    ) -> Result<(), Error>
    where
        F: FnMut(usize, Arc<[u8]>) -> Result<(), Error>,
    {
        for (index, image) in self.frames.iter().enumerate() {
            let image = fit_letterboxed(image, target_width, target_height)?;
            consume(index, Arc::from(image.to_ppm()?))?;
        }
        Ok(())
    }
}

/// Expand exactly one contiguous field of `#` characters. A template such as
/// `frame####.png` maps frame 7 to `frame0007.png`.
pub(crate) fn expand_frame_template(
    template: &str,
    first: i64,
    last: i64,
) -> Result<Vec<String>, Error> {
    if first < 0 || last < first {
        return Err(Error::IllegalQuantity);
    }
    let start = template
        .find('#')
        .ok_or_else(|| Error::syntax("FLIPBOOK template requires a # number field"))?;
    let width = template[start..]
        .bytes()
        .take_while(|byte| *byte == b'#')
        .count();
    if width == 0 || width > 12 || template[start + width..].contains('#') {
        return Err(Error::syntax(
            "FLIPBOOK template requires one contiguous field of 1 to 12 # characters",
        ));
    }
    let count = last
        .checked_sub(first)
        .and_then(|span| span.checked_add(1))
        .and_then(|count| usize::try_from(count).ok())
        .ok_or(Error::IntegerOverflow)?;
    if count > MAX_FLIPBOOK_FRAMES {
        return Err(Error::syntax("FLIPBOOK duration exceeds 30 minutes"));
    }
    let prefix = &template[..start];
    let suffix = &template[start + width..];
    let mut paths = Vec::with_capacity(count);
    for number in first..=last {
        paths.push(format!("{prefix}{number:0width$}{suffix}"));
    }
    Ok(paths)
}

fn validate_id(id: &str) -> Result<(), Error> {
    let mut characters = id.chars();
    if id.len() > 64
        || !characters
            .next()
            .is_some_and(|character| character.is_ascii_alphabetic() || character == '_')
        || !characters.all(|character| character.is_ascii_alphanumeric() || character == '_')
    {
        return Err(Error::syntax("invalid FLIPBOOK identifier"));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use std::sync::atomic::{AtomicU64, Ordering};

    use super::*;
    use crate::image_codec::RgbImage;

    fn temporary_root() -> PathBuf {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        std::env::temp_dir().join(format!(
            "modernbasic-flipbook-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ))
    }

    #[test]
    fn template_expansion_is_ordered_and_unambiguous() {
        assert_eq!(
            expand_frame_template("page####.ppm", 7, 9).unwrap(),
            ["page0007.ppm", "page0008.ppm", "page0009.ppm"]
        );
        assert!(expand_frame_template("page.ppm", 1, 2).is_err());
        assert!(expand_frame_template("a##b##.ppm", 1, 2).is_err());
        assert!(expand_frame_template("page#.ppm", 2, 1).is_err());
    }

    #[test]
    fn ppm_flipbook_streams_complete_letterboxed_frames() {
        let root = temporary_root();
        std::fs::create_dir(&root).unwrap();
        let mut frames = Vec::new();
        for (number, color) in [(1_u8, [255, 0, 0]), (2_u8, [0, 255, 0])] {
            let path = root.join(format!("page{number:04}.ppm"));
            let image = RgbImage {
                width: 2,
                height: 1,
                pixels: vec![color; 2],
                alpha: vec![255; 2],
            };
            std::fs::write(&path, image.to_ppm().unwrap()).unwrap();
            frames.push(path);
        }
        let flipbook = FlipbookSequence::new("DEMO", frames, 24).unwrap();
        let mut projected = Vec::new();
        flipbook
            .stream_frames(4, 4, |index, ppm| {
                projected.push((index, ppm));
                Ok(())
            })
            .unwrap();
        assert_eq!(flipbook.id(), "DEMO");
        assert_eq!(flipbook.fps(), 24);
        assert_eq!(flipbook.native_dimensions(), (2, 1));
        assert_eq!(projected.len(), 2);
        assert!(projected
            .iter()
            .all(|(_, ppm)| ppm.starts_with(b"P6\n4 4\n255\n")));
        std::fs::remove_dir_all(root).unwrap();
    }
}
