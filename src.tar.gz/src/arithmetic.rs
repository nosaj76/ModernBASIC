use crate::error::Error;

/// Checked 64-bit addition.
pub fn checked_add(a: i64, b: i64) -> Result<i64, Error> {
    a.checked_add(b).ok_or(Error::IntegerOverflow)
}

/// Checked 64-bit subtraction.
pub fn checked_sub(a: i64, b: i64) -> Result<i64, Error> {
    a.checked_sub(b).ok_or(Error::IntegerUnderflow)
}

/// Checked 64-bit multiplication.
pub fn checked_mul(a: i64, b: i64) -> Result<i64, Error> {
    a.checked_mul(b).ok_or(Error::IntegerOverflow)
}

/// Checked 64-bit integer division (`/` in BASIC on integers).
pub fn checked_div(a: i64, b: i64) -> Result<i64, Error> {
    if b == 0 {
        return Err(Error::DivideByZero);
    }
    a.checked_div(b).ok_or(Error::IntegerOverflow)
}

/// Alias for `checked_div`; satisfies the explicit "integer-divide" requirement.
pub fn checked_integer_divide(a: i64, b: i64) -> Result<i64, Error> {
    checked_div(a, b)
}

/// Checked 64-bit modulo (`MOD`).
pub fn checked_mod(a: i64, b: i64) -> Result<i64, Error> {
    if b == 0 {
        return Err(Error::DivideByZero);
    }
    a.checked_rem(b).ok_or(Error::IntegerOverflow)
}

/// Checked 64-bit unary negation.
pub fn checked_neg(a: i64) -> Result<i64, Error> {
    a.checked_neg().ok_or(Error::IntegerOverflow)
}

/// 64-bit bitwise AND.
pub fn checked_and(a: i64, b: i64) -> Result<i64, Error> {
    Ok(a & b)
}

/// 64-bit bitwise OR.
pub fn checked_or(a: i64, b: i64) -> Result<i64, Error> {
    Ok(a | b)
}

/// 64-bit bitwise XOR.
pub fn checked_xor(a: i64, b: i64) -> Result<i64, Error> {
    Ok(a ^ b)
}

/// 64-bit bitwise NOT.
pub fn checked_not(a: i64) -> Result<i64, Error> {
    Ok(!a)
}

/// Validate a shift distance.
fn validate_shift(shift: i64) -> Result<u32, Error> {
    if !(0..64).contains(&shift) {
        return Err(Error::InvalidShift { shift });
    }
    Ok(shift as u32)
}

/// Checked left shift.  Rejects distances outside `0..64` and reports overflow.
pub fn checked_shl(a: i64, shift: i64) -> Result<i64, Error> {
    let s = validate_shift(shift)?;
    a.checked_shl(s).ok_or(Error::IntegerOverflow)
}

/// Checked arithmetic right shift.  Rejects distances outside `0..64`.
pub fn checked_shr(a: i64, shift: i64) -> Result<i64, Error> {
    let s = validate_shift(shift)?;
    a.checked_shr(s).ok_or(Error::IntegerOverflow)
}
