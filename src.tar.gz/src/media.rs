//! Bounded local and HTTP(S) media decoding for PLAY AUDIO and PLAY VIDEO.
//!
//! FFmpeg is used only through fixed arguments. BASIC cannot supply codec
//! options, filters, shell text, output paths, or non-HTTP network protocols.

use std::io::{BufReader, Read, Write};
use std::path::Path;
use std::process::{Child, Command, ExitStatus, Stdio};
use std::sync::Arc;

use crate::error::Error;
use crate::image_codec::{find_ffmpeg, find_ffprobe, read_ppm_frame};
use crate::video::{MAX_VIDEO_FPS, MAX_VIDEO_SECONDS};

const MEDIA_SAMPLE_RATE: u32 = 44_100;
const MAX_AUDIO_PCM_BYTES: u64 =
    MEDIA_SAMPLE_RATE as u64 * 2 * std::mem::size_of::<i16>() as u64 * MAX_VIDEO_SECONDS as u64;

/// Own a decoder until it has been reaped. Any early parsing, callback, or
/// stream error drops this guard and terminates the subprocess instead of
/// leaving FFmpeg running or as a zombie.
struct DecoderChild {
    child: Child,
    reaped: bool,
    input_feeder: Option<std::thread::JoinHandle<()>>,
}

impl DecoderChild {
    fn new(child: Child) -> Self {
        Self {
            child,
            reaped: false,
            input_feeder: None,
        }
    }

    fn take_stdout(&mut self) -> Result<std::process::ChildStdout, Error> {
        self.child
            .stdout
            .take()
            .ok_or_else(|| Error::Io("cannot open decoder output".into()))
    }

    fn feed_memory(&mut self, bytes: Arc<[u8]>) -> Result<(), Error> {
        let mut stdin = self
            .child
            .stdin
            .take()
            .ok_or_else(|| Error::Io("cannot open decoder input".into()))?;
        self.input_feeder = Some(std::thread::spawn(move || {
            // A decoder may deliberately stop before consuming container
            // padding. BrokenPipe is therefore normal after its exit.
            let _ = stdin.write_all(bytes.as_ref());
        }));
        Ok(())
    }

    fn join_input_feeder(&mut self) {
        if let Some(feeder) = self.input_feeder.take() {
            let _ = feeder.join();
        }
    }

    fn wait(&mut self) -> Result<ExitStatus, Error> {
        let status = self.child.wait()?;
        self.reaped = true;
        self.join_input_feeder();
        Ok(status)
    }
}

impl Drop for DecoderChild {
    fn drop(&mut self) {
        if self.reaped {
            return;
        }
        if self.child.try_wait().is_ok_and(|status| status.is_some()) {
            self.reaped = true;
            self.join_input_feeder();
            return;
        }
        let _ = self.child.kill();
        let _ = self.child.wait();
        self.reaped = true;
        self.join_input_feeder();
    }
}

#[derive(Debug, Clone)]
pub(crate) struct MediaSource {
    bytes: Arc<[u8]>,
    name: String,
}

impl MediaSource {
    pub(crate) fn memory(bytes: Arc<[u8]>, name: String) -> Self {
        Self { bytes, name }
    }

    pub(crate) fn bytes(&self) -> Arc<[u8]> {
        Arc::clone(&self.bytes)
    }

    pub(crate) fn name(&self) -> &str {
        &self.name
    }

    fn validate(&self, extensions: &[&str]) -> Result<(), Error> {
        validate_media_name(&self.name, extensions)
    }

    fn add_input(&self, command: &mut Command, input_flag: bool) {
        if input_flag {
            command.arg("-i");
        }
        command.arg("pipe:0");
    }

    fn stdin(&self) -> Stdio {
        Stdio::piped()
    }

    fn attach_input(&self, child: &mut DecoderChild) -> Result<(), Error> {
        child.feed_memory(Arc::clone(&self.bytes))
    }
}

pub(crate) fn play_audio(
    session: &crate::synth::PlaybackSession,
    source: MediaSource,
) -> Result<(), Error> {
    validate_audio_source(&source)?;
    let ffmpeg = find_ffmpeg()
        .ok_or_else(|| Error::Io("PLAY AUDIO requires FFmpeg on the host system".into()))?;
    session.playback_raw_async(MEDIA_SAMPLE_RATE, move |sink| {
        let mut command = Command::new(ffmpeg);
        command.arg("-nostdin").arg("-loglevel").arg("error");
        source.add_input(&mut command, true);
        let child = command
            .arg("-t")
            .arg(MAX_VIDEO_SECONDS.to_string())
            .arg("-vn")
            .arg("-f")
            .arg("s16le")
            .arg("-acodec")
            .arg("pcm_s16le")
            .arg("-ar")
            .arg(MEDIA_SAMPLE_RATE.to_string())
            .arg("-ac")
            .arg("2")
            .arg("pipe:1")
            .stdin(source.stdin())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|error| Error::Io(format!("cannot start audio decoder: {error}")))?;
        let mut child = DecoderChild::new(child);
        source.attach_input(&mut child)?;
        let stdout = child.take_stdout()?;
        std::io::copy(&mut stdout.take(MAX_AUDIO_PCM_BYTES), sink)?;
        let status = child.wait()?;
        if !status.success() {
            return Err(Error::Io(format!("audio decoder exited with {status}")));
        }
        Ok(())
    })
}

/// Decode a local file or HTTP(S) stream to uniformly sized PPM frames.
pub(crate) fn stream_video<F>(
    source: &MediaSource,
    width: usize,
    height: usize,
    mut consume: F,
) -> Result<f64, Error>
where
    F: FnMut(usize, Arc<[u8]>) -> Result<(), Error>,
{
    validate_video_source(source)?;
    if width == 0 || height == 0 {
        return Err(Error::IllegalQuantity);
    }
    let fps = video_frame_rate(source)?;
    let ffmpeg = find_ffmpeg()
        .ok_or_else(|| Error::Io("PLAY VIDEO requires FFmpeg on the host system".into()))?;
    let filter = format!(
        "scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:black"
    );
    let mut command = Command::new(ffmpeg);
    command.arg("-nostdin").arg("-loglevel").arg("error");
    source.add_input(&mut command, true);
    let child = command
        .arg("-t")
        .arg(MAX_VIDEO_SECONDS.to_string())
        .arg("-an")
        .arg("-vf")
        .arg(filter)
        .arg("-fps_mode")
        .arg("passthrough")
        .arg("-f")
        .arg("image2pipe")
        .arg("-vcodec")
        .arg("ppm")
        .arg("pipe:1")
        .stdin(source.stdin())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot start video decoder: {error}")))?;
    let mut child = DecoderChild::new(child);
    source.attach_input(&mut child)?;
    let stdout = child.take_stdout()?;
    let mut reader = BufReader::new(stdout);
    let maximum = MAX_VIDEO_FPS as usize * MAX_VIDEO_SECONDS as usize;
    let mut frames = 0_usize;
    while let Some(image) = read_ppm_frame(&mut reader)? {
        if frames >= maximum {
            return Err(Error::syntax("PLAY VIDEO duration exceeds 30 minutes"));
        }
        consume(frames, Arc::from(image.to_ppm()?))?;
        frames += 1;
    }
    let status = child.wait()?;
    if !status.success() {
        return Err(Error::Io(format!("video decoder exited with {status}")));
    }
    if frames == 0 {
        return Err(Error::Io("video decoder produced no frames".into()));
    }
    Ok(fps)
}

pub(crate) fn video_frame_rate(source: &MediaSource) -> Result<f64, Error> {
    validate_video_source(source)?;
    let ffprobe = find_ffprobe()
        .ok_or_else(|| Error::Io("PLAY VIDEO requires FFprobe on the host system".into()))?;
    let mut command = Command::new(ffprobe);
    command
        .arg("-v")
        .arg("error")
        .arg("-select_streams")
        .arg("v:0")
        .arg("-show_entries")
        .arg("stream=avg_frame_rate")
        .arg("-of")
        .arg("default=noprint_wrappers=1:nokey=1");
    source.add_input(&mut command, false);
    let child = command
        .stdin(source.stdin())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot start video probe: {error}")))?;
    let mut child = DecoderChild::new(child);
    source.attach_input(&mut child)?;
    let mut stdout = child.take_stdout()?;
    let mut output = Vec::new();
    stdout.by_ref().take(129).read_to_end(&mut output)?;
    let status = child.wait()?;
    if !status.success() || output.len() > 128 {
        return Err(Error::Io("video probe failed".into()));
    }
    let text = std::str::from_utf8(&output)
        .map_err(|_| Error::Io("video probe returned invalid text".into()))?
        .trim();
    let fps = if let Some((numerator, denominator)) = text.split_once('/') {
        let numerator = numerator
            .parse::<f64>()
            .map_err(|_| Error::Io("video probe returned invalid frame rate".into()))?;
        let denominator = denominator
            .parse::<f64>()
            .map_err(|_| Error::Io("video probe returned invalid frame rate".into()))?;
        numerator / denominator
    } else {
        text.parse::<f64>()
            .map_err(|_| Error::Io("video probe returned invalid frame rate".into()))?
    };
    if !fps.is_finite() || fps <= 0.0 || fps > MAX_VIDEO_FPS as f64 {
        return Err(Error::IllegalQuantity);
    }
    Ok(fps)
}

pub(crate) fn validate_audio_source(source: &MediaSource) -> Result<(), Error> {
    source.validate(&[
        "wav", "mp3", "flac", "ogg", "opus", "m4a", "aac", "mp4", "webm", "mkv", "mov", "avi",
        "m4v",
    ])
}

pub(crate) fn validate_video_source(source: &MediaSource) -> Result<(), Error> {
    source.validate(&["mp4", "webm", "mkv", "mov", "avi", "m4v"])
}

fn validate_media_name(name: &str, extensions: &[&str]) -> Result<(), Error> {
    let without_query = name.split(['?', '#']).next().unwrap_or(name);
    let extension = Path::new(without_query)
        .extension()
        .and_then(|extension| extension.to_str())
        .map(str::to_ascii_lowercase)
        .ok_or_else(|| Error::syntax("media path requires a supported extension"))?;
    if !extensions.contains(&extension.as_str()) {
        return Err(Error::syntax("unsupported local media format"));
    }
    Ok(())
}
