//! Native graphical system hub for ModernBASIC.
//!
//! The frameless boot window owns filesystem and task-management commands.
//! Every loaded file receives a separate, normally managed X11 window with its
//! own complete BASIC REPL and interpreter thread.
//!
//! The implementation uses a small, isolated Xlib FFI boundary so the core
//! interpreter remains dependency-free.  If X11 is unavailable, callers can
//! report the graphical startup error.

use std::collections::{HashMap, VecDeque};
use std::ffi::CString;
use std::fs::OpenOptions;
use std::io::{self, BufRead, Read, Write};
use std::os::raw::{c_char, c_int, c_long, c_uint, c_ulong, c_void};
use std::sync::{
    atomic::{AtomicBool, Ordering},
    mpsc::{self, Receiver, Sender, TryRecvError},
    Arc, Mutex,
};
use std::thread;
use std::time::{Duration, Instant};

pub use crate::color_prefs::ColorPrefs;
use crate::error::Error;
use crate::help::HelpViewer;
use crate::interpreter::{clear_interrupt, take_interrupt, RunOptions, UNLIMITED_STEPS};
use crate::program::{Program, DEFAULT_MAX_SOURCE_LINE_BYTES};
use crate::repl::ReplFilesystem;
use crate::screen::{
    DisplayInfo, PointerState, ScreenView, SharedDisplayInfo, SharedKeyQueue, SharedPointerState,
};

#[path = "program_window.rs"]
mod program_window;

use program_window::{
    ProgramTaskInfo, ProgramWindowManager, ProgramWindowOpenContext, ProgramWindowPasteAtoms,
};

/// Default window size when the user has not specified one.
const DEFAULT_WIDTH: u32 = 1100;
const DEFAULT_HEIGHT: u32 = 760;
const FONT_WIDTH: i32 = 9;
const FONT_HEIGHT: i32 = 15;
const FONT_ASCENT: i32 = 12;
const MARGIN_X: i32 = 12;
const MARGIN_Y: i32 = 10;
const STATUS_HEIGHT: i32 = 24;
const MAX_SCROLLBACK_LINES: usize = 5000;
const MAX_HISTORY_LINES: usize = 500;
const CURSOR_BLINK: Duration = Duration::from_millis(520);
const HARDWARE_REFRESH_INTERVAL: Duration = Duration::from_secs(3);
const DOUBLE_CLICK_INTERVAL: Time = 400;
const MAX_PASTE_BYTES: usize = 8 * 1024 * 1024;
const MAX_RUNTIME_KEYS: usize = 64;
const MAX_SHELL_EVENTS_PER_CYCLE: usize = 128;
const SPRITE_EDITOR_SOURCE: &str = include_str!("../programs/graphics/sprite_editor.bas");
const FONT_EDITOR_SOURCE: &str = include_str!("../programs/graphics/font_editor.bas");

const KEY_PRESS: c_int = 2;
const KEY_RELEASE: c_int = 3;
const BUTTON_PRESS: c_int = 4;
const BUTTON_RELEASE: c_int = 5;
const MOTION_NOTIFY: c_int = 6;
const LEAVE_NOTIFY: c_int = 8;
const FOCUS_IN: c_int = 9;
const FOCUS_OUT: c_int = 10;
const EXPOSE: c_int = 12;
const SELECTION_CLEAR: c_int = 29;
const SELECTION_REQUEST: c_int = 30;
const SELECTION_NOTIFY: c_int = 31;
const CONFIGURE_NOTIFY: c_int = 22;
const CLIENT_MESSAGE: c_int = 33;

pub(crate) const KEY_PRESS_MASK: c_long = 1 << 0;
pub(crate) const KEY_RELEASE_MASK: c_long = 1 << 1;
pub(crate) const BUTTON_PRESS_MASK: c_long = 1 << 2;
pub(crate) const BUTTON_RELEASE_MASK: c_long = 1 << 3;
pub(crate) const LEAVE_WINDOW_MASK: c_long = 1 << 5;
pub(crate) const POINTER_MOTION_MASK: c_long = 1 << 6;
pub(crate) const EXPOSURE_MASK: c_long = 1 << 15;
pub(crate) const STRUCTURE_NOTIFY_MASK: c_long = 1 << 17;
const SUBSTRUCTURE_NOTIFY_MASK: c_long = 1 << 19;
const SUBSTRUCTURE_REDIRECT_MASK: c_long = 1 << 20;
pub(crate) const FOCUS_CHANGE_MASK: c_long = 1 << 21;

const SHIFT_MASK: c_uint = 1 << 0;
const LOCK_MASK: c_uint = 1 << 1;
const CONTROL_MASK: c_uint = 1 << 2;

const XK_BACKSPACE: c_ulong = 0xFF08;
const XK_RETURN: c_ulong = 0xFF0D;
const XK_ESCAPE: c_ulong = 0xFF1B;
const XK_HOME: c_ulong = 0xFF50;
const XK_LEFT: c_ulong = 0xFF51;
const XK_UP: c_ulong = 0xFF52;
const XK_RIGHT: c_ulong = 0xFF53;
const XK_DOWN: c_ulong = 0xFF54;
const XK_PAGE_UP: c_ulong = 0xFF55;
const XK_PAGE_DOWN: c_ulong = 0xFF56;
const XK_END: c_ulong = 0xFF57;
const XK_DELETE: c_ulong = 0xFFFF;
const XK_F1: c_ulong = 0xFFBE;
const XK_F2: c_ulong = 0xFFBF;
const XK_F3: c_ulong = 0xFFC0;
const XK_F5: c_ulong = 0xFFC2;
const XK_F11: c_ulong = 0xFFC8;
const XK_INSERT: c_ulong = 0xFF63;

const ZPIXMAP: c_int = 2;
const LSB_FIRST: c_int = 0;
const SCENE_RENDER_DEBOUNCE: Duration = Duration::from_millis(12);
const MAX_RASTER_PIXELS: usize = 16_777_216;
const CW_OVERRIDE_REDIRECT: c_ulong = 1 << 9;
const PROP_MODE_REPLACE: c_int = 0;
const INPUT_HINT: c_long = 1 << 0;
const STATE_HINT: c_long = 1 << 1;
const NORMAL_STATE: c_int = 1;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum EditorKind {
    Sprite,
    Font,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum SystemCommand {
    Help,
    Load {
        path: std::path::PathBuf,
        visible_path: String,
    },
    Editor(EditorKind),
    New {
        path: std::path::PathBuf,
        visible_path: String,
    },
    Tasks,
    Stop(String),
    Close(String),
    Focus(String),
    ScreenColor(String),
    TextColor(String),
    Restart,
    Shutdown,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PowerAction {
    Restart,
    Shutdown,
}

impl PowerAction {
    fn command(self) -> SystemCommand {
        match self {
            Self::Restart => SystemCommand::Restart,
            Self::Shutdown => SystemCommand::Shutdown,
        }
    }
}

/// Host-window policy for presenting the logical BASIC screen device.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GraphicsScaleMode {
    /// Preserve logical aspect ratio and center the result with black bars.
    Fit,
    /// Fill the host graphics region even when that changes the aspect ratio.
    Stretch,
}

/// Options for the graphical programming shell.
#[derive(Debug, Clone)]
pub struct ShellOptions {
    pub run_options: RunOptions,
    pub width: u32,
    pub height: u32,
    pub fullscreen: bool,
    pub graphics_scale: GraphicsScaleMode,
    pub uppercase_input: bool,
    pub initial_program: Option<String>,
    /// Pre-tokenized program supplied by a native-packaged graphical binary.
    /// The shell opens it in a program window and runs it immediately.
    pub initial_program_image: Option<Program>,
    pub screen_color: String,
    pub text_color: String,
}

impl ShellOptions {
    pub fn new(mut run_options: RunOptions) -> Self {
        // A classic interactive BASIC program is allowed to loop until the
        // operator presses Ctrl+Esc. Batch and library runs retain their
        // configured safety budget; only the native shell disables the cutoff.
        run_options.max_steps = UNLIMITED_STEPS;
        let colors = ColorPrefs::default();
        Self {
            run_options,
            width: DEFAULT_WIDTH,
            height: DEFAULT_HEIGHT,
            fullscreen: false,
            graphics_scale: GraphicsScaleMode::Fit,
            uppercase_input: true,
            initial_program: None,
            initial_program_image: None,
            screen_color: colors.screen_color,
            text_color: colors.text_color,
        }
    }
}

/// Start the native graphical BASIC shell.
///
/// An error is returned when X11 cannot be opened or initialized.  The default launcher reports that error directly.
pub fn run_shell(mut options: ShellOptions) -> Result<(), Error> {
    loop {
        let (action, colors) = run_shell_once(options.clone())?;
        options.screen_color = colors.screen_color;
        options.text_color = colors.text_color;
        match action {
            PowerAction::Restart => continue,
            PowerAction::Shutdown => return Ok(()),
        }
    }
}

fn run_shell_once(options: ShellOptions) -> Result<(PowerAction, ColorPrefs), Error> {
    clear_interrupt();
    let (input_tx, input_rx) = mpsc::channel::<Vec<u8>>();
    let (output_tx, output_rx) = mpsc::channel::<ReplEvent>();
    let pointer_state = Arc::new(Mutex::new(PointerState::default()));
    let key_queue = Arc::new(Mutex::new(VecDeque::new()));
    let display_info = Arc::new(Mutex::new(DisplayInfo::default()));
    let command_interrupt = Arc::new(AtomicBool::new(false));

    let file_root = options.run_options.file_root.clone();
    let color_prefs = ColorPrefs {
        screen_color: options.screen_color.clone(),
        text_color: options.text_color.clone(),
    };
    let worker = thread::Builder::new()
        .name("modernbasic-system-hub".into())
        .spawn(move || {
            let mut input = ChannelReader::new(input_rx);
            let prompt_tx = output_tx.clone();
            let command_tx = output_tx.clone();
            let mut output = ChannelWriter::new(output_tx);
            run_system_hub(
                &mut input,
                &mut output,
                file_root.as_deref(),
                color_prefs,
                move || {
                    let _ = prompt_tx.send(ReplEvent::Ready);
                },
                move |command| command_tx.send(ReplEvent::HostCommand(command)).is_ok(),
            )
        })
        .map_err(|error| Error::Io(format!("cannot start system command hub: {error}")))?;

    let context = X11ShellOpenContext {
        input_tx,
        output_rx,
        pointer_state,
        key_queue,
        display_info: Arc::clone(&display_info),
        command_interrupt: Arc::clone(&command_interrupt),
    };
    let mut shell = match X11Shell::open(options, context) {
        Ok(shell) => shell,
        Err(error) => {
            clear_interrupt();
            let _ = worker.join();
            return Err(error);
        }
    };

    // Share the physical display dimensions with the interpreter worker thread
    // so `SCREEN MAX` can resolve to the user's actual hardware.
    if let Ok(mut info) = display_info.lock() {
        info.width = shell.screen_width();
        info.height = shell.screen_height();
    }

    let result = shell.event_loop();
    let exit_action = shell.exit_action;
    let color_prefs = shell.color_prefs.clone();

    command_interrupt.store(true, Ordering::SeqCst);
    let _ = shell.send_line("QUIT");
    drop(shell);
    let _ = worker.join();
    clear_interrupt();
    result?;
    Ok((exit_action, color_prefs))
}

struct ChannelReader {
    receiver: Receiver<Vec<u8>>,
    buffer: Vec<u8>,
    position: usize,
    closed: bool,
}

impl ChannelReader {
    fn new(receiver: Receiver<Vec<u8>>) -> Self {
        Self {
            receiver,
            buffer: Vec::new(),
            position: 0,
            closed: false,
        }
    }

    fn refill(&mut self) -> io::Result<()> {
        if take_interrupt() {
            self.buffer.clear();
            self.position = 0;
            return Err(run_stop_io_error());
        }

        while self.position >= self.buffer.len() && !self.closed {
            match self.receiver.recv() {
                Ok(bytes) => {
                    if take_interrupt() {
                        self.buffer.clear();
                        self.position = 0;
                        return Err(run_stop_io_error());
                    }
                    self.buffer = bytes;
                    self.position = 0;
                    if !self.buffer.is_empty() {
                        break;
                    }
                }
                Err(_) => self.closed = true,
            }
        }
        Ok(())
    }
}

fn run_stop_io_error() -> io::Error {
    io::Error::new(io::ErrorKind::Interrupted, "ModernBASIC RUN/STOP")
}

impl Read for ChannelReader {
    fn read(&mut self, destination: &mut [u8]) -> io::Result<usize> {
        self.refill()?;
        let available = &self.buffer[self.position..];
        let length = available.len().min(destination.len());
        destination[..length].copy_from_slice(&available[..length]);
        self.position += length;
        Ok(length)
    }
}

impl BufRead for ChannelReader {
    fn fill_buf(&mut self) -> io::Result<&[u8]> {
        self.refill()?;
        Ok(&self.buffer[self.position..])
    }

    fn consume(&mut self, amount: usize) {
        self.position = (self.position + amount).min(self.buffer.len());
    }
}

enum ReplEvent {
    Output(Vec<u8>),
    Ready,
    HostCommand(SystemCommand),
}

struct ChannelWriter {
    sender: Sender<ReplEvent>,
}

impl ChannelWriter {
    fn new(sender: Sender<ReplEvent>) -> Self {
        Self { sender }
    }
}

impl Write for ChannelWriter {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.sender
            .send(ReplEvent::Output(bytes.to_vec()))
            .map_err(|_| io::Error::new(io::ErrorKind::BrokenPipe, "graphical shell closed"))?;
        Ok(bytes.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

fn run_system_hub<R: BufRead + ?Sized, W: Write, F: FnMut(), H: FnMut(SystemCommand) -> bool>(
    input: &mut R,
    output: &mut W,
    file_root: Option<&std::path::Path>,
    mut color_prefs: ColorPrefs,
    mut on_prompt: F,
    mut on_command: H,
) -> Result<(), Error> {
    let mut filesystem = ReplFilesystem::new(file_root)?;
    let mut confirmation: Option<PowerAction> = None;
    on_prompt();

    loop {
        output.flush()?;
        let mut line = String::new();
        if input.read_line(&mut line)? == 0 {
            return Ok(());
        }
        let line = line.trim();

        if let Some(action) = confirmation.take() {
            if line.eq_ignore_ascii_case("Y") || line.eq_ignore_ascii_case("YES") {
                let _ = on_command(action.command());
                return Ok(());
            }
            if line.eq_ignore_ascii_case("N") || line.eq_ignore_ascii_case("NO") {
                writeln!(output, "CANCELLED.")?;
            } else {
                writeln!(output, "PLEASE ANSWER Y OR N.")?;
                confirmation = Some(action);
            }
            on_prompt();
            continue;
        }

        if line.is_empty() {
            on_prompt();
            continue;
        }
        let (command, argument) = split_system_command(line);
        let result = match command.as_str() {
            "HELP" | "MANUAL" if argument.is_empty() => {
                if on_command(SystemCommand::Help) {
                    Ok(())
                } else {
                    Err(Error::Io("system command hub closed".into()))
                }
            }
            "EDIT" => {
                let kind = match argument.to_ascii_uppercase().as_str() {
                    "SPRITE" => EditorKind::Sprite,
                    "FONT" => EditorKind::Font,
                    _ => return Err(Error::syntax("usage: EDIT SPRITE or EDIT FONT")),
                };
                if on_command(SystemCommand::Editor(kind)) {
                    Ok(())
                } else {
                    Err(Error::Io("system command hub closed".into()))
                }
            }
            "LOAD" if !argument.is_empty() => filesystem.existing_path(argument).and_then(|path| {
                if !path.is_file() {
                    return Err(Error::InvalidFilePath);
                }
                let visible_path = filesystem.basic_path(&path)?;
                if on_command(SystemCommand::Load { path, visible_path }) {
                    Ok(())
                } else {
                    Err(Error::Io("system command hub closed".into()))
                }
            }),
            "NEW" if !argument.is_empty() => filesystem.output_path(argument).and_then(|path| {
                OpenOptions::new().write(true).create_new(true).open(&path)?;
                let visible_path = filesystem.basic_path(&path)?;
                if on_command(SystemCommand::New { path, visible_path }) {
                    Ok(())
                } else {
                    Err(Error::Io("system command hub closed".into()))
                }
            }),
            "DELETE" if !argument.is_empty() => filesystem.kill(argument).and_then(|()| {
                writeln!(output, "FILE DELETED.")?;
                Ok(())
            }),
            "STOP" if !argument.is_empty() => {
                if on_command(SystemCommand::Stop(argument.to_string())) {
                    Ok(())
                } else {
                    Err(Error::Io("system command hub closed".into()))
                }
            }
            "CLOSE" if !argument.is_empty() => {
                if on_command(SystemCommand::Close(argument.to_string())) {
                    Ok(())
                } else {
                    Err(Error::Io("system command hub closed".into()))
                }
            }
            "FOCUS" if !argument.is_empty() => {
                if on_command(SystemCommand::Focus(argument.to_string())) {
                    Ok(())
                } else {
                    Err(Error::Io("system command hub closed".into()))
                }
            }
            "TASKS" if argument.is_empty() => {
                if on_command(SystemCommand::Tasks) {
                    Ok(())
                } else {
                    Err(Error::Io("system command hub closed".into()))
                }
            }
            "DIR" => filesystem.list(argument, output),
            "CD" => filesystem.change_dir(argument).and_then(|()| filesystem.display_cwd(output)),
            "SCREEN" => {
                let arg = argument.trim();
                let (key, value) = split_system_command(arg);
                let value = value.trim_start_matches('=').trim();
                if key.eq_ignore_ascii_case("COLOR") && !value.is_empty() {
                    let hex = ColorPrefs::normalize_hex(value)?;
                    if !on_command(SystemCommand::ScreenColor(hex.clone())) {
                        return Err(Error::Io("system command hub closed".into()));
                    }
                    color_prefs.screen_color = hex;
                    writeln!(output, "SCREEN COLOR {}.", color_prefs.screen_color)?;
                    Ok(())
                } else {
                    Err(Error::syntax("usage: SCREEN COLOR = #rrggbb"))
                }
            }
            "TEXT" => {
                let arg = argument.trim();
                let (key, value) = split_system_command(arg);
                let value = value.trim_start_matches('=').trim();
                if key.eq_ignore_ascii_case("COLOR") && !value.is_empty() {
                    let hex = ColorPrefs::normalize_hex(value)?;
                    if !on_command(SystemCommand::TextColor(hex.clone())) {
                        return Err(Error::Io("system command hub closed".into()));
                    }
                    color_prefs.text_color = hex;
                    writeln!(output, "TEXT COLOR {}.", color_prefs.text_color)?;
                    Ok(())
                } else {
                    Err(Error::syntax("usage: TEXT COLOR = #rrggbb"))
                }
            }
            "RESTART" if argument.is_empty() => {
                confirmation = Some(PowerAction::Restart);
                writeln!(output, "ARE YOU SURE? Y/N")?;
                Ok(())
            }
            "SHUTDOWN" if argument.is_empty() => {
                confirmation = Some(PowerAction::Shutdown);
                writeln!(output, "ARE YOU SURE? Y/N")?;
                Ok(())
            }
            _ => Err(Error::syntax(format!(
                "unknown system command: {command}; use HELP, EDIT SPRITE, EDIT FONT, LOAD, NEW, DELETE, STOP, CLOSE, FOCUS, TASKS, DIR, CD, SCREEN COLOR, TEXT COLOR, RESTART, or SHUTDOWN"
            ))),
        };
        if let Err(error) = result {
            program_window::log_diagnostic_error(None, &error.to_string());
            writeln!(output, "? {error}")?;
        }
        on_prompt();
    }
}

fn split_system_command(line: &str) -> (String, &str) {
    let split = line
        .char_indices()
        .find_map(|(index, character)| character.is_whitespace().then_some(index));
    match split {
        Some(index) => (line[..index].to_ascii_uppercase(), line[index..].trim()),
        None => (line.to_ascii_uppercase(), ""),
    }
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
struct TerminalTextColors {
    foreground: c_ulong,
    background: c_ulong,
}

impl From<X11Colors> for TerminalTextColors {
    fn from(colors: X11Colors) -> Self {
        Self {
            foreground: colors.text,
            background: colors.screen,
        }
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
struct TerminalRow {
    text: String,
    colors: Vec<TerminalTextColors>,
}

impl TerminalRow {
    fn clear(&mut self) {
        self.text.clear();
        self.colors.clear();
    }
}

struct TerminalBuffer {
    lines: VecDeque<String>,
    line_colors: VecDeque<Vec<TerminalTextColors>>,
    current: String,
    current_colors: Vec<TerminalTextColors>,
    text_colors: TerminalTextColors,
    cursor_line: usize,
    cursor_column: usize,
    cursor_visible: bool,
    print_top: usize,
    print_bottom: usize,
}

impl Default for TerminalBuffer {
    fn default() -> Self {
        Self::with_colors(X11Colors::default())
    }
}

impl TerminalBuffer {
    fn with_colors(colors: X11Colors) -> Self {
        Self {
            lines: VecDeque::new(),
            line_colors: VecDeque::new(),
            current: String::new(),
            current_colors: Vec::new(),
            text_colors: colors.into(),
            cursor_line: 0,
            cursor_column: 0,
            cursor_visible: true,
            print_top: 1,
            print_bottom: 25,
        }
    }

    fn set_text_colors(&mut self, colors: X11Colors) {
        self.text_colors = colors.into();
    }

    fn push_bytes(&mut self, bytes: &[u8]) {
        let text = String::from_utf8_lossy(bytes);
        for character in text.chars() {
            match character {
                '\n' => self.finish_line(),
                '\r' => self.cursor_column = 0,
                '\u{8}' => self.erase_previous_character(),
                character if !character.is_control() || character == '\t' => {
                    if character == '\t' {
                        let spaces = 8 - (self.cursor_column % 8);
                        for _ in 0..spaces {
                            self.put_character(' ');
                        }
                    } else {
                        self.put_character(character);
                    }
                }
                _ => {}
            }
        }
    }

    fn append_entered_line(&mut self, line: &str) {
        for character in line.chars() {
            self.put_character(character);
        }
        self.finish_line();
    }

    fn finish_line(&mut self) {
        self.advance_line();
        self.cursor_column = 0;
    }

    fn put_character(&mut self, character: char) {
        if self.cursor_column >= 80 {
            self.finish_line();
        }
        self.ensure_line(self.cursor_line);
        let column = self.cursor_column;
        let colors = self.text_colors;
        let (line, line_colors) = self.row_mut(self.cursor_line);
        let mut characters = line.chars().collect::<Vec<_>>();
        while characters.len() < column {
            characters.push(' ');
            line_colors.push(colors);
        }
        if column == characters.len() {
            characters.push(character);
            line_colors.push(colors);
        } else {
            characters[column] = character;
            line_colors[column] = colors;
        }
        *line = characters.into_iter().collect();
        self.cursor_column = self.cursor_column.saturating_add(1);
    }

    fn erase_previous_character(&mut self) {
        if self.cursor_column == 0 {
            return;
        }
        self.cursor_column -= 1;
        self.ensure_line(self.cursor_line);
        let column = self.cursor_column;
        let (line, line_colors) = self.row_mut(self.cursor_line);
        let mut characters = line.chars().collect::<Vec<_>>();
        if column < characters.len() {
            characters.remove(column);
            line_colors.remove(column);
            *line = characters.into_iter().collect();
        }
    }

    fn advance_line(&mut self) {
        if self.print_top == 1 && self.print_bottom == 25 && self.cursor_line == self.lines.len() {
            self.lines.push_back(std::mem::take(&mut self.current));
            self.line_colors
                .push_back(std::mem::take(&mut self.current_colors));
            while self.lines.len() > MAX_SCROLLBACK_LINES {
                self.lines.pop_front();
                self.line_colors.pop_front();
            }
            self.cursor_line = self.lines.len();
            return;
        }

        let mut rows = self.take_rows();
        let origin = rows.len().saturating_sub(25);
        let screen_row = self
            .cursor_line
            .saturating_sub(origin)
            .saturating_add(1)
            .clamp(1, 25);
        if screen_row >= self.print_top && screen_row == self.print_bottom {
            if self.print_top == 1 && self.print_bottom == 25 {
                rows.push(TerminalRow::default());
                self.cursor_line = rows.len() - 1;
            } else {
                let top = origin + self.print_top - 1;
                let bottom = origin + self.print_bottom - 1;
                rows.remove(top);
                rows.insert(bottom, TerminalRow::default());
                self.cursor_line = bottom;
            }
        } else {
            self.cursor_line = self.cursor_line.saturating_add(1).min(rows.len());
            if self.cursor_line == rows.len() {
                rows.push(TerminalRow::default());
            }
        }
        self.restore_rows(rows);
    }

    fn set_cursor(&mut self, row: usize, column: usize, visible: bool) {
        let row = row.clamp(1, 25);
        let origin = self.row_count().saturating_sub(25);
        let target = origin + row - 1;
        self.ensure_line(target);
        self.cursor_line = target;
        self.cursor_column = column.clamp(1, 80) - 1;
        self.cursor_visible = visible;
    }

    fn set_print_region(&mut self, top: usize, bottom: usize) {
        self.print_top = top.clamp(1, 25);
        self.print_bottom = bottom.clamp(self.print_top, 25);
    }

    fn clear_print_region(&mut self) {
        if self.print_top == 1 && self.print_bottom == 25 {
            self.clear();
            return;
        }
        let mut rows = self.take_rows();
        while rows.len() < self.print_bottom {
            rows.push(TerminalRow::default());
        }
        let origin = rows.len().saturating_sub(25);
        for row in self.print_top..=self.print_bottom {
            rows[origin + row - 1].clear();
        }
        self.cursor_line = origin + self.print_top - 1;
        self.cursor_column = 0;
        self.restore_rows(rows);
    }

    fn row_count(&self) -> usize {
        self.lines.len() + 1
    }

    fn ensure_line(&mut self, index: usize) {
        while self.lines.len() < index {
            self.lines.push_back(std::mem::take(&mut self.current));
            self.line_colors
                .push_back(std::mem::take(&mut self.current_colors));
        }
    }

    fn row_mut(&mut self, index: usize) -> (&mut String, &mut Vec<TerminalTextColors>) {
        if index < self.lines.len() {
            (
                self.lines
                    .get_mut(index)
                    .expect("terminal row index was checked"),
                self.line_colors
                    .get_mut(index)
                    .expect("terminal color row index was checked"),
            )
        } else {
            (&mut self.current, &mut self.current_colors)
        }
    }

    fn take_rows(&mut self) -> Vec<TerminalRow> {
        let mut rows = self
            .lines
            .drain(..)
            .zip(self.line_colors.drain(..))
            .map(|(text, colors)| TerminalRow { text, colors })
            .collect::<Vec<_>>();
        rows.push(TerminalRow {
            text: std::mem::take(&mut self.current),
            colors: std::mem::take(&mut self.current_colors),
        });
        rows
    }

    fn restore_rows(&mut self, mut rows: Vec<TerminalRow>) {
        let excess = rows.len().saturating_sub(MAX_SCROLLBACK_LINES + 1);
        if excess > 0 {
            rows.drain(..excess);
            self.cursor_line = self.cursor_line.saturating_sub(excess);
        }
        let current = rows.pop().unwrap_or_default();
        self.current = current.text;
        self.current_colors = current.colors;
        (self.lines, self.line_colors) = rows.into_iter().map(|row| (row.text, row.colors)).unzip();
        self.cursor_line = self.cursor_line.min(self.lines.len());
    }

    fn rows_with_input(&self, input: &str) -> Vec<TerminalRow> {
        let mut rows = self
            .lines
            .iter()
            .cloned()
            .zip(self.line_colors.iter().cloned())
            .map(|(text, colors)| TerminalRow { text, colors })
            .collect::<Vec<_>>();
        rows.push(TerminalRow {
            text: self.current.clone(),
            colors: self.current_colors.clone(),
        });
        let active_row = self.cursor_line.min(rows.len() - 1);
        let row = &mut rows[active_row];
        let mut characters = row.text.chars().collect::<Vec<_>>();
        while characters.len() < self.cursor_column {
            characters.push(' ');
            row.colors.push(self.text_colors);
        }
        let input_length = input.chars().count();
        characters.splice(self.cursor_column..self.cursor_column, input.chars());
        row.colors.splice(
            self.cursor_column..self.cursor_column,
            std::iter::repeat(self.text_colors).take(input_length),
        );
        row.text = characters.into_iter().collect();
        rows
    }

    fn clear(&mut self) {
        self.lines.clear();
        self.line_colors.clear();
        self.current.clear();
        self.current_colors.clear();
        self.cursor_line = 0;
        self.cursor_column = 0;
    }

    #[cfg(test)]
    fn line_at(&self, index: usize) -> Option<&str> {
        if index < self.lines.len() {
            self.lines.get(index).map(String::as_str)
        } else if index == self.lines.len() {
            Some(&self.current)
        } else {
            None
        }
    }

    #[cfg(test)]
    fn colors_at(&self, row: usize, column: usize) -> Option<TerminalTextColors> {
        if row < self.line_colors.len() {
            self.line_colors.get(row)?.get(column).copied()
        } else if row == self.line_colors.len() {
            self.current_colors.get(column).copied()
        } else {
            None
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RasterImage {
    width: u32,
    height: u32,
    rgb: Vec<u8>,
}

impl RasterImage {
    fn parse_ppm(bytes: &[u8]) -> Result<Self, Error> {
        let mut cursor = 0usize;
        let magic = ppm_token(bytes, &mut cursor)?;
        if magic != b"P6" {
            return Err(Error::Io(
                "Artist screen raster is not binary PPM (P6)".into(),
            ));
        }
        let width = parse_ppm_u32(ppm_token(bytes, &mut cursor)?, "width")?;
        let height = parse_ppm_u32(ppm_token(bytes, &mut cursor)?, "height")?;
        let max = parse_ppm_u32(ppm_token(bytes, &mut cursor)?, "maximum value")?;
        if width == 0 || height == 0 || max != 255 {
            return Err(Error::Io(
                "invalid Artist PPM screen dimensions or range".into(),
            ));
        }
        let pixels = usize::try_from(width)
            .ok()
            .and_then(|width| {
                usize::try_from(height)
                    .ok()
                    .and_then(|height| width.checked_mul(height))
            })
            .ok_or_else(|| Error::Io("Artist PPM screen dimensions overflow".into()))?;
        if pixels > MAX_RASTER_PIXELS {
            return Err(Error::Io(
                "Artist PPM screen exceeds the integrated-screen limit".into(),
            ));
        }
        if cursor >= bytes.len() || !bytes[cursor].is_ascii_whitespace() {
            return Err(Error::Io(
                "Artist PPM screen is missing its raster separator".into(),
            ));
        }
        if bytes[cursor] == b'\r' && bytes.get(cursor + 1) == Some(&b'\n') {
            cursor += 2;
        } else {
            cursor += 1;
        }
        let length = pixels
            .checked_mul(3)
            .ok_or_else(|| Error::Io("Artist PPM screen byte size overflow".into()))?;
        let end = cursor
            .checked_add(length)
            .ok_or_else(|| Error::Io("Artist PPM screen byte size overflow".into()))?;
        if end > bytes.len() {
            return Err(Error::Io("Artist PPM screen is truncated".into()));
        }
        Ok(Self {
            width,
            height,
            rgb: bytes[cursor..end].to_vec(),
        })
    }
}

fn ppm_token<'a>(bytes: &'a [u8], cursor: &mut usize) -> Result<&'a [u8], Error> {
    loop {
        while *cursor < bytes.len() && bytes[*cursor].is_ascii_whitespace() {
            *cursor += 1;
        }
        if *cursor < bytes.len() && bytes[*cursor] == b'#' {
            while *cursor < bytes.len() && bytes[*cursor] != b'\n' {
                *cursor += 1;
            }
            continue;
        }
        break;
    }
    let start = *cursor;
    while *cursor < bytes.len() && !bytes[*cursor].is_ascii_whitespace() && bytes[*cursor] != b'#' {
        *cursor += 1;
    }
    if start == *cursor {
        return Err(Error::Io("invalid Artist PPM screen header".into()));
    }
    Ok(&bytes[start..*cursor])
}

fn parse_ppm_u32(token: &[u8], name: &str) -> Result<u32, Error> {
    std::str::from_utf8(token)
        .ok()
        .and_then(|text| text.parse::<u32>().ok())
        .ok_or_else(|| Error::Io(format!("invalid Artist PPM screen {name}")))
}

const INTEGRATED_TEXT_RASTER_MARKER: &str = "// modernbasic integrated text raster compatibility";

/// Artist 0.64's tiled raster path clips text at 256-pixel tile boundaries.
///
/// The native shell must use Artist as its renderer, but it also must present
/// complete text.  A fully transparent clipped shape makes Artist select its
/// non-tiled raster path without changing any visible pixels.  This source is
/// used only for the temporary in-window PPM frame; saved SVG, PNG,
/// HTML, and JSON outputs retain the exact user scene.
fn prepare_integrated_raster_source(source: &str) -> String {
    let has_text = source.lines().any(|line| {
        let line = line.trim_start();
        !line.starts_with("//") && (line == "text" || line.starts_with("text "))
    });
    if !has_text || source.contains(INTEGRATED_TEXT_RASTER_MARKER) {
        return source.to_string();
    }

    let mut prepared = String::with_capacity(source.len().saturating_add(256));
    prepared.push_str(source);
    if !prepared.ends_with('\n') {
        prepared.push('\n');
    }
    prepared.push_str(INTEGRATED_TEXT_RASTER_MARKER);
    prepared.push('\n');
    prepared.push_str("id __modernbasic_internal_raster_clip\n");
    prepared.push_str("rectangle 0 0 1 1 fill=none stroke=none\n");
    prepared.push_str("id __modernbasic_internal_raster_guard\n");
    prepared.push_str(
        "rectangle 0 0 1 1 fill=none stroke=none clip=__modernbasic_internal_raster_clip\n",
    );
    prepared
}

fn is_escape_interrupt(keysym: KeySym, state: c_uint) -> bool {
    keysym == XK_ESCAPE && state & CONTROL_MASK != 0
}

fn break_target_task(
    tasks: &[program_window::ProgramTaskInfo],
    selected_task: Option<u64>,
) -> Option<u64> {
    tasks
        .iter()
        .find(|task| {
            Some(task.task_id) == selected_task
                && task.status == program_window::ProgramTaskStatus::Running
        })
        .or_else(|| {
            tasks
                .iter()
                .find(|task| task.status == program_window::ProgramTaskStatus::Running)
        })
        .map(|task| task.task_id)
}

fn shell_control_function_shortcut(keysym: KeySym, state: c_uint) -> bool {
    state & CONTROL_MASK != 0 && matches!(keysym, XK_F1 | XK_F2)
}

fn lookup_event_keysym(mut event: XKeyEvent) -> KeySym {
    let mut keysym = 0;
    let mut buffer = [0 as c_char; 1];
    unsafe {
        XLookupString(
            &mut event,
            buffer.as_mut_ptr(),
            buffer.len() as c_int,
            &mut keysym,
            std::ptr::null_mut(),
        );
    }
    keysym
}

#[cfg(test)]
fn latch_scene_render_start(pending: &mut Option<Instant>, received_at: Instant) {
    pending.get_or_insert(received_at);
}

fn run_stop_has_completed(ready: bool, run_stop_pending: bool) -> bool {
    ready && run_stop_pending
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum VerticalNavigation {
    HistoryPrevious,
    HistoryNext,
    ProgramPrevious,
    ProgramNext,
}

fn vertical_navigation(keysym: KeySym, state: c_uint) -> Option<VerticalNavigation> {
    if state & CONTROL_MASK != 0 {
        return None;
    }
    match (keysym, state & CONTROL_MASK != 0) {
        (XK_UP, false) => Some(VerticalNavigation::HistoryPrevious),
        (XK_DOWN, false) => Some(VerticalNavigation::HistoryNext),
        _ => None,
    }
}

fn control_shortcut_letter(keysym: KeySym) -> Option<u8> {
    let letter = u8::try_from(keysym).ok()?;
    letter
        .is_ascii_alphabetic()
        .then_some(letter.to_ascii_lowercase())
}

fn program_navigation_available(active: bool, line_count: usize, ready: bool) -> bool {
    active && line_count > 0 && ready
}

fn program_navigation_index(
    current: Option<usize>,
    line_count: usize,
    navigation: VerticalNavigation,
) -> Option<usize> {
    if line_count == 0 {
        return None;
    }
    let last = line_count - 1;
    match navigation {
        VerticalNavigation::ProgramPrevious => Some(
            current
                .map(|position| position.min(last).saturating_sub(1))
                .unwrap_or(last),
        ),
        VerticalNavigation::ProgramNext => Some(
            current
                .map(|position| position.saturating_add(1).min(last))
                .unwrap_or(0),
        ),
        VerticalNavigation::HistoryPrevious | VerticalNavigation::HistoryNext => None,
    }
}

fn cursor_is_inside_quotes(input: &str, cursor: usize) -> bool {
    input
        .chars()
        .take(cursor)
        .filter(|character| *character == '"')
        .count()
        % 2
        == 1
}

#[derive(Debug, Clone, Copy)]
struct PendingPaste {
    selection: Atom,
    target_index: usize,
}

type TextPosition = (usize, usize);

fn ordered_selection(start: TextPosition, end: TextPosition) -> (TextPosition, TextPosition) {
    if start <= end {
        (start, end)
    } else {
        (end, start)
    }
}

pub(crate) fn selection_span(
    row: usize,
    line_length: usize,
    start: TextPosition,
    end: TextPosition,
) -> Option<(usize, usize)> {
    if line_length == 0 {
        return None;
    }
    let (start, end) = ordered_selection(start, end);
    if row < start.0 || row > end.0 {
        return None;
    }
    let first = if row == start.0 { start.1 } else { 0 }.min(line_length);
    let last = if row == end.0 {
        end.1.saturating_add(1)
    } else {
        line_length
    }
    .min(line_length);
    (first < last).then_some((first, last))
}

pub(crate) fn selected_text<'a>(
    rows: impl IntoIterator<Item = &'a str>,
    start: TextPosition,
    end: TextPosition,
) -> String {
    let (start, end) = ordered_selection(start, end);
    let mut selected = String::new();
    for (row, text) in rows.into_iter().enumerate() {
        if row < start.0 || row > end.0 {
            continue;
        }
        if row > start.0 {
            selected.push('\n');
        }
        let characters = text.chars().collect::<Vec<_>>();
        let first = if row == start.0 { start.1 } else { 0 }.min(characters.len());
        let last = if row == end.0 {
            end.1.saturating_add(1)
        } else {
            characters.len()
        }
        .min(characters.len());
        if first < last {
            selected.extend(&characters[first..last]);
        }
    }
    selected
}

pub(crate) fn serve_text_selection(
    display: *mut Display,
    text: &str,
    text_targets: [Atom; 4],
    targets_atom: Atom,
    atom_atom: Atom,
    request: XSelectionRequestEvent,
) {
    let property = if request.property == 0 {
        request.target
    } else {
        request.property
    };
    let mut response_property = 0;
    if request.target == targets_atom {
        let supported = [
            targets_atom,
            text_targets[0],
            text_targets[1],
            text_targets[2],
            text_targets[3],
        ];
        unsafe {
            XChangeProperty(
                display,
                request.requestor,
                property,
                atom_atom,
                32,
                PROP_MODE_REPLACE,
                supported.as_ptr().cast::<u8>(),
                supported.len() as c_int,
            );
        }
        response_property = property;
    } else if text_targets.contains(&request.target) {
        let bytes = if request.target == text_targets[3] {
            text.chars()
                .map(|character| {
                    let value = character as u32;
                    if value <= u8::MAX as u32 {
                        value as u8
                    } else {
                        b'?'
                    }
                })
                .collect::<Vec<_>>()
        } else {
            text.as_bytes().to_vec()
        };
        unsafe {
            XChangeProperty(
                display,
                request.requestor,
                property,
                request.target,
                8,
                PROP_MODE_REPLACE,
                bytes.as_ptr(),
                bytes.len() as c_int,
            );
        }
        response_property = property;
    }

    let response = XSelectionEvent {
        type_: SELECTION_NOTIFY,
        serial: 0,
        send_event: 1,
        display,
        requestor: request.requestor,
        selection: request.selection,
        target: request.target,
        property: response_property,
        time: request.time,
    };
    let mut event = XEvent {
        xselection: response,
    };
    unsafe {
        XSendEvent(display, request.requestor, 0, 0, &mut event);
        XFlush(display);
    }
}

#[derive(Debug, PartialEq, Eq)]
enum PastePlan {
    Insert(String),
    Submit(Vec<String>),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ActivePanel {
    Terminal,
    ProgramManager,
}

fn left_panel_width(width: u32) -> u32 {
    (width.saturating_mul(65) / 100)
        .max(1)
        .min(width.saturating_sub(1).max(1))
}

fn program_panel_top(height: u32, hardware_line_count: usize) -> u32 {
    let hardware_content_height = MARGIN_Y * 2 + hardware_line_count as i32 * FONT_HEIGHT;
    let hardware_height_with_gap = (hardware_content_height + FONT_HEIGHT).max(0) as u32;
    let minimum_program_height = (MARGIN_Y * 2 + 4 * FONT_HEIGHT).max(0) as u32;
    hardware_height_with_gap.min(height.saturating_sub(minimum_program_height))
}

fn program_panel_visible_rows(height: u32) -> usize {
    let panel_rows = ((height as i32 - MARGIN_Y * 2) / FONT_HEIGHT).max(0) as usize;
    panel_rows.saturating_sub(2)
}

fn normalized_program_panel_selection(
    item_count: usize,
    visible_rows: usize,
    selected: usize,
    scroll: usize,
) -> (usize, usize) {
    if item_count == 0 {
        return (0, 0);
    }

    let selected = selected.min(item_count - 1);
    if visible_rows == 0 {
        return (selected, selected);
    }

    let mut scroll = scroll.min(item_count.saturating_sub(visible_rows));
    if selected < scroll {
        scroll = selected;
    } else if selected >= scroll.saturating_add(visible_rows) {
        scroll = selected + 1 - visible_rows;
    }
    (selected, scroll)
}

struct X11Shell {
    display: *mut Display,
    window: Window,
    gc: GC,
    reverse_gc: GC,
    font: Font,
    root: Window,
    wm_delete: Atom,
    clipboard: Atom,
    primary: Atom,
    utf8_string: Atom,
    text_plain_utf8: Atom,
    text_atom: Atom,
    string_atom: Atom,
    targets_atom: Atom,
    atom_atom: Atom,
    paste_property: Atom,
    pending_paste: Option<PendingPaste>,
    paste_queue: VecDeque<String>,
    selection_start: Option<TextPosition>,
    selection_end: Option<TextPosition>,
    selecting: bool,
    selected_text: String,
    run_stop_pending: bool,
    ready: bool,
    initial_program_command: Option<String>,
    width: u32,
    height: u32,
    screen_width: u32,
    screen_height: u32,
    fullscreen: bool,
    has_focus: bool,
    graphics_scale: GraphicsScaleMode,
    caps_mode: bool,
    terminal: TerminalBuffer,
    help: HelpViewer,
    input: String,
    cursor: usize,
    history: Vec<String>,
    history_position: Option<usize>,
    program_lines: Vec<String>,
    program_line_position: Option<usize>,
    program_navigation_active: bool,
    program_listing_pending: bool,
    pending_program_navigation: Option<VerticalNavigation>,
    scroll_offset: usize,
    active_panel: ActivePanel,
    program_panel_scroll: usize,
    program_panel_selected: usize,
    last_program_panel_click: Option<(u64, Time)>,
    input_sender: Sender<Vec<u8>>,
    output_receiver: Receiver<ReplEvent>,
    pointer_state: SharedPointerState,
    key_queue: SharedKeyQueue,
    command_interrupt: Arc<AtomicBool>,
    display_info: SharedDisplayInfo,
    program_options: RunOptions,
    color_prefs: ColorPrefs,
    color_cache: X11ColorCache,
    program_windows: ProgramWindowManager,
    screen_view: ScreenView,
    raster: Option<RasterImage>,
    dirty: bool,
    cursor_visible: bool,
    cursor_changed: Instant,
    closed: bool,
    exit_action: PowerAction,
    hardware: HardwareInfo,
    last_hardware_refresh: Instant,
    task_snapshot: Vec<ProgramTaskInfo>,
}

struct X11ShellOpenContext {
    input_tx: Sender<Vec<u8>>,
    output_rx: Receiver<ReplEvent>,
    pointer_state: SharedPointerState,
    key_queue: SharedKeyQueue,
    display_info: SharedDisplayInfo,
    command_interrupt: Arc<AtomicBool>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct HardwareInfo {
    display: String,
    cpu: String,
    load: String,
    memory: String,
    audio: String,
    version: String,
}

impl HardwareInfo {
    fn detect(display_width: u32, display_height: u32) -> Self {
        Self {
            display: format!("{display_width}x{display_height}"),
            cpu: detect_cpu_name(),
            load: detect_cpu_load(),
            memory: detect_memory_usage(),
            audio: detect_audio_system(),
            version: env!("CARGO_PKG_VERSION").to_string(),
        }
    }

    fn refresh(&mut self) {
        self.load = detect_cpu_load();
        self.memory = detect_memory_usage();
    }

    fn lines(&self) -> [String; 7] {
        [
            "HARDWARE".to_string(),
            format!("Display: {}", self.display),
            format!("CPU: {}", self.cpu),
            format!("Load: {} (1m)", self.load),
            format!("Memory: {}", self.memory),
            format!("Audio: {}", self.audio),
            format!("BASIC: {}", self.version),
        ]
    }
}

impl X11Shell {
    fn open(options: ShellOptions, context: X11ShellOpenContext) -> Result<Self, Error> {
        let X11ShellOpenContext {
            input_tx: input_sender,
            output_rx: output_receiver,
            pointer_state,
            key_queue,
            display_info,
            command_interrupt,
        } = context;
        let initial_program = options.initial_program.clone();
        let initial_program_image = options.initial_program_image.clone();
        let program_options = options.run_options.clone();
        let color_prefs = ColorPrefs {
            screen_color: ColorPrefs::normalize_hex(&options.screen_color)?,
            text_color: ColorPrefs::normalize_hex(&options.text_color)?,
        };
        let display = unsafe { XOpenDisplay(std::ptr::null()) };
        if display.is_null() {
            return Err(Error::Io(
                "cannot open X11 display; the graphical READY environment requires X11".into(),
            ));
        }

        let screen_number = unsafe { XDefaultScreen(display) };
        let root = unsafe { XRootWindow(display, screen_number) };
        let mut color_cache = X11ColorCache::new(display, screen_number);
        let colors = match color_cache.colors_for_prefs(display, &color_prefs) {
            Ok(colors) => colors,
            Err(error) => {
                unsafe {
                    XCloseDisplay(display);
                }
                return Err(error);
            }
        };
        let screen_width = unsafe { XDisplayWidth(display, screen_number) }.max(1) as u32;
        let screen_height = unsafe { XDisplayHeight(display, screen_number) }.max(1) as u32;
        let color_depth = unsafe { XDefaultDepth(display, screen_number) }.max(1) as u32;
        if let Ok(mut info) = display_info.lock() {
            info.width = screen_width;
            info.height = screen_height;
            info.color_depth = color_depth;
            info.scale = 1;
        }
        let fullscreen = options.fullscreen || options.width == 0 || options.height == 0;
        // The system hub covers the physical screen when fullscreen, or sits
        // inside a manageable window when windowed.
        let width = if fullscreen {
            screen_width
        } else {
            options.width.max(640)
        };
        let height = if fullscreen {
            screen_height
        } else {
            options.height.max(400)
        };
        let window = unsafe {
            XCreateSimpleWindow(
                display,
                root,
                0,
                0,
                width,
                height,
                0,
                colors.text,
                colors.screen,
            )
        };
        if window == 0 {
            unsafe {
                XCloseDisplay(display);
            }
            return Err(Error::Io("cannot create ModernBASIC X11 window".into()));
        }

        let title = CString::new(format!(
            "ModernBASIC {} - System Hub",
            env!("CARGO_PKG_VERSION")
        ))
        .map_err(|_| Error::Io("invalid window title".into()))?;
        let mut attributes = XSetWindowAttributes {
            override_redirect: 0,
            ..Default::default()
        };
        unsafe {
            XStoreName(display, window, title.as_ptr());
            XChangeWindowAttributes(display, window, CW_OVERRIDE_REDIRECT, &mut attributes);
        }

        if fullscreen {
            let net_wm_state = intern_atom(display, "_NET_WM_STATE")?;
            let net_wm_state_fullscreen = intern_atom(display, "_NET_WM_STATE_FULLSCREEN")?;
            let atom_type = intern_atom(display, "ATOM")?;
            unsafe {
                XChangeProperty(
                    display,
                    window,
                    net_wm_state,
                    atom_type,
                    32,
                    PROP_MODE_REPLACE,
                    (&net_wm_state_fullscreen as *const Atom).cast::<u8>(),
                    1,
                );
            }
        }

        let wm_delete = intern_atom(display, "WM_DELETE_WINDOW")?;
        let mut wm_delete_protocol = wm_delete;
        let mut wm_hints = XWMHints {
            flags: INPUT_HINT | STATE_HINT,
            input: 1,
            initial_state: NORMAL_STATE,
            ..XWMHints::default()
        };
        unsafe {
            XSetWMProtocols(display, window, &mut wm_delete_protocol, 1);
            XSetWMHints(display, window, &mut wm_hints);
            XSelectInput(
                display,
                window,
                KEY_PRESS_MASK
                    | KEY_RELEASE_MASK
                    | BUTTON_PRESS_MASK
                    | BUTTON_RELEASE_MASK
                    | POINTER_MOTION_MASK
                    | LEAVE_WINDOW_MASK
                    | EXPOSURE_MASK
                    | STRUCTURE_NOTIFY_MASK
                    | FOCUS_CHANGE_MASK,
            );
        }

        let gc = unsafe { XCreateGC(display, window, 0, std::ptr::null_mut()) };
        let reverse_gc = unsafe { XCreateGC(display, window, 0, std::ptr::null_mut()) };
        if gc.is_null() || reverse_gc.is_null() {
            unsafe {
                if !gc.is_null() {
                    XFreeGC(display, gc);
                }
                if !reverse_gc.is_null() {
                    XFreeGC(display, reverse_gc);
                }
                XDestroyWindow(display, window);
                XCloseDisplay(display);
            }
            return Err(Error::Io("cannot create X11 graphics contexts".into()));
        }

        let font_name = CString::new("9x15").unwrap();
        let mut font = unsafe { XLoadFont(display, font_name.as_ptr()) };
        if font == 0 {
            let fallback = CString::new("fixed").unwrap();
            font = unsafe { XLoadFont(display, fallback.as_ptr()) };
        }

        unsafe {
            XSetForeground(display, gc, colors.text);
            XSetBackground(display, gc, colors.screen);
            XSetForeground(display, reverse_gc, colors.screen);
            XSetBackground(display, reverse_gc, colors.text);
            if font != 0 {
                XSetFont(display, gc, font);
                XSetFont(display, reverse_gc, font);
            }
            XMapWindow(display, window);
            // XSetInputFocus on a not-yet-viewable window causes a fatal
            // BadMatch X error. XRaiseWindow is safe and brings the window
            // to the front; the WM grants focus when it becomes viewable.
            XRaiseWindow(display, window);
            XFlush(display);
        }

        let clipboard = intern_atom(display, "CLIPBOARD")?;
        let primary = intern_atom(display, "PRIMARY")?;
        let utf8_string = intern_atom(display, "UTF8_STRING")?;
        let text_plain_utf8 = intern_atom(display, "text/plain;charset=utf-8")?;
        let text_atom = intern_atom(display, "TEXT")?;
        let string_atom = intern_atom(display, "STRING")?;
        let targets_atom = intern_atom(display, "TARGETS")?;
        let atom_atom = intern_atom(display, "ATOM")?;
        let paste_property = intern_atom(display, "_MODERNBASIC_PASTE")?;
        let program_window_paste_atoms = ProgramWindowPasteAtoms {
            clipboard,
            primary,
            utf8_string,
            text_plain_utf8,
            text_atom,
            string_atom,
            targets_atom,
            atom_atom,
            paste_property: intern_atom(display, "_MODERNBASIC_PASTE_WIN")?,
        };

        let mut shell = Self {
            display,
            window,
            gc,
            reverse_gc,
            font,
            root,
            wm_delete,
            clipboard,
            primary,
            utf8_string,
            text_plain_utf8,
            text_atom,
            string_atom,
            targets_atom,
            atom_atom,
            paste_property,
            pending_paste: None,
            paste_queue: VecDeque::new(),
            selection_start: None,
            selection_end: None,
            selecting: false,
            selected_text: String::new(),
            run_stop_pending: false,
            ready: false,
            initial_program_command: None,
            width,
            height,
            screen_width,
            screen_height,
            fullscreen,
            has_focus: false,
            graphics_scale: options.graphics_scale,
            caps_mode: options.uppercase_input,
            terminal: TerminalBuffer::with_colors(colors),
            help: HelpViewer::default(),
            input: String::new(),
            cursor: 0,
            history: Vec::new(),
            history_position: None,
            program_lines: Vec::new(),
            program_line_position: None,
            program_navigation_active: false,
            program_listing_pending: false,
            pending_program_navigation: None,
            scroll_offset: 0,
            active_panel: ActivePanel::Terminal,
            program_panel_scroll: 0,
            program_panel_selected: 0,
            last_program_panel_click: None,
            input_sender,
            output_receiver,
            pointer_state,
            key_queue,
            command_interrupt,
            display_info,
            program_options,
            color_prefs: color_prefs.clone(),
            color_cache,
            program_windows: ProgramWindowManager::new(
                options.graphics_scale,
                color_prefs,
                program_window_paste_atoms,
            ),
            screen_view: ScreenView::Text,
            raster: None,
            dirty: true,
            cursor_visible: true,
            cursor_changed: Instant::now(),
            closed: false,
            exit_action: PowerAction::Shutdown,
            hardware: HardwareInfo::detect(screen_width, screen_height),
            last_hardware_refresh: Instant::now(),
            task_snapshot: Vec::new(),
        };

        if let Some(path) = initial_program {
            let path = std::fs::canonicalize(path)?;
            let path = path.to_str().ok_or(Error::InvalidFilePath)?;
            if path.contains('"') {
                return Err(Error::InvalidFilePath);
            }
            shell.initial_program_command = Some(format!("LOAD \"{path}\""));
        }
        if let Some(program) = initial_program_image {
            let task_id = shell.open_program_window_with_image(program)?;
            shell
                .program_windows
                .focus(shell.display, shell.root, Some(task_id));
        }
        Ok(shell)
    }

    fn event_loop(&mut self) -> Result<(), Error> {
        while !self.closed {
            // X11 owns all user interaction. Give it first priority on every
            // cycle, regardless of how much interpreter output is queued.
            self.drain_events()?;
            self.drain_output();
            self.finish_pending_run_stop();
            self.program_windows
                .service(self.display, &mut self.color_cache);
            let tasks = self.program_windows.list();
            if tasks != self.task_snapshot {
                self.update_task_snapshot(tasks);
            }

            if self.last_hardware_refresh.elapsed() >= HARDWARE_REFRESH_INTERVAL {
                self.hardware.refresh();
                self.last_hardware_refresh = Instant::now();
                self.dirty = true;
            }

            if self.at_ready_prompt() {
                if self.cursor_changed.elapsed() >= CURSOR_BLINK {
                    self.cursor_visible = !self.cursor_visible;
                    self.cursor_changed = Instant::now();
                    self.dirty = true;
                }
            } else if self.cursor_visible {
                self.cursor_visible = false;
                self.dirty = true;
            }

            if self.dirty {
                self.redraw();
            }
            thread::sleep(Duration::from_millis(4));
        }
        Ok(())
    }

    fn drain_output(&mut self) {
        for _ in 0..MAX_SHELL_EVENTS_PER_CYCLE {
            match self.output_receiver.try_recv() {
                Ok(ReplEvent::Output(bytes)) => {
                    self.terminal.push_bytes(&bytes);
                    self.scroll_offset = 0;
                    self.dirty = true;
                }
                Ok(ReplEvent::Ready) => {
                    self.ready = true;
                    self.command_interrupt.store(false, Ordering::SeqCst);
                    clear_interrupt();
                    if let Some(command) = self.initial_program_command.take() {
                        if self.submit_command(&command).is_err() {
                            self.closed = true;
                        }
                        continue;
                    }
                    if self.program_listing_pending {
                        self.refresh_program_lines();
                        self.program_listing_pending = false;
                        if let Some(navigation) = self.pending_program_navigation.take() {
                            self.apply_program_navigation(navigation);
                        }
                    }
                    self.submit_next_paste_line();
                    self.dirty = true;
                }
                Ok(ReplEvent::HostCommand(command)) => self.handle_host_command(command),
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => {
                    self.closed = true;
                    break;
                }
            }
        }
    }

    fn handle_host_command(&mut self, command: SystemCommand) {
        let result = match command {
            SystemCommand::Help => {
                self.show_help();
                return;
            }
            SystemCommand::Editor(kind) => {
                let name = match kind {
                    EditorKind::Sprite => "SPRITE EDITOR",
                    EditorKind::Font => "FONT EDITOR",
                };
                self.open_editor_window(kind)
                    .map(|task_id| format!("TASK {task_id} OPENED: {name}"))
            }
            SystemCommand::Load { path, visible_path } => self
                .open_program_window(Some(path))
                .map(|task_id| format!("TASK {task_id} OPENED: {visible_path}")),
            SystemCommand::New { path, visible_path } => self
                .open_program_window(Some(path))
                .map(|task_id| format!("TASK {task_id} CREATED: {visible_path}")),
            SystemCommand::Tasks => {
                let tasks = self.program_windows.list();
                if tasks.is_empty() {
                    Ok("NO PROGRAM TASKS.".to_string())
                } else {
                    let mut table = String::from("ID   FILENAME                       STATE");
                    for task in tasks {
                        table.push_str(&format!(
                            "\n{:<4} {:<30} {}",
                            task.task_id,
                            task.filename.chars().take(30).collect::<String>(),
                            task.status.name()
                        ));
                    }
                    Ok(table)
                }
            }
            SystemCommand::Stop(argument) => self
                .program_windows
                .stop_selector(&argument)
                .map(|task_id| format!("TASK {task_id} STOP REQUESTED.")),
            SystemCommand::Close(argument) => self
                .program_windows
                .close_selector(self.display, &argument)
                .map(|task_id| format!("TASK {task_id} CLOSED.")),
            SystemCommand::Focus(argument) => self
                .program_windows
                .focus_selector(self.display, self.root, &argument)
                .map(|task_id| format!("TASK {task_id} FOCUSED.")),
            SystemCommand::ScreenColor(color) => {
                let mut prefs = self.color_prefs.clone();
                prefs.screen_color = color;
                self.apply_color_prefs(prefs)
                    .map(|()| format!("SCREEN COLOR {}.", self.color_prefs.screen_color))
            }
            SystemCommand::TextColor(color) => {
                let mut prefs = self.color_prefs.clone();
                prefs.text_color = color;
                self.apply_color_prefs(prefs)
                    .map(|()| format!("TEXT COLOR {}.", self.color_prefs.text_color))
            }
            SystemCommand::Restart => {
                self.shell_notice("RESTARTING.");
                self.exit_action = PowerAction::Restart;
                self.closed = true;
                return;
            }
            SystemCommand::Shutdown => {
                self.shell_notice("SHUTTING DOWN.");
                self.exit_action = PowerAction::Shutdown;
                self.closed = true;
                return;
            }
        };
        match result {
            Ok(message) => self.shell_notice(&message),
            Err(error) => self.shell_notice(&format!("? {error}")),
        }
    }

    fn open_editor_window(&mut self, kind: EditorKind) -> Result<u64, Error> {
        let source = match kind {
            EditorKind::Sprite => SPRITE_EDITOR_SOURCE,
            EditorKind::Font => FONT_EDITOR_SOURCE,
        };
        let mut program = Program::new();
        let mut reader = io::Cursor::new(source.as_bytes());
        program.read_from(&mut reader, DEFAULT_MAX_SOURCE_LINE_BYTES)?;
        self.open_program_window_with_image(program)
    }

    fn open_program_window(
        &mut self,
        source_path: Option<std::path::PathBuf>,
    ) -> Result<u64, Error> {
        let context = ProgramWindowOpenContext {
            display: self.display,
            root: self.root,
            font: self.font,
            wm_delete: self.wm_delete,
            run_options: self.program_options.clone(),
            display_info: Arc::clone(&self.display_info),
            caps_mode: self.caps_mode,
            color_cache: &mut self.color_cache,
        };
        let task_id = self.program_windows.open(source_path, None, context)?;
        self.program_windows
            .focus(self.display, self.root, Some(task_id));
        Ok(task_id)
    }

    fn open_program_window_with_image(&mut self, program: Program) -> Result<u64, Error> {
        let context = ProgramWindowOpenContext {
            display: self.display,
            root: self.root,
            font: self.font,
            wm_delete: self.wm_delete,
            run_options: self.program_options.clone(),
            display_info: Arc::clone(&self.display_info),
            caps_mode: self.caps_mode,
            color_cache: &mut self.color_cache,
        };
        let task_id = self.program_windows.open(None, Some(program), context)?;
        self.program_windows
            .focus(self.display, self.root, Some(task_id));
        Ok(task_id)
    }

    fn apply_color_prefs(&mut self, prefs: ColorPrefs) -> Result<(), Error> {
        let prefs = ColorPrefs {
            screen_color: ColorPrefs::normalize_hex(&prefs.screen_color)?,
            text_color: ColorPrefs::normalize_hex(&prefs.text_color)?,
        };
        let colors = self.color_cache.colors_for_prefs(self.display, &prefs)?;
        prefs.save(self.program_options.file_root.as_deref())?;
        unsafe {
            XSetForeground(self.display, self.gc, colors.text);
            XSetBackground(self.display, self.gc, colors.screen);
            XSetForeground(self.display, self.reverse_gc, colors.screen);
            XSetBackground(self.display, self.reverse_gc, colors.text);
            XSetWindowBackground(self.display, self.window, colors.screen);
        }
        self.program_windows
            .set_colors(self.display, prefs.clone(), colors);
        self.color_prefs = prefs;
        self.dirty = true;
        Ok(())
    }

    fn finish_pending_run_stop(&mut self) {
        if !run_stop_has_completed(self.ready, self.run_stop_pending) {
            return;
        }
        self.run_stop_pending = false;
        self.show_text_screen();
        self.scroll_offset = 0;
        self.dirty = true;
    }

    fn drain_events(&mut self) -> Result<(), Error> {
        while unsafe { XPending(self.display) } > 0 {
            let mut event = XEvent { pad: [0; 24] };
            unsafe {
                XNextEvent(self.display, &mut event);
            }
            let event_type = unsafe { event.type_ };
            let event_window = unsafe { event.xany.window };
            if event_window != self.window && self.program_windows.contains_window(event_window) {
                match event_type {
                    KEY_PRESS => {
                        let key = unsafe { event.xkey };
                        let keysym = lookup_event_keysym(key);
                        if shell_control_function_shortcut(keysym, key.state) {
                            self.handle_control_function_key(keysym, true);
                        } else {
                            self.program_windows.handle_key(event_window, key);
                        }
                    }
                    KEY_RELEASE => {
                        let key = unsafe { event.xkey };
                        if !shell_control_function_shortcut(lookup_event_keysym(key), key.state) {
                            self.program_windows.handle_key_release(event_window, key);
                        }
                    }
                    FOCUS_IN => self.program_windows.handle_focus(event_window, true),
                    FOCUS_OUT => self.program_windows.handle_focus(event_window, false),
                    BUTTON_PRESS => {
                        let button = unsafe { event.xbutton };
                        self.program_windows
                            .handle_button(event_window, button, true);
                    }
                    BUTTON_RELEASE => {
                        let button = unsafe { event.xbutton };
                        self.program_windows
                            .handle_button(event_window, button, false);
                    }
                    MOTION_NOTIFY => {
                        let motion = unsafe { event.xmotion };
                        self.program_windows
                            .handle_motion(event_window, motion.x, motion.y);
                    }
                    LEAVE_NOTIFY => self.program_windows.handle_leave(event_window),
                    EXPOSE => self.program_windows.handle_expose(event_window),
                    SELECTION_NOTIFY => {
                        let selection = unsafe { event.xselection };
                        self.program_windows
                            .handle_selection_notify(event_window, selection);
                    }
                    SELECTION_REQUEST => {
                        let selection = unsafe { event.xselectionrequest };
                        self.program_windows
                            .handle_selection_request(event_window, selection);
                    }
                    SELECTION_CLEAR => {
                        let selection = unsafe { event.xselectionclear };
                        self.program_windows
                            .handle_selection_clear(event_window, selection);
                    }
                    CONFIGURE_NOTIFY => {
                        let configure = unsafe { event.xconfigure };
                        self.program_windows
                            .handle_configure(event_window, configure);
                    }
                    CLIENT_MESSAGE => {
                        let client = unsafe { event.xclient };
                        let first = unsafe { client.data.l[0] as Atom };
                        if first == self.wm_delete {
                            if let Some(task_id) = self
                                .program_windows
                                .close_window(self.display, event_window)
                            {
                                self.shell_notice(&format!("TASK {task_id} CLOSED."));
                                unsafe {
                                    XRaiseWindow(self.display, self.window);
                                }
                            }
                        }
                    }
                    _ => {}
                }
                continue;
            }
            match event_type {
                KEY_PRESS => {
                    let key = unsafe { event.xkey };
                    self.handle_key(key);
                }
                FOCUS_IN => {
                    self.has_focus = true;
                    self.dirty = true;
                }
                FOCUS_OUT => self.has_focus = false,
                BUTTON_PRESS => {
                    let button_event = unsafe { event.xbutton };
                    self.handle_button(button_event, true);
                }
                BUTTON_RELEASE => {
                    let button_event = unsafe { event.xbutton };
                    self.handle_button(button_event, false);
                }
                MOTION_NOTIFY => {
                    let motion = unsafe { event.xmotion };
                    self.update_pointer(motion.x, motion.y, None);
                    self.extend_selection(motion.x, motion.y);
                }
                LEAVE_NOTIFY => {
                    if let Ok(mut state) = self.pointer_state.lock() {
                        state.inside = false;
                    }
                }
                EXPOSE => {
                    self.dirty = true;
                }
                SELECTION_NOTIFY => {
                    let selection = unsafe { event.xselection };
                    self.handle_selection_notify(selection);
                }
                SELECTION_REQUEST => {
                    let selection = unsafe { event.xselectionrequest };
                    self.handle_selection_request(selection);
                }
                SELECTION_CLEAR => {
                    let selection = unsafe { event.xselectionclear };
                    self.handle_selection_clear(selection);
                }
                CONFIGURE_NOTIFY => {
                    let configure = unsafe { event.xconfigure };
                    self.width = configure.width.max(1) as u32;
                    self.height = configure.height.max(1) as u32;
                    self.ensure_program_panel_selection_visible();
                    self.dirty = true;
                }
                CLIENT_MESSAGE => {
                    let client = unsafe { event.xclient };
                    let first = unsafe { client.data.l[0] as Atom };
                    if first == self.wm_delete && event_window == self.window {
                        self.closed = true;
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    fn handle_button(&mut self, event: XButtonEvent, pressed: bool) {
        if self.help.is_open() {
            if pressed {
                let (_, rows) = help_dialog_capacity(self.width, self.height);
                match event.button {
                    4 => self.help.page_up(3),
                    5 => self.help.page_down(3.min(rows.max(1))),
                    _ => {}
                }
                self.dirty = true;
            }
            return;
        }
        self.update_pointer(event.x, event.y, Some((event.button, pressed)));
        if !pressed {
            if event.button == 1 {
                self.finish_selection(event.x, event.y, event.time);
            }
            return;
        }

        let left_width = self.left_panel_width();
        let in_terminal = event.x >= 0 && event.x < left_width as c_int;
        let in_program_manager = event.x >= left_width as c_int
            && event.x < self.width as c_int
            && event.y >= self.program_panel_top() as c_int
            && event.y < self.height as c_int;

        match event.button {
            1 if in_terminal => {
                self.active_panel = ActivePanel::Terminal;
                self.last_program_panel_click = None;
                self.begin_selection(event.x, event.y);
                self.dirty = true;
            }
            1 if in_program_manager => {
                self.active_panel = ActivePanel::ProgramManager;
                if let Some(index) = self.program_panel_row_at(event.x, event.y) {
                    let task_id = self.task_snapshot[index].task_id;
                    let double_click = self.last_program_panel_click.is_some_and(
                        |(previous_task_id, previous_time)| {
                            previous_task_id == task_id
                                && event.time.wrapping_sub(previous_time) <= DOUBLE_CLICK_INTERVAL
                        },
                    );
                    self.select_program_panel_index(index);
                    if double_click {
                        self.last_program_panel_click = None;
                        self.focus_selected_program();
                    } else {
                        self.last_program_panel_click = Some((task_id, event.time));
                    }
                } else {
                    self.last_program_panel_click = None;
                }
                self.dirty = true;
            }
            2 => self.request_paste(self.primary),
            4 if event.x >= left_width as c_int => self.scroll_program_panel_up(3),
            5 if event.x >= left_width as c_int => self.scroll_program_panel_down(3),
            4 => self.scroll_up(3),
            5 => self.scroll_down(3),
            _ => {}
        }
    }

    fn update_pointer(&self, x: c_int, y: c_int, button: Option<(c_uint, bool)>) {
        let mut logical = None;
        if let Some(raster) = self.raster.as_ref() {
            let status_visible =
                !(self.fullscreen && matches!(self.screen_view, ScreenView::Graphics));
            let content_height = if status_visible {
                (self.height as i32 - STATUS_HEIGHT).max(1)
            } else {
                self.height as i32
            };
            let graphics_height = match self.screen_view {
                ScreenView::Text => 0,
                ScreenView::Graphics => content_height,
                ScreenView::Split => (content_height * 2 / 3).max(1),
            };
            if graphics_height > 0 {
                if let Some(viewport) = raster_viewport(
                    self.width,
                    graphics_height as u32,
                    raster.width,
                    raster.height,
                    self.graphics_scale,
                ) {
                    logical = map_pointer_to_raster(x, y, viewport, raster.width, raster.height);
                }
            }
        }
        if let Ok(mut state) = self.pointer_state.lock() {
            state.update(logical, button);
        }
    }

    fn command_text_position(&self, x: c_int, y: c_int, clamp: bool) -> Option<TextPosition> {
        let width = (self.width.saturating_mul(65) / 100)
            .max(1)
            .min(self.width.saturating_sub(1).max(1));
        let columns = ((width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let rows =
            ((self.height as i32 - MARGIN_Y * 2 - FONT_HEIGHT * 2) / FONT_HEIGHT).max(1) as usize;
        let visual = self.visual_lines(columns);
        let end = visual.len().saturating_sub(self.scroll_offset);
        let start = end.saturating_sub(rows);
        let visible = end.saturating_sub(start);
        if visible == 0 {
            return None;
        }
        let top = MARGIN_Y + FONT_HEIGHT * 2;
        if !clamp
            && (x < MARGIN_X
                || x >= MARGIN_X + columns as i32 * FONT_WIDTH
                || y < top
                || y >= top + visible as i32 * FONT_HEIGHT)
        {
            return None;
        }
        let column = ((x - MARGIN_X) / FONT_WIDTH).clamp(0, columns as i32 - 1) as usize;
        let visible_row = ((y - top) / FONT_HEIGHT).clamp(0, visible as i32 - 1) as usize;
        Some((start + visible_row, column))
    }

    fn begin_selection(&mut self, x: c_int, y: c_int) {
        let position = self.command_text_position(x, y, false);
        self.selection_start = position;
        self.selection_end = position;
        self.selecting = position.is_some();
        self.dirty = true;
    }

    fn extend_selection(&mut self, x: c_int, y: c_int) {
        if !self.selecting {
            return;
        }
        if let Some(position) = self.command_text_position(x, y, true) {
            self.selection_end = Some(position);
            self.dirty = true;
        }
    }

    fn finish_selection(&mut self, x: c_int, y: c_int, time: Time) {
        if !self.selecting {
            return;
        }
        self.extend_selection(x, y);
        self.selecting = false;
        let (Some(start), Some(end)) = (self.selection_start, self.selection_end) else {
            return;
        };
        let width = (self.width.saturating_mul(65) / 100)
            .max(1)
            .min(self.width.saturating_sub(1).max(1));
        let columns = ((width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let visual = self.visual_lines(columns);
        self.selected_text = selected_text(visual.iter().map(String::as_str), start, end);
        if self.selected_text.is_empty() {
            self.selection_start = None;
            self.selection_end = None;
        } else {
            unsafe {
                XSetSelectionOwner(self.display, self.primary, self.window, time);
                XSetSelectionOwner(self.display, self.clipboard, self.window, time);
                XFlush(self.display);
            }
        }
        self.dirty = true;
    }

    fn handle_selection_request(&self, event: XSelectionRequestEvent) {
        if self.selected_text.is_empty()
            || (event.selection != self.primary && event.selection != self.clipboard)
        {
            return;
        }
        serve_text_selection(
            self.display,
            &self.selected_text,
            self.paste_targets(),
            self.targets_atom,
            self.atom_atom,
            event,
        );
    }

    fn handle_selection_clear(&mut self, event: XSelectionClearEvent) {
        if event.selection != self.primary && event.selection != self.clipboard {
            return;
        }
        self.selection_start = None;
        self.selection_end = None;
        self.selecting = false;
        self.selected_text.clear();
        self.dirty = true;
    }

    fn handle_control_function_key(&mut self, keysym: KeySym, from_program_window: bool) -> bool {
        match keysym {
            XK_F1 => {
                self.active_panel = match self.active_panel {
                    ActivePanel::Terminal => ActivePanel::ProgramManager,
                    ActivePanel::ProgramManager => ActivePanel::Terminal,
                };
                self.last_program_panel_click = None;
                self.ensure_program_panel_selection_visible();
                self.dirty = true;
                if from_program_window {
                    activate_window(self.display, self.root, self.window);
                }
                true
            }
            XK_F2 => {
                let tasks = self.program_windows.list();
                if !tasks.is_empty() {
                    let current = self.program_windows.selected_task();
                    let next = if let Some(current_id) = current {
                        let position = tasks.iter().position(|task| task.task_id == current_id);
                        match position {
                            Some(position) => tasks[(position + 1) % tasks.len()].task_id,
                            None => tasks[0].task_id,
                        }
                    } else {
                        tasks[0].task_id
                    };
                    self.program_windows
                        .focus(self.display, self.root, Some(next));
                }
                true
            }
            _ => false,
        }
    }

    fn handle_key(&mut self, mut event: XKeyEvent) {
        let mut buffer = [0 as c_char; 32];
        let mut keysym: KeySym = 0;
        let length = unsafe {
            XLookupString(
                &mut event,
                buffer.as_mut_ptr(),
                buffer.len() as c_int,
                &mut keysym,
                std::ptr::null_mut(),
            )
        };
        let ctrl = event.state & CONTROL_MASK != 0;
        let shift = event.state & SHIFT_MASK != 0;
        let lock = event.state & LOCK_MASK != 0;

        let typed_text = if length > 0 {
            let bytes = unsafe {
                std::slice::from_raw_parts(buffer.as_ptr().cast::<u8>(), length as usize)
            };
            std::str::from_utf8(bytes).ok().map(str::to_owned)
        } else {
            None
        };
        if self.help.is_open() {
            let (_, rows) = help_dialog_capacity(self.width, self.height);
            handle_help_dialog_key(&mut self.help, keysym, typed_text.as_deref(), rows);
            self.dirty = true;
            return;
        }
        if keysym == XK_F1 && !ctrl {
            self.show_help();
            return;
        }

        // Ctrl+F1 and Ctrl+F2 remain global system-window shortcuts.
        if ctrl && self.handle_control_function_key(keysym, false) {
            return;
        }

        if is_escape_interrupt(keysym, event.state) {
            if let Some(task_id) =
                break_target_task(&self.task_snapshot, self.program_windows.selected_task())
            {
                if self.program_windows.stop(Some(task_id)).is_some() {
                    self.last_program_panel_click = None;
                    self.shell_notice(&format!("TASK {task_id} BREAK REQUESTED."));
                }
                return;
            }
            self.paste_queue.clear();
            self.pending_paste = None;
            self.input.clear();
            self.cursor = 0;
            self.history_position = None;
            self.scroll_offset = 0;
            self.dirty = true;
            return;
        }

        if ctrl {
            match control_shortcut_letter(keysym) {
                Some(b'c') => {
                    self.paste_queue.clear();
                    if self.at_ready_prompt() {
                        self.input.clear();
                        self.cursor = 0;
                        self.history_position = None;
                        self.leave_program_navigation();
                        self.terminal.append_entered_line("^C");
                    } else {
                        self.terminal.push_bytes(b"^C\n");
                    }
                    self.scroll_offset = 0;
                    self.dirty = true;
                    return;
                }
                Some(b'v') => {
                    self.request_paste(self.clipboard);
                    return;
                }
                Some(b'l') => {
                    self.terminal.clear();
                    self.scroll_offset = 0;
                    self.dirty = true;
                    return;
                }
                Some(b'u') => {
                    self.caps_mode = !self.caps_mode;
                    self.dirty = true;
                    return;
                }
                _ => {}
            }
        }

        if self.active_panel == ActivePanel::ProgramManager {
            self.handle_program_panel_key(keysym);
            return;
        }

        match vertical_navigation(keysym, event.state) {
            Some(VerticalNavigation::HistoryPrevious) => {
                self.history_previous();
                return;
            }
            Some(VerticalNavigation::HistoryNext) => {
                self.history_next();
                return;
            }
            Some(VerticalNavigation::ProgramPrevious) => {
                if !self.program_line_previous() {
                    self.request_program_navigation(VerticalNavigation::ProgramPrevious);
                }
                return;
            }
            Some(VerticalNavigation::ProgramNext) => {
                if !self.program_line_next() {
                    self.request_program_navigation(VerticalNavigation::ProgramNext);
                }
                return;
            }
            None => {}
        }

        match keysym {
            XK_INSERT if shift => self.request_paste(self.clipboard),
            XK_RETURN => self.submit_input(),
            XK_BACKSPACE => self.backspace(),
            XK_DELETE => self.delete_forward(),
            XK_LEFT => self.move_left(),
            XK_RIGHT => self.move_right(),
            XK_HOME => {
                self.cursor = 0;
                self.dirty = true;
            }
            XK_END => {
                self.cursor = self.input.chars().count();
                self.dirty = true;
            }
            XK_PAGE_UP => self.scroll_up(self.visible_rows().saturating_sub(2)),
            XK_PAGE_DOWN => self.scroll_down(self.visible_rows().saturating_sub(2)),
            XK_F11 => {
                // Runtime fullscreen toggling is disabled. Select the managed
                // EWMH fullscreen state with --fullscreen at startup.
            }
            XK_ESCAPE => {
                self.paste_queue.clear();
                self.pending_paste = None;
                self.input.clear();
                self.cursor = 0;
                self.history_position = None;
                self.leave_program_navigation();
                self.show_text_screen();
                self.dirty = true;
            }
            _ if typed_text.is_some() => {
                if let Some(text) = typed_text.as_deref() {
                    for mut character in text.chars().filter(|character| !character.is_control()) {
                        if (self.caps_mode || (lock && !shift))
                            && character.is_ascii_alphabetic()
                            && !cursor_is_inside_quotes(&self.input, self.cursor)
                        {
                            character = character.to_ascii_uppercase();
                        }
                        self.insert_character(character);
                    }
                }
            }
            _ => {}
        }
    }

    fn paste_targets(&self) -> [Atom; 4] {
        [
            self.utf8_string,
            self.text_plain_utf8,
            self.text_atom,
            self.string_atom,
        ]
    }

    fn request_paste(&mut self, selection: Atom) {
        self.pending_paste = Some(PendingPaste {
            selection,
            target_index: 0,
        });
        self.request_pending_paste();
    }

    fn request_pending_paste(&mut self) {
        let Some(pending) = self.pending_paste else {
            return;
        };
        let targets = self.paste_targets();
        let Some(target) = targets.get(pending.target_index).copied() else {
            self.pending_paste = None;
            self.shell_notice("? CLIPBOARD DOES NOT CONTAIN TEXT");
            return;
        };
        unsafe {
            XConvertSelection(
                self.display,
                pending.selection,
                target,
                self.paste_property,
                self.window,
                0,
            );
            XFlush(self.display);
        }
    }

    fn retry_paste_target(&mut self) {
        if let Some(mut pending) = self.pending_paste {
            pending.target_index += 1;
            self.pending_paste = Some(pending);
            self.request_pending_paste();
        }
    }

    fn handle_selection_notify(&mut self, event: XSelectionEvent) {
        let Some(pending) = self.pending_paste else {
            return;
        };
        if event.requestor != self.window || event.selection != pending.selection {
            return;
        }
        if event.property == 0 {
            self.retry_paste_target();
            return;
        }

        let mut actual_type: Atom = 0;
        let mut actual_format: c_int = 0;
        let mut item_count: c_ulong = 0;
        let mut bytes_after: c_ulong = 0;
        let mut data: *mut u8 = std::ptr::null_mut();
        let long_length = MAX_PASTE_BYTES.div_ceil(4) as c_long;
        let status = unsafe {
            XGetWindowProperty(
                self.display,
                self.window,
                event.property,
                0,
                long_length,
                1,
                0,
                &mut actual_type,
                &mut actual_format,
                &mut item_count,
                &mut bytes_after,
                &mut data,
            )
        };

        if status != 0 || actual_type == 0 || actual_format != 8 || data.is_null() {
            if !data.is_null() {
                unsafe {
                    XFree(data.cast::<c_void>());
                }
            }
            unsafe {
                XDeleteProperty(self.display, self.window, event.property);
            }
            self.retry_paste_target();
            return;
        }

        let length = item_count as usize;
        if length > MAX_PASTE_BYTES || bytes_after != 0 {
            unsafe {
                XFree(data.cast::<c_void>());
                XDeleteProperty(self.display, self.window, event.property);
            }
            self.pending_paste = None;
            self.shell_notice("? PASTE TOO LARGE");
            return;
        }

        let bytes = unsafe { std::slice::from_raw_parts(data as *const u8, length) };
        let text = if event.target == self.string_atom {
            bytes
                .iter()
                .map(|byte| char::from(*byte))
                .collect::<String>()
        } else {
            String::from_utf8_lossy(bytes).into_owned()
        };
        unsafe {
            XFree(data.cast::<c_void>());
            XDeleteProperty(self.display, self.window, event.property);
        }
        self.pending_paste = None;
        self.apply_paste(&text);
    }

    fn apply_paste(&mut self, text: &str) {
        match plan_paste(&self.input, self.cursor, text) {
            PastePlan::Insert(text) => self.insert_text(&text),
            PastePlan::Submit(lines) => {
                self.input.clear();
                self.cursor = 0;
                self.history_position = None;
                if self.at_ready_prompt() {
                    self.paste_queue.extend(lines);
                    self.submit_next_paste_line();
                } else {
                    for line in lines {
                        self.terminal.append_entered_line(&line);
                        let _ = self.send_line(&line);
                    }
                    self.scroll_offset = 0;
                    self.dirty = true;
                }
            }
        }
    }

    fn submit_next_paste_line(&mut self) {
        if !self.at_ready_prompt() {
            return;
        }
        let Some(line) = self.paste_queue.pop_front() else {
            return;
        };
        self.replace_input(&line);
        self.submit_input();
    }

    fn insert_text(&mut self, text: &str) {
        let byte = byte_index_for_character(&self.input, self.cursor);
        self.input.insert_str(byte, text);
        self.cursor += text.chars().count();
        self.cursor_visible = true;
        self.cursor_changed = Instant::now();
        self.dirty = true;
    }

    fn shell_notice(&mut self, message: &str) {
        if message.trim_start().starts_with('?') {
            program_window::log_diagnostic_error(None, message);
        }
        if !self.terminal.current.is_empty() {
            self.terminal.finish_line();
        }
        self.terminal.push_bytes(message.as_bytes());
        self.terminal.finish_line();
        self.scroll_offset = 0;
        self.dirty = true;
    }

    fn submit_input(&mut self) {
        let line = self.input.clone();
        let remember = self.at_ready_prompt();
        if self.program_navigation_active {
            if numbered_program_line(&line).is_some() {
                self.record_program_line_submission(&line);
            } else if !line.trim().is_empty() {
                self.leave_program_navigation();
            }
        }
        self.input.clear();
        self.cursor = 0;
        self.history_position = None;
        self.terminal.append_entered_line(&format!("> {line}"));
        if remember {
            remember_history(&mut self.history, &line);
        }
        let _ = self.send_line(&line);
        self.scroll_offset = 0;
        self.cursor_visible = true;
        self.cursor_changed = Instant::now();
        self.dirty = true;
    }

    fn submit_command(&mut self, command: &str) -> Result<(), Error> {
        if !command.trim().eq_ignore_ascii_case("LIST") {
            self.leave_program_navigation();
        }
        self.terminal.append_entered_line(&format!("> {command}"));
        remember_history(&mut self.history, command);
        self.history_position = None;
        self.send_line(command)?;
        self.scroll_offset = 0;
        self.dirty = true;
        Ok(())
    }

    fn replace_input(&mut self, text: &str) {
        self.input.clear();
        self.input.push_str(text);
        self.cursor = self.input.chars().count();
        self.history_position = None;
        self.cursor_visible = true;
        self.cursor_changed = Instant::now();
        self.dirty = true;
    }

    fn show_text_screen(&mut self) {
        if self.screen_view != ScreenView::Text {
            self.screen_view = ScreenView::Text;
            self.update_window_title();
        }
    }

    fn show_help(&mut self) {
        let (columns, _) = help_dialog_capacity(self.width, self.height);
        self.help.show(columns);
        self.selection_start = None;
        self.selection_end = None;
        self.selecting = false;
        self.dirty = true;
    }

    fn at_ready_prompt(&self) -> bool {
        self.ready
    }

    fn send_line(&mut self, line: &str) -> Result<(), Error> {
        if let Ok(mut queue) = self.key_queue.lock() {
            queue.clear();
        }
        let mut bytes = line.as_bytes().to_vec();
        bytes.push(b'\n');
        self.input_sender
            .send(bytes)
            .map_err(|_| Error::Io("BASIC session closed".into()))?;
        self.ready = false;
        Ok(())
    }

    fn insert_character(&mut self, character: char) {
        let byte = byte_index_for_character(&self.input, self.cursor);
        self.input.insert(byte, character);
        self.cursor += 1;
        self.dirty = true;
    }

    fn backspace(&mut self) {
        if self.cursor == 0 {
            return;
        }
        let start = byte_index_for_character(&self.input, self.cursor - 1);
        let end = byte_index_for_character(&self.input, self.cursor);
        self.input.replace_range(start..end, "");
        self.cursor -= 1;
        self.dirty = true;
    }

    fn delete_forward(&mut self) {
        let count = self.input.chars().count();
        if self.cursor >= count {
            return;
        }
        let start = byte_index_for_character(&self.input, self.cursor);
        let end = byte_index_for_character(&self.input, self.cursor + 1);
        self.input.replace_range(start..end, "");
        self.dirty = true;
    }

    fn move_left(&mut self) {
        self.cursor = self.cursor.saturating_sub(1);
        self.dirty = true;
    }

    fn move_right(&mut self) {
        self.cursor = (self.cursor + 1).min(self.input.chars().count());
        self.dirty = true;
    }

    fn history_previous(&mut self) {
        if !self.at_ready_prompt() || self.history.is_empty() {
            return;
        }
        let position = self
            .history_position
            .map(|position| position.saturating_sub(1))
            .unwrap_or(self.history.len() - 1);
        self.history_position = Some(position);
        self.input = self.history[position].clone();
        self.cursor = self.input.chars().count();
        self.program_line_position = None;
        self.dirty = true;
    }

    fn history_next(&mut self) {
        if !self.at_ready_prompt() {
            return;
        }
        let Some(position) = self.history_position else {
            return;
        };
        if position + 1 < self.history.len() {
            let next = position + 1;
            self.history_position = Some(next);
            self.input = self.history[next].clone();
        } else {
            self.history_position = None;
            self.input.clear();
        }
        self.cursor = self.input.chars().count();
        self.program_line_position = None;
        self.dirty = true;
    }

    fn refresh_program_lines(&mut self) {
        self.program_lines =
            program_listing_after_last_list(&self.terminal.lines).unwrap_or_default();
        self.program_line_position = None;
        self.program_navigation_active = !self.program_lines.is_empty();
    }

    fn leave_program_navigation(&mut self) {
        self.program_lines.clear();
        self.program_line_position = None;
        self.program_navigation_active = false;
        self.program_listing_pending = false;
        self.pending_program_navigation = None;
    }

    fn request_program_navigation(&mut self, navigation: VerticalNavigation) {
        if !self.at_ready_prompt()
            || self.program_listing_pending
            || !matches!(
                navigation,
                VerticalNavigation::ProgramPrevious | VerticalNavigation::ProgramNext
            )
        {
            return;
        }
        self.program_navigation_active = false;
        self.program_line_position = None;
        self.pending_program_navigation = Some(navigation);
        self.program_listing_pending = true;
        if self.submit_command("LIST").is_err() {
            self.program_listing_pending = false;
            self.pending_program_navigation = None;
        }
    }

    fn apply_program_navigation(&mut self, navigation: VerticalNavigation) -> bool {
        match navigation {
            VerticalNavigation::ProgramPrevious => self.program_line_previous(),
            VerticalNavigation::ProgramNext => self.program_line_next(),
            VerticalNavigation::HistoryPrevious | VerticalNavigation::HistoryNext => false,
        }
    }

    fn program_line_previous(&mut self) -> bool {
        if !program_navigation_available(
            self.program_navigation_active,
            self.program_lines.len(),
            self.at_ready_prompt(),
        ) {
            return false;
        }
        let Some(position) = program_navigation_index(
            self.program_line_position,
            self.program_lines.len(),
            VerticalNavigation::ProgramPrevious,
        ) else {
            return false;
        };
        self.load_program_line(position)
    }

    fn program_line_next(&mut self) -> bool {
        if !program_navigation_available(
            self.program_navigation_active,
            self.program_lines.len(),
            self.at_ready_prompt(),
        ) {
            return false;
        }
        let Some(position) = program_navigation_index(
            self.program_line_position,
            self.program_lines.len(),
            VerticalNavigation::ProgramNext,
        ) else {
            return false;
        };
        self.load_program_line(position)
    }

    fn load_program_line(&mut self, position: usize) -> bool {
        let Some(line) = self.program_lines.get(position).cloned() else {
            self.program_line_position = None;
            self.program_navigation_active = !self.program_lines.is_empty();
            return false;
        };
        self.program_line_position = Some(position);
        self.input = line;
        self.cursor = self.input.chars().count();
        self.history_position = None;
        self.cursor_visible = true;
        self.cursor_changed = Instant::now();
        self.scroll_offset = 0;
        self.dirty = true;
        true
    }

    fn record_program_line_submission(&mut self, source: &str) {
        self.program_navigation_active = update_program_line_cache(
            &mut self.program_lines,
            &mut self.program_line_position,
            source,
        );
    }

    fn update_task_snapshot(&mut self, tasks: Vec<ProgramTaskInfo>) {
        let selected_task_id = self
            .task_snapshot
            .get(self.program_panel_selected)
            .map(|task| task.task_id);
        self.task_snapshot = tasks;
        if let Some(index) = selected_task_id.and_then(|task_id| {
            self.task_snapshot
                .iter()
                .position(|task| task.task_id == task_id)
        }) {
            self.program_panel_selected = index;
        }
        self.ensure_program_panel_selection_visible();
        self.dirty = true;
    }

    fn handle_program_panel_key(&mut self, keysym: KeySym) {
        self.last_program_panel_click = None;
        let page = self.program_panel_visible_rows().max(1);
        match keysym {
            XK_UP => self.select_program_panel_index(self.program_panel_selected.saturating_sub(1)),
            XK_DOWN => self.select_program_panel_index(
                self.program_panel_selected
                    .saturating_add(1)
                    .min(self.task_snapshot.len().saturating_sub(1)),
            ),
            XK_PAGE_UP => self.scroll_program_panel_up(page),
            XK_PAGE_DOWN => self.scroll_program_panel_down(page),
            XK_HOME => self.select_program_panel_index(0),
            XK_END => self.select_program_panel_index(self.task_snapshot.len().saturating_sub(1)),
            XK_RETURN => self.focus_selected_program(),
            key if key == b's' as KeySym || key == b'S' as KeySym => self.stop_selected_program(),
            XK_DELETE | XK_BACKSPACE => self.close_selected_program(),
            _ => {}
        }
    }

    fn select_program_panel_index(&mut self, index: usize) {
        if self.task_snapshot.is_empty() {
            self.program_panel_selected = 0;
            self.program_panel_scroll = 0;
        } else {
            self.program_panel_selected = index.min(self.task_snapshot.len() - 1);
            self.ensure_program_panel_selection_visible();
        }
        self.dirty = true;
    }

    fn scroll_program_panel_up(&mut self, amount: usize) {
        let visible_rows = self.program_panel_visible_rows();
        self.program_panel_scroll = self.program_panel_scroll.saturating_sub(amount);
        if visible_rows > 0
            && self.program_panel_selected >= self.program_panel_scroll + visible_rows
        {
            self.program_panel_selected = self.program_panel_scroll + visible_rows - 1;
        }
        self.ensure_program_panel_selection_visible();
        self.dirty = true;
    }

    fn scroll_program_panel_down(&mut self, amount: usize) {
        let visible_rows = self.program_panel_visible_rows();
        let maximum = self.task_snapshot.len().saturating_sub(visible_rows);
        self.program_panel_scroll = self
            .program_panel_scroll
            .saturating_add(amount)
            .min(maximum);
        if self.program_panel_selected < self.program_panel_scroll {
            self.program_panel_selected = self.program_panel_scroll;
        }
        self.ensure_program_panel_selection_visible();
        self.dirty = true;
    }

    fn ensure_program_panel_selection_visible(&mut self) {
        (self.program_panel_selected, self.program_panel_scroll) =
            normalized_program_panel_selection(
                self.task_snapshot.len(),
                self.program_panel_visible_rows(),
                self.program_panel_selected,
                self.program_panel_scroll,
            );
    }

    fn focus_selected_program(&mut self) {
        let Some(task_id) = self
            .task_snapshot
            .get(self.program_panel_selected)
            .map(|task| task.task_id)
        else {
            return;
        };
        self.program_windows
            .focus(self.display, self.root, Some(task_id));
    }

    fn close_selected_program(&mut self) {
        let Some(task_id) = self
            .task_snapshot
            .get(self.program_panel_selected)
            .map(|task| task.task_id)
        else {
            return;
        };
        if self
            .program_windows
            .close(self.display, Some(task_id))
            .is_some()
        {
            self.last_program_panel_click = None;
            let tasks = self.program_windows.list();
            self.update_task_snapshot(tasks);
            self.shell_notice(&format!("TASK {task_id} CLOSED."));
        }
    }

    fn stop_selected_program(&mut self) {
        let Some(task_id) = self
            .task_snapshot
            .get(self.program_panel_selected)
            .map(|task| task.task_id)
        else {
            return;
        };
        if self.program_windows.stop(Some(task_id)).is_some() {
            self.last_program_panel_click = None;
            self.shell_notice(&format!("TASK {task_id} STOP REQUESTED."));
        }
    }

    fn left_panel_width(&self) -> u32 {
        left_panel_width(self.width)
    }

    fn program_panel_top(&self) -> u32 {
        program_panel_top(self.height, self.hardware.lines().len())
    }

    fn program_panel_visible_rows(&self) -> usize {
        program_panel_visible_rows(self.height.saturating_sub(self.program_panel_top()))
    }

    fn program_panel_row_at(&self, x: c_int, y: c_int) -> Option<usize> {
        let left = self.left_panel_width() as c_int;
        let row_top = self.program_panel_top() as c_int + MARGIN_Y + FONT_HEIGHT * 2;
        if x < left || x >= self.width as c_int || y < row_top || y >= self.height as c_int {
            return None;
        }
        let visible_row = usize::try_from((y - row_top) / FONT_HEIGHT).ok()?;
        if visible_row >= self.program_panel_visible_rows() {
            return None;
        }
        let index = self.program_panel_scroll.saturating_add(visible_row);
        (index < self.task_snapshot.len()).then_some(index)
    }

    fn scroll_up(&mut self, amount: usize) {
        let columns = ((self.width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let visual_total = self.visual_lines(columns).len();
        let maximum = visual_total.saturating_sub(self.visible_rows().max(1));
        self.scroll_offset = (self.scroll_offset + amount).min(maximum);
        self.dirty = true;
    }

    fn scroll_down(&mut self, amount: usize) {
        self.scroll_offset = self.scroll_offset.saturating_sub(amount);
        self.dirty = true;
    }

    fn visible_rows(&self) -> usize {
        let content = if self.fullscreen && matches!(self.screen_view, ScreenView::Graphics) {
            self.height as i32
        } else {
            self.height as i32 - STATUS_HEIGHT
        };
        let text_height = match self.screen_view {
            ScreenView::Text => content,
            ScreenView::Split => content - (content * 2 / 3) - 1,
            ScreenView::Graphics => FONT_HEIGHT + MARGIN_Y * 2,
        };
        ((text_height - MARGIN_Y * 2) / FONT_HEIGHT).max(1) as usize
    }

    fn redraw(&mut self) {
        if self.help.is_open() {
            draw_help_dialog(
                self.display,
                self.window,
                self.gc,
                self.reverse_gc,
                self.width,
                self.height,
                &mut self.help,
            );
            unsafe {
                XFlush(self.display);
            }
            self.dirty = false;
            return;
        }
        let left_width = self.left_panel_width();
        let right_width = self.width.saturating_sub(left_width);
        let right_split = self.program_panel_top();
        unsafe {
            XFillRectangle(
                self.display,
                self.window,
                self.reverse_gc,
                0,
                0,
                left_width,
                self.height,
            );
            XFillRectangle(
                self.display,
                self.window,
                self.reverse_gc,
                left_width as i32,
                0,
                right_width,
                right_split,
            );
            XFillRectangle(
                self.display,
                self.window,
                self.reverse_gc,
                left_width as i32,
                right_split as i32,
                right_width,
                self.height.saturating_sub(right_split),
            );
            XDrawLine(
                self.display,
                self.window,
                self.gc,
                left_width as i32,
                0,
                left_width as i32,
                self.height as i32,
            );
            XDrawLine(
                self.display,
                self.window,
                self.gc,
                left_width as i32,
                right_split as i32,
                self.width as i32,
                right_split as i32,
            );
        }
        self.draw_command_panel(left_width, self.height);
        self.draw_hardware_panel(left_width, right_width, right_split);
        self.draw_task_panel(
            left_width,
            right_split,
            right_width,
            self.height.saturating_sub(right_split),
        );
        unsafe {
            XFlush(self.display);
        }
        self.dirty = false;
    }

    fn draw_highlighted_ascii(&self, x: i32, y: i32, text: &str, width: u32) {
        if width > 0 {
            unsafe {
                XFillRectangle(
                    self.display,
                    self.window,
                    self.gc,
                    x,
                    y - FONT_ASCENT,
                    width,
                    FONT_HEIGHT as u32,
                );
            }
        }
        draw_ascii(self.display, self.window, self.reverse_gc, x, y, text);
    }

    fn draw_command_panel(&self, width: u32, height: u32) {
        let columns = ((width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let rows = ((height as i32 - MARGIN_Y * 2 - FONT_HEIGHT * 2) / FONT_HEIGHT).max(1) as usize;
        let header = "SYSTEM COMMAND INTERFACE - F1 HELP";
        let header_y = MARGIN_Y + FONT_ASCENT;
        if self.active_panel == ActivePanel::Terminal {
            self.draw_highlighted_ascii(
                MARGIN_X,
                header_y,
                header,
                (header.len() as i32 * FONT_WIDTH) as u32,
            );
        } else {
            draw_ascii(
                self.display,
                self.window,
                self.gc,
                MARGIN_X,
                header_y,
                header,
            );
        }
        let current = format!("> {}", self.input);
        let visual = self.visual_lines(columns);
        let total = visual.len();
        let end = total.saturating_sub(self.scroll_offset);
        let start = end.saturating_sub(rows);
        let top = MARGIN_Y + FONT_HEIGHT * 2;
        for (row, line) in visual[start..end].iter().enumerate() {
            let y = top + FONT_ASCENT + row as i32 * FONT_HEIGHT;
            draw_ascii(self.display, self.window, self.gc, MARGIN_X, y, line);
            if let (Some(selection_start), Some(selection_end)) =
                (self.selection_start, self.selection_end)
            {
                let line_length = line.chars().count();
                if let Some((first, last)) =
                    selection_span(start + row, line_length, selection_start, selection_end)
                {
                    let selected = line
                        .chars()
                        .skip(first)
                        .take(last - first)
                        .collect::<String>();
                    let x = MARGIN_X + first as i32 * FONT_WIDTH;
                    unsafe {
                        XFillRectangle(
                            self.display,
                            self.window,
                            self.gc,
                            x,
                            y - FONT_ASCENT,
                            ((last - first) as i32 * FONT_WIDTH) as u32,
                            FONT_HEIGHT as u32,
                        );
                    }
                    draw_ascii(self.display, self.window, self.reverse_gc, x, y, &selected);
                }
            }
        }
        if self.at_ready_prompt() && self.cursor_visible && self.scroll_offset == 0 {
            let prefix = format!(
                "> {}",
                self.input.chars().take(self.cursor).collect::<String>()
            );
            let cursor_row = total
                .saturating_sub(cursor_line_count(&current, columns))
                .saturating_add(prefix.chars().count() / columns);
            if cursor_row >= start && cursor_row < end {
                let x = MARGIN_X + (prefix.chars().count() % columns) as i32 * FONT_WIDTH;
                let y = top + (cursor_row - start) as i32 * FONT_HEIGHT + FONT_HEIGHT - 2;
                unsafe {
                    XFillRectangle(
                        self.display,
                        self.window,
                        self.gc,
                        x,
                        y,
                        FONT_WIDTH as u32,
                        2,
                    );
                }
            }
        }
    }

    fn draw_hardware_panel(&self, left: u32, width: u32, height: u32) {
        let x = left as i32 + MARGIN_X;
        let columns = ((width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let lines = self.hardware.lines();
        let max_rows = ((height as i32 - MARGIN_Y * 2) / FONT_HEIGHT).max(0) as usize;
        for (row, line) in lines.iter().take(max_rows).enumerate() {
            let line = line.chars().take(columns).collect::<String>();
            draw_ascii(
                self.display,
                self.window,
                self.gc,
                x,
                MARGIN_Y + FONT_ASCENT + row as i32 * FONT_HEIGHT,
                &line,
            );
        }
    }

    fn draw_task_panel(&self, left: u32, top: u32, width: u32, height: u32) {
        let x = left as i32 + MARGIN_X;
        let columns = ((width as i32 - MARGIN_X * 2) / FONT_WIDTH).max(1) as usize;
        let max_rows = ((height as i32 - MARGIN_Y * 2) / FONT_HEIGHT).max(0) as usize;
        let panel_y = top as i32 + MARGIN_Y + FONT_ASCENT;
        let header = "PROGRAM MANAGER".chars().take(columns).collect::<String>();
        if self.active_panel == ActivePanel::ProgramManager {
            self.draw_highlighted_ascii(
                x,
                panel_y,
                &header,
                (header.chars().count() as i32 * FONT_WIDTH) as u32,
            );
        } else {
            draw_ascii(self.display, self.window, self.gc, x, panel_y, &header);
        }

        if max_rows > 1 {
            let columns_header = "ID  FILE                 STATE"
                .chars()
                .take(columns)
                .collect::<String>();
            draw_ascii(
                self.display,
                self.window,
                self.gc,
                x,
                panel_y + FONT_HEIGHT,
                &columns_header,
            );
        }

        let visible_rows = max_rows.saturating_sub(2);
        if visible_rows == 0 {
            return;
        }
        if self.task_snapshot.is_empty() {
            draw_ascii(
                self.display,
                self.window,
                self.gc,
                x,
                panel_y + FONT_HEIGHT * 2,
                &"NO OPEN PROGRAMS".chars().take(columns).collect::<String>(),
            );
            return;
        }

        let start = self
            .program_panel_scroll
            .min(self.task_snapshot.len().saturating_sub(visible_rows));
        let end = start
            .saturating_add(visible_rows)
            .min(self.task_snapshot.len());
        let highlight_width = (columns as i32 * FONT_WIDTH).max(0) as u32;
        for (visible_row, task) in self.task_snapshot[start..end].iter().enumerate() {
            let task_index = start + visible_row;
            let line = format!(
                "{:<3} {:<20} {}",
                task.task_id,
                task.filename.chars().take(20).collect::<String>(),
                task.status.name()
            )
            .chars()
            .take(columns)
            .collect::<String>();
            let y = panel_y + (visible_row as i32 + 2) * FONT_HEIGHT;
            if task_index == self.program_panel_selected {
                self.draw_highlighted_ascii(x, y, &line, highlight_width);
            } else {
                draw_ascii(self.display, self.window, self.gc, x, y, &line);
            }
        }
    }

    fn visual_lines(&self, columns: usize) -> Vec<String> {
        let mut result = Vec::new();
        for line in &self.terminal.lines {
            result.extend(wrap_completed_line(line, columns));
        }
        let current = format!("> {}", self.input);
        result.extend(wrap_cursor_line(&current, columns));
        if result.is_empty() {
            result.push(String::new());
        }
        result
    }

    fn update_window_title(&self) {
        let view = match self.screen_view {
            ScreenView::Text => "TEXT",
            ScreenView::Graphics => "GRAPHICS",
            ScreenView::Split => "SPLIT",
        };
        if let Ok(title) = CString::new(format!(
            "ModernBASIC {} - {view}",
            env!("CARGO_PKG_VERSION")
        )) {
            unsafe {
                XStoreName(self.display, self.window, title.as_ptr());
            }
        }
    }

    fn screen_width(&self) -> u32 {
        self.screen_width
    }

    fn screen_height(&self) -> u32 {
        self.screen_height
    }
}

pub(crate) struct RasterWindowTarget {
    pub(crate) display: *mut Display,
    pub(crate) window: Window,
    pub(crate) gc: GC,
    pub(crate) x: i32,
    pub(crate) y: i32,
    pub(crate) width: u32,
    pub(crate) height: u32,
}

pub(crate) struct X11RasterSurface {
    image: *mut XImage,
    width: u32,
    height: u32,
    source_width: u32,
    source_height: u32,
    source_columns: Vec<usize>,
    source_rows: Vec<usize>,
}

impl Default for X11RasterSurface {
    fn default() -> Self {
        Self {
            image: std::ptr::null_mut(),
            width: 0,
            height: 0,
            source_width: 0,
            source_height: 0,
            source_columns: Vec::new(),
            source_rows: Vec::new(),
        }
    }
}

impl X11RasterSurface {
    fn reset(&mut self) {
        if !self.image.is_null() {
            unsafe {
                XDestroyImage(self.image);
            }
            self.image = std::ptr::null_mut();
        }
        self.width = 0;
        self.height = 0;
    }

    fn ensure_image(
        &mut self,
        display: *mut Display,
        width: u32,
        height: u32,
    ) -> Result<(), Error> {
        if !self.image.is_null() && self.width == width && self.height == height {
            return Ok(());
        }
        self.reset();
        let screen_number = unsafe { XDefaultScreen(display) };
        let visual = unsafe { XDefaultVisual(display, screen_number) };
        let depth = unsafe { XDefaultDepth(display, screen_number) };
        if visual.is_null() || depth <= 0 {
            return Err(Error::Io(
                "cannot determine X11 visual for graphics screen".into(),
            ));
        }
        let image = unsafe {
            XCreateImage(
                display,
                visual,
                depth as c_uint,
                ZPIXMAP,
                0,
                std::ptr::null_mut(),
                width,
                height,
                32,
                0,
            )
        };
        if image.is_null() {
            return Err(Error::Io("cannot create X11 graphics screen image".into()));
        }
        unsafe {
            let bytes_per_line = (*image).bytes_per_line;
            let Some(total) = usize::try_from(bytes_per_line).ok().and_then(|line| {
                usize::try_from(height)
                    .ok()
                    .and_then(|height| line.checked_mul(height))
            }) else {
                XDestroyImage(image);
                return Err(Error::Io("X11 graphics screen allocation overflow".into()));
            };
            let data = calloc(total, 1).cast::<c_char>();
            if data.is_null() {
                XDestroyImage(image);
                return Err(Error::Io(
                    "not enough memory for X11 graphics screen".into(),
                ));
            }
            (*image).data = data;
        }
        self.image = image;
        self.width = width;
        self.height = height;
        Ok(())
    }

    fn prepare_mapping(&mut self, raster: &RasterImage) {
        if self.source_width == raster.width
            && self.source_height == raster.height
            && self.source_columns.len() == self.width as usize
            && self.source_rows.len() == self.height as usize
        {
            return;
        }
        self.source_width = raster.width;
        self.source_height = raster.height;
        self.source_columns = (0..self.width)
            .map(|x| (u64::from(x) * u64::from(raster.width) / u64::from(self.width)) as usize * 3)
            .collect();
        self.source_rows = (0..self.height)
            .map(|y| {
                (u64::from(y) * u64::from(raster.height) / u64::from(self.height)) as usize
                    * raster.width as usize
                    * 3
            })
            .collect();
    }
}

impl Drop for X11RasterSurface {
    fn drop(&mut self) {
        self.reset();
    }
}

fn put_raster_to_window(
    target: RasterWindowTarget,
    raster: &RasterImage,
    surface: &mut X11RasterSurface,
) -> Result<(), Error> {
    let RasterWindowTarget {
        display,
        window,
        gc,
        x,
        y,
        width,
        height,
    } = target;
    if width == 0 || height == 0 {
        return Ok(());
    }
    surface.ensure_image(display, width, height)?;
    surface.prepare_mapping(raster);
    let image = surface.image;
    unsafe {
        fill_ximage(
            image,
            raster,
            width,
            height,
            &surface.source_columns,
            &surface.source_rows,
        )?;
        XPutImage(display, window, gc, image, 0, 0, x, y, width, height);
    }
    Ok(())
}

impl Drop for X11Shell {
    fn drop(&mut self) {
        if self.display.is_null() {
            return;
        }
        self.program_windows.close_all(self.display);
        unsafe {
            if self.font != 0 {
                XUnloadFont(self.display, self.font);
            }
            if !self.gc.is_null() {
                XFreeGC(self.display, self.gc);
            }
            if !self.reverse_gc.is_null() {
                XFreeGC(self.display, self.reverse_gc);
            }
            if self.window != 0 {
                XDestroyWindow(self.display, self.window);
            }
            self.color_cache.free(self.display);
            XCloseDisplay(self.display);
        }
        self.display = std::ptr::null_mut();
    }
}

fn normalize_paste_text(text: &str) -> String {
    let mut normalized = String::with_capacity(text.len());
    let mut characters = text.chars().peekable();
    while let Some(character) = characters.next() {
        match character {
            '\r' => {
                if characters.peek() == Some(&'\n') {
                    characters.next();
                }
                normalized.push('\n');
            }
            '\n' => normalized.push(character),
            '\t' => normalized.push(' '),
            '\0' => {}
            character if !character.is_control() => normalized.push(character),
            _ => {}
        }
    }
    normalized
}

fn plan_paste(input: &str, cursor: usize, text: &str) -> PastePlan {
    let normalized = normalize_paste_text(text);
    if !normalized.contains('\n') {
        return PastePlan::Insert(normalized);
    }

    let split = byte_index_for_character(input, cursor);
    let prefix = &input[..split];
    let suffix = &input[split..];
    let ended_with_newline = normalized.ends_with('\n');
    let mut lines = normalized
        .split('\n')
        .map(ToOwned::to_owned)
        .collect::<Vec<_>>();
    if ended_with_newline && lines.last().is_some_and(String::is_empty) {
        lines.pop();
    }
    if lines.is_empty() {
        return PastePlan::Insert(String::new());
    }
    lines[0].insert_str(0, prefix);
    if let Some(last) = lines.last_mut() {
        last.push_str(suffix);
    }
    PastePlan::Submit(lines)
}

fn byte_index_for_character(text: &str, character_index: usize) -> usize {
    text.char_indices()
        .nth(character_index)
        .map(|(index, _)| index)
        .unwrap_or(text.len())
}

fn detect_cpu_name() -> String {
    if let Ok(cpuinfo) = std::fs::read_to_string("/proc/cpuinfo") {
        if let Some(name) = cpuinfo.lines().find_map(|line| {
            let (key, value) = line.split_once(':')?;
            key.trim()
                .eq_ignore_ascii_case("model name")
                .then(|| value.trim().to_string())
        }) {
            return name;
        }
    }
    let count = thread::available_parallelism().map_or(1, usize::from);
    format!("{count} logical CPU(s)")
}

fn detect_cpu_load() -> String {
    std::fs::read_to_string("/proc/loadavg")
        .ok()
        .and_then(|loadavg| loadavg.split_whitespace().next().map(str::to_string))
        .unwrap_or_else(|| "UNKNOWN".to_string())
}

fn detect_memory_usage() -> String {
    let Ok(meminfo) = std::fs::read_to_string("/proc/meminfo") else {
        return "UNKNOWN".to_string();
    };
    let mut available_kib = None;
    let mut total_kib = None;
    for line in meminfo.lines() {
        let Some((key, value)) = line.split_once(':') else {
            continue;
        };
        let kib = value
            .split_whitespace()
            .next()
            .and_then(|value| value.parse::<u64>().ok());
        match key {
            "MemAvailable" => available_kib = kib,
            "MemTotal" => total_kib = kib,
            _ => {}
        }
    }
    match (available_kib, total_kib) {
        (Some(available), Some(total)) => format!(
            "{:.1} GiB / {:.1} GiB",
            available as f64 / 1024.0 / 1024.0,
            total as f64 / 1024.0 / 1024.0
        ),
        _ => "UNKNOWN".to_string(),
    }
}

fn detect_audio_system() -> String {
    if crate::synth::is_audio_disabled() {
        return "DISABLED".to_string();
    }
    if std::env::var_os("PIPEWIRE_RUNTIME_DIR").is_some()
        || std::env::var_os("XDG_RUNTIME_DIR")
            .map(std::path::PathBuf::from)
            .is_some_and(|directory| directory.join("pipewire-0").exists())
    {
        return "PipeWire".to_string();
    }
    if std::path::Path::new("/proc/asound").exists() {
        return "ALSA".to_string();
    }
    "SYSTEM".to_string()
}

fn numbered_program_line(source: &str) -> Option<(u64, &str)> {
    let canonical = source.trim_start();
    let digit_bytes = canonical
        .as_bytes()
        .iter()
        .take_while(|byte| byte.is_ascii_digit())
        .count();
    if digit_bytes == 0 {
        return None;
    }
    let remainder = &canonical[digit_bytes..];
    if !remainder.is_empty()
        && !remainder
            .as_bytes()
            .first()
            .is_some_and(u8::is_ascii_whitespace)
    {
        return None;
    }
    let number = canonical[..digit_bytes].parse::<u64>().ok()?;
    Some((number, canonical.trim_end()))
}

fn program_line_has_body(source: &str) -> bool {
    numbered_program_line(source).is_some_and(|(_, canonical)| {
        let digits = canonical
            .as_bytes()
            .iter()
            .take_while(|byte| byte.is_ascii_digit())
            .count();
        !canonical[digits..].trim().is_empty()
    })
}

fn validated_numbered_program_line(source: &str) -> Option<(u64, &str)> {
    let numbered = numbered_program_line(source)?;
    let mut validator = Program::new();
    validator.insert_line(numbered.1).ok()?;
    Some(numbered)
}

fn update_program_line_cache(
    lines: &mut Vec<String>,
    selected: &mut Option<usize>,
    source: &str,
) -> bool {
    let Some((number, canonical)) = validated_numbered_program_line(source) else {
        return !lines.is_empty();
    };
    match lines.binary_search_by_key(&number, |line| {
        numbered_program_line(line)
            .map(|(line_number, _)| line_number)
            .unwrap_or(u64::MAX)
    }) {
        Ok(position) if program_line_has_body(canonical) => {
            lines[position] = canonical.to_string();
            *selected = Some(position);
        }
        Ok(position) => {
            lines.remove(position);
            *selected = position.checked_sub(1);
        }
        Err(position) if program_line_has_body(canonical) => {
            lines.insert(position, canonical.to_string());
            *selected = Some(position);
        }
        Err(_) => {}
    }
    !lines.is_empty()
}

fn program_listing_after_last_list(lines: &VecDeque<String>) -> Option<Vec<String>> {
    let start = lines.iter().rposition(|line| {
        let command = line.trim();
        command == "LIST" || command.starts_with("LIST ")
    })?;
    Some(
        lines
            .iter()
            .skip(start + 1)
            .filter_map(|line| numbered_program_line(line).map(|(_, source)| source.to_string()))
            .collect(),
    )
}

fn remember_history(history: &mut Vec<String>, line: &str) {
    if line.trim().is_empty() || history.last().is_some_and(|latest| latest == line) {
        return;
    }
    history.push(line.to_string());
    if history.len() > MAX_HISTORY_LINES {
        history.remove(0);
    }
}

fn wrap_completed_line(text: &str, columns: usize) -> Vec<String> {
    let columns = columns.max(1);
    let characters = text.chars().collect::<Vec<_>>();
    if characters.is_empty() {
        return vec![String::new()];
    }
    characters
        .chunks(columns)
        .map(|chunk| chunk.iter().collect::<String>())
        .collect()
}

fn cursor_line_count(text: &str, columns: usize) -> usize {
    text.chars().count() / columns.max(1) + 1
}

fn wrap_cursor_line(text: &str, columns: usize) -> Vec<String> {
    let columns = columns.max(1);
    let mut result = wrap_completed_line(text, columns);
    if !text.is_empty() && text.chars().count() % columns == 0 {
        result.push(String::new());
    }
    result
}

fn wrap_completed_row(row: &TerminalRow, columns: usize) -> Vec<TerminalRow> {
    let columns = columns.max(1);
    let characters = row.text.chars().collect::<Vec<_>>();
    if characters.is_empty() {
        return vec![TerminalRow::default()];
    }
    characters
        .chunks(columns)
        .enumerate()
        .map(|(index, chunk)| {
            let start = index * columns;
            TerminalRow {
                text: chunk.iter().collect(),
                colors: (start..start + chunk.len())
                    .map(|position| row.colors.get(position).copied().unwrap_or_default())
                    .collect(),
            }
        })
        .collect()
}

fn wrap_cursor_row(row: &TerminalRow, columns: usize) -> Vec<TerminalRow> {
    let columns = columns.max(1);
    let mut result = wrap_completed_row(row, columns);
    if !row.text.is_empty() && row.text.chars().count() % columns == 0 {
        result.push(TerminalRow::default());
    }
    result
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RasterViewport {
    x: i32,
    y: i32,
    width: u32,
    height: u32,
}

fn raster_viewport(
    region_width: u32,
    region_height: u32,
    raster_width: u32,
    raster_height: u32,
    mode: GraphicsScaleMode,
) -> Option<RasterViewport> {
    if region_width == 0 || region_height == 0 || raster_width == 0 || raster_height == 0 {
        return None;
    }
    if mode == GraphicsScaleMode::Stretch {
        return Some(RasterViewport {
            x: 0,
            y: 0,
            width: region_width,
            height: region_height,
        });
    }

    let (width, height) = if u64::from(region_width) * u64::from(raster_height)
        <= u64::from(region_height) * u64::from(raster_width)
    {
        let height = (u64::from(region_width) * u64::from(raster_height) / u64::from(raster_width))
            .max(1) as u32;
        (region_width, height.min(region_height))
    } else {
        let width = (u64::from(region_height) * u64::from(raster_width) / u64::from(raster_height))
            .max(1) as u32;
        (width.min(region_width), region_height)
    };
    Some(RasterViewport {
        x: i32::try_from((region_width - width) / 2).unwrap_or(i32::MAX),
        y: i32::try_from((region_height - height) / 2).unwrap_or(i32::MAX),
        width,
        height,
    })
}

fn map_pointer_to_raster(
    x: i32,
    y: i32,
    viewport: RasterViewport,
    raster_width: u32,
    raster_height: u32,
) -> Option<(i64, i64)> {
    let relative_x = x.checked_sub(viewport.x)?;
    let relative_y = y.checked_sub(viewport.y)?;
    if relative_x < 0
        || relative_y < 0
        || relative_x >= i32::try_from(viewport.width).ok()?
        || relative_y >= i32::try_from(viewport.height).ok()?
        || raster_width == 0
        || raster_height == 0
    {
        return None;
    }
    let map_axis = |position: i32, viewport_extent: u32, logical_extent: u32| {
        if viewport_extent <= 1 || logical_extent <= 1 {
            0
        } else {
            (u64::try_from(position).unwrap_or(0) * u64::from(logical_extent - 1)
                / u64::from(viewport_extent - 1)) as i64
        }
    };
    Some((
        map_axis(relative_x, viewport.width, raster_width),
        map_axis(relative_y, viewport.height, raster_height),
    ))
}

fn help_dialog_capacity(width: u32, height: u32) -> (usize, usize) {
    const INSET: i32 = 12;
    const BAR_HEIGHT: i32 = FONT_HEIGHT + 8;
    let dialog_width = (width as i32 - INSET * 2).max(FONT_WIDTH * 20);
    let dialog_height = (height as i32 - INSET * 2).max(FONT_HEIGHT * 5);
    let columns = ((dialog_width - MARGIN_X * 2) / FONT_WIDTH).max(20) as usize;
    let rows = ((dialog_height - BAR_HEIGHT * 2 - MARGIN_Y * 2) / FONT_HEIGHT).max(1) as usize;
    (columns, rows)
}

fn handle_help_dialog_key(
    viewer: &mut HelpViewer,
    keysym: KeySym,
    typed_text: Option<&str>,
    rows: usize,
) {
    if viewer.is_searching() {
        match keysym {
            XK_F1 => viewer.close(),
            XK_ESCAPE => viewer.cancel_search(),
            XK_RETURN => {
                viewer.finish_search();
            }
            XK_BACKSPACE | XK_DELETE => viewer.backspace_search(),
            _ => {
                if let Some(text) = typed_text {
                    viewer.push_search_text(text);
                }
            }
        }
        return;
    }

    match keysym {
        XK_F1 | XK_ESCAPE => viewer.close(),
        XK_UP => viewer.line_up(),
        XK_DOWN => viewer.line_down(rows),
        XK_PAGE_UP => viewer.page_up(rows.saturating_sub(1).max(1)),
        XK_PAGE_DOWN => viewer.page_down(rows.saturating_sub(1).max(1)),
        XK_HOME => viewer.first_page(),
        XK_END => viewer.last_page(rows),
        XK_F3 => {
            viewer.find_next();
        }
        _ if typed_text == Some("/") => viewer.begin_search(),
        _ => {}
    }
}

fn draw_help_dialog(
    display: *mut Display,
    window: Window,
    gc: GC,
    reverse_gc: GC,
    width: u32,
    height: u32,
    viewer: &mut HelpViewer,
) {
    const INSET: i32 = 12;
    const BAR_HEIGHT: i32 = FONT_HEIGHT + 8;
    let dialog_x = INSET.min(width.saturating_sub(1) as i32);
    let dialog_y = INSET.min(height.saturating_sub(1) as i32);
    let dialog_width = width.saturating_sub((dialog_x * 2).max(0) as u32).max(1);
    let dialog_height = height.saturating_sub((dialog_y * 2).max(0) as u32).max(1);
    let footer_y = dialog_y + dialog_height as i32 - BAR_HEIGHT;
    let content_y = dialog_y + BAR_HEIGHT + MARGIN_Y;
    let (columns, rows) = help_dialog_capacity(width, height);
    viewer.ensure_width(columns);

    unsafe {
        XFillRectangle(display, window, reverse_gc, 0, 0, width, height);
        XFillRectangle(
            display,
            window,
            gc,
            dialog_x,
            dialog_y,
            dialog_width,
            BAR_HEIGHT.max(1) as u32,
        );
        XFillRectangle(
            display,
            window,
            gc,
            dialog_x,
            footer_y,
            dialog_width,
            BAR_HEIGHT.max(1) as u32,
        );
        let right = dialog_x + dialog_width as i32 - 1;
        let bottom = dialog_y + dialog_height as i32 - 1;
        XDrawLine(display, window, gc, dialog_x, dialog_y, right, dialog_y);
        XDrawLine(display, window, gc, right, dialog_y, right, bottom);
        XDrawLine(display, window, gc, right, bottom, dialog_x, bottom);
        XDrawLine(display, window, gc, dialog_x, bottom, dialog_x, dialog_y);
    }

    let title = viewer.title(rows).chars().take(columns).collect::<String>();
    draw_ascii(
        display,
        window,
        reverse_gc,
        dialog_x + MARGIN_X,
        dialog_y + FONT_ASCENT + 4,
        &title,
    );
    for (row, line) in viewer.visible_lines(rows).iter().enumerate() {
        draw_ascii(
            display,
            window,
            gc,
            dialog_x + MARGIN_X,
            content_y + FONT_ASCENT + row as i32 * FONT_HEIGHT,
            line,
        );
    }
    let footer = viewer.footer().chars().take(columns).collect::<String>();
    draw_ascii(
        display,
        window,
        reverse_gc,
        dialog_x + MARGIN_X,
        footer_y + FONT_ASCENT + 4,
        &footer,
    );
}

fn draw_ascii(display: *mut Display, window: Window, gc: GC, x: i32, y: i32, text: &str) {
    let bytes = text
        .chars()
        .map(|character| {
            if character.is_ascii() && !character.is_control() {
                character as u8
            } else {
                b'?'
            }
        })
        .collect::<Vec<_>>();
    for (chunk_index, chunk) in bytes.chunks(255).enumerate() {
        unsafe {
            XDrawString(
                display,
                window,
                gc,
                x + (chunk_index * 255) as i32 * FONT_WIDTH,
                y,
                chunk.as_ptr().cast::<c_char>(),
                chunk.len() as c_int,
            );
        }
    }
}

fn draw_terminal_row(
    display: *mut Display,
    window: Window,
    gc: GC,
    x: i32,
    y: i32,
    row: &TerminalRow,
) {
    let characters = row.text.chars().collect::<Vec<_>>();
    let mut start = 0usize;
    while start < characters.len() {
        let colors = row.colors.get(start).copied().unwrap_or_default();
        let mut end = start + 1;
        while end < characters.len() && row.colors.get(end).copied().unwrap_or_default() == colors {
            end += 1;
        }
        let text = characters[start..end].iter().collect::<String>();
        let span_x = x + start as i32 * FONT_WIDTH;
        unsafe {
            XSetForeground(display, gc, colors.background);
            XFillRectangle(
                display,
                window,
                gc,
                span_x,
                y - FONT_ASCENT,
                ((end - start) as i32 * FONT_WIDTH) as u32,
                FONT_HEIGHT as u32,
            );
            XSetForeground(display, gc, colors.foreground);
        }
        draw_ascii(display, window, gc, span_x, y, &text);
        start = end;
    }
}

unsafe fn fill_ximage(
    image: *mut XImage,
    raster: &RasterImage,
    width: u32,
    height: u32,
    source_columns: &[usize],
    source_rows: &[usize],
) -> Result<(), Error> {
    let bits_per_pixel = (*image).bits_per_pixel;
    if !matches!(bits_per_pixel, 16 | 24 | 32) {
        return Err(Error::Io(format!(
            "unsupported X11 graphics screen pixel depth: {bits_per_pixel} bits"
        )));
    }
    let bytes_per_pixel = (bits_per_pixel / 8) as usize;
    let bytes_per_line = usize::try_from((*image).bytes_per_line)
        .map_err(|_| Error::Io("invalid X11 graphics screen stride".into()))?;
    let data = (*image).data.cast::<u8>();
    if data.is_null() {
        return Err(Error::Io("X11 graphics screen has no image buffer".into()));
    }

    if bits_per_pixel == 32
        && (*image).byte_order == LSB_FIRST
        && (*image).red_mask == 0x00ff_0000
        && (*image).green_mask == 0x0000_ff00
        && (*image).blue_mask == 0x0000_00ff
    {
        let output_length = bytes_per_line
            .checked_mul(height as usize)
            .ok_or_else(|| Error::Io("X11 graphics screen byte size overflow".into()))?;
        let output = std::slice::from_raw_parts_mut(data, output_length);
        fill_scaled_bgrx(
            output,
            bytes_per_line,
            raster,
            width as usize,
            source_columns,
            source_rows,
        );
        return Ok(());
    }

    let red_lut: [c_ulong; 256] =
        std::array::from_fn(|value| component_to_mask(value as u8, (*image).red_mask));
    let green_lut: [c_ulong; 256] =
        std::array::from_fn(|value| component_to_mask(value as u8, (*image).green_mask));
    let blue_lut: [c_ulong; 256] =
        std::array::from_fn(|value| component_to_mask(value as u8, (*image).blue_mask));

    for (destination_y, &source_row) in source_rows.iter().enumerate() {
        for (destination_x, &source_column) in source_columns.iter().enumerate() {
            let source_index = source_row + source_column;
            let red = raster.rgb[source_index];
            let green = raster.rgb[source_index + 1];
            let blue = raster.rgb[source_index + 2];
            let pixel = red_lut[red as usize] | green_lut[green as usize] | blue_lut[blue as usize];
            let offset = destination_y * bytes_per_line + destination_x * bytes_per_pixel;
            for byte in 0..bytes_per_pixel {
                let shift = if (*image).byte_order == LSB_FIRST {
                    byte * 8
                } else {
                    (bytes_per_pixel - 1 - byte) * 8
                };
                *data.add(offset + byte) = ((pixel >> shift) & 0xff) as u8;
            }
        }
    }
    Ok(())
}

fn fill_scaled_bgrx(
    output: &mut [u8],
    bytes_per_line: usize,
    raster: &RasterImage,
    width: usize,
    source_columns: &[usize],
    source_rows: &[usize],
) {
    for (destination_y, &source_row) in source_rows.iter().enumerate() {
        let output_row =
            &mut output[destination_y * bytes_per_line..destination_y * bytes_per_line + width * 4];
        for (pixel, &source_column) in output_row.chunks_exact_mut(4).zip(source_columns) {
            let source = source_row + source_column;
            pixel[0] = raster.rgb[source + 2];
            pixel[1] = raster.rgb[source + 1];
            pixel[2] = raster.rgb[source];
            pixel[3] = 0;
        }
    }
}

fn component_to_mask(component: u8, mask: c_ulong) -> c_ulong {
    if mask == 0 {
        return 0;
    }
    let shift = mask.trailing_zeros();
    let bits = mask.count_ones();
    let maximum = if bits >= c_ulong::BITS {
        c_ulong::MAX
    } else {
        ((1 as c_ulong) << bits) - 1
    };
    (((component as c_ulong * maximum + 127) / 255) << shift) & mask
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub(crate) struct X11Colors {
    pub screen: c_ulong,
    pub text: c_ulong,
}

pub(crate) struct X11ColorCache {
    colormap: Colormap,
    colors: HashMap<String, XColor>,
    least_recently_used: VecDeque<String>,
}

const MAX_X11_COLOR_CACHE_ENTRIES: usize = 64;

impl X11ColorCache {
    fn new(display: *mut Display, screen_number: c_int) -> Self {
        Self {
            colormap: unsafe { XDefaultColormap(display, screen_number) },
            colors: HashMap::new(),
            least_recently_used: VecDeque::new(),
        }
    }

    fn colors_for_prefs(
        &mut self,
        display: *mut Display,
        prefs: &ColorPrefs,
    ) -> Result<X11Colors, Error> {
        let screen = self.color(display, &prefs.screen_color)?.pixel;
        let text = self.color(display, &prefs.text_color)?.pixel;
        Ok(X11Colors { screen, text })
    }

    pub(crate) fn basic_text_colors(
        &mut self,
        display: *mut Display,
        foreground: i64,
        background: i64,
    ) -> Result<X11Colors, Error> {
        let screen_color = basic_color_hex(background)?;
        let text_color = basic_color_hex(foreground)?;
        let screen = self.color(display, &screen_color)?.pixel;
        let text = self.color(display, &text_color)?.pixel;
        Ok(X11Colors { screen, text })
    }

    fn color(&mut self, display: *mut Display, value: &str) -> Result<XColor, Error> {
        let value = ColorPrefs::normalize_hex(value)?;
        if let Some(color) = self.colors.get(&value).copied() {
            self.least_recently_used.retain(|cached| cached != &value);
            self.least_recently_used.push_back(value);
            return Ok(color);
        }
        if self.colors.len() >= MAX_X11_COLOR_CACHE_ENTRIES {
            if let Some(oldest) = self.least_recently_used.pop_front() {
                if let Some(color) = self.colors.remove(&oldest) {
                    let mut pixel = color.pixel;
                    unsafe {
                        XFreeColors(display, self.colormap, &mut pixel, 1, 0);
                    }
                }
            }
        }
        let color = allocate_x11_color(display, self.colormap, &value)?;
        self.colors.insert(value.clone(), color);
        self.least_recently_used.push_back(value);
        Ok(color)
    }

    unsafe fn free(&mut self, display: *mut Display) {
        let mut pixels = self
            .colors
            .drain()
            .map(|(_, color)| color.pixel)
            .collect::<Vec<_>>();
        self.least_recently_used.clear();
        for chunk in pixels.chunks_mut(c_int::MAX as usize) {
            XFreeColors(
                display,
                self.colormap,
                chunk.as_mut_ptr(),
                chunk.len() as c_int,
                0,
            );
        }
    }
}

fn basic_color_hex(color: i64) -> Result<String, Error> {
    const PALETTE: [&str; 16] = [
        "#000000", "#0000aa", "#00aa00", "#00aaaa", "#aa0000", "#aa00aa", "#aa5500", "#aaaaaa",
        "#555555", "#5555ff", "#00ff00", "#55ffff", "#ff5555", "#ff55ff", "#ffff55", "#ffffff",
    ];
    match usize::try_from(color)
        .ok()
        .and_then(|index| PALETTE.get(index))
    {
        Some(color) => Ok((*color).to_string()),
        None if (0..=0xff_ffff).contains(&color) => Ok(format!("#{color:06x}")),
        None => Err(Error::IllegalQuantity),
    }
}

fn allocate_x11_color(
    display: *mut Display,
    colormap: Colormap,
    value: &str,
) -> Result<XColor, Error> {
    let value = ColorPrefs::normalize_hex(value)?;
    let value = CString::new(value).map_err(|_| Error::syntax("invalid X11 color"))?;
    let mut color = XColor::default();
    if unsafe { XParseColor(display, colormap, value.as_ptr(), &mut color) } == 0 {
        return Err(Error::Io("X11 cannot parse the requested color".into()));
    }
    if unsafe { XAllocColor(display, colormap, &mut color) } == 0 {
        return Err(Error::Io(
            "X11 cannot allocate the requested color in the default colormap".into(),
        ));
    }
    Ok(color)
}

fn intern_atom(display: *mut Display, name: &str) -> Result<Atom, Error> {
    let name = CString::new(name).map_err(|_| Error::Io("invalid X11 atom name".into()))?;
    let atom = unsafe { XInternAtom(display, name.as_ptr(), 0) };
    if atom == 0 {
        Err(Error::Io("cannot create X11 atom".into()))
    } else {
        Ok(atom)
    }
}

pub(crate) fn activate_window(display: *mut Display, root: Window, window: Window) {
    unsafe {
        // Mapping is harmless for a visible window and restores one that the
        // window manager iconized by unmapping it.
        XMapWindow(display, window);
        XRaiseWindow(display, window);
    }

    // Ask the window manager to transfer focus. Direct XSetInputFocus calls
    // can fail with BadMatch while a restored window is not yet viewable.
    if let Ok(net_active_window) = intern_atom(display, "_NET_ACTIVE_WINDOW") {
        let client = XClientMessageEvent {
            type_: CLIENT_MESSAGE,
            serial: 0,
            send_event: 1,
            display,
            window,
            message_type: net_active_window,
            format: 32,
            data: XClientMessageData { l: [2, 0, 0, 0, 0] },
        };
        let mut event = XEvent { xclient: client };
        unsafe {
            XSendEvent(
                display,
                root,
                0,
                SUBSTRUCTURE_NOTIFY_MASK | SUBSTRUCTURE_REDIRECT_MASK,
                &mut event,
            );
        }
    }
    unsafe {
        XFlush(display);
    }
}

pub(crate) fn set_window_fullscreen(
    display: *mut Display,
    root: Window,
    window: Window,
    enabled: bool,
) -> Result<(), Error> {
    let net_wm_state = intern_atom(display, "_NET_WM_STATE")?;
    let fullscreen = intern_atom(display, "_NET_WM_STATE_FULLSCREEN")?;
    let client = XClientMessageEvent {
        type_: CLIENT_MESSAGE,
        serial: 0,
        send_event: 1,
        display,
        window,
        message_type: net_wm_state,
        format: 32,
        // EWMH: REMOVE=0, ADD=1, second property unused, source=application.
        data: XClientMessageData {
            l: [if enabled { 1 } else { 0 }, fullscreen as c_long, 0, 1, 0],
        },
    };
    let mut event = XEvent { xclient: client };
    let sent = unsafe {
        let sent = XSendEvent(
            display,
            root,
            0,
            SUBSTRUCTURE_NOTIFY_MASK | SUBSTRUCTURE_REDIRECT_MASK,
            &mut event,
        );
        XFlush(display);
        sent
    };
    if sent == 0 {
        return Err(Error::Io(
            "X11 window manager rejected the fullscreen request".into(),
        ));
    }
    Ok(())
}

pub(crate) fn set_window_resizable(
    display: *mut Display,
    window: Window,
    enabled: bool,
    width: u32,
    height: u32,
) {
    const P_MIN_SIZE: c_long = 1 << 4;
    const P_MAX_SIZE: c_long = 1 << 5;
    let mut hints = XSizeHints::default();
    if !enabled {
        hints.flags = P_MIN_SIZE | P_MAX_SIZE;
        hints.min_width = width as c_int;
        hints.max_width = width as c_int;
        hints.min_height = height as c_int;
        hints.max_height = height as c_int;
    }
    unsafe {
        XSetWMNormalHints(display, window, &mut hints);
        XFlush(display);
    }
}

pub(crate) fn set_window_pointer_visible(display: *mut Display, window: Window, visible: bool) {
    unsafe {
        if visible {
            XUndefineCursor(display, window);
        } else {
            let data = [0_u8];
            let bitmap = XCreateBitmapFromData(display, window, data.as_ptr().cast(), 1, 1);
            if bitmap != 0 {
                let mut color = XColor::default();
                let cursor =
                    XCreatePixmapCursor(display, bitmap, bitmap, &mut color, &mut color, 0, 0);
                if cursor != 0 {
                    XDefineCursor(display, window, cursor);
                    XFreeCursor(display, cursor);
                }
                XFreePixmap(display, bitmap);
            }
        }
        XFlush(display);
    }
}

#[repr(C)]
pub(crate) struct Display {
    _private: [u8; 0],
}

#[repr(C)]
#[derive(Debug, Default, Clone, Copy)]
pub(crate) struct XColor {
    pixel: c_ulong,
    red: u16,
    green: u16,
    blue: u16,
    flags: u8,
    pad: u8,
}

#[repr(C)]
struct Visual {
    _private: [u8; 0],
}

#[repr(C)]
struct XImage {
    width: c_int,
    height: c_int,
    xoffset: c_int,
    format: c_int,
    data: *mut c_char,
    byte_order: c_int,
    bitmap_unit: c_int,
    bitmap_bit_order: c_int,
    bitmap_pad: c_int,
    depth: c_int,
    bytes_per_line: c_int,
    bits_per_pixel: c_int,
    red_mask: c_ulong,
    green_mask: c_ulong,
    blue_mask: c_ulong,
    obdata: *mut c_char,
    funcs: [usize; 6],
}

#[repr(C)]
#[derive(Default)]
struct XSetWindowAttributes {
    background_pixmap: c_ulong,
    background_pixel: c_ulong,
    border_pixmap: c_ulong,
    border_pixel: c_ulong,
    bit_gravity: c_int,
    win_gravity: c_int,
    backing_store: c_int,
    backing_planes: c_ulong,
    backing_pixel: c_ulong,
    save_under: c_int,
    event_mask: c_long,
    do_not_propagate_mask: c_long,
    override_redirect: c_int,
    colormap: c_ulong,
    cursor: c_ulong,
}

#[repr(C)]
#[derive(Default)]
struct XWMHints {
    flags: c_long,
    input: c_int,
    initial_state: c_int,
    icon_pixmap: c_ulong,
    icon_window: Window,
    icon_x: c_int,
    icon_y: c_int,
    icon_mask: c_ulong,
    window_group: c_ulong,
}

#[repr(C)]
#[derive(Default)]
struct XAspect {
    x: c_int,
    y: c_int,
}

#[repr(C)]
#[derive(Default)]
struct XSizeHints {
    flags: c_long,
    x: c_int,
    y: c_int,
    width: c_int,
    height: c_int,
    min_width: c_int,
    min_height: c_int,
    max_width: c_int,
    max_height: c_int,
    width_inc: c_int,
    height_inc: c_int,
    min_aspect: XAspect,
    max_aspect: XAspect,
    base_width: c_int,
    base_height: c_int,
    win_gravity: c_int,
}

pub(crate) type Window = c_ulong;
pub(crate) type Drawable = c_ulong;
pub(crate) type Font = c_ulong;
pub(crate) type Atom = c_ulong;
pub(crate) type Colormap = c_ulong;
pub(crate) type KeySym = c_ulong;
pub(crate) type Time = c_ulong;
pub(crate) type GC = *mut c_void;
type Pixmap = c_ulong;
type Cursor = c_ulong;

#[repr(C)]
#[derive(Clone, Copy)]
struct XAnyEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    window: Window,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub(crate) struct XKeyEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    window: Window,
    root: Window,
    subwindow: Window,
    time: Time,
    x: c_int,
    y: c_int,
    x_root: c_int,
    y_root: c_int,
    state: c_uint,
    keycode: c_uint,
    same_screen: c_int,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub(crate) struct XButtonEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    window: Window,
    root: Window,
    subwindow: Window,
    time: Time,
    x: c_int,
    y: c_int,
    x_root: c_int,
    y_root: c_int,
    state: c_uint,
    button: c_uint,
    same_screen: c_int,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct XMotionEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    window: Window,
    root: Window,
    subwindow: Window,
    time: Time,
    x: c_int,
    y: c_int,
    x_root: c_int,
    y_root: c_int,
    state: c_uint,
    is_hint: c_char,
    same_screen: c_int,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub(crate) struct XConfigureEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    event: Window,
    window: Window,
    x: c_int,
    y: c_int,
    width: c_int,
    height: c_int,
    border_width: c_int,
    above: Window,
    override_redirect: c_int,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct XSelectionEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    requestor: Window,
    selection: Atom,
    target: Atom,
    property: Atom,
    time: Time,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub(crate) struct XSelectionRequestEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    owner: Window,
    requestor: Window,
    selection: Atom,
    target: Atom,
    property: Atom,
    time: Time,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub(crate) struct XSelectionClearEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    window: Window,
    selection: Atom,
    time: Time,
}

#[repr(C)]
#[derive(Clone, Copy)]
union XClientMessageData {
    b: [c_char; 20],
    s: [i16; 10],
    l: [c_long; 5],
}

#[repr(C)]
#[derive(Clone, Copy)]
struct XClientMessageEvent {
    type_: c_int,
    serial: c_ulong,
    send_event: c_int,
    display: *mut Display,
    window: Window,
    message_type: Atom,
    format: c_int,
    data: XClientMessageData,
}

#[repr(C)]
union XEvent {
    type_: c_int,
    xany: XAnyEvent,
    xkey: XKeyEvent,
    xbutton: XButtonEvent,
    xmotion: XMotionEvent,
    xconfigure: XConfigureEvent,
    xselection: XSelectionEvent,
    xselectionrequest: XSelectionRequestEvent,
    xselectionclear: XSelectionClearEvent,
    xclient: XClientMessageEvent,
    pad: [c_long; 24],
}

#[link(name = "X11")]
extern "C" {
    fn XOpenDisplay(display_name: *const c_char) -> *mut Display;
    fn XCloseDisplay(display: *mut Display) -> c_int;
    pub(crate) fn XDefaultScreen(display: *mut Display) -> c_int;
    fn XDefaultVisual(display: *mut Display, screen_number: c_int) -> *mut Visual;
    fn XDefaultDepth(display: *mut Display, screen_number: c_int) -> c_int;
    fn XRootWindow(display: *mut Display, screen_number: c_int) -> Window;
    fn XDisplayWidth(display: *mut Display, screen_number: c_int) -> c_int;
    fn XDisplayHeight(display: *mut Display, screen_number: c_int) -> c_int;
    pub(crate) fn XDefaultColormap(display: *mut Display, screen_number: c_int) -> Colormap;
    pub(crate) fn XParseColor(
        display: *mut Display,
        colormap: Colormap,
        color_string: *const c_char,
        exact_def_return: *mut XColor,
    ) -> c_int;
    pub(crate) fn XAllocColor(
        display: *mut Display,
        colormap: Colormap,
        screen_in_out: *mut XColor,
    ) -> c_int;
    fn XFreeColors(
        display: *mut Display,
        colormap: Colormap,
        pixels: *mut c_ulong,
        npixels: c_int,
        planes: c_ulong,
    ) -> c_int;
    pub(crate) fn XCreateSimpleWindow(
        display: *mut Display,
        parent: Window,
        x: c_int,
        y: c_int,
        width: c_uint,
        height: c_uint,
        border_width: c_uint,
        border: c_ulong,
        background: c_ulong,
    ) -> Window;
    fn XChangeWindowAttributes(
        display: *mut Display,
        window: Window,
        value_mask: c_ulong,
        attributes: *mut XSetWindowAttributes,
    ) -> c_int;
    fn XChangeProperty(
        display: *mut Display,
        window: Window,
        property: Atom,
        property_type: Atom,
        format: c_int,
        mode: c_int,
        data: *const u8,
        element_count: c_int,
    ) -> c_int;
    pub(crate) fn XDestroyWindow(display: *mut Display, window: Window) -> c_int;
    pub(crate) fn XStoreName(display: *mut Display, window: Window, name: *const c_char) -> c_int;
    fn XInternAtom(display: *mut Display, atom_name: *const c_char, only_if_exists: c_int) -> Atom;
    pub(crate) fn XSetWMProtocols(
        display: *mut Display,
        window: Window,
        protocols: *mut Atom,
        count: c_int,
    ) -> c_int;
    fn XSetWMHints(display: *mut Display, window: Window, wm_hints: *mut XWMHints) -> c_int;
    fn XSetWMNormalHints(display: *mut Display, window: Window, hints: *mut XSizeHints) -> c_int;
    fn XCreateBitmapFromData(
        display: *mut Display,
        drawable: Drawable,
        data: *const c_char,
        width: c_uint,
        height: c_uint,
    ) -> Pixmap;
    fn XCreatePixmapCursor(
        display: *mut Display,
        source: Pixmap,
        mask: Pixmap,
        foreground: *mut XColor,
        background: *mut XColor,
        x: c_uint,
        y: c_uint,
    ) -> Cursor;
    fn XDefineCursor(display: *mut Display, window: Window, cursor: Cursor) -> c_int;
    fn XUndefineCursor(display: *mut Display, window: Window) -> c_int;
    fn XFreeCursor(display: *mut Display, cursor: Cursor) -> c_int;
    fn XFreePixmap(display: *mut Display, pixmap: Pixmap) -> c_int;
    pub(crate) fn XSelectInput(display: *mut Display, window: Window, event_mask: c_long) -> c_int;
    pub(crate) fn XMapWindow(display: *mut Display, window: Window) -> c_int;
    pub(crate) fn XCreateGC(
        display: *mut Display,
        drawable: Drawable,
        value_mask: c_ulong,
        values: *mut c_void,
    ) -> GC;
    pub(crate) fn XFreeGC(display: *mut Display, gc: GC) -> c_int;
    pub(crate) fn XSetForeground(display: *mut Display, gc: GC, foreground: c_ulong) -> c_int;
    pub(crate) fn XSetBackground(display: *mut Display, gc: GC, background: c_ulong) -> c_int;
    pub(crate) fn XSetWindowBackground(
        display: *mut Display,
        window: Window,
        background_pixel: c_ulong,
    ) -> c_int;
    fn XLoadFont(display: *mut Display, name: *const c_char) -> Font;
    fn XUnloadFont(display: *mut Display, font: Font) -> c_int;
    pub(crate) fn XSetFont(display: *mut Display, gc: GC, font: Font) -> c_int;
    fn XCreateImage(
        display: *mut Display,
        visual: *mut Visual,
        depth: c_uint,
        format: c_int,
        offset: c_int,
        data: *mut c_char,
        width: c_uint,
        height: c_uint,
        bitmap_pad: c_int,
        bytes_per_line: c_int,
    ) -> *mut XImage;
    fn XDestroyImage(image: *mut XImage) -> c_int;
    fn XPutImage(
        display: *mut Display,
        drawable: Drawable,
        gc: GC,
        image: *mut XImage,
        src_x: c_int,
        src_y: c_int,
        dest_x: c_int,
        dest_y: c_int,
        width: c_uint,
        height: c_uint,
    ) -> c_int;
    fn XDrawString(
        display: *mut Display,
        drawable: Drawable,
        gc: GC,
        x: c_int,
        y: c_int,
        string: *const c_char,
        length: c_int,
    ) -> c_int;
    fn XDrawLine(
        display: *mut Display,
        drawable: Drawable,
        gc: GC,
        x1: c_int,
        y1: c_int,
        x2: c_int,
        y2: c_int,
    ) -> c_int;
    pub(crate) fn XFillRectangle(
        display: *mut Display,
        drawable: Drawable,
        gc: GC,
        x: c_int,
        y: c_int,
        width: c_uint,
        height: c_uint,
    ) -> c_int;
    fn XConvertSelection(
        display: *mut Display,
        selection: Atom,
        target: Atom,
        property: Atom,
        requestor: Window,
        time: Time,
    ) -> c_int;
    pub(crate) fn XSetSelectionOwner(
        display: *mut Display,
        selection: Atom,
        owner: Window,
        time: Time,
    ) -> c_int;
    fn XSendEvent(
        display: *mut Display,
        window: Window,
        propagate: c_int,
        event_mask: c_long,
        event_send: *mut XEvent,
    ) -> c_int;
    fn XGetWindowProperty(
        display: *mut Display,
        window: Window,
        property: Atom,
        long_offset: c_long,
        long_length: c_long,
        delete: c_int,
        requested_type: Atom,
        actual_type_return: *mut Atom,
        actual_format_return: *mut c_int,
        item_count_return: *mut c_ulong,
        bytes_after_return: *mut c_ulong,
        property_return: *mut *mut u8,
    ) -> c_int;
    fn XDeleteProperty(display: *mut Display, window: Window, property: Atom) -> c_int;
    fn XFree(data: *mut c_void) -> c_int;
    fn calloc(count: usize, size: usize) -> *mut c_void;
    pub(crate) fn XLookupString(
        event_struct: *mut XKeyEvent,
        buffer_return: *mut c_char,
        bytes_buffer: c_int,
        keysym_return: *mut KeySym,
        status_in_out: *mut c_void,
    ) -> c_int;
    fn XPending(display: *mut Display) -> c_int;
    fn XNextEvent(display: *mut Display, event_return: *mut XEvent) -> c_int;
    pub(crate) fn XFlush(display: *mut Display) -> c_int;
    pub(crate) fn XResizeWindow(
        display: *mut Display,
        window: Window,
        width: c_uint,
        height: c_uint,
    ) -> c_int;
    pub(crate) fn XRaiseWindow(display: *mut Display, window: Window) -> c_int;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn text_selection_extracts_forward_and_reverse_ranges() {
        let rows = ["READY.", "αβγ", "PRINT 42"];
        let forward = selected_text(rows, (0, 2), (2, 4));
        let reverse = selected_text(rows, (2, 4), (0, 2));
        assert_eq!(forward, "ADY.\nαβγ\nPRINT");
        assert_eq!(reverse, forward);
    }

    #[test]
    fn text_selection_span_clamps_to_rendered_characters() {
        assert_eq!(selection_span(3, 6, (2, 4), (4, 1)), Some((0, 6)));
        assert_eq!(selection_span(2, 3, (2, 9), (4, 1)), None);
        assert_eq!(selection_span(4, 3, (2, 4), (4, 9)), Some((0, 3)));
        assert_eq!(selection_span(5, 3, (2, 4), (4, 9)), None);
    }

    #[test]
    fn terminal_buffer_handles_stream_controls_and_bounds() {
        let mut buffer = TerminalBuffer::default();
        buffer.push_bytes(b"READY.\nPRINT 1\n1\nREADY.\n");
        assert_eq!(buffer.line_at(0), Some("READY."));
        assert_eq!(buffer.line_at(1), Some("PRINT 1"));
        assert_eq!(buffer.current, "");
        for index in 0..(MAX_SCROLLBACK_LINES + 10) {
            buffer.push_bytes(format!("{index}\n").as_bytes());
        }
        assert_eq!(buffer.lines.len(), MAX_SCROLLBACK_LINES);
    }

    #[test]
    fn terminal_buffer_positions_overwrites_and_scrolls_a_print_region() {
        let mut buffer = TerminalBuffer::default();
        buffer.set_cursor(2, 4, false);
        buffer.push_bytes(b"ABC");
        assert_eq!(buffer.line_at(1), Some("   ABC"));
        assert!(!buffer.cursor_visible);

        buffer.set_print_region(2, 3);
        buffer.set_cursor(2, 1, true);
        buffer.push_bytes(b"TOP");
        buffer.set_cursor(3, 1, true);
        buffer.push_bytes(b"BOTTOM\nNEXT");
        assert_eq!(buffer.line_at(1), Some("BOTTOM"));
        assert_eq!(buffer.line_at(2), Some("NEXT"));

        buffer.clear_print_region();
        assert_eq!(buffer.line_at(1), Some(""));
        assert_eq!(buffer.line_at(2), Some(""));
    }

    #[test]
    fn terminal_buffer_retains_colors_per_character() {
        let first = X11Colors {
            text: 0x11,
            screen: 0x22,
        };
        let second = X11Colors {
            text: 0x33,
            screen: 0x44,
        };
        let mut buffer = TerminalBuffer::with_colors(first);
        buffer.push_bytes(b"OLD");
        buffer.set_text_colors(second);
        buffer.push_bytes(b"NEW");

        assert_eq!(buffer.line_at(0), Some("OLDNEW"));
        assert_eq!(buffer.colors_at(0, 0), Some(first.into()));
        assert_eq!(buffer.colors_at(0, 2), Some(first.into()));
        assert_eq!(buffer.colors_at(0, 3), Some(second.into()));
        assert_eq!(buffer.colors_at(0, 5), Some(second.into()));
    }

    #[test]
    fn basic_text_colors_support_palette_and_packed_rgb_values() {
        assert_eq!(basic_color_hex(0).unwrap(), "#000000");
        assert_eq!(basic_color_hex(10).unwrap(), "#00ff00");
        assert_eq!(basic_color_hex(0x12_34_56).unwrap(), "#123456");
        assert_eq!(basic_color_hex(-1).unwrap_err(), Error::IllegalQuantity);
        assert_eq!(
            basic_color_hex(0x1_00_00_00).unwrap_err(),
            Error::IllegalQuantity
        );
    }

    #[test]
    fn list_output_becomes_canonical_editable_program_lines() {
        let lines = VecDeque::from([
            "READY.".to_string(),
            " LIST".to_string(),
            "10 PRINT \"ONE\"".to_string(),
            "20 GOTO 10".to_string(),
        ]);
        assert_eq!(
            program_listing_after_last_list(&lines),
            Some(vec![
                "10 PRINT \"ONE\"".to_string(),
                "20 GOTO 10".to_string()
            ])
        );
        assert_eq!(
            numbered_program_line("  20 GOTO 10"),
            Some((20, "20 GOTO 10"))
        );
        assert!(program_line_has_body("20 GOTO 10"));
        assert!(!program_line_has_body("20"));
        assert!(numbered_program_line("20PRINT").is_none());
        assert_eq!(
            validated_numbered_program_line("20 PRINT \"VALID\""),
            Some((20, "20 PRINT \"VALID\""))
        );
        assert_eq!(
            validated_numbered_program_line("65530 PRINT 1"),
            Some((65_530, "65530 PRINT 1"))
        );

        let mut cache = vec!["10 PRINT \"ONE\"".to_string(), "20 END".to_string()];
        let mut selected = None;
        assert!(update_program_line_cache(
            &mut cache,
            &mut selected,
            "20 PRINT \"TWO\""
        ));
        assert_eq!(cache[1], "20 PRINT \"TWO\"");
        assert!(update_program_line_cache(&mut cache, &mut selected, "20"));
        assert!(!update_program_line_cache(&mut cache, &mut selected, "10"));
        assert!(cache.is_empty());
    }

    #[test]
    fn latest_list_replaces_an_older_listing_cache() {
        let lines = VecDeque::from([
            " LIST".to_string(),
            "10 PRINT 1".to_string(),
            " RUN".to_string(),
            "1".to_string(),
            " LIST 20-".to_string(),
            "20 END".to_string(),
        ]);
        assert_eq!(
            program_listing_after_last_list(&lines),
            Some(vec!["20 END".to_string()])
        );
    }

    #[test]
    fn history_retains_commands_and_numbered_statements_without_adjacent_duplicates() {
        let mut history = Vec::new();
        remember_history(&mut history, "RUN");
        remember_history(&mut history, "10 PRINT \"HELLO\"");
        remember_history(&mut history, "10 PRINT \"HELLO\"");
        remember_history(&mut history, "   ");
        assert_eq!(
            history,
            vec!["RUN".to_string(), "10 PRINT \"HELLO\"".to_string()]
        );

        for number in 0..=MAX_HISTORY_LINES {
            remember_history(&mut history, &format!("PRINT {number}"));
        }
        assert_eq!(history.len(), MAX_HISTORY_LINES);
        assert_eq!(history.last().map(String::as_str), Some("PRINT 500"));
    }

    #[test]
    fn channel_reader_preserves_line_stream_order() {
        let (sender, receiver) = mpsc::channel();
        sender.send(b"10 PRINT 1\n".to_vec()).unwrap();
        sender.send(b"RUN\n".to_vec()).unwrap();
        drop(sender);
        let mut reader = ChannelReader::new(receiver);
        let mut text = String::new();
        reader.read_to_string(&mut text).unwrap();
        assert_eq!(text, "10 PRINT 1\nRUN\n");
    }

    #[test]
    fn character_cursor_conversion_handles_utf8() {
        let text = "AéZ";
        assert_eq!(byte_index_for_character(text, 0), 0);
        assert_eq!(byte_index_for_character(text, 1), 1);
        assert_eq!(byte_index_for_character(text, 2), 3);
        assert_eq!(byte_index_for_character(text, 3), 4);
    }

    #[test]
    fn visual_wrapping_preserves_completed_and_cursor_rows() {
        assert_eq!(wrap_completed_line("", 4), vec![""]);
        assert_eq!(wrap_completed_line("ABCDEFG", 4), vec!["ABCD", "EFG"]);
        assert_eq!(wrap_cursor_line("ABCD", 4), vec!["ABCD", ""]);
        assert_eq!(wrap_cursor_line("ABCDE", 4), vec!["ABCD", "E"]);
        assert_eq!(cursor_line_count("ABCD", 4), 2);
        assert_eq!(cursor_line_count("ABC", 4), 1);
    }
    #[test]
    fn integrated_raster_source_forces_artist_non_tiled_path_for_text() {
        let source =
            "canvas 1024 768 #000000\ntext 210 550 28 \"MODERNBASIC GRAPHICS\" fill=#ffffff\n";
        let prepared = prepare_integrated_raster_source(source);
        assert!(prepared.starts_with(source));
        assert!(prepared.contains(INTEGRATED_TEXT_RASTER_MARKER));
        assert!(prepared.contains("clip=__modernbasic_internal_raster_clip"));
    }

    #[test]
    fn integrated_raster_source_does_not_change_geometry_only_scenes() {
        let source = "canvas 1024 768 #000000\ncircle 400 300 100 fill=none stroke=#ffffff\n";
        assert_eq!(prepare_integrated_raster_source(source), source);
    }

    #[test]
    fn control_escape_is_the_run_stop_shortcut() {
        assert!(is_escape_interrupt(XK_ESCAPE, CONTROL_MASK));
        assert!(is_escape_interrupt(XK_ESCAPE, CONTROL_MASK | SHIFT_MASK));
        assert!(!is_escape_interrupt(XK_ESCAPE, 0));
        assert!(!is_escape_interrupt(XK_RETURN, CONTROL_MASK));
    }

    #[test]
    fn control_escape_prefers_the_selected_running_task_then_any_running_task() {
        let tasks = vec![
            program_window::ProgramTaskInfo {
                task_id: 1,
                filename: "idle.bas".to_string(),
                status: program_window::ProgramTaskStatus::Ready,
            },
            program_window::ProgramTaskInfo {
                task_id: 2,
                filename: "first.bas".to_string(),
                status: program_window::ProgramTaskStatus::Running,
            },
            program_window::ProgramTaskInfo {
                task_id: 3,
                filename: "selected.bas".to_string(),
                status: program_window::ProgramTaskStatus::Running,
            },
        ];
        assert_eq!(break_target_task(&tasks, Some(3)), Some(3));
        assert_eq!(break_target_task(&tasks, Some(1)), Some(2));
        assert_eq!(break_target_task(&tasks[..1], Some(1)), None);
    }

    #[test]
    fn continuous_graphics_updates_preserve_the_first_render_deadline() {
        let first = Instant::now();
        let later = first + SCENE_RENDER_DEBOUNCE + Duration::from_millis(1);
        let mut pending = None;
        latch_scene_render_start(&mut pending, first);
        latch_scene_render_start(&mut pending, later);
        assert_eq!(pending, Some(first));
    }

    #[test]
    fn pending_run_stop_completes_only_after_ready_returns() {
        assert!(!run_stop_has_completed(false, false));
        assert!(!run_stop_has_completed(false, true));
        assert!(!run_stop_has_completed(true, false));
        assert!(run_stop_has_completed(true, true));
    }

    #[test]
    fn vertical_arrows_separate_history_from_program_navigation() {
        assert_eq!(
            vertical_navigation(XK_UP, 0),
            Some(VerticalNavigation::HistoryPrevious)
        );
        assert_eq!(
            vertical_navigation(XK_DOWN, SHIFT_MASK),
            Some(VerticalNavigation::HistoryNext)
        );
        assert_eq!(vertical_navigation(XK_UP, CONTROL_MASK), None);
        assert_eq!(
            vertical_navigation(XK_DOWN, CONTROL_MASK | SHIFT_MASK),
            None
        );
        assert_eq!(vertical_navigation(XK_LEFT, CONTROL_MASK), None);
        assert_eq!(control_shortcut_letter(XK_LEFT), None);
        assert_eq!(control_shortcut_letter(XK_RIGHT), None);
        assert_eq!(control_shortcut_letter(XK_UP), None);
        assert_eq!(control_shortcut_letter(XK_DOWN), None);
        assert_eq!(control_shortcut_letter(b'Q' as KeySym), Some(b'q'));
        assert!(!program_navigation_available(true, 0, true));
        assert!(!program_navigation_available(false, 2, true));
        assert!(!program_navigation_available(true, 2, false));
        assert!(program_navigation_available(true, 2, true));
        assert_eq!(
            program_navigation_index(None, 3, VerticalNavigation::ProgramPrevious),
            Some(2)
        );
        assert_eq!(
            program_navigation_index(None, 3, VerticalNavigation::ProgramNext),
            Some(0)
        );
        assert_eq!(
            program_navigation_index(Some(0), 3, VerticalNavigation::ProgramPrevious),
            Some(0)
        );
        assert_eq!(
            program_navigation_index(Some(2), 3, VerticalNavigation::ProgramNext),
            Some(2)
        );
        assert_eq!(
            program_navigation_index(Some(usize::MAX), 3, VerticalNavigation::ProgramNext,),
            Some(2)
        );
        assert_eq!(
            program_navigation_index(None, 0, VerticalNavigation::ProgramPrevious),
            None
        );
    }

    #[test]
    fn program_panel_reserves_headers_and_keeps_selection_visible() {
        assert_eq!(
            program_panel_visible_rows((MARGIN_Y * 2 + 9 * FONT_HEIGHT) as u32),
            7
        );
        assert_eq!(normalized_program_panel_selection(0, 7, 4, 3), (0, 0));
        assert_eq!(normalized_program_panel_selection(20, 7, 3, 8), (3, 3));
        assert_eq!(normalized_program_panel_selection(20, 7, 12, 3), (12, 6));
        assert_eq!(normalized_program_panel_selection(5, 7, 99, 99), (4, 0));
        assert_eq!(normalized_program_panel_selection(5, 0, 3, 0), (3, 3));
    }

    #[test]
    fn caps_mode_preserves_case_inside_quoted_paths_and_text() {
        assert!(!cursor_is_inside_quotes("LOAD ", 5));
        assert!(cursor_is_inside_quotes("LOAD \"programs/music", 20));
        assert!(!cursor_is_inside_quotes(
            "LOAD \"programs/music/file.bas\"",
            30
        ));
        assert!(cursor_is_inside_quotes("10 PRINT \"Mixed Case", 19));
    }

    #[test]
    fn binary_ppm_parser_preserves_whitespace_valued_first_pixels() {
        let mut ppm = b"P6\n2 1\n255\n".to_vec();
        ppm.extend_from_slice(&[10, 32, 255, 255, 0, 128]);
        let image = RasterImage::parse_ppm(&ppm).unwrap();
        assert_eq!(image.width, 2);
        assert_eq!(image.height, 1);
        assert_eq!(image.rgb, vec![10, 32, 255, 255, 0, 128]);
    }

    #[test]
    fn native_bgrx_upload_scales_pixels_and_preserves_stride_padding() {
        let raster = RasterImage {
            width: 2,
            height: 2,
            rgb: vec![255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 255],
        };
        let source_columns = vec![0, 0, 3, 3];
        let source_rows = vec![0, 0, 6, 6];
        let stride = 20;
        let mut output = vec![0xaa; stride * 4];
        fill_scaled_bgrx(
            &mut output,
            stride,
            &raster,
            4,
            &source_columns,
            &source_rows,
        );

        assert_eq!(
            &output[0..16],
            &[0, 0, 255, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 255, 0, 0,]
        );
        assert_eq!(
            &output[stride * 2..stride * 2 + 16],
            &[255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 0, 255, 255, 255, 0,]
        );
        assert!(output[16..20].iter().all(|byte| *byte == 0xaa));
        assert!(output[stride * 2 + 16..stride * 3]
            .iter()
            .all(|byte| *byte == 0xaa));
    }

    #[test]
    fn graphics_screen_fit_preserves_aspect_ratio_and_pointer_coordinates() {
        assert_eq!(
            raster_viewport(1_100, 700, 1_920, 1_080, GraphicsScaleMode::Fit),
            Some(RasterViewport {
                x: 0,
                y: 41,
                width: 1_100,
                height: 618,
            })
        );
        let portrait = raster_viewport(800, 1_000, 1_920, 1_080, GraphicsScaleMode::Fit)
            .expect("nonzero viewport");
        assert_eq!(
            portrait,
            RasterViewport {
                x: 0,
                y: 275,
                width: 800,
                height: 450,
            }
        );
        assert_eq!(
            map_pointer_to_raster(0, 275, portrait, 1_920, 1_080),
            Some((0, 0))
        );
        assert_eq!(
            map_pointer_to_raster(799, 724, portrait, 1_920, 1_080),
            Some((1_919, 1_079))
        );
        assert_eq!(
            map_pointer_to_raster(400, 100, portrait, 1_920, 1_080),
            None
        );
        assert_eq!(
            raster_viewport(800, 1_000, 1_920, 1_080, GraphicsScaleMode::Stretch),
            Some(RasterViewport {
                x: 0,
                y: 0,
                width: 800,
                height: 1_000,
            })
        );
        assert_eq!(
            raster_viewport(0, 100, 100, 100, GraphicsScaleMode::Fit),
            None
        );
    }

    #[test]
    fn system_hub_rejects_basic_and_never_prints_ready() {
        let root = std::env::temp_dir().join(format!(
            "modernbasic-system-hub-reject-{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir(&root).unwrap();
        let mut input =
            std::io::Cursor::new(b"RUN\nLIST\n10 PRINT 1\n2+2\nSHUTDOWN\nN\n".as_slice());
        let mut output = Vec::new();
        let mut commands = Vec::new();
        run_system_hub(
            &mut input,
            &mut output,
            Some(&root),
            ColorPrefs::default(),
            || {},
            |command| {
                commands.push(command);
                true
            },
        )
        .unwrap();
        let output = String::from_utf8(output).unwrap();
        assert!(!output.contains("READY."));
        assert_eq!(output.matches("unknown system command").count(), 4);
        assert!(output.contains("ARE YOU SURE? Y/N"));
        assert!(output.contains("CANCELLED."));
        assert!(commands.is_empty());
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn system_hub_routes_only_file_and_task_commands() {
        let root = std::env::temp_dir().join(format!(
            "modernbasic-system-hub-route-{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir(&root).unwrap();
        std::fs::write(root.join("demo.bas"), b"10 END\n").unwrap();
        std::fs::write(root.join("delete.bas"), b"10 END\n").unwrap();
        let mut input = std::io::Cursor::new(
            b"LOAD \"demo.bas\"\nNEW \"blank.bas\"\nDELETE \"delete.bas\"\nTASKS\nSTOP \"demo.bas\"\nCLOSE \"demo.bas\"\nFOCUS \"blank.bas\"\nRESTART\nY\n"
                .as_slice(),
        );
        let mut output = Vec::new();
        let mut commands = Vec::new();
        run_system_hub(
            &mut input,
            &mut output,
            Some(&root),
            ColorPrefs::default(),
            || {},
            |command| {
                commands.push(command);
                true
            },
        )
        .unwrap();
        assert!(root.join("blank.bas").is_file());
        assert!(!root.join("delete.bas").exists());
        assert_eq!(commands.len(), 7);
        assert!(matches!(
            &commands[0],
            SystemCommand::Load { visible_path, .. } if visible_path == "programs/demo.bas"
        ));
        assert!(matches!(
            &commands[1],
            SystemCommand::New { visible_path, .. } if visible_path == "programs/blank.bas"
        ));
        assert_eq!(commands[2], SystemCommand::Tasks);
        assert_eq!(commands[3], SystemCommand::Stop("\"demo.bas\"".into()));
        assert_eq!(commands[4], SystemCommand::Close("\"demo.bas\"".into()));
        assert_eq!(commands[5], SystemCommand::Focus("\"blank.bas\"".into()));
        assert_eq!(commands[6], SystemCommand::Restart);
        let output = String::from_utf8(output).unwrap();
        assert!(!output.contains("READY."));
        assert!(output.contains("FILE DELETED."));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn system_hub_routes_help_and_manual_to_the_embedded_viewer() {
        let root = std::env::temp_dir().join(format!(
            "modernbasic-system-hub-help-{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir(&root).unwrap();
        let mut input = std::io::Cursor::new(b"HELP\nMANUAL\nEDIT SPRITE\nEDIT FONT\n".as_slice());
        let mut output = Vec::new();
        let mut commands = Vec::new();

        run_system_hub(
            &mut input,
            &mut output,
            Some(&root),
            ColorPrefs::default(),
            || {},
            |command| {
                commands.push(command);
                true
            },
        )
        .unwrap();

        assert_eq!(
            commands,
            vec![
                SystemCommand::Help,
                SystemCommand::Help,
                SystemCommand::Editor(EditorKind::Sprite),
                SystemCommand::Editor(EditorKind::Font)
            ]
        );
        assert!(!String::from_utf8(output)
            .unwrap()
            .contains("unknown system command"));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn embedded_graphics_editors_parse_and_expose_their_native_asset_commands() {
        for (name, source, minimum_lines, required) in [
            (
                "sprite",
                SPRITE_EDITOR_SOURCE,
                90,
                ["SPRITE IMAGE", "PUT # 1", "assets/sprite"],
            ),
            (
                "font",
                FONT_EDITOR_SOURCE,
                75,
                ["FONT", "PUT # 1", "assets/custom_font.ppm"],
            ),
        ] {
            let mut program = Program::new();
            program
                .read_from(
                    &mut io::Cursor::new(source.as_bytes()),
                    DEFAULT_MAX_SOURCE_LINE_BYTES,
                )
                .unwrap_or_else(|error| panic!("{name} editor did not parse: {error}"));
            let listing = program.list();
            assert!(
                listing.len() >= minimum_lines,
                "{name} editor is incomplete"
            );
            let source = listing
                .into_iter()
                .map(|(_, line)| line)
                .collect::<Vec<_>>()
                .join("\n");
            for marker in required {
                assert!(source.contains(marker), "{name} editor is missing {marker}");
            }
        }
    }

    #[test]
    fn system_hub_routes_screen_and_text_color_commands() {
        let root = std::env::temp_dir().join(format!(
            "modernbasic-system-hub-color-{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir(&root).unwrap();
        let mut input =
            std::io::Cursor::new(b"SCREEN COLOR = #f5f0e1\nTEXT COLOR = #36454f\n".as_slice());
        let mut output = Vec::new();
        let mut commands = Vec::new();
        run_system_hub(
            &mut input,
            &mut output,
            Some(&root),
            ColorPrefs::default(),
            || {},
            |command| {
                commands.push(command);
                true
            },
        )
        .unwrap();
        assert_eq!(
            commands,
            vec![
                SystemCommand::ScreenColor("#f5f0e1".into()),
                SystemCommand::TextColor("#36454f".into()),
            ]
        );
        let output = String::from_utf8(output).unwrap();
        assert!(output.contains("SCREEN COLOR #f5f0e1."));
        assert!(output.contains("TEXT COLOR #36454f."));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn paste_text_normalizes_platform_line_endings_and_controls() {
        assert_eq!(
            normalize_paste_text("10 PRINT 1\r\n20 PRINT 2\r30 END\0"),
            "10 PRINT 1\n20 PRINT 2\n30 END"
        );
    }

    #[test]
    fn control_function_keys_are_reserved_for_the_shell() {
        assert!(shell_control_function_shortcut(XK_F1, CONTROL_MASK));
        assert!(shell_control_function_shortcut(XK_F2, CONTROL_MASK));
        assert!(!shell_control_function_shortcut(XK_F1, 0));
        assert!(!shell_control_function_shortcut(XK_F5, CONTROL_MASK));
    }

    #[test]
    fn single_line_paste_inserts_at_the_character_cursor() {
        assert_eq!(plan_paste("10 PRNT", 5, "I"), PastePlan::Insert("I".into()));
    }

    #[test]
    fn multiline_paste_becomes_numbered_input_lines_and_preserves_edges() {
        assert_eq!(
            plan_paste("ABCD", 2, "10 PRINT 1\n20 END\n"),
            PastePlan::Submit(vec!["AB10 PRINT 1".into(), "20 ENDCD".into()])
        );
        assert_eq!(
            plan_paste("", 0, "10 PRINT 1\n20 END"),
            PastePlan::Submit(vec!["10 PRINT 1".into(), "20 END".into()])
        );
    }
}
