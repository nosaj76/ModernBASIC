//! Checked finite complex numbers for the portable TI-BASIC extension.

use std::fmt;

use crate::error::Error;
use crate::real::BasicReal;

/// One finite binary64 complex value.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BasicComplex {
    real: BasicReal,
    imaginary: BasicReal,
}

#[allow(clippy::should_implement_trait)]
impl BasicComplex {
    pub fn new(real: f64, imaginary: f64) -> Result<Self, Error> {
        Ok(Self {
            real: BasicReal::new(real)?,
            imaginary: BasicReal::new(imaginary)?,
        })
    }

    pub fn from_real(real: BasicReal) -> Self {
        Self {
            real,
            imaginary: BasicReal::zero(),
        }
    }

    pub fn real(self) -> BasicReal {
        self.real
    }

    pub fn imaginary(self) -> BasicReal {
        self.imaginary
    }

    pub fn is_real(self) -> bool {
        self.imaginary.is_zero()
    }

    pub fn is_zero(self) -> bool {
        self.real.is_zero() && self.imaginary.is_zero()
    }

    pub fn add(self, right: Self) -> Result<Self, Error> {
        Self::new(
            self.real.value() + right.real.value(),
            self.imaginary.value() + right.imaginary.value(),
        )
    }

    pub fn sub(self, right: Self) -> Result<Self, Error> {
        Self::new(
            self.real.value() - right.real.value(),
            self.imaginary.value() - right.imaginary.value(),
        )
    }

    pub fn mul(self, right: Self) -> Result<Self, Error> {
        let a = self.real.value();
        let b = self.imaginary.value();
        let c = right.real.value();
        let d = right.imaginary.value();
        Self::new(a * c - b * d, a * d + b * c)
    }

    pub fn div(self, right: Self) -> Result<Self, Error> {
        if right.is_zero() {
            return Err(Error::DivideByZero);
        }
        // Smith's scaled division avoids unnecessary intermediate overflow.
        let a = self.real.value();
        let b = self.imaginary.value();
        let c = right.real.value();
        let d = right.imaginary.value();
        if c.abs() >= d.abs() {
            let ratio = d / c;
            let denominator = c + d * ratio;
            Self::new((a + b * ratio) / denominator, (b - a * ratio) / denominator)
        } else {
            let ratio = c / d;
            let denominator = d + c * ratio;
            Self::new((a * ratio + b) / denominator, (b * ratio - a) / denominator)
        }
    }

    pub fn neg(self) -> Result<Self, Error> {
        Self::new(-self.real.value(), -self.imaginary.value())
    }

    pub fn conjugate(self) -> Result<Self, Error> {
        Self::new(self.real.value(), -self.imaginary.value())
    }

    pub fn magnitude(self) -> Result<BasicReal, Error> {
        BasicReal::new(self.real.value().hypot(self.imaginary.value()))
    }

    pub fn angle(self) -> Result<BasicReal, Error> {
        if self.is_zero() {
            return Err(Error::MathDomain { function: "ANGLE" });
        }
        BasicReal::new(self.imaginary.value().atan2(self.real.value()))
    }

    pub fn exp(self) -> Result<Self, Error> {
        let radius = self.real.value().exp();
        Self::new(
            radius * self.imaginary.value().cos(),
            radius * self.imaginary.value().sin(),
        )
    }

    pub fn ln(self) -> Result<Self, Error> {
        if self.is_zero() {
            return Err(Error::MathDomain { function: "LOG" });
        }
        Self::new(self.magnitude()?.value().ln(), self.angle()?.value())
    }

    pub fn sqrt(self) -> Result<Self, Error> {
        if self.is_zero() {
            return Ok(self);
        }
        let magnitude = self.magnitude()?.value();
        let real = ((magnitude + self.real.value()) / 2.0).sqrt();
        let imaginary = ((magnitude - self.real.value()) / 2.0)
            .sqrt()
            .copysign(self.imaginary.value());
        Self::new(real, imaginary)
    }

    pub fn sin(self) -> Result<Self, Error> {
        let a = self.real.value();
        let b = self.imaginary.value();
        Self::new(a.sin() * b.cosh(), a.cos() * b.sinh())
    }

    pub fn cos(self) -> Result<Self, Error> {
        let a = self.real.value();
        let b = self.imaginary.value();
        Self::new(a.cos() * b.cosh(), -a.sin() * b.sinh())
    }

    pub fn tan(self) -> Result<Self, Error> {
        self.sin()?.div(self.cos()?)
    }

    pub fn sinh(self) -> Result<Self, Error> {
        let a = self.real.value();
        let b = self.imaginary.value();
        Self::new(a.sinh() * b.cos(), a.cosh() * b.sin())
    }

    pub fn cosh(self) -> Result<Self, Error> {
        let a = self.real.value();
        let b = self.imaginary.value();
        Self::new(a.cosh() * b.cos(), a.sinh() * b.sin())
    }

    pub fn tanh(self) -> Result<Self, Error> {
        self.sinh()?.div(self.cosh()?)
    }

    pub fn asin(self) -> Result<Self, Error> {
        let imaginary_times_self = Self::new(-self.imaginary.value(), self.real.value())?;
        let root = Self::new(1.0, 0.0)?.sub(self.mul(self)?)?.sqrt()?;
        let logarithm = imaginary_times_self.add(root)?.ln()?;
        Self::new(logarithm.imaginary.value(), -logarithm.real.value())
    }

    pub fn acos(self) -> Result<Self, Error> {
        Self::new(std::f64::consts::FRAC_PI_2, 0.0)?.sub(self.asin()?)
    }

    pub fn atan(self) -> Result<Self, Error> {
        let imaginary_times_self = Self::new(-self.imaginary.value(), self.real.value())?;
        let one = Self::new(1.0, 0.0)?;
        let difference = one
            .sub(imaginary_times_self)?
            .ln()?
            .sub(one.add(imaginary_times_self)?.ln()?)?;
        Self::new(
            -difference.imaginary.value() / 2.0,
            difference.real.value() / 2.0,
        )
    }

    pub fn asinh(self) -> Result<Self, Error> {
        self.add(self.mul(self)?.add(Self::new(1.0, 0.0)?)?.sqrt()?)?
            .ln()
    }

    pub fn acosh(self) -> Result<Self, Error> {
        let one = Self::new(1.0, 0.0)?;
        self.add(self.add(one)?.sqrt()?.mul(self.sub(one)?.sqrt()?)?)?
            .ln()
    }

    pub fn atanh(self) -> Result<Self, Error> {
        let one = Self::new(1.0, 0.0)?;
        let difference = one.add(self)?.ln()?.sub(one.sub(self)?.ln()?)?;
        Self::new(
            difference.real.value() / 2.0,
            difference.imaginary.value() / 2.0,
        )
    }

    pub fn log10(self) -> Result<Self, Error> {
        let value = self.ln()?;
        Self::new(
            value.real.value() / std::f64::consts::LN_10,
            value.imaginary.value() / std::f64::consts::LN_10,
        )
    }

    pub fn scale(self, factor: BasicReal) -> Result<Self, Error> {
        Self::new(
            self.real.value() * factor.value(),
            self.imaginary.value() * factor.value(),
        )
    }

    pub fn pow(self, exponent: Self) -> Result<Self, Error> {
        if self.is_zero() {
            if exponent.imaginary.is_zero() && exponent.real.value() > 0.0 {
                return Ok(self);
            }
            if exponent.is_zero() {
                return Self::new(1.0, 0.0);
            }
            return Err(Error::MathDomain { function: "^" });
        }
        if exponent.imaginary.is_zero() {
            if let Ok(integer) = exponent.real.to_integer() {
                let mut power = integer.unsigned_abs();
                let mut factor = self;
                let mut result = Self::new(1.0, 0.0)?;
                while power > 0 {
                    if power & 1 == 1 {
                        result = result.mul(factor)?;
                    }
                    power >>= 1;
                    if power > 0 {
                        factor = factor.mul(factor)?;
                    }
                }
                return if integer < 0 {
                    Self::new(1.0, 0.0)?.div(result)
                } else {
                    Ok(result)
                };
            }
        }
        exponent.mul(self.ln()?)?.exp()
    }
}

impl fmt::Display for BasicComplex {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        let real = self.real.value();
        let imaginary = self.imaginary.value();
        if imaginary == 0.0 {
            return write!(formatter, "{}", self.real);
        }
        if real == 0.0 {
            return display_imaginary(formatter, imaginary);
        }
        write!(formatter, "{}", self.real)?;
        if imaginary > 0.0 {
            write!(formatter, "+")?;
        }
        display_imaginary(formatter, imaginary)
    }
}

fn display_imaginary(formatter: &mut fmt::Formatter<'_>, value: f64) -> fmt::Result {
    if value == 1.0 {
        write!(formatter, "i")
    } else if value == -1.0 {
        write!(formatter, "-i")
    } else {
        write!(
            formatter,
            "{}i",
            BasicReal::new(value).map_err(|_| fmt::Error)?
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn arithmetic_and_principal_functions_are_checked() {
        let left = BasicComplex::new(2.0, 3.0).unwrap();
        let right = BasicComplex::new(4.0, -1.0).unwrap();
        assert_eq!(
            left.add(right).unwrap(),
            BasicComplex::new(6.0, 2.0).unwrap()
        );
        assert_eq!(
            left.mul(right).unwrap(),
            BasicComplex::new(11.0, 10.0).unwrap()
        );
        let quotient = left.div(right).unwrap();
        assert!((quotient.real().value() - 5.0 / 17.0).abs() < 1e-14);
        assert!((quotient.imaginary().value() - 14.0 / 17.0).abs() < 1e-14);
        assert_eq!(
            BasicComplex::new(-4.0, 0.0).unwrap().sqrt().unwrap(),
            BasicComplex::new(0.0, 2.0).unwrap()
        );
        assert_eq!(
            left.div(BasicComplex::new(0.0, 0.0).unwrap()).unwrap_err(),
            Error::DivideByZero
        );
    }

    #[test]
    fn display_is_unambiguous_and_finite() {
        assert_eq!(BasicComplex::new(2.0, 3.0).unwrap().to_string(), "2+3i");
        assert_eq!(BasicComplex::new(0.0, 1.0).unwrap().to_string(), "i");
        assert_eq!(BasicComplex::new(0.0, -1.0).unwrap().to_string(), "-i");
        assert_eq!(BasicComplex::new(2.0, -3.0).unwrap().to_string(), "2-3i");
    }
}
