//! Checked native 64-bit real-number support.
//!
//! `BasicReal` wraps a finite IEEE-754 binary64 value. NaN and infinities are
//! never valid BASIC values, zero is canonicalized, and conversion from the
//! exact integer domain rejects values that binary64 cannot represent exactly.

use std::fmt;

use crate::error::Error;

/// A finite, canonicalized native 64-bit real number.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct BasicReal {
    bits: u64,
}

#[allow(clippy::should_implement_trait)]
impl BasicReal {
    /// Canonical finite zero.
    pub const fn zero() -> Self {
        Self { bits: 0 }
    }

    /// Construct a checked real value.
    pub fn new(value: f64) -> Result<Self, Error> {
        if !value.is_finite() {
            return Err(Error::RealOverflow);
        }
        let value = if value == 0.0 { 0.0 } else { value };
        Ok(Self {
            bits: value.to_bits(),
        })
    }

    /// Parse one finite decimal/exponent literal.
    pub fn parse(text: &str) -> Result<Self, Error> {
        let value = text
            .parse::<f64>()
            .map_err(|_| Error::syntax(format!("bad real number {text}")))?;
        Self::new(value)
    }

    /// Promote an integer only when binary64 preserves it exactly.
    pub fn from_integer(value: i64) -> Result<Self, Error> {
        let real = value as f64;
        if real as i128 != i128::from(value) {
            return Err(Error::InexactRealConversion { value });
        }
        Self::new(real)
    }

    /// Return the underlying finite binary64 value.
    pub fn value(self) -> f64 {
        f64::from_bits(self.bits)
    }

    /// Convert an integral, in-range real to `i64`.
    pub fn to_integer(self) -> Result<i64, Error> {
        const I64_LOWER: f64 = -9_223_372_036_854_775_808.0;
        const I64_UPPER_EXCLUSIVE: f64 = 9_223_372_036_854_775_808.0;
        let value = self.value();
        if value.fract() != 0.0 || !(I64_LOWER..I64_UPPER_EXCLUSIVE).contains(&value) {
            return Err(Error::IntegerRequired);
        }
        Ok(value as i64)
    }

    /// Round a finite real to the nearest in-range integer.
    pub fn to_rounded_integer(self) -> Result<i64, Error> {
        const I64_LOWER: f64 = -9_223_372_036_854_775_808.0;
        const I64_UPPER_EXCLUSIVE: f64 = 9_223_372_036_854_775_808.0;
        let rounded = self.value().round();
        if !(I64_LOWER..I64_UPPER_EXCLUSIVE).contains(&rounded) {
            return Err(Error::IntegerOverflow);
        }
        Ok(rounded as i64)
    }

    /// Whether this number is zero.
    pub fn is_zero(self) -> bool {
        self.value() == 0.0
    }

    /// Numeric sign as `-1`, `0`, or `1`.
    pub fn signum(self) -> i64 {
        let value = self.value();
        if value < 0.0 {
            -1
        } else if value > 0.0 {
            1
        } else {
            0
        }
    }

    /// Checked addition.
    pub fn add(self, rhs: Self) -> Result<Self, Error> {
        Self::new(self.value() + rhs.value())
    }

    /// Checked subtraction.
    pub fn sub(self, rhs: Self) -> Result<Self, Error> {
        Self::new(self.value() - rhs.value())
    }

    /// Checked multiplication.
    pub fn mul(self, rhs: Self) -> Result<Self, Error> {
        Self::new(self.value() * rhs.value())
    }

    /// Checked division.
    pub fn div(self, rhs: Self) -> Result<Self, Error> {
        if rhs.is_zero() {
            return Err(Error::DivideByZero);
        }
        Self::new(self.value() / rhs.value())
    }

    /// Checked unary negation.
    pub fn neg(self) -> Result<Self, Error> {
        Self::new(-self.value())
    }

    /// Absolute value.
    pub fn abs(self) -> Result<Self, Error> {
        Self::new(self.value().abs())
    }

    /// Floor toward negative infinity.
    pub fn floor(self) -> Result<Self, Error> {
        Self::new(self.value().floor())
    }

    /// Checked square root.
    pub fn sqrt(self) -> Result<Self, Error> {
        if self.value() < 0.0 {
            return Err(Error::MathDomain { function: "SQR" });
        }
        Self::new(self.value().sqrt())
    }

    /// Checked natural logarithm.
    pub fn ln(self) -> Result<Self, Error> {
        if self.value() <= 0.0 {
            return Err(Error::MathDomain { function: "LOG" });
        }
        Self::new(self.value().ln())
    }

    /// Checked natural exponential.
    pub fn exp(self) -> Result<Self, Error> {
        let input = self.value();
        let mut result = input.exp();

        // `ln` can map an exact integer and its adjacent floating-point value
        // to the same binary64 result. Prefer that exact integer when it is a
        // valid inverse at the engine's storage precision, making common
        // EXP(LOG(n)) round trips stable without broadly rounding EXP output.
        let integer = result.round();
        if integer > 0.0 && integer.is_finite() && integer.ln().to_bits() == input.to_bits() {
            result = integer;
        }
        Self::new(result)
    }

    /// Checked sine, with the argument in radians.
    pub fn sin(self) -> Result<Self, Error> {
        Self::new(self.value().sin())
    }

    /// Checked cosine, with the argument in radians.
    pub fn cos(self) -> Result<Self, Error> {
        Self::new(self.value().cos())
    }

    /// Checked tangent, with the argument in radians.
    pub fn tan(self) -> Result<Self, Error> {
        Self::new(self.value().tan())
    }

    /// Checked arctangent, returning radians.
    pub fn atan(self) -> Result<Self, Error> {
        Self::new(self.value().atan())
    }

    /// Checked arcsine, returning radians.
    pub fn asin(self) -> Result<Self, Error> {
        if !(-1.0..=1.0).contains(&self.value()) {
            return Err(Error::MathDomain { function: "ASIN" });
        }
        Self::new(self.value().asin())
    }

    /// Checked arccosine, returning radians.
    pub fn acos(self) -> Result<Self, Error> {
        if !(-1.0..=1.0).contains(&self.value()) {
            return Err(Error::MathDomain { function: "ACOS" });
        }
        Self::new(self.value().acos())
    }

    /// Checked hyperbolic sine.
    pub fn sinh(self) -> Result<Self, Error> {
        Self::new(self.value().sinh())
    }

    /// Checked hyperbolic cosine.
    pub fn cosh(self) -> Result<Self, Error> {
        Self::new(self.value().cosh())
    }

    /// Checked hyperbolic tangent.
    pub fn tanh(self) -> Result<Self, Error> {
        Self::new(self.value().tanh())
    }

    /// Checked inverse hyperbolic sine.
    pub fn asinh(self) -> Result<Self, Error> {
        Self::new(self.value().asinh())
    }

    /// Checked inverse hyperbolic cosine.
    pub fn acosh(self) -> Result<Self, Error> {
        if self.value() < 1.0 {
            return Err(Error::MathDomain { function: "ACOSH" });
        }
        Self::new(self.value().acosh())
    }

    /// Checked inverse hyperbolic tangent.
    pub fn atanh(self) -> Result<Self, Error> {
        if self.value().abs() >= 1.0 {
            return Err(Error::MathDomain { function: "ATANH" });
        }
        Self::new(self.value().atanh())
    }

    /// Checked base-10 logarithm.
    pub fn log10(self) -> Result<Self, Error> {
        if self.value() <= 0.0 {
            return Err(Error::MathDomain { function: "LOG10" });
        }
        Self::new(self.value().log10())
    }

    /// Checked logarithm in an explicitly supplied base.
    pub fn log_base(self, base: Self) -> Result<Self, Error> {
        if self.value() <= 0.0 || base.value() <= 0.0 || base.value() == 1.0 {
            return Err(Error::MathDomain {
                function: "LOGBASE",
            });
        }
        Self::new(self.value().log(base.value()))
    }

    /// Checked real cube root, including negative values.
    pub fn cbrt(self) -> Result<Self, Error> {
        Self::new(self.value().cbrt())
    }

    /// Checked real nth root, using `ROOT(value,index)` ordering.
    pub fn root(self, index: Self) -> Result<Self, Error> {
        let value = self.value();
        let index = index.value();
        if index == 0.0 {
            return Err(Error::MathDomain { function: "ROOT" });
        }
        if value == 0.0 && index < 0.0 {
            return Err(Error::DivideByZero);
        }
        if value < 0.0 {
            if index.fract() != 0.0 || index.rem_euclid(2.0) != 1.0 {
                return Err(Error::MathDomain { function: "ROOT" });
            }
            return Self::new(-(-value).powf(1.0 / index));
        }
        Self::new(value.powf(1.0 / index))
    }

    /// Convert radians to degrees.
    pub fn to_degrees(self) -> Result<Self, Error> {
        Self::new(self.value().to_degrees())
    }

    /// Convert degrees to radians.
    pub fn to_radians(self) -> Result<Self, Error> {
        Self::new(self.value().to_radians())
    }

    /// Checked exponentiation.
    ///
    /// Negative bases require an integral exponent. Zero to a negative power
    /// is division by zero, while zero to the zero power follows Microsoft
    /// BASIC's exponentiation path and produces one.
    pub fn pow(self, exponent: Self) -> Result<Self, Error> {
        let base = self.value();
        let exponent = exponent.value();
        if exponent == 0.0 {
            return Self::new(1.0);
        }
        if base == 0.0 {
            if exponent < 0.0 {
                return Err(Error::DivideByZero);
            }
            return Self::new(0.0);
        }
        if base < 0.0 {
            if exponent.fract() != 0.0 {
                return Err(Error::MathDomain { function: "^" });
            }
            let magnitude = (-base).powf(exponent);
            let signed = if exponent.rem_euclid(2.0) == 1.0 {
                -magnitude
            } else {
                magnitude
            };
            return Self::new(signed);
        }
        Self::new(base.powf(exponent))
    }
}

impl fmt::Display for BasicReal {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}", self.value())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn finite_values_and_zero_are_canonical() {
        assert_eq!(BasicReal::new(-0.0).unwrap(), BasicReal::new(0.0).unwrap());
        assert_eq!(
            BasicReal::new(f64::INFINITY).unwrap_err(),
            Error::RealOverflow
        );
        assert_eq!(BasicReal::new(f64::NAN).unwrap_err(), Error::RealOverflow);
    }

    #[test]
    fn integer_promotion_must_be_exact() {
        assert_eq!(
            BasicReal::from_integer(9_007_199_254_740_992)
                .unwrap()
                .to_integer()
                .unwrap(),
            9_007_199_254_740_992
        );
        assert_eq!(
            BasicReal::from_integer(9_007_199_254_740_993).unwrap_err(),
            Error::InexactRealConversion {
                value: 9_007_199_254_740_993
            }
        );
    }

    #[test]
    fn checked_real_arithmetic_rejects_invalid_results() {
        let one = BasicReal::new(1.0).unwrap();
        assert_eq!(
            one.div(BasicReal::new(0.0).unwrap()).unwrap_err(),
            Error::DivideByZero
        );
        assert_eq!(
            BasicReal::new(f64::MAX)
                .unwrap()
                .mul(BasicReal::new(2.0).unwrap())
                .unwrap_err(),
            Error::RealOverflow
        );
    }

    #[test]
    fn checked_math_has_explicit_domains_and_finite_results() {
        assert_eq!(
            BasicReal::new(9.0).unwrap().sqrt().unwrap(),
            BasicReal::new(3.0).unwrap()
        );
        assert_eq!(
            BasicReal::new(-1.0).unwrap().sqrt().unwrap_err(),
            Error::MathDomain { function: "SQR" }
        );
        assert_eq!(
            BasicReal::new(0.0).unwrap().ln().unwrap_err(),
            Error::MathDomain { function: "LOG" }
        );
        assert_eq!(
            BasicReal::new(1000.0).unwrap().exp().unwrap_err(),
            Error::RealOverflow
        );
    }

    #[test]
    fn checked_power_handles_sign_zero_domain_and_overflow() {
        let two = BasicReal::new(2.0).unwrap();
        assert_eq!(
            two.pow(BasicReal::new(3.0).unwrap()).unwrap(),
            BasicReal::new(8.0).unwrap()
        );
        assert_eq!(
            BasicReal::new(-2.0)
                .unwrap()
                .pow(BasicReal::new(3.0).unwrap())
                .unwrap(),
            BasicReal::new(-8.0).unwrap()
        );
        assert_eq!(
            BasicReal::new(-2.0)
                .unwrap()
                .pow(BasicReal::new(0.5).unwrap())
                .unwrap_err(),
            Error::MathDomain { function: "^" }
        );
        assert_eq!(
            BasicReal::new(0.0)
                .unwrap()
                .pow(BasicReal::new(-1.0).unwrap())
                .unwrap_err(),
            Error::DivideByZero
        );
        assert_eq!(
            BasicReal::new(0.0)
                .unwrap()
                .pow(BasicReal::new(0.0).unwrap())
                .unwrap(),
            BasicReal::new(1.0).unwrap()
        );
    }

    #[test]
    fn ti_inverse_hyperbolic_log_and_root_functions_are_checked() {
        let one = BasicReal::new(1.0).unwrap();
        assert!((one.asin().unwrap().value() - std::f64::consts::FRAC_PI_2).abs() < 1e-12);
        assert_eq!(one.acos().unwrap(), BasicReal::new(0.0).unwrap());
        assert_eq!(
            BasicReal::new(2.0).unwrap().asin().unwrap_err(),
            Error::MathDomain { function: "ASIN" }
        );
        assert!((one.sinh().unwrap().asinh().unwrap().value() - 1.0).abs() < 1e-12);
        assert!(
            (BasicReal::new(2.0)
                .unwrap()
                .acosh()
                .unwrap()
                .cosh()
                .unwrap()
                .value()
                - 2.0)
                .abs()
                < 1e-12
        );
        assert!(
            (BasicReal::new(0.5)
                .unwrap()
                .atanh()
                .unwrap()
                .tanh()
                .unwrap()
                .value()
                - 0.5)
                .abs()
                < 1e-12
        );
        assert_eq!(
            one.atanh().unwrap_err(),
            Error::MathDomain { function: "ATANH" }
        );
        assert_eq!(
            BasicReal::new(100.0).unwrap().log10().unwrap(),
            BasicReal::new(2.0).unwrap()
        );
        assert_eq!(
            BasicReal::new(8.0)
                .unwrap()
                .log_base(BasicReal::new(2.0).unwrap())
                .unwrap(),
            BasicReal::new(3.0).unwrap()
        );
        assert_eq!(
            BasicReal::new(8.0)
                .unwrap()
                .log_base(BasicReal::new(1.0).unwrap())
                .unwrap_err(),
            Error::MathDomain {
                function: "LOGBASE"
            }
        );
        assert_eq!(
            BasicReal::new(-8.0)
                .unwrap()
                .root(BasicReal::new(3.0).unwrap())
                .unwrap(),
            BasicReal::new(-2.0).unwrap()
        );
        assert_eq!(
            BasicReal::new(-8.0)
                .unwrap()
                .root(BasicReal::new(2.0).unwrap())
                .unwrap_err(),
            Error::MathDomain { function: "ROOT" }
        );
    }
}
