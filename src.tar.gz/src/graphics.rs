//! Unified ModernBASIC graphics device backed by Artist.
//!
//! The BASIC programmer uses ordinary graphics statements (`SCREEN`, `LINE`,
//! `CIRCLE`, `PSET`, `PAINT`, `SPRITE`, and related commands). Artist is an
//! internal rendering engine, not part of the public source syntax.

use std::collections::HashMap;

use crate::artist_scene::ArtistScene;
use crate::error::Error;
use crate::framebuffer::ScreenBuffer;
use crate::perspective::PerspectiveWorld;

pub const MAX_PALETTE_COLORS: usize = 256;
pub const GRAPHICS_BUFFER_COUNT: usize = 2;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GraphicsMode {
    TwoD,
    Perspective3D,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RasterAction {
    Pset,
    Preset,
    And,
    Or,
    Xor,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Viewport {
    left: usize,
    top: usize,
    right: usize,
    bottom: usize,
    screen_coordinates: bool,
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct WindowMapping {
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
    screen_coordinates: bool,
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct SpriteBounds {
    x: f64,
    y: f64,
    width: f64,
    height: f64,
    velocity_x: f64,
    velocity_y: f64,
    acceleration_x: f64,
    acceleration_y: f64,
}

impl SpriteBounds {
    fn intersects(self, other: Self) -> bool {
        self.width > 0.0
            && self.height > 0.0
            && other.width > 0.0
            && other.height > 0.0
            && self.x < other.x + other.width
            && other.x < self.x + self.width
            && self.y < other.y + other.height
            && other.y < self.y + self.height
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
struct BitmapFontSelection {
    path: String,
    cell_width: usize,
    cell_height: usize,
    first_codepoint: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub struct GraphicsDevice {
    scenes: [ArtistScene; GRAPHICS_BUFFER_COUNT],
    framebuffers: [ScreenBuffer; GRAPHICS_BUFFER_COUNT],
    scene_generations: [u64; GRAPHICS_BUFFER_COUNT],
    framebuffer_generations: [u64; GRAPHICS_BUFFER_COUNT],
    scene_dirty: bool,
    /// True while PSET can be retained as device-space scanline rasters.
    /// Any general scene mutation disables the optimization until SCREEN or
    /// CLS establishes a fresh identity graphics state.
    pixel_batch_safe: [bool; GRAPHICS_BUFFER_COUNT],
    sprites: [HashMap<String, SpriteBounds>; GRAPHICS_BUFFER_COUNT],
    perspective_world: PerspectiveWorld,
    graphics_mode: GraphicsMode,
    draw_buffer: usize,
    display_buffer: usize,
    foreground: String,
    background: String,
    /// Classic BASIC's optional third `COLOR` argument. Whether this appears
    /// as a physical border is a policy of the attached graphical shell.
    border_color: String,
    palette: Vec<String>,
    cursor_x: String,
    cursor_y: String,
    viewport: Option<Viewport>,
    window: Option<WindowMapping>,
    applied_viewports: [Option<Viewport>; GRAPHICS_BUFFER_COUNT],
    applied_windows: [Option<WindowMapping>; GRAPHICS_BUFFER_COUNT],
    bitmap_font: Option<BitmapFontSelection>,
}

impl Default for GraphicsDevice {
    fn default() -> Self {
        let palette = default_palette()
            .iter()
            .map(|color| (*color).to_string())
            .collect();
        Self {
            scenes: [ArtistScene::default(), ArtistScene::default()],
            framebuffers: [
                ScreenBuffer::new(1024, 768, 0xff000000),
                ScreenBuffer::new(1024, 768, 0xff000000),
            ],
            scene_generations: [0; GRAPHICS_BUFFER_COUNT],
            framebuffer_generations: [0; GRAPHICS_BUFFER_COUNT],
            scene_dirty: false,
            pixel_batch_safe: [true; GRAPHICS_BUFFER_COUNT],
            sprites: [HashMap::new(), HashMap::new()],
            perspective_world: PerspectiveWorld::default(),
            graphics_mode: GraphicsMode::TwoD,
            draw_buffer: 0,
            display_buffer: 0,
            foreground: "#ffffff".to_string(),
            background: "#000000".to_string(),
            border_color: "#000000".to_string(),
            palette,
            cursor_x: "0".to_string(),
            cursor_y: "0".to_string(),
            viewport: None,
            window: None,
            applied_viewports: [None; GRAPHICS_BUFFER_COUNT],
            applied_windows: [None; GRAPHICS_BUFFER_COUNT],
            bitmap_font: None,
        }
    }
}

impl GraphicsDevice {
    pub fn set_screen(&mut self, width: i64, height: i64, background: &str) -> Result<(), Error> {
        let clear_color = parse_argb(background)?;
        for scene in &mut self.scenes {
            scene.set_screen(width, height, background)?;
        }
        let width = usize::try_from(width).map_err(|_| Error::IllegalQuantity)?;
        let height = usize::try_from(height).map_err(|_| Error::IllegalQuantity)?;
        for buffer in &mut self.framebuffers {
            *buffer = ScreenBuffer::new(width, height, clear_color);
        }
        for sprites in &mut self.sprites {
            sprites.clear();
        }
        self.perspective_world = PerspectiveWorld::default();
        self.graphics_mode = GraphicsMode::TwoD;
        self.background = background.to_string();
        self.draw_buffer = 0;
        self.display_buffer = 0;
        self.scene_generations = [0; GRAPHICS_BUFFER_COUNT];
        self.framebuffer_generations = [0; GRAPHICS_BUFFER_COUNT];
        self.scene_dirty = true;
        self.pixel_batch_safe = [true; GRAPHICS_BUFFER_COUNT];
        self.viewport = None;
        self.window = None;
        self.applied_viewports = [None; GRAPHICS_BUFFER_COUNT];
        self.applied_windows = [None; GRAPHICS_BUFFER_COUNT];
        self.bitmap_font = None;
        self.set_cursor(0.0, 0.0);
        Ok(())
    }

    pub fn clear(&mut self, background: Option<&str>) -> Result<(), Error> {
        let clear_color = background.map(parse_argb).transpose()?;
        if let Some(background) = background {
            self.background = background.to_string();
        }
        self.scene_mut().clear(background)?;
        if self.viewport.is_some() || self.window.is_some() {
            self.append_coordinate_state()?;
        }
        self.sprites[self.draw_buffer].clear();
        if let Some(clear_color) = clear_color {
            self.framebuffers[self.draw_buffer].clear_color = clear_color;
        }
        self.framebuffers[self.draw_buffer].clear();
        self.framebuffer_generations[self.draw_buffer] = self.scene_generations[self.draw_buffer];
        self.pixel_batch_safe[self.draw_buffer] = self.viewport.is_none() && self.window.is_none();
        self.set_cursor(0.0, 0.0);
        Ok(())
    }

    pub fn set_pixel(&mut self, x: usize, y: usize, color: u32) {
        self.framebuffers[self.draw_buffer].set_pixel(x, y, color);
    }

    pub fn dimensions(&self) -> (usize, usize) {
        let framebuffer = &self.framebuffers[self.draw_buffer];
        (framebuffer.width, framebuffer.height)
    }

    pub fn framebuffer(&mut self) -> Result<&ScreenBuffer, Error> {
        self.rasterize_if_dirty()?;
        Ok(&self.framebuffers[self.draw_buffer])
    }

    pub fn scene(&self) -> &ArtistScene {
        &self.scenes[self.draw_buffer]
    }

    pub fn scene_mut(&mut self) -> &mut ArtistScene {
        self.mark_draw_buffer_dirty();
        self.pixel_batch_safe[self.draw_buffer] = false;
        &mut self.scenes[self.draw_buffer]
    }

    /// Plot a 2D BASIC pixel. In a fresh identity-coordinate scene, adjacent
    /// PSET calls are retained as compact raster rows; after a general Artist
    /// state mutation the exact legacy pixel-command path remains in use.
    pub fn plot_pixel(&mut self, x: f64, y: f64, color: &str) -> Result<(), Error> {
        if !x.is_finite() || !y.is_finite() {
            return Err(Error::RealOverflow);
        }
        if self.pixel_batch_safe[self.draw_buffer]
            && self.viewport.is_none()
            && self.window.is_none()
        {
            let color = parse_argb(color)?;
            let (width, height) = self.dimensions();
            if x < 0.0 || y < 0.0 || x >= width as f64 || y >= height as f64 {
                return Ok(());
            }
            let x = x as usize;
            let y = y as usize;
            self.scenes[self.draw_buffer].pixel_argb(x, y, color)?;
            self.mark_draw_buffer_dirty();
            return Ok(());
        }
        self.scene_mut().pixel(x, y, color)
    }

    /// Rasterize retained drawing commands only when they have changed since
    /// the framebuffer was last queried.
    pub fn rasterize_if_dirty(&mut self) -> Result<bool, Error> {
        self.rasterize_buffer_if_dirty(self.draw_buffer)
    }

    fn rasterize_buffer_if_dirty(&mut self, buffer: usize) -> Result<bool, Error> {
        if self.framebuffer_generations[buffer] == self.scene_generations[buffer] {
            return Ok(false);
        }
        let raster = self.render_buffer(buffer)?;
        self.framebuffers[buffer] = raster;
        self.framebuffer_generations[buffer] = self.scene_generations[buffer];
        Ok(true)
    }

    fn render_buffer(&self, buffer: usize) -> Result<ScreenBuffer, Error> {
        let source = self.source_for(buffer);
        let ppm = crate::artist_renderer::render_ppm(&source)?;
        let payload = ppm_payload(&ppm)?;
        let framebuffer = &self.framebuffers[buffer];
        let pixel_count = framebuffer
            .width
            .checked_mul(framebuffer.height)
            .ok_or(Error::IllegalQuantity)?;
        if payload.len() != pixel_count.saturating_mul(3) {
            return Err(Error::Io(
                "graphics raster dimensions do not match the framebuffer".to_string(),
            ));
        }
        let pixels = payload
            .chunks_exact(3)
            .map(|rgb| {
                0xff00_0000
                    | (u32::from(rgb[0]) << 16)
                    | (u32::from(rgb[1]) << 8)
                    | u32::from(rgb[2])
            })
            .collect::<Vec<_>>();
        let mut raster = ScreenBuffer::new(
            framebuffer.width,
            framebuffer.height,
            framebuffer.clear_color,
        );
        raster.restore(&pixels);
        Ok(raster)
    }

    pub fn get_pixel(&mut self, x: usize, y: usize) -> Result<u32, Error> {
        Ok(self.framebuffer()?.get_pixel(x, y))
    }

    /// Query a pixel through an immutable expression-runtime borrow. The
    /// interpreter normally pre-rasterizes direct POINT/SCRN expressions; the
    /// fallback render keeps queries inside user-defined functions correct.
    pub(crate) fn query_pixel(&self, x: f64, y: f64) -> Result<u32, Error> {
        let (x, y) = self.map_point(x, y);
        if x < 0.0 || y < 0.0 || x > usize::MAX as f64 || y > usize::MAX as f64 {
            return Ok(0);
        }
        let x = x.round() as usize;
        let y = y.round() as usize;
        if self.framebuffer_generations[self.draw_buffer]
            == self.scene_generations[self.draw_buffer]
        {
            Ok(self.framebuffers[self.draw_buffer].get_pixel(x, y))
        } else {
            Ok(self.render_buffer(self.draw_buffer)?.get_pixel(x, y))
        }
    }

    pub(crate) fn palette_index(&self, color: u32) -> Result<i64, Error> {
        let red = i64::from((color >> 16) & 0xff);
        let green = i64::from((color >> 8) & 0xff);
        let blue = i64::from(color & 0xff);
        self.palette
            .iter()
            .enumerate()
            .map(|(index, candidate)| {
                let candidate = parse_argb(candidate)?;
                let dr = red - i64::from((candidate >> 16) & 0xff);
                let dg = green - i64::from((candidate >> 8) & 0xff);
                let db = blue - i64::from(candidate & 0xff);
                Ok((dr * dr + dg * dg + db * db, index))
            })
            .collect::<Result<Vec<_>, Error>>()?
            .into_iter()
            .min()
            .map(|(_, index)| index as i64)
            .ok_or(Error::IllegalQuantity)
    }

    pub fn generation(&self) -> u64 {
        self.scene_generations[self.draw_buffer]
    }

    /// True when retained graphics have changed since their last successful
    /// presentation to an attached screen.
    pub(crate) fn scene_is_dirty(&self) -> bool {
        self.scene_dirty
    }

    pub(crate) fn mark_scene_presented(&mut self) {
        self.scene_dirty = false;
    }

    fn mark_draw_buffer_dirty(&mut self) {
        self.scene_generations[self.draw_buffer] =
            self.scene_generations[self.draw_buffer].wrapping_add(1);
        self.scene_dirty = true;
    }

    fn mark_all_buffers_dirty(&mut self) {
        for generation in &mut self.scene_generations {
            *generation = generation.wrapping_add(1);
        }
        self.scene_dirty = true;
    }

    pub fn displayed_scene(&self) -> &ArtistScene {
        &self.scenes[self.display_buffer]
    }

    pub fn graphics_mode(&self) -> GraphicsMode {
        self.graphics_mode
    }

    pub fn set_graphics_mode(&mut self, mode: GraphicsMode) {
        self.graphics_mode = mode;
        self.mark_all_buffers_dirty();
    }

    pub fn scene_source(&self) -> String {
        self.source_for(self.draw_buffer)
    }

    pub fn displayed_scene_source(&self) -> String {
        self.source_for(self.display_buffer)
    }

    fn source_for(&self, buffer: usize) -> String {
        let mut source = self.scenes[buffer].to_artist_script();
        if self.graphics_mode == GraphicsMode::Perspective3D {
            source.push_str(&self.perspective_world.to_artist_commands());
        }
        source
    }

    pub fn configure_perspective(
        &mut self,
        horizon_x: f64,
        horizon_y: f64,
        focal_length: f64,
        near: f64,
        far: f64,
        ambient: f64,
    ) -> Result<(), Error> {
        self.perspective_world
            .configure(horizon_x, horizon_y, focal_length, near, far, ambient)?;
        self.graphics_mode = GraphicsMode::Perspective3D;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn set_perspective_camera(&mut self, x: f64, y: f64, z: f64) -> Result<(), Error> {
        self.perspective_world.set_camera(x, y, z)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    pub fn define_perspective_object(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
        width: f64,
        height: f64,
        fill: &str,
        stroke: &str,
    ) -> Result<(), Error> {
        self.perspective_world
            .define_object(id, x, y, z, width, height, fill, stroke)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn set_perspective_pixel(
        &mut self,
        x: f64,
        y: f64,
        z: f64,
        fill: &str,
    ) -> Result<(), Error> {
        self.perspective_world.set_pixel(x, y, z, fill)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn unset_perspective_pixel(&mut self, x: f64, y: f64, z: f64) -> Result<(), Error> {
        self.perspective_world.unset_pixel(x, y, z)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn move_perspective_object(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
    ) -> Result<(), Error> {
        self.perspective_world.move_object(id, x, y, z)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn scale_perspective_object(
        &mut self,
        id: &str,
        width: f64,
        height: f64,
    ) -> Result<(), Error> {
        self.perspective_world.scale_object(id, width, height)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    pub fn define_perspective_light(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
        intensity: f64,
        range: f64,
        color: &str,
    ) -> Result<(), Error> {
        self.perspective_world
            .define_light(id, x, y, z, intensity, range, color)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn remove_perspective_object(&mut self, id: &str) -> Result<(), Error> {
        self.perspective_world.remove_object(id)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn clear_perspective_world(&mut self) {
        self.perspective_world.clear();
        self.mark_all_buffers_dirty();
    }

    pub fn perspective_object_state(&self, id: &str) -> Option<[f64; 6]> {
        self.perspective_world.object_state(id)
    }

    /// True when ordinary drawing commands affect the visible front buffer.
    pub fn drawing_is_visible(&self) -> bool {
        self.draw_buffer == self.display_buffer
    }

    pub fn select_draw_buffer(&mut self, index: i64) -> Result<(), Error> {
        let index = usize::try_from(index).map_err(|_| Error::IllegalQuantity)?;
        if index >= GRAPHICS_BUFFER_COUNT {
            return Err(Error::IllegalQuantity);
        }
        self.draw_buffer = index;
        self.sync_coordinate_state()
    }

    pub fn copy_page(&mut self, source: i64, destination: i64) -> Result<(), Error> {
        let source = usize::try_from(source).map_err(|_| Error::IllegalQuantity)?;
        let destination = usize::try_from(destination).map_err(|_| Error::IllegalQuantity)?;
        if source >= GRAPHICS_BUFFER_COUNT || destination >= GRAPHICS_BUFFER_COUNT {
            return Err(Error::IllegalQuantity);
        }
        if source == destination {
            return Ok(());
        }
        self.rasterize_buffer_if_dirty(source)?;
        self.scenes[destination] = self.scenes[source].clone();
        self.framebuffers[destination] = self.framebuffers[source].clone();
        self.scene_generations[destination] = self.scene_generations[source];
        self.framebuffer_generations[destination] = self.framebuffer_generations[source];
        self.sprites[destination] = self.sprites[source].clone();
        self.applied_viewports[destination] = self.applied_viewports[source];
        self.applied_windows[destination] = self.applied_windows[source];
        self.scene_dirty = true;
        Ok(())
    }

    pub fn set_viewport(
        &mut self,
        left: i64,
        top: i64,
        right: i64,
        bottom: i64,
        screen_coordinates: bool,
    ) -> Result<(), Error> {
        let left = usize::try_from(left).map_err(|_| Error::IllegalQuantity)?;
        let top = usize::try_from(top).map_err(|_| Error::IllegalQuantity)?;
        let right = usize::try_from(right).map_err(|_| Error::IllegalQuantity)?;
        let bottom = usize::try_from(bottom).map_err(|_| Error::IllegalQuantity)?;
        let (width, height) = self.dimensions();
        if left > right
            || top > bottom
            || right >= width
            || bottom >= height
            || (self.window.is_some() && (left == right || top == bottom))
        {
            return Err(Error::IllegalQuantity);
        }
        self.viewport = Some(Viewport {
            left,
            top,
            right,
            bottom,
            screen_coordinates,
        });
        self.mark_draw_buffer_dirty();
        self.append_coordinate_state()
    }

    pub fn reset_viewport(&mut self) -> Result<(), Error> {
        self.viewport = None;
        self.mark_draw_buffer_dirty();
        self.append_coordinate_state()
    }

    pub fn set_window(
        &mut self,
        x1: f64,
        y1: f64,
        x2: f64,
        y2: f64,
        screen_coordinates: bool,
    ) -> Result<(), Error> {
        if [x1, y1, x2, y2].iter().any(|value| !value.is_finite()) || x1 == x2 || y1 == y2 {
            return Err(Error::IllegalQuantity);
        }
        let (left, top, right, bottom) = self.device_mapping_bounds();
        if left == right || top == bottom {
            return Err(Error::IllegalQuantity);
        }
        self.window = Some(WindowMapping {
            x1,
            y1,
            x2,
            y2,
            screen_coordinates,
        });
        self.mark_draw_buffer_dirty();
        self.append_coordinate_state()
    }

    pub fn reset_window(&mut self) -> Result<(), Error> {
        self.window = None;
        self.mark_draw_buffer_dirty();
        self.append_coordinate_state()
    }

    pub fn draw_viewport_decoration(
        &mut self,
        fill: Option<&str>,
        border: Option<&str>,
    ) -> Result<(), Error> {
        if fill.is_none() && border.is_none() {
            return Ok(());
        }
        let viewport = self.viewport.ok_or_else(|| {
            Error::syntax("viewport decoration requires an active graphics viewport")
        })?;
        let fill = fill.map(parse_argb).transpose()?;
        let border = border.map(parse_argb).transpose()?;
        self.rasterize_if_dirty()?;
        let width = viewport.right - viewport.left + 1;
        let height = viewport.bottom - viewport.top + 1;
        let framebuffer = &self.framebuffers[self.draw_buffer];
        let mut pixels = Vec::with_capacity(width.saturating_mul(height));
        for row in 0..height {
            for column in 0..width {
                let edge = row == 0 || column == 0 || row + 1 == height || column + 1 == width;
                let previous = framebuffer.get_pixel(viewport.left + column, viewport.top + row);
                pixels.push(if edge {
                    border.or(fill).unwrap_or(previous)
                } else {
                    fill.unwrap_or(previous)
                });
            }
        }
        self.append_device_raster(viewport.left, viewport.top, width, height, &pixels)
    }

    pub fn map_point(&self, x: f64, y: f64) -> (f64, f64) {
        let (scale_x, scale_y, translate_x, translate_y) = self.coordinate_transform();
        (x * scale_x + translate_x, y * scale_y + translate_y)
    }

    pub(crate) fn pmap(&self, coordinate: f64, direction: i64) -> Result<f64, Error> {
        if self.window.is_none() {
            return Err(Error::syntax("PMAP requires an active WINDOW mapping"));
        }
        let (scale_x, scale_y, translate_x, translate_y) = self.coordinate_transform();
        match direction {
            0 => Ok(coordinate * scale_x + translate_x),
            1 => Ok(coordinate * scale_y + translate_y),
            2 => Ok((coordinate - translate_x) / scale_x),
            3 => Ok((coordinate - translate_y) / scale_y),
            _ => Err(Error::IllegalQuantity),
        }
    }

    pub fn capture_region(
        &mut self,
        x1: f64,
        y1: f64,
        x2: f64,
        y2: f64,
    ) -> Result<(usize, usize, Vec<u32>), Error> {
        let (x1, y1) = self.map_point(x1, y1);
        let (x2, y2) = self.map_point(x2, y2);
        let left = checked_screen_coordinate(x1.min(x2))?;
        let top = checked_screen_coordinate(y1.min(y2))?;
        let right = checked_screen_coordinate(x1.max(x2))?;
        let bottom = checked_screen_coordinate(y1.max(y2))?;
        let framebuffer = self.framebuffer()?;
        if right >= framebuffer.width || bottom >= framebuffer.height {
            return Err(Error::IllegalQuantity);
        }
        let width = right - left + 1;
        let height = bottom - top + 1;
        let mut pixels = Vec::with_capacity(width.saturating_mul(height));
        for y in top..=bottom {
            let start = y * framebuffer.width + left;
            pixels.extend_from_slice(&framebuffer.pixels[start..start + width]);
        }
        Ok((width, height, pixels))
    }

    pub fn put_region(
        &mut self,
        x: f64,
        y: f64,
        width: usize,
        height: usize,
        source: &[u32],
        action: RasterAction,
    ) -> Result<(), Error> {
        let expected = width.checked_mul(height).ok_or(Error::IllegalQuantity)?;
        if width == 0 || height == 0 || source.len() != expected {
            return Err(Error::IllegalQuantity);
        }
        let (x, y) = self.map_point(x, y);
        let (screen_width, screen_height) = self.dimensions();
        if action == RasterAction::Pset
            && x == 0.0
            && y == 0.0
            && width == screen_width
            && height == screen_height
            && self.viewport.is_none()
            && self.window.is_none()
            && self.scenes[self.draw_buffer].replace_opaque_raster(source)?
        {
            // The entire old framebuffer is covered: rendering it first is
            // wasted work. Keep the retained scene and pixel buffer in sync.
            self.mark_draw_buffer_dirty();
            self.framebuffers[self.draw_buffer].blit_opaque(source, width, height, 0, 0);
            self.framebuffer_generations[self.draw_buffer] =
                self.scene_generations[self.draw_buffer];
            return Ok(());
        }
        self.rasterize_if_dirty()?;
        let x = checked_signed_screen_coordinate(x)?;
        let y = checked_signed_screen_coordinate(y)?;
        let framebuffer = &self.framebuffers[self.draw_buffer];
        let mut left = x.max(0);
        let mut top = y.max(0);
        let mut right = x
            .checked_add(i64::try_from(width).map_err(|_| Error::IllegalQuantity)? - 1)
            .ok_or(Error::IllegalQuantity)?
            .min(framebuffer.width.saturating_sub(1) as i64);
        let mut bottom = y
            .checked_add(i64::try_from(height).map_err(|_| Error::IllegalQuantity)? - 1)
            .ok_or(Error::IllegalQuantity)?
            .min(framebuffer.height.saturating_sub(1) as i64);
        if let Some(viewport) = self.viewport {
            left = left.max(viewport.left as i64);
            top = top.max(viewport.top as i64);
            right = right.min(viewport.right as i64);
            bottom = bottom.min(viewport.bottom as i64);
        }
        if left > right || top > bottom {
            return Ok(());
        }
        let copy_width = usize::try_from(right - left + 1).map_err(|_| Error::IllegalQuantity)?;
        let copy_height = usize::try_from(bottom - top + 1).map_err(|_| Error::IllegalQuantity)?;
        let source_x = usize::try_from(left - x).map_err(|_| Error::IllegalQuantity)?;
        let source_y = usize::try_from(top - y).map_err(|_| Error::IllegalQuantity)?;
        let left = usize::try_from(left).map_err(|_| Error::IllegalQuantity)?;
        let top = usize::try_from(top).map_err(|_| Error::IllegalQuantity)?;

        // A captured GET image is normally opaque and restored without
        // clipping. In that common animation path, retain and blit its shared
        // pixels directly: no destination reads, action dispatch, or temporary
        // framebuffer-sized result allocation is required.
        if action == RasterAction::Pset
            && source_x == 0
            && source_y == 0
            && copy_width == width
            && copy_height == height
            && source.iter().all(|pixel| pixel >> 24 == 0xff)
        {
            return self.append_device_raster(left, top, width, height, source);
        }

        let mut result = Vec::with_capacity(copy_width.saturating_mul(copy_height));
        if action == RasterAction::Pset {
            for row in 0..copy_height {
                for column in 0..copy_width {
                    let source_pixel = source[(source_y + row) * width + source_x + column];
                    result.push(0xff00_0000 | (source_pixel & 0x00ff_ffff));
                }
            }
        } else {
            for row in 0..copy_height {
                for column in 0..copy_width {
                    let source_pixel = source[(source_y + row) * width + source_x + column];
                    let destination = framebuffer.get_pixel(left + column, top + row);
                    result.push(apply_raster_action(destination, source_pixel, action));
                }
            }
        }
        self.append_device_raster(left, top, copy_width, copy_height, &result)
    }

    fn coordinate_transform(&self) -> (f64, f64, f64, f64) {
        if let Some(window) = self.window {
            let (left, top, right, bottom) = self.device_mapping_bounds();
            let scale_x = (right - left) / (window.x2 - window.x1);
            let translate_x = left - window.x1 * scale_x;
            let scale_y = if window.screen_coordinates {
                (bottom - top) / (window.y2 - window.y1)
            } else {
                (top - bottom) / (window.y2 - window.y1)
            };
            let y_origin = if window.screen_coordinates {
                top
            } else {
                bottom
            };
            let translate_y = y_origin - window.y1 * scale_y;
            (scale_x, scale_y, translate_x, translate_y)
        } else if let Some(viewport) = self.viewport {
            if viewport.screen_coordinates {
                (1.0, 1.0, 0.0, 0.0)
            } else {
                (1.0, 1.0, viewport.left as f64, viewport.top as f64)
            }
        } else {
            (1.0, 1.0, 0.0, 0.0)
        }
    }

    fn device_mapping_bounds(&self) -> (f64, f64, f64, f64) {
        self.viewport.map_or_else(
            || {
                let (width, height) = self.dimensions();
                (
                    0.0,
                    0.0,
                    width.saturating_sub(1) as f64,
                    height.saturating_sub(1) as f64,
                )
            },
            |viewport| {
                (
                    viewport.left as f64,
                    viewport.top as f64,
                    viewport.right as f64,
                    viewport.bottom as f64,
                )
            },
        )
    }

    fn append_coordinate_state(&mut self) -> Result<(), Error> {
        let clip = self
            .viewport
            .map(|viewport| (viewport.left, viewport.top, viewport.right, viewport.bottom));
        let transform = self.coordinate_transform();
        let scene = &mut self.scenes[self.draw_buffer];
        scene.set_clip(clip)?;
        scene.set_coordinate_transform(transform.0, transform.1, transform.2, transform.3)?;
        self.applied_viewports[self.draw_buffer] = self.viewport;
        self.applied_windows[self.draw_buffer] = self.window;
        self.pixel_batch_safe[self.draw_buffer] = false;
        Ok(())
    }

    fn sync_coordinate_state(&mut self) -> Result<(), Error> {
        if self.applied_viewports[self.draw_buffer] == self.viewport
            && self.applied_windows[self.draw_buffer] == self.window
        {
            return Ok(());
        }
        self.mark_draw_buffer_dirty();
        self.append_coordinate_state()
    }

    fn append_device_raster(
        &mut self,
        left: usize,
        top: usize,
        width: usize,
        height: usize,
        pixels: &[u32],
    ) -> Result<(), Error> {
        self.mark_draw_buffer_dirty();
        self.scenes[self.draw_buffer].raster_blit(left, top, width, height, pixels)?;
        self.framebuffers[self.draw_buffer].blit_opaque(pixels, width, height, left, top);
        self.framebuffer_generations[self.draw_buffer] = self.scene_generations[self.draw_buffer];
        Ok(())
    }

    pub fn flip(&mut self) -> Result<(), Error> {
        self.display_buffer = self.draw_buffer;
        self.draw_buffer = (self.draw_buffer + 1) % GRAPHICS_BUFFER_COUNT;
        self.sync_coordinate_state()
    }

    pub fn foreground(&self) -> &str {
        &self.foreground
    }

    pub fn background(&self) -> &str {
        &self.background
    }

    pub fn set_foreground(&mut self, color: &str) {
        self.foreground = color.to_string();
    }

    pub fn set_background(&mut self, color: &str) {
        self.background = color.to_string();
    }

    /// Retain the classic screen-border color even on shells without a
    /// separately renderable border region.
    pub fn set_border_color(&mut self, color: &str) {
        self.border_color = color.to_string();
    }

    pub fn border_color(&self) -> &str {
        &self.border_color
    }

    pub fn palette_color(&self, index: i64) -> Result<&str, Error> {
        let index = usize::try_from(index).map_err(|_| Error::IllegalQuantity)?;
        if index >= MAX_PALETTE_COLORS {
            return Err(Error::IllegalQuantity);
        }
        self.palette
            .get(index)
            .map(String::as_str)
            .ok_or(Error::IllegalQuantity)
    }

    pub fn set_palette_color(&mut self, index: i64, color: &str) -> Result<(), Error> {
        let index = usize::try_from(index).map_err(|_| Error::IllegalQuantity)?;
        if index >= MAX_PALETTE_COLORS {
            return Err(Error::IllegalQuantity);
        }
        if index >= self.palette.len() {
            self.palette.resize(index + 1, "#000000".to_string());
        }
        self.palette[index] = color.to_string();
        Ok(())
    }

    pub fn cursor(&self) -> (f64, f64) {
        let x = self.cursor_x.parse().unwrap_or(0.0);
        let y = self.cursor_y.parse().unwrap_or(0.0);
        (x, y)
    }

    pub fn set_cursor(&mut self, x: f64, y: f64) {
        self.cursor_x = x.to_string();
        self.cursor_y = y.to_string();
    }

    #[allow(clippy::too_many_arguments)]
    pub fn set_bitmap_font(
        &mut self,
        path: &str,
        cell_width: usize,
        cell_height: usize,
        first_codepoint: u32,
    ) -> Result<(), Error> {
        if path.is_empty()
            || cell_width == 0
            || cell_height == 0
            || cell_width > 4096
            || cell_height > 4096
            || char::from_u32(first_codepoint).is_none()
        {
            return Err(Error::IllegalQuantity);
        }
        self.bitmap_font = Some(BitmapFontSelection {
            path: path.to_string(),
            cell_width,
            cell_height,
            first_codepoint,
        });
        Ok(())
    }

    pub fn use_builtin_font(&mut self) {
        self.bitmap_font = None;
    }

    pub fn text(&mut self, x: f64, y: f64, size: f64, text: &str, fill: &str) -> Result<(), Error> {
        if let Some(font) = self.bitmap_font.clone() {
            self.scene_mut().bitmap_font_text(
                x,
                y,
                size,
                text,
                fill,
                &font.path,
                font.cell_width,
                font.cell_height,
                font.first_codepoint,
            )
        } else {
            self.scene_mut().text(x, y, size, text, fill)
        }
    }

    #[allow(clippy::too_many_arguments)]
    pub fn image_sprite(
        &mut self,
        id: &str,
        path: &str,
        x: f64,
        y: f64,
        width: f64,
        height: f64,
        transparent: Option<&str>,
    ) -> Result<(), Error> {
        if self.perspective_world.has_sprite(id) {
            return Err(Error::syntax(format!(
                "sprite {id} already has retained XYZ coordinates"
            )));
        }
        self.scene_mut()
            .bitmap_sprite(id, path, x, y, width, height, transparent)?;
        self.sprites[self.draw_buffer].insert(
            id.to_ascii_uppercase(),
            SpriteBounds {
                x,
                y,
                width,
                height,
                velocity_x: 0.0,
                velocity_y: 0.0,
                acceleration_x: 0.0,
                acceleration_y: 0.0,
            },
        );
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    pub fn sprite(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        width: f64,
        height: f64,
        fill: &str,
        stroke: &str,
    ) -> Result<(), Error> {
        if self.perspective_world.has_sprite(id) {
            return Err(Error::syntax(format!(
                "sprite {id} already has retained XYZ coordinates"
            )));
        }
        self.scene_mut()
            .sprite(id, x, y, width, height, fill, stroke)?;
        self.sprites[self.draw_buffer].insert(
            id.to_ascii_uppercase(),
            SpriteBounds {
                x,
                y,
                width,
                height,
                velocity_x: 0.0,
                velocity_y: 0.0,
                acceleration_x: 0.0,
                acceleration_y: 0.0,
            },
        );
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    pub fn perspective_sprite(
        &mut self,
        id: &str,
        x: f64,
        y: f64,
        z: f64,
        width: f64,
        height: f64,
        fill: &str,
        stroke: &str,
    ) -> Result<(), Error> {
        let key = id.to_ascii_uppercase();
        if self
            .sprites
            .iter()
            .any(|sprites| sprites.contains_key(&key))
        {
            return Err(Error::syntax(format!(
                "sprite {id} already has 2D screen coordinates"
            )));
        }
        self.perspective_world
            .define_sprite(id, x, y, z, width, height, fill, stroke)?;
        self.mark_all_buffers_dirty();
        Ok(())
    }
    #[allow(clippy::too_many_arguments)]
    pub fn perspective_image_sprite(
        &mut self,
        id: &str,
        path: &str,
        x: f64,
        y: f64,
        z: f64,
        width: f64,
        height: f64,
        transparent: Option<&str>,
    ) -> Result<(), Error> {
        let key = id.to_ascii_uppercase();
        if self
            .sprites
            .iter()
            .any(|sprites| sprites.contains_key(&key))
        {
            return Err(Error::syntax(format!(
                "sprite {id} already has 2D screen coordinates"
            )));
        }
        self.perspective_world.define_image_sprite(
            id,
            path,
            x,
            y,
            z,
            width,
            height,
            transparent,
        )?;
        self.graphics_mode = GraphicsMode::Perspective3D;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn move_sprite(&mut self, id: &str, x: f64, y: f64, z: Option<f64>) -> Result<(), Error> {
        if let Some(state) = self.perspective_world.sprite_state(id) {
            self.perspective_world
                .move_sprite(id, x, y, z.unwrap_or(state[2]))?;
            self.mark_all_buffers_dirty();
            return Ok(());
        }
        if z.is_some() {
            return Err(Error::syntax(format!("undefined XYZ sprite {id}")));
        }
        let key = id.to_ascii_uppercase();
        if !self.sprites[self.draw_buffer].contains_key(&key) {
            return Err(Error::syntax(format!("undefined sprite {id}")));
        }
        self.scene_mut().move_sprite(id, x, y)?;
        let sprite = self.sprites[self.draw_buffer]
            .get_mut(&key)
            .expect("validated 2D sprite");
        sprite.x = x;
        sprite.y = y;
        Ok(())
    }

    pub fn set_sprite_motion(
        &mut self,
        id: &str,
        velocity: [f64; 3],
        acceleration: [f64; 3],
    ) -> Result<(), Error> {
        if velocity
            .iter()
            .chain(acceleration.iter())
            .any(|value| !value.is_finite())
        {
            return Err(Error::IllegalQuantity);
        }
        if self.perspective_world.has_sprite(id) {
            return self
                .perspective_world
                .set_sprite_motion(id, velocity, acceleration);
        }
        if velocity[2] != 0.0 || acceleration[2] != 0.0 {
            return Err(Error::syntax(format!(
                "sprite {id} does not have a Z coordinate"
            )));
        }
        let sprite = self.sprites[self.draw_buffer]
            .get_mut(&id.to_ascii_uppercase())
            .ok_or_else(|| Error::syntax(format!("undefined sprite {id}")))?;
        sprite.velocity_x = velocity[0];
        sprite.velocity_y = velocity[1];
        sprite.acceleration_x = acceleration[0];
        sprite.acceleration_y = acceleration[1];
        Ok(())
    }

    pub fn orient_sprite(&mut self, id: &str, mode: &str) -> Result<(), Error> {
        let horizon_aligned = match mode.to_ascii_uppercase().as_str() {
            "HORIZON" => true,
            "SCREEN" => false,
            _ => {
                return Err(Error::syntax(
                    "SPRITE ORIENT mode must be HORIZON or SCREEN",
                ))
            }
        };
        self.perspective_world
            .set_sprite_horizon_alignment(id, horizon_aligned)?;
        self.graphics_mode = GraphicsMode::Perspective3D;
        self.mark_all_buffers_dirty();
        Ok(())
    }

    pub fn advance_sprites(&mut self, seconds: f64) -> Result<(), Error> {
        if !seconds.is_finite() || !(0.0..=60.0).contains(&seconds) {
            return Err(Error::IllegalQuantity);
        }
        let mut updates = Vec::with_capacity(self.sprites[self.draw_buffer].len());
        for (id, sprite) in &self.sprites[self.draw_buffer] {
            let x = sprite.x
                + sprite.velocity_x * seconds
                + 0.5 * sprite.acceleration_x * seconds * seconds;
            let y = sprite.y
                + sprite.velocity_y * seconds
                + 0.5 * sprite.acceleration_y * seconds * seconds;
            let velocity_x = sprite.velocity_x + sprite.acceleration_x * seconds;
            let velocity_y = sprite.velocity_y + sprite.acceleration_y * seconds;
            if !x.is_finite()
                || !y.is_finite()
                || !velocity_x.is_finite()
                || !velocity_y.is_finite()
            {
                return Err(Error::IllegalQuantity);
            }
            updates.push((id.clone(), x, y, velocity_x, velocity_y));
        }
        self.perspective_world.advance_sprites(seconds)?;
        self.mark_all_buffers_dirty();
        for (id, x, y, velocity_x, velocity_y) in updates {
            let sprite = self.sprites[self.draw_buffer]
                .get_mut(&id)
                .expect("validated 2D sprite");
            sprite.x = x;
            sprite.y = y;
            sprite.velocity_x = velocity_x;
            sprite.velocity_y = velocity_y;
            self.scene_mut().move_sprite(&id, x, y)?;
        }
        Ok(())
    }

    pub fn sprite_motion(&self, id: &str) -> Option<[f64; 6]> {
        self.sprites[self.draw_buffer]
            .get(&id.to_ascii_uppercase())
            .map(|sprite| {
                [
                    sprite.x,
                    sprite.y,
                    sprite.velocity_x,
                    sprite.velocity_y,
                    sprite.acceleration_x,
                    sprite.acceleration_y,
                ]
            })
            .or_else(|| {
                self.perspective_world.sprite_state(id).map(|sprite| {
                    [
                        sprite[0], sprite[1], sprite[6], sprite[7], sprite[9], sprite[10],
                    ]
                })
            })
    }

    pub fn sprite_depth(&self, id: &str) -> Option<[f64; 4]> {
        if let Some(sprite) = self.perspective_world.sprite_state(id) {
            return Some([sprite[2], sprite[3], sprite[8], sprite[11]]);
        }
        self.sprites[self.draw_buffer]
            .contains_key(&id.to_ascii_uppercase())
            .then_some([0.0, 1.0, 0.0, 0.0])
    }

    /// Test one sprite against another, or against every other sprite when
    /// `second` is omitted. Missing sprites and edge-only contact are not
    /// collisions. XYZ sprites use their current projected screen bounds.
    pub fn sprites_collide(&self, first: &str, second: Option<&str>) -> bool {
        let sprites = self.current_sprite_bounds();
        let first_name = first.to_ascii_uppercase();
        let Some(first_bounds) = sprites.get(&first_name).copied() else {
            return false;
        };
        if let Some(second) = second {
            return sprites
                .get(&second.to_ascii_uppercase())
                .copied()
                .is_some_and(|second_bounds| first_bounds.intersects(second_bounds));
        }
        sprites
            .iter()
            .any(|(name, bounds)| name != &first_name && first_bounds.intersects(*bounds))
    }

    /// Whether any two nonempty sprites in the current draw buffer overlap.
    /// Sorting by the projected left edge avoids comparisons separated on X.
    pub fn any_sprite_collision(&self) -> bool {
        let mut sprites = self
            .current_sprite_bounds()
            .into_values()
            .filter(|sprite| sprite.width > 0.0 && sprite.height > 0.0)
            .collect::<Vec<_>>();
        sprites.sort_by(|left, right| left.x.total_cmp(&right.x));
        for (index, sprite) in sprites.iter().copied().enumerate() {
            for other in sprites[index + 1..].iter().copied() {
                if other.x >= sprite.x + sprite.width {
                    break;
                }
                if sprite.intersects(other) {
                    return true;
                }
            }
        }
        false
    }

    fn current_sprite_bounds(&self) -> HashMap<String, SpriteBounds> {
        let mut sprites = self.sprites[self.draw_buffer].clone();
        for (id, [x, y, width, height]) in self.perspective_world.projected_sprites() {
            sprites.insert(
                id,
                SpriteBounds {
                    x,
                    y,
                    width,
                    height,
                    velocity_x: 0.0,
                    velocity_y: 0.0,
                    acceleration_x: 0.0,
                    acceleration_y: 0.0,
                },
            );
        }
        sprites
    }
}

/// Named logical render sizes commonly targeted by current desktop games.
/// These configure the BASIC framebuffer; the host window scales separately.
pub fn game_screen_preset_dimensions(name: &str) -> Option<(i64, i64)> {
    match name.to_ascii_uppercase().as_str() {
        "STANDARD" => Some((1024, 768)),
        "HD" | "720P" => Some((1280, 720)),
        "HDPLUS" | "900P" => Some((1600, 900)),
        "FULLHD" | "FHD" | "1080P" => Some((1920, 1080)),
        "QHD" | "1440P" => Some((2560, 1440)),
        "ULTRAWIDE" | "UWQHD" => Some((3440, 1440)),
        "UHD" | "4K" | "2160P" => Some((3840, 2160)),
        _ => None,
    }
}

pub fn screen_mode_dimensions(mode: i64) -> Result<(i64, i64, &'static str), Error> {
    match mode {
        0 => Ok((640, 400, "#000000")),
        1 | 7 | 13 => Ok((320, 200, "#000000")),
        2 | 8 => Ok((640, 200, "#000000")),
        9 | 10 => Ok((640, 350, "#000000")),
        11 | 12 => Ok((640, 480, "#000000")),
        _ => Err(Error::IllegalQuantity),
    }
}

fn default_palette() -> &'static [&'static str] {
    &[
        "#000000", "#0000aa", "#00aa00", "#00aaaa", "#aa0000", "#aa00aa", "#aa5500", "#aaaaaa",
        "#555555", "#5555ff", "#55ff55", "#55ffff", "#ff5555", "#ff55ff", "#ffff55", "#ffffff",
        "#000000", "#000033", "#000066", "#000099", "#0000cc", "#0000ff", "#003300", "#003333",
        "#003366", "#003399", "#0033cc", "#0033ff", "#006600", "#006633", "#006666", "#006699",
        "#0066cc", "#0066ff", "#009900", "#009933", "#009966", "#009999", "#0099cc", "#0099ff",
        "#00cc00", "#00cc33", "#00cc66", "#00cc99", "#00cccc", "#00ccff", "#00ff00", "#00ff33",
        "#00ff66", "#00ff99", "#00ffcc", "#00ffff", "#330000", "#330033", "#330066", "#330099",
        "#3300cc", "#3300ff", "#333300", "#333333", "#333366", "#333399", "#3333cc", "#3333ff",
        "#336600", "#336633", "#336666", "#336699", "#3366cc", "#3366ff", "#339900", "#339933",
        "#339966", "#339999", "#3399cc", "#3399ff", "#33cc00", "#33cc33", "#33cc66", "#33cc99",
        "#33cccc", "#33ccff", "#33ff00", "#33ff33", "#33ff66", "#33ff99", "#33ffcc", "#33ffff",
        "#660000", "#660033", "#660066", "#660099", "#6600cc", "#6600ff", "#663300", "#663333",
        "#663366", "#663399", "#6633cc", "#6633ff", "#666600", "#666633", "#666666", "#666699",
        "#6666cc", "#6666ff", "#669900", "#669933", "#669966", "#669999", "#6699cc", "#6699ff",
        "#66cc00", "#66cc33", "#66cc66", "#66cc99", "#66cccc", "#66ccff", "#66ff00", "#66ff33",
        "#66ff66", "#66ff99", "#66ffcc", "#66ffff", "#990000", "#990033", "#990066", "#990099",
        "#9900cc", "#9900ff", "#993300", "#993333", "#993366", "#993399", "#9933cc", "#9933ff",
        "#996600", "#996633", "#996666", "#996699", "#9966cc", "#9966ff", "#999900", "#999933",
        "#999966", "#999999", "#9999cc", "#9999ff", "#99cc00", "#99cc33", "#99cc66", "#99cc99",
        "#99cccc", "#99ccff", "#99ff00", "#99ff33", "#99ff66", "#99ff99", "#99ffcc", "#99ffff",
        "#cc0000", "#cc0033", "#cc0066", "#cc0099", "#cc00cc", "#cc00ff", "#cc3300", "#cc3333",
        "#cc3366", "#cc3399", "#cc33cc", "#cc33ff", "#cc6600", "#cc6633", "#cc6666", "#cc6699",
        "#cc66cc", "#cc66ff", "#cc9900", "#cc9933", "#cc9966", "#cc9999", "#cc99cc", "#cc99ff",
        "#cccc00", "#cccc33", "#cccc66", "#cccc99", "#cccccc", "#ccccff", "#ccff00", "#ccff33",
        "#ccff66", "#ccff99", "#ccffcc", "#ccffff", "#ff0000", "#ff0033", "#ff0066", "#ff0099",
        "#ff00cc", "#ff00ff", "#ff3300", "#ff3333", "#ff3366", "#ff3399", "#ff33cc", "#ff33ff",
        "#ff6600", "#ff6633", "#ff6666", "#ff6699", "#ff66cc", "#ff66ff", "#ff9900", "#ff9933",
        "#ff9966", "#ff9999", "#ff99cc", "#ff99ff", "#ffcc00", "#ffcc33", "#ffcc66", "#ffcc99",
        "#ffcccc", "#ffccff", "#ffff00", "#ffff33", "#ffff66", "#ffff99", "#ffffcc", "#ffffff",
        "#000000", "#0b0b0b", "#161616", "#212121", "#2c2c2c", "#373737", "#424242", "#4d4d4d",
        "#585858", "#636363", "#6e6e6e", "#797979", "#858585", "#909090", "#9b9b9b", "#a6a6a6",
        "#b1b1b1", "#bcbcbc", "#c7c7c7", "#d2d2d2", "#dddddd", "#e8e8e8", "#f3f3f3", "#ffffff",
    ]
}

#[cfg(test)]
#[allow(clippy::items_after_test_module)]
mod tests {
    use super::*;

    #[test]
    fn buffers_flip_without_losing_the_other_scene() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(320, 200, "#000000").unwrap();
        graphics
            .scene_mut()
            .line(0.0, 0.0, 10.0, 10.0, "#ffffff", 1.0)
            .unwrap();
        graphics.flip().unwrap();
        assert_eq!(graphics.displayed_scene().command_count(), 1);
        assert_eq!(graphics.scene().command_count(), 0);
    }

    #[test]
    fn clear_is_buffer_local_and_resets_all_drawing_state() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(32, 24, "#000000").unwrap();
        graphics
            .scene_mut()
            .line(1.0, 2.0, 10.0, 12.0, "#ffffff", 1.0)
            .unwrap();
        graphics.set_cursor(10.0, 12.0);
        graphics
            .sprite("DOT", 2.0, 3.0, 4.0, 5.0, "red", "none")
            .unwrap();
        graphics.flip().unwrap();

        assert_eq!(graphics.displayed_scene().command_count(), 2);
        graphics
            .scene_mut()
            .line(3.0, 4.0, 7.0, 8.0, "#00ff00", 1.0)
            .unwrap();
        graphics.set_cursor(7.0, 8.0);
        graphics.clear(Some("#123456")).unwrap();

        assert_eq!(graphics.scene().command_count(), 0);
        assert_eq!(graphics.cursor(), (0.0, 0.0));
        assert_eq!(graphics.framebuffer().unwrap().clear_color, 0xff123456);
        assert!(graphics
            .framebuffer()
            .unwrap()
            .pixels
            .iter()
            .all(|pixel| *pixel == 0xff123456));
        assert_eq!(graphics.displayed_scene().command_count(), 2);
    }

    #[test]
    fn classic_screen_modes_have_deterministic_sizes() {
        assert_eq!(screen_mode_dimensions(12).unwrap(), (640, 480, "#000000"));
        assert_eq!(screen_mode_dimensions(13).unwrap(), (320, 200, "#000000"));
        assert_eq!(
            screen_mode_dimensions(99).unwrap_err(),
            Error::IllegalQuantity
        );
    }

    #[test]
    fn modern_game_screen_presets_cover_standard_16_9_ultrawide_and_4k_targets() {
        assert_eq!(game_screen_preset_dimensions("HD"), Some((1280, 720)));
        assert_eq!(game_screen_preset_dimensions("900p"), Some((1600, 900)));
        assert_eq!(game_screen_preset_dimensions("fullhd"), Some((1920, 1080)));
        assert_eq!(game_screen_preset_dimensions("QHD"), Some((2560, 1440)));
        assert_eq!(
            game_screen_preset_dimensions("ultrawide"),
            Some((3440, 1440))
        );
        assert_eq!(game_screen_preset_dimensions("4K"), Some((3840, 2160)));
        assert_eq!(game_screen_preset_dimensions("unknown"), None);
    }

    #[test]
    fn sprite_collision_tracks_moves_clear_and_buffer_scope() {
        let mut graphics = GraphicsDevice::default();
        graphics
            .sprite("A", 0.0, 0.0, 10.0, 10.0, "red", "none")
            .unwrap();
        graphics
            .sprite("B", 10.0, 0.0, 5.0, 5.0, "blue", "none")
            .unwrap();
        assert!(!graphics.sprites_collide("A", Some("B")));
        graphics.move_sprite("B", 9.0, 0.0, None).unwrap();
        assert!(graphics.sprites_collide("a", Some("b")));
        assert!(graphics.sprites_collide("A", None));
        assert!(graphics.any_sprite_collision());
        graphics.select_draw_buffer(1).unwrap();
        assert!(!graphics.sprites_collide("A", Some("B")));
        graphics.select_draw_buffer(0).unwrap();
        graphics.clear(None).unwrap();
        assert!(!graphics.sprites_collide("A", Some("B")));
    }

    #[test]
    fn sprite_motion_integrates_velocity_and_acceleration_deterministically() {
        let mut graphics = GraphicsDevice::default();
        graphics
            .sprite("SHIP", 10.0, 20.0, 4.0, 3.0, "red", "none")
            .unwrap();
        graphics
            .set_sprite_motion("ship", [8.0, -2.0, 0.0], [4.0, 6.0, 0.0])
            .unwrap();
        graphics.advance_sprites(0.5).unwrap();
        assert_eq!(
            graphics.sprite_motion("SHIP").unwrap(),
            [14.5, 19.75, 10.0, 1.0, 4.0, 6.0]
        );
        assert!(graphics.advance_sprites(-0.1).is_err());
        assert!(graphics
            .set_sprite_motion("MISSING", [0.0; 3], [0.0; 3])
            .is_err());
    }

    #[test]
    fn failed_screen_changes_are_atomic_and_the_device_remains_usable() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(320, 180, "#102030").unwrap();
        graphics
            .scene_mut()
            .line(1.0, 2.0, 40.0, 20.0, "white", 2.0)
            .unwrap();
        let expected = graphics.clone();

        assert_eq!(
            graphics.set_screen(65_535, 65_535, "black").unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(graphics, expected);
        assert!(graphics
            .set_screen(640, 360, "bad\nartist-command")
            .is_err());
        assert_eq!(graphics, expected);

        graphics.set_screen(64, 48, "black").unwrap();
        graphics
            .scene_mut()
            .rectangle(2.0, 2.0, 30.0, 20.0, "white", "blue", 1.0)
            .unwrap();
        assert_eq!(graphics.scene().command_count(), 1);
    }

    #[test]
    fn framebuffer_queries_lazily_rasterize_new_scene_commands() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(4, 4, "#000000").unwrap();
        let initial_generation = graphics.generation();
        graphics.scene_mut().pixel(2.0, 1.0, "#ff0000").unwrap();
        assert_ne!(graphics.generation(), initial_generation);
        assert_eq!(graphics.get_pixel(2, 1).unwrap(), 0xffff0000);
        assert!(!graphics.rasterize_if_dirty().unwrap());
    }

    #[test]
    fn pset_batches_scanlines_and_preserves_true_color_pixels() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(5, 3, "#000000").unwrap();
        graphics.plot_pixel(1.0, 1.0, "#ff0000").unwrap();
        graphics.plot_pixel(2.0, 1.0, "#00ff00").unwrap();
        graphics.plot_pixel(3.0, 1.0, "#0000ff80").unwrap();
        assert!(graphics
            .scene_source()
            .contains("raster 1 1 3 1 ffff0000 ff00ff00 800000ff"));
        assert_eq!(graphics.get_pixel(1, 1).unwrap(), 0xffff0000);
        assert_eq!(graphics.get_pixel(2, 1).unwrap(), 0xff00ff00);

        graphics
            .scene_mut()
            .line(0.0, 2.0, 4.0, 2.0, "#ffffff", 1.0)
            .unwrap();
        graphics.plot_pixel(0.0, 0.0, "#ffff00").unwrap();
        let source = graphics.scene_source();
        assert!(source.find("raster 1 1 3 1").unwrap() < source.find("line 0 2 4 2").unwrap());
        assert!(source.find("line 0 2 4 2").unwrap() < source.find("pixel 0 0").unwrap());
    }

    #[test]
    fn viewport_clips_and_offsets_subsequent_drawing() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(8, 8, "#000000").unwrap();
        graphics.set_viewport(2, 2, 5, 5, false).unwrap();
        graphics
            .scene_mut()
            .line(-4.0, 1.0, 8.0, 1.0, "#ff0000", 1.0)
            .unwrap();
        assert_eq!(graphics.get_pixel(1, 3).unwrap(), 0xff000000);
        assert_eq!(graphics.get_pixel(2, 3).unwrap(), 0xffff0000);
        assert_eq!(graphics.get_pixel(5, 3).unwrap(), 0xffff0000);
        assert_eq!(graphics.get_pixel(6, 3).unwrap(), 0xff000000);
    }

    #[test]
    fn window_mapping_and_pmap_support_both_y_conventions() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(11, 11, "#000000").unwrap();
        graphics.set_window(0.0, 0.0, 10.0, 10.0, false).unwrap();
        assert_eq!(graphics.map_point(0.0, 0.0), (0.0, 10.0));
        assert_eq!(graphics.map_point(10.0, 10.0), (10.0, 0.0));
        assert_eq!(graphics.pmap(5.0, 0).unwrap(), 5.0);
        assert_eq!(graphics.pmap(5.0, 1).unwrap(), 5.0);
        graphics.set_window(0.0, 0.0, 10.0, 10.0, true).unwrap();
        assert_eq!(graphics.map_point(0.0, 0.0), (0.0, 0.0));
        assert_eq!(graphics.pmap(10.0, 3).unwrap(), 10.0);
    }

    #[test]
    fn retained_raster_put_supports_actions_and_page_copy() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(4, 3, "#000000").unwrap();
        graphics
            .put_region(1.0, 1.0, 1, 1, &[0xffff0000], RasterAction::Pset)
            .unwrap();
        assert_eq!(graphics.get_pixel(1, 1).unwrap(), 0xffff0000);
        graphics
            .put_region(1.0, 1.0, 1, 1, &[0xffff0000], RasterAction::Xor)
            .unwrap();
        assert_eq!(graphics.get_pixel(1, 1).unwrap(), 0xff000000);
        graphics
            .put_region(2.0, 1.0, 1, 1, &[0xff00ff00], RasterAction::Preset)
            .unwrap();
        assert_eq!(graphics.get_pixel(2, 1).unwrap(), 0xffff00ff);
        graphics.copy_page(0, 1).unwrap();
        graphics.select_draw_buffer(1).unwrap();
        assert_eq!(graphics.get_pixel(2, 1).unwrap(), 0xffff00ff);
        assert!(graphics.scene_source().contains("raster 2 1 1 1 ffff00ff"));
    }

    #[test]
    fn full_background_restore_discards_covered_drawings_on_both_pages() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(16, 8, "black").unwrap();
        let pixels = vec![0xff12_3456; 16 * 8];
        for _ in 0..40 {
            graphics
                .scene_mut()
                .rectangle(2.0, 2.0, 3.0, 3.0, "red", "red", 1.0)
                .unwrap();
            graphics
                .put_region(0.0, 0.0, 16, 8, &pixels, RasterAction::Pset)
                .unwrap();
            assert_eq!(graphics.scene().command_count(), 1);
            assert_eq!(graphics.get_pixel(3, 3).unwrap(), 0xff12_3456);
            graphics.scene_mut().pixel(3.0, 3.0, "white").unwrap();
            assert_eq!(graphics.get_pixel(3, 3).unwrap(), 0xffffffff);
            assert_eq!(graphics.get_pixel(15, 7).unwrap(), 0xff12_3456);
            graphics.flip().unwrap();
        }
    }

    #[test]
    fn background_restore_preserves_partial_logical_and_clipped_puts() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(8, 8, "blue").unwrap();
        graphics
            .put_region(1.0, 1.0, 1, 1, &[0xffff0000], RasterAction::Pset)
            .unwrap();
        assert_eq!(graphics.get_pixel(0, 0).unwrap(), 0xff0000ff);
        assert_eq!(graphics.get_pixel(1, 1).unwrap(), 0xffff0000);
        graphics
            .put_region(0.0, 0.0, 8, 8, &[0xffff0000; 64], RasterAction::Xor)
            .unwrap();
        assert_eq!(graphics.get_pixel(0, 0).unwrap(), 0xffff00ff);
        assert_eq!(graphics.get_pixel(1, 1).unwrap(), 0xff000000);
        graphics.set_viewport(2, 2, 5, 5, true).unwrap();
        graphics
            .put_region(0.0, 0.0, 8, 8, &[0xff00ff00; 64], RasterAction::Pset)
            .unwrap();
        assert_eq!(graphics.get_pixel(0, 0).unwrap(), 0xffff00ff);
        assert_eq!(graphics.get_pixel(3, 3).unwrap(), 0xff00ff00);
        graphics
            .scene_mut()
            .line(0.0, 3.0, 7.0, 3.0, "white", 1.0)
            .unwrap();
        assert_eq!(graphics.get_pixel(0, 3).unwrap(), 0xffff00ff);
        assert_eq!(graphics.get_pixel(3, 3).unwrap(), 0xffffffff);
    }

    #[test]
    fn full_opaque_pset_uses_compact_retained_raster_and_preserves_pixels() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(32, 16, "#000000").unwrap();
        let pixels = vec![0xff12_3456; 32 * 16];
        graphics
            .put_region(0.0, 0.0, 32, 16, &pixels, RasterAction::Pset)
            .unwrap();
        assert_eq!(graphics.get_pixel(31, 15).unwrap(), 0xff12_3456);
        assert!(graphics.scene_source().contains("raster_rle 0 0 32 16"));
    }

    #[test]
    fn pset_still_forces_manually_supplied_array_pixels_opaque() {
        let mut graphics = GraphicsDevice::default();
        graphics.set_screen(2, 2, "#000000").unwrap();
        graphics
            .put_region(0.0, 0.0, 1, 1, &[0x0012_3456], RasterAction::Pset)
            .unwrap();
        assert_eq!(graphics.get_pixel(0, 0).unwrap(), 0xff12_3456);
    }
}

fn ppm_payload(ppm: &[u8]) -> Result<&[u8], Error> {
    if !ppm.starts_with(b"P6\n") {
        return Err(Error::Io(
            "graphics renderer returned an invalid PPM image".to_string(),
        ));
    }
    let mut newlines = ppm
        .iter()
        .enumerate()
        .filter_map(|(index, byte)| (*byte == b'\n').then_some(index));
    let header_end = newlines
        .nth(2)
        .and_then(|index| index.checked_add(1))
        .ok_or_else(|| Error::Io("graphics renderer returned a truncated PPM image".to_string()))?;
    Ok(&ppm[header_end..])
}

fn parse_argb(color: &str) -> Result<u32, Error> {
    let color = crate::artist_renderer::parse_color(color)?;
    Ok((u32::from(color.a) << 24)
        | (u32::from(color.r) << 16)
        | (u32::from(color.g) << 8)
        | u32::from(color.b))
}

fn checked_screen_coordinate(value: f64) -> Result<usize, Error> {
    if !value.is_finite() || value < 0.0 || value > usize::MAX as f64 {
        return Err(Error::IllegalQuantity);
    }
    Ok(value.round() as usize)
}

fn checked_signed_screen_coordinate(value: f64) -> Result<i64, Error> {
    if !value.is_finite() || value < i64::MIN as f64 || value > i64::MAX as f64 {
        return Err(Error::IllegalQuantity);
    }
    Ok(value.round() as i64)
}

fn apply_raster_action(destination: u32, source: u32, action: RasterAction) -> u32 {
    let destination = destination & 0x00ff_ffff;
    let source = source & 0x00ff_ffff;
    let rgb = match action {
        RasterAction::Pset => source,
        RasterAction::Preset => !source & 0x00ff_ffff,
        RasterAction::And => destination & source,
        RasterAction::Or => destination | source,
        RasterAction::Xor => destination ^ source,
    };
    0xff00_0000 | rgb
}
