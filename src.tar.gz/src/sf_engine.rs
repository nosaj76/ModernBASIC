//! SoundFont-based instrument synthesis using RustySynth.
//!
//! Provides real instrument sounds (piano, strings, brass, drums, etc.)
//! by loading a GM SoundFont (.sf2) file and rendering through the
//! RustySynth synthesizer.
//!
//! Used by the INSTRUMENT and SOUND statements when a SoundFont is loaded.

use std::collections::HashMap;
use std::io::{Cursor, Read, Write};
use std::sync::{Arc, OnceLock};

use crate::error::Error;
use crate::rustysynth::{SoundFont, Synthesizer, SynthesizerSettings};
use crate::synth::{
    check_audio_render_interrupt, midi_channel_for_voice, parse_note, PlaybackSession,
    SoundFontDsp, SoundFontEnvelope, MAX_REST_BEATS, MAX_SYNTH_SECONDS, MAX_WAV_BYTES, VOICE_COUNT,
};

const MAX_SCORE_NOTES: usize = 1_000_000;
const SCORE_RENDER_FRAMES: usize = 2_048;
const SCORE_RELEASE_TAIL_SECONDS: f64 = 2.0;
static DEFAULT_SOUNDFONT_CACHE: OnceLock<Arc<SoundFont>> = OnceLock::new();

fn default_voice_channels() -> [u8; VOICE_COUNT] {
    std::array::from_fn(|index| {
        midi_channel_for_voice((index + 1) as i64).expect("BASIC voice index is valid") as u8
    })
}

fn default_channel_controllers() -> [[u8; 128]; 16] {
    let mut controllers = [[0; 128]; 16];
    for channel in &mut controllers {
        channel[11] = 127;
    }
    controllers
}

/// GM instrument numbers (0-127) from the General MIDI standard.
pub const GM_INSTRUMENTS: &[(&str, u8)] = &[
    ("ACOUSTIC GRAND PIANO", 0),
    ("BRIGHT ACOUSTIC PIANO", 1),
    ("ELECTRIC GRAND PIANO", 2),
    ("HONKY-TONK PIANO", 3),
    ("ELECTRIC PIANO 1", 4),
    ("ELECTRIC PIANO 2", 5),
    ("HARPSICHORD", 6),
    ("CLAVI", 7),
    ("CELESTA", 8),
    ("GLOCKENSPIEL", 9),
    ("MUSIC BOX", 10),
    ("VIBRAPHONE", 11),
    ("MARIMBA", 12),
    ("XYLOPHONE", 13),
    ("TUBULAR BELLS", 14),
    ("DULCIMER", 15),
    ("DRAWBAR ORGAN", 16),
    ("PERCUSSIVE ORGAN", 17),
    ("ROCK ORGAN", 18),
    ("CHURCH ORGAN", 19),
    ("REED ORGAN", 20),
    ("ACCORDION", 21),
    ("HARMONICA", 22),
    ("TANGO ACCORDION", 23),
    ("ACOUSTIC GUITAR NYLON", 24),
    ("ACOUSTIC GUITAR STEEL", 25),
    ("ELECTRIC GUITAR JAZZ", 26),
    ("ELECTRIC GUITAR CLEAN", 27),
    ("ELECTRIC GUITAR MUTED", 28),
    ("OVERDRIVEN GUITAR", 29),
    ("DISTORTION GUITAR", 30),
    ("GUITAR HARMONICS", 31),
    ("ACOUSTIC BASS", 32),
    ("ELECTRIC BASS FINGER", 33),
    ("ELECTRIC BASS PICK", 34),
    ("ELECTRIC BASS FRETLESS", 35),
    ("SLAP BASS 1", 36),
    ("SLAP BASS 2", 37),
    ("SYNTH BASS 1", 38),
    ("SYNTH BASS 2", 39),
    ("VIOLIN", 40),
    ("VIOLA", 41),
    ("CELLO", 42),
    ("CONTRABASS", 43),
    ("TREMOLO STRINGS", 44),
    ("PIZZICATO STRINGS", 45),
    ("ORCHESTRAL STRINGS", 46),
    ("HARP", 46),
    ("TIMPANI", 47),
    ("STRING ENSEMBLE 1", 48),
    ("STRING ENSEMBLE 2", 49),
    ("SYNTH STRINGS 1", 50),
    ("SYNTH STRINGS 2", 51),
    ("CHOIR AAHS", 52),
    ("VOICE OOHS", 53),
    ("SYNTH VOICE", 54),
    ("ORCHESTRA HIT", 55),
    ("TRUMPET", 56),
    ("TROMBONE", 57),
    ("TUBA", 58),
    ("MUTED TRUMPET", 59),
    ("FRENCH HORN", 60),
    ("BRASS SECTION", 61),
    ("SYNTH BRASS 1", 62),
    ("SYNTH BRASS 2", 63),
    ("SOPRANO SAX", 64),
    ("ALTO SAX", 65),
    ("TENOR SAX", 66),
    ("BARITONE SAX", 67),
    ("OBOE", 68),
    ("ENGLISH HORN", 69),
    ("BASSOON", 70),
    ("CLARINET", 71),
    ("PICCOLO", 72),
    ("FLUTE", 73),
    ("RECORDER", 74),
    ("PAN FLUTE", 75),
    ("BLOWN BOTTLE", 76),
    ("SHAKUHACHI", 77),
    ("WHISTLE", 78),
    ("OCARINA", 79),
    ("LEAD SQUARE", 80),
    ("LEAD SAWTOOTH", 81),
    ("LEAD CALLIOPE", 82),
    ("LEAD CHIFF", 83),
    ("LEAD CHARANG", 84),
    ("LEAD VOICE", 85),
    ("LEAD FIFTHS", 86),
    ("LEAD BASS LEAD", 87),
    ("PAD NEW AGE", 88),
    ("PAD WARM", 89),
    ("PAD POLYSYNTH", 90),
    ("PAD CHOIR", 91),
    ("PAD BOWED", 92),
    ("PAD METALLIC", 93),
    ("PAD HALO", 94),
    ("PAD SWEEP", 95),
    ("FX RAIN", 96),
    ("FX SOUNDTRACK", 97),
    ("FX CRYSTAL", 98),
    ("FX ATMOSPHERE", 99),
    ("FX BRIGHTNESS", 100),
    ("FX GOBLINS", 101),
    ("FX ECHOES", 102),
    ("FX SCI-FI", 103),
    ("SITAR", 104),
    ("BANJO", 105),
    ("SHAMISEN", 106),
    ("KOTO", 107),
    ("KALIMBA", 108),
    ("BAG PIPE", 109),
    ("FIDDLE", 110),
    ("SHANAI", 111),
    ("TINKLE BELL", 112),
    ("AGOGO", 113),
    ("STEEL DRUMS", 114),
    ("WOODBLOCK", 115),
    ("TAIKO DRUM", 116),
    ("MELODIC TOM", 117),
    ("SYNTH DRUM", 118),
    ("REVERSE CYMBAL", 119),
    ("GUITAR FRET NOISE", 120),
    ("BREATH NOISE", 121),
    ("SEASHORE", 122),
    ("BIRD TWEET", 123),
    ("TELEPHONE RING", 124),
    ("HELICOPTER", 125),
    ("APPLAUSE", 126),
    ("GUNSHOT", 127),
];

/// General MIDI percussion kits. They use the same `INSTRUMENT voice,"name"`
/// statement as melodic programs; the engine routes only that BASIC voice to
/// MIDI channel 10 (zero-based channel 9).
pub const GM_DRUM_KITS: &[(&str, u8)] = &[
    ("STANDARD DRUM KIT", 0),
    ("ROOM DRUM KIT", 8),
    ("POWER DRUM KIT", 16),
    ("ELECTRONIC DRUM KIT", 24),
    ("TR-808 DRUM KIT", 25),
    ("JAZZ DRUM KIT", 32),
    ("BRUSH DRUM KIT", 40),
    ("ORCHESTRA DRUM KIT", 48),
    ("SFX DRUM KIT", 56),
];

fn named_instrument(name: &str) -> Option<(u8, bool)> {
    let upper = name.to_uppercase();
    if upper == "PIANO" {
        return Some((0, false));
    }
    GM_INSTRUMENTS
        .iter()
        .find(|(candidate, _)| *candidate == upper)
        .map(|(_, program)| (*program, false))
        .or_else(|| {
            GM_DRUM_KITS
                .iter()
                .find(|(candidate, _)| *candidate == upper)
                .map(|(_, program)| (*program, true))
        })
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct MidiScoreNote {
    voice: u8,
    channel: u8,
    note: u8,
    velocity: u8,
    start_seconds: f64,
    duration_seconds: f64,
}

type SoundFontScoreGroup = (Arc<SoundFont>, usize, Vec<MidiScoreNote>);

#[derive(Clone, Copy)]
struct SoundFontRenderSettings {
    sample_rate: u32,
    instruments: [u8; VOICE_COUNT],
    voice_channels: [u8; VOICE_COUNT],
    controllers: [[u8; 128]; VOICE_COUNT],
    pitch_bend: [u16; VOICE_COUNT],
    voice_mix: [(f32, f32); VOICE_COUNT],
    voice_envelopes: [Option<SoundFontEnvelope>; VOICE_COUNT],
    voice_dsp: [Option<SoundFontDsp>; VOICE_COUNT],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum MidiEventKind {
    Off,
    On,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct TimedMidiEvent {
    frame: usize,
    id: usize,
    channel: u8,
    note: u8,
    velocity: u8,
    kind: MidiEventKind,
}

pub struct SfEngine {
    sound_font: Option<Arc<SoundFont>>,
    voice_sound_fonts: [Option<Arc<SoundFont>>; VOICE_COUNT],
    sample_rate: i32,
    /// MIDI channel selected for each BASIC voice. Melodic voices use the
    /// normal one-to-one mapping; a named drum kit maps only its owner to 9.
    voice_channels: [u8; VOICE_COUNT],
    /// Score settings belong to BASIC voices, not MIDI channels. Voices 1 and
    /// 16 both use MIDI channel 0, and any number of named drum voices can use
    /// channel 9, so channel-indexed score state would make one voice overwrite
    /// another before their independently rendered tracks are mixed.
    voice_instruments: [u8; VOICE_COUNT],
    voice_controllers: [[u8; 128]; VOICE_COUNT],
    voice_pitch_bend: [u16; VOICE_COUNT],
    /// Symbolic MIDI events queued by `PLAY`. Keeping these as note data makes
    /// each BASIC statement immediate and avoids full-song PCM buffers.
    score_notes: Vec<MidiScoreNote>,
    /// Parsed program assets prepared while LOAD still owns the READY boundary.
    /// Execution installs these shared banks without reading or reparsing them.
    prepared_soundfonts: HashMap<String, Arc<SoundFont>>,
}

impl SfEngine {
    pub fn new(sample_rate: u32) -> Self {
        Self {
            sound_font: None,
            voice_sound_fonts: std::array::from_fn(|_| None),
            sample_rate: sample_rate as i32,
            voice_channels: default_voice_channels(),
            voice_instruments: [0; VOICE_COUNT],
            voice_controllers: default_channel_controllers(),
            voice_pitch_bend: [8_192; VOICE_COUNT],
            score_notes: Vec::new(),
            prepared_soundfonts: HashMap::new(),
        }
    }

    /// Parse and retain one named bank without changing live MIDI routing.
    /// Repeated declarations of the same path share one parsed SoundFont.
    pub(crate) fn prepare_soundfont_reader<R: Read>(
        &mut self,
        key: &str,
        reader: &mut R,
    ) -> Result<bool, Error> {
        if self.prepared_soundfonts.contains_key(key) {
            return Ok(false);
        }
        let sound_font = Arc::new(
            SoundFont::new(reader)
                .map_err(|e| Error::Io(format!("SoundFont load error: {e:?}")))?,
        );
        self.prepared_soundfonts.insert(key.to_string(), sound_font);
        Ok(true)
    }

    /// Whether a bank has already crossed the READY asset boundary.
    pub(crate) fn has_prepared_soundfont(&self, key: &str) -> bool {
        self.prepared_soundfonts.contains_key(key)
    }

    /// Install a bank previously parsed by [`Self::prepare_soundfont_reader`].
    /// Returns false when the program did not prepare this dynamic path.
    pub(crate) fn activate_prepared_soundfont(
        &mut self,
        key: &str,
        voice_range: Option<(i64, i64)>,
    ) -> Result<bool, Error> {
        let Some(sound_font) = self.prepared_soundfonts.get(key).cloned() else {
            return Ok(false);
        };
        if let Some((first_voice, last_voice)) = voice_range {
            if first_voice < 1 || last_voice < first_voice || last_voice > VOICE_COUNT as i64 {
                return Err(Error::IllegalQuantity);
            }
            for voice in first_voice..=last_voice {
                self.voice_sound_fonts[(voice - 1) as usize] = Some(Arc::clone(&sound_font));
            }
        } else {
            self.install_soundfont(sound_font)?;
        }
        Ok(true)
    }

    fn install_soundfont(&mut self, sound_font: Arc<SoundFont>) -> Result<(), Error> {
        // Validate the parsed bank against the renderer settings now. Score
        // playback later creates isolated synthesizers per BASIC voice so
        // there is no second, mutable sequential engine hidden in SfEngine.
        let settings = SynthesizerSettings::new(self.sample_rate);
        Synthesizer::new(&sound_font, &settings)
            .map_err(|e| Error::Io(format!("Synthesizer init error: {e:?}")))?;
        self.sound_font = Some(sound_font);
        self.voice_sound_fonts.fill(None);
        self.voice_channels = default_voice_channels();
        self.voice_instruments = [0; VOICE_COUNT];
        self.voice_controllers = default_channel_controllers();
        self.voice_pitch_bend = [8_192; VOICE_COUNT];
        Ok(())
    }

    /// Load a SoundFont from raw bytes.
    pub fn load_soundfont(&mut self, data: &[u8]) -> Result<(), Error> {
        let mut cursor = Cursor::new(data);
        self.load_soundfont_reader(&mut cursor)
    }

    /// Parse a SoundFont directly from a bounded reader without first copying
    /// the complete file into another allocation.
    pub(crate) fn load_soundfont_reader<R: Read>(&mut self, reader: &mut R) -> Result<(), Error> {
        let sound_font = Arc::new(
            SoundFont::new(reader)
                .map_err(|e| Error::Io(format!("SoundFont load error: {e:?}")))?,
        );
        self.install_soundfont(sound_font)
    }

    /// Install the already parsed default SoundFont, if another session loaded it.
    pub(crate) fn load_cached_soundfont(&mut self) -> Result<bool, Error> {
        let Some(sound_font) = DEFAULT_SOUNDFONT_CACHE.get() else {
            return Ok(false);
        };
        self.install_soundfont(Arc::clone(sound_font))?;
        Ok(true)
    }

    /// Reuse the parsed default MIDI device across LOAD/NEW session rebuilds.
    /// The first call streams and parses it; later sessions only clone the Arc.
    pub(crate) fn load_cached_soundfont_reader<R: Read>(
        &mut self,
        reader: &mut R,
    ) -> Result<(), Error> {
        if let Some(sound_font) = DEFAULT_SOUNDFONT_CACHE.get() {
            return self.install_soundfont(Arc::clone(sound_font));
        }
        let parsed = Arc::new(
            SoundFont::new(reader)
                .map_err(|e| Error::Io(format!("SoundFont load error: {e:?}")))?,
        );
        let sound_font = Arc::clone(DEFAULT_SOUNDFONT_CACHE.get_or_init(|| parsed));
        self.install_soundfont(sound_font)
    }

    /// Reset BASIC music state while retaining the already parsed SoundFont
    /// device. `CLEAR` uses this so a second RUN does not parse a large .sf2
    /// file again, but no prior instrument or queued note leaks into the run.
    pub fn reset_music_state(&mut self) {
        self.score_notes.clear();
        self.voice_channels = default_voice_channels();
        self.voice_instruments = [0; VOICE_COUNT];
        self.voice_controllers = default_channel_controllers();
        self.voice_pitch_bend = [8_192; VOICE_COUNT];
    }

    /// Remove all MIDI notes queued by `PLAY`.
    pub fn clear_score(&mut self) {
        self.score_notes.clear();
    }

    /// Number of individual note-on events in the symbolic MIDI score.
    pub fn score_note_count(&self) -> usize {
        self.score_notes.len()
    }

    pub fn has_score(&self) -> bool {
        !self.score_notes.is_empty()
    }

    fn has_voice_soundfonts(&self) -> bool {
        self.voice_sound_fonts.iter().any(Option::is_some)
    }

    fn score_soundfont_groups(&self) -> Result<Vec<SoundFontScoreGroup>, Error> {
        let mut groups: Vec<SoundFontScoreGroup> = Vec::new();
        for note in &self.score_notes {
            let voice_index = usize::from(note.voice);
            let sound_font = self
                .voice_sound_fonts
                .get(voice_index)
                .and_then(Option::as_ref)
                .or(self.sound_font.as_ref())
                .ok_or_else(|| {
                    Error::Io(format!(
                        "no SoundFont assigned to BASIC voice {}",
                        voice_index + 1
                    ))
                })?;
            if let Some((_, _, notes)) = groups.iter_mut().find(|(candidate, voice, _)| {
                *voice == voice_index && Arc::ptr_eq(candidate, sound_font)
            }) {
                notes.push(*note);
            } else {
                groups.push((Arc::clone(sound_font), voice_index, vec![*note]));
            }
        }
        Ok(groups)
    }

    fn render_bound_score_floats(
        &self,
        voice_mix: [(f32, f32); VOICE_COUNT],
        voice_envelopes: [Option<SoundFontEnvelope>; VOICE_COUNT],
        voice_dsp: [Option<SoundFontDsp>; VOICE_COUNT],
    ) -> Result<Vec<[f32; 2]>, Error> {
        let total_frames = score_output_frames(&self.score_notes, self.sample_rate as u32)?;
        let groups = self.score_soundfont_groups()?;
        render_soundfont_groups_floats(
            groups,
            total_frames,
            SoundFontRenderSettings {
                sample_rate: self.sample_rate as u32,
                instruments: self.voice_instruments,
                voice_channels: self.voice_channels,
                controllers: self.voice_controllers,
                pitch_bend: self.voice_pitch_bend,
                voice_mix,
                voice_envelopes,
                voice_dsp,
            },
        )
    }

    /// Queue one simultaneous MIDI chord. No PCM is rendered here: this method
    /// only validates and stores note-on/note-off timing data.
    pub fn queue_score_chord(
        &mut self,
        voice_index: usize,
        channel: usize,
        notes: &[u8],
        velocity: u8,
        start_seconds: f64,
        duration_seconds: f64,
    ) -> Result<(), Error> {
        if voice_index >= VOICE_COUNT
            || channel >= 16
            || notes.is_empty()
            || notes.len() > 32
            || velocity == 0
            || !start_seconds.is_finite()
            || start_seconds < 0.0
            || !duration_seconds.is_finite()
            || duration_seconds <= 0.0
            || start_seconds + duration_seconds > MAX_SYNTH_SECONDS
        {
            return Err(Error::IllegalQuantity);
        }
        if self.score_notes.len().saturating_add(notes.len()) > MAX_SCORE_NOTES {
            return Err(Error::syntax(
                "SoundFont MIDI score contains too many notes",
            ));
        }
        self.score_notes
            .extend(notes.iter().copied().map(|note| MidiScoreNote {
                voice: voice_index as u8,
                channel: channel as u8,
                note,
                velocity,
                start_seconds,
                duration_seconds,
            }));
        Ok(())
    }

    /// Queue a whitespace-separated `PLAY` sequence while retaining an
    /// independent cursor for every BASIC voice. `Vn` changes the voice for
    /// subsequent tokens without moving any other voice's cursor.
    pub fn queue_play_sequence(
        &mut self,
        initial_voice: i64,
        sequence: &str,
        default_beats: f64,
        tempo_bpm: f64,
        positions_seconds: &mut [f64; VOICE_COUNT],
        routes: [bool; VOICE_COUNT],
    ) -> Result<(), Error> {
        if sequence.split_whitespace().next().is_none() {
            return Err(Error::syntax("PLAY requires at least one note or rest"));
        }
        if !default_beats.is_finite()
            || default_beats <= 0.0
            || default_beats > MAX_REST_BEATS
            || !tempo_bpm.is_finite()
            || !(1.0..=1_000.0).contains(&tempo_bpm)
        {
            return Err(Error::IllegalQuantity);
        }

        let mut current_voice = initial_voice;
        self.channel_for_voice(current_voice)?;
        for token in sequence.split_whitespace() {
            if let Some(voice) = token
                .strip_prefix('V')
                .or_else(|| token.strip_prefix('v'))
                .and_then(|voice| voice.parse::<i64>().ok())
            {
                if midi_channel_for_voice(voice).is_ok() {
                    current_voice = voice;
                    continue;
                }
            }

            let note = parse_note(token, default_beats)?;
            let position_index =
                usize::try_from(current_voice - 1).map_err(|_| Error::IllegalQuantity)?;
            let start_seconds = positions_seconds[position_index];
            let duration_seconds = note.beats * 60.0 / tempo_bpm;
            let end_seconds = start_seconds + duration_seconds;
            if !end_seconds.is_finite() || end_seconds > MAX_SYNTH_SECONDS {
                return Err(Error::IllegalQuantity);
            }
            if routes[position_index] {
                if let Some(frequency) = note.frequency {
                    let channel = self.channel_for_voice(current_voice)?;
                    self.queue_score_chord(
                        position_index,
                        channel,
                        &[freq_to_midi(frequency)],
                        note.velocity,
                        start_seconds,
                        duration_seconds,
                    )?;
                }
            }
            positions_seconds[position_index] = end_seconds;
        }
        Ok(())
    }

    /// Begin real-time SoundFont playback from one sample-accurate BASIC score.
    pub(crate) fn play_score_async(
        &self,
        session: &PlaybackSession,
        voice_mix: [(f32, f32); VOICE_COUNT],
        voice_envelopes: [Option<SoundFontEnvelope>; VOICE_COUNT],
        voice_dsp: [Option<SoundFontDsp>; VOICE_COUNT],
        master_volume: f32,
    ) -> Result<(), Error> {
        if self.score_notes.is_empty() {
            return Err(Error::syntax("no SoundFont MIDI notes have been queued"));
        }
        let groups = self.score_soundfont_groups()?;
        let total_frames = score_output_frames(&self.score_notes, self.sample_rate as u32)?;
        let instruments = self.voice_instruments;
        let voice_channels = self.voice_channels;
        let controllers = self.voice_controllers;
        let pitch_bend = self.voice_pitch_bend;
        let sample_rate = self.sample_rate as u32;
        session.playback_raw_async(sample_rate, move |writer| {
            stream_soundfont_groups(
                groups,
                total_frames,
                SoundFontRenderSettings {
                    sample_rate,
                    instruments,
                    voice_channels,
                    controllers,
                    pitch_bend,
                    voice_mix,
                    voice_envelopes,
                    voice_dsp,
                },
                master_volume,
                writer,
            )
        })
    }

    /// Render a queued MIDI score only when BASIC explicitly executes WAVEFILE.
    pub fn render_score_wav(
        &self,
        voice_mix: [(f32, f32); VOICE_COUNT],
        voice_envelopes: [Option<SoundFontEnvelope>; VOICE_COUNT],
        voice_dsp: [Option<SoundFontDsp>; VOICE_COUNT],
        master_volume: f32,
    ) -> Result<Vec<u8>, Error> {
        check_audio_render_interrupt()?;
        let frames = score_output_frames(&self.score_notes, self.sample_rate as u32)?;
        let data_bytes = frames.checked_mul(4).ok_or(Error::IntegerOverflow)?;
        let total_bytes = data_bytes.checked_add(44).ok_or(Error::IntegerOverflow)?;
        if total_bytes > MAX_WAV_BYTES {
            return Err(Error::FileLimitExceeded {
                limit: MAX_WAV_BYTES,
            });
        }
        let samples = self.render_bound_score_floats(voice_mix, voice_envelopes, voice_dsp)?;
        let mut wav = Vec::with_capacity(total_bytes);
        write_wav_header(&mut wav, self.sample_rate as u32, data_bytes)?;
        for chunk in samples.chunks(SCORE_RENDER_FRAMES) {
            check_audio_render_interrupt()?;
            for [left, right] in chunk {
                let left = encode_pcm_sample(*left, master_volume);
                let right = encode_pcm_sample(*right, master_volume);
                wav.extend_from_slice(&left.to_le_bytes());
                wav.extend_from_slice(&right.to_le_bytes());
            }
        }
        Ok(wav)
    }

    /// Check if a SoundFont is loaded.
    pub fn is_loaded(&self) -> bool {
        self.sound_font.is_some() || self.has_voice_soundfonts()
    }

    /// Resolve the MIDI channel currently owned by one BASIC voice.
    pub fn channel_for_voice(&self, voice: i64) -> Result<usize, Error> {
        let default_channel = midi_channel_for_voice(voice)?;
        let index = usize::try_from(voice - 1).map_err(|_| Error::IllegalQuantity)?;
        Ok(self
            .voice_channels
            .get(index)
            .copied()
            .map(usize::from)
            .unwrap_or(default_channel))
    }

    /// Select a program for one BASIC voice without allowing another voice
    /// that shares its MIDI channel to replace the score setting.
    pub fn select_instrument_for_voice(&mut self, voice: i64, program: u8) -> Result<(), Error> {
        self.channel_for_voice(voice)?;
        let voice_index = usize::try_from(voice - 1).map_err(|_| Error::IllegalQuantity)?;
        if !self.is_loaded() {
            return Err(Error::Io("No SoundFont loaded".into()));
        }
        self.voice_instruments[voice_index] = program;
        Ok(())
    }

    /// Select a GM instrument for one BASIC voice. Drum-kit names use the
    /// standard percussion channel; melodic names retain the ordinary map.
    pub fn select_instrument_by_name(&mut self, voice: i64, name: &str) -> Result<(), Error> {
        let melodic_channel = midi_channel_for_voice(voice)?;
        let voice_index = usize::try_from(voice - 1).map_err(|_| Error::IllegalQuantity)?;
        let (program, percussion) = named_instrument(name)
            .ok_or_else(|| Error::syntax(format!("Unknown instrument: {name}")))?;
        if !self.is_loaded() {
            return Err(Error::Io("No SoundFont loaded".into()));
        }
        let channel = if percussion {
            Synthesizer::PERCUSSION_CHANNEL
        } else {
            melodic_channel
        };
        self.voice_channels[voice_index] = channel as u8;
        self.voice_instruments[voice_index] = program;
        Ok(())
    }

    /// Set one bounded General MIDI controller for a BASIC voice.
    pub fn set_controller_for_voice(
        &mut self,
        voice: i64,
        controller: u8,
        amount: u8,
    ) -> Result<(), Error> {
        self.channel_for_voice(voice)?;
        let voice_index = usize::try_from(voice - 1).map_err(|_| Error::IllegalQuantity)?;
        if controller > 127 || amount > 127 {
            return Err(Error::IllegalQuantity);
        }
        if !self.is_loaded() {
            return Err(Error::Io("No SoundFont loaded".into()));
        }
        self.voice_controllers[voice_index][controller as usize] = amount;
        Ok(())
    }

    /// Set pitch bend for one BASIC voice without coupling shared channels.
    pub fn set_pitch_bend_for_voice(&mut self, voice: i64, value: u16) -> Result<(), Error> {
        self.channel_for_voice(voice)?;
        let voice_index = usize::try_from(voice - 1).map_err(|_| Error::IllegalQuantity)?;
        if value > 16_383 {
            return Err(Error::IllegalQuantity);
        }
        if !self.is_loaded() {
            return Err(Error::Io("No SoundFont loaded".into()));
        }
        self.voice_pitch_bend[voice_index] = value;
        Ok(())
    }
}

fn score_output_frames(notes: &[MidiScoreNote], sample_rate: u32) -> Result<usize, Error> {
    let last_end = notes
        .iter()
        .map(|note| note.start_seconds + note.duration_seconds)
        .reduce(f64::max)
        .ok_or_else(|| Error::syntax("no SoundFont MIDI notes have been queued"))?;
    let maximum = (MAX_SYNTH_SECONDS * sample_rate as f64).round() as usize;
    let final_seconds = (last_end + SCORE_RELEASE_TAIL_SECONDS).min(MAX_SYNTH_SECONDS);
    Ok(((final_seconds * sample_rate as f64).round() as usize).min(maximum))
}

fn score_timeline(notes: &[MidiScoreNote], sample_rate: u32, gate: f32) -> Vec<TimedMidiEvent> {
    let mut events = Vec::with_capacity(notes.len().saturating_mul(2));
    for (id, note) in notes.iter().enumerate() {
        let start = (note.start_seconds * sample_rate as f64).round() as usize;
        let held_seconds = note.duration_seconds * gate.clamp(0.0, 1.0) as f64;
        let end = ((note.start_seconds + held_seconds) * sample_rate as f64).round() as usize;
        events.push(TimedMidiEvent {
            frame: start,
            id,
            channel: note.channel,
            note: note.note,
            velocity: note.velocity,
            kind: MidiEventKind::On,
        });
        events.push(TimedMidiEvent {
            frame: end.max(start.saturating_add(1)),
            id,
            channel: note.channel,
            note: note.note,
            velocity: 0,
            kind: MidiEventKind::Off,
        });
    }
    events.sort_by_key(|event| {
        (
            event.frame,
            match event.kind {
                MidiEventKind::Off => 0_u8,
                MidiEventKind::On => 1_u8,
            },
            event.channel,
            event.note,
            event.id,
        )
    });
    events
}

#[derive(Default)]
struct SampledDspState {
    presence_low: [f32; 2],
    cabinet_one: [f32; 2],
    cabinet_two: [f32; 2],
    envelope: f32,
    compressor_gain: f32,
}

struct LiveSoundFontGroup {
    synthesizer: Synthesizer,
    voice_index: usize,
    notes: Vec<MidiScoreNote>,
    timeline: Vec<TimedMidiEvent>,
    event_index: usize,
    active_notes: [Option<usize>; 16 * 128],
    next_envelope_note: usize,
    active_envelope_notes: Vec<usize>,
    dsp_state: SampledDspState,
}

impl LiveSoundFontGroup {
    fn new(group: SoundFontScoreGroup, settings: SoundFontRenderSettings) -> Result<Self, Error> {
        let (sound_font, voice_index, mut notes) = group;
        notes.sort_by(|left, right| {
            left.start_seconds
                .total_cmp(&right.start_seconds)
                .then_with(|| left.channel.cmp(&right.channel))
                .then_with(|| left.note.cmp(&right.note))
        });
        let gate = settings.voice_dsp[voice_index]
            .map(|dsp| dsp.gate)
            .unwrap_or(1.0);
        let timeline = score_timeline(&notes, settings.sample_rate, gate);
        let mut synth_settings = SynthesizerSettings::new(settings.sample_rate as i32);
        synth_settings.maximum_polyphony = 256;
        let mut synthesizer = Synthesizer::new(&sound_font, &synth_settings)
            .map_err(|error| Error::Io(format!("SoundFont MIDI device error: {error:?}")))?;
        synthesizer.set_master_volume(1.0);
        configure_score_synthesizer(&mut synthesizer, settings, voice_index);
        Ok(Self {
            synthesizer,
            voice_index,
            notes,
            timeline,
            event_index: 0,
            active_notes: [None; 16 * 128],
            next_envelope_note: 0,
            active_envelope_notes: Vec::new(),
            dsp_state: SampledDspState {
                compressor_gain: 1.0,
                ..SampledDspState::default()
            },
        })
    }

    fn render_chunk(
        &mut self,
        start_frame: usize,
        frames: usize,
        settings: SoundFontRenderSettings,
    ) -> Vec<[f32; 2]> {
        let end_frame = start_frame.saturating_add(frames);
        let mut left = vec![0.0_f32; frames];
        let mut right = vec![0.0_f32; frames];
        let mut cursor = start_frame;

        while cursor < end_frame {
            while self.event_index < self.timeline.len()
                && self.timeline[self.event_index].frame <= cursor
            {
                self.process_event(settings.instruments[self.voice_index]);
            }
            let next_event = self
                .timeline
                .get(self.event_index)
                .map(|event| event.frame)
                .unwrap_or(end_frame)
                .min(end_frame);
            let render_frames = next_event.saturating_sub(cursor);
            if render_frames > 0 {
                let offset = cursor - start_frame;
                self.synthesizer.render(
                    &mut left[offset..offset + render_frames],
                    &mut right[offset..offset + render_frames],
                );
                cursor += render_frames;
            } else {
                self.process_event(settings.instruments[self.voice_index]);
            }
        }

        let mut samples = left
            .into_iter()
            .zip(right)
            .map(|(left, right)| [left, right])
            .collect::<Vec<_>>();
        if let Some(dsp) = settings.voice_dsp[self.voice_index] {
            apply_sampled_dsp_with_state(
                &mut samples,
                settings.sample_rate,
                dsp,
                &mut self.dsp_state,
            );
        }
        if let Some(envelope) = settings.voice_envelopes[self.voice_index] {
            let gate = settings.voice_dsp[self.voice_index]
                .map(|dsp| dsp.gate)
                .unwrap_or(1.0);
            apply_sampled_envelope_chunk(
                &mut samples,
                start_frame,
                &self.notes,
                settings.sample_rate,
                envelope,
                gate,
                &mut self.next_envelope_note,
                &mut self.active_envelope_notes,
            );
        }
        samples
    }

    fn process_event(&mut self, instrument: u8) {
        let Some(event) = self.timeline.get(self.event_index).copied() else {
            return;
        };
        let key = event.channel as usize * 128 + event.note as usize;
        match event.kind {
            MidiEventKind::Off => {
                if self.active_notes[key] == Some(event.id) {
                    self.synthesizer.process_midi_message(
                        event.channel as i32,
                        0x80,
                        event.note as i32,
                        0,
                    );
                    self.active_notes[key] = None;
                }
            }
            MidiEventKind::On => {
                if self.active_notes[key].is_some() {
                    self.synthesizer.process_midi_message(
                        event.channel as i32,
                        0x80,
                        event.note as i32,
                        0,
                    );
                }
                let velocity = instrument_velocity(instrument, event.velocity);
                self.synthesizer.process_midi_message(
                    event.channel as i32,
                    0x90,
                    event.note as i32,
                    velocity as i32,
                );
                self.active_notes[key] = Some(event.id);
            }
        }
        self.event_index += 1;
    }
}

fn configure_score_synthesizer(
    synthesizer: &mut Synthesizer,
    settings: SoundFontRenderSettings,
    voice_index: usize,
) {
    configure_voice_synthesizer(
        synthesizer,
        voice_index,
        settings.instruments,
        settings.voice_channels,
        settings.controllers,
        settings.pitch_bend,
        settings.voice_mix,
    );
}

#[allow(clippy::too_many_arguments)]
fn configure_voice_synthesizer(
    synthesizer: &mut Synthesizer,
    voice_index: usize,
    instruments: [u8; VOICE_COUNT],
    voice_channels: [u8; VOICE_COUNT],
    controllers: [[u8; 128]; VOICE_COUNT],
    pitch_bend: [u16; VOICE_COUNT],
    voice_mix: [(f32, f32); VOICE_COUNT],
) {
    let channel = usize::from(voice_channels[voice_index]);
    synthesizer.process_midi_message(channel as i32, 0xC0, instruments[voice_index] as i32, 0);
    for (controller, amount) in controllers[voice_index].iter().copied().enumerate() {
        if amount != 0 || matches!(controller, 1 | 11 | 64 | 91 | 93) {
            synthesizer.process_midi_message(
                channel as i32,
                0xB0,
                controller as i32,
                amount as i32,
            );
        }
    }
    synthesizer.process_midi_message(
        channel as i32,
        0xE0,
        (pitch_bend[voice_index] & 0x7f) as i32,
        ((pitch_bend[voice_index] >> 7) & 0x7f) as i32,
    );
    let (volume, pan) = voice_mix[voice_index];
    let midi_volume = (volume.clamp(0.0, 1.0) * 127.0).round() as i32;
    synthesizer.process_midi_message(channel as i32, 0xB0, 7, midi_volume);
    let midi_pan = ((pan.clamp(-1.0, 1.0) + 1.0) * 63.5).round() as i32;
    synthesizer.process_midi_message(channel as i32, 0xB0, 10, midi_pan);
}

fn stream_soundfont_groups(
    groups: Vec<SoundFontScoreGroup>,
    total_frames: usize,
    settings: SoundFontRenderSettings,
    master_volume: f32,
    writer: &mut dyn Write,
) -> Result<(), Error> {
    let mut groups = create_live_soundfont_groups(groups, settings)?;
    let mut encoded = Vec::with_capacity(SCORE_RENDER_FRAMES * 4);

    for start_frame in (0..total_frames).step_by(SCORE_RENDER_FRAMES) {
        check_audio_render_interrupt()?;
        let frames = (total_frames - start_frame).min(SCORE_RENDER_FRAMES);
        let mixed = render_soundfont_chunk(&mut groups, start_frame, frames, settings);
        encoded.clear();
        // Live playback and WAVEFILE share this exact fixed-gain encoder.
        // Quiet passages remain quiet; overload is bounded sample by sample,
        // without chunk normalization or gain pumping.
        for [left, right] in mixed {
            let left = encode_pcm_sample(left, master_volume);
            let right = encode_pcm_sample(right, master_volume);
            encoded.extend_from_slice(&left.to_le_bytes());
            encoded.extend_from_slice(&right.to_le_bytes());
        }
        writer
            .write_all(&encoded)
            .map_err(|error| Error::Io(format!("audio stream write failed: {error}")))?;
    }
    Ok(())
}

fn render_soundfont_groups_floats(
    groups: Vec<SoundFontScoreGroup>,
    total_frames: usize,
    settings: SoundFontRenderSettings,
) -> Result<Vec<[f32; 2]>, Error> {
    check_audio_render_interrupt()?;
    let mut groups = create_live_soundfont_groups(groups, settings)?;
    let mut mixed = Vec::with_capacity(total_frames);
    for start_frame in (0..total_frames).step_by(SCORE_RENDER_FRAMES) {
        check_audio_render_interrupt()?;
        let frames = (total_frames - start_frame).min(SCORE_RENDER_FRAMES);
        mixed.extend(render_soundfont_chunk(
            &mut groups,
            start_frame,
            frames,
            settings,
        ));
    }
    Ok(mixed)
}

fn create_live_soundfont_groups(
    groups: Vec<SoundFontScoreGroup>,
    settings: SoundFontRenderSettings,
) -> Result<Vec<LiveSoundFontGroup>, Error> {
    groups
        .into_iter()
        .map(|group| LiveSoundFontGroup::new(group, settings))
        .collect()
}

fn render_soundfont_chunk(
    groups: &mut [LiveSoundFontGroup],
    start_frame: usize,
    frames: usize,
    settings: SoundFontRenderSettings,
) -> Vec<[f32; 2]> {
    let mut mixed = vec![[0.0_f32; 2]; frames];
    for group in groups {
        for (target, source) in
            mixed
                .iter_mut()
                .zip(group.render_chunk(start_frame, frames, settings))
        {
            target[0] += source[0];
            target[1] += source[1];
        }
    }
    mixed
}

#[allow(clippy::too_many_arguments)]
fn apply_sampled_envelope_chunk(
    samples: &mut [[f32; 2]],
    start_frame: usize,
    notes: &[MidiScoreNote],
    sample_rate: u32,
    envelope: SoundFontEnvelope,
    gate: f32,
    next_note: &mut usize,
    active_notes: &mut Vec<usize>,
) {
    if samples.is_empty() {
        return;
    }
    let end_frame = start_frame.saturating_add(samples.len());
    let frames_per_ms = sample_rate as f64 / 1_000.0;
    let attack = (envelope.attack_ms as f64 * frames_per_ms).round() as usize;
    let decay = (envelope.decay_ms as f64 * frames_per_ms).round() as usize;
    let release = (envelope.release_ms as f64 * frames_per_ms).round() as usize;
    let sustain = envelope.sustain.clamp(0.0, 1.0);

    while *next_note < notes.len() {
        let note_start = (notes[*next_note].start_seconds * sample_rate as f64).round() as usize;
        if note_start >= end_frame {
            break;
        }
        active_notes.push(*next_note);
        *next_note += 1;
    }
    active_notes.retain(|index| {
        let note = &notes[*index];
        let stop = ((note.start_seconds + note.duration_seconds * gate.clamp(0.0, 1.0) as f64)
            * sample_rate as f64)
            .round() as usize;
        stop.saturating_add(release) > start_frame
    });

    let mut gain = vec![0.0_f32; samples.len()];
    for &index in active_notes.iter() {
        let note = &notes[index];
        let note_start = (note.start_seconds * sample_rate as f64).round() as usize;
        let stop = ((note.start_seconds + note.duration_seconds * gate.clamp(0.0, 1.0) as f64)
            * sample_rate as f64)
            .round() as usize;
        let held_start = note_start.max(start_frame);
        let held_end = stop.min(end_frame);
        for frame in held_start..held_end {
            let elapsed = frame.saturating_sub(note_start);
            let level = if attack > 0 && elapsed < attack {
                elapsed as f32 / attack as f32
            } else {
                let decay_elapsed = elapsed.saturating_sub(attack);
                if decay > 0 && decay_elapsed < decay {
                    1.0 - (1.0 - sustain) * decay_elapsed as f32 / decay as f32
                } else {
                    sustain
                }
            };
            let slot = frame - start_frame;
            gain[slot] = gain[slot].max(level);
        }

        if release > 0 {
            let held = stop.saturating_sub(note_start);
            let stop_level = if attack > 0 && held < attack {
                held as f32 / attack as f32
            } else {
                let decay_elapsed = held.saturating_sub(attack);
                if decay > 0 && decay_elapsed < decay {
                    1.0 - (1.0 - sustain) * decay_elapsed as f32 / decay as f32
                } else {
                    sustain
                }
            };
            let release_start = stop.max(start_frame);
            let release_end = stop.saturating_add(release).min(end_frame);
            for frame in release_start..release_end {
                let elapsed = frame.saturating_sub(stop);
                let level = stop_level * (1.0 - elapsed as f32 / release as f32);
                let slot = frame - start_frame;
                gain[slot] = gain[slot].max(level);
            }
        }
    }

    for (frame, gain) in samples.iter_mut().zip(gain) {
        frame[0] *= gain;
        frame[1] *= gain;
    }
}

/// Apply an explicit BASIC ADSR to one already-isolated sampled voice. Chords
/// share the same channel envelope, while overlapping releases retain the
/// loudest active note envelope.
#[cfg(test)]
fn apply_sampled_envelope(
    samples: &mut [[f32; 2]],
    notes: &[MidiScoreNote],
    sample_rate: u32,
    envelope: SoundFontEnvelope,
    gate: f32,
) {
    let mut next_note = 0;
    let mut active_notes = Vec::new();
    apply_sampled_envelope_chunk(
        samples,
        0,
        notes,
        sample_rate,
        envelope,
        gate,
        &mut next_note,
        &mut active_notes,
    );
}

/// Apply one isolated sampled voice's configurable amp/cabinet processing.
/// Presence lifts the high-frequency pick component, drive adds symmetric
/// soft clipping, tone models a two-pole cabinet roll-off, and compression
/// controls peaks with a smoothed envelope follower.
#[cfg(test)]
fn apply_sampled_dsp(samples: &mut [[f32; 2]], sample_rate: u32, dsp: SoundFontDsp) {
    let mut state = SampledDspState {
        compressor_gain: 1.0,
        ..SampledDspState::default()
    };
    apply_sampled_dsp_with_state(samples, sample_rate, dsp, &mut state);
}

fn apply_sampled_dsp_with_state(
    samples: &mut [[f32; 2]],
    sample_rate: u32,
    dsp: SoundFontDsp,
    state: &mut SampledDspState,
) {
    if samples.is_empty() || sample_rate == 0 {
        return;
    }
    let presence_alpha = 1.0 - (-2.0 * std::f32::consts::PI * 1_600.0 / sample_rate as f32).exp();
    let cutoff = 1_800.0 + 10_000.0 * dsp.tone.clamp(0.0, 1.0).powi(2);
    let tone_alpha = 1.0 - (-2.0 * std::f32::consts::PI * cutoff / sample_rate as f32).exp();
    let compression = dsp.compression.clamp(0.0, 1.0);
    let threshold = 1.0 - 0.78 * compression;
    let ratio = 1.0 + 7.0 * compression;
    let envelope_attack = 1.0 - (-1.0 / (0.002 * sample_rate as f32)).exp();
    let envelope_release = 1.0 - (-1.0 / (0.080 * sample_rate as f32)).exp();
    let gain_attack = 1.0 - (-1.0 / (0.001 * sample_rate as f32)).exp();
    let gain_release = 1.0 - (-1.0 / (0.060 * sample_rate as f32)).exp();
    for frame in samples {
        for (channel, input) in frame.iter().copied().enumerate() {
            state.presence_low[channel] += presence_alpha * (input - state.presence_low[channel]);
            let high = input - state.presence_low[channel];
            let emphasized = input + 1.8 * dsp.presence.clamp(0.0, 1.0) * high;
            // Zero drive must be a genuinely clean signal path. Applying
            // tanh at unity gain still rounds transients and made sampled
            // guitar attacks sound like keyboard envelopes.
            let driven = sampled_drive(emphasized, dsp.drive);
            state.cabinet_one[channel] += tone_alpha * (driven - state.cabinet_one[channel]);
            state.cabinet_two[channel] +=
                tone_alpha * (state.cabinet_one[channel] - state.cabinet_two[channel]);
        }
        let processed = state.cabinet_two;

        let peak = processed[0].abs().max(processed[1].abs());
        let envelope_coefficient = if peak > state.envelope {
            envelope_attack
        } else {
            envelope_release
        };
        state.envelope += envelope_coefficient * (peak - state.envelope);
        let target_gain = if state.envelope > threshold && state.envelope > 0.0 {
            (threshold + (state.envelope - threshold) / ratio) / state.envelope
        } else {
            1.0
        };
        let gain_coefficient = if target_gain < state.compressor_gain {
            gain_attack
        } else {
            gain_release
        };
        state.compressor_gain += gain_coefficient * (target_gain - state.compressor_gain);
        let makeup = 1.0 + 0.35 * compression;
        frame[0] = processed[0] * state.compressor_gain * makeup;
        frame[1] = processed[1] * state.compressor_gain * makeup;
    }
}

fn sampled_drive(input: f32, drive: f32) -> f32 {
    let drive = drive.clamp(0.0, 1.0);
    if drive <= f32::EPSILON {
        return input;
    }
    let pre_gain = 1.0 + 18.0 * drive.powi(2);
    (input * pre_gain).tanh() / pre_gain.tanh().max(0.000_001)
}

fn encode_pcm_sample(sample: f32, master_volume: f32) -> i16 {
    let level = if master_volume.is_finite() {
        master_volume.clamp(0.0, 1.0)
    } else {
        0.0
    };
    let sample = if sample.is_finite() { sample } else { 0.0 };
    ((sample * level).clamp(-0.95, 0.95) * i16::MAX as f32).round() as i16
}

fn write_wav_header<W: Write + ?Sized>(
    writer: &mut W,
    sample_rate: u32,
    data_bytes: usize,
) -> Result<(), Error> {
    let data_bytes = u32::try_from(data_bytes).map_err(|_| Error::IntegerOverflow)?;
    let riff_bytes = data_bytes.checked_add(36).ok_or(Error::IntegerOverflow)?;
    let mut header = Vec::with_capacity(44);
    header.extend_from_slice(b"RIFF");
    header.extend_from_slice(&riff_bytes.to_le_bytes());
    header.extend_from_slice(b"WAVEfmt ");
    header.extend_from_slice(&16_u32.to_le_bytes());
    header.extend_from_slice(&1_u16.to_le_bytes());
    header.extend_from_slice(&2_u16.to_le_bytes());
    header.extend_from_slice(&sample_rate.to_le_bytes());
    header.extend_from_slice(&sample_rate.saturating_mul(4).to_le_bytes());
    header.extend_from_slice(&4_u16.to_le_bytes());
    header.extend_from_slice(&16_u16.to_le_bytes());
    header.extend_from_slice(b"data");
    header.extend_from_slice(&data_bytes.to_le_bytes());
    writer
        .write_all(&header)
        .map_err(|error| Error::Io(format!("cannot write WAV header: {error}")))
}

/// Balance families whose General MIDI samples respond very differently to
/// the same velocity. This keeps bass present and removes the banjo's brittle
/// edge without altering the voice level.
fn instrument_velocity(program: u8, velocity: u8) -> u8 {
    let adjusted = match program {
        32..=39 => velocity.saturating_add(7),
        40..=44 | 46 | 110 => velocity.saturating_add(2),
        105 => velocity.saturating_sub(2), // banjo — keep more of the attack edge
        _ => velocity,
    };
    adjusted.clamp(1, 127)
}

/// Convert a frequency in Hz to a MIDI note number.
pub fn freq_to_midi(freq: f64) -> u8 {
    let note = 69.0 + 12.0 * (freq / 440.0).log2();
    note.round().clamp(0.0, 127.0) as u8
}

/// Convert a MIDI note number to frequency in Hz.
pub fn midi_to_freq(note: u8) -> f64 {
    440.0 * 2.0_f64.powf((note as f64 - 69.0) / 12.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicBool, Ordering};

    #[test]
    fn score_rendering_observes_the_window_interrupt() {
        let interrupt = Arc::new(AtomicBool::new(true));
        crate::interpreter::set_thread_interrupt_flag(Some(Arc::clone(&interrupt)));
        let settings = SoundFontRenderSettings {
            sample_rate: 44_100,
            instruments: [0; VOICE_COUNT],
            voice_channels: default_voice_channels(),
            controllers: default_channel_controllers(),
            pitch_bend: [8_192; VOICE_COUNT],
            voice_mix: [(1.0, 0.0); VOICE_COUNT],
            voice_envelopes: [None; VOICE_COUNT],
            voice_dsp: [None; VOICE_COUNT],
        };

        assert_eq!(
            render_soundfont_groups_floats(Vec::new(), SCORE_RENDER_FRAMES, settings),
            Err(Error::Break)
        );
        assert!(!interrupt.load(Ordering::SeqCst));
        crate::interpreter::set_thread_interrupt_flag(None);
    }

    #[test]
    fn freq_midi_conversion() {
        assert_eq!(freq_to_midi(440.0), 69); // A4
        assert_eq!(freq_to_midi(261.63), 60); // C4 (middle C)
        let a4 = midi_to_freq(69);
        assert!((a4 - 440.0).abs() < 0.1);
    }

    #[test]
    fn instrument_lookup() {
        let (_, prog) = GM_INSTRUMENTS[0];
        assert_eq!(prog, 0); // Acoustic Grand Piano
        let trumpet = GM_INSTRUMENTS.iter().find(|(n, _)| *n == "TRUMPET");
        assert_eq!(trumpet.unwrap().1, 56);
        assert_eq!(named_instrument("electric piano 1"), Some((4, false)));
        assert_eq!(named_instrument("standard drum kit"), Some((0, true)));
        assert_eq!(named_instrument("power drum kit"), Some((16, true)));
    }

    #[test]
    fn instrument_velocity_balances_samples() {
        assert_eq!(instrument_velocity(32, 100), 107);
        assert_eq!(instrument_velocity(42, 100), 102);
        assert_eq!(instrument_velocity(105, 100), 98);
        assert_eq!(instrument_velocity(32, 125), 127);
    }

    #[test]
    fn sampled_master_gain_never_normalizes_quiet_music_upward() {
        let full = encode_pcm_sample(0.10, 1.0) as f32 / i16::MAX as f32;
        let quiet = encode_pcm_sample(0.10, 0.25) as f32 / i16::MAX as f32;
        assert!((full - 0.10).abs() < 0.001);
        assert!((quiet - 0.025).abs() < 0.001);
        assert_eq!(encode_pcm_sample(0.50, 0.0), 0);
    }

    #[test]
    fn sampled_master_output_bounds_overload_and_non_finite_samples() {
        let ceiling = (0.95 * i16::MAX as f32).round() as i16;
        assert_eq!(encode_pcm_sample(2.0, 1.0), ceiling);
        assert_eq!(encode_pcm_sample(-2.0, 1.0), -ceiling);
        assert_eq!(encode_pcm_sample(f32::NAN, 1.0), 0);
        assert_eq!(encode_pcm_sample(0.5, f32::NAN), 0);
    }

    #[test]
    fn midi_score_queue_is_symbolic_immediate_and_lossless() {
        let mut engine = SfEngine::new(44_100);
        engine
            .queue_score_chord(0, 0, &[60, 64, 67], 110, 0.0, 1.0)
            .unwrap();
        engine
            .queue_score_chord(1, 1, &[55, 59], 96, 0.5, 1.25)
            .unwrap();

        assert_eq!(engine.score_note_count(), 5);
        assert!(engine.sound_font.is_none());
        assert_eq!(score_timeline(&engine.score_notes, 44_100, 1.0).len(), 10);

        engine.clear_score();
        assert!(!engine.has_score());
        assert_eq!(engine.score_note_count(), 0);
    }

    #[test]
    fn explicit_sampled_adsr_shapes_attack_sustain_and_release() {
        let notes = [MidiScoreNote {
            voice: 0,
            channel: 0,
            note: 60,
            velocity: 100,
            start_seconds: 0.0,
            duration_seconds: 0.1,
        }];
        let mut samples = vec![[1.0, 1.0]; 250];
        apply_sampled_envelope(
            &mut samples,
            &notes,
            1_000,
            SoundFontEnvelope {
                attack_ms: 50.0,
                decay_ms: 0.0,
                sustain: 1.0,
                release_ms: 100.0,
            },
            1.0,
        );

        assert_eq!(samples[0], [0.0, 0.0]);
        assert!((samples[25][0] - 0.5).abs() < 0.001);
        assert_eq!(samples[75], [1.0, 1.0]);
        assert_eq!(samples[100], [1.0, 1.0]);
        assert!((samples[150][0] - 0.5).abs() < 0.001);
        assert_eq!(samples[200], [0.0, 0.0]);
    }

    #[test]
    fn streamed_sampled_adsr_matches_full_buffer_processing_across_odd_chunks() {
        let notes = vec![
            MidiScoreNote {
                voice: 0,
                channel: 0,
                note: 60,
                velocity: 100,
                start_seconds: 0.0,
                duration_seconds: 0.17,
            },
            MidiScoreNote {
                voice: 0,
                channel: 0,
                note: 64,
                velocity: 95,
                start_seconds: 0.13,
                duration_seconds: 0.19,
            },
        ];
        let envelope = SoundFontEnvelope {
            attack_ms: 37.0,
            decay_ms: 43.0,
            sustain: 0.61,
            release_ms: 83.0,
        };
        let mut full = vec![[1.0, -0.5]; 500];
        apply_sampled_envelope(&mut full, &notes, 1_000, envelope, 0.73);

        let mut streamed = vec![[1.0, -0.5]; 500];
        let mut next_note = 0usize;
        let mut active_notes = Vec::new();
        let mut start = 0usize;
        for chunk in streamed.chunks_mut(37) {
            apply_sampled_envelope_chunk(
                chunk,
                start,
                &notes,
                1_000,
                envelope,
                0.73,
                &mut next_note,
                &mut active_notes,
            );
            start += chunk.len();
        }
        assert_eq!(streamed, full);
    }

    #[test]
    fn streamed_sampled_dsp_preserves_filter_and_compressor_state() {
        let settings = SoundFontDsp {
            drive: 0.41,
            tone: 0.68,
            presence: 0.37,
            compression: 0.52,
            gate: 0.79,
        };
        let source = (0..503)
            .map(|index| {
                let phase = index as f32 * 0.071;
                [phase.sin() * 0.72, phase.cos() * 0.43]
            })
            .collect::<Vec<_>>();
        let mut full = source.clone();
        apply_sampled_dsp(&mut full, 44_100, settings);

        let mut streamed = source;
        let mut state = SampledDspState {
            compressor_gain: 1.0,
            ..SampledDspState::default()
        };
        for chunk in streamed.chunks_mut(41) {
            apply_sampled_dsp_with_state(chunk, 44_100, settings, &mut state);
        }
        assert_eq!(streamed, full);
    }

    #[test]
    fn play_sequence_tracks_each_voice_cursor_and_channel_independently() {
        let mut engine = SfEngine::new(44_100);
        let mut positions = [0.0; VOICE_COUNT];
        engine
            .queue_play_sequence(
                1,
                "C4:1 V2 E4:2 V1 G4:1",
                1.0,
                60.0,
                &mut positions,
                [true; VOICE_COUNT],
            )
            .unwrap();

        assert_eq!(engine.score_note_count(), 3);
        assert_eq!(positions[0], 2.0);
        assert_eq!(positions[1], 2.0);
        assert_eq!(engine.score_notes[0].channel, 0);
        assert_eq!(engine.score_notes[1].channel, 1);
        assert_eq!(engine.score_notes[2].channel, 0);
        assert_eq!(engine.score_notes[0].start_seconds, 0.0);
        assert_eq!(engine.score_notes[1].start_seconds, 0.0);
        assert_eq!(engine.score_notes[2].start_seconds, 1.0);
    }

    #[test]
    fn score_settings_do_not_alias_voices_that_share_a_midi_channel() {
        let mut engine = SfEngine::new(44_100);
        assert_eq!(engine.channel_for_voice(1).unwrap(), 0);
        assert_eq!(engine.channel_for_voice(16).unwrap(), 0);

        engine.voice_instruments[0] = 15;
        engine.voice_instruments[15] = 40;
        engine.voice_controllers[0][11] = 48;
        engine.voice_controllers[15][11] = 112;
        engine.voice_pitch_bend[0] = 7_168;
        engine.voice_pitch_bend[15] = 9_216;

        assert_eq!(engine.voice_instruments[0], 15);
        assert_eq!(engine.voice_instruments[15], 40);
        assert_eq!(engine.voice_controllers[0][11], 48);
        assert_eq!(engine.voice_controllers[15][11], 112);
        assert_eq!(engine.voice_pitch_bend[0], 7_168);
        assert_eq!(engine.voice_pitch_bend[15], 9_216);
    }

    #[test]
    fn play_routes_skip_midi_notes_but_preserve_voice_time() {
        let mut engine = SfEngine::new(44_100);
        let mut positions = [0.0; VOICE_COUNT];
        let mut routes = [true; VOICE_COUNT];
        routes[0] = false;
        engine
            .queue_play_sequence(1, "C4:1 V2 E4:2 V1 G4:1", 1.0, 60.0, &mut positions, routes)
            .unwrap();
        assert_eq!(engine.score_note_count(), 1);
        assert_eq!(engine.score_notes[0].voice, 1);
        assert_eq!(positions[0], 2.0);
        assert_eq!(positions[1], 2.0);
    }

    #[test]
    fn midi_timeline_processes_note_off_before_retrigger() {
        let notes = [
            MidiScoreNote {
                voice: 0,
                channel: 0,
                note: 60,
                velocity: 100,
                start_seconds: 0.0,
                duration_seconds: 1.0,
            },
            MidiScoreNote {
                voice: 0,
                channel: 0,
                note: 60,
                velocity: 105,
                start_seconds: 1.0,
                duration_seconds: 1.0,
            },
        ];
        let timeline = score_timeline(&notes, 100, 1.0);
        let boundary = timeline
            .iter()
            .filter(|event| event.frame == 100)
            .collect::<Vec<_>>();
        assert_eq!(boundary.len(), 2);
        assert_eq!(boundary[0].kind, MidiEventKind::Off);
        assert_eq!(boundary[1].kind, MidiEventKind::On);

        let gated = score_timeline(&notes, 100, 0.35);
        let first_off = gated
            .iter()
            .find(|event| event.id == 0 && event.kind == MidiEventKind::Off)
            .unwrap();
        assert_eq!(first_off.frame, 35);
    }

    #[test]
    fn sampled_dsp_is_finite_and_changes_an_isolated_voice() {
        let mut samples = vec![[0.0, 0.0]; 256];
        samples[0] = [0.8, -0.8];
        let original = samples.clone();
        apply_sampled_dsp(
            &mut samples,
            44_100,
            SoundFontDsp {
                drive: 0.7,
                tone: 0.5,
                presence: 0.8,
                compression: 0.4,
                gate: 0.35,
            },
        );
        assert_ne!(samples, original);
        assert!(samples.iter().flatten().all(|sample| sample.is_finite()));
        assert!(samples.iter().flatten().any(|sample| sample.abs() > 0.0));
    }

    #[test]
    fn zero_sampled_drive_does_not_round_a_clean_guitar_transient() {
        for input in [-1.0_f32, -0.73, -0.1, 0.0, 0.1, 0.73, 1.0] {
            assert_eq!(sampled_drive(input, 0.0), input);
        }
        assert_ne!(sampled_drive(0.73, 0.7), 0.73);
    }
}
