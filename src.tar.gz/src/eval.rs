use crate::arrays::ArrayStore;
use crate::complex::BasicComplex;
use crate::error::Error;
use crate::file_io::FileStore;
use crate::functions::{
    evaluate_builtin, evaluate_free, evaluate_named_builtin, evaluate_position,
    is_builtin_function, is_named_builtin,
};
use crate::graphics::GraphicsDevice;
use crate::integer::{BasicInteger, NumericMode};
use crate::numerical::{self, Extremum};
use crate::random::BasicRng;
use crate::real::BasicReal;
use crate::screen::TextScreenBuffer;
use crate::ti_graph::TiGraphState;
use crate::tokens::{tokenize, Token, TokenInstance};
use crate::user_functions::{compact_function_name, UserFunctions};
use crate::value::{default_for, Value, Variables};
use std::collections::HashMap;
use std::sync::Mutex;

pub(crate) type SystemService = fn(i64) -> Result<i64, Error>;

/// Evaluate a simple BASIC arithmetic expression under the given numeric mode.
///
/// This is the original integer-only public API, preserved for existing callers
/// and tests.  The supplied variable map contains integer values; the result is
/// an integer.  String expressions evaluate to [`Error::TypeMismatch`].
///
/// The string byte limit is derived from `mode`.  Array references use a
/// temporary empty store, so they always read as default values.
pub fn evaluate(mode: NumericMode, expr: &str, vars: &HashMap<String, i64>) -> Result<i64, Error> {
    let tokens = tokenize(expr)?;
    evaluate_tokens(mode, &tokens, vars)
}

/// Convenience wrapper with an empty integer variable context.
pub fn evaluate_direct(mode: NumericMode, expr: &str) -> Result<i64, Error> {
    evaluate(mode, expr, &HashMap::new())
}

/// Evaluate an expression that has already been tokenised.
///
/// This is the entry point used by the interpreter so that it can evaluate
/// sub-expressions from a numbered program line without re-tokenising.  This
/// integer-only signature is kept for backward compatibility; the interpreter
/// now prefers [`evaluate_value_tokens_with_arrays`].
pub fn evaluate_tokens(
    mode: NumericMode,
    tokens: &[TokenInstance],
    vars: &HashMap<String, i64>,
) -> Result<i64, Error> {
    let value_vars: Variables = vars
        .iter()
        .map(|(k, v)| (k.clone(), Value::Integer(*v)))
        .collect();
    let mut arrays = ArrayStore::new(usize::MAX);
    let value = evaluate_value_tokens_with_arrays(
        mode,
        tokens,
        &value_vars,
        &mut arrays,
        mode.default_string_byte_limit(),
    )?;
    into_integer(value, mode).map(BasicInteger::value)
}

/// Evaluate a BASIC expression and return a typed [`Value`].
///
/// The evaluator enforces the configured `max_string_bytes` limit on string
/// literals, string variable loads, and string concatenation.  Array references
/// use a temporary empty store and therefore read default values.
pub fn evaluate_value(
    mode: NumericMode,
    expr: &str,
    vars: &Variables,
    max_string_bytes: usize,
) -> Result<Value, Error> {
    let tokens = tokenize(expr)?;
    evaluate_value_tokens(mode, &tokens, vars, max_string_bytes)
}

/// Convenience wrapper with an empty variable context and the mode's default
/// string byte limit.
pub fn evaluate_value_direct(mode: NumericMode, expr: &str) -> Result<Value, Error> {
    evaluate_value(
        mode,
        expr,
        &Variables::new(),
        mode.default_string_byte_limit(),
    )
}

/// Evaluate a pre-tokenised expression and return a typed [`Value`].
///
/// This wrapper uses a temporary empty array store so that existing callers
/// keep working; see [`evaluate_value_tokens_with_arrays`] for the
/// array-aware entry point.
pub fn evaluate_value_tokens(
    mode: NumericMode,
    tokens: &[TokenInstance],
    vars: &Variables,
    max_string_bytes: usize,
) -> Result<Value, Error> {
    let mut arrays = ArrayStore::new(usize::MAX);
    evaluate_value_tokens_with_arrays(mode, tokens, vars, &mut arrays, max_string_bytes)
}

/// Evaluate a pre-tokenised expression with a live array store.
///
/// The store may be mutated to create implicit arrays on first reference,
/// matching the behaviour of the original `array.s` / `var.s` code.
pub fn evaluate_value_tokens_with_arrays(
    mode: NumericMode,
    tokens: &[TokenInstance],
    vars: &Variables,
    arrays: &mut ArrayStore,
    max_string_bytes: usize,
) -> Result<Value, Error> {
    let mut rng = BasicRng::default();
    evaluate_value_tokens_with_runtime(mode, tokens, vars, arrays, max_string_bytes, &mut rng)
}

/// Evaluate a pre-tokenised expression with live array and random-number state.
///
/// Program execution uses this entry point so successive `RND` calls share one
/// deterministic sequence. Callers choose the initial seed through
/// [`BasicRng::new`].
pub fn evaluate_value_tokens_with_runtime(
    mode: NumericMode,
    tokens: &[TokenInstance],
    vars: &Variables,
    arrays: &mut ArrayStore,
    max_string_bytes: usize,
    rng: &mut BasicRng,
) -> Result<Value, Error> {
    evaluate_runtime_inner(
        mode,
        tokens,
        vars,
        arrays,
        max_string_bytes,
        rng,
        None,
        0,
        0,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        0,
        None,
        None,
        None,
        None,
    )
}

#[derive(Clone, Copy)]
struct ProcessContext<'a> {
    command_line: &'a str,
    environment: &'a [(String, String)],
    session_environment: &'a HashMap<String, String>,
    session_clock: Option<&'a std::time::SystemTime>,
}

/// Borrowed expression state supplied by one interpreter run.
#[derive(Clone, Copy)]
pub(crate) struct ExpressionRuntime<'a> {
    definitions: &'a UserFunctions,
    max_depth: usize,
    output_column: usize,
    cursor_row: usize,
    text_screen: Option<&'a Mutex<TextScreenBuffer>>,
    free_storage_bytes: usize,
    graph: Option<&'a TiGraphState>,
    graphics: Option<&'a GraphicsDevice>,
    virtual_memory: Option<&'a [u8]>,
    virtual_ports: Option<&'a [u8]>,
    memory_segment: usize,
    files: Option<&'a FileStore>,
    system_services: Option<&'a HashMap<usize, SystemService>>,
    usr_addresses: Option<&'a [Option<usize>; 10]>,
    process_context: Option<ProcessContext<'a>>,
}

impl<'a> ExpressionRuntime<'a> {
    pub fn new(
        definitions: &'a UserFunctions,
        max_depth: usize,
        output_column: usize,
        free_storage_bytes: usize,
    ) -> Self {
        Self {
            definitions,
            max_depth,
            output_column,
            cursor_row: 1,
            text_screen: None,
            free_storage_bytes,
            graph: None,
            graphics: None,
            virtual_memory: None,
            virtual_ports: None,
            memory_segment: 0,
            files: None,
            system_services: None,
            usr_addresses: None,
            process_context: None,
        }
    }

    pub fn with_graph(mut self, graph: &'a TiGraphState) -> Self {
        self.graph = Some(graph);
        self
    }

    pub fn with_cursor_row(mut self, cursor_row: usize) -> Self {
        self.cursor_row = cursor_row;
        self
    }

    pub fn with_text_screen(mut self, screen: &'a Mutex<TextScreenBuffer>) -> Self {
        self.text_screen = Some(screen);
        self
    }

    pub fn with_graphics(mut self, graphics: &'a GraphicsDevice) -> Self {
        self.graphics = Some(graphics);
        self
    }

    pub fn with_virtual_memory(mut self, memory: &'a [u8], segment: usize) -> Self {
        self.virtual_memory = Some(memory);
        self.memory_segment = segment;
        self
    }

    pub fn with_virtual_ports(mut self, ports: &'a [u8]) -> Self {
        self.virtual_ports = Some(ports);
        self
    }

    pub fn with_files(mut self, files: &'a FileStore) -> Self {
        self.files = Some(files);
        self
    }

    pub fn with_process_context(
        mut self,
        command_line: &'a str,
        environment: &'a [(String, String)],
        session_environment: &'a HashMap<String, String>,
        session_clock: Option<&'a std::time::SystemTime>,
    ) -> Self {
        self.process_context = Some(ProcessContext {
            command_line,
            environment,
            session_environment,
            session_clock,
        });
        self
    }

    pub fn with_system_services(
        mut self,
        services: &'a HashMap<usize, SystemService>,
        usr_addresses: &'a [Option<usize>; 10],
    ) -> Self {
        self.system_services = Some(services);
        self.usr_addresses = Some(usr_addresses);
        self
    }
}

/// Evaluate with the user-function definitions owned by one interpreter run.
pub(crate) fn evaluate_value_tokens_with_user_functions(
    mode: NumericMode,
    tokens: &[TokenInstance],
    vars: &Variables,
    arrays: &mut ArrayStore,
    max_string_bytes: usize,
    rng: &mut BasicRng,
    runtime: ExpressionRuntime<'_>,
) -> Result<Value, Error> {
    evaluate_runtime_inner(
        mode,
        tokens,
        vars,
        arrays,
        max_string_bytes,
        rng,
        Some(runtime.definitions),
        0,
        runtime.max_depth,
        Some(runtime.output_column),
        Some(runtime.cursor_row),
        runtime.text_screen,
        Some(runtime.free_storage_bytes),
        runtime.graph,
        runtime.graphics,
        runtime.virtual_memory,
        runtime.virtual_ports,
        runtime.memory_segment,
        runtime.files,
        runtime.system_services,
        runtime.usr_addresses,
        runtime.process_context,
    )
}

#[allow(clippy::too_many_arguments)]
fn evaluate_runtime_inner(
    mode: NumericMode,
    tokens: &[TokenInstance],
    vars: &Variables,
    arrays: &mut ArrayStore,
    max_string_bytes: usize,
    rng: &mut BasicRng,
    user_functions: Option<&UserFunctions>,
    function_depth: usize,
    max_function_depth: usize,
    output_column: Option<usize>,
    cursor_row: Option<usize>,
    text_screen: Option<&Mutex<TextScreenBuffer>>,
    free_storage_bytes: Option<usize>,
    graph: Option<&TiGraphState>,
    graphics: Option<&GraphicsDevice>,
    virtual_memory: Option<&[u8]>,
    virtual_ports: Option<&[u8]>,
    memory_segment: usize,
    files: Option<&FileStore>,
    system_services: Option<&HashMap<usize, SystemService>>,
    usr_addresses: Option<&[Option<usize>; 10]>,
    process_context: Option<ProcessContext<'_>>,
) -> Result<Value, Error> {
    let mut p = Parser {
        tokens,
        pos: 0,
        mode,
        vars,
        arrays,
        max_string_bytes,
        rng,
        user_functions,
        function_depth,
        max_function_depth,
        output_column,
        cursor_row,
        text_screen,
        free_storage_bytes,
        graph,
        graphics,
        virtual_memory,
        virtual_ports,
        memory_segment,
        files,
        system_services,
        usr_addresses,
        process_context,
        expression_depth: 0,
    };
    let value = p.parse_expr()?;
    if !p.at_end() {
        return Err(Error::syntax("trailing characters after expression"));
    }
    Ok(value)
}

/// Prefix evaluator used by statements that may contain multiple expressions
/// and user-function calls.
pub(crate) fn evaluate_prefix_with_user_functions(
    mode: NumericMode,
    tokens: &[TokenInstance],
    vars: &Variables,
    arrays: &mut ArrayStore,
    max_string_bytes: usize,
    rng: &mut BasicRng,
    runtime: ExpressionRuntime<'_>,
) -> Result<(Value, usize), Error> {
    evaluate_prefix_inner(
        mode,
        tokens,
        vars,
        arrays,
        max_string_bytes,
        rng,
        Some(runtime.definitions),
        runtime.max_depth,
        Some(runtime.output_column),
        Some(runtime.cursor_row),
        runtime.text_screen,
        Some(runtime.free_storage_bytes),
        runtime.graph,
        runtime.graphics,
        runtime.virtual_memory,
        runtime.virtual_ports,
        runtime.memory_segment,
        runtime.files,
        runtime.system_services,
        runtime.usr_addresses,
        runtime.process_context,
    )
}

#[allow(clippy::too_many_arguments)]
fn evaluate_prefix_inner(
    mode: NumericMode,
    tokens: &[TokenInstance],
    vars: &Variables,
    arrays: &mut ArrayStore,
    max_string_bytes: usize,
    rng: &mut BasicRng,
    user_functions: Option<&UserFunctions>,
    max_function_depth: usize,
    output_column: Option<usize>,
    cursor_row: Option<usize>,
    text_screen: Option<&Mutex<TextScreenBuffer>>,
    free_storage_bytes: Option<usize>,
    graph: Option<&TiGraphState>,
    graphics: Option<&GraphicsDevice>,
    virtual_memory: Option<&[u8]>,
    virtual_ports: Option<&[u8]>,
    memory_segment: usize,
    files: Option<&FileStore>,
    system_services: Option<&HashMap<usize, SystemService>>,
    usr_addresses: Option<&[Option<usize>; 10]>,
    process_context: Option<ProcessContext<'_>>,
) -> Result<(Value, usize), Error> {
    let mut parser = Parser {
        tokens,
        pos: 0,
        mode,
        vars,
        arrays,
        max_string_bytes,
        rng,
        user_functions,
        function_depth: 0,
        max_function_depth,
        output_column,
        cursor_row,
        text_screen,
        free_storage_bytes,
        graph,
        graphics,
        virtual_memory,
        virtual_ports,
        memory_segment,
        files,
        system_services,
        usr_addresses,
        process_context,
        expression_depth: 0,
    };
    let value = parser.parse_expr()?;
    Ok((value, parser.pos))
}

fn default_for_declared(name: &str, vars: &Variables) -> Value {
    let Some(letter) = name.bytes().next().filter(u8::is_ascii_alphabetic) else {
        return default_for(name);
    };
    let Some(Value::String(types)) = vars.get("__DEF_TYPES$") else {
        return default_for(name);
    };
    let index = (letter.to_ascii_uppercase() - b'A') as usize;
    match types.as_bytes().get(index).copied() {
        Some(b'S') => Value::String(String::new()),
        Some(b'F' | b'D') => Value::Real(BasicReal::zero()),
        _ => Value::Integer(0),
    }
}

/// Internal variable name used to pass a materialized SADD address into the
/// otherwise read-only expression evaluator.
pub(crate) fn sadd_address_key(name: &str) -> String {
    format!("\0M64B:SADD:{name}")
}

struct Parser<'a> {
    tokens: &'a [TokenInstance],
    pos: usize,
    mode: NumericMode,
    vars: &'a Variables,
    arrays: &'a mut ArrayStore,
    max_string_bytes: usize,
    rng: &'a mut BasicRng,
    user_functions: Option<&'a UserFunctions>,
    function_depth: usize,
    max_function_depth: usize,
    output_column: Option<usize>,
    cursor_row: Option<usize>,
    text_screen: Option<&'a Mutex<TextScreenBuffer>>,
    free_storage_bytes: Option<usize>,
    graph: Option<&'a TiGraphState>,
    graphics: Option<&'a GraphicsDevice>,
    virtual_memory: Option<&'a [u8]>,
    virtual_ports: Option<&'a [u8]>,
    memory_segment: usize,
    files: Option<&'a FileStore>,
    system_services: Option<&'a HashMap<usize, SystemService>>,
    usr_addresses: Option<&'a [Option<usize>; 10]>,
    process_context: Option<ProcessContext<'a>>,
    expression_depth: usize,
}

#[derive(Debug, Clone, Copy)]
enum Comparison {
    Equal,
    NotEqual,
    Less,
    LessEqual,
    Greater,
    GreaterEqual,
}

/// Convert a value to a [`BasicInteger`], reporting [`Error::TypeMismatch`] for
/// strings.
fn into_integer(value: Value, mode: NumericMode) -> Result<BasicInteger, Error> {
    match value {
        Value::Integer(n) => BasicInteger::with_mode(mode, n),
        Value::Real(n) => BasicInteger::with_mode(mode, n.to_rounded_integer()?),
        Value::Complex(_) | Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

/// Microsoft integer operators round real operands before applying the
/// operation. Keep that conversion separate from the exact-integral helper
/// used by array subscripts and other ModernBASIC facilities.
fn into_rounded_integer(value: Value, mode: NumericMode) -> Result<BasicInteger, Error> {
    let value = match value {
        Value::Integer(value) => value,
        Value::Real(value) => {
            const I64_LOWER: f64 = -9_223_372_036_854_775_808.0;
            const I64_UPPER_EXCLUSIVE: f64 = 9_223_372_036_854_775_808.0;
            let rounded = value.value().round();
            if !(I64_LOWER..I64_UPPER_EXCLUSIVE).contains(&rounded) {
                return Err(Error::IntegerOverflow);
            }
            rounded as i64
        }
        Value::Complex(_) | Value::List(_) | Value::String(_) => return Err(Error::TypeMismatch),
    };
    BasicInteger::with_mode(mode, value)
}

fn into_real(value: Value) -> Result<BasicReal, Error> {
    match value {
        Value::Integer(n) => BasicReal::from_integer(n),
        Value::Real(n) => Ok(n),
        Value::Complex(value) if value.is_real() => Ok(value.real()),
        Value::Complex(_) | Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn coordinate_value(value: f64) -> Result<Value, Error> {
    if value.fract() == 0.0 && value >= i64::MIN as f64 && value < 9_223_372_036_854_775_808.0 {
        Ok(Value::Integer(value as i64))
    } else {
        Ok(Value::Real(BasicReal::new(value)?))
    }
}

fn timer_value_at(clock: std::time::SystemTime) -> Result<Value, Error> {
    let seconds = crate::local_time::local_seconds_since_midnight_at(clock)?;
    Ok(Value::Real(BasicReal::new(seconds)?))
}

fn into_complex(value: Value) -> Result<BasicComplex, Error> {
    match value {
        Value::Integer(value) => Ok(BasicComplex::from_real(BasicReal::from_integer(value)?)),
        Value::Real(value) => Ok(BasicComplex::from_real(value)),
        Value::Complex(value) => Ok(value),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

fn as_complex(value: &Value) -> Result<BasicComplex, Error> {
    match value {
        Value::Integer(value) => Ok(BasicComplex::from_real(BasicReal::from_integer(*value)?)),
        Value::Real(value) => Ok(BasicComplex::from_real(*value)),
        Value::Complex(value) => Ok(*value),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

#[derive(Debug, Clone, Copy)]
enum NumericOperation {
    Add,
    Subtract,
    Multiply,
    Divide,
}

const MAX_LIST_ELEMENTS: usize = 1_000_000;
const MAX_EXPRESSION_DEPTH: usize = 32;

fn numeric_list_element_count(value: &Value) -> Option<usize> {
    match value {
        Value::Integer(_) | Value::Real(_) | Value::Complex(_) => Some(1),
        Value::List(values) => values.iter().try_fold(0_usize, |total, value| {
            total.checked_add(numeric_list_element_count(value)?)
        }),
        Value::String(_) => None,
    }
}

fn binary_numeric(
    left: Value,
    right: Value,
    mode: NumericMode,
    operation: NumericOperation,
) -> Result<Value, Error> {
    match (left, right) {
        (Value::List(left), Value::List(right)) => {
            if left.len() != right.len() {
                return Err(Error::IllegalQuantity);
            }
            let values = left
                .into_iter()
                .zip(right)
                .map(|(left, right)| binary_numeric(left, right, mode, operation))
                .collect::<Result<Vec<_>, _>>()?;
            Ok(Value::List(values))
        }
        (Value::List(left), right) if right.is_numeric() => {
            let values = left
                .into_iter()
                .map(|left| binary_numeric(left, right.clone(), mode, operation))
                .collect::<Result<Vec<_>, _>>()?;
            Ok(Value::List(values))
        }
        (left, Value::List(right)) if left.is_numeric() => {
            let values = right
                .into_iter()
                .map(|right| binary_numeric(left.clone(), right, mode, operation))
                .collect::<Result<Vec<_>, _>>()?;
            Ok(Value::List(values))
        }
        (left, right) => binary_scalar_numeric(left, right, mode, operation),
    }
}

fn binary_scalar_numeric(
    left: Value,
    right: Value,
    mode: NumericMode,
    operation: NumericOperation,
) -> Result<Value, Error> {
    if matches!(left, Value::Complex(_)) || matches!(right, Value::Complex(_)) {
        let left = into_complex(left)?;
        let right = into_complex(right)?;
        let result = match operation {
            NumericOperation::Add => left.add(right),
            NumericOperation::Subtract => left.sub(right),
            NumericOperation::Multiply => left.mul(right),
            NumericOperation::Divide => left.div(right),
        }?;
        return Ok(Value::Complex(result));
    }
    // Dartmouth and Microsoft BASIC use ordinary real division. Keep exact
    // integer arithmetic for +, -, and *, but make `5/2` produce 2.5 even
    // when both source literals happen to be represented as exact integers.
    if let (
        Value::Integer(left),
        Value::Integer(right),
        operation @ (NumericOperation::Add
        | NumericOperation::Subtract
        | NumericOperation::Multiply),
    ) = (&left, &right, operation)
    {
        let left = BasicInteger::with_mode(mode, *left)?;
        let right = BasicInteger::with_mode(mode, *right)?;
        let result = match operation {
            NumericOperation::Add => left.add(right),
            NumericOperation::Subtract => left.sub(right),
            NumericOperation::Multiply => left.mul(right),
            NumericOperation::Divide => unreachable!("pattern excludes division"),
        }?;
        return Ok(Value::Integer(result.value()));
    }

    let left = into_real(left)?;
    let right = into_real(right)?;
    let result = match operation {
        NumericOperation::Add => left.add(right),
        NumericOperation::Subtract => left.sub(right),
        NumericOperation::Multiply => left.mul(right),
        NumericOperation::Divide => left.div(right),
    }?;
    Ok(Value::Real(result))
}

/// Add two scalar numeric values with the evaluator's checked arithmetic.
pub(crate) fn add_numeric_values(
    left: Value,
    right: Value,
    mode: NumericMode,
) -> Result<Value, Error> {
    binary_scalar_numeric(left, right, mode, NumericOperation::Add)
}

fn binary_power(left: Value, right: Value) -> Result<Value, Error> {
    match (left, right) {
        (Value::List(left), Value::List(right)) => {
            if left.len() != right.len() {
                return Err(Error::IllegalQuantity);
            }
            Ok(Value::List(
                left.into_iter()
                    .zip(right)
                    .map(|(left, right)| binary_power(left, right))
                    .collect::<Result<Vec<_>, _>>()?,
            ))
        }
        (Value::List(left), right) if right.is_numeric() => Ok(Value::List(
            left.into_iter()
                .map(|left| binary_power(left, right.clone()))
                .collect::<Result<Vec<_>, _>>()?,
        )),
        (left, Value::List(right)) if left.is_numeric() => Ok(Value::List(
            right
                .into_iter()
                .map(|right| binary_power(left.clone(), right))
                .collect::<Result<Vec<_>, _>>()?,
        )),
        (left, right) => binary_scalar_power(left, right),
    }
}

fn binary_scalar_power(left: Value, right: Value) -> Result<Value, Error> {
    if matches!(left, Value::Complex(_)) || matches!(right, Value::Complex(_)) {
        return Ok(Value::Complex(
            into_complex(left)?.pow(into_complex(right)?)?,
        ));
    }
    let base = into_real(left)?;
    let exponent = into_real(right)?;
    Ok(Value::Real(base.pow(exponent)?))
}

fn compare_numeric(left: &Value, right: &Value) -> Result<std::cmp::Ordering, Error> {
    match (left, right) {
        (Value::Integer(left), Value::Integer(right)) => Ok(left.cmp(right)),
        (Value::Integer(left), Value::Real(right)) => BasicReal::from_integer(*left)?
            .value()
            .partial_cmp(&right.value())
            .ok_or(Error::RealOverflow),
        (Value::Real(left), Value::Integer(right)) => left
            .value()
            .partial_cmp(&BasicReal::from_integer(*right)?.value())
            .ok_or(Error::RealOverflow),
        (Value::Real(left), Value::Real(right)) => left
            .value()
            .partial_cmp(&right.value())
            .ok_or(Error::RealOverflow),
        (Value::Complex(_), _) | (_, Value::Complex(_)) => Err(Error::TypeMismatch),
        _ => Err(Error::TypeMismatch),
    }
}

pub(crate) fn compare_case_values(
    left: &Value,
    right: &Value,
) -> Result<std::cmp::Ordering, Error> {
    match (left, right) {
        (Value::String(left), Value::String(right)) => Ok(left.cmp(right)),
        (left, right) if left.is_numeric() && right.is_numeric() => compare_numeric(left, right),
        _ => Err(Error::TypeMismatch),
    }
}
fn compare_values(left: &Value, right: &Value, comparison: Comparison) -> Result<Value, Error> {
    match (left, right) {
        (Value::List(left), Value::List(right)) => {
            if left.len() != right.len() {
                return Err(Error::IllegalQuantity);
            }
            Ok(Value::List(
                left.iter()
                    .zip(right)
                    .map(|(left, right)| compare_values(left, right, comparison))
                    .collect::<Result<Vec<_>, _>>()?,
            ))
        }
        (Value::List(left), right) => Ok(Value::List(
            left.iter()
                .map(|left| compare_values(left, right, comparison))
                .collect::<Result<Vec<_>, _>>()?,
        )),
        (left, Value::List(right)) => Ok(Value::List(
            right
                .iter()
                .map(|right| compare_values(left, right, comparison))
                .collect::<Result<Vec<_>, _>>()?,
        )),
        _ => Ok(Value::Integer(
            if scalar_comparison(left, right, comparison)? {
                -1
            } else {
                0
            },
        )),
    }
}

fn scalar_comparison(left: &Value, right: &Value, comparison: Comparison) -> Result<bool, Error> {
    match (left, right) {
        (left, right) if left.is_numeric() && right.is_numeric() => {
            if matches!(left, Value::Complex(_)) || matches!(right, Value::Complex(_)) {
                let equal = as_complex(left)? == as_complex(right)?;
                match comparison {
                    Comparison::Equal => Ok(equal),
                    Comparison::NotEqual => Ok(!equal),
                    _ => Err(Error::TypeMismatch),
                }
            } else {
                let ordering = compare_numeric(left, right)?;
                Ok(match comparison {
                    Comparison::Equal => ordering.is_eq(),
                    Comparison::NotEqual => !ordering.is_eq(),
                    Comparison::Less => ordering.is_lt(),
                    Comparison::LessEqual => !ordering.is_gt(),
                    Comparison::Greater => ordering.is_gt(),
                    Comparison::GreaterEqual => !ordering.is_lt(),
                })
            }
        }
        (Value::String(left), Value::String(right)) => Ok(match comparison {
            Comparison::Equal => left == right,
            Comparison::NotEqual => left != right,
            Comparison::Less => left < right,
            Comparison::LessEqual => left <= right,
            Comparison::Greater => left > right,
            Comparison::GreaterEqual => left >= right,
        }),
        _ => Err(Error::TypeMismatch),
    }
}

fn expect_raw_arity(
    token: Token,
    args: &[Vec<TokenInstance>],
    minimum: usize,
    maximum: usize,
) -> Result<(), Error> {
    if (minimum..=maximum).contains(&args.len()) {
        return Ok(());
    }
    let expected = if minimum == maximum {
        minimum.to_string()
    } else {
        format!("{minimum} or {maximum}")
    };
    Err(Error::syntax(format!(
        "{} expects {expected} argument(s), got {}",
        token.to_text(),
        args.len()
    )))
}

fn raw_variable(token: Token, tokens: &[TokenInstance]) -> Result<String, Error> {
    match tokens {
        [TokenInstance::Ident(name)] if !name.ends_with('$') => Ok(name.clone()),
        _ => Err(Error::syntax(format!(
            "{} requires a numeric variable as its second argument",
            token.to_text()
        ))),
    }
}

impl<'a> Parser<'a> {
    fn peek(&self) -> Option<&TokenInstance> {
        self.tokens.get(self.pos)
    }

    fn bump(&mut self) -> Option<TokenInstance> {
        let t = self.tokens.get(self.pos).cloned();
        if t.is_some() {
            self.pos += 1;
        }
        t
    }

    fn at_end(&self) -> bool {
        self.pos >= self.tokens.len()
    }

    fn check_string_len(&self, s: &str) -> Result<(), Error> {
        let length = s.len();
        if length > self.max_string_bytes {
            return Err(Error::StringTooLong {
                length,
                limit: self.max_string_bytes,
            });
        }
        Ok(())
    }

    fn command_value(&self) -> Result<Value, Error> {
        let command_line = self
            .process_context
            .map(|context| context.command_line)
            .unwrap_or_default();
        self.check_string_len(command_line)?;
        Ok(Value::String(command_line.to_string()))
    }

    fn environment_value(&self, args: &[Value]) -> Result<Value, Error> {
        let [argument] = args else {
            return Err(Error::syntax("ENVIRON$ expects one name or index"));
        };
        let environment = self
            .process_context
            .map(|context| context.environment)
            .unwrap_or_default();
        let session_environment = self
            .process_context
            .map(|context| context.session_environment);
        let value = if let Some(name) = argument.as_str() {
            session_environment
                .and_then(|overlay| {
                    overlay
                        .iter()
                        .find(|(candidate, _)| candidate.eq_ignore_ascii_case(name))
                        .map(|(_, value)| value.clone())
                })
                .or_else(|| {
                    environment
                        .iter()
                        .find(|(candidate, _)| candidate.eq_ignore_ascii_case(name))
                        .map(|(_, value)| value.clone())
                })
                .unwrap_or_default()
        } else {
            let index = argument.to_integer()?;
            if index <= 0 {
                return Err(Error::IllegalQuantity);
            }
            let Ok(index) = usize::try_from(index - 1) else {
                return Ok(Value::String(String::new()));
            };
            let mut entries = session_environment
                .map(|overlay| overlay.iter().collect::<Vec<_>>())
                .unwrap_or_default();
            entries.sort_by(|left, right| left.0.cmp(right.0));
            let overlay_len = entries.len();
            if index < overlay_len {
                let (name, value) = entries[index];
                format!("{name}={value}")
            } else {
                environment
                    .iter()
                    .filter(|(name, _)| {
                        session_environment.map_or(true, |overlay| {
                            !overlay.keys().any(|key| key.eq_ignore_ascii_case(name))
                        })
                    })
                    .nth(index - overlay_len)
                    .map(|(name, value)| format!("{name}={value}"))
                    .unwrap_or_default()
            }
        };
        self.check_string_len(&value)?;
        Ok(Value::String(value))
    }

    fn clock_value(&self, date: bool) -> Result<Value, Error> {
        let clock = self.clock_time();
        if date {
            crate::functions::eval_date_at(clock)
        } else {
            crate::functions::eval_time_at(clock)
        }
    }

    fn clock_time(&self) -> std::time::SystemTime {
        self.process_context
            .and_then(|context| context.session_clock.copied())
            .unwrap_or_else(std::time::SystemTime::now)
    }

    fn literal(&self, n: i64) -> Result<BasicInteger, Error> {
        BasicInteger::with_mode(self.mode, n)
    }

    fn parse_nested<T>(
        &mut self,
        parse: impl FnOnce(&mut Self) -> Result<T, Error>,
    ) -> Result<T, Error> {
        if self.expression_depth >= MAX_EXPRESSION_DEPTH {
            return Err(Error::ExpressionDepthExceeded {
                limit: MAX_EXPRESSION_DEPTH,
            });
        }
        self.expression_depth += 1;
        let result = parse(self);
        self.expression_depth -= 1;
        result
    }

    fn parse_expr(&mut self) -> Result<Value, Error> {
        self.parse_xor()
    }

    fn parse_xor(&mut self) -> Result<Value, Error> {
        let left = self.parse_or()?;
        if !matches!(
            self.peek(),
            Some(TokenInstance::Ident(name)) if matches!(name.as_str(), "XOR" | "EOR")
        ) {
            return Ok(left);
        }
        let mut left = into_integer(left, self.mode)?;
        while matches!(
            self.peek(),
            Some(TokenInstance::Ident(name)) if matches!(name.as_str(), "XOR" | "EOR")
        ) {
            self.bump();
            let right = into_integer(self.parse_or()?, self.mode)?;
            left = left.xor(right)?;
        }
        Ok(Value::Integer(left.value()))
    }

    fn parse_or(&mut self) -> Result<Value, Error> {
        let left = self.parse_and()?;
        if !matches!(self.peek(), Some(TokenInstance::Keyword(Token::Or))) {
            return Ok(left);
        }
        let mut left = into_integer(left, self.mode)?;
        while matches!(self.peek(), Some(TokenInstance::Keyword(Token::Or))) {
            self.bump();
            let right = into_integer(self.parse_and()?, self.mode)?;
            left = left.or(right)?;
        }
        Ok(Value::Integer(left.value()))
    }

    fn parse_and(&mut self) -> Result<Value, Error> {
        let left = self.parse_not()?;
        if !matches!(self.peek(), Some(TokenInstance::Keyword(Token::And))) {
            return Ok(left);
        }
        let mut left = into_integer(left, self.mode)?;
        while matches!(self.peek(), Some(TokenInstance::Keyword(Token::And))) {
            self.bump();
            let right = into_integer(self.parse_not()?, self.mode)?;
            left = left.and(right)?;
        }
        Ok(Value::Integer(left.value()))
    }

    fn parse_not(&mut self) -> Result<Value, Error> {
        if matches!(self.peek(), Some(TokenInstance::Keyword(Token::Not))) {
            self.bump();
            let mode = self.mode;
            let value = into_integer(self.parse_nested(Self::parse_not)?, mode)?;
            return Ok(Value::Integer(value.not()?.value()));
        }
        self.parse_comparison()
    }

    fn parse_comparison(&mut self) -> Result<Value, Error> {
        let mut left = self.parse_add()?;
        while let Some((comparison, token_count)) = self.comparison() {
            self.pos += token_count;
            let right = self.parse_add()?;
            left = compare_values(&left, &right, comparison)?;
        }
        Ok(left)
    }

    fn comparison(&self) -> Option<(Comparison, usize)> {
        use Comparison::*;

        match (self.tokens.get(self.pos), self.tokens.get(self.pos + 1)) {
            (
                Some(TokenInstance::Keyword(Token::Less)),
                Some(TokenInstance::Keyword(Token::Equal)),
            ) => Some((LessEqual, 2)),
            (
                Some(TokenInstance::Keyword(Token::Less)),
                Some(TokenInstance::Keyword(Token::Greater)),
            ) => Some((NotEqual, 2)),
            (
                Some(TokenInstance::Keyword(Token::Greater)),
                Some(TokenInstance::Keyword(Token::Equal)),
            ) => Some((GreaterEqual, 2)),
            (Some(TokenInstance::Keyword(Token::Equal)), _) => Some((Equal, 1)),
            (Some(TokenInstance::Keyword(Token::Less)), _) => Some((Less, 1)),
            (Some(TokenInstance::Keyword(Token::Greater)), _) => Some((Greater, 1)),
            _ => None,
        }
    }

    fn parse_add(&mut self) -> Result<Value, Error> {
        let mut left = self.parse_mul()?;
        loop {
            match self.peek() {
                Some(TokenInstance::Keyword(Token::Plus)) => {
                    self.bump();
                    let right = self.parse_mul()?;
                    left = match (left, right) {
                        (Value::String(l), Value::String(r)) => {
                            let length =
                                l.len().checked_add(r.len()).ok_or(Error::StringTooLong {
                                    length: usize::MAX,
                                    limit: self.max_string_bytes,
                                })?;
                            if length > self.max_string_bytes {
                                return Err(Error::StringTooLong {
                                    length,
                                    limit: self.max_string_bytes,
                                });
                            }
                            let mut out = l;
                            out.push_str(&r);
                            Value::String(out)
                        }
                        (left, right)
                            if (left.is_numeric() && right.is_numeric())
                                || matches!(left, Value::List(_))
                                || matches!(right, Value::List(_)) =>
                        {
                            binary_numeric(left, right, self.mode, NumericOperation::Add)?
                        }
                        _ => return Err(Error::TypeMismatch),
                    };
                }
                Some(TokenInstance::Keyword(Token::Minus)) => {
                    self.bump();
                    let right = self.parse_mul()?;
                    left = binary_numeric(left, right, self.mode, NumericOperation::Subtract)?;
                }
                _ => break,
            }
        }
        Ok(left)
    }

    fn parse_mul(&mut self) -> Result<Value, Error> {
        let mut left = self.parse_unary()?;
        loop {
            match self.peek() {
                Some(TokenInstance::Keyword(Token::Mul)) => {
                    self.bump();
                    let right = self.parse_unary()?;
                    left = binary_numeric(left, right, self.mode, NumericOperation::Multiply)?;
                }
                Some(TokenInstance::Keyword(Token::Div)) => {
                    self.bump();
                    let right = self.parse_unary()?;
                    left = binary_numeric(left, right, self.mode, NumericOperation::Divide)?;
                }
                Some(token)
                    if matches!(token, TokenInstance::IntegerDiv)
                        || matches!(token, TokenInstance::Ident(name) if name == "DIV") =>
                {
                    self.bump();
                    let left_integer = into_rounded_integer(left, self.mode)?;
                    let right_integer = into_rounded_integer(self.parse_unary()?, self.mode)?;
                    left = Value::Integer(left_integer.idiv(right_integer)?.value());
                }
                Some(TokenInstance::Keyword(Token::Mod)) => {
                    self.bump();
                    let left_integer = into_rounded_integer(left, self.mode)?;
                    let right_integer = into_rounded_integer(self.parse_unary()?, self.mode)?;
                    left = Value::Integer(left_integer.modulo(right_integer)?.value());
                }
                Some(TokenInstance::Keyword(token @ (Token::Npr | Token::Ncr))) => {
                    let token = *token;
                    self.bump();
                    let right = self.parse_unary()?;
                    left = evaluate_builtin(
                        token,
                        vec![left, right],
                        self.mode,
                        self.max_string_bytes,
                        self.rng,
                    )?;
                }
                _ => break,
            }
        }
        Ok(left)
    }

    fn parse_unary(&mut self) -> Result<Value, Error> {
        match self.peek() {
            Some(TokenInstance::Keyword(Token::Plus)) => {
                self.bump();
                let value = self.parse_nested(Self::parse_unary)?;
                if value.is_numeric()
                    || matches!(&value, Value::List(values) if values.iter().all(Value::is_numeric))
                {
                    Ok(value)
                } else {
                    Err(Error::TypeMismatch)
                }
            }
            Some(TokenInstance::Keyword(Token::Minus)) => {
                self.bump();
                match self.parse_nested(Self::parse_unary)? {
                    Value::Integer(value) => Ok(Value::Integer(
                        BasicInteger::with_mode(self.mode, value)?.neg()?.value(),
                    )),
                    Value::Real(value) => Ok(Value::Real(value.neg()?)),
                    Value::Complex(value) => Ok(Value::Complex(value.neg()?)),
                    Value::List(values) => Ok(Value::List(
                        values
                            .into_iter()
                            .map(|value| match value {
                                Value::Integer(value) => Ok(Value::Integer(
                                    BasicInteger::with_mode(self.mode, value)?.neg()?.value(),
                                )),
                                Value::Real(value) => Ok(Value::Real(value.neg()?)),
                                Value::Complex(value) => Ok(Value::Complex(value.neg()?)),
                                Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
                            })
                            .collect::<Result<Vec<_>, _>>()?,
                    )),
                    Value::String(_) => Err(Error::TypeMismatch),
                }
            }
            _ => self.parse_power(),
        }
    }

    fn parse_power(&mut self) -> Result<Value, Error> {
        let mut left = self.parse_postfix()?;
        while matches!(self.peek(), Some(TokenInstance::Keyword(Token::Pow))) {
            self.bump();
            let right = self.parse_nested(Self::parse_power_operand)?;
            left = binary_power(left, right)?;
        }
        Ok(left)
    }

    /// Parse one exponent operand. Unary signs are accepted immediately after
    /// a power operator without consuming a following power expression, which
    /// keeps chained exponentiation left-associative.
    fn parse_power_operand(&mut self) -> Result<Value, Error> {
        match self.peek() {
            Some(TokenInstance::Keyword(Token::Plus)) => {
                self.bump();
                let value = self.parse_nested(Self::parse_power_operand)?;
                if value.is_numeric() {
                    Ok(value)
                } else {
                    Err(Error::TypeMismatch)
                }
            }
            Some(TokenInstance::Keyword(Token::Minus)) => {
                self.bump();
                match self.parse_nested(Self::parse_power_operand)? {
                    Value::Integer(value) => Ok(Value::Integer(
                        BasicInteger::with_mode(self.mode, value)?.neg()?.value(),
                    )),
                    Value::Real(value) => Ok(Value::Real(value.neg()?)),
                    Value::Complex(value) => Ok(Value::Complex(value.neg()?)),
                    Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
                }
            }
            _ => self.parse_postfix(),
        }
    }

    fn parse_postfix(&mut self) -> Result<Value, Error> {
        let mut value = self.parse_primary()?;
        while matches!(self.peek(), Some(TokenInstance::Keyword(Token::Factorial))) {
            self.bump();
            value = evaluate_builtin(
                Token::Fact,
                vec![value],
                self.mode,
                self.max_string_bytes,
                self.rng,
            )?;
        }
        Ok(value)
    }

    fn parse_primary(&mut self) -> Result<Value, Error> {
        match self.bump() {
            Some(TokenInstance::Number(n)) => {
                let bi = self.literal(n)?;
                Ok(Value::Integer(bi.value()))
            }
            Some(TokenInstance::Real(number)) => Ok(Value::Real(BasicReal::parse(&number)?)),
            Some(TokenInstance::Ident(name)) => {
                if matches!(self.peek(), Some(TokenInstance::LParen)) {
                    if name == "SADD" {
                        self.bump();
                        let Some(TokenInstance::Ident(variable)) = self.bump() else {
                            return Err(Error::syntax("SADD expects a string variable"));
                        };
                        if !crate::value::is_string_variable(&variable) {
                            return Err(Error::syntax("SADD expects a string variable"));
                        }
                        if !matches!(self.bump(), Some(TokenInstance::RParen)) {
                            return Err(Error::syntax("SADD expects exactly one string variable"));
                        }
                        return self
                            .vars
                            .get(&sadd_address_key(&variable))
                            .cloned()
                            .ok_or_else(|| Error::syntax("SADD requires an active BASIC session"));
                    }
                    if name == "COMMAND$" {
                        let args = self.parse_call_arguments(&name)?;
                        if !args.is_empty() {
                            return Err(Error::syntax("COMMAND$ expects no arguments"));
                        }
                        return self.command_value();
                    }
                    if name == "ENVIRON$" {
                        let args = self.parse_call_arguments(&name)?;
                        return self.environment_value(&args);
                    }
                    if matches!(name.as_str(), "DATE$" | "TIME$") {
                        let args = self.parse_call_arguments(&name)?;
                        if !args.is_empty() {
                            return Err(Error::syntax(format!("{name} expects no arguments")));
                        }
                        return self.clock_value(name == "DATE$");
                    }
                    if name == "INKEY$" {
                        let args = self.parse_call_arguments(&name)?;
                        if !args.is_empty() {
                            return Err(Error::syntax("INKEY$ expects no arguments"));
                        }
                        let key = crate::screen::pop_key();
                        self.check_string_len(&key)?;
                        return Ok(Value::String(key));
                    }
                    if name == "CURDIR$" {
                        let args = self.parse_call_arguments(&name)?;
                        if !args.is_empty() {
                            return Err(Error::syntax("CURDIR$ expects no arguments"));
                        }
                        let files = self.files.ok_or_else(|| {
                            Error::syntax("CURDIR$ requires an active BASIC session")
                        })?;
                        let directory = files.current_directory()?;
                        self.check_string_len(&directory)?;
                        return Ok(Value::String(directory));
                    }
                    if name == "SCREENINFO" {
                        let args = self.parse_call_arguments(&name)?;
                        let [selector] = args.as_slice() else {
                            return Err(Error::syntax("SCREENINFO expects one selector"));
                        };
                        let selector = selector.to_integer()?;
                        let graphics = self.graphics.ok_or_else(|| {
                            Error::syntax("SCREENINFO requires an active graphics session")
                        })?;
                        let (width, height) = graphics.dimensions();
                        let display = crate::screen::display_info();
                        let value = match selector {
                            0 => i64::try_from(width).map_err(|_| Error::IllegalQuantity)?,
                            1 => i64::try_from(height).map_err(|_| Error::IllegalQuantity)?,
                            2 => i64::from(if display.color_depth == 0 {
                                32
                            } else {
                                display.color_depth
                            }),
                            3 => i64::from(if display.scale == 0 { 1 } else { display.scale }),
                            _ => return Err(Error::IllegalQuantity),
                        };
                        return Ok(Value::Integer(value));
                    }
                    if name == "MULTIKEY" {
                        let args = self.parse_call_arguments(&name)?;
                        let [keycode] = args.as_slice() else {
                            return Err(Error::syntax("MULTIKEY expects one keycode"));
                        };
                        let keycode = keycode.to_integer()?;
                        if !(1..=255).contains(&keycode) {
                            return Err(Error::IllegalQuantity);
                        }
                        return Ok(Value::Integer(crate::screen::multikey(keycode as u8)));
                    }
                    if name == "CSRLIN" {
                        let args = self.parse_call_arguments(&name)?;
                        if !args.is_empty() {
                            return Err(Error::syntax("CSRLIN expects no arguments"));
                        }
                        return Ok(Value::Integer(self.cursor_row.unwrap_or(1) as i64));
                    }
                    if name == "TIMER" {
                        let args = self.parse_call_arguments(&name)?;
                        if !args.is_empty() {
                            return Err(Error::syntax("TIMER expects no arguments"));
                        }
                        return timer_value_at(self.clock_time());
                    }
                    if matches!(name.as_str(), "POINT" | "SCRN" | "PMAP") {
                        let args = self.parse_call_arguments(&name)?;
                        let graphics = self.graphics.ok_or_else(|| {
                            Error::syntax(format!("{name} requires an active graphics session"))
                        })?;
                        return match name.as_str() {
                            "POINT" => match args.as_slice() {
                                [] => {
                                    let (x, y) = graphics.cursor();
                                    Ok(Value::List(vec![
                                        coordinate_value(x)?,
                                        coordinate_value(y)?,
                                    ]))
                                }
                                [direction] => match direction.to_integer()? {
                                    0 => Ok(coordinate_value(graphics.cursor().0)?),
                                    1 => Ok(coordinate_value(graphics.cursor().1)?),
                                    _ => Err(Error::IllegalQuantity),
                                },
                                [x, y] => {
                                    let x = into_real(x.clone())?.value();
                                    let y = into_real(y.clone())?.value();
                                    Ok(Value::Integer(i64::from(graphics.query_pixel(x, y)?)))
                                }
                                _ => Err(Error::syntax("POINT expects (), (0), (1), or (x,y)")),
                            },
                            "SCRN" => {
                                let [x, y] = args.as_slice() else {
                                    return Err(Error::syntax("SCRN expects x,y"));
                                };
                                let x = into_real(x.clone())?.value();
                                let y = into_real(y.clone())?.value();
                                let color = graphics.query_pixel(x, y)?;
                                Ok(Value::Integer(graphics.palette_index(color)?))
                            }
                            "PMAP" => {
                                let [coordinate, direction] = args.as_slice() else {
                                    return Err(Error::syntax("PMAP expects coordinate,direction"));
                                };
                                let coordinate = into_real(coordinate.clone())?.value();
                                let direction = direction.to_integer()?;
                                let mapped = graphics.pmap(coordinate, direction)?;
                                if direction <= 1 {
                                    let mapped = Value::Real(BasicReal::new(mapped)?);
                                    Ok(Value::Integer(
                                        into_rounded_integer(mapped, self.mode)?.value(),
                                    ))
                                } else {
                                    Ok(Value::Real(BasicReal::new(mapped)?))
                                }
                            }
                            _ => unreachable!(),
                        };
                    }
                    if name == "INP" {
                        let args = self.parse_call_arguments(&name)?;
                        let [argument] = args.as_slice() else {
                            return Err(Error::syntax("INP expects one port"));
                        };
                        let port = argument.to_integer()?;
                        let port = usize::try_from(port).map_err(|_| Error::IllegalQuantity)?;
                        let ports = self
                            .virtual_ports
                            .ok_or_else(|| Error::syntax("INP requires an active BASIC session"))?;
                        let value = ports.get(port).copied().ok_or(Error::IllegalQuantity)?;
                        return Ok(Value::Integer(i64::from(value)));
                    }
                    if matches!(name.as_str(), "LOC" | "LOF" | "EOF") {
                        let args = self.parse_call_arguments(&name)?;
                        let [argument] = args.as_slice() else {
                            return Err(Error::syntax(format!("{name} expects one channel")));
                        };
                        let channel = FileStore::channel(argument.to_integer()?)?;
                        let files = self.files.ok_or_else(|| {
                            Error::syntax("file status function requires an active BASIC session")
                        })?;
                        return Ok(Value::Integer(match name.as_str() {
                            "LOC" => i64::try_from(files.location(channel)?)
                                .map_err(|_| Error::IllegalQuantity)?,
                            "LOF" => i64::try_from(files.length(channel)?)
                                .map_err(|_| Error::IllegalQuantity)?,
                            "EOF" => files.eof_value(channel)?,
                            _ => unreachable!(),
                        }));
                    }
                    if matches!(name.as_str(), "LBOUND" | "UBOUND") {
                        return self.parse_array_bound_call(name == "UBOUND");
                    }
                    if matches!(
                        name.as_str(),
                        "OBJECTX"
                            | "OBJECTY"
                            | "OBJECTZ"
                            | "OBJECTSCALE"
                            | "OBJECTWIDTH"
                            | "OBJECTHEIGHT"
                    ) {
                        return self.parse_perspective_object_call(&name);
                    }
                    if name == "PCOLLISION" {
                        return self.parse_sprite_collision_call();
                    }
                    if matches!(
                        name.as_str(),
                        "SPRITEX"
                            | "SPRITEY"
                            | "SPRITEZ"
                            | "SPRITESCALE"
                            | "SPRITEVX"
                            | "SPRITEVY"
                            | "SPRITEVZ"
                            | "SPRITEAX"
                            | "SPRITEAY"
                            | "SPRITEAZ"
                    ) {
                        return self.parse_sprite_motion_call(&name);
                    }
                    if matches!(
                        name.as_str(),
                        "MOUSEX" | "MOUSEY" | "MOUSEINSIDE" | "MOUSEBUTTON"
                    ) {
                        let args = self.parse_call_arguments(&name)?;
                        let state = crate::screen::pointer_state();
                        return match name.as_str() {
                            "MOUSEX" | "MOUSEY" | "MOUSEINSIDE" => {
                                if !args.is_empty() {
                                    return Err(Error::syntax(format!(
                                        "{name} expects no arguments"
                                    )));
                                }
                                Ok(Value::Integer(match name.as_str() {
                                    "MOUSEX" => state.x,
                                    "MOUSEY" => state.y,
                                    "MOUSEINSIDE" => -i64::from(state.inside),
                                    _ => unreachable!(),
                                }))
                            }
                            "MOUSEBUTTON" => {
                                let [button] = args.as_slice() else {
                                    return Err(Error::syntax("MOUSEBUTTON expects one button"));
                                };
                                let button = button.to_integer()?;
                                if !(1..=3).contains(&button) {
                                    return Err(Error::IllegalQuantity);
                                }
                                let mask = 1_u8 << (button - 1);
                                Ok(Value::Integer(if state.buttons & mask != 0 {
                                    -1
                                } else {
                                    0
                                }))
                            }
                            _ => unreachable!(),
                        };
                    }
                    if matches!(name.as_str(), "PXL-TEST" | "PXLTEST" | "PT-TEST" | "PTTEST") {
                        let args = self.parse_call_arguments(&name)?;
                        return evaluate_ti_graph_query(&name, &args, self.mode, self.graph);
                    }
                    if matches!(name.as_str(), "BITXNOR" | "BITIMPLIES") {
                        let args = self.parse_call_arguments(&name)?;
                        let [left, right] = args.as_slice() else {
                            return Err(Error::syntax(format!(
                                "{name} expects exactly two arguments"
                            )));
                        };
                        let left = into_integer(left.clone(), self.mode)?;
                        let right = into_integer(right.clone(), self.mode)?;
                        let value = if name == "BITXNOR" {
                            left.xor(right)?.not()?
                        } else {
                            left.not()?.or(right)?
                        };
                        return Ok(Value::Integer(value.value()));
                    }
                    if name == "TEXTCELL" {
                        let args = self.parse_call_arguments(&name)?;
                        let (row, column, field) = match args.as_slice() {
                            [row, column] => (row, column, 0),
                            [row, column, field] => {
                                (row, column, into_integer(field.clone(), self.mode)?.value())
                            }
                            _ => return Err(Error::syntax("TEXTCELL expects row,column[,field]")),
                        };
                        let row = into_integer(row.clone(), self.mode)?.value();
                        let column = into_integer(column.clone(), self.mode)?.value();
                        let row = usize::try_from(row).map_err(|_| Error::IllegalQuantity)?;
                        let column = usize::try_from(column).map_err(|_| Error::IllegalQuantity)?;
                        let screen = self.text_screen.ok_or_else(|| {
                            Error::syntax("TEXTCELL requires an active BASIC session")
                        })?;
                        let cell = screen
                            .lock()
                            .unwrap_or_else(|poisoned| poisoned.into_inner())
                            .cell(row, column)
                            .ok_or(Error::IllegalQuantity)?;
                        return Ok(Value::Integer(match field {
                            0 => i64::from(u32::from(cell.character)),
                            1 => cell.foreground,
                            2 => cell.background,
                            _ => return Err(Error::IllegalQuantity),
                        }));
                    }
                    if is_named_builtin(&name) {
                        let args = self.parse_call_arguments(&name)?;
                        let value = evaluate_named_builtin(&name, &args, self.max_string_bytes)?;
                        if let Value::String(text) = &value {
                            self.check_string_len(text)?;
                        }
                        return Ok(value);
                    }
                    if let Some(function_name) = compact_function_name(&name) {
                        return self.parse_user_function_call(function_name.to_string());
                    }
                    // Array reference: consume '(' and parse subscripts.
                    self.bump();
                    let mut indices = Vec::new();
                    loop {
                        if matches!(self.peek(), Some(TokenInstance::RParen)) {
                            self.bump();
                            break;
                        }
                        let start = self.pos;
                        let value = self.parse_nested(Self::parse_expr)?;
                        if self.pos == start {
                            return Err(Error::syntax("missing array subscript"));
                        }
                        let index = into_integer(value, self.mode)?.value();
                        indices.push(index);
                        match self.peek() {
                            Some(TokenInstance::Comma) => {
                                self.bump();
                                if matches!(self.peek(), Some(TokenInstance::RParen) | None) {
                                    return Err(Error::syntax("missing array subscript"));
                                }
                            }
                            Some(TokenInstance::RParen) => {
                                self.bump();
                                break;
                            }
                            _ => {
                                return Err(Error::syntax(
                                    "expected ',' or ')' in array subscript",
                                ));
                            }
                        }
                    }
                    let value = if let Some(Value::List(values)) = self.vars.get(&name) {
                        let [index] = indices.as_slice() else {
                            return Err(Error::BadSubscript);
                        };
                        let index = usize::try_from(*index).map_err(|_| Error::BadSubscript)?;
                        if index == 0 || index > values.len() {
                            return Err(Error::BadSubscript);
                        }
                        values[index - 1].clone()
                    } else {
                        self.arrays.load(&name, &indices)?
                    };
                    if let Value::String(s) = &value {
                        self.check_string_len(s)?;
                    }
                    Ok(value)
                } else {
                    if name == "COMMAND$" {
                        return self.command_value();
                    }
                    if name == "ENVIRON$" {
                        return Err(Error::syntax("ENVIRON$ requires one name or index"));
                    }
                    if matches!(name.as_str(), "DATE$" | "TIME$") {
                        return self.clock_value(name == "DATE$");
                    }
                    if name == "TIMER" {
                        return timer_value_at(self.clock_time());
                    }
                    if name == "INKEY$" {
                        let key = crate::screen::pop_key();
                        self.check_string_len(&key)?;
                        return Ok(Value::String(key));
                    }
                    if name == "CURDIR$" {
                        let files = self.files.ok_or_else(|| {
                            Error::syntax("CURDIR$ requires an active BASIC session")
                        })?;
                        let directory = files.current_directory()?;
                        self.check_string_len(&directory)?;
                        return Ok(Value::String(directory));
                    }
                    if name == "CSRLIN" {
                        return Ok(Value::Integer(self.cursor_row.unwrap_or(1) as i64));
                    }
                    let value = self
                        .vars
                        .get(&name)
                        .cloned()
                        .unwrap_or_else(|| default_for_declared(&name, self.vars));
                    if let Value::String(s) = &value {
                        self.check_string_len(s)?;
                    }
                    Ok(value)
                }
            }
            Some(TokenInstance::String(s)) => {
                self.check_string_len(&s)?;
                Ok(Value::String(s))
            }
            Some(TokenInstance::LBrace) => self.parse_list_literal(),
            Some(TokenInstance::Keyword(Token::Rnd))
                if !matches!(self.peek(), Some(TokenInstance::LParen)) =>
            {
                evaluate_builtin(
                    Token::Rnd,
                    vec![Value::Integer(1)],
                    self.mode,
                    self.max_string_bytes,
                    self.rng,
                )
            }
            Some(TokenInstance::Keyword(Token::Rand))
                if !matches!(self.peek(), Some(TokenInstance::LParen)) =>
            {
                evaluate_builtin(
                    Token::Rand,
                    Vec::new(),
                    self.mode,
                    self.max_string_bytes,
                    self.rng,
                )
            }
            Some(TokenInstance::Keyword(
                token @ (Token::Fmin
                | Token::Fmax
                | Token::Nderiv
                | Token::Fnint
                | Token::Sum
                | Token::Solve
                | Token::Piecewise),
            )) => self.parse_numerical_function(token),
            Some(TokenInstance::Keyword(Token::Usr)) => {
                let index = match self.peek().cloned() {
                    Some(TokenInstance::Number(value)) if (0..=9).contains(&value) => {
                        self.bump();
                        value as usize
                    }
                    _ => 0,
                };
                let args = self.parse_call_arguments("USR")?;
                let [argument] = args.as_slice() else {
                    return Err(Error::syntax("USR expects one numeric argument"));
                };
                let addresses = self
                    .usr_addresses
                    .ok_or_else(|| Error::syntax("USR requires an active BASIC session"))?;
                let address =
                    addresses[index].ok_or(Error::SystemServiceNotRegistered { address: index })?;
                let services = self
                    .system_services
                    .ok_or_else(|| Error::syntax("USR requires an active BASIC session"))?;
                let service = services
                    .get(&address)
                    .copied()
                    .ok_or(Error::SystemServiceNotRegistered { address })?;
                Ok(Value::Integer(service(argument.to_integer()?)?))
            }
            Some(TokenInstance::Keyword(token)) if is_builtin_function(token) => {
                self.parse_function_call(token)
            }
            Some(TokenInstance::Keyword(Token::Fn)) => {
                let Some(TokenInstance::Ident(name)) = self.bump() else {
                    return Err(Error::syntax("FN requires a function name"));
                };
                self.parse_user_function_call(name)
            }
            Some(TokenInstance::LParen) => {
                let v = self.parse_nested(Self::parse_expr)?;
                match self.peek() {
                    Some(TokenInstance::RParen) => {
                        self.bump();
                    }
                    _ => return Err(Error::syntax("expected ')'")),
                };
                Ok(v)
            }
            Some(other) => Err(Error::syntax(format!(
                "unexpected token in expression: {other:?}"
            ))),
            None => Err(Error::syntax("unexpected end of expression")),
        }
    }

    fn parse_function_call(&mut self, token: Token) -> Result<Value, Error> {
        let args = self.parse_call_arguments(token.to_text())?;

        if token == Token::Peek {
            if args.len() != 1 {
                return Err(Error::syntax("PEEK expects one argument"));
            }
            let address = args[0].to_integer()?;
            if !(0..=65_535).contains(&address) {
                return Err(Error::IllegalQuantity);
            }
            if let Some(memory) = self.virtual_memory {
                let physical = self
                    .memory_segment
                    .saturating_mul(16)
                    .saturating_add(address as usize);
                let byte = *memory.get(physical).ok_or(Error::IllegalQuantity)?;
                return Ok(Value::Integer(i64::from(byte)));
            }
        }
        if token == Token::Pos {
            if let Some(column) = self.output_column {
                return evaluate_position(&args, self.mode, column);
            }
        }
        if token == Token::Fre {
            if let Some(remaining_bytes) = self.free_storage_bytes {
                return evaluate_free(&args, self.mode, remaining_bytes);
            }
        }
        evaluate_builtin(token, args, self.mode, self.max_string_bytes, self.rng)
    }

    fn parse_array_bound_call(&mut self, upper: bool) -> Result<Value, Error> {
        let function = if upper { "UBOUND" } else { "LBOUND" };
        if !matches!(self.bump(), Some(TokenInstance::LParen)) {
            return Err(Error::syntax(format!("{function} requires '('")));
        }
        let name = match self.bump() {
            Some(TokenInstance::Ident(name)) => name,
            _ => return Err(Error::syntax(format!("{function} expects an array name"))),
        };
        let dimension = match self.peek() {
            Some(TokenInstance::RParen) => 1,
            Some(TokenInstance::Comma) => {
                self.bump();
                let value = self.parse_nested(Self::parse_expr)?;
                let dimension = into_integer(value, self.mode)?.value();
                usize::try_from(dimension).map_err(|_| Error::BadSubscript)?
            }
            _ => {
                return Err(Error::syntax(format!(
                    "{function} expects array[,dimension]"
                )))
            }
        };
        if !matches!(self.bump(), Some(TokenInstance::RParen)) {
            return Err(Error::syntax(format!("expected ')' in {function}")));
        }
        Ok(Value::Integer(self.arrays.bound(&name, dimension, upper)?))
    }

    fn parse_perspective_object_call(&mut self, function: &str) -> Result<Value, Error> {
        if !matches!(self.bump(), Some(TokenInstance::LParen)) {
            return Err(Error::syntax(format!(
                "{function} requires an opening parenthesis"
            )));
        }
        let id = self.parse_sprite_identifier_argument()?;
        if !matches!(self.bump(), Some(TokenInstance::RParen)) {
            return Err(Error::syntax(format!(
                "{function} expects one perspective object"
            )));
        }
        let graphics = self
            .graphics
            .ok_or_else(|| Error::syntax(format!("{function} requires an active BASIC session")))?;
        let state = graphics
            .perspective_object_state(&id)
            .ok_or_else(|| Error::syntax(format!("undefined perspective object {id}")))?;
        let index = match function {
            "OBJECTX" => 0,
            "OBJECTY" => 1,
            "OBJECTZ" => 2,
            "OBJECTSCALE" => 3,
            "OBJECTWIDTH" => 4,
            "OBJECTHEIGHT" => 5,
            _ => unreachable!("perspective object function was prevalidated"),
        };
        Ok(Value::Real(BasicReal::new(state[index])?))
    }

    fn parse_sprite_collision_call(&mut self) -> Result<Value, Error> {
        if !matches!(self.bump(), Some(TokenInstance::LParen)) {
            return Err(Error::syntax("PCOLLISION requires '('"));
        }
        let first = self.parse_sprite_identifier_argument()?;
        let second = if matches!(self.peek(), Some(TokenInstance::Comma)) {
            self.bump();
            Some(self.parse_sprite_identifier_argument()?)
        } else {
            None
        };
        if !matches!(self.bump(), Some(TokenInstance::RParen)) {
            return Err(Error::syntax("PCOLLISION expects sprite[,sprite]"));
        }
        let graphics = self
            .graphics
            .ok_or_else(|| Error::syntax("PCOLLISION requires an active BASIC session"))?;
        Ok(Value::Integer(
            if graphics.sprites_collide(&first, second.as_deref()) {
                -1
            } else {
                0
            },
        ))
    }

    fn parse_sprite_motion_call(&mut self, function: &str) -> Result<Value, Error> {
        if !matches!(self.bump(), Some(TokenInstance::LParen)) {
            return Err(Error::syntax(format!("{function} requires '('")));
        }
        let id = self.parse_sprite_identifier_argument()?;
        if !matches!(self.bump(), Some(TokenInstance::RParen)) {
            return Err(Error::syntax(format!("{function} expects one sprite")));
        }
        let graphics = self
            .graphics
            .ok_or_else(|| Error::syntax(format!("{function} requires an active BASIC session")))?;
        let value = match function {
            "SPRITEX" | "SPRITEY" | "SPRITEVX" | "SPRITEVY" | "SPRITEAX" | "SPRITEAY" => {
                let motion = graphics
                    .sprite_motion(&id)
                    .ok_or_else(|| Error::syntax(format!("undefined sprite {id}")))?;
                let index = match function {
                    "SPRITEX" => 0,
                    "SPRITEY" => 1,
                    "SPRITEVX" => 2,
                    "SPRITEVY" => 3,
                    "SPRITEAX" => 4,
                    "SPRITEAY" => 5,
                    _ => unreachable!(),
                };
                motion[index]
            }
            "SPRITEZ" | "SPRITESCALE" | "SPRITEVZ" | "SPRITEAZ" => {
                let depth = graphics
                    .sprite_depth(&id)
                    .ok_or_else(|| Error::syntax(format!("undefined sprite {id}")))?;
                let index = match function {
                    "SPRITEZ" => 0,
                    "SPRITESCALE" => 1,
                    "SPRITEVZ" => 2,
                    "SPRITEAZ" => 3,
                    _ => unreachable!(),
                };
                depth[index]
            }
            _ => unreachable!("sprite function was prevalidated"),
        };
        Ok(Value::Real(BasicReal::new(value)?))
    }

    fn parse_sprite_identifier_argument(&mut self) -> Result<String, Error> {
        if let Some(TokenInstance::Ident(name)) = self.peek() {
            if !crate::value::is_string_variable(name)
                && matches!(
                    self.tokens.get(self.pos + 1),
                    Some(TokenInstance::Comma | TokenInstance::RParen)
                )
            {
                let name = name.clone();
                self.bump();
                return Ok(name);
            }
        }
        self.parse_nested(Self::parse_expr)?
            .into_string()
            .ok_or(Error::TypeMismatch)
    }

    fn parse_call_arguments(&mut self, label: &str) -> Result<Vec<Value>, Error> {
        if !matches!(self.peek(), Some(TokenInstance::LParen)) {
            return Err(Error::syntax(format!("{label} requires '('")));
        }
        self.bump();

        let mut args = Vec::new();
        if matches!(self.peek(), Some(TokenInstance::RParen)) {
            self.bump();
        } else {
            loop {
                if matches!(self.peek(), Some(TokenInstance::Comma) | None) {
                    return Err(Error::syntax(format!("missing argument to {label}")));
                }
                args.push(self.parse_nested(Self::parse_expr)?);
                match self.peek() {
                    Some(TokenInstance::Comma) => {
                        self.bump();
                        if matches!(self.peek(), Some(TokenInstance::RParen) | None) {
                            return Err(Error::syntax(format!("missing argument to {label}")));
                        }
                    }
                    Some(TokenInstance::RParen) => {
                        self.bump();
                        break;
                    }
                    _ => return Err(Error::syntax(format!("expected ',' or ')' in {label}"))),
                }
            }
        }

        Ok(args)
    }

    fn parse_list_literal(&mut self) -> Result<Value, Error> {
        let mut values = Vec::new();
        let mut numeric_elements = 0_usize;
        if matches!(self.peek(), Some(TokenInstance::RBrace)) {
            self.bump();
            return Ok(Value::List(values));
        }
        loop {
            if values.len() == MAX_LIST_ELEMENTS {
                return Err(Error::IllegalQuantity);
            }
            let value = self.parse_nested(Self::parse_expr)?;
            let count = numeric_list_element_count(&value).ok_or(Error::TypeMismatch)?;
            numeric_elements = numeric_elements
                .checked_add(count)
                .ok_or(Error::ArrayTooLarge)?;
            if numeric_elements > MAX_LIST_ELEMENTS {
                return Err(Error::ArrayTooLarge);
            }
            values.push(value);
            match self.peek() {
                Some(TokenInstance::Comma) => {
                    self.bump();
                    if matches!(self.peek(), Some(TokenInstance::RBrace) | None) {
                        return Err(Error::syntax("missing list element"));
                    }
                }
                Some(TokenInstance::RBrace) => {
                    self.bump();
                    break;
                }
                _ => return Err(Error::syntax("expected ',' or '}' in list literal")),
            }
        }
        Ok(Value::List(values))
    }

    fn parse_numerical_function(&mut self, token: Token) -> Result<Value, Error> {
        let args = self.take_raw_function_arguments(token)?;
        match token {
            Token::Nderiv => {
                expect_raw_arity(token, &args, 3, 4)?;
                let variable = raw_variable(token, &args[1])?;
                let point = self.evaluate_raw_real(&args[2])?;
                let step = if let Some(step) = args.get(3) {
                    self.evaluate_raw_real(step)?
                } else {
                    1e-5 * point.abs().max(1.0)
                };
                let value = numerical::derivative(
                    |argument| self.evaluate_scoped_real(&args[0], &variable, argument),
                    point,
                    step,
                )?;
                Ok(Value::Real(value))
            }
            Token::Fnint => {
                expect_raw_arity(token, &args, 4, 5)?;
                let variable = raw_variable(token, &args[1])?;
                let lower = self.evaluate_raw_real(&args[2])?;
                let upper = self.evaluate_raw_real(&args[3])?;
                let tolerance = if let Some(tolerance) = args.get(4) {
                    self.evaluate_raw_real(tolerance)?
                } else {
                    1e-9
                };
                let value = numerical::integrate(
                    |argument| self.evaluate_scoped_real(&args[0], &variable, argument),
                    lower,
                    upper,
                    tolerance,
                )?;
                Ok(Value::Real(value))
            }
            Token::Fmin | Token::Fmax => {
                expect_raw_arity(token, &args, 4, 5)?;
                let variable = raw_variable(token, &args[1])?;
                let lower = self.evaluate_raw_real(&args[2])?;
                let upper = self.evaluate_raw_real(&args[3])?;
                let tolerance = if let Some(tolerance) = args.get(4) {
                    self.evaluate_raw_real(tolerance)?
                } else {
                    1e-9
                };
                let kind = if token == Token::Fmin {
                    Extremum::Minimum
                } else {
                    Extremum::Maximum
                };
                let value = numerical::extremum(
                    |argument| self.evaluate_scoped_real(&args[0], &variable, argument),
                    lower,
                    upper,
                    tolerance,
                    kind,
                )?;
                Ok(Value::Real(value))
            }
            Token::Solve => {
                expect_raw_arity(token, &args, 4, 5)?;
                let variable = raw_variable(token, &args[1])?;
                let lower = self.evaluate_raw_real(&args[2])?;
                let upper = self.evaluate_raw_real(&args[3])?;
                let tolerance = if let Some(tolerance) = args.get(4) {
                    self.evaluate_raw_real(tolerance)?
                } else {
                    1e-9
                };
                let value = numerical::solve(
                    |argument| self.evaluate_scoped_real(&args[0], &variable, argument),
                    lower,
                    upper,
                    tolerance,
                )?;
                Ok(Value::Real(value))
            }
            Token::Sum if args.len() == 1 => {
                let Value::List(values) = self.evaluate_raw(&args[0])? else {
                    return Err(Error::TypeMismatch);
                };
                let mut total = Value::Integer(0);
                for value in values {
                    total = binary_numeric(total, value, self.mode, NumericOperation::Add)?;
                }
                Ok(total)
            }
            Token::Sum => self.evaluate_sum(token, &args),
            Token::Piecewise => self.evaluate_piecewise(token, &args),
            _ => unreachable!("caller accepts only numerical function tokens"),
        }
    }

    fn take_raw_function_arguments(
        &mut self,
        token: Token,
    ) -> Result<Vec<Vec<TokenInstance>>, Error> {
        if !matches!(self.peek(), Some(TokenInstance::LParen)) {
            return Err(Error::syntax(format!("{} requires '('", token.to_text())));
        }
        self.bump();
        if matches!(self.peek(), Some(TokenInstance::RParen)) {
            self.bump();
            return Ok(Vec::new());
        }

        let mut args = Vec::new();
        let mut start = self.pos;
        let mut depth = 0_usize;
        let mut brace_depth = 0_usize;
        let mut cursor = self.pos;
        loop {
            match self.tokens.get(cursor) {
                Some(TokenInstance::LParen) => depth += 1,
                Some(TokenInstance::LBrace) => brace_depth += 1,
                Some(TokenInstance::RBrace) if brace_depth > 0 => brace_depth -= 1,
                Some(TokenInstance::RParen) if depth == 0 && brace_depth == 0 => {
                    if cursor == start {
                        return Err(Error::syntax(format!(
                            "missing argument to {}",
                            token.to_text()
                        )));
                    }
                    args.push(self.tokens[start..cursor].to_vec());
                    self.pos = cursor + 1;
                    return Ok(args);
                }
                Some(TokenInstance::RParen) if depth > 0 => depth -= 1,
                Some(TokenInstance::RParen) => {
                    return Err(Error::syntax(format!(
                        "mismatched ')' in {}",
                        token.to_text()
                    )))
                }
                Some(TokenInstance::Comma) if depth == 0 && brace_depth == 0 => {
                    if cursor == start {
                        return Err(Error::syntax(format!(
                            "missing argument to {}",
                            token.to_text()
                        )));
                    }
                    args.push(self.tokens[start..cursor].to_vec());
                    start = cursor + 1;
                }
                Some(_) => {}
                None => {
                    return Err(Error::syntax(format!(
                        "expected ')' in {}",
                        token.to_text()
                    )))
                }
            }
            cursor += 1;
        }
    }

    fn evaluate_raw(&mut self, tokens: &[TokenInstance]) -> Result<Value, Error> {
        evaluate_runtime_inner(
            self.mode,
            tokens,
            self.vars,
            self.arrays,
            self.max_string_bytes,
            self.rng,
            self.user_functions,
            self.function_depth,
            self.max_function_depth,
            self.output_column,
            self.cursor_row,
            self.text_screen,
            self.free_storage_bytes,
            self.graph,
            self.graphics,
            self.virtual_memory,
            self.virtual_ports,
            self.memory_segment,
            self.files,
            self.system_services,
            self.usr_addresses,
            self.process_context,
        )
    }

    fn evaluate_raw_real(&mut self, tokens: &[TokenInstance]) -> Result<f64, Error> {
        Ok(into_real(self.evaluate_raw(tokens)?)?.value())
    }

    fn evaluate_scoped_real(
        &mut self,
        tokens: &[TokenInstance],
        variable: &str,
        argument: f64,
    ) -> Result<f64, Error> {
        let mut variables = self.vars.clone();
        variables.insert(variable.to_string(), Value::Real(BasicReal::new(argument)?));
        let mut rng = self.rng.clone();
        let value = evaluate_runtime_inner(
            self.mode,
            tokens,
            &variables,
            self.arrays,
            self.max_string_bytes,
            &mut rng,
            self.user_functions,
            self.function_depth,
            self.max_function_depth,
            self.output_column,
            self.cursor_row,
            self.text_screen,
            self.free_storage_bytes,
            self.graph,
            self.graphics,
            self.virtual_memory,
            self.virtual_ports,
            self.memory_segment,
            self.files,
            self.system_services,
            self.usr_addresses,
            self.process_context,
        )?;
        Ok(into_real(value)?.value())
    }

    fn evaluate_sum(&mut self, token: Token, args: &[Vec<TokenInstance>]) -> Result<Value, Error> {
        const MAX_TERMS: u64 = 1_000_000;
        expect_raw_arity(token, args, 4, 5)?;
        let variable = raw_variable(token, &args[1])?;
        let lower = into_integer(self.evaluate_raw(&args[2])?, self.mode)?.value();
        let upper = into_integer(self.evaluate_raw(&args[3])?, self.mode)?.value();
        let step = if let Some(step) = args.get(4) {
            into_integer(self.evaluate_raw(step)?, self.mode)?.value()
        } else {
            1
        };
        if step == 0 || (step > 0 && lower > upper) || (step < 0 && lower < upper) {
            return Err(Error::IllegalQuantity);
        }
        let distance = if step > 0 {
            i128::from(upper) - i128::from(lower)
        } else {
            i128::from(lower) - i128::from(upper)
        };
        let terms = distance / i128::from(step.unsigned_abs()) + 1;
        if terms > i128::from(MAX_TERMS) {
            return Err(Error::IllegalQuantity);
        }

        let mut total = BasicReal::new(0.0)?;
        let mut current = lower;
        for index in 0..terms {
            let argument = BasicReal::from_integer(current)?.value();
            let value = self.evaluate_scoped_real(&args[0], &variable, argument)?;
            total = total.add(BasicReal::new(value)?)?;
            if index + 1 < terms {
                current = current.checked_add(step).ok_or(if step > 0 {
                    Error::IntegerOverflow
                } else {
                    Error::IntegerUnderflow
                })?;
            }
        }
        Ok(Value::Real(total))
    }

    fn evaluate_piecewise(
        &mut self,
        _token: Token,
        args: &[Vec<TokenInstance>],
    ) -> Result<Value, Error> {
        if args.len() < 2 {
            return Err(Error::syntax("PIECEWISE expects condition/value pairs"));
        }
        let pair_count = args.len() / 2;
        for pair in 0..pair_count {
            let condition = self.evaluate_raw(&args[pair * 2])?;
            if condition.numeric_truth()? {
                return self.evaluate_raw(&args[pair * 2 + 1]);
            }
        }
        if args.len() % 2 == 1 {
            return self.evaluate_raw(args.last().expect("odd arguments have an else value"));
        }
        Err(Error::MathDomain {
            function: "PIECEWISE",
        })
    }

    fn parse_user_function_call(&mut self, name: String) -> Result<Value, Error> {
        let label = format!("FN{name}");
        let arguments = self.parse_call_arguments(&label)?;
        self.evaluate_user_function(&name, arguments)
    }

    fn evaluate_user_function(
        &mut self,
        name: &str,
        arguments: Vec<Value>,
    ) -> Result<Value, Error> {
        if arguments.iter().any(|argument| !argument.is_numeric()) {
            return Err(Error::TypeMismatch);
        }
        let functions = self
            .user_functions
            .ok_or_else(|| Error::UndefinedFunction {
                name: name.to_string(),
            })?;
        let definition = functions
            .get(name)
            .cloned()
            .ok_or_else(|| Error::UndefinedFunction {
                name: name.to_string(),
            })?;
        if arguments.len() != definition.parameters.len() {
            return Err(Error::syntax(format!(
                "FN{name} expects {} arguments",
                definition.parameters.len()
            )));
        }
        if self.function_depth >= self.max_function_depth {
            return Err(Error::FunctionStackExceeded {
                limit: self.max_function_depth,
            });
        }

        // The arguments temporarily shadow variables of the same names while
        // every other program variable remains visible to the expression.
        let mut scoped_vars = self.vars.clone();
        for (parameter, argument) in definition.parameters.iter().zip(arguments) {
            scoped_vars.insert(parameter.clone(), argument);
        }
        let value = evaluate_runtime_inner(
            self.mode,
            &definition.body,
            &scoped_vars,
            self.arrays,
            self.max_string_bytes,
            self.rng,
            Some(functions),
            self.function_depth + 1,
            self.max_function_depth,
            self.output_column,
            self.cursor_row,
            self.text_screen,
            self.free_storage_bytes,
            self.graph,
            self.graphics,
            self.virtual_memory,
            self.virtual_ports,
            self.memory_segment,
            self.files,
            self.system_services,
            self.usr_addresses,
            self.process_context,
        )?;
        if value.is_numeric() {
            Ok(value)
        } else {
            Err(Error::TypeMismatch)
        }
    }
}

fn evaluate_ti_graph_query(
    name: &str,
    args: &[Value],
    mode: NumericMode,
    graph: Option<&TiGraphState>,
) -> Result<Value, Error> {
    let graph = graph.ok_or_else(|| {
        Error::syntax("TI graph query requires an active BASIC execution session")
    })?;
    if args.len() != 2 {
        return Err(Error::syntax(format!(
            "{name} expects exactly two arguments"
        )));
    }
    let on = match name {
        "PXL-TEST" | "PXLTEST" => {
            let row = into_integer(args[0].clone(), mode)?.value();
            let column = into_integer(args[1].clone(), mode)?.value();
            graph.pixel_test(row, column)
        }
        "PT-TEST" | "PTTEST" => {
            let x = into_real(args[0].clone())?.value();
            let y = into_real(args[1].clone())?.value();
            graph.point_test(x, y)
        }
        _ => unreachable!("caller checks TI graph query name"),
    };
    Ok(Value::Integer(i64::from(on)))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn modern_handles_more_than_32_bit() {
        let result = evaluate_direct(NumericMode::Modern, "3000000000+10").unwrap();
        assert_eq!(result, 3_000_000_010);
    }

    #[test]
    fn modern_named_functions_cover_classic_eqv_and_imp_operations() {
        let truth_cases = [
            ("BITXNOR(-1,-1)", -1),
            ("BITXNOR(-1,0)", 0),
            ("BITXNOR(0,-1)", 0),
            ("BITXNOR(0,0)", -1),
            ("BITIMPLIES(-1,-1)", -1),
            ("BITIMPLIES(-1,0)", 0),
            ("BITIMPLIES(0,-1)", -1),
            ("BITIMPLIES(0,0)", -1),
            ("BITXNOR(1,0)", -2),
            ("BITIMPLIES(1,0)", -2),
        ];
        for mode in [NumericMode::Modern, NumericMode::Legacy6502] {
            for (expression, expected) in truth_cases {
                assert_eq!(evaluate_direct(mode, expression).unwrap(), expected);
            }
        }
    }

    #[test]
    fn named_bitwise_functions_reject_bad_arity_and_types() {
        for expression in ["BITXNOR(1)", "BITIMPLIES(1,2,3)"] {
            assert!(matches!(
                evaluate_value_direct(NumericMode::Modern, expression),
                Err(Error::Syntax { .. })
            ));
        }
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "BITXNOR(\"1\",0)").unwrap_err(),
            Error::TypeMismatch
        );
    }

    #[test]
    fn real_literals_and_mixed_arithmetic_use_checked_binary64() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "1.5+2*.25").unwrap(),
            Value::real(2.0).unwrap()
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "5/2").unwrap(),
            Value::real(2.5).unwrap()
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "5/2.0").unwrap(),
            Value::real(2.5).unwrap()
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "-(.5)+2").unwrap(),
            Value::real(1.5).unwrap()
        );
    }

    #[test]
    fn slash_always_uses_basic_real_division() {
        for (mode, expression, expected) in [
            (NumericMode::Modern, "1/2", 0.5),
            (NumericMode::Modern, "-5/2", -2.5),
            (NumericMode::Legacy6502, "3/4", 0.75),
        ] {
            assert_eq!(
                evaluate_value_direct(mode, expression).unwrap(),
                Value::real(expected).unwrap(),
                "{expression}"
            );
        }
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "1/0").unwrap_err(),
            Error::DivideByZero
        );
    }

    #[test]
    fn mod_is_checked_integer_remainder() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "17 MOD 5").unwrap(),
            Value::Integer(2)
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "-17 MOD 5").unwrap(),
            Value::Integer(-2)
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "1.5 MOD 1").unwrap(),
            Value::Integer(0)
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "1 MOD 0").unwrap_err(),
            Error::DivideByZero
        );
    }

    #[test]
    fn ti_factorial_permutation_and_combination_syntax_is_supported() {
        for (expression, expected) in [
            ("FACT(5)", 120.0),
            ("5 NPR 2", 20.0),
            ("NPR(5,2)", 20.0),
            ("5 NCR 2", 10.0),
            ("NCR(5,2)", 10.0),
            ("FACT(3)^2", 36.0),
            ("2*FACT(4)", 48.0),
        ] {
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, expression).unwrap(),
                Value::real(expected).unwrap(),
                "{expression}"
            );
        }
    }

    #[test]
    fn ti_extended_scalar_functions_compose_in_expressions() {
        let Value::Real(value) = evaluate_value_direct(
            NumericMode::Modern,
            "DEG(ASIN(1))+LOG10(100)+LOGBASE(8,2)+ROOT(27,3)+PI()",
        )
        .unwrap() else {
            panic!("expression did not produce a real");
        };
        let expected = 90.0 + 2.0 + 3.0 + 3.0 + std::f64::consts::PI;
        assert!((value.value() - expected).abs() < 1e-12);
    }

    #[test]
    fn ti_rand_without_parentheses_is_a_scalar_function() {
        let value = evaluate_value_direct(NumericMode::Modern, "RAND").unwrap();
        let Value::Real(value) = value else {
            panic!("RAND did not return a real");
        };
        assert!((0.0..1.0).contains(&value.value()));
    }

    #[test]
    fn ti_bounded_numerical_functions_evaluate_raw_expressions() {
        for (expression, expected, tolerance) in [
            ("NDERIV(X^2,X,3)", 6.0, 1e-8),
            ("FNINT(X^2,X,0,3)", 9.0, 1e-8),
            ("FMIN((X-2)^2,X,-10,10)", 2.0, 1e-7),
            ("FMAX(-(X-2)^2,X,-10,10)", 2.0, 1e-7),
            ("SOLVE(X^2-2,X,0,2)", std::f64::consts::SQRT_2, 1e-7),
            ("SUM(X^2,X,1,3)", 14.0, 0.0),
            ("SUM(X,X,3,1,-1)", 6.0, 0.0),
            ("PIECEWISE(0,1,1,2,3)", 2.0, 0.0),
            ("PIECEWISE(0,1,0,2,3)", 3.0, 0.0),
        ] {
            let value = evaluate_value_direct(NumericMode::Modern, expression).unwrap();
            let actual = into_real(value).unwrap().value();
            assert!(
                (actual - expected).abs() <= tolerance,
                "{expression} returned {actual} instead of {expected}"
            );
        }
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "PIECEWISE(1,7,1,1/0)",).unwrap(),
            Value::Integer(7)
        );
    }

    #[test]
    fn ti_bounded_numerical_function_errors_are_structured() {
        for expression in [
            "NDERIV(X^2,X,3,0)",
            "FNINT(X,X,0,1,0)",
            "FMIN(X^2,X,1,-1)",
            "SOLVE(X^2+1,X,-1,1)",
            "SUM(X,X,1,3,0)",
        ] {
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, expression).unwrap_err(),
                Error::IllegalQuantity,
                "{expression}"
            );
        }
        assert!(matches!(
            evaluate_value_direct(NumericMode::Modern, "NDERIV(X^2,1,3)"),
            Err(Error::Syntax { .. })
        ));
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "PIECEWISE(0,1)").unwrap_err(),
            Error::MathDomain {
                function: "PIECEWISE"
            }
        );
    }

    #[test]
    fn mixed_numeric_comparisons_return_basic_booleans() {
        for (expression, expected) in [
            ("1=1.0", -1),
            ("1.5>1", -1),
            ("-2.0<=-2", -1),
            ("2.5<>2.5", 0),
        ] {
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, expression).unwrap(),
                Value::Integer(expected),
                "{expression}"
            );
        }
    }

    #[test]
    fn real_promotion_and_results_must_remain_safe() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "9007199254740993+0.5").unwrap_err(),
            Error::InexactRealConversion {
                value: 9_007_199_254_740_993
            }
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "1E308*10.0").unwrap_err(),
            Error::RealOverflow
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "1.0/0.0").unwrap_err(),
            Error::DivideByZero
        );
    }

    #[test]
    fn power_is_left_associative_and_binds_above_leading_unary_minus() {
        for (expression, expected) in [
            ("2^3", 8.0),
            ("2^3^2", 64.0),
            ("-2^2", -4.0),
            ("(-2)^3", -8.0),
            ("2^-2", 0.25),
            ("2*3^2", 18.0),
            ("2^3*2", 16.0),
            ("0^0", 1.0),
        ] {
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, expression).unwrap(),
                Value::real(expected).unwrap(),
                "{expression}"
            );
        }
    }

    #[test]
    fn power_rejects_undefined_and_unsafe_results() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "(-2)^.5").unwrap_err(),
            Error::MathDomain { function: "^" }
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "0^-1").unwrap_err(),
            Error::DivideByZero
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "10^1000").unwrap_err(),
            Error::RealOverflow
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "9007199254740993^2").unwrap_err(),
            Error::InexactRealConversion {
                value: 9_007_199_254_740_993
            }
        );
    }

    #[test]
    fn integer_api_rounds_real_results() {
        assert_eq!(evaluate_direct(NumericMode::Modern, "1.0").unwrap(), 1);
        assert_eq!(evaluate_direct(NumericMode::Modern, "1.5").unwrap(), 2);
    }

    #[test]
    fn legacy_rejects_more_than_32_bit() {
        let err = evaluate_direct(NumericMode::Legacy6502, "3000000000+10").unwrap_err();
        assert!(matches!(err, Error::OutOfLegacyRange { .. }));
    }

    #[test]
    fn overflow_is_caught_in_modern_mode() {
        let err = evaluate_direct(NumericMode::Modern, "9223372036854775807+1").unwrap_err();
        assert_eq!(err, Error::IntegerOverflow);
    }

    #[test]
    fn all_relational_operators_use_basic_boolean_values() {
        let cases = [
            ("2=2", -1),
            ("2=3", 0),
            ("2<>3", -1),
            ("2<>2", 0),
            ("2<3", -1),
            ("3<2", 0),
            ("2<=2", -1),
            ("3<=2", 0),
            ("3>2", -1),
            ("2>3", 0),
            ("3>=3", -1),
            ("2>=3", 0),
        ];

        for (expression, expected) in cases {
            assert_eq!(
                evaluate_direct(NumericMode::Modern, expression).unwrap(),
                expected,
                "expression: {expression}"
            );
        }
    }

    #[test]
    fn string_concatenation_with_plus() {
        let value =
            evaluate_value_direct(NumericMode::Modern, "\"hello\" + \" \" + \"world\"").unwrap();
        assert_eq!(value, Value::String("hello world".to_string()));
    }

    #[test]
    fn nested_builtin_functions_parse_as_expressions() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, r#"LEN(LEFT$("AéB",2))+ABS(-3)"#).unwrap(),
            Value::Integer(5)
        );
    }

    #[test]
    fn rgb_calls_are_functions_not_array_subscripts() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "RGB(255,128,0)").unwrap(),
            Value::String("#ff8000".to_string())
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "RGBA(1,2,3,4)").unwrap(),
            Value::String("#01020304".to_string())
        );
    }

    #[test]
    fn builtin_function_syntax_and_arity_are_checked() {
        for expression in ["ABS 1", "ABS()", "LEFT$(\"A\",)", "MID$(\"A\",1,2,3)"] {
            assert!(matches!(
                evaluate_value_direct(NumericMode::Modern, expression).unwrap_err(),
                Error::Syntax { .. }
            ));
        }
    }

    #[test]
    fn string_comparisons_use_lexical_order() {
        let cases = [
            ("\"abc\"=\"abc\"", -1),
            ("\"abc\"=\"def\"", 0),
            ("\"abc\"<>\"def\"", -1),
            ("\"abc\"<\"def\"", -1),
            ("\"def\">\"abc\"", -1),
            ("\"abc\"<=\"abc\"", -1),
            ("\"def\">=\"abc\"", -1),
        ];
        for (expr, expected) in cases {
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, expr)
                    .unwrap()
                    .as_integer()
                    .unwrap(),
                expected,
                "expr: {expr}"
            );
        }
    }

    #[test]
    fn mixed_string_integer_comparison_is_type_mismatch() {
        let err = evaluate_value_direct(NumericMode::Modern, "\"abc\"=1").unwrap_err();
        assert_eq!(err, Error::TypeMismatch);
    }

    #[test]
    fn arithmetic_on_strings_is_type_mismatch() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "\"abc\" - \"def\"").unwrap_err(),
            Error::TypeMismatch
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "\"abc\" * 2").unwrap_err(),
            Error::TypeMismatch
        );
    }

    #[test]
    fn missing_variables_use_defaults() {
        let vars = Variables::new();
        assert_eq!(
            evaluate_value_tokens(
                NumericMode::Modern,
                &tokenize("X").unwrap(),
                &vars,
                NumericMode::Modern.default_string_byte_limit(),
            )
            .unwrap(),
            Value::Integer(0)
        );
        assert_eq!(
            evaluate_value_tokens(
                NumericMode::Modern,
                &tokenize("X$").unwrap(),
                &vars,
                NumericMode::Modern.default_string_byte_limit(),
            )
            .unwrap(),
            Value::String(String::new())
        );
    }

    #[test]
    fn mixed_plus_integer_string_is_type_mismatch() {
        let err = evaluate_value_direct(NumericMode::Modern, "1 + \"x\"").unwrap_err();
        assert_eq!(err, Error::TypeMismatch);
    }

    #[test]
    fn string_literals_respect_byte_limit() {
        let big = "x".repeat(256);
        let expr = format!("\"{}\"", big);
        let err = evaluate_value_direct(NumericMode::Legacy6502, &expr).unwrap_err();
        assert!(matches!(
            err,
            Error::StringTooLong {
                length: 256,
                limit: 255
            }
        ));
    }

    #[test]
    fn string_concatenation_checked_before_allocation() {
        let a = "x".repeat(200);
        let b = "x".repeat(100);
        let expr = format!("\"{}\" + \"{}\"", a, b);
        let err = evaluate_value_direct(NumericMode::Legacy6502, &expr).unwrap_err();
        assert!(matches!(
            err,
            Error::StringTooLong {
                length: 300,
                limit: 255
            }
        ));
    }

    #[test]
    fn named_string_repeat_functions_enforce_byte_limit_before_allocation() {
        let vars = Variables::new();
        for expression in ["SPACE$(999999999)", "STRING$(999999, \"A\")"] {
            let error = evaluate_value_tokens(
                NumericMode::Modern,
                &tokenize(expression).unwrap(),
                &vars,
                64,
            )
            .unwrap_err();
            assert!(
                matches!(
                    error,
                    Error::StringTooLong {
                        length,
                        limit: 64
                    } if length > 64
                ),
                "{expression} returned {error:?}"
            );
        }

        let error = evaluate_value_tokens(
            NumericMode::Modern,
            &tokenize("STRING$(33, \"é\")").unwrap(),
            &vars,
            64,
        )
        .unwrap_err();
        assert_eq!(
            error,
            Error::StringTooLong {
                length: 66,
                limit: 64
            }
        );
    }

    #[test]
    fn parentheses_work_for_strings() {
        let value = evaluate_value_direct(NumericMode::Modern, "(\"a\" + \"b\") + \"c\"").unwrap();
        assert_eq!(value, Value::String("abc".to_string()));
    }

    #[test]
    fn array_reference_reads_default_from_temporary_store() {
        let mut arrays = ArrayStore::new(usize::MAX);
        let value = evaluate_value_tokens_with_arrays(
            NumericMode::Modern,
            &tokenize("A(5)").unwrap(),
            &Variables::new(),
            &mut arrays,
            NumericMode::Modern.default_string_byte_limit(),
        )
        .unwrap();
        assert_eq!(value, Value::Integer(0));
    }

    #[test]
    fn array_subscript_expression_is_evaluated() {
        let mut vars = Variables::new();
        vars.insert("I".to_string(), Value::Integer(3));
        let mut arrays = ArrayStore::new(usize::MAX);
        arrays.store("A", &[3], Value::Integer(99)).unwrap();
        let value = evaluate_value_tokens_with_arrays(
            NumericMode::Modern,
            &tokenize("A(I)").unwrap(),
            &vars,
            &mut arrays,
            NumericMode::Modern.default_string_byte_limit(),
        )
        .unwrap();
        assert_eq!(value, Value::Integer(99));
    }

    #[test]
    fn ti_complex_values_support_arithmetic_and_principal_functions() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "COMPLEX(2,3)+COMPLEX(4,-1)")
                .unwrap()
                .to_string(),
            "6+2i"
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "COMPLEX(0,1)^2")
                .unwrap()
                .to_string(),
            "-1"
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "SQR(COMPLEX(-4,0))")
                .unwrap()
                .to_string(),
            "2i"
        );
        assert_eq!(
            evaluate_value_direct(
                NumericMode::Modern,
                "REAL(COMPLEX(2,3))+IMAG(COMPLEX(2,3))+ABS(COMPLEX(3,4))"
            )
            .unwrap(),
            Value::real(10.0).unwrap()
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "FRAC$(1/3)").unwrap(),
            Value::String("1/3".into())
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "FRAC$({1/3,.125,COMPLEX(.5,.25)})")
                .unwrap(),
            Value::String("{1/3,1/8,1/2+1/4i}".into())
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "DEC(\"1/8\")").unwrap(),
            Value::real(0.125).unwrap()
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "DEC(\"FF\")").unwrap(),
            Value::Integer(255)
        );
    }

    #[test]
    fn ti_lists_are_bounded_first_class_numeric_values() {
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "{1,2,3}*2+1")
                .unwrap()
                .to_string(),
            "{3,5,7}"
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "{1,2,3}>1")
                .unwrap()
                .to_string(),
            "{0,-1,-1}"
        );
        assert_eq!(
            evaluate_value_direct(
                NumericMode::Modern,
                "SUM({1,2,3})+MEAN({2,4,6})+MEDIAN({5,1,3})"
            )
            .unwrap(),
            Value::real(13.0).unwrap()
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "{1,2}+{3}").unwrap_err(),
            Error::IllegalQuantity
        );
        assert!(matches!(
            evaluate_value_direct(NumericMode::Modern, "RANDINTNOREP(1,5,3)").unwrap(),
            Value::List(values) if values.len() == 3
        ));
    }

    #[test]
    fn ti_probability_distributions_are_numerically_checked() {
        for (expression, expected, tolerance) in [
            ("NORMALPDF(0)", 0.398_942_280_401_432_7, 1e-14),
            ("NORMALCDF(-1,1)", 0.682_689_492, 2e-7),
            ("INVNORM(.975)", 1.959_963_984_540_054, 1e-8),
            ("BINOMCDF(5,.5,2)", 0.5, 1e-14),
            ("GEOMETPDF(.25,3)", 0.140625, 1e-14),
            ("POISSONPDF(3,2)", 0.224_041_807_655_387_75, 1e-14),
        ] {
            let Value::Real(value) =
                evaluate_value_direct(NumericMode::Modern, expression).unwrap()
            else {
                panic!("{expression} did not return a real")
            };
            assert!(
                (value.value() - expected).abs() <= tolerance,
                "{expression}"
            );
        }
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "NORMALPDF({0,1})")
                .unwrap()
                .to_string(),
            "{0.3989422804014327,0.24197072451914337}"
        );
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "INVNORM(1)").unwrap_err(),
            Error::IllegalQuantity
        );
    }

    #[test]
    fn list_variance_deviation_correlation_and_regression_are_checked() {
        for (expression, expected, tolerance) in [
            ("VARP({1,2,3,4})", 1.25, 1e-14),
            ("VARS({1,2,3,4})", 5.0 / 3.0, 1e-14),
            ("STDEVP({1,2,3,4})", 1.25_f64.sqrt(), 1e-14),
            ("STDEVS({1,2,3,4})", (5.0_f64 / 3.0).sqrt(), 1e-14),
            ("CORREL({1,2,3},{7,5,3})", -1.0, 1e-14),
        ] {
            let Value::Real(value) =
                evaluate_value_direct(NumericMode::Modern, expression).unwrap()
            else {
                panic!("{expression} did not return a real")
            };
            assert!((value.value() - expected).abs() <= tolerance);
        }
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "LINREG({1,2,3},{3,5,7})")
                .unwrap()
                .to_string(),
            "{2,1,1,1}"
        );
        for expression in [
            "VARS({1})",
            "CORREL({1,2},{3})",
            "CORREL({1,1},{2,3})",
            "LINREG({1,2},{4,4})",
        ] {
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, expression).unwrap_err(),
                Error::IllegalQuantity,
                "{expression}"
            );
        }
    }

    #[test]
    fn reported_math_function_aliases_and_round_trip_are_supported() {
        for (expression, expected) in [("COMB(5,2)", 10.0), ("PERM(5,2)", 20.0)] {
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, expression).unwrap(),
                Value::real(expected).unwrap(),
                "{expression}"
            );
        }

        for name in ["VARIANCE", "STD", "STDDEV", "STDEV"] {
            let expression = format!("{name}({{2,4,6,8,10}})");
            let Value::Real(value) =
                evaluate_value_direct(NumericMode::Modern, &expression).unwrap()
            else {
                panic!("{expression} did not return a real")
            };
            let expected = if name == "VARIANCE" {
                10.0
            } else {
                10.0_f64.sqrt()
            };
            assert!((value.value() - expected).abs() <= 1e-14, "{expression}");
        }

        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, "EXP(LOG(7))").unwrap(),
            Value::real(7.0).unwrap()
        );
    }

    #[test]
    fn deeply_recursive_expression_shapes_return_a_bounded_error() {
        let depth = MAX_EXPRESSION_DEPTH + 1;
        for expression in [
            format!("{}1{}", "(".repeat(depth), ")".repeat(depth)),
            format!("{}1", "-".repeat(depth)),
        ] {
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, &expression).unwrap_err(),
                Error::ExpressionDepthExceeded {
                    limit: MAX_EXPRESSION_DEPTH,
                }
            );
        }
        assert_eq!(
            evaluate_value_direct(NumericMode::Modern, &format!("{}1", "1^".repeat(depth)))
                .unwrap(),
            Value::real(1.0).unwrap()
        );
    }

    #[test]
    fn deterministic_integer_expression_properties_match_checked_arithmetic() {
        let mut state = 0xa076_1d64_78bd_642f_u64;
        for case in 0..10_000 {
            state = state
                .wrapping_mul(6_364_136_223_846_793_005)
                .wrapping_add(1_442_695_040_888_963_407);
            let left = (state % 20_001) as i64 - 10_000;
            state = state
                .wrapping_mul(6_364_136_223_846_793_005)
                .wrapping_add(1_442_695_040_888_963_407);
            let right = (state % 20_001) as i64 - 10_000;
            let (operator, expected) = match case % 3 {
                0 => ('+', left + right),
                1 => ('-', left - right),
                _ => ('*', left * right),
            };
            let expression = format!("({left}){operator}({right})");
            assert_eq!(
                evaluate_value_direct(NumericMode::Modern, &expression).unwrap(),
                Value::Integer(expected),
                "stress case {case}: {expression}"
            );
        }
    }
}
