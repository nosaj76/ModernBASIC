//! Sandboxed native file channels for BASIC file statements.
//!
//! The store is disabled unless a root directory is explicitly configured.
//! Paths must be relative and contain only normal components; parent traversal,
//! absolute paths, and symlinks are rejected. Writable channels also retain an
//! independent deterministic output column for `PRINT#`; append mode derives
//! it from the bounded existing tail. This is native host file I/O, not
//! Commodore device-number or 6502 KERNAL emulation.

use std::collections::{HashMap, VecDeque};
use std::fs::{self, File, OpenOptions};
use std::io::{self, BufReader, Read, Seek, SeekFrom, Write};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Mutex, OnceLock};

#[cfg(target_os = "linux")]
use std::os::fd::AsRawFd;
#[cfg(target_os = "linux")]
use std::os::unix::fs::OpenOptionsExt;

use crate::bounded_line::{read_bounded_line, BoundedLineError};
use crate::error::Error;
use crate::output::advance_column_bytes;

/// Default maximum number of concurrently open BASIC file channels.
pub const DEFAULT_MAX_OPEN_FILES: usize = 16;
/// Default maximum size of one file read or written by a run.
/// Large PCM music exports can exceed 16 MiB, so the ModernBASIC modern mode permits
/// a complete multi-minute 44.1 kHz mono score without special flags.
pub const DEFAULT_MAX_FILE_BYTES: usize = 512 * 1_048_576;
/// Tokenized BASIC programs have a smaller input ceiling than general media
/// and audio files because each encoded byte can expand into a heap object.
pub const DEFAULT_MAX_BINARY_PROGRAM_BYTES: usize = 64 * 1_048_576;

/// Native access direction selected by an `OPEN` statement.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FileMode {
    Read,
    Write,
    Append,
    Random,
    Binary,
}

impl FileMode {
    /// Parse the documented native mode names case-insensitively.
    pub fn parse(text: &str) -> Result<Self, Error> {
        match text.trim().to_ascii_uppercase().as_str() {
            "READ" => Ok(Self::Read),
            "WRITE" => Ok(Self::Write),
            "APPEND" => Ok(Self::Append),
            "RANDOM" => Ok(Self::Random),
            "BINARY" => Ok(Self::Binary),
            _ => Err(Error::syntax(
                "file mode must be READ, WRITE, APPEND, RANDOM, or BINARY",
            )),
        }
    }
}

enum OpenFile {
    Read {
        reader: BufReader<File>,
        bytes_read: usize,
    },
    Write {
        file: File,
        total_bytes: usize,
        column: usize,
    },
    Random {
        file: File,
        record_len: usize,
        buffer: Vec<u8>,
        last_record: usize,
    },
    Binary {
        file: File,
        position: usize,
        column: usize,
    },
    Serial {
        file: File,
        buffer: VecDeque<u8>,
        pending_output: Option<PendingSerialOutput>,
        bytes_read: usize,
        bytes_written: usize,
        column: usize,
        port: u8,
    },
}

#[derive(Debug)]
struct PendingSerialOutput {
    bytes: Vec<u8>,
    offset: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct SerialConfig {
    port: u8,
    baud: u32,
    parity: u8,
    data_bits: u8,
    stop_bits: u8,
}

impl SerialConfig {
    fn default_for_port(port: u8) -> Result<Self, Error> {
        if port == 0 {
            return Err(Error::IllegalQuantity);
        }
        Ok(Self {
            port,
            baud: 9_600,
            parity: b'N',
            data_bits: 8,
            stop_bits: 1,
        })
    }

    fn parse(text: &str) -> Result<Option<Self>, Error> {
        let upper = text.trim().to_ascii_uppercase();
        let Some(spec) = upper.strip_prefix("COM") else {
            return Ok(None);
        };
        let (port, settings) = spec.split_once(':').unwrap_or((spec, ""));
        let port = port
            .parse::<u8>()
            .map_err(|_| Error::syntax("serial path expects COMn[:baud,parity,bits,stop]"))?;
        let mut config = Self::default_for_port(port)?;
        if settings.is_empty() {
            return Ok(Some(config));
        }
        let fields = settings.split(',').collect::<Vec<_>>();
        if fields.len() > 4 || fields.iter().any(|field| field.trim().is_empty()) {
            return Err(Error::syntax(
                "serial settings expect baud,parity,data-bits,stop-bits",
            ));
        }
        if let Some(baud) = fields.first() {
            config.baud = baud
                .trim()
                .parse::<u32>()
                .map_err(|_| Error::syntax("invalid serial baud rate"))?;
        }
        if let Some(parity) = fields.get(1) {
            let bytes = parity.trim().as_bytes();
            if bytes.len() != 1 || !matches!(bytes[0], b'N' | b'E' | b'O') {
                return Err(Error::syntax("serial parity must be N, E, or O"));
            }
            config.parity = bytes[0];
        }
        if let Some(bits) = fields.get(2) {
            config.data_bits = bits
                .trim()
                .parse::<u8>()
                .map_err(|_| Error::syntax("invalid serial data bits"))?;
            if !(5..=8).contains(&config.data_bits) {
                return Err(Error::syntax("serial data bits must be 5 through 8"));
            }
        }
        if let Some(stop) = fields.get(3) {
            config.stop_bits = stop
                .trim()
                .parse::<u8>()
                .map_err(|_| Error::syntax("invalid serial stop bits"))?;
            if !matches!(config.stop_bits, 1 | 2) {
                return Err(Error::syntax("serial stop bits must be 1 or 2"));
            }
        }
        serial_baud_constant(config.baud)?;
        Ok(Some(config))
    }
}

/// Per-run store of bounded logical channels rooted in one sandbox directory.
pub struct FileStore {
    owner_id: u64,
    sandbox_root: Option<PathBuf>,
    root: Option<PathBuf>,
    channels: HashMap<u8, OpenFile>,
    channel_paths: HashMap<u8, PathBuf>,
    locks: HashMap<u8, Vec<FileLockRange>>,
    max_open_files: usize,
    max_file_bytes: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct FileLockRange {
    /// Inclusive one-based byte range. `None` means the entire file.
    bytes: Option<(usize, usize)>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct GlobalFileLock {
    owner_id: u64,
    channel: u8,
    range: FileLockRange,
}

static NEXT_FILE_STORE_ID: AtomicU64 = AtomicU64::new(1);
static GLOBAL_FILE_LOCKS: OnceLock<Mutex<HashMap<PathBuf, Vec<GlobalFileLock>>>> = OnceLock::new();

fn global_file_locks() -> &'static Mutex<HashMap<PathBuf, Vec<GlobalFileLock>>> {
    GLOBAL_FILE_LOCKS.get_or_init(|| Mutex::new(HashMap::new()))
}

impl FileLockRange {
    fn overlaps(self, other: Self) -> bool {
        match (self.bytes, other.bytes) {
            (None, _) | (_, None) => true,
            (Some((left_start, left_end)), Some((right_start, right_end))) => {
                left_start <= right_end && right_start <= left_end
            }
        }
    }
}

impl FileStore {
    /// Construct a disabled store or canonicalize an explicitly supplied root.
    pub fn new(
        root: Option<PathBuf>,
        max_open_files: usize,
        max_file_bytes: usize,
    ) -> Result<Self, Error> {
        let root = root
            .map(|path| {
                let canonical = fs::canonicalize(path)?;
                if !canonical.is_dir() {
                    return Err(Error::InvalidFilePath);
                }
                Ok(canonical)
            })
            .transpose()?;
        Ok(Self {
            owner_id: NEXT_FILE_STORE_ID.fetch_add(1, Ordering::Relaxed),
            sandbox_root: root.clone(),
            root,
            channels: HashMap::new(),
            channel_paths: HashMap::new(),
            locks: HashMap::new(),
            max_open_files,
            max_file_bytes,
        })
    }

    /// Change the sandbox root used by subsequent relative file operations.
    /// Existing open channels retain their already-open host handles.
    pub(crate) fn set_root(&mut self, root: PathBuf) -> Result<(), Error> {
        let canonical = fs::canonicalize(root)?;
        if !canonical.is_dir() {
            return Err(Error::InvalidFilePath);
        }
        self.sandbox_root = Some(canonical.clone());
        self.root = Some(canonical);
        Ok(())
    }

    pub(crate) fn root_path(&self) -> Option<&Path> {
        self.root.as_deref()
    }

    /// Change the current directory without allowing the configured sandbox
    /// root, or a symlink anywhere beneath it, to be crossed.
    pub(crate) fn change_dir(&mut self, text: &str) -> Result<(), Error> {
        let sandbox_root = self
            .sandbox_root
            .as_ref()
            .ok_or(Error::FileIoDisabled)?
            .clone();
        let mut current = self.root.as_ref().ok_or(Error::FileIoDisabled)?.clone();
        let requested = Path::new(text);
        if text.trim().is_empty() || requested.is_absolute() {
            return Err(Error::InvalidFilePath);
        }
        for component in requested.components() {
            match component {
                Component::CurDir => {}
                Component::ParentDir => {
                    if current == sandbox_root {
                        return Err(Error::InvalidFilePath);
                    }
                    current = current
                        .parent()
                        .filter(|parent| parent.starts_with(&sandbox_root))
                        .ok_or(Error::InvalidFilePath)?
                        .to_path_buf();
                }
                Component::Normal(name) => {
                    let exact = current.join(name);
                    let child = match fs::symlink_metadata(&exact) {
                        Ok(metadata) => {
                            if metadata.file_type().is_symlink() {
                                return Err(Error::InvalidFilePath);
                            }
                            exact
                        }
                        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                            self.case_insensitive_child(&current, name)?.ok_or(error)?
                        }
                        Err(error) => return Err(error.into()),
                    };
                    if fs::symlink_metadata(&child)?.file_type().is_symlink() {
                        return Err(Error::InvalidFilePath);
                    }
                    current = fs::canonicalize(child)?;
                    if !current.starts_with(&sandbox_root) || !current.is_dir() {
                        return Err(Error::InvalidFilePath);
                    }
                }
                Component::RootDir | Component::Prefix(_) => return Err(Error::InvalidFilePath),
            }
        }
        self.root = Some(current);
        Ok(())
    }

    /// Current directory rendered relative to the configured sandbox root.
    pub(crate) fn current_directory(&self) -> Result<String, Error> {
        let sandbox_root = self.sandbox_root.as_ref().ok_or(Error::FileIoDisabled)?;
        let root = self.root.as_ref().ok_or(Error::FileIoDisabled)?;
        let relative = root
            .strip_prefix(sandbox_root)
            .map_err(|_| Error::InvalidFilePath)?;
        if relative.as_os_str().is_empty() {
            Ok(".".to_string())
        } else {
            Ok(relative.to_string_lossy().replace('\\', "/"))
        }
    }

    /// Convert a checked integer into the supported logical channel range.
    pub fn channel(value: i64) -> Result<u8, Error> {
        u8::try_from(value).map_err(|_| Error::InvalidFileChannel { channel: value })
    }

    /// Configured per-file byte limit.
    pub fn max_file_bytes(&self) -> usize {
        self.max_file_bytes
    }

    /// Read one complete bounded sandbox file for native program `LOAD`.
    pub fn read_all(&self, path: &str) -> Result<Vec<u8>, Error> {
        self.read_all_with_limit(path, self.max_file_bytes)
    }

    /// Read one complete sandboxed file with a caller-specific hard limit.
    /// This is reserved for trusted engine assets such as SoundFonts; ordinary
    /// BASIC file operations continue to use the configured per-file limit.
    pub(crate) fn read_all_with_limit(
        &self,
        path: &str,
        max_bytes: usize,
    ) -> Result<Vec<u8>, Error> {
        let target = self.resolve(path, true)?;
        let metadata = fs::metadata(&target)?;
        if !metadata.is_file() {
            return Err(Error::InvalidFilePath);
        }
        let length = usize::try_from(metadata.len()).unwrap_or(usize::MAX);
        if length > max_bytes {
            return Err(Error::FileLimitExceeded { limit: max_bytes });
        }
        let mut file = File::open(target)?;
        let take_limit = u64::try_from(max_bytes)
            .unwrap_or(u64::MAX)
            .saturating_add(1);
        let mut bytes = Vec::with_capacity(length);
        Read::by_ref(&mut file)
            .take(take_limit)
            .read_to_end(&mut bytes)?;
        if bytes.len() > max_bytes {
            return Err(Error::FileLimitExceeded { limit: max_bytes });
        }
        Ok(bytes)
    }

    /// Open one sandboxed engine asset as a bounded-size stream. This avoids a
    /// second complete in-memory copy for large SoundFonts.
    pub(crate) fn open_asset_with_limit(
        &self,
        path: &str,
        max_bytes: usize,
    ) -> Result<BufReader<File>, Error> {
        let target = self.resolve(path, true)?;
        let metadata = fs::metadata(&target)?;
        if !metadata.is_file() {
            return Err(Error::InvalidFilePath);
        }
        let length = usize::try_from(metadata.len()).unwrap_or(usize::MAX);
        if length > max_bytes {
            return Err(Error::FileLimitExceeded { limit: max_bytes });
        }
        Ok(BufReader::with_capacity(1_048_576, File::open(target)?))
    }

    /// Resolve a writable BASIC path to its sandboxed host location.
    /// Graphics backends use this when an external renderer must receive a
    /// real host path while retaining the same path policy as BASIC file I/O.
    pub(crate) fn output_path(&self, path: &str) -> Result<PathBuf, Error> {
        self.resolve(path, false)
    }

    /// Replace one complete bounded sandbox file for native program `SAVE`.
    pub fn write_all(&self, path: &str, bytes: &[u8]) -> Result<(), Error> {
        if bytes.len() > self.max_file_bytes {
            return Err(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            });
        }
        let target = self.resolve(path, false)?;
        let mut file = OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)
            .open(target)?;
        file.write_all(bytes)?;
        file.flush()?;
        Ok(())
    }

    /// Open a relative sandbox path on a new logical channel.
    pub fn open(&mut self, channel: u8, path: &str, mode: FileMode) -> Result<(), Error> {
        if self.channels.contains_key(&channel) {
            return Err(Error::FileChannelAlreadyOpen { channel });
        }
        if self.channels.len() >= self.max_open_files {
            return Err(Error::OpenFileLimitExceeded {
                limit: self.max_open_files,
            });
        }
        let target = self.resolve(path, mode == FileMode::Read)?;
        let channel_path = target.clone();
        let open_file = match mode {
            FileMode::Read => {
                let metadata = fs::metadata(&target)?;
                if !metadata.is_file() {
                    return Err(Error::InvalidFilePath);
                }
                let length = usize::try_from(metadata.len()).unwrap_or(usize::MAX);
                if length > self.max_file_bytes {
                    return Err(Error::FileLimitExceeded {
                        limit: self.max_file_bytes,
                    });
                }
                OpenFile::Read {
                    reader: BufReader::new(File::open(target)?),
                    bytes_read: 0,
                }
            }
            FileMode::Write => OpenFile::Write {
                file: OpenOptions::new()
                    .write(true)
                    .create(true)
                    .truncate(true)
                    .open(target)?,
                total_bytes: 0,
                column: 0,
            },
            FileMode::Append => {
                let existing = fs::metadata(&target)
                    .ok()
                    .map(|metadata| usize::try_from(metadata.len()).unwrap_or(usize::MAX))
                    .unwrap_or(0);
                if existing > self.max_file_bytes {
                    return Err(Error::FileLimitExceeded {
                        limit: self.max_file_bytes,
                    });
                }
                let column = match fs::read(&target) {
                    Ok(bytes) => advance_column_bytes(0, &bytes),
                    Err(error) if error.kind() == std::io::ErrorKind::NotFound => 0,
                    Err(error) => return Err(error.into()),
                };
                OpenFile::Write {
                    file: OpenOptions::new().append(true).create(true).open(target)?,
                    total_bytes: existing,
                    column,
                }
            }
            FileMode::Random => {
                let existing = fs::metadata(&target)
                    .ok()
                    .map(|metadata| usize::try_from(metadata.len()).unwrap_or(usize::MAX))
                    .unwrap_or(0);
                if existing > self.max_file_bytes {
                    return Err(Error::FileLimitExceeded {
                        limit: self.max_file_bytes,
                    });
                }
                OpenFile::Random {
                    file: OpenOptions::new()
                        .read(true)
                        .write(true)
                        .create(true)
                        .truncate(false)
                        .open(target)?,
                    record_len: 128,
                    buffer: vec![b' '; 128],
                    last_record: 0,
                }
            }
            FileMode::Binary => {
                let existing = fs::metadata(&target)
                    .ok()
                    .map(|metadata| usize::try_from(metadata.len()).unwrap_or(usize::MAX))
                    .unwrap_or(0);
                if existing > self.max_file_bytes {
                    return Err(Error::FileLimitExceeded {
                        limit: self.max_file_bytes,
                    });
                }
                OpenFile::Binary {
                    file: OpenOptions::new()
                        .read(true)
                        .write(true)
                        .create(true)
                        .truncate(false)
                        .open(target)?,
                    position: 0,
                    column: 0,
                }
            }
        };
        self.channels.insert(channel, open_file);
        self.channel_paths.insert(channel, channel_path);
        Ok(())
    }

    /// Open `COMn[:baud,parity,bits,stop]` as a bidirectional, non-blocking
    /// BASIC channel. Returns `Ok(None)` when the text is an ordinary path.
    pub fn open_serial_spec(&mut self, channel: u8, text: &str) -> Result<Option<u8>, Error> {
        let Some(config) = SerialConfig::parse(text)? else {
            return Ok(None);
        };
        self.open_serial_config(channel, config)?;
        Ok(Some(config.port))
    }

    /// Open `/dev/ttyUSB(n-1)` or `/dev/ttyS(n-1)` at 9600 8N1. The BASIC
    /// port number is also used as its logical channel by the `COM n` form.
    pub fn open_serial_port(&mut self, port: u8) -> Result<(), Error> {
        self.open_serial_config(port, SerialConfig::default_for_port(port)?)
    }

    #[cfg(target_os = "linux")]
    fn open_serial_config(&mut self, channel: u8, config: SerialConfig) -> Result<(), Error> {
        if self.channels.contains_key(&channel) {
            return Err(Error::FileChannelAlreadyOpen { channel });
        }
        if let Some(channel) = self.serial_channel_for_port(config.port) {
            return Err(Error::FileChannelAlreadyOpen { channel });
        }
        if self.channels.len() >= self.max_open_files {
            return Err(Error::OpenFileLimitExceeded {
                limit: self.max_open_files,
            });
        }
        let index = usize::from(config.port - 1);
        let candidates = [
            PathBuf::from(format!("/dev/ttyUSB{index}")),
            PathBuf::from(format!("/dev/ttyS{index}")),
        ];
        let mut last_error = None;
        for path in candidates {
            match OpenOptions::new()
                .read(true)
                .write(true)
                .custom_flags(0x800)
                .open(&path)
            {
                Ok(file) => {
                    configure_serial(&file, config)?;
                    self.insert_serial(channel, config.port, path, file);
                    return Ok(());
                }
                Err(error) => last_error = Some(error),
            }
        }
        Err(last_error
            .unwrap_or_else(|| std::io::Error::new(std::io::ErrorKind::NotFound, "serial port"))
            .into())
    }

    #[cfg(not(target_os = "linux"))]
    fn open_serial_config(&mut self, _channel: u8, _config: SerialConfig) -> Result<(), Error> {
        Err(Error::Io(
            "native serial ports are currently supported on Linux".into(),
        ))
    }

    pub(crate) fn insert_serial(&mut self, channel: u8, port: u8, path: PathBuf, file: File) {
        self.channels.insert(
            channel,
            OpenFile::Serial {
                file,
                buffer: VecDeque::new(),
                pending_output: None,
                bytes_read: 0,
                bytes_written: 0,
                column: 0,
                port,
            },
        );
        self.channel_paths.insert(channel, path);
    }

    /// Close one logical channel, flushing output first.
    pub fn close(&mut self, channel: u8) -> Result<(), Error> {
        let open = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?;
        match open {
            OpenFile::Write { file, .. }
            | OpenFile::Random { file, .. }
            | OpenFile::Binary { file, .. } => file.flush()?,
            OpenFile::Serial {
                file,
                pending_output,
                ..
            } => {
                if let Some(pending) = pending_output.as_mut() {
                    if !drain_serial_output(file, pending)? {
                        return Err(Error::Io("serial output would block".into()));
                    }
                }
                file.flush()?;
            }
            OpenFile::Read { .. } => {}
        }
        self.release_global_locks(channel)?;
        self.channels.remove(&channel);
        self.channel_paths.remove(&channel);
        self.locks.remove(&channel);
        Ok(())
    }

    /// Close all serial channels while retaining ordinary BASIC files.
    pub fn close_serials(&mut self) -> Result<(), Error> {
        let channels = self
            .channels
            .iter()
            .filter_map(|(channel, open)| {
                matches!(open, OpenFile::Serial { .. }).then_some(*channel)
            })
            .collect::<Vec<_>>();
        for channel in channels {
            self.close(channel)?;
        }
        Ok(())
    }

    /// Return the channel currently associated with a one-based COM port.
    pub fn serial_channel_for_port(&self, port: u8) -> Option<u8> {
        self.channels.iter().find_map(|(channel, open)| match open {
            OpenFile::Serial {
                port: candidate, ..
            } if *candidate == port => Some(*channel),
            _ => None,
        })
    }

    /// Close every logical channel, releasing all advisory locks.
    pub fn close_all(&mut self) -> Result<(), Error> {
        let mut channels = self.channels.keys().copied().collect::<Vec<_>>();
        channels.sort_unstable();
        for channel in channels {
            self.close(channel)?;
        }
        self.locks.clear();
        self.channel_paths.clear();
        Ok(())
    }

    /// Acquire a process-wide advisory whole-file or inclusive byte-range lock.
    pub fn lock(&mut self, channel: u8, bytes: Option<(usize, usize)>) -> Result<(), Error> {
        if !self.channels.contains_key(&channel) {
            return Err(Error::FileChannelNotOpen { channel });
        }
        if let Some((start, end)) = bytes {
            if start == 0 || start > end {
                return Err(Error::IllegalQuantity);
            }
        }
        let requested = FileLockRange { bytes };
        let path = self
            .channel_paths
            .get(&channel)
            .expect("open channel retains its resolved path");
        let path = fs::canonicalize(path)?;
        let mut registry = global_file_locks()
            .lock()
            .map_err(|_| Error::Io("process-wide file lock registry is poisoned".into()))?;
        let held = registry.entry(path).or_default();
        if held.iter().any(|lock| lock.range.overlaps(requested)) {
            return Err(Error::Io(format!(
                "file channel {channel} range is already locked"
            )));
        }
        held.push(GlobalFileLock {
            owner_id: self.owner_id,
            channel,
            range: requested,
        });
        let locks = self.locks.entry(channel).or_default();
        locks.push(requested);
        Ok(())
    }

    /// Release the exact advisory range previously acquired by `lock`.
    pub fn unlock(&mut self, channel: u8, bytes: Option<(usize, usize)>) -> Result<(), Error> {
        if !self.channels.contains_key(&channel) {
            return Err(Error::FileChannelNotOpen { channel });
        }
        if let Some((start, end)) = bytes {
            if start == 0 || start > end {
                return Err(Error::IllegalQuantity);
            }
        }
        let requested = FileLockRange { bytes };
        let Some(locks) = self.locks.get(&channel) else {
            return Err(Error::Io(format!(
                "file channel {channel} range is not locked"
            )));
        };
        let Some(position) = locks.iter().position(|held| *held == requested) else {
            return Err(Error::Io(format!(
                "file channel {channel} range is not locked"
            )));
        };
        let path = self
            .channel_paths
            .get(&channel)
            .expect("open channel retains its resolved path");
        let path = fs::canonicalize(path)?;
        let mut registry = global_file_locks()
            .lock()
            .map_err(|_| Error::Io("process-wide file lock registry is poisoned".into()))?;
        let Some(held) = registry.get_mut(&path) else {
            return Err(Error::Io(format!(
                "file channel {channel} range is not locked"
            )));
        };
        let Some(global_position) = held.iter().position(|lock| {
            lock.owner_id == self.owner_id && lock.channel == channel && lock.range == requested
        }) else {
            return Err(Error::Io(format!(
                "file channel {channel} range is not locked"
            )));
        };
        held.remove(global_position);
        if held.is_empty() {
            registry.remove(&path);
        }

        let locks = self
            .locks
            .get_mut(&channel)
            .expect("local lock was validated before the global registry");
        locks.remove(position);
        if locks.is_empty() {
            self.locks.remove(&channel);
        }
        Ok(())
    }

    fn release_global_locks(&self, channel: u8) -> Result<(), Error> {
        let mut registry = global_file_locks()
            .lock()
            .map_err(|_| Error::Io("process-wide file lock registry is poisoned".into()))?;
        registry.retain(|_, locks| {
            locks.retain(|lock| !(lock.owner_id == self.owner_id && lock.channel == channel));
            !locks.is_empty()
        });
        Ok(())
    }

    /// Validate that a channel can receive output before expressions run.
    pub fn ensure_writable(&self, channel: u8) -> Result<(), Error> {
        match self.channels.get(&channel) {
            Some(OpenFile::Write { .. } | OpenFile::Binary { .. } | OpenFile::Serial { .. }) => {
                Ok(())
            }
            Some(OpenFile::Read { .. }) | Some(OpenFile::Random { .. }) => {
                Err(Error::FileModeMismatch { channel })
            }
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    /// Current zero-based output column for a writable channel.
    pub fn output_column(&self, channel: u8) -> Result<usize, Error> {
        match self.channels.get(&channel) {
            Some(
                OpenFile::Write { column, .. }
                | OpenFile::Binary { column, .. }
                | OpenFile::Serial { column, .. },
            ) => Ok(*column),
            Some(OpenFile::Read { .. }) | Some(OpenFile::Random { .. }) => {
                Err(Error::FileModeMismatch { channel })
            }
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    /// Validate that a channel can provide input before destinations resolve.
    pub fn ensure_readable(&self, channel: u8) -> Result<(), Error> {
        match self.channels.get(&channel) {
            Some(OpenFile::Read { .. } | OpenFile::Binary { .. } | OpenFile::Serial { .. }) => {
                Ok(())
            }
            Some(OpenFile::Write { .. }) | Some(OpenFile::Random { .. }) => {
                Err(Error::FileModeMismatch { channel })
            }
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    /// Append bytes to a writable channel and flush them to the host file.
    pub fn write(&mut self, channel: u8, bytes: &[u8]) -> Result<(), Error> {
        let open = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?;
        if let OpenFile::Binary {
            file,
            position,
            column,
        } = open
        {
            let next = position
                .checked_add(bytes.len())
                .ok_or(Error::FileLimitExceeded {
                    limit: self.max_file_bytes,
                })?;
            if next > self.max_file_bytes {
                return Err(Error::FileLimitExceeded {
                    limit: self.max_file_bytes,
                });
            }
            file.seek(SeekFrom::Start(*position as u64))?;
            file.write_all(bytes)?;
            file.flush()?;
            *position = next;
            *column = advance_column_bytes(*column, bytes);
            return Ok(());
        }
        if let OpenFile::Serial {
            file,
            pending_output,
            bytes_written,
            column,
            ..
        } = open
        {
            let retrying_same_record = pending_output
                .as_ref()
                .is_some_and(|pending| pending.bytes == bytes);
            if let Some(pending) = pending_output.as_mut() {
                if !drain_serial_output(file, pending)? {
                    return Err(Error::Io("serial output would block".into()));
                }
                file.flush()?;
                let completed = pending_output
                    .take()
                    .expect("completed serial output remains pending until committed");
                *bytes_written = bytes_written.checked_add(completed.bytes.len()).ok_or(
                    Error::FileLimitExceeded {
                        limit: self.max_file_bytes,
                    },
                )?;
                *column = advance_column_bytes(*column, &completed.bytes);
                if retrying_same_record {
                    return Ok(());
                }
            }

            let next = bytes_written
                .checked_add(bytes.len())
                .ok_or(Error::FileLimitExceeded {
                    limit: self.max_file_bytes,
                })?;
            if next > self.max_file_bytes {
                return Err(Error::FileLimitExceeded {
                    limit: self.max_file_bytes,
                });
            }
            if bytes.is_empty() {
                return Ok(());
            }
            *pending_output = Some(PendingSerialOutput {
                bytes: bytes.to_vec(),
                offset: 0,
            });
            let completed = drain_serial_output(
                file,
                pending_output
                    .as_mut()
                    .expect("new serial output is pending before its first write"),
            )?;
            if !completed {
                return Err(Error::Io("serial output would block".into()));
            }
            file.flush()?;
            pending_output.take();
            *bytes_written = next;
            *column = advance_column_bytes(*column, bytes);
            return Ok(());
        }
        let OpenFile::Write {
            file,
            total_bytes,
            column,
        } = open
        else {
            return Err(Error::FileModeMismatch { channel });
        };
        let next = total_bytes
            .checked_add(bytes.len())
            .ok_or(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            })?;
        if next > self.max_file_bytes {
            return Err(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            });
        }
        file.write_all(bytes)?;
        file.flush()?;
        *total_bytes = next;
        *column = advance_column_bytes(*column, bytes);
        Ok(())
    }

    /// Read one bounded UTF-8 line from a readable channel.
    pub fn read_line(&mut self, channel: u8, max_line_bytes: usize) -> Result<String, Error> {
        if matches!(self.channels.get(&channel), Some(OpenFile::Serial { .. })) {
            self.poll_serial(channel)?;
            let OpenFile::Serial {
                buffer, bytes_read, ..
            } = self
                .channels
                .get_mut(&channel)
                .expect("polled serial channel remains open")
            else {
                unreachable!();
            };
            if buffer.is_empty() {
                return Err(Error::EndOfFile { channel });
            }
            let newline = buffer.iter().position(|byte| *byte == b'\n');
            let count = newline.unwrap_or(buffer.len());
            if count > max_line_bytes {
                return Err(Error::FileLimitExceeded {
                    limit: max_line_bytes,
                });
            }
            let bytes = buffer.drain(..count).collect::<Vec<_>>();
            if newline.is_some() {
                buffer.pop_front();
            }
            *bytes_read = bytes_read
                .checked_add(bytes.len() + usize::from(newline.is_some()))
                .ok_or(Error::FileLimitExceeded {
                    limit: self.max_file_bytes,
                })?;
            let mut text = String::from_utf8(bytes).map_err(|_| Error::BadFileData { channel })?;
            if text.ends_with('\r') {
                text.pop();
            }
            return Ok(text);
        }
        let open = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?;
        let OpenFile::Read { reader, bytes_read } = open else {
            return Err(Error::FileModeMismatch { channel });
        };
        let before = reader.stream_position()?;
        let line = read_bounded_line(reader, max_line_bytes).map_err(|error| match error {
            BoundedLineError::Io(message) => Error::Io(message),
            BoundedLineError::Interrupted => Error::Io("I/O operation interrupted".into()),
            BoundedLineError::TooLong { .. } => Error::FileLimitExceeded {
                limit: max_line_bytes,
            },
            BoundedLineError::InvalidUtf8 => Error::BadFileData { channel },
        })?;
        let after = reader.stream_position()?;
        let line = line.ok_or(Error::EndOfFile { channel })?;
        let consumed = usize::try_from(after.saturating_sub(before)).unwrap_or(usize::MAX);
        *bytes_read = bytes_read
            .checked_add(consumed)
            .ok_or(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            })?;
        if *bytes_read > self.max_file_bytes {
            return Err(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            });
        }
        Ok(line)
    }

    /// Read one raw byte from a readable channel.
    pub fn read_byte(&mut self, channel: u8) -> Result<u8, Error> {
        if matches!(self.channels.get(&channel), Some(OpenFile::Serial { .. })) {
            self.poll_serial(channel)?;
            let OpenFile::Serial {
                buffer, bytes_read, ..
            } = self
                .channels
                .get_mut(&channel)
                .expect("polled serial channel remains open")
            else {
                unreachable!();
            };
            let byte = buffer.pop_front().ok_or(Error::EndOfFile { channel })?;
            *bytes_read = bytes_read.checked_add(1).ok_or(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            })?;
            return Ok(byte);
        }
        let open = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?;
        if let OpenFile::Binary { file, position, .. } = open {
            file.seek(SeekFrom::Start(*position as u64))?;
            let mut byte = [0u8; 1];
            if file.read(&mut byte)? == 0 {
                return Err(Error::EndOfFile { channel });
            }
            *position += 1;
            return Ok(byte[0]);
        }
        let OpenFile::Read { reader, bytes_read } = open else {
            return Err(Error::FileModeMismatch { channel });
        };
        let mut byte = [0u8; 1];
        match reader.read(&mut byte)? {
            0 => Err(Error::EndOfFile { channel }),
            1 => {
                *bytes_read = bytes_read.checked_add(1).ok_or(Error::FileLimitExceeded {
                    limit: self.max_file_bytes,
                })?;
                if *bytes_read > self.max_file_bytes {
                    return Err(Error::FileLimitExceeded {
                        limit: self.max_file_bytes,
                    });
                }
                Ok(byte[0])
            }
            _ => unreachable!("one-byte read returned more than one byte"),
        }
    }

    /// Poll a serial channel once and report whether buffered data is ready.
    /// Reads continue until the non-blocking descriptor returns `WouldBlock`.
    pub fn serial_data_available(&mut self, channel: u8) -> Result<bool, Error> {
        self.poll_serial(channel)?;
        match self.channels.get(&channel) {
            Some(OpenFile::Serial { buffer, .. }) => Ok(!buffer.is_empty()),
            Some(_) => Err(Error::FileModeMismatch { channel }),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    fn poll_serial(&mut self, channel: u8) -> Result<(), Error> {
        let OpenFile::Serial { file, buffer, .. } = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?
        else {
            return Err(Error::FileModeMismatch { channel });
        };
        let mut bytes = [0u8; 1024];
        loop {
            match file.read(&mut bytes) {
                Ok(0) => return Ok(()),
                Ok(count) => {
                    let next = buffer
                        .len()
                        .checked_add(count)
                        .ok_or(Error::FileLimitExceeded {
                            limit: self.max_file_bytes,
                        })?;
                    if next > self.max_file_bytes {
                        return Err(Error::FileLimitExceeded {
                            limit: self.max_file_bytes,
                        });
                    }
                    buffer.extend(&bytes[..count]);
                }
                Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => return Ok(()),
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => return Err(error.into()),
            }
        }
    }

    /// Read an exact block from the current position of a binary channel.
    /// A short read leaves the logical BASIC position unchanged, so a trapped
    /// EOF can be retried after the underlying file is repaired or replaced.
    pub fn read_binary_exact(&mut self, channel: u8, length: usize) -> Result<Vec<u8>, Error> {
        let open = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?;
        let OpenFile::Binary { file, position, .. } = open else {
            return Err(Error::FileModeMismatch { channel });
        };
        let end = position
            .checked_add(length)
            .ok_or(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            })?;
        if end > self.max_file_bytes {
            return Err(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            });
        }
        file.seek(SeekFrom::Start(*position as u64))?;
        let mut bytes = vec![0u8; length];
        let mut read = 0usize;
        while read < length {
            let count = file.read(&mut bytes[read..])?;
            if count == 0 {
                return Err(Error::EndOfFile { channel });
            }
            read += count;
        }
        *position = end;
        Ok(bytes)
    }

    /// Return whether a channel is open for random record access.
    pub fn is_random(&self, channel: u8) -> Result<bool, Error> {
        match self.channels.get(&channel) {
            Some(OpenFile::Random { .. }) => Ok(true),
            Some(_) => Ok(false),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    /// Return whether a channel is open for byte-addressable binary access.
    pub fn is_binary(&self, channel: u8) -> Result<bool, Error> {
        match self.channels.get(&channel) {
            Some(OpenFile::Binary { .. }) => Ok(true),
            Some(_) => Ok(false),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    /// Set a binary channel's one-based BASIC byte position.
    pub fn seek_binary(&mut self, channel: u8, position: usize) -> Result<(), Error> {
        if position == 0 || position > self.max_file_bytes.saturating_add(1) {
            return Err(Error::IllegalQuantity);
        }
        match self.channels.get_mut(&channel) {
            Some(OpenFile::Binary {
                file,
                position: current,
                column,
            }) => {
                let offset = position - 1;
                file.seek(SeekFrom::Start(offset as u64))?;
                *current = offset;
                *column = 0;
                Ok(())
            }
            Some(_) => Err(Error::FileModeMismatch { channel }),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    /// Set the fixed record length for a newly opened random channel.
    pub fn set_random_record_len(&mut self, channel: u8, record_len: usize) -> Result<(), Error> {
        if record_len == 0 || record_len > self.max_file_bytes {
            return Err(Error::IllegalQuantity);
        }
        match self.channels.get_mut(&channel) {
            Some(OpenFile::Random {
                record_len: len,
                buffer,
                last_record,
                ..
            }) => {
                *len = record_len;
                *buffer = vec![b' '; record_len];
                *last_record = 0;
                Ok(())
            }
            Some(_) => Err(Error::FileModeMismatch { channel }),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    pub fn random_record_len(&self, channel: u8) -> Result<usize, Error> {
        match self.channels.get(&channel) {
            Some(OpenFile::Random { record_len, .. }) => Ok(*record_len),
            Some(_) => Err(Error::FileModeMismatch { channel }),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    pub fn set_random_field(
        &mut self,
        channel: u8,
        offset: usize,
        bytes: &[u8],
    ) -> Result<(), Error> {
        match self.channels.get_mut(&channel) {
            Some(OpenFile::Random { buffer, .. }) => {
                let end = offset
                    .checked_add(bytes.len())
                    .ok_or(Error::IllegalQuantity)?;
                if end > buffer.len() {
                    return Err(Error::IllegalQuantity);
                }
                buffer[offset..end].copy_from_slice(bytes);
                Ok(())
            }
            Some(_) => Err(Error::FileModeMismatch { channel }),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    pub fn get_random_record(
        &mut self,
        channel: u8,
        record: Option<usize>,
    ) -> Result<Vec<u8>, Error> {
        let open = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?;
        let OpenFile::Random {
            file,
            record_len,
            buffer,
            last_record,
        } = open
        else {
            return Err(Error::FileModeMismatch { channel });
        };
        let record = record.unwrap_or(last_record.saturating_add(1));
        if !(1..=32_767).contains(&record) {
            return Err(Error::IllegalQuantity);
        }
        let offset = (record - 1)
            .checked_mul(*record_len)
            .ok_or(Error::IllegalQuantity)?;
        file.seek(SeekFrom::Start(offset as u64))?;
        let mut next_buffer = vec![0u8; *record_len];
        let mut read = 0usize;
        while read < *record_len {
            let count = file.read(&mut next_buffer[read..])?;
            if count == 0 {
                return Err(Error::EndOfFile { channel });
            }
            read += count;
        }
        *buffer = next_buffer;
        *last_record = record;
        Ok(buffer.clone())
    }

    pub fn put_random_record(&mut self, channel: u8, record: Option<usize>) -> Result<(), Error> {
        let open = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?;
        let OpenFile::Random {
            file,
            record_len,
            buffer,
            last_record,
        } = open
        else {
            return Err(Error::FileModeMismatch { channel });
        };
        let record = record.unwrap_or(last_record.saturating_add(1));
        if !(1..=32_767).contains(&record) {
            return Err(Error::IllegalQuantity);
        }
        let offset = (record - 1)
            .checked_mul(*record_len)
            .ok_or(Error::IllegalQuantity)?;
        let end = offset
            .checked_add(*record_len)
            .ok_or(Error::IllegalQuantity)?;
        if end > self.max_file_bytes {
            return Err(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            });
        }
        file.seek(SeekFrom::Start(offset as u64))?;
        file.write_all(buffer)?;
        file.flush()?;
        *last_record = record;
        Ok(())
    }

    /// Write a typed payload as one random record, zero-padding any unused
    /// bytes. Validation and host I/O complete before the channel buffer and
    /// current-record metadata are committed.
    pub fn put_random_data(
        &mut self,
        channel: u8,
        record: Option<usize>,
        bytes: &[u8],
    ) -> Result<(), Error> {
        let open = self
            .channels
            .get_mut(&channel)
            .ok_or(Error::FileChannelNotOpen { channel })?;
        let OpenFile::Random {
            file,
            record_len,
            buffer,
            last_record,
        } = open
        else {
            return Err(Error::FileModeMismatch { channel });
        };
        if bytes.len() > *record_len {
            return Err(Error::IllegalQuantity);
        }
        let record = record.unwrap_or(last_record.saturating_add(1));
        if !(1..=32_767).contains(&record) {
            return Err(Error::IllegalQuantity);
        }
        let offset = (record - 1)
            .checked_mul(*record_len)
            .ok_or(Error::IllegalQuantity)?;
        let end = offset
            .checked_add(*record_len)
            .ok_or(Error::IllegalQuantity)?;
        if end > self.max_file_bytes {
            return Err(Error::FileLimitExceeded {
                limit: self.max_file_bytes,
            });
        }
        let mut next_buffer = vec![0u8; *record_len];
        next_buffer[..bytes.len()].copy_from_slice(bytes);
        file.seek(SeekFrom::Start(offset as u64))?;
        file.write_all(&next_buffer)?;
        file.flush()?;
        *buffer = next_buffer;
        *last_record = record;
        Ok(())
    }

    /// BASIC LOC: current byte count for sequential channels, last record for RANDOM.
    pub fn location(&self, channel: u8) -> Result<usize, Error> {
        match self.channels.get(&channel) {
            Some(OpenFile::Read { bytes_read, .. }) => Ok(*bytes_read),
            Some(OpenFile::Write { total_bytes, .. }) => Ok(*total_bytes),
            Some(OpenFile::Random { last_record, .. }) => Ok(*last_record),
            Some(OpenFile::Binary { position, .. }) => Ok(*position),
            Some(OpenFile::Serial { bytes_read, .. }) => Ok(*bytes_read),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    /// BASIC LOF: current host-file length in bytes.
    pub fn length(&self, channel: u8) -> Result<usize, Error> {
        let length = match self.channels.get(&channel) {
            Some(OpenFile::Read { reader, .. }) => reader.get_ref().metadata()?.len(),
            Some(OpenFile::Write { file, .. })
            | Some(OpenFile::Random { file, .. })
            | Some(OpenFile::Binary { file, .. }) => file.metadata()?.len(),
            Some(OpenFile::Serial { buffer, .. }) => buffer.len() as u64,
            None => return Err(Error::FileChannelNotOpen { channel }),
        };
        usize::try_from(length).map_err(|_| Error::FileLimitExceeded {
            limit: self.max_file_bytes,
        })
    }

    /// BASIC EOF: -1 once a readable channel is positioned at end, otherwise 0.
    pub fn eof_value(&self, channel: u8) -> Result<i64, Error> {
        match self.channels.get(&channel) {
            Some(OpenFile::Read { bytes_read, reader }) => {
                let length =
                    usize::try_from(reader.get_ref().metadata()?.len()).unwrap_or(usize::MAX);
                Ok(if *bytes_read >= length { -1 } else { 0 })
            }
            Some(OpenFile::Random {
                last_record,
                record_len,
                file,
                ..
            }) => {
                let position = last_record.saturating_mul(*record_len);
                let length = usize::try_from(file.metadata()?.len()).unwrap_or(usize::MAX);
                Ok(if position >= length { -1 } else { 0 })
            }
            Some(OpenFile::Binary { position, file, .. }) => {
                let length = usize::try_from(file.metadata()?.len()).unwrap_or(usize::MAX);
                Ok(if *position >= length { -1 } else { 0 })
            }
            Some(OpenFile::Serial { buffer, .. }) => Ok(if buffer.is_empty() { -1 } else { 0 }),
            Some(OpenFile::Write { .. }) => Err(Error::FileModeMismatch { channel }),
            None => Err(Error::FileChannelNotOpen { channel }),
        }
    }

    pub(crate) fn resolve(&self, text: &str, must_exist: bool) -> Result<PathBuf, Error> {
        let root = self.root.as_ref().ok_or(Error::FileIoDisabled)?;
        let relative = Path::new(text);
        if text.is_empty()
            || relative.is_absolute()
            || relative
                .components()
                .any(|component| !matches!(component, Component::Normal(_)))
        {
            return Err(Error::InvalidFilePath);
        }

        let mut cursor = root.clone();
        let components = relative.components().collect::<Vec<_>>();
        for (index, component) in components.iter().enumerate() {
            let Component::Normal(component) = component else {
                return Err(Error::InvalidFilePath);
            };
            let exact = cursor.join(component);
            let existing = match fs::symlink_metadata(&exact) {
                Ok(metadata) if metadata.file_type().is_symlink() => {
                    return Err(Error::InvalidFilePath)
                }
                Ok(_) => Some(exact),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                    self.case_insensitive_child(&cursor, component)?
                }
                Err(error) => return Err(error.into()),
            };
            if let Some(existing) = existing {
                cursor = existing;
                continue;
            }
            if !must_exist && index + 1 == components.len() {
                cursor.push(component);
                break;
            }
            return Err(std::io::Error::new(
                std::io::ErrorKind::NotFound,
                format!("path not found: {}", self.visible_path(relative).display()),
            )
            .into());
        }

        let checked = if must_exist || cursor.exists() {
            fs::canonicalize(&cursor)?
        } else {
            let parent = cursor.parent().ok_or(Error::InvalidFilePath)?;
            let parent = fs::canonicalize(parent)?;
            let name = cursor.file_name().ok_or(Error::InvalidFilePath)?;
            parent.join(name)
        };
        if !checked.starts_with(root) {
            return Err(Error::InvalidFilePath);
        }
        Ok(checked)
    }

    /// Render a sandboxed path the same way users address it. In particular,
    /// backend assets rooted at `soundfont/` must never be mislabeled as files
    /// under `programs/` in an I/O diagnostic.
    fn visible_path(&self, relative: &Path) -> PathBuf {
        let Some(sandbox_root) = self.sandbox_root.as_ref() else {
            return relative.to_path_buf();
        };
        let mut visible = sandbox_root
            .file_name()
            .map(PathBuf::from)
            .unwrap_or_default();
        if let Some(root) = self.root.as_ref() {
            if let Ok(current) = root.strip_prefix(sandbox_root) {
                visible.push(current);
            }
        }
        visible.push(relative);
        visible
    }

    fn case_insensitive_child(
        &self,
        directory: &Path,
        requested: &std::ffi::OsStr,
    ) -> Result<Option<PathBuf>, Error> {
        let requested = requested.to_string_lossy();
        let mut found = None;
        for entry in fs::read_dir(directory)? {
            let entry = entry?;
            if !entry
                .file_name()
                .to_string_lossy()
                .eq_ignore_ascii_case(&requested)
            {
                continue;
            }
            if found.is_some() {
                return Err(Error::InvalidFilePath);
            }
            let path = entry.path();
            if fs::symlink_metadata(&path)?.file_type().is_symlink() {
                return Err(Error::InvalidFilePath);
            }
            found = Some(path);
        }
        Ok(found)
    }
}

fn drain_serial_output<W: Write>(
    writer: &mut W,
    pending: &mut PendingSerialOutput,
) -> io::Result<bool> {
    while pending.offset < pending.bytes.len() {
        match writer.write(&pending.bytes[pending.offset..]) {
            Ok(0) => {
                return Err(io::Error::new(
                    io::ErrorKind::WriteZero,
                    "serial descriptor accepted zero output bytes",
                ))
            }
            Ok(count) => pending.offset += count,
            Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
            Err(error) if error.kind() == io::ErrorKind::WouldBlock => return Ok(false),
            Err(error) => return Err(error),
        }
    }
    Ok(true)
}

impl Drop for FileStore {
    fn drop(&mut self) {
        if let Ok(mut registry) = global_file_locks().lock() {
            registry.retain(|_, locks| {
                locks.retain(|lock| lock.owner_id != self.owner_id);
                !locks.is_empty()
            });
        }
    }
}

fn serial_baud_constant(baud: u32) -> Result<u32, Error> {
    Ok(match baud {
        50 => 0x0001,
        75 => 0x0002,
        110 => 0x0003,
        134 => 0x0004,
        150 => 0x0005,
        200 => 0x0006,
        300 => 0x0007,
        600 => 0x0008,
        1_200 => 0x0009,
        1_800 => 0x000a,
        2_400 => 0x000b,
        4_800 => 0x000c,
        9_600 => 0x000d,
        19_200 => 0x000e,
        38_400 => 0x000f,
        57_600 => 0x1001,
        115_200 => 0x1002,
        230_400 => 0x1003,
        _ => return Err(Error::syntax("unsupported serial baud rate")),
    })
}

#[cfg(target_os = "linux")]
#[repr(C)]
struct LinuxTermios {
    input_flags: u32,
    output_flags: u32,
    control_flags: u32,
    local_flags: u32,
    line_discipline: u8,
    control_characters: [u8; 32],
    input_speed: u32,
    output_speed: u32,
}

#[cfg(target_os = "linux")]
unsafe extern "C" {
    fn tcgetattr(fd: i32, termios: *mut LinuxTermios) -> i32;
    fn tcsetattr(fd: i32, actions: i32, termios: *const LinuxTermios) -> i32;
    fn cfsetispeed(termios: *mut LinuxTermios, speed: u32) -> i32;
    fn cfsetospeed(termios: *mut LinuxTermios, speed: u32) -> i32;
}

#[cfg(target_os = "linux")]
fn configure_serial(file: &File, config: SerialConfig) -> Result<(), Error> {
    const CSIZE: u32 = 0o60;
    const CS5: u32 = 0o00;
    const CS6: u32 = 0o20;
    const CS7: u32 = 0o40;
    const CS8: u32 = 0o60;
    const CSTOPB: u32 = 0o100;
    const CREAD: u32 = 0o200;
    const PARENB: u32 = 0o400;
    const PARODD: u32 = 0o1000;
    const CLOCAL: u32 = 0o4000;
    const CRTSCTS: u32 = 0x8000_0000;
    const TCSANOW: i32 = 0;
    const VTIME: usize = 5;
    const VMIN: usize = 6;

    let mut termios = std::mem::MaybeUninit::<LinuxTermios>::uninit();
    // SAFETY: `termios` points to writable storage with the Linux termios ABI,
    // and the file descriptor remains valid for this complete operation.
    if unsafe { tcgetattr(file.as_raw_fd(), termios.as_mut_ptr()) } != 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    // SAFETY: tcgetattr succeeded and initialized the complete structure.
    let mut termios = unsafe { termios.assume_init() };
    termios.input_flags = 0;
    termios.output_flags = 0;
    termios.local_flags = 0;
    termios.control_flags &= !(CSIZE | CSTOPB | PARENB | PARODD | CRTSCTS);
    termios.control_flags |= CREAD | CLOCAL;
    termios.control_flags |= match config.data_bits {
        5 => CS5,
        6 => CS6,
        7 => CS7,
        8 => CS8,
        _ => return Err(Error::syntax("serial data bits must be 5 through 8")),
    };
    match config.parity {
        b'N' => {}
        b'E' => termios.control_flags |= PARENB,
        b'O' => termios.control_flags |= PARENB | PARODD,
        _ => return Err(Error::syntax("serial parity must be N, E, or O")),
    }
    if config.stop_bits == 2 {
        termios.control_flags |= CSTOPB;
    }
    termios.control_characters[VMIN] = 0;
    termios.control_characters[VTIME] = 0;
    let speed = serial_baud_constant(config.baud)?;
    // SAFETY: all calls receive a valid initialized termios pointer.
    if unsafe { cfsetispeed(&mut termios, speed) } != 0
        || unsafe { cfsetospeed(&mut termios, speed) } != 0
        || unsafe { tcsetattr(file.as_raw_fd(), TCSANOW, &termios) } != 0
    {
        return Err(std::io::Error::last_os_error().into());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};

    fn sandbox() -> PathBuf {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let path = std::env::temp_dir().join(format!(
            "modernbasic-file-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&path).unwrap();
        path
    }

    #[test]
    fn disabled_store_and_channel_range_are_explicit() {
        let mut store = FileStore::new(None, 1, 10).unwrap();
        assert_eq!(
            store.open(1, "x", FileMode::Write).unwrap_err(),
            Error::FileIoDisabled
        );
        assert_eq!(
            FileStore::channel(-1).unwrap_err(),
            Error::InvalidFileChannel { channel: -1 }
        );
        assert_eq!(
            FileStore::channel(256).unwrap_err(),
            Error::InvalidFileChannel { channel: 256 }
        );
    }

    #[test]
    fn serial_specs_and_mock_nonblocking_data_share_file_channels() {
        assert_eq!(
            SerialConfig::parse("COM2:19200,E,7,2").unwrap(),
            Some(SerialConfig {
                port: 2,
                baud: 19_200,
                parity: b'E',
                data_bits: 7,
                stop_bits: 2,
            })
        );
        assert!(SerialConfig::parse("plain.dat").unwrap().is_none());

        let root = sandbox();
        let path = root.join("mock-serial");
        fs::write(&path, b"READY\nZ").unwrap();
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .open(&path)
            .unwrap();
        let mut store = FileStore::new(None, 2, 100).unwrap();
        store.insert_serial(7, 2, path, file);
        assert_eq!(store.serial_channel_for_port(2), Some(7));
        assert!(store.serial_data_available(7).unwrap());
        assert_eq!(store.read_line(7, 20).unwrap(), "READY");
        assert_eq!(store.read_byte(7).unwrap(), b'Z');
        assert_eq!(
            store.read_byte(7).unwrap_err(),
            Error::EndOfFile { channel: 7 }
        );
        store.close_serials().unwrap();
        assert_eq!(store.serial_channel_for_port(2), None);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn serial_pending_output_resumes_after_a_partial_would_block() {
        struct PartialWriter {
            output: Vec<u8>,
            calls: usize,
        }

        impl Write for PartialWriter {
            fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
                self.calls += 1;
                if self.calls == 2 {
                    return Err(io::Error::from(io::ErrorKind::WouldBlock));
                }
                let count = if self.calls == 1 {
                    bytes.len().min(3)
                } else {
                    bytes.len()
                };
                self.output.extend_from_slice(&bytes[..count]);
                Ok(count)
            }

            fn flush(&mut self) -> io::Result<()> {
                Ok(())
            }
        }

        let mut writer = PartialWriter {
            output: Vec::new(),
            calls: 0,
        };
        let mut pending = PendingSerialOutput {
            bytes: b"RECORD".to_vec(),
            offset: 0,
        };
        assert!(!drain_serial_output(&mut writer, &mut pending).unwrap());
        assert_eq!(pending.offset, 3);
        assert!(drain_serial_output(&mut writer, &mut pending).unwrap());
        assert_eq!(writer.output, b"RECORD");
    }

    #[test]
    fn write_append_and_read_round_trip() {
        let root = sandbox();
        let mut store = FileStore::new(Some(root.clone()), 4, 100).unwrap();
        store.open(1, "data.txt", FileMode::Write).unwrap();
        assert_eq!(store.output_column(1).unwrap(), 0);
        store.write(1, b"A\n").unwrap();
        assert_eq!(store.output_column(1).unwrap(), 0);
        store.close(1).unwrap();
        fs::write(root.join("tail.txt"), "HEADER\né").unwrap();
        store.open(3, "tail.txt", FileMode::Append).unwrap();
        assert_eq!(store.output_column(3).unwrap(), 1);
        store.write(3, b"X").unwrap();
        assert_eq!(store.output_column(3).unwrap(), 2);
        store.close(3).unwrap();
        store.open(1, "data.txt", FileMode::Append).unwrap();
        store.write(1, b"B\n").unwrap();
        store.close(1).unwrap();
        store.open(2, "data.txt", FileMode::Read).unwrap();
        assert_eq!(store.read_line(2, 10).unwrap(), "A");
        assert_eq!(store.read_line(2, 10).unwrap(), "B");
        assert_eq!(
            store.read_line(2, 10).unwrap_err(),
            Error::EndOfFile { channel: 2 }
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn missing_path_reports_the_real_sandbox_and_current_directory() {
        let root = sandbox();
        let soundfont = root.join("soundfont");
        let banks = soundfont.join("banks");
        fs::create_dir_all(&banks).unwrap();
        let mut store = FileStore::new(Some(soundfont), 1, 100).unwrap();

        let err = store.resolve("Persa.sf2", true).unwrap_err();
        assert_eq!(err, Error::Io("path not found: soundfont/Persa.sf2".into()));

        store.change_dir("banks").unwrap();
        let err = store.resolve("Persa.sf2", true).unwrap_err();
        assert_eq!(
            err,
            Error::Io("path not found: soundfont/banks/Persa.sf2".into())
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn advisory_locks_require_exact_unlock_and_close_releases_them() {
        let root = sandbox();
        let mut store = FileStore::new(Some(root.clone()), 2, 100).unwrap();
        store.open(1, "data.bin", FileMode::Binary).unwrap();
        store.open(2, "data.bin", FileMode::Binary).unwrap();
        store.lock(1, Some((1, 10))).unwrap();
        assert!(store.lock(1, Some((5, 12))).is_err());
        assert!(store.lock(2, Some((5, 12))).is_err());
        store.lock(2, Some((20, 30))).unwrap();
        store.unlock(2, Some((20, 30))).unwrap();
        assert!(store.unlock(1, Some((2, 10))).is_err());
        store.unlock(1, Some((1, 10))).unwrap();
        store.lock(1, None).unwrap();
        assert!(store.lock(1, Some((20, 30))).is_err());
        store.close(1).unwrap();
        store.open(1, "data.bin", FileMode::Binary).unwrap();
        store.lock(1, None).unwrap();
        store.close_all().unwrap();
        assert_eq!(
            store.unlock(1, None).unwrap_err(),
            Error::FileChannelNotOpen { channel: 1 }
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn advisory_locks_coordinate_across_file_stores_and_drop_releases_them() {
        let root = sandbox();
        let mut first = FileStore::new(Some(root.clone()), 1, 100).unwrap();
        let mut second = FileStore::new(Some(root.clone()), 1, 100).unwrap();
        first.open(1, "shared.bin", FileMode::Binary).unwrap();
        second.open(1, "shared.bin", FileMode::Binary).unwrap();
        first.lock(1, Some((1, 10))).unwrap();
        assert!(second.lock(1, Some((5, 12))).is_err());
        second.lock(1, Some((20, 30))).unwrap();
        second.unlock(1, Some((20, 30))).unwrap();
        drop(first);
        second.lock(1, Some((5, 12))).unwrap();
        second.close_all().unwrap();
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn bounded_whole_file_operations_support_program_snapshots() {
        let root = sandbox();
        let store = FileStore::new(Some(root.clone()), 2, 12).unwrap();
        store.write_all("program.bas", b"10 PRINT 1\n").unwrap();
        assert_eq!(store.read_all("program.bas").unwrap(), b"10 PRINT 1\n");
        fs::write(root.join("asset.bin"), b"1234567890123").unwrap();
        assert_eq!(
            store.read_all_with_limit("asset.bin", 13).unwrap(),
            b"1234567890123"
        );
        assert_eq!(
            store.read_all("asset.bin").unwrap_err(),
            Error::FileLimitExceeded { limit: 12 }
        );
        assert_eq!(
            store.write_all("large.bas", b"1234567890123").unwrap_err(),
            Error::FileLimitExceeded { limit: 12 }
        );
        assert_eq!(
            store.read_all("../program.bas").unwrap_err(),
            Error::InvalidFilePath
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn line_and_raw_byte_reads_share_one_buffered_position() {
        let root = sandbox();
        fs::write(root.join("mixed.txt"), b"LINE\nA7").unwrap();
        let mut store = FileStore::new(Some(root.clone()), 2, 100).unwrap();
        store.open(1, "mixed.txt", FileMode::Read).unwrap();
        assert_eq!(store.read_line(1, 10).unwrap(), "LINE");
        assert_eq!(store.read_byte(1).unwrap(), b'A');
        assert_eq!(store.read_byte(1).unwrap(), b'7');
        assert_eq!(
            store.read_byte(1).unwrap_err(),
            Error::EndOfFile { channel: 1 }
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn exact_limit_unterminated_input_ends_with_eof_not_limit_error() {
        let root = sandbox();
        fs::write(root.join("exact.txt"), b"12345").unwrap();
        let mut line_store = FileStore::new(Some(root.clone()), 2, 5).unwrap();
        line_store.open(1, "exact.txt", FileMode::Read).unwrap();
        assert_eq!(line_store.read_line(1, 5).unwrap(), "12345");
        assert_eq!(
            line_store.read_line(1, 5).unwrap_err(),
            Error::EndOfFile { channel: 1 }
        );

        let mut byte_store = FileStore::new(Some(root.clone()), 2, 5).unwrap();
        byte_store.open(1, "exact.txt", FileMode::Read).unwrap();
        for expected in *b"12345" {
            assert_eq!(byte_store.read_byte(1).unwrap(), expected);
        }
        assert_eq!(
            byte_store.read_byte(1).unwrap_err(),
            Error::EndOfFile { channel: 1 }
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn traversal_absolute_and_symlink_paths_are_rejected() {
        let root = sandbox();
        let mut store = FileStore::new(Some(root.clone()), 4, 100).unwrap();
        for path in ["../escape", "./local", "/absolute", ""] {
            assert_eq!(
                store.open(1, path, FileMode::Write).unwrap_err(),
                Error::InvalidFilePath,
                "{path}"
            );
        }

        #[cfg(unix)]
        {
            std::os::unix::fs::symlink(std::env::temp_dir(), root.join("link")).unwrap();
            assert_eq!(
                store.open(1, "link/escape", FileMode::Write).unwrap_err(),
                Error::InvalidFilePath
            );
        }
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn open_mode_count_and_size_limits_are_enforced() {
        let root = sandbox();
        fs::write(root.join("input.txt"), b"12345\n").unwrap();
        let mut store = FileStore::new(Some(root.clone()), 1, 5).unwrap();
        assert_eq!(
            store.open(1, "input.txt", FileMode::Read).unwrap_err(),
            Error::FileLimitExceeded { limit: 5 }
        );

        store.open(1, "output.txt", FileMode::Write).unwrap();
        assert_eq!(
            store.open(1, "other.txt", FileMode::Write).unwrap_err(),
            Error::FileChannelAlreadyOpen { channel: 1 }
        );
        assert_eq!(
            store.open(2, "other.txt", FileMode::Write).unwrap_err(),
            Error::OpenFileLimitExceeded { limit: 1 }
        );
        assert_eq!(
            store.read_line(1, 5).unwrap_err(),
            Error::FileModeMismatch { channel: 1 }
        );
        store.write(1, b"12345").unwrap();
        assert_eq!(
            store.write(1, b"6").unwrap_err(),
            Error::FileLimitExceeded { limit: 5 }
        );
        store.close(1).unwrap();
        assert_eq!(
            store.close(1).unwrap_err(),
            Error::FileChannelNotOpen { channel: 1 }
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn exact_binary_and_random_reads_do_not_commit_partial_eof_state() {
        let root = sandbox();
        fs::write(root.join("binary.dat"), b"ABC").unwrap();
        let mut binary = FileStore::new(Some(root.clone()), 2, 100).unwrap();
        binary.open(1, "binary.dat", FileMode::Binary).unwrap();
        assert_eq!(
            binary.read_binary_exact(1, 4).unwrap_err(),
            Error::EndOfFile { channel: 1 }
        );
        assert_eq!(binary.location(1).unwrap(), 0);
        assert_eq!(binary.read_binary_exact(1, 3).unwrap(), b"ABC");
        assert_eq!(binary.location(1).unwrap(), 3);

        fs::write(root.join("random.dat"), b"XY").unwrap();
        let mut random = FileStore::new(Some(root.clone()), 2, 100).unwrap();
        random.open(1, "random.dat", FileMode::Random).unwrap();
        random.set_random_record_len(1, 4).unwrap();
        random.set_random_field(1, 0, b"SAFE").unwrap();
        assert_eq!(
            random.get_random_record(1, Some(1)).unwrap_err(),
            Error::EndOfFile { channel: 1 }
        );
        assert_eq!(random.location(1).unwrap(), 0);
        random.put_random_record(1, Some(2)).unwrap();
        random.close(1).unwrap();
        assert_eq!(&fs::read(root.join("random.dat")).unwrap()[4..8], b"SAFE");
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn existing_paths_match_case_insensitively_without_creating_duplicates() {
        let root = sandbox();
        fs::create_dir(root.join("MixedDir")).unwrap();
        fs::write(root.join("MixedDir/input.bas"), b"10 END\n").unwrap();
        let store = FileStore::new(Some(root.clone()), 2, 100).unwrap();
        assert_eq!(store.read_all("mixeddir/INPUT.BAS").unwrap(), b"10 END\n");
        store.write_all("MIXEDDIR/output.TXT", b"new").unwrap();
        assert_eq!(fs::read(root.join("MixedDir/output.TXT")).unwrap(), b"new");
        assert!(!root.join("MIXEDDIR").exists());
        fs::write(root.join("MixedDir/Result.txt"), b"old").unwrap();
        store.write_all("mixeddir/RESULT.TXT", b"updated").unwrap();
        assert_eq!(
            fs::read(root.join("MixedDir/Result.txt")).unwrap(),
            b"updated"
        );
        assert!(!root.join("MixedDir/RESULT.TXT").exists());
        fs::create_dir(root.join("Mix")).unwrap();
        fs::create_dir(root.join("mIX")).unwrap();
        assert_eq!(
            store.resolve("mix/file.txt", false).unwrap_err(),
            Error::InvalidFilePath
        );
        fs::remove_dir_all(root).unwrap();
    }
}
