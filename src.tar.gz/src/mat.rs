//! Parser for Dartmouth BASIC's thirteen `MAT` statement forms.
//!
//! Parsing is intentionally separate from execution so malformed statements
//! cannot consume DATA, input, storage capacity, or random-number state.

use crate::error::Error;
use crate::tokens::{Token, TokenInstance};

pub(crate) type DimensionExpressions = Vec<Vec<TokenInstance>>;

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct MatArraySpec {
    pub(crate) name: String,
    /// One expression denotes a vector; two denote rows and columns.
    pub(crate) dimensions: Option<DimensionExpressions>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum MatPrintMode {
    /// No trailing separator: matrices print normally and vectors as columns.
    Normal,
    /// A trailing comma: vectors print as rows in five-value zones.
    Row,
    /// A trailing semicolon: values print closely packed.
    Packed,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct MatPrintItem {
    pub(crate) name: String,
    pub(crate) mode: MatPrintMode,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum MatFill {
    Zero,
    One,
    Identity,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum MatExpression {
    Copy(String),
    Add(String, String),
    Subtract(String, String),
    Multiply(String, String),
    Scale {
        factor: Vec<TokenInstance>,
        source: String,
    },
    Transpose(String),
    Inverse(String),
    Fill {
        kind: MatFill,
        dimensions: Option<DimensionExpressions>,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum MatStatement {
    Read(Vec<MatArraySpec>),
    Print(Vec<MatPrintItem>),
    Input(String),
    Assign {
        target: String,
        expression: MatExpression,
    },
}

pub(crate) fn parse(tokens: &[TokenInstance]) -> Result<MatStatement, Error> {
    let Some(first) = tokens.first() else {
        return Err(Error::syntax("MAT requires an operation"));
    };
    match first {
        TokenInstance::Keyword(Token::Read) => parse_read(&tokens[1..]),
        TokenInstance::Keyword(Token::Print) => parse_print(&tokens[1..]),
        TokenInstance::Keyword(Token::Input) => parse_input(&tokens[1..]),
        TokenInstance::Ident(_) => parse_assignment(tokens),
        _ => Err(Error::syntax(
            "MAT requires READ, PRINT, INPUT, or an assignment",
        )),
    }
}

fn parse_read(tokens: &[TokenInstance]) -> Result<MatStatement, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax("MAT READ requires at least one array"));
    }
    let mut arrays = Vec::new();
    let mut pos = 0usize;
    loop {
        let name = identifier(tokens.get(pos), "MAT READ")?;
        pos += 1;
        let (dimensions, next) = optional_dimensions(tokens, pos)?;
        pos = next;
        arrays.push(MatArraySpec { name, dimensions });
        if pos == tokens.len() {
            break;
        }
        if !matches!(tokens.get(pos), Some(TokenInstance::Comma)) {
            return Err(Error::syntax("MAT READ arrays must be separated by ','"));
        }
        pos += 1;
        if pos == tokens.len() {
            return Err(Error::syntax("MAT READ cannot end with ','"));
        }
    }
    Ok(MatStatement::Read(arrays))
}

fn parse_print(tokens: &[TokenInstance]) -> Result<MatStatement, Error> {
    if tokens.is_empty() {
        return Err(Error::syntax("MAT PRINT requires at least one array"));
    }
    let mut arrays = Vec::new();
    let mut pos = 0usize;
    loop {
        let name = identifier(tokens.get(pos), "MAT PRINT")?;
        pos += 1;
        let mode = match tokens.get(pos) {
            Some(TokenInstance::Comma) => {
                pos += 1;
                MatPrintMode::Row
            }
            Some(TokenInstance::Semicolon) => {
                pos += 1;
                MatPrintMode::Packed
            }
            Some(_) => {
                return Err(Error::syntax(
                    "MAT PRINT arrays must be separated by ',' or ';'",
                ))
            }
            None => MatPrintMode::Normal,
        };
        arrays.push(MatPrintItem { name, mode });
        if pos == tokens.len() {
            break;
        }
    }
    Ok(MatStatement::Print(arrays))
}

fn parse_input(tokens: &[TokenInstance]) -> Result<MatStatement, Error> {
    match tokens {
        [TokenInstance::Ident(name)] => Ok(MatStatement::Input(name.clone())),
        [] => Err(Error::syntax("MAT INPUT requires a vector name")),
        _ => Err(Error::syntax("MAT INPUT accepts exactly one vector name")),
    }
}

fn parse_assignment(tokens: &[TokenInstance]) -> Result<MatStatement, Error> {
    let target = identifier(tokens.first(), "MAT assignment")?;
    if !matches!(tokens.get(1), Some(TokenInstance::Keyword(Token::Equal))) {
        return Err(Error::syntax("MAT assignment requires '='"));
    }
    let rhs = &tokens[2..];
    if rhs.is_empty() {
        return Err(Error::syntax("MAT assignment requires a right-hand side"));
    }

    let expression = if matches!(rhs.first(), Some(TokenInstance::LParen)) {
        parse_scale(rhs)?
    } else {
        let first = identifier(rhs.first(), "MAT expression")?;
        match first.as_str() {
            "ZER" | "CON" | "IDN" => {
                let kind = match first.as_str() {
                    "ZER" => MatFill::Zero,
                    "CON" => MatFill::One,
                    "IDN" => MatFill::Identity,
                    _ => unreachable!(),
                };
                let (dimensions, pos) = optional_dimensions(rhs, 1)?;
                if pos != rhs.len() {
                    return Err(Error::syntax("extra characters after MAT fill"));
                }
                MatExpression::Fill { kind, dimensions }
            }
            "TRN" | "INV" => {
                if !matches!(rhs.get(1), Some(TokenInstance::LParen))
                    || !matches!(rhs.get(3), Some(TokenInstance::RParen))
                    || rhs.len() != 4
                {
                    return Err(Error::syntax(format!(
                        "{first} requires exactly one matrix name in parentheses"
                    )));
                }
                let source = identifier(rhs.get(2), &first)?;
                if first == "TRN" {
                    MatExpression::Transpose(source)
                } else {
                    MatExpression::Inverse(source)
                }
            }
            _ => {
                match rhs {
                    [TokenInstance::Ident(source)] => MatExpression::Copy(source.clone()),
                    [TokenInstance::Ident(left), TokenInstance::Keyword(Token::Plus), TokenInstance::Ident(right)] => {
                        MatExpression::Add(left.clone(), right.clone())
                    }
                    [TokenInstance::Ident(left), TokenInstance::Keyword(Token::Minus), TokenInstance::Ident(right)] => {
                        MatExpression::Subtract(left.clone(), right.clone())
                    }
                    [TokenInstance::Ident(left), TokenInstance::Keyword(Token::Mul), TokenInstance::Ident(right)] => {
                        MatExpression::Multiply(left.clone(), right.clone())
                    }
                    _ => return Err(Error::syntax(
                        "MAT permits one copy, addition, subtraction, or multiplication operation",
                    )),
                }
            }
        }
    };

    Ok(MatStatement::Assign { target, expression })
}

fn parse_scale(tokens: &[TokenInstance]) -> Result<MatExpression, Error> {
    let mut depth = 0usize;
    let mut closing = None;
    for (position, token) in tokens.iter().enumerate() {
        match token {
            TokenInstance::LParen => depth += 1,
            TokenInstance::RParen => {
                if depth == 0 {
                    return Err(Error::syntax("unexpected ')' in MAT scalar expression"));
                }
                depth -= 1;
                if depth == 0 {
                    closing = Some(position);
                    break;
                }
            }
            _ => {}
        }
    }
    let closing = closing.ok_or_else(|| Error::syntax("MAT scalar expression requires ')'"))?;
    if closing == 1 {
        return Err(Error::syntax("MAT scalar expression cannot be empty"));
    }
    if !matches!(
        tokens.get(closing + 1),
        Some(TokenInstance::Keyword(Token::Mul))
    ) {
        return Err(Error::syntax(
            "MAT scalar expression must be followed by '*'",
        ));
    }
    let source = identifier(tokens.get(closing + 2), "MAT scalar multiplication")?;
    if closing + 3 != tokens.len() {
        return Err(Error::syntax(
            "extra characters after MAT scalar multiplication",
        ));
    }
    Ok(MatExpression::Scale {
        factor: tokens[1..closing].to_vec(),
        source,
    })
}

fn optional_dimensions(
    tokens: &[TokenInstance],
    pos: usize,
) -> Result<(Option<DimensionExpressions>, usize), Error> {
    if !matches!(tokens.get(pos), Some(TokenInstance::LParen)) {
        return Ok((None, pos));
    }
    let mut dimensions = Vec::new();
    let mut depth = 1usize;
    let mut start = pos + 1;
    let mut cursor = start;
    while cursor < tokens.len() {
        match &tokens[cursor] {
            TokenInstance::LParen => depth += 1,
            TokenInstance::RParen => {
                depth -= 1;
                if depth == 0 {
                    if start == cursor {
                        return Err(Error::syntax("MAT dimension expression cannot be empty"));
                    }
                    dimensions.push(tokens[start..cursor].to_vec());
                    if !(1..=2).contains(&dimensions.len()) {
                        return Err(Error::MatrixRankUnsupported {
                            dimensions: dimensions.len(),
                        });
                    }
                    return Ok((Some(dimensions), cursor + 1));
                }
            }
            TokenInstance::Comma if depth == 1 => {
                if start == cursor {
                    return Err(Error::syntax("MAT dimension expression cannot be empty"));
                }
                dimensions.push(tokens[start..cursor].to_vec());
                if dimensions.len() >= 2 {
                    return Err(Error::MatrixRankUnsupported {
                        dimensions: dimensions.len() + 1,
                    });
                }
                start = cursor + 1;
            }
            _ => {}
        }
        cursor += 1;
    }
    Err(Error::syntax("MAT dimensions require closing ')'"))
}

fn identifier(token: Option<&TokenInstance>, context: &str) -> Result<String, Error> {
    match token {
        Some(TokenInstance::Ident(name)) if !name.ends_with('$') => Ok(name.clone()),
        Some(TokenInstance::Ident(_)) => Err(Error::TypeMismatch),
        _ => Err(Error::syntax(format!(
            "{context} requires a numeric array name"
        ))),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tokens::tokenize;

    fn statement(source: &str) -> MatStatement {
        let tokens = tokenize(source).unwrap();
        let mat = tokens
            .iter()
            .position(|token| matches!(token, TokenInstance::Keyword(Token::Mat)))
            .unwrap();
        parse(&tokens[mat + 1..]).unwrap()
    }

    #[test]
    fn parses_the_thirteen_dartmouth_forms() {
        for source in [
            "10 MAT READ A,B(2,3)",
            "10 MAT A=ZER",
            "10 MAT A=CON(2,3)",
            "10 MAT A=IDN",
            "10 MAT PRINT A,B;C",
            "10 MAT INPUT V",
            "10 MAT B=A",
            "10 MAT C=A+B",
            "10 MAT C=A-B",
            "10 MAT C=A*B",
            "10 MAT C=TRN(A)",
            "10 MAT C=(K+1)*A",
            "10 MAT C=INV(A)",
        ] {
            statement(source);
        }
    }

    #[test]
    fn print_separator_selects_the_preceding_array_format() {
        assert_eq!(
            statement("10 MAT PRINT A,B;C"),
            MatStatement::Print(vec![
                MatPrintItem {
                    name: "A".into(),
                    mode: MatPrintMode::Row,
                },
                MatPrintItem {
                    name: "B".into(),
                    mode: MatPrintMode::Packed,
                },
                MatPrintItem {
                    name: "C".into(),
                    mode: MatPrintMode::Normal,
                },
            ])
        );
    }

    #[test]
    fn rejects_chained_matrix_arithmetic() {
        let tokens = tokenize("10 MAT D=A+B-C").unwrap();
        assert!(parse(&tokens[2..]).is_err());
    }
}
