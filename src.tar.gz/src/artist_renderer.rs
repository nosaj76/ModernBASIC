//! Internal Artist-derived graphics engine implemented in pure Rust.
//!
//! Parses Artist Script text and renders to SVG or PPM (binary raster) with no
//! external C++ binary. The BASIC runtime is self-contained.
//!
//! Ported from the C++ Artist engine at:
//!   artist/src/rendering/render/render.cpp (SVG writer + rasterizer)
//!   artist/src/scripting/script/script.cpp (script parser)
//!   artist/include/artist/scene.hpp (Scene/Shape/Style model)
//!   artist/include/artist/blend_mode.hpp (compositing modes)

#![allow(clippy::items_after_test_module, clippy::too_many_arguments)]
use std::cell::RefCell;
use std::collections::HashMap;
use std::fmt::Write as _;
use std::sync::Arc;

use crate::artist_scene::MAX_ARTIST_PIXELS;
use crate::error::Error;
use crate::image_codec;

/// Linear working RGB. Geometry and coverage remain binary64, while stored
/// color channels use binary32 to halve Full-HD framebuffer traffic without
/// reducing the final 8-bit output precision.
type RasterPixel = (f32, f32, f32);

/// Keep retained frames bounded even when callers select very large logical
/// screens. Full HD needs about 24 MiB; larger screens simply use the normal
/// complete render path.
const MAX_RASTER_PREFIX_CACHE_BYTES: usize = 32 * 1024 * 1024;

/// Decoded immutable program textures stay resident on their render thread.
/// The cache is replaced wholesale before it can exceed this bounded budget.
const MAX_BITMAP_TEXTURE_CACHE_BYTES: usize = 64 * 1024 * 1024;
/// Creating scoped OS threads costs more than the work for the relatively
/// small bands produced by ordinary HD scenes, especially inside a VM. Keep
/// those jobs on the already-dedicated render thread; reserve row fan-out for
/// genuinely large (roughly 4K) fills and conversions.
const MIN_PARALLEL_RASTER_PIXELS: usize = 4 * 1024 * 1024;
// ── Color ─────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct Color {
    pub r: u8,
    pub g: u8,
    pub b: u8,
    pub a: u8,
}

impl Color {
    pub const fn rgba(r: u8, g: u8, b: u8, a: u8) -> Self {
        Self { r, g, b, a }
    }
    pub const fn rgb(r: u8, g: u8, b: u8) -> Self {
        Self { r, g, b, a: 255 }
    }
    pub const TRANSPARENT: Self = Self::rgba(0, 0, 0, 0);
    pub const BLACK: Self = Self::rgb(0, 0, 0);
    pub const WHITE: Self = Self::rgb(255, 255, 255);

    pub fn alpha_unit(self) -> f64 {
        self.a as f64 / 255.0
    }
    pub fn to_svg(self) -> String {
        if self.a == 255 {
            format!("#{:02x}{:02x}{:02x}", self.r, self.g, self.b)
        } else {
            format!(
                "rgba({},{},{},{})",
                self.r,
                self.g,
                self.b,
                self.alpha_unit()
            )
        }
    }
}

pub(crate) fn parse_color(s: &str) -> Result<Color, Error> {
    let s = s.trim();
    if s.eq_ignore_ascii_case("none") || s.is_empty() {
        return Ok(Color::TRANSPARENT);
    }
    if let Some(hex) = s.strip_prefix('#') {
        if !hex.is_ascii() || !hex.bytes().all(|byte| byte.is_ascii_hexdigit()) {
            return Err(Error::syntax(format!("invalid color {s}")));
        }
        return match hex.len() {
            3 => {
                let bytes = hex.as_bytes();
                let expand = |byte: u8| {
                    (byte as char)
                        .to_digit(16)
                        .map(|value| (value as u8) * 17)
                        .ok_or_else(|| Error::syntax(format!("invalid color {s}")))
                };
                Ok(Color::rgb(
                    expand(bytes[0])?,
                    expand(bytes[1])?,
                    expand(bytes[2])?,
                ))
            }
            6 => {
                let value = u32::from_str_radix(hex, 16)
                    .map_err(|_| Error::syntax(format!("invalid color {s}")))?;
                Ok(Color::rgb(
                    (value >> 16) as u8,
                    (value >> 8) as u8,
                    value as u8,
                ))
            }
            8 => {
                let value = u32::from_str_radix(hex, 16)
                    .map_err(|_| Error::syntax(format!("invalid color {s}")))?;
                Ok(Color::rgba(
                    (value >> 24) as u8,
                    (value >> 16) as u8,
                    (value >> 8) as u8,
                    value as u8,
                ))
            }
            _ => Err(Error::syntax(format!("invalid color {s}"))),
        };
    }
    if let Some(inner) = s
        .strip_prefix("rgb(")
        .and_then(|value| value.strip_suffix(')'))
    {
        // rgb(r,g,b) or rgb(r,g,b,a)
        let parts: Vec<&str> = inner.split(',').collect();
        if !matches!(parts.len(), 3 | 4) {
            return Err(Error::syntax(format!("invalid color {s}")));
        }
        let parse_component = |component: &str| {
            component
                .trim()
                .parse::<u8>()
                .map_err(|_| Error::syntax(format!("invalid color {s}")))
        };
        let r = parse_component(parts[0])?;
        let g = parse_component(parts[1])?;
        let b = parse_component(parts[2])?;
        let a = if parts.len() == 4 {
            let alpha = parts[3]
                .trim()
                .parse::<f64>()
                .map_err(|_| Error::syntax(format!("invalid color {s}")))?;
            if !alpha.is_finite() || !(0.0..=1.0).contains(&alpha) {
                return Err(Error::syntax(format!("invalid color {s}")));
            }
            (alpha * 255.0).round() as u8
        } else {
            255
        };
        return Ok(Color::rgba(r, g, b, a));
    }

    let color = match s.to_ascii_lowercase().as_str() {
        "black" => Color::rgb(0, 0, 0),
        "white" => Color::rgb(255, 255, 255),
        "red" => Color::rgb(255, 0, 0),
        "green" => Color::rgb(0, 255, 0),
        "blue" => Color::rgb(0, 0, 255),
        "yellow" => Color::rgb(255, 255, 0),
        "cyan" => Color::rgb(0, 255, 255),
        "magenta" => Color::rgb(255, 0, 255),
        "gray" | "grey" => Color::rgb(128, 128, 128),
        "darkgray" | "darkgrey" => Color::rgb(64, 64, 64),
        "lightgray" | "lightgrey" => Color::rgb(192, 192, 192),
        "darkblue" => Color::rgb(0, 0, 139),
        "darkgreen" => Color::rgb(0, 100, 0),
        "darkcyan" => Color::rgb(0, 139, 139),
        "darkred" => Color::rgb(139, 0, 0),
        "darkmagenta" => Color::rgb(139, 0, 139),
        "lightblue" => Color::rgb(173, 216, 230),
        "lightgreen" => Color::rgb(144, 238, 144),
        "lightcyan" => Color::rgb(224, 255, 255),
        "lightred" => Color::rgb(255, 85, 85),
        "lightmagenta" => Color::rgb(255, 85, 255),
        "skyblue" => Color::rgb(135, 206, 235),
        "gold" => Color::rgb(255, 215, 0),
        "orange" => Color::rgb(255, 165, 0),
        "purple" => Color::rgb(128, 0, 128),
        "brown" => Color::rgb(165, 42, 42),
        "pink" => Color::rgb(255, 192, 203),
        "lime" => Color::rgb(0, 255, 0),
        "navy" => Color::rgb(0, 0, 128),
        "teal" => Color::rgb(0, 128, 128),
        "olive" => Color::rgb(128, 128, 0),
        "maroon" => Color::rgb(128, 0, 0),
        "aqua" => Color::rgb(0, 255, 255),
        "silver" => Color::rgb(192, 192, 192),
        "fuchsia" => Color::rgb(255, 0, 255),
        _ => return Err(Error::syntax(format!("invalid color {s}"))),
    };
    Ok(color)
}

// ── BlendMode ─────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum BlendMode {
    Normal,
    Multiply,
    Screen,
    Overlay,
    Darken,
    Lighten,
    Difference,
    Xor,
    Add,
    Exclusion,
    ColorDodge,
    ColorBurn,
    HardLight,
    SoftLight,
    Erase,
    Hue,
    Saturation,
    Color,
    Luminosity,
}

impl BlendMode {
    fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "normal" | "source-over" => Some(Self::Normal),
            "multiply" => Some(Self::Multiply),
            "screen" => Some(Self::Screen),
            "overlay" => Some(Self::Overlay),
            "darken" => Some(Self::Darken),
            "lighten" => Some(Self::Lighten),
            "difference" => Some(Self::Difference),
            "xor" => Some(Self::Xor),
            "add" | "lighter" | "plus-lighter" => Some(Self::Add),
            "exclusion" => Some(Self::Exclusion),
            "color-dodge" => Some(Self::ColorDodge),
            "color-burn" => Some(Self::ColorBurn),
            "hard-light" => Some(Self::HardLight),
            "soft-light" => Some(Self::SoftLight),
            "erase" => Some(Self::Erase),
            "hue" => Some(Self::Hue),
            "saturation" => Some(Self::Saturation),
            "color" => Some(Self::Color),
            "luminosity" | "luminance" => Some(Self::Luminosity),
            _ => None,
        }
    }

    fn to_svg_string(self) -> &'static str {
        match self {
            Self::Normal => "normal",
            Self::Multiply => "multiply",
            Self::Screen => "screen",
            Self::Overlay => "overlay",
            Self::Darken => "darken",
            Self::Lighten => "lighten",
            Self::Difference => "difference",
            Self::Xor => "xor",
            Self::Add => "plus-lighter",
            Self::Exclusion => "exclusion",
            Self::ColorDodge => "color-dodge",
            Self::ColorBurn => "color-burn",
            Self::HardLight => "hard-light",
            Self::SoftLight => "soft-light",
            Self::Erase => "erase",
            Self::Hue => "hue",
            Self::Saturation => "saturation",
            Self::Color => "color",
            Self::Luminosity => "luminosity",
        }
    }
}

// ── Style ─────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq)]
pub struct Style {
    pub fill: Option<Color>,
    pub stroke: Option<Color>,
    pub gradient_id: String,
    pub stroke_width: f64,
    pub opacity: f64,
    pub font_family: String,
    pub font_weight: String,
    pub font_style: String,
    pub text_align: String,
    pub text_baseline: String,
    pub letter_spacing: f64,
    pub fill_rule: String,
    pub pattern_id: String,
    pub composite: BlendMode,
}

impl Default for Style {
    fn default() -> Self {
        Self {
            fill: Some(Color::BLACK),
            stroke: None,
            gradient_id: String::new(),
            stroke_width: 1.0,
            opacity: 1.0,
            font_family: "monospace".to_string(),
            font_weight: "normal".to_string(),
            font_style: "normal".to_string(),
            text_align: "start".to_string(),
            text_baseline: "alphabetic".to_string(),
            letter_spacing: 0.0,
            fill_rule: "nonzero".to_string(),
            pattern_id: String::new(),
            composite: BlendMode::Normal,
        }
    }
}

// ── Shape types ───────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ShapeType {
    Line,
    Rect,
    Circle,
    Ellipse,
    Polygon,
    Polyline,
    Path,
    Text,
    Pixel,
    Bitmap,
    TexturePath,
    RasterFilter,
    FloodFill,
}

#[derive(Debug, Clone, PartialEq)]
pub struct PathCommand {
    pub op: char,
    pub values: Vec<f64>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct BitmapData {
    pub width: usize,
    pub height: usize,
    pub pixels: Arc<[Color]>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct BitmapFontData {
    pub bitmap: BitmapData,
    pub cell_width: usize,
    pub cell_height: usize,
    pub first_codepoint: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub struct BitmapWarp {
    pub angle: f64,
    pub bend: f64,
    pub turn: f64,
    pub aim: f64,
    pub light: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ClipRect {
    pub left: usize,
    pub top: usize,
    pub right: usize,
    pub bottom: usize,
}

#[derive(Debug, Clone, PartialEq)]
pub struct TexturePaint {
    pub seed: i64,
    pub scale: f64,
    pub octaves: u8,
    pub low: Color,
    pub high: Color,
}

#[derive(Debug, Clone, PartialEq)]
pub enum RasterFilter {
    Blur {
        radius: usize,
    },
    Sharpen {
        amount: f64,
    },
    Color {
        brightness: f64,
        contrast: f64,
        saturation: f64,
    },
}

fn sample_bitmap_bilinear(
    bitmap: &BitmapData,
    x: usize,
    y: usize,
    width: usize,
    height: usize,
) -> Color {
    let source_x = ((x as f64 + 0.5) * bitmap.width as f64 / width as f64 - 0.5)
        .clamp(0.0, (bitmap.width - 1) as f64);
    let source_y = ((y as f64 + 0.5) * bitmap.height as f64 / height as f64 - 0.5)
        .clamp(0.0, (bitmap.height - 1) as f64);
    sample_bitmap_at(bitmap, source_x, source_y)
}

fn sample_bitmap_uv(bitmap: &BitmapData, u: f64, v: f64) -> Color {
    sample_bitmap_at(
        bitmap,
        u.clamp(0.0, 1.0) * (bitmap.width - 1) as f64,
        v.clamp(0.0, 1.0) * (bitmap.height - 1) as f64,
    )
}

fn sample_bitmap_at(bitmap: &BitmapData, source_x: f64, source_y: f64) -> Color {
    let x0 = source_x.floor() as usize;
    let y0 = source_y.floor() as usize;
    let x1 = (x0 + 1).min(bitmap.width - 1);
    let y1 = (y0 + 1).min(bitmap.height - 1);
    let fx = source_x - x0 as f64;
    let fy = source_y - y0 as f64;
    let samples = [
        bitmap.pixels[y0 * bitmap.width + x0],
        bitmap.pixels[y0 * bitmap.width + x1],
        bitmap.pixels[y1 * bitmap.width + x0],
        bitmap.pixels[y1 * bitmap.width + x1],
    ];
    let weights = [
        (1.0 - fx) * (1.0 - fy),
        fx * (1.0 - fy),
        (1.0 - fx) * fy,
        fx * fy,
    ];
    let alpha = samples
        .iter()
        .zip(weights)
        .map(|(color, weight)| color.alpha_unit() * weight)
        .sum::<f64>();
    if alpha <= f64::EPSILON {
        return Color::TRANSPARENT;
    }
    let interpolate = |channel: fn(Color) -> u8| {
        let premultiplied = samples
            .iter()
            .zip(weights)
            .map(|(color, weight)| f64::from(channel(*color)) * color.alpha_unit() * weight)
            .sum::<f64>();
        (premultiplied / alpha).round().clamp(0.0, 255.0) as u8
    };
    Color::rgba(
        interpolate(|color| color.r),
        interpolate(|color| color.g),
        interpolate(|color| color.b),
        (alpha * 255.0).round().clamp(0.0, 255.0) as u8,
    )
}

fn tint_bitmap_color(color: Color, tint: Color) -> Color {
    let multiply =
        |channel: u8, tint: u8| ((u16::from(channel) * u16::from(tint) + 127) / 255) as u8;
    Color::rgba(
        multiply(color.r, tint.r),
        multiply(color.g, tint.g),
        multiply(color.b, tint.b),
        multiply(color.a, tint.a),
    )
}
#[derive(Debug, Clone, PartialEq)]
pub struct Shape {
    pub shape_type: ShapeType,
    pub style: Style,
    pub id: String,
    pub name: String,
    pub layer: String,
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub r: f64,
    pub rx: f64,
    pub ry: f64,
    pub font_size: f64,
    pub points: Vec<(f64, f64)>,
    pub path: Vec<PathCommand>,
    pub text: String,
    pub bitmap_warp: Option<BitmapWarp>,
    pub bitmap: Option<BitmapData>,
    pub bitmap_tint: Color,
    pub bitmap_font: Option<BitmapFontData>,
    pub texture: Option<TexturePaint>,
    pub raster_filter: Option<RasterFilter>,
    pub clip: Option<ClipRect>,
    pub device_space: bool,
}

impl Default for Shape {
    fn default() -> Self {
        Self {
            shape_type: ShapeType::Rect,
            style: Style::default(),
            id: String::new(),
            name: String::new(),
            layer: String::new(),
            x: 0.0,
            y: 0.0,
            w: 0.0,
            h: 0.0,
            r: 0.0,
            rx: 0.0,
            ry: 0.0,
            font_size: 16.0,
            points: Vec::new(),
            path: Vec::new(),
            text: String::new(),
            bitmap_warp: None,
            bitmap: None,
            bitmap_tint: Color::WHITE,
            bitmap_font: None,
            texture: None,
            raster_filter: None,
            clip: None,
            device_space: false,
        }
    }
}

// ── Gradient ──────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq)]
pub struct GradientDef {
    pub id: String,
    pub kind: String,
    pub x1: f64,
    pub y1: f64,
    pub x2: f64,
    pub y2: f64,
    pub fx: f64,
    pub fy: f64,
    pub r2: f64,
    pub stops: Vec<(f64, Color)>,
}

// ── Layer ─────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq)]
pub struct ShapeLayer {
    pub id: String,
    pub name: String,
    pub visible: bool,
    pub opacity: f64,
}

// ── Scene ─────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct Scene {
    pub width: u32,
    pub height: u32,
    pub background: Color,
    pub shapes: Vec<Shape>,
    pub gradients: Vec<GradientDef>,
    pub layers: Vec<ShapeLayer>,
    pub metadata: Vec<(String, String)>,
    pub notes: Vec<String>,
}

impl Default for Scene {
    fn default() -> Self {
        Self {
            width: 800,
            height: 600,
            background: Color::WHITE,
            shapes: Vec::new(),
            gradients: Vec::new(),
            layers: Vec::new(),
            metadata: Vec::new(),
            notes: Vec::new(),
        }
    }
}

struct RasterPrefixCache {
    width: u32,
    height: u32,
    background: Color,
    gradients: Vec<GradientDef>,
    layers: Vec<ShapeLayer>,
    shapes: Vec<Shape>,
    prefix_len: usize,
    pixels: Vec<RasterPixel>,
}

#[derive(Default)]
struct BitmapTextureCache {
    images: HashMap<String, BitmapData>,
    bytes: usize,
}

thread_local! {
    static RASTER_PREFIX_CACHE: RefCell<Option<RasterPrefixCache>> = const { RefCell::new(None) };
    static BITMAP_TEXTURE_CACHE: RefCell<BitmapTextureCache> = RefCell::new(BitmapTextureCache::default());
}

#[cfg(test)]
fn clear_raster_prefix_cache() {
    RASTER_PREFIX_CACHE.with(|cache| *cache.borrow_mut() = None);
}

#[cfg(test)]
fn retained_raster_prefix_len() -> usize {
    RASTER_PREFIX_CACHE.with(|cache| {
        cache
            .borrow()
            .as_ref()
            .map_or(0, |retained| retained.prefix_len)
    })
}

// ── Public API ────────────────────────────────────────────────────

pub fn render_svg(source: &str) -> Result<String, Error> {
    let scene = parse_scene(source)?;
    if scene
        .shapes
        .iter()
        .any(|shape| shape.shape_type == ShapeType::FloodFill)
    {
        checked_raster_pixel_count(scene.width, scene.height)?;
    }
    Ok(scene_to_svg(&scene))
}

pub fn render_ppm(source: &str) -> Result<Vec<u8>, Error> {
    let scene = parse_scene(source)?;
    scene_to_ppm(&scene)
}

// ── SVG renderer ──────────────────────────────────────────────────

fn scene_to_svg(scene: &Scene) -> String {
    let mut out = String::with_capacity(4096);
    let _ = writeln!(out, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    let _ = writeln!(
        out,
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{}\" height=\"{}\" viewBox=\"0 0 {} {}\">",
        scene.width, scene.height, scene.width, scene.height
    );
    let _ = writeln!(out, "  <defs>");

    // Gradients
    for grad in &scene.gradients {
        if grad.kind == "radial" {
            let _ = writeln!(
                out,
                "    <radialGradient id=\"{}\" cx=\"{}\" cy=\"{}\" fx=\"{}\" fy=\"{}\" r=\"{}\">",
                xml_escape(&grad.id),
                fmt(grad.x1),
                fmt(grad.y1),
                fmt(grad.fx),
                fmt(grad.fy),
                fmt(grad.r2)
            );
        } else {
            let _ = writeln!(
                out,
                "    <linearGradient id=\"{}\" x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\">",
                xml_escape(&grad.id),
                fmt(grad.x1),
                fmt(grad.y1),
                fmt(grad.x2),
                fmt(grad.y2)
            );
        }
        for (offset, color) in &grad.stops {
            let _ = writeln!(
                out,
                "      <stop offset=\"{}\" stop-color=\"{}\"/>",
                fmt(*offset),
                color.to_svg()
            );
        }
        let tag = if grad.kind == "radial" {
            "radialGradient"
        } else {
            "linearGradient"
        };
        let _ = writeln!(out, "    </{}>", tag);
    }

    let _ = writeln!(out, "  </defs>");

    // Background
    let _ = write!(
        out,
        "  <rect width=\"100%\" height=\"100%\" fill=\"{}\"",
        scene.background.to_svg()
    );
    if scene.background.a < 255 {
        let _ = write!(
            out,
            " fill-opacity=\"{}\"",
            fmt(scene.background.alpha_unit())
        );
    }
    let _ = writeln!(out, "/>");

    // Metadata
    for (key, value) in &scene.metadata {
        let _ = writeln!(
            out,
            "  <metadata data-key=\"{}\">{}</metadata>",
            xml_escape(key),
            xml_escape(value)
        );
    }
    for note in &scene.notes {
        let _ = writeln!(out, "  <!-- {} -->", xml_comment_escape(note));
    }

    // Flood fill depends on the pixels produced by preceding shapes. Keep a
    // lightweight raster alongside SVG generation only when the scene
    // contains a flood command; each filled pixel run is emitted as a compact
    // SVG path at the command's original z-order.
    let mut flood_framebuffer = scene
        .shapes
        .iter()
        .any(|shape| shape.shape_type == ShapeType::FloodFill)
        .then(|| {
            vec![
                (
                    scene.background.r as f32,
                    scene.background.g as f32,
                    scene.background.b as f32,
                );
                scene.width as usize * scene.height as usize
            ]
        });

    // Shapes
    for shape in &scene.shapes {
        // Check layer visibility
        if !shape.layer.is_empty() {
            if let Some(layer) = scene.layers.iter().find(|l| l.id == shape.layer) {
                if !layer.visible {
                    continue;
                }
            }
        }
        let layer_opacity = if shape.layer.is_empty() {
            1.0
        } else {
            scene
                .layers
                .iter()
                .find(|layer| layer.id == shape.layer)
                .map(|layer| layer.opacity)
                .unwrap_or(1.0)
        };
        let total_opacity = shape.style.opacity * layer_opacity;
        if let Some(framebuffer) = flood_framebuffer.as_mut() {
            if shape.shape_type == ShapeType::FloodFill {
                let changed = flood_fill_pixels(
                    framebuffer,
                    scene.width as usize,
                    scene.height as usize,
                    shape,
                    total_opacity,
                );
                append_flood_svg(
                    &mut out,
                    &changed,
                    scene.width as usize,
                    shape.style.fill.unwrap_or(Color::TRANSPARENT),
                    total_opacity,
                );
                continue;
            }
            rasterize_shape(
                framebuffer,
                scene.width as usize,
                scene.height as usize,
                shape,
                total_opacity,
                &scene.gradients,
            );
        }
        if layer_opacity == 1.0 {
            shape_to_svg(shape, &mut out);
        } else {
            let mut layered = shape.clone();
            layered.style.opacity = total_opacity;
            shape_to_svg(&layered, &mut out);
        }
    }

    let _ = writeln!(out, "</svg>");
    out
}

fn shape_to_svg(shape: &Shape, out: &mut String) {
    let style = &shape.style;
    match shape.shape_type {
        ShapeType::Line => {
            if shape.points.len() >= 2 {
                if shape.points.len() == 2 {
                    let _ = write!(
                        out,
                        "  <line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\"",
                        fmt(shape.points[0].0),
                        fmt(shape.points[0].1),
                        fmt(shape.points[1].0),
                        fmt(shape.points[1].1)
                    );
                } else {
                    let _ = write!(out, "  <polyline points=\"");
                    for (i, (px, py)) in shape.points.iter().enumerate() {
                        if i > 0 {
                            let _ = write!(out, " ");
                        }
                        let _ = write!(out, "{},{}", fmt(*px), fmt(*py));
                    }
                    let _ = write!(out, "\"");
                }
                append_style_svg(out, style);
                let _ = writeln!(out, "/>");
            }
        }
        ShapeType::Rect => {
            let _ = write!(
                out,
                "  <rect x=\"{}\" y=\"{}\" width=\"{}\" height=\"{}\"",
                fmt(shape.x),
                fmt(shape.y),
                fmt(shape.w),
                fmt(shape.h)
            );
            if shape.rx > 0.0 {
                let _ = write!(out, " rx=\"{}\"", fmt(shape.rx));
            }
            append_style_svg(out, style);
            let _ = writeln!(out, "/>");
        }
        ShapeType::Circle => {
            let _ = write!(
                out,
                "  <circle cx=\"{}\" cy=\"{}\" r=\"{}\"",
                fmt(shape.x),
                fmt(shape.y),
                fmt(shape.r)
            );
            append_style_svg(out, style);
            let _ = writeln!(out, "/>");
        }
        ShapeType::Ellipse => {
            let _ = write!(
                out,
                "  <ellipse cx=\"{}\" cy=\"{}\" rx=\"{}\" ry=\"{}\"",
                fmt(shape.x),
                fmt(shape.y),
                fmt(shape.rx),
                fmt(shape.ry)
            );
            append_style_svg(out, style);
            let _ = writeln!(out, "/>");
        }
        ShapeType::Polygon => {
            let _ = write!(out, "  <polygon points=\"");
            for (px, py) in &shape.points {
                let _ = write!(out, "{},{} ", fmt(*px), fmt(*py));
            }
            let _ = write!(out, "\"");
            append_style_svg(out, style);
            let _ = writeln!(out, "/>");
        }
        ShapeType::Polyline => {
            let _ = write!(out, "  <polyline points=\"");
            for (px, py) in &shape.points {
                let _ = write!(out, "{},{} ", fmt(*px), fmt(*py));
            }
            let _ = write!(out, "\" fill=\"none\"");
            append_style_svg(out, style);
            let _ = writeln!(out, "/>");
        }
        ShapeType::Path => {
            let path_data = path_commands_to_svg(&shape.path);
            let _ = write!(out, "  <path d=\"{}\"", xml_escape(&path_data));
            append_style_svg(out, style);
            let _ = writeln!(out, "/>");
        }
        ShapeType::Text => {
            let _ = write!(
                out,
                "  <text x=\"{}\" y=\"{}\" font-size=\"{}\" font-family=\"{}\"",
                fmt(shape.x),
                fmt(shape.y),
                fmt(shape.font_size),
                xml_escape(&style.font_family)
            );
            // Text alignment
            match style.text_align.as_str() {
                "middle" | "center" => {
                    let _ = write!(out, " text-anchor=\"middle\"");
                }
                "end" | "right" => {
                    let _ = write!(out, " text-anchor=\"end\"");
                }
                _ => {
                    let _ = write!(out, " text-anchor=\"start\"");
                }
            }
            match style.text_baseline.as_str() {
                "middle" => {
                    let _ = write!(out, " dominant-baseline=\"middle\"");
                }
                "hanging" => {
                    let _ = write!(out, " dominant-baseline=\"hanging\"");
                }
                _ => {}
            }
            append_style_svg(out, style);
            let _ = writeln!(out, ">{}</text>", xml_escape(&shape.text));
        }
        ShapeType::Pixel => {
            let _ = write!(
                out,
                "  <rect x=\"{}\" y=\"{}\" width=\"1\" height=\"1\"",
                fmt(shape.x - 0.5),
                fmt(shape.y - 0.5)
            );
            append_style_svg(out, style);
            let _ = writeln!(out, "/>");
        }
        ShapeType::Bitmap | ShapeType::TexturePath | ShapeType::RasterFilter => {}
        ShapeType::FloodFill => {}
    }
}

fn append_flood_svg(out: &mut String, changed: &[usize], width: usize, fill: Color, opacity: f64) {
    let alpha = (fill.alpha_unit() * opacity).clamp(0.0, 1.0);
    if changed.is_empty() || width == 0 || alpha == 0.0 {
        return;
    }

    let mut pixels = changed.to_vec();
    pixels.sort_unstable();
    let _ = write!(out, "  <path d=\"");
    let mut start = pixels[0];
    let mut previous = start;
    for &pixel in pixels.iter().skip(1).chain(std::iter::once(&usize::MAX)) {
        let same_row = pixel != usize::MAX && pixel / width == previous / width;
        if pixel == previous.saturating_add(1) && same_row {
            previous = pixel;
            continue;
        }
        let x = start % width;
        let y = start / width;
        let length = previous - start + 1;
        let _ = write!(out, "M{x} {y}h{length}v1h-{length}z");
        start = pixel;
        previous = pixel;
    }
    let _ = write!(
        out,
        "\" fill=\"#{:02x}{:02x}{:02x}\"",
        fill.r, fill.g, fill.b
    );
    if alpha < 1.0 {
        let _ = write!(out, " fill-opacity=\"{}\"", fmt(alpha));
    }
    let _ = writeln!(out, "/>");
}

fn append_style_svg(out: &mut String, style: &Style) {
    // Fill
    if !style.gradient_id.is_empty() {
        let _ = write!(out, " fill=\"url(#{})\"", xml_escape(&style.gradient_id));
    } else if let Some(fill) = style.fill {
        let _ = write!(out, " fill=\"{}\"", fill.to_svg());
        let alpha = fill.alpha_unit();
        if alpha < 1.0 {
            let _ = write!(out, " fill-opacity=\"{}\"", fmt(alpha));
        }
    } else {
        let _ = write!(out, " fill=\"none\"");
    }

    // Stroke
    if let Some(stroke) = style.stroke {
        let _ = write!(out, " stroke=\"{}\"", stroke.to_svg());
        let _ = write!(out, " stroke-width=\"{}\"", fmt(style.stroke_width));
        let _ = write!(out, " stroke-linecap=\"round\" stroke-linejoin=\"round\"");
        let alpha = stroke.alpha_unit();
        if alpha < 1.0 {
            let _ = write!(out, " stroke-opacity=\"{}\"", fmt(alpha));
        }
    } else {
        let _ = write!(out, " stroke=\"none\"");
    }

    // Fill rule
    if style.fill_rule == "evenodd" {
        let _ = write!(out, " fill-rule=\"evenodd\"");
    }

    // Opacity
    if style.opacity < 1.0 {
        let _ = write!(out, " opacity=\"{}\"", fmt(style.opacity));
    }

    // Blend mode
    if style.composite != BlendMode::Normal
        && style.composite != BlendMode::Xor
        && style.composite != BlendMode::Erase
    {
        let _ = write!(
            out,
            " style=\"mix-blend-mode:{}\"",
            style.composite.to_svg_string()
        );
    }
}

fn path_commands_to_svg(path: &[PathCommand]) -> String {
    let mut out = String::new();
    for cmd in path {
        let _ = write!(out, "{}", cmd.op);
        for (i, v) in cmd.values.iter().enumerate() {
            if i > 0 && (cmd.op == 'M' || cmd.op == 'L' || cmd.op == 'C' || cmd.op == 'Q') {
                let _ = write!(out, " ");
            }
            let _ = write!(out, "{}", fmt(*v));
            if (cmd.op == 'C' || cmd.op == 'Q') && (i + 1) % 2 == 0 && i + 1 < cmd.values.len() {
                let _ = write!(out, " ");
            }
        }
    }
    out
}

// ── PPM rasterizer ────────────────────────────────────────────────

fn scene_to_ppm(scene: &Scene) -> Result<Vec<u8>, Error> {
    let width = scene.width as usize;
    let height = scene.height as usize;
    if width == 0 || height == 0 || width > 65535 || height > 65535 {
        return Err(Error::IllegalQuantity);
    }
    let pixel_count = checked_raster_pixel_count(scene.width, scene.height)?;

    let cacheable = pixel_count
        .checked_mul(std::mem::size_of::<RasterPixel>())
        .is_some_and(|bytes| bytes <= MAX_RASTER_PREFIX_CACHE_BYTES);
    let previous_cache = if cacheable {
        RASTER_PREFIX_CACHE.with(|cache| cache.borrow_mut().take())
    } else {
        RASTER_PREFIX_CACHE.with(|cache| *cache.borrow_mut() = None);
        None
    };
    let mut reusable_prefix = 0;
    let mut next_prefix = 0;
    let mut retained_prefix_pixels = None;
    if let Some(previous) = previous_cache {
        if previous.width == scene.width
            && previous.height == scene.height
            && previous.background == scene.background
            && previous.gradients == scene.gradients
            && previous.layers == scene.layers
        {
            next_prefix = previous
                .shapes
                .iter()
                .zip(&scene.shapes)
                .take_while(|(left, right)| left == right)
                .count();
            if previous.prefix_len > 0
                && previous.prefix_len <= next_prefix
                && previous.pixels.len() == pixel_count
            {
                reusable_prefix = previous.prefix_len;
                retained_prefix_pixels = Some(previous.pixels);
            }
        }
    }

    // Framebuffer with alpha-aware compositing. An exact retained prefix can
    // seed it after the first two matching frames; all other scenes start from
    // their canvas color as before.
    let mut fb: Vec<RasterPixel> = vec![
        (
            scene.background.r as f32,
            scene.background.g as f32,
            scene.background.b as f32,
        );
        pixel_count
    ];
    if let Some(pixels) = &retained_prefix_pixels {
        fb.copy_from_slice(pixels);
    }
    let mut captured_prefix = if reusable_prefix > 0 && reusable_prefix == next_prefix {
        retained_prefix_pixels.take()
    } else {
        None
    };

    // Render shapes
    for (shape_index, shape) in scene.shapes.iter().enumerate().skip(reusable_prefix) {
        rasterize_scene_shape_clipped(&mut fb, width, height, shape, scene);
        if shape_index + 1 == next_prefix {
            captured_prefix = Some(fb.clone());
        }
    }

    if cacheable {
        let (prefix_len, pixels) = captured_prefix
            .map(|pixels| (next_prefix, pixels))
            .unwrap_or_else(|| (0, Vec::new()));
        RASTER_PREFIX_CACHE.with(|cache| {
            *cache.borrow_mut() = Some(RasterPrefixCache {
                width: scene.width,
                height: scene.height,
                background: scene.background,
                gradients: scene.gradients.clone(),
                layers: scene.layers.clone(),
                shapes: scene.shapes.clone(),
                prefix_len,
                pixels,
            });
        });
    }

    // Convert to PPM P6
    let mut ppm = Vec::with_capacity(pixel_count * 3 + 64);
    ppm.extend_from_slice(b"P6\n");
    ppm.extend_from_slice(format!("{} {}\n", width, height).as_bytes());
    ppm.extend_from_slice(b"255\n");
    let raster_start = ppm.len();
    ppm.resize(raster_start + pixel_count * 3, 0);
    pack_raster_rgb(&fb, &mut ppm[raster_start..], height);
    Ok(ppm)
}

fn rasterize_scene_shape_clipped(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    scene: &Scene,
) {
    let Some(clip) = shape.clip else {
        rasterize_scene_shape(framebuffer, width, height, shape, scene);
        return;
    };
    // Artist's integrated-text compatibility guard is a transparent clipped
    // rectangle. It intentionally changes no pixels, so do not clone an
    // entire HD framebuffer before discovering that in rasterize_shape().
    if shape.shape_type == ShapeType::Rect
        && shape.style.gradient_id.is_empty()
        && shape.style.fill.map_or(true, |fill| fill.a == 0)
        && shape.style.stroke.map_or(true, |stroke| stroke.a == 0)
    {
        return;
    }
    if width == 0 || height == 0 || clip.left >= width || clip.top >= height {
        return;
    }
    let mut clipped = framebuffer.to_vec();
    rasterize_scene_shape(&mut clipped, width, height, shape, scene);
    let right = clip.right.min(width - 1);
    let bottom = clip.bottom.min(height - 1);
    for y in clip.top..=bottom {
        let row = y * width;
        framebuffer[row + clip.left..=row + right]
            .copy_from_slice(&clipped[row + clip.left..=row + right]);
    }
}

fn pack_raster_rgb(pixels: &[RasterPixel], output: &mut [u8], row_count: usize) {
    debug_assert_eq!(output.len(), pixels.len() * 3);
    let workers = raster_worker_count(pixels.len(), row_count);
    if workers == 1 {
        pack_raster_rgb_chunk(pixels, output);
        return;
    }

    let pixels_per_worker = pixels.len().div_ceil(workers);
    std::thread::scope(|scope| {
        let mut remaining_pixels = pixels;
        let mut remaining_output = output;
        while !remaining_pixels.is_empty() {
            let count = remaining_pixels.len().min(pixels_per_worker);
            let (worker_pixels, rest_pixels) = remaining_pixels.split_at(count);
            let (worker_output, rest_output) = remaining_output.split_at_mut(count * 3);
            scope.spawn(move || pack_raster_rgb_chunk(worker_pixels, worker_output));
            remaining_pixels = rest_pixels;
            remaining_output = rest_output;
        }
    });
}

fn pack_raster_rgb_chunk(pixels: &[RasterPixel], output: &mut [u8]) {
    for (&(red, green, blue), rgb) in pixels.iter().zip(output.chunks_exact_mut(3)) {
        rgb[0] = red.round().clamp(0.0, 255.0) as u8;
        rgb[1] = green.round().clamp(0.0, 255.0) as u8;
        rgb[2] = blue.round().clamp(0.0, 255.0) as u8;
    }
}

fn rasterize_scene_shape(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    scene: &Scene,
) {
    if !shape.layer.is_empty()
        && scene
            .layers
            .iter()
            .find(|layer| layer.id == shape.layer)
            .is_some_and(|layer| !layer.visible)
    {
        return;
    }
    let layer_opacity = if shape.layer.is_empty() {
        1.0
    } else {
        scene
            .layers
            .iter()
            .find(|layer| layer.id == shape.layer)
            .map(|layer| layer.opacity)
            .unwrap_or(1.0)
    };
    let total_opacity = shape.style.opacity * layer_opacity;
    if rasterize_parallel_fill_shape(
        framebuffer,
        width,
        height,
        shape,
        total_opacity,
        &scene.gradients,
    ) {
        return;
    }
    if shape.style.composite == BlendMode::Normal {
        rasterize_shape(
            framebuffer,
            width,
            height,
            shape,
            total_opacity,
            &scene.gradients,
        );
    } else {
        rasterize_composited_shape(
            framebuffer,
            width,
            height,
            shape,
            total_opacity,
            &scene.gradients,
            scene.background,
        );
    }
}

fn checked_raster_pixel_count(width: u32, height: u32) -> Result<usize, Error> {
    let pixels = (width as usize)
        .checked_mul(height as usize)
        .ok_or(Error::IllegalQuantity)?;
    if pixels > MAX_ARTIST_PIXELS {
        Err(Error::IllegalQuantity)
    } else {
        Ok(pixels)
    }
}

fn blend_pixel(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    x: i32,
    y: i32,
    r: f64,
    g: f64,
    b: f64,
    alpha: f64,
) {
    if x < 0 || (x as usize) >= width || y < 0 || (y as usize) >= height {
        return;
    }
    let idx = (y as usize) * width + (x as usize);
    let (old_r, old_g, old_b) = fb[idx];
    let a = alpha.clamp(0.0, 1.0);
    fb[idx] = (
        (old_r as f64 * (1.0 - a) + r * a) as f32,
        (old_g as f64 * (1.0 - a) + g * a) as f32,
        (old_b as f64 * (1.0 - a) + b * a) as f32,
    );
}

fn blend_paint_pixel(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    x: i32,
    y: i32,
    fallback: Color,
    opacity: f64,
    gradient: Option<&GradientDef>,
) {
    if opacity <= 0.0 {
        return;
    }
    let color = gradient
        .map(|gradient| sample_gradient_at(gradient, x as f64 + 0.5, y as f64 + 0.5))
        .unwrap_or(fallback);
    blend_pixel(
        fb,
        width,
        height,
        x,
        y,
        color.r as f64,
        color.g as f64,
        color.b as f64,
        color.alpha_unit() * opacity,
    );
}

fn sample_gradient_at(gradient: &GradientDef, x: f64, y: f64) -> Color {
    let t = if gradient.kind == "radial" {
        let radius = gradient.r2.abs();
        if radius <= f64::EPSILON {
            0.0
        } else {
            ((x - gradient.fx).powi(2) + (y - gradient.fy).powi(2)).sqrt() / radius
        }
    } else {
        let dx = gradient.x2 - gradient.x1;
        let dy = gradient.y2 - gradient.y1;
        let length_squared = dx * dx + dy * dy;
        if length_squared <= f64::EPSILON {
            0.0
        } else {
            ((x - gradient.x1) * dx + (y - gradient.y1) * dy) / length_squared
        }
    };
    sample_gradient(&gradient.stops, t)
}

fn rounded_rect_signed_distance(
    px: f64,
    py: f64,
    x: f64,
    y: f64,
    width: f64,
    height: f64,
    radius: f64,
) -> f64 {
    let half_width = width * 0.5;
    let half_height = height * 0.5;
    let qx = (px - (x + half_width)).abs() - (half_width - radius);
    let qy = (py - (y + half_height)).abs() - (half_height - radius);
    let outside = qx.max(0.0).hypot(qy.max(0.0));
    outside + qx.max(qy).min(0.0) - radius
}

/// Render the large, fill-only primitives used for backgrounds and lighting
/// directly into independent framebuffer rows. The general compositing path
/// reconstructs source alpha by drawing onto black and white temporary images;
/// that is useful for arbitrary shapes, but it needlessly allocates and scans
/// two extra Full-HD buffers for a rectangle or ellipse whose coverage and
/// paint are already known analytically.
fn rasterize_parallel_fill_shape(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    opacity: f64,
    gradients: &[GradientDef],
) -> bool {
    let gradient = gradients
        .iter()
        .find(|gradient| gradient.id == shape.style.gradient_id);
    let fill = shape.style.fill.unwrap_or(Color::TRANSPARENT);
    let has_fill = gradient.is_some() || (shape.style.fill.is_some() && fill.a > 0);
    let has_stroke = shape.style.stroke.is_some()
        && shape.style.stroke_width > 0.0
        && shape.style.stroke.is_some_and(|stroke| stroke.a > 0);
    if !has_fill || has_stroke || opacity <= 0.0 || shape.style.composite == BlendMode::Erase {
        return false;
    }

    match shape.shape_type {
        ShapeType::Rect if shape.rx <= f64::EPSILON => {
            rasterize_parallel_rect_fill(
                framebuffer,
                width,
                height,
                shape,
                opacity,
                gradient,
                fill,
            );
            true
        }
        ShapeType::Ellipse if shape.rx > 0.0 && shape.ry > 0.0 => {
            rasterize_parallel_ellipse_fill(
                framebuffer,
                width,
                height,
                shape,
                opacity,
                gradient,
                fill,
            );
            true
        }
        _ => false,
    }
}

fn raster_worker_count(pixel_count: usize, row_count: usize) -> usize {
    if pixel_count < MIN_PARALLEL_RASTER_PIXELS || row_count < 2 {
        return 1;
    }
    std::thread::available_parallelism()
        .map(usize::from)
        .unwrap_or(1)
        .min(8)
        .min(row_count)
}

fn blend_pixel_value(pixel: &mut RasterPixel, mode: BlendMode, color: Color, alpha: f64) {
    let alpha = (color.alpha_unit() * alpha).clamp(0.0, 1.0);
    if alpha <= 0.0 {
        return;
    }
    if mode == BlendMode::Normal && alpha >= 1.0 {
        *pixel = (color.r as f32, color.g as f32, color.b as f32);
        return;
    }
    let blended = blend_with_mode(
        mode,
        color.r as f64,
        color.g as f64,
        color.b as f64,
        pixel.0 as f64,
        pixel.1 as f64,
        pixel.2 as f64,
        alpha,
    );
    *pixel = (blended.0 as f32, blended.1 as f32, blended.2 as f32);
}

#[allow(clippy::too_many_arguments)]
fn rasterize_parallel_rect_fill(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    opacity: f64,
    gradient: Option<&GradientDef>,
    fill: Color,
) {
    let left = shape.x.min(shape.x + shape.w);
    let right = shape.x.max(shape.x + shape.w);
    let top = shape.y.min(shape.y + shape.h);
    let bottom = shape.y.max(shape.y + shape.h);
    let x_start = (left.floor() as i32).clamp(0, width as i32) as usize;
    let x_end = (right.ceil() as i32).clamp(0, width as i32) as usize;
    let y_start = (top.floor() as i32).clamp(0, height as i32) as usize;
    let y_end = (bottom.ceil() as i32).clamp(0, height as i32) as usize;
    if x_start >= x_end || y_start >= y_end {
        return;
    }

    let rows = y_end - y_start;
    let workers = raster_worker_count((x_end - x_start) * rows, rows);
    let rows_per_worker = rows.div_ceil(workers);
    let mode = shape.style.composite;
    let active = &mut framebuffer[y_start * width..y_end * width];
    let render_rows = |pixels: &mut [RasterPixel], chunk_y: usize| {
        for (row_offset, row) in pixels.chunks_mut(width).enumerate() {
            let y = chunk_y + row_offset;
            let y_coverage = ((y as f64 + 1.0).min(bottom) - (y as f64).max(top)).clamp(0.0, 1.0);
            for (x, pixel) in row.iter_mut().enumerate().take(x_end).skip(x_start) {
                let coverage = (((x as f64 + 1.0).min(right) - (x as f64).max(left))
                    .clamp(0.0, 1.0))
                    * y_coverage;
                let color = gradient
                    .map(|gradient| sample_gradient_at(gradient, x as f64 + 0.5, y as f64 + 0.5))
                    .unwrap_or(fill);
                blend_pixel_value(pixel, mode, color, opacity * coverage);
            }
        }
    };
    if workers == 1 {
        render_rows(active, y_start);
        return;
    }
    std::thread::scope(|scope| {
        for (chunk_index, chunk) in active.chunks_mut(rows_per_worker * width).enumerate() {
            let render_rows = &render_rows;
            let chunk_y = y_start + chunk_index * rows_per_worker;
            scope.spawn(move || render_rows(chunk, chunk_y));
        }
    });
}

#[allow(clippy::too_many_arguments)]
fn rasterize_parallel_ellipse_fill(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    opacity: f64,
    gradient: Option<&GradientDef>,
    fill: Color,
) {
    let x_start = ((shape.x - shape.rx).floor() as i32 - 1).clamp(0, width as i32) as usize;
    let x_end = ((shape.x + shape.rx).ceil() as i32 + 1).clamp(0, width as i32) as usize;
    let y_start = ((shape.y - shape.ry).floor() as i32 - 1).clamp(0, height as i32) as usize;
    let y_end = ((shape.y + shape.ry).ceil() as i32 + 1).clamp(0, height as i32) as usize;
    if x_start >= x_end || y_start >= y_end {
        return;
    }

    let rows = y_end - y_start;
    let workers = raster_worker_count((x_end - x_start) * rows, rows);
    let rows_per_worker = rows.div_ceil(workers);
    let mode = shape.style.composite;
    let active = &mut framebuffer[y_start * width..y_end * width];
    let render_rows = |pixels: &mut [RasterPixel], chunk_y: usize| {
        for (row_offset, row) in pixels.chunks_mut(width).enumerate() {
            let y = chunk_y + row_offset;
            for (x, pixel) in row.iter_mut().enumerate().take(x_end).skip(x_start) {
                let ex = (x as f64 + 0.5 - shape.x) / shape.rx;
                let ey = (y as f64 + 0.5 - shape.y) / shape.ry;
                let signed_distance = ((ex * ex + ey * ey).sqrt() - 1.0) * shape.rx.min(shape.ry);
                let coverage = (0.5 - signed_distance).clamp(0.0, 1.0);
                if coverage <= 0.0 {
                    continue;
                }
                let color = gradient
                    .map(|gradient| sample_gradient_at(gradient, x as f64 + 0.5, y as f64 + 0.5))
                    .unwrap_or(fill);
                blend_pixel_value(pixel, mode, color, opacity * coverage);
            }
        }
    };
    if workers == 1 {
        render_rows(active, y_start);
        return;
    }
    std::thread::scope(|scope| {
        for (chunk_index, chunk) in active.chunks_mut(rows_per_worker * width).enumerate() {
            let render_rows = &render_rows;
            let chunk_y = y_start + chunk_index * rows_per_worker;
            scope.spawn(move || render_rows(chunk, chunk_y));
        }
    });
}

fn rasterize_composited_shape(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    opacity: f64,
    gradients: &[GradientDef],
    background: Color,
) {
    let Some((left, top, right, bottom)) = shape_raster_bounds(shape, width, height) else {
        return;
    };
    let local_width = (right - left) as usize;
    let local_height = (bottom - top) as usize;
    let mut local_shape = shape.clone();
    apply_transform(
        &mut local_shape,
        Affine2D {
            e: -(left as f64),
            f: -(top as f64),
            ..Default::default()
        },
    );
    let local_gradients = gradients
        .iter()
        .cloned()
        .map(|mut gradient| {
            gradient.x1 -= left as f64;
            gradient.y1 -= top as f64;
            gradient.x2 -= left as f64;
            gradient.y2 -= top as f64;
            gradient.fx -= left as f64;
            gradient.fy -= top as f64;
            gradient
        })
        .collect::<Vec<_>>();

    let local_pixels = local_width * local_height;
    let mut black = vec![(0.0, 0.0, 0.0); local_pixels];
    let mut white = vec![(255.0, 255.0, 255.0); local_pixels];
    rasterize_shape(
        &mut black,
        local_width,
        local_height,
        &local_shape,
        opacity,
        &local_gradients,
    );
    rasterize_shape(
        &mut white,
        local_width,
        local_height,
        &local_shape,
        opacity,
        &local_gradients,
    );

    for index in 0..local_pixels {
        let remaining = (((white[index].0 - black[index].0) as f64
            + (white[index].1 - black[index].1) as f64
            + (white[index].2 - black[index].2) as f64)
            / (3.0 * 255.0))
            .clamp(0.0, 1.0);
        let alpha = 1.0 - remaining;
        if alpha <= 1e-9 {
            continue;
        }
        let source = (
            (black[index].0 as f64 / alpha).clamp(0.0, 255.0),
            (black[index].1 as f64 / alpha).clamp(0.0, 255.0),
            (black[index].2 as f64 / alpha).clamp(0.0, 255.0),
        );
        let local_x = index % local_width;
        let local_y = index / local_width;
        let framebuffer_index = (top as usize + local_y) * width + left as usize + local_x;
        let destination = framebuffer[framebuffer_index];
        let blended = if shape.style.composite == BlendMode::Erase {
            (
                destination.0 as f64 * (1.0 - alpha) + background.r as f64 * alpha,
                destination.1 as f64 * (1.0 - alpha) + background.g as f64 * alpha,
                destination.2 as f64 * (1.0 - alpha) + background.b as f64 * alpha,
            )
        } else {
            blend_with_mode(
                shape.style.composite,
                source.0,
                source.1,
                source.2,
                destination.0 as f64,
                destination.1 as f64,
                destination.2 as f64,
                alpha,
            )
        };
        framebuffer[framebuffer_index] = (blended.0 as f32, blended.1 as f32, blended.2 as f32);
    }
}

fn warped_bitmap_point(shape: &Shape, u: f64, v: f64) -> (f64, f64) {
    let warp = shape
        .bitmap_warp
        .as_ref()
        .expect("warped bitmap point requires warp state");
    let distance_from_stem = 1.0 - v;
    let turn_angle = warp.turn * std::f64::consts::FRAC_PI_2 * (0.2 + 0.8 * distance_from_stem);
    let aim_facing = (1.0 + warp.aim * warp.aim).sqrt().recip();
    let facing = (turn_angle.cos().abs() * aim_facing).max(0.06);
    let across = (u - 0.5) * shape.w;
    let local_x = across * facing
        + warp.aim * shape.h * distance_from_stem
        + warp.bend * shape.h * 0.28 * distance_from_stem * distance_from_stem;
    let local_y = -distance_from_stem * shape.h
        + across * turn_angle.sin() * 0.32
        + warp.bend.abs() * shape.h * 0.04 * distance_from_stem * distance_from_stem;
    let angle = warp.angle.to_radians();
    let cosine = angle.cos();
    let sine = angle.sin();
    (
        shape.x + local_x * cosine - local_y * sine,
        shape.y + local_x * sine + local_y * cosine,
    )
}

fn warped_bitmap_bounds(shape: &Shape) -> Option<(f64, f64, f64, f64)> {
    let warp = shape.bitmap_warp.as_ref()?;
    if warp.bend == 0.0 && warp.turn == 0.0 {
        let points = [
            warped_bitmap_point(shape, 0.0, 0.0),
            warped_bitmap_point(shape, 1.0, 0.0),
            warped_bitmap_point(shape, 0.0, 1.0),
            warped_bitmap_point(shape, 1.0, 1.0),
        ];
        return point_bounds(&points);
    }
    const COLUMNS: usize = 12;
    const ROWS: usize = 32;
    let mut points = Vec::with_capacity((COLUMNS + 1) * (ROWS + 1));
    for row in 0..=ROWS {
        for column in 0..=COLUMNS {
            points.push(warped_bitmap_point(
                shape,
                column as f64 / COLUMNS as f64,
                row as f64 / ROWS as f64,
            ));
        }
    }
    point_bounds(&points)
}

fn shape_raster_bounds(shape: &Shape, width: usize, height: usize) -> Option<(i32, i32, i32, i32)> {
    let (mut left, mut top, mut right, mut bottom) = match shape.shape_type {
        ShapeType::Rect => (shape.x, shape.y, shape.x + shape.w, shape.y + shape.h),
        ShapeType::Bitmap => {
            if shape.bitmap_warp.is_some() {
                warped_bitmap_bounds(shape)?
            } else {
                (shape.x, shape.y, shape.x + shape.w, shape.y + shape.h)
            }
        }
        ShapeType::Circle => (
            shape.x - shape.r,
            shape.y - shape.r,
            shape.x + shape.r,
            shape.y + shape.r,
        ),
        ShapeType::Ellipse => (
            shape.x - shape.rx,
            shape.y - shape.ry,
            shape.x + shape.rx,
            shape.y + shape.ry,
        ),
        ShapeType::Line | ShapeType::Polyline | ShapeType::Polygon => point_bounds(&shape.points)?,
        ShapeType::Path | ShapeType::TexturePath => {
            let flattened = flatten_path(&shape.path);
            let points = flattened
                .iter()
                .flat_map(|subpath| subpath.points.iter().copied())
                .collect::<Vec<_>>();
            point_bounds(&points)?
        }
        ShapeType::Text => (
            shape.x,
            shape.y - shape.font_size,
            shape.x + shape.font_size * 0.75 * shape.text.chars().count() as f64,
            shape.y + shape.font_size * 0.25,
        ),
        ShapeType::Pixel => (shape.x, shape.y, shape.x + 1.0, shape.y + 1.0),
        ShapeType::RasterFilter | ShapeType::FloodFill => (0.0, 0.0, width as f64, height as f64),
    };
    let padding = shape.style.stroke_width.max(1.0) * 0.5 + 2.0;
    left = (left - padding).floor().max(0.0);
    top = (top - padding).floor().max(0.0);
    right = (right + padding).ceil().min(width as f64);
    bottom = (bottom + padding).ceil().min(height as f64);
    if right <= left || bottom <= top {
        None
    } else {
        Some((left as i32, top as i32, right as i32, bottom as i32))
    }
}

fn point_bounds(points: &[(f64, f64)]) -> Option<(f64, f64, f64, f64)> {
    let first = points.first()?;
    let mut left = first.0;
    let mut top = first.1;
    let mut right = first.0;
    let mut bottom = first.1;
    for &(x, y) in points.iter().skip(1) {
        left = left.min(x);
        top = top.min(y);
        right = right.max(x);
        bottom = bottom.max(y);
    }
    Some((left, top, right, bottom))
}

#[derive(Clone, Copy)]
struct TexturedVertex {
    x: f64,
    y: f64,
    u: f64,
    v: f64,
}

fn warped_bitmap_vertex(shape: &Shape, u: f64, v: f64) -> TexturedVertex {
    let (x, y) = warped_bitmap_point(shape, u, v);
    TexturedVertex { x, y, u, v }
}

fn rasterize_warped_bitmap(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    bitmap: &BitmapData,
    opacity: f64,
) {
    let warp = shape
        .bitmap_warp
        .as_ref()
        .expect("warped bitmap raster requires warp state");
    if warp.bend == 0.0 && warp.turn == 0.0 {
        rasterize_rigid_bitmap(framebuffer, width, height, shape, bitmap, opacity);
        return;
    }
    const COLUMNS: usize = 12;
    const ROWS: usize = 32;
    for row in 0..ROWS {
        let v0 = row as f64 / ROWS as f64;
        let v1 = (row + 1) as f64 / ROWS as f64;
        for column in 0..COLUMNS {
            let u0 = column as f64 / COLUMNS as f64;
            let u1 = (column + 1) as f64 / COLUMNS as f64;
            let top_left = warped_bitmap_vertex(shape, u0, v0);
            let top_right = warped_bitmap_vertex(shape, u1, v0);
            let bottom_left = warped_bitmap_vertex(shape, u0, v1);
            let bottom_right = warped_bitmap_vertex(shape, u1, v1);
            rasterize_textured_triangle(
                framebuffer,
                width,
                height,
                bitmap,
                shape,
                opacity,
                [top_left, top_right, bottom_right],
            );
            rasterize_textured_triangle(
                framebuffer,
                width,
                height,
                bitmap,
                shape,
                opacity,
                [top_left, bottom_right, bottom_left],
            );
        }
    }
}

fn rasterize_rigid_bitmap(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    bitmap: &BitmapData,
    opacity: f64,
) {
    let Some((left, top, right, bottom)) = warped_bitmap_bounds(shape) else {
        return;
    };
    if right < 0.0 || bottom < 0.0 || left >= width as f64 || top >= height as f64 {
        return;
    }
    let left = left.floor().max(0.0) as i32;
    let top = top.floor().max(0.0) as i32;
    let right = right.ceil().min(width.saturating_sub(1) as f64) as i32;
    let bottom = bottom.ceil().min(height.saturating_sub(1) as f64) as i32;
    let warp = shape
        .bitmap_warp
        .as_ref()
        .expect("rigid bitmap raster requires warp state");
    let angle = warp.angle.to_radians();
    let cosine = angle.cos();
    let sine = angle.sin();
    let facing = (1.0 + warp.aim * warp.aim).sqrt().recip();
    for y in top..=bottom {
        for x in left..=right {
            let dx = x as f64 + 0.5 - shape.x;
            let dy = y as f64 + 0.5 - shape.y;
            let local_x = dx * cosine + dy * sine;
            let local_y = -dx * sine + dy * cosine;
            let across = (local_x + warp.aim * local_y) / facing;
            let u = across / shape.w + 0.5;
            let v = local_y / shape.h + 1.0;
            if !(0.0..=1.0).contains(&u) || !(0.0..=1.0).contains(&v) {
                continue;
            }
            let color = tint_bitmap_color(sample_bitmap_uv(bitmap, u, v), shape.bitmap_tint);
            if color.a == 0 {
                continue;
            }
            blend_pixel(
                framebuffer,
                width,
                height,
                x,
                y,
                f64::from(color.r) * warp.light,
                f64::from(color.g) * warp.light,
                f64::from(color.b) * warp.light,
                color.alpha_unit() * opacity,
            );
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn rasterize_textured_triangle(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    bitmap: &BitmapData,
    shape: &Shape,
    opacity: f64,
    vertices: [TexturedVertex; 3],
) {
    let [v0, v1, v2] = vertices;
    let denominator = (v1.y - v2.y) * (v0.x - v2.x) + (v2.x - v1.x) * (v0.y - v2.y);
    if denominator.abs() <= 1e-9 {
        return;
    }
    let left = v0.x.min(v1.x).min(v2.x).floor().max(0.0) as i32;
    let top = v0.y.min(v1.y).min(v2.y).floor().max(0.0) as i32;
    let right =
        v0.x.max(v1.x)
            .max(v2.x)
            .ceil()
            .min(width.saturating_sub(1) as f64) as i32;
    let bottom =
        v0.y.max(v1.y)
            .max(v2.y)
            .ceil()
            .min(height.saturating_sub(1) as f64) as i32;
    if right < left || bottom < top {
        return;
    }
    let warp = shape
        .bitmap_warp
        .as_ref()
        .expect("textured triangle requires warp state");
    for y in top..=bottom {
        for x in left..=right {
            let sample_x = x as f64 + 0.5;
            let sample_y = y as f64 + 0.5;
            let weight0 = ((v1.y - v2.y) * (sample_x - v2.x) + (v2.x - v1.x) * (sample_y - v2.y))
                / denominator;
            let weight1 = ((v2.y - v0.y) * (sample_x - v2.x) + (v0.x - v2.x) * (sample_y - v2.y))
                / denominator;
            let weight2 = 1.0 - weight0 - weight1;
            if weight0 < -1e-7 || weight1 < -1e-7 || weight2 < -1e-7 {
                continue;
            }
            let u = v0.u * weight0 + v1.u * weight1 + v2.u * weight2;
            let v = v0.v * weight0 + v1.v * weight1 + v2.v * weight2;
            let color = tint_bitmap_color(sample_bitmap_uv(bitmap, u, v), shape.bitmap_tint);
            if color.a == 0 {
                continue;
            }
            let distance_from_stem = 1.0 - v;
            let shade = (warp.light
                * (1.0 - 0.25 * warp.turn.abs() * distance_from_stem)
                * (1.0 - 0.12 * warp.turn * (u - 0.5) * 2.0 * distance_from_stem))
                .clamp(0.0, 2.0);
            blend_pixel(
                framebuffer,
                width,
                height,
                x,
                y,
                f64::from(color.r) * shade,
                f64::from(color.g) * shade,
                f64::from(color.b) * shade,
                color.alpha_unit() * opacity,
            );
        }
    }
}

fn rasterize_shape(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    opacity: f64,
    gradients: &[GradientDef],
) {
    let style = &shape.style;
    let fill = style.fill.unwrap_or(Color::TRANSPARENT);
    let stroke = style.stroke.unwrap_or(Color::TRANSPARENT);
    let gradient = gradients
        .iter()
        .find(|gradient| gradient.id == style.gradient_id);
    let has_fill = gradient.is_some() || (style.fill.is_some() && fill.a > 0);
    let has_stroke = style.stroke.is_some() && style.stroke_width > 0.0 && stroke.a > 0;
    let stroke_alpha = (stroke.alpha_unit() * opacity).clamp(0.0, 1.0);

    match shape.shape_type {
        ShapeType::Rect => {
            let x0 = shape.x.floor() as i32 - 1;
            let y0 = shape.y.floor() as i32 - 1;
            let x1 = (shape.x + shape.w).ceil() as i32 + 1;
            let y1 = (shape.y + shape.h).ceil() as i32 + 1;
            let radius = shape.rx.max(0.0).min(shape.w.min(shape.h) * 0.5);
            if has_fill {
                for y in y0..y1 {
                    for x in x0..x1 {
                        let coverage = (0.5
                            - rounded_rect_signed_distance(
                                x as f64 + 0.5,
                                y as f64 + 0.5,
                                shape.x,
                                shape.y,
                                shape.w,
                                shape.h,
                                radius,
                            ))
                        .clamp(0.0, 1.0);
                        blend_paint_pixel(
                            fb,
                            width,
                            height,
                            x,
                            y,
                            fill,
                            opacity * coverage,
                            gradient,
                        );
                    }
                }
            }
            if has_stroke {
                let sw = (style.stroke_width * 0.5).ceil() as i32 + 1;
                for y in (y0 - sw)..(y1 + sw) {
                    for x in (x0 - sw)..(x1 + sw) {
                        let distance = rounded_rect_signed_distance(
                            x as f64 + 0.5,
                            y as f64 + 0.5,
                            shape.x,
                            shape.y,
                            shape.w,
                            shape.h,
                            radius,
                        );
                        let coverage =
                            (style.stroke_width * 0.5 + 0.5 - distance.abs()).clamp(0.0, 1.0);
                        blend_pixel(
                            fb,
                            width,
                            height,
                            x,
                            y,
                            stroke.r as f64,
                            stroke.g as f64,
                            stroke.b as f64,
                            stroke_alpha * coverage,
                        );
                    }
                }
            }
        }
        ShapeType::Circle => {
            let cx = shape.x;
            let cy = shape.y;
            let r = shape.r;
            if has_fill {
                let x0 = (cx - r).floor() as i32 - 1;
                let y0 = (cy - r).floor() as i32 - 1;
                let x1 = (cx + r).ceil() as i32 + 1;
                let y1 = (cy + r).ceil() as i32 + 1;
                for y in y0..=y1 {
                    for x in x0..=x1 {
                        let distance =
                            ((x as f64 + 0.5 - cx).powi(2) + (y as f64 + 0.5 - cy).powi(2)).sqrt();
                        let coverage = (r + 0.5 - distance).clamp(0.0, 1.0);
                        blend_paint_pixel(
                            fb,
                            width,
                            height,
                            x,
                            y,
                            fill,
                            opacity * coverage,
                            gradient,
                        );
                    }
                }
            }
            if has_stroke {
                let extent = r + style.stroke_width * 0.5 + 1.0;
                let x0 = (cx - extent).floor() as i32;
                let y0 = (cy - extent).floor() as i32;
                let x1 = (cx + extent).ceil() as i32;
                let y1 = (cy + extent).ceil() as i32;
                for y in y0..=y1 {
                    for x in x0..=x1 {
                        let distance =
                            ((x as f64 + 0.5 - cx).powi(2) + (y as f64 + 0.5 - cy).powi(2)).sqrt();
                        let coverage =
                            (style.stroke_width * 0.5 + 0.5 - (distance - r).abs()).clamp(0.0, 1.0);
                        blend_pixel(
                            fb,
                            width,
                            height,
                            x,
                            y,
                            stroke.r as f64,
                            stroke.g as f64,
                            stroke.b as f64,
                            stroke_alpha * coverage,
                        );
                    }
                }
            }
        }
        ShapeType::Ellipse => {
            let cx = shape.x;
            let cy = shape.y;
            let rx = shape.rx;
            let ry = shape.ry;
            if has_fill && rx > 0.0 && ry > 0.0 {
                let x0 = (cx - rx).floor() as i32 - 1;
                let y0 = (cy - ry).floor() as i32 - 1;
                let x1 = (cx + rx).ceil() as i32 + 1;
                let y1 = (cy + ry).ceil() as i32 + 1;
                for y in y0..=y1 {
                    for x in x0..=x1 {
                        let ex = (x as f64 + 0.5 - cx) / rx;
                        let ey = (y as f64 + 0.5 - cy) / ry;
                        let signed_distance = ((ex * ex + ey * ey).sqrt() - 1.0) * rx.min(ry);
                        let coverage = (0.5 - signed_distance).clamp(0.0, 1.0);
                        blend_paint_pixel(
                            fb,
                            width,
                            height,
                            x,
                            y,
                            fill,
                            opacity * coverage,
                            gradient,
                        );
                    }
                }
            }
            if has_stroke && rx > 0.0 && ry > 0.0 {
                let extent = style.stroke_width * 0.5 + 1.0;
                let x0 = (cx - rx - extent).floor() as i32;
                let y0 = (cy - ry - extent).floor() as i32;
                let x1 = (cx + rx + extent).ceil() as i32;
                let y1 = (cy + ry + extent).ceil() as i32;
                for y in y0..=y1 {
                    for x in x0..=x1 {
                        let ex = (x as f64 + 0.5 - cx) / rx;
                        let ey = (y as f64 + 0.5 - cy) / ry;
                        let signed_distance = ((ex * ex + ey * ey).sqrt() - 1.0) * rx.min(ry);
                        let coverage = (style.stroke_width * 0.5 + 0.5 - signed_distance.abs())
                            .clamp(0.0, 1.0);
                        blend_pixel(
                            fb,
                            width,
                            height,
                            x,
                            y,
                            stroke.r as f64,
                            stroke.g as f64,
                            stroke.b as f64,
                            stroke_alpha * coverage,
                        );
                    }
                }
            }
        }
        ShapeType::Line => {
            if shape.points.len() >= 2 && has_stroke {
                let (x0, y0) = shape.points[0];
                let (x1, y1) = shape.points[1];
                if style.stroke_width <= 1.25 {
                    draw_line_aa(fb, width, height, x0, y0, x1, y1, stroke, stroke_alpha);
                } else {
                    draw_line_thick(
                        fb,
                        width,
                        height,
                        x0,
                        y0,
                        x1,
                        y1,
                        stroke,
                        stroke_alpha,
                        style.stroke_width,
                    );
                }
            }
        }
        ShapeType::Polyline => {
            // Not in the current ShapeType enum, handled as Line with multiple points
            if shape.points.len() >= 2 && has_stroke {
                for i in 0..shape.points.len() - 1 {
                    let (x0, y0) = shape.points[i];
                    let (x1, y1) = shape.points[i + 1];
                    draw_line_thick(
                        fb,
                        width,
                        height,
                        x0,
                        y0,
                        x1,
                        y1,
                        stroke,
                        stroke_alpha,
                        style.stroke_width,
                    );
                }
            }
        }
        ShapeType::Polygon => {
            if has_fill && shape.points.len() >= 3 {
                fill_polygon_scanline(fb, width, height, &shape.points, fill, opacity, gradient);
            }
            if has_stroke && shape.points.len() >= 2 {
                for i in 0..shape.points.len() {
                    let (x0, y0) = shape.points[i];
                    let (x1, y1) = shape.points[(i + 1) % shape.points.len()];
                    draw_line_thick(
                        fb,
                        width,
                        height,
                        x0,
                        y0,
                        x1,
                        y1,
                        stroke,
                        stroke_alpha,
                        style.stroke_width,
                    );
                }
            }
        }
        ShapeType::Path => {
            // Flatten path to subpaths and rasterize
            let subpaths = flatten_path(&shape.path);
            for sub in &subpaths {
                if has_fill && sub.points.len() >= 3 && sub.closed {
                    fill_polygon_scanline(fb, width, height, &sub.points, fill, opacity, gradient);
                }
                if has_stroke && sub.points.len() >= 2 {
                    for i in 0..sub.points.len() - 1 {
                        draw_line_thick(
                            fb,
                            width,
                            height,
                            sub.points[i].0,
                            sub.points[i].1,
                            sub.points[i + 1].0,
                            sub.points[i + 1].1,
                            stroke,
                            stroke_alpha,
                            style.stroke_width,
                        );
                    }
                }
            }
        }
        ShapeType::TexturePath => {
            if let Some(texture) = &shape.texture {
                let subpaths = flatten_path(&shape.path);
                let origin = subpaths
                    .iter()
                    .flat_map(|subpath| subpath.points.iter().copied())
                    .fold((f64::INFINITY, f64::INFINITY), |origin, point| {
                        (origin.0.min(point.0), origin.1.min(point.1))
                    });
                for subpath in &subpaths {
                    if subpath.closed && subpath.points.len() >= 3 {
                        fill_polygon_texture(
                            fb,
                            width,
                            height,
                            &subpath.points,
                            texture,
                            opacity,
                            origin,
                        );
                    }
                }
            }
        }
        ShapeType::RasterFilter => {
            if let Some(filter) = &shape.raster_filter {
                apply_raster_filter(fb, width, height, filter, opacity);
            }
        }
        ShapeType::Bitmap => {
            if let Some(bitmap) = &shape.bitmap {
                if !rasterize_exact_device_bitmap(fb, width, height, shape, bitmap, opacity) {
                    if shape.bitmap_warp.is_some() {
                        rasterize_warped_bitmap(fb, width, height, shape, bitmap, opacity);
                    } else {
                        let w = shape.w.max(1.0) as usize;
                        let h = shape.h.max(1.0) as usize;
                        for py in 0..h {
                            for px in 0..w {
                                let color = tint_bitmap_color(
                                    sample_bitmap_bilinear(bitmap, px, py, w, h),
                                    shape.bitmap_tint,
                                );
                                blend_pixel(
                                    fb,
                                    width,
                                    height,
                                    shape.x as i32 + px as i32,
                                    shape.y as i32 + py as i32,
                                    color.r as f64,
                                    color.g as f64,
                                    color.b as f64,
                                    color.alpha_unit() * opacity,
                                );
                            }
                        }
                    }
                }
            }
        }
        ShapeType::Pixel => {
            if has_fill {
                blend_paint_pixel(
                    fb,
                    width,
                    height,
                    shape.x as i32,
                    shape.y as i32,
                    fill,
                    opacity,
                    gradient,
                );
            }
        }
        ShapeType::Text => {
            if has_fill {
                if let Some(font) = &shape.bitmap_font {
                    draw_text_bitmap_font(
                        fb,
                        width,
                        height,
                        shape.x as i32,
                        shape.y as i32,
                        &shape.text,
                        shape.font_size,
                        fill,
                        fill.alpha_unit() * opacity,
                        font,
                    );
                } else {
                    // Large text uses the antialiased geometric display face;
                    // tiny glyphs retain the portable bitmap fallback.
                    draw_text_builtin(
                        fb,
                        width,
                        height,
                        shape.x as i32,
                        shape.y as i32,
                        &shape.text,
                        shape.font_size,
                        fill,
                        fill.alpha_unit() * opacity,
                    );
                }
            }
        }
        ShapeType::FloodFill => {
            let _ = flood_fill_pixels(fb, width, height, shape, opacity);
        }
    }
}

fn rasterize_exact_device_bitmap(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    bitmap: &BitmapData,
    opacity: f64,
) -> bool {
    if !shape.device_space
        || shape.bitmap_warp.is_some()
        || opacity != 1.0
        || shape.x.fract() != 0.0
        || shape.y.fract() != 0.0
        || shape.x < 0.0
        || shape.y < 0.0
        || shape.w != bitmap.width as f64
        || shape.h != bitmap.height as f64
    {
        return false;
    }
    let destination_x = shape.x as usize;
    let destination_y = shape.y as usize;
    if destination_x >= width || destination_y >= height {
        return true;
    }
    let copy_width = bitmap.width.min(width - destination_x);
    let copy_height = bitmap.height.min(height - destination_y);
    for row in 0..copy_height {
        let source_start = row * bitmap.width;
        let destination_start = (destination_y + row) * width + destination_x;
        let source = &bitmap.pixels[source_start..source_start + copy_width];
        let destination = &mut framebuffer[destination_start..destination_start + copy_width];
        for (pixel, source_color) in destination.iter_mut().zip(source) {
            let color = tint_bitmap_color(*source_color, shape.bitmap_tint);
            match color.a {
                255 => *pixel = (color.r as f32, color.g as f32, color.b as f32),
                0 => {}
                _ => blend_pixel_value(pixel, BlendMode::Normal, color, color.alpha_unit()),
            }
        }
    }
    true
}

fn flood_fill_pixels(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    shape: &Shape,
    opacity: f64,
) -> Vec<usize> {
    let x = shape.x.round() as i64;
    let y = shape.y.round() as i64;
    let fill = shape.style.fill.unwrap_or(Color::TRANSPARENT);
    let alpha = (fill.alpha_unit() * opacity).clamp(0.0, 1.0);
    if x < 0 || y < 0 || x >= width as i64 || y >= height as i64 || alpha == 0.0 {
        return Vec::new();
    }

    let start = y as usize * width + x as usize;
    let target = framebuffer[start];
    let border = shape
        .style
        .stroke
        .map(|color| (color.r as f32, color.g as f32, color.b as f32));
    if border.is_some_and(|border| same_raster_pixel(target, border)) {
        return Vec::new();
    }
    let blend_fill = |pixel: RasterPixel| {
        (
            (pixel.0 as f64 * (1.0 - alpha) + fill.r as f64 * alpha) as f32,
            (pixel.1 as f64 * (1.0 - alpha) + fill.g as f64 * alpha) as f32,
            (pixel.2 as f64 * (1.0 - alpha) + fill.b as f64 * alpha) as f32,
        )
    };
    let replacement = blend_fill(target);
    if border.is_none() && same_raster_pixel(target, replacement) {
        return Vec::new();
    }

    let mut changed = Vec::new();
    let mut pending = Vec::new();
    let mut visited = border.map(|_| vec![false; framebuffer.len()]);
    if let Some(visited) = visited.as_mut() {
        visited[start] = true;
    }
    framebuffer[start] = replacement;
    changed.push(start);
    pending.push(start);

    while let Some(index) = pending.pop() {
        let pixel_x = index % width;
        let pixel_y = index / width;
        let neighbors = [
            pixel_x.checked_sub(1).map(|x| pixel_y * width + x),
            (pixel_x + 1 < width).then_some(pixel_y * width + pixel_x + 1),
            pixel_y.checked_sub(1).map(|y| y * width + pixel_x),
            (pixel_y + 1 < height).then_some((pixel_y + 1) * width + pixel_x),
        ];
        for neighbor in neighbors.into_iter().flatten() {
            let should_fill = if let Some(border) = border {
                let visited = visited
                    .as_ref()
                    .expect("border flood fills allocate a visited bitmap");
                !visited[neighbor] && !same_raster_pixel(framebuffer[neighbor], border)
            } else {
                same_raster_pixel(framebuffer[neighbor], target)
            };
            if should_fill {
                if let Some(visited) = visited.as_mut() {
                    visited[neighbor] = true;
                }
                framebuffer[neighbor] = if border.is_some() {
                    blend_fill(framebuffer[neighbor])
                } else {
                    replacement
                };
                changed.push(neighbor);
                pending.push(neighbor);
            }
        }
    }
    changed
}

fn same_raster_pixel(left: RasterPixel, right: RasterPixel) -> bool {
    left.0.to_bits() == right.0.to_bits()
        && left.1.to_bits() == right.1.to_bits()
        && left.2.to_bits() == right.2.to_bits()
}

fn draw_line_thick(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    x0: f64,
    y0: f64,
    x1: f64,
    y1: f64,
    color: Color,
    alpha: f64,
    line_width: f64,
) {
    let dx = x1 - x0;
    let dy = y1 - y0;
    let length_squared = dx * dx + dy * dy;
    let half_width = line_width * 0.5;
    let padding = half_width + 1.0;
    let left = ((x0.min(x1) - padding).floor() as i32).clamp(0, width as i32 - 1);
    let top = ((y0.min(y1) - padding).floor() as i32).clamp(0, height as i32 - 1);
    let right = ((x0.max(x1) + padding).ceil() as i32).clamp(0, width as i32 - 1);
    let bottom = ((y0.max(y1) + padding).ceil() as i32).clamp(0, height as i32 - 1);
    if right < left || bottom < top {
        return;
    }

    for y in top..=bottom {
        for x in left..=right {
            let px = x as f64 + 0.5;
            let py = y as f64 + 0.5;
            let t = if length_squared <= f64::EPSILON {
                0.0
            } else {
                (((px - x0) * dx + (py - y0) * dy) / length_squared).clamp(0.0, 1.0)
            };
            let nearest_x = x0 + t * dx;
            let nearest_y = y0 + t * dy;
            let distance = (px - nearest_x).hypot(py - nearest_y);
            let coverage = (half_width + 0.5 - distance).clamp(0.0, 1.0);
            blend_pixel(
                fb,
                width,
                height,
                x,
                y,
                color.r as f64,
                color.g as f64,
                color.b as f64,
                alpha * coverage,
            );
        }
    }
}

fn texture_hash(seed: i64, x: i64, y: i64) -> f64 {
    let mut value = (seed as u64)
        ^ (x as u64).wrapping_mul(0x9e37_79b9_7f4a_7c15)
        ^ (y as u64).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    ((value ^ (value >> 31)) as f64) / u64::MAX as f64
}

fn texture_value_noise(seed: i64, x: f64, y: f64) -> f64 {
    let x0 = x.floor() as i64;
    let y0 = y.floor() as i64;
    let tx = x - x0 as f64;
    let ty = y - y0 as f64;
    let smooth_x = tx * tx * (3.0 - 2.0 * tx);
    let smooth_y = ty * ty * (3.0 - 2.0 * ty);
    let top =
        texture_hash(seed, x0, y0) * (1.0 - smooth_x) + texture_hash(seed, x0 + 1, y0) * smooth_x;
    let bottom = texture_hash(seed, x0, y0 + 1) * (1.0 - smooth_x)
        + texture_hash(seed, x0 + 1, y0 + 1) * smooth_x;
    top * (1.0 - smooth_y) + bottom * smooth_y
}

fn fractal_texture(texture: &TexturePaint, x: f64, y: f64) -> f64 {
    let mut value = 0.0;
    let mut amplitude = 1.0;
    let mut amplitude_sum = 0.0;
    let mut frequency = 1.0 / texture.scale;
    for octave in 0..texture.octaves {
        value += texture_value_noise(
            texture.seed.wrapping_add(i64::from(octave) * 7_919),
            x * frequency,
            y * frequency,
        ) * amplitude;
        amplitude_sum += amplitude;
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    (value / amplitude_sum.max(f64::EPSILON)).clamp(0.0, 1.0)
}

fn texture_color(texture: &TexturePaint, amount: f64) -> Color {
    let interpolate = |low: u8, high: u8| {
        (f64::from(low) * (1.0 - amount) + f64::from(high) * amount)
            .round()
            .clamp(0.0, 255.0) as u8
    };
    Color::rgba(
        interpolate(texture.low.r, texture.high.r),
        interpolate(texture.low.g, texture.high.g),
        interpolate(texture.low.b, texture.high.b),
        interpolate(texture.low.a, texture.high.a),
    )
}

fn fill_polygon_texture(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    points: &[(f64, f64)],
    texture: &TexturePaint,
    opacity: f64,
    origin: (f64, f64),
) {
    if points.len() < 3 || !origin.0.is_finite() || !origin.1.is_finite() {
        return;
    }
    let min_x = (points
        .iter()
        .map(|point| point.0)
        .fold(f64::INFINITY, f64::min)
        .floor() as i32)
        .clamp(0, width as i32);
    let max_x = (points
        .iter()
        .map(|point| point.0)
        .fold(f64::NEG_INFINITY, f64::max)
        .ceil() as i32)
        .clamp(0, width as i32);
    let min_y = (points
        .iter()
        .map(|point| point.1)
        .fold(f64::INFINITY, f64::min)
        .floor() as i32)
        .clamp(0, height as i32 - 1);
    let max_y = (points
        .iter()
        .map(|point| point.1)
        .fold(f64::NEG_INFINITY, f64::max)
        .ceil() as i32)
        .clamp(0, height as i32 - 1);
    let row_width = (max_x - min_x).max(0) as usize;
    for y in min_y..=max_y {
        let mut coverage = vec![0.0_f64; row_width];
        for sample in 0..4 {
            let yf = y as f64 + (sample as f64 + 0.5) * 0.25;
            let mut crossings = Vec::new();
            for index in 0..points.len() {
                let (x0, y0) = points[index];
                let (x1, y1) = points[(index + 1) % points.len()];
                if (y0 <= yf && y1 > yf) || (y1 <= yf && y0 > yf) {
                    let t = (yf - y0) / (y1 - y0);
                    crossings.push(x0 + t * (x1 - x0));
                }
            }
            crossings.sort_by(|left, right| {
                left.partial_cmp(right).unwrap_or(std::cmp::Ordering::Equal)
            });
            for interval in crossings.chunks_exact(2) {
                let interval_start = interval[0];
                let interval_end = interval[1];
                for x in interval_start.floor() as i32..interval_end.ceil() as i32 {
                    if x < min_x || x >= max_x {
                        continue;
                    }
                    let overlap = ((x as f64 + 1.0).min(interval_end)
                        - (x as f64).max(interval_start))
                    .clamp(0.0, 1.0);
                    coverage[(x - min_x) as usize] += overlap * 0.25;
                }
            }
        }
        for (offset, coverage) in coverage.into_iter().enumerate() {
            if coverage <= 0.0 {
                continue;
            }
            let x = min_x + offset as i32;
            let amount = fractal_texture(
                texture,
                x as f64 + 0.5 - origin.0,
                y as f64 + 0.5 - origin.1,
            );
            let color = texture_color(texture, amount);
            blend_pixel(
                fb,
                width,
                height,
                x,
                y,
                f64::from(color.r),
                f64::from(color.g),
                f64::from(color.b),
                color.alpha_unit() * opacity * coverage.min(1.0),
            );
        }
    }
}

fn box_blur(
    source: &[RasterPixel],
    width: usize,
    height: usize,
    radius: usize,
) -> Vec<RasterPixel> {
    if radius == 0 || width == 0 || height == 0 {
        return source.to_vec();
    }
    let mut horizontal = vec![(0.0_f32, 0.0_f32, 0.0_f32); source.len()];
    for y in 0..height {
        let mut sum = (0.0_f64, 0.0_f64, 0.0_f64);
        let initial_end = radius.min(width - 1);
        for x in 0..=initial_end {
            let pixel = source[y * width + x];
            sum.0 += f64::from(pixel.0);
            sum.1 += f64::from(pixel.1);
            sum.2 += f64::from(pixel.2);
        }
        let mut count = initial_end + 1;
        for x in 0..width {
            horizontal[y * width + x] = (
                (sum.0 / count as f64) as f32,
                (sum.1 / count as f64) as f32,
                (sum.2 / count as f64) as f32,
            );
            if x >= radius {
                let pixel = source[y * width + x - radius];
                sum.0 -= f64::from(pixel.0);
                sum.1 -= f64::from(pixel.1);
                sum.2 -= f64::from(pixel.2);
                count -= 1;
            }
            if x + radius + 1 < width {
                let pixel = source[y * width + x + radius + 1];
                sum.0 += f64::from(pixel.0);
                sum.1 += f64::from(pixel.1);
                sum.2 += f64::from(pixel.2);
                count += 1;
            }
        }
    }
    let mut output = vec![(0.0_f32, 0.0_f32, 0.0_f32); source.len()];
    for x in 0..width {
        let mut sum = (0.0_f64, 0.0_f64, 0.0_f64);
        let initial_end = radius.min(height - 1);
        for y in 0..=initial_end {
            let pixel = horizontal[y * width + x];
            sum.0 += f64::from(pixel.0);
            sum.1 += f64::from(pixel.1);
            sum.2 += f64::from(pixel.2);
        }
        let mut count = initial_end + 1;
        for y in 0..height {
            output[y * width + x] = (
                (sum.0 / count as f64) as f32,
                (sum.1 / count as f64) as f32,
                (sum.2 / count as f64) as f32,
            );
            if y >= radius {
                let pixel = horizontal[(y - radius) * width + x];
                sum.0 -= f64::from(pixel.0);
                sum.1 -= f64::from(pixel.1);
                sum.2 -= f64::from(pixel.2);
                count -= 1;
            }
            if y + radius + 1 < height {
                let pixel = horizontal[(y + radius + 1) * width + x];
                sum.0 += f64::from(pixel.0);
                sum.1 += f64::from(pixel.1);
                sum.2 += f64::from(pixel.2);
                count += 1;
            }
        }
    }
    output
}

fn apply_raster_filter(
    framebuffer: &mut [RasterPixel],
    width: usize,
    height: usize,
    filter: &RasterFilter,
    opacity: f64,
) {
    if framebuffer.is_empty() || opacity <= 0.0 {
        return;
    }
    let original = framebuffer.to_vec();
    let filtered = match *filter {
        RasterFilter::Blur { radius } => box_blur(&original, width, height, radius),
        RasterFilter::Sharpen { amount } => {
            let blurred = box_blur(&original, width, height, 1);
            original
                .iter()
                .zip(blurred)
                .map(|(source, soft)| {
                    (
                        (f64::from(source.0) + amount * f64::from(source.0 - soft.0))
                            .clamp(0.0, 255.0) as f32,
                        (f64::from(source.1) + amount * f64::from(source.1 - soft.1))
                            .clamp(0.0, 255.0) as f32,
                        (f64::from(source.2) + amount * f64::from(source.2 - soft.2))
                            .clamp(0.0, 255.0) as f32,
                    )
                })
                .collect()
        }
        RasterFilter::Color {
            brightness,
            contrast,
            saturation,
        } => original
            .iter()
            .map(|pixel| {
                let adjust = |channel: f32| {
                    ((f64::from(channel) * brightness - 127.5) * contrast + 127.5).clamp(0.0, 255.0)
                };
                let red = adjust(pixel.0);
                let green = adjust(pixel.1);
                let blue = adjust(pixel.2);
                let luminance = 0.2126 * red + 0.7152 * green + 0.0722 * blue;
                (
                    (luminance + (red - luminance) * saturation).clamp(0.0, 255.0) as f32,
                    (luminance + (green - luminance) * saturation).clamp(0.0, 255.0) as f32,
                    (luminance + (blue - luminance) * saturation).clamp(0.0, 255.0) as f32,
                )
            })
            .collect(),
    };
    let mix = opacity.clamp(0.0, 1.0) as f32;
    for ((destination, source), before) in framebuffer.iter_mut().zip(filtered).zip(original) {
        *destination = (
            before.0 * (1.0 - mix) + source.0 * mix,
            before.1 * (1.0 - mix) + source.1 * mix,
            before.2 * (1.0 - mix) + source.2 * mix,
        );
    }
}

fn fill_polygon_scanline(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    points: &[(f64, f64)],
    color: Color,
    opacity: f64,
    gradient: Option<&GradientDef>,
) {
    if points.len() < 3 {
        return;
    }
    let min_y = (points
        .iter()
        .map(|p| p.1)
        .fold(f64::INFINITY, f64::min)
        .floor() as i32)
        .clamp(0, height as i32 - 1);
    let max_y = (points
        .iter()
        .map(|p| p.1)
        .fold(f64::NEG_INFINITY, f64::max)
        .ceil() as i32)
        .clamp(0, height as i32 - 1);
    for y in min_y..=max_y {
        if y < 0 || (y as usize) >= height {
            continue;
        }
        let min_x = (points
            .iter()
            .map(|point| point.0)
            .fold(f64::INFINITY, f64::min)
            .floor() as i32)
            .clamp(0, width as i32);
        let max_x = (points
            .iter()
            .map(|point| point.0)
            .fold(f64::NEG_INFINITY, f64::max)
            .ceil() as i32)
            .clamp(0, width as i32);
        let row_width = (max_x - min_x).max(0) as usize;
        let mut coverage = vec![0.0_f64; row_width];
        for sample in 0..4 {
            let yf = y as f64 + (sample as f64 + 0.5) * 0.25;
            let mut crossings = Vec::new();
            for i in 0..points.len() {
                let (x0, y0) = points[i];
                let (x1, y1) = points[(i + 1) % points.len()];
                if (y0 <= yf && y1 > yf) || (y1 <= yf && y0 > yf) {
                    let t = (yf - y0) / (y1 - y0);
                    crossings.push(x0 + t * (x1 - x0));
                }
            }
            crossings.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
            let mut i = 0;
            while i + 1 < crossings.len() {
                let interval_start = crossings[i];
                let interval_end = crossings[i + 1];
                let x_start = interval_start.floor() as i32;
                let x_end = interval_end.ceil() as i32;
                for x in x_start..x_end {
                    if x < min_x || x >= max_x {
                        continue;
                    }
                    let overlap = ((x as f64 + 1.0).min(interval_end)
                        - (x as f64).max(interval_start))
                    .clamp(0.0, 1.0);
                    coverage[(x - min_x) as usize] += overlap * 0.25;
                }
                i += 2;
            }
        }
        for (offset, coverage) in coverage.into_iter().enumerate() {
            if coverage > 0.0 {
                blend_paint_pixel(
                    fb,
                    width,
                    height,
                    min_x + offset as i32,
                    y,
                    color,
                    opacity * coverage.min(1.0),
                    gradient,
                );
            }
        }
    }
}

// ── Path flattening ───────────────────────────────────────────────

struct FlatSubpath {
    points: Vec<(f64, f64)>,
    closed: bool,
}

fn flatten_path(path: &[PathCommand]) -> Vec<FlatSubpath> {
    let mut subpaths: Vec<FlatSubpath> = Vec::new();
    let mut cur = (0.0f64, 0.0f64);
    let mut start = (0.0f64, 0.0f64);
    let mut have_cur = false;

    for cmd in path {
        match cmd.op {
            'M' | 'm' => {
                if have_cur && !subpaths.is_empty() && !subpaths.last().unwrap().points.is_empty() {
                    // auto-close handled by Z
                }
                if cmd.op == 'm' && have_cur {
                    cur = (cur.0 + cmd.values[0], cur.1 + cmd.values[1]);
                } else {
                    cur = (cmd.values[0], cmd.values[1]);
                }
                start = cur;
                subpaths.push(FlatSubpath {
                    points: vec![cur],
                    closed: false,
                });
            }
            'L' | 'l' => {
                if cmd.op == 'l' && have_cur {
                    cur = (cur.0 + cmd.values[0], cur.1 + cmd.values[1]);
                } else {
                    cur = (cmd.values[0], cmd.values[1]);
                }
                if let Some(sub) = subpaths.last_mut() {
                    sub.points.push(cur);
                }
            }
            'C' | 'c' => {
                // Cubic bezier: C cx1 cy1 cx2 cy2 x2 y2
                let (cx1, cy1, cx2, cy2, x2, y2) = if cmd.op == 'c' && have_cur {
                    (
                        cur.0 + cmd.values[0],
                        cur.1 + cmd.values[1],
                        cur.0 + cmd.values[2],
                        cur.1 + cmd.values[3],
                        cur.0 + cmd.values[4],
                        cur.1 + cmd.values[5],
                    )
                } else {
                    (
                        cmd.values[0],
                        cmd.values[1],
                        cmd.values[2],
                        cmd.values[3],
                        cmd.values[4],
                        cmd.values[5],
                    )
                };
                let pts = flatten_cubic(cur, (cx1, cy1), (cx2, cy2), (x2, y2), 16);
                if let Some(sub) = subpaths.last_mut() {
                    sub.points.extend(pts);
                }
                cur = (x2, y2);
            }
            'Q' | 'q' => {
                // Quadratic bezier: Q cx cy x2 y2
                let (cx, cy, x2, y2) = if cmd.op == 'q' && have_cur {
                    (
                        cur.0 + cmd.values[0],
                        cur.1 + cmd.values[1],
                        cur.0 + cmd.values[2],
                        cur.1 + cmd.values[3],
                    )
                } else {
                    (cmd.values[0], cmd.values[1], cmd.values[2], cmd.values[3])
                };
                let pts = flatten_quadratic(cur, (cx, cy), (x2, y2), 16);
                if let Some(sub) = subpaths.last_mut() {
                    sub.points.extend(pts);
                }
                cur = (x2, y2);
            }
            'H' | 'h' => {
                let x = if cmd.op == 'h' && have_cur {
                    cur.0 + cmd.values[0]
                } else {
                    cmd.values[0]
                };
                cur = (x, cur.1);
                if let Some(sub) = subpaths.last_mut() {
                    sub.points.push(cur);
                }
            }
            'V' | 'v' => {
                let y = if cmd.op == 'v' && have_cur {
                    cur.1 + cmd.values[0]
                } else {
                    cmd.values[0]
                };
                cur = (cur.0, y);
                if let Some(sub) = subpaths.last_mut() {
                    sub.points.push(cur);
                }
            }
            'Z' | 'z' => {
                if have_cur && !subpaths.is_empty() {
                    let sub = subpaths.last_mut().unwrap();
                    if sub.points.last() != Some(&start) {
                        sub.points.push(start);
                    }
                    sub.closed = true;
                    cur = start;
                }
            }
            'A' | 'a' => {
                // SVG arc: A rx ry x-rotation large-arc sweep x y
                if cmd.values.len() >= 7 && have_cur {
                    let rx = cmd.values[0];
                    let ry = cmd.values[1];
                    let x_rot = cmd.values[2];
                    let large = cmd.values[3] >= 0.5;
                    let sweep = cmd.values[4] >= 0.5;
                    let end = if cmd.op == 'a' && have_cur {
                        (cur.0 + cmd.values[5], cur.1 + cmd.values[6])
                    } else {
                        (cmd.values[5], cmd.values[6])
                    };
                    let pts = flatten_arc(cur, rx, ry, x_rot, large, sweep, end);
                    if let Some(sub) = subpaths.last_mut() {
                        sub.points.extend(pts);
                    }
                    cur = end;
                }
            }
            _ => {}
        }
        have_cur = true;
    }
    subpaths.retain(|s| !s.points.is_empty());
    subpaths
}

fn flatten_cubic(
    p0: (f64, f64),
    p1: (f64, f64),
    p2: (f64, f64),
    p3: (f64, f64),
    steps: usize,
) -> Vec<(f64, f64)> {
    let mut pts = Vec::with_capacity(steps);
    for i in 1..=steps {
        let t = i as f64 / steps as f64;
        let mt = 1.0 - t;
        let x = mt * mt * mt * p0.0
            + 3.0 * mt * mt * t * p1.0
            + 3.0 * mt * t * t * p2.0
            + t * t * t * p3.0;
        let y = mt * mt * mt * p0.1
            + 3.0 * mt * mt * t * p1.1
            + 3.0 * mt * t * t * p2.1
            + t * t * t * p3.1;
        pts.push((x, y));
    }
    pts
}

fn flatten_quadratic(
    p0: (f64, f64),
    p1: (f64, f64),
    p2: (f64, f64),
    steps: usize,
) -> Vec<(f64, f64)> {
    let mut pts = Vec::with_capacity(steps);
    for i in 1..=steps {
        let t = i as f64 / steps as f64;
        let mt = 1.0 - t;
        let x = mt * mt * p0.0 + 2.0 * mt * t * p1.0 + t * t * p2.0;
        let y = mt * mt * p0.1 + 2.0 * mt * t * p1.1 + t * t * p2.1;
        pts.push((x, y));
    }
    pts
}

// ── Built-in dependency-free fonts ───────────────────────────────

mod geometric_font {
    pub type Segment = (f32, f32, f32, f32);

    const SPACE: &[Segment] = &[];
    const A: &[Segment] = &[
        (0.0, 1.0, 0.5, 0.0),
        (0.5, 0.0, 1.0, 1.0),
        (0.2, 0.58, 0.8, 0.58),
    ];
    const B: &[Segment] = &[
        (0.0, 0.0, 0.0, 1.0),
        (0.0, 0.0, 0.72, 0.0),
        (0.72, 0.0, 0.95, 0.2),
        (0.95, 0.2, 0.72, 0.48),
        (0.0, 0.48, 0.72, 0.48),
        (0.72, 0.48, 1.0, 0.72),
        (1.0, 0.72, 0.72, 1.0),
        (0.72, 1.0, 0.0, 1.0),
    ];
    const C: &[Segment] = &[
        (0.95, 0.08, 0.72, 0.0),
        (0.72, 0.0, 0.08, 0.18),
        (0.08, 0.18, 0.08, 0.82),
        (0.08, 0.82, 0.72, 1.0),
        (0.72, 1.0, 0.95, 0.92),
    ];
    const D: &[Segment] = &[
        (0.0, 0.0, 0.0, 1.0),
        (0.0, 0.0, 0.62, 0.0),
        (0.62, 0.0, 1.0, 0.28),
        (1.0, 0.28, 1.0, 0.72),
        (1.0, 0.72, 0.62, 1.0),
        (0.62, 1.0, 0.0, 1.0),
    ];
    const E: &[Segment] = &[
        (0.0, 0.0, 0.0, 1.0),
        (0.0, 0.0, 1.0, 0.0),
        (0.0, 0.5, 0.78, 0.5),
        (0.0, 1.0, 1.0, 1.0),
    ];
    const F: &[Segment] = &[
        (0.0, 0.0, 0.0, 1.0),
        (0.0, 0.0, 1.0, 0.0),
        (0.0, 0.5, 0.78, 0.5),
    ];
    const G: &[Segment] = &[
        (0.95, 0.08, 0.72, 0.0),
        (0.72, 0.0, 0.08, 0.18),
        (0.08, 0.18, 0.08, 0.82),
        (0.08, 0.82, 0.72, 1.0),
        (0.72, 1.0, 1.0, 0.78),
        (1.0, 0.78, 1.0, 0.55),
        (1.0, 0.55, 0.58, 0.55),
    ];
    const H: &[Segment] = &[
        (0.0, 0.0, 0.0, 1.0),
        (1.0, 0.0, 1.0, 1.0),
        (0.0, 0.5, 1.0, 0.5),
    ];
    const I: &[Segment] = &[
        (0.08, 0.0, 0.92, 0.0),
        (0.5, 0.0, 0.5, 1.0),
        (0.08, 1.0, 0.92, 1.0),
    ];
    const J: &[Segment] = &[
        (0.08, 0.0, 0.92, 0.0),
        (0.72, 0.0, 0.72, 0.82),
        (0.72, 0.82, 0.5, 1.0),
        (0.5, 1.0, 0.12, 0.86),
    ];
    const K: &[Segment] = &[
        (0.0, 0.0, 0.0, 1.0),
        (0.0, 0.55, 1.0, 0.0),
        (0.0, 0.55, 1.0, 1.0),
    ];
    const L: &[Segment] = &[(0.0, 0.0, 0.0, 1.0), (0.0, 1.0, 1.0, 1.0)];
    const M: &[Segment] = &[
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 0.5, 0.48),
        (0.5, 0.48, 1.0, 0.0),
        (1.0, 0.0, 1.0, 1.0),
    ];
    const N: &[Segment] = &[
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 1.0),
        (1.0, 1.0, 1.0, 0.0),
    ];
    const O: &[Segment] = &[
        (0.18, 0.0, 0.82, 0.0),
        (0.82, 0.0, 1.0, 0.18),
        (1.0, 0.18, 1.0, 0.82),
        (1.0, 0.82, 0.82, 1.0),
        (0.82, 1.0, 0.18, 1.0),
        (0.18, 1.0, 0.0, 0.82),
        (0.0, 0.82, 0.0, 0.18),
        (0.0, 0.18, 0.18, 0.0),
    ];
    const P: &[Segment] = &[
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 0.72, 0.0),
        (0.72, 0.0, 1.0, 0.22),
        (1.0, 0.22, 0.72, 0.5),
        (0.72, 0.5, 0.0, 0.5),
    ];
    const Q: &[Segment] = &[
        (0.18, 0.0, 0.82, 0.0),
        (0.82, 0.0, 1.0, 0.18),
        (1.0, 0.18, 1.0, 0.82),
        (1.0, 0.82, 0.82, 1.0),
        (0.82, 1.0, 0.18, 1.0),
        (0.18, 1.0, 0.0, 0.82),
        (0.0, 0.82, 0.0, 0.18),
        (0.0, 0.18, 0.18, 0.0),
        (0.58, 0.62, 1.08, 1.08),
    ];
    const R: &[Segment] = &[
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 0.72, 0.0),
        (0.72, 0.0, 1.0, 0.22),
        (1.0, 0.22, 0.72, 0.5),
        (0.72, 0.5, 0.0, 0.5),
        (0.55, 0.5, 1.0, 1.0),
    ];
    const S: &[Segment] = &[
        (1.0, 0.08, 0.78, 0.0),
        (0.78, 0.0, 0.08, 0.15),
        (0.08, 0.15, 0.78, 0.52),
        (0.78, 0.52, 1.0, 0.82),
        (1.0, 0.82, 0.22, 1.0),
        (0.22, 1.0, 0.0, 0.92),
    ];
    const T: &[Segment] = &[(0.0, 0.0, 1.0, 0.0), (0.5, 0.0, 0.5, 1.0)];
    const U: &[Segment] = &[
        (0.0, 0.0, 0.0, 0.8),
        (0.0, 0.8, 0.22, 1.0),
        (0.22, 1.0, 0.78, 1.0),
        (0.78, 1.0, 1.0, 0.8),
        (1.0, 0.8, 1.0, 0.0),
    ];
    const V: &[Segment] = &[(0.0, 0.0, 0.5, 1.0), (0.5, 1.0, 1.0, 0.0)];
    const W: &[Segment] = &[
        (0.0, 0.0, 0.18, 1.0),
        (0.18, 1.0, 0.5, 0.58),
        (0.5, 0.58, 0.82, 1.0),
        (0.82, 1.0, 1.0, 0.0),
    ];
    const X: &[Segment] = &[(0.0, 0.0, 1.0, 1.0), (1.0, 0.0, 0.0, 1.0)];
    const Y: &[Segment] = &[
        (0.0, 0.0, 0.5, 0.5),
        (1.0, 0.0, 0.5, 0.5),
        (0.5, 0.5, 0.5, 1.0),
    ];
    const Z: &[Segment] = &[
        (0.0, 0.0, 1.0, 0.0),
        (1.0, 0.0, 0.0, 1.0),
        (0.0, 1.0, 1.0, 1.0),
    ];

    const ZERO: &[Segment] = O;
    const ONE: &[Segment] = &[
        (0.2, 0.2, 0.5, 0.0),
        (0.5, 0.0, 0.5, 1.0),
        (0.18, 1.0, 0.82, 1.0),
    ];
    const TWO: &[Segment] = &[
        (0.0, 0.18, 0.22, 0.0),
        (0.22, 0.0, 0.82, 0.0),
        (0.82, 0.0, 1.0, 0.22),
        (1.0, 0.22, 0.0, 1.0),
        (0.0, 1.0, 1.0, 1.0),
    ];
    const THREE: &[Segment] = &[
        (0.0, 0.08, 0.22, 0.0),
        (0.22, 0.0, 0.82, 0.0),
        (0.82, 0.0, 1.0, 0.22),
        (1.0, 0.22, 0.62, 0.5),
        (0.62, 0.5, 1.0, 0.78),
        (1.0, 0.78, 0.82, 1.0),
        (0.82, 1.0, 0.12, 1.0),
    ];
    const FOUR: &[Segment] = &[
        (0.82, 1.0, 0.82, 0.0),
        (0.82, 0.0, 0.0, 0.68),
        (0.0, 0.68, 1.0, 0.68),
    ];
    const FIVE: &[Segment] = &[
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 0.0, 0.0, 0.5),
        (0.0, 0.5, 0.78, 0.5),
        (0.78, 0.5, 1.0, 0.72),
        (1.0, 0.72, 0.8, 1.0),
        (0.8, 1.0, 0.08, 1.0),
    ];
    const SIX: &[Segment] = &[
        (0.92, 0.05, 0.68, 0.0),
        (0.68, 0.0, 0.05, 0.45),
        (0.05, 0.45, 0.08, 0.85),
        (0.08, 0.85, 0.28, 1.0),
        (0.28, 1.0, 0.8, 1.0),
        (0.8, 1.0, 1.0, 0.75),
        (1.0, 0.75, 0.78, 0.52),
        (0.78, 0.52, 0.08, 0.52),
    ];
    const SEVEN: &[Segment] = &[(0.0, 0.0, 1.0, 0.0), (1.0, 0.0, 0.35, 1.0)];
    const EIGHT: &[Segment] = &[
        (0.2, 0.0, 0.8, 0.0),
        (0.8, 0.0, 1.0, 0.22),
        (1.0, 0.22, 0.5, 0.5),
        (0.5, 0.5, 0.0, 0.22),
        (0.0, 0.22, 0.2, 0.0),
        (0.5, 0.5, 1.0, 0.78),
        (1.0, 0.78, 0.8, 1.0),
        (0.8, 1.0, 0.2, 1.0),
        (0.2, 1.0, 0.0, 0.78),
        (0.0, 0.78, 0.5, 0.5),
    ];
    const NINE: &[Segment] = &[
        (0.92, 0.48, 0.22, 0.48),
        (0.22, 0.48, 0.0, 0.25),
        (0.0, 0.25, 0.2, 0.0),
        (0.2, 0.0, 0.72, 0.0),
        (0.72, 0.0, 0.95, 0.15),
        (0.95, 0.15, 0.92, 0.55),
        (0.92, 0.55, 0.3, 1.0),
        (0.3, 1.0, 0.08, 0.95),
    ];

    const DASH: &[Segment] = &[(0.12, 0.52, 0.88, 0.52)];
    const PLUS: &[Segment] = &[(0.1, 0.52, 0.9, 0.52), (0.5, 0.18, 0.5, 0.86)];
    const SLASH: &[Segment] = &[(0.92, 0.0, 0.08, 1.0)];
    const DOT: &[Segment] = &[(0.5, 0.96, 0.5, 0.96)];
    const COLON: &[Segment] = &[(0.5, 0.3, 0.5, 0.3), (0.5, 0.76, 0.5, 0.76)];
    const EXCLAMATION: &[Segment] = &[(0.5, 0.0, 0.5, 0.7), (0.5, 0.96, 0.5, 0.96)];
    const LEFT_PAREN: &[Segment] = &[
        (0.72, 0.0, 0.35, 0.22),
        (0.35, 0.22, 0.35, 0.78),
        (0.35, 0.78, 0.72, 1.0),
    ];
    const RIGHT_PAREN: &[Segment] = &[
        (0.28, 0.0, 0.65, 0.22),
        (0.65, 0.22, 0.65, 0.78),
        (0.65, 0.78, 0.28, 1.0),
    ];

    pub fn glyph(ch: char) -> Option<&'static [Segment]> {
        Some(match ch {
            ' ' => SPACE,
            'A' => A,
            'B' => B,
            'C' => C,
            'D' => D,
            'E' => E,
            'F' => F,
            'G' => G,
            'H' => H,
            'I' => I,
            'J' => J,
            'K' => K,
            'L' => L,
            'M' => M,
            'N' => N,
            'O' => O,
            'P' => P,
            'Q' => Q,
            'R' => R,
            'S' => S,
            'T' => T,
            'U' => U,
            'V' => V,
            'W' => W,
            'X' => X,
            'Y' => Y,
            'Z' => Z,
            '0' => ZERO,
            '1' => ONE,
            '2' => TWO,
            '3' => THREE,
            '4' => FOUR,
            '5' => FIVE,
            '6' => SIX,
            '7' => SEVEN,
            '8' => EIGHT,
            '9' => NINE,
            '-' => DASH,
            '+' => PLUS,
            '/' => SLASH,
            '.' => DOT,
            ':' => COLON,
            '!' => EXCLAMATION,
            '(' => LEFT_PAREN,
            ')' => RIGHT_PAREN,
            _ => return None,
        })
    }
}

// Tiny text and unsupported printable ASCII use this compact fallback.

mod font5x7 {
    /// 5x7 bitmap font for ASCII characters. Each entry stores five columns;
    /// the low seven bits of each column run from top to bottom. Two trailing
    /// zero columns retain the table's historical fixed-width representation.
    /// Only printable ASCII (32-126) is covered. Unknown chars render as blank.
    pub fn glyph(ch: char) -> Option<&'static [u8; 7]> {
        let idx = ch as usize;
        if !(32..=126).contains(&idx) {
            return None;
        }
        Some(&GLYPHS[idx - 32])
    }

    pub const GLYPHS: [[u8; 7]; 95] = [
        [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00], // space
        [0x00, 0x00, 0x5F, 0x00, 0x00, 0x00, 0x00], // !
        [0x00, 0x07, 0x00, 0x07, 0x00, 0x00, 0x00], // "
        [0x14, 0x7F, 0x14, 0x7F, 0x14, 0x00, 0x00], // #
        [0x24, 0x2A, 0x7F, 0x2A, 0x12, 0x00, 0x00], // $
        [0x23, 0x13, 0x08, 0x64, 0x62, 0x00, 0x00], // %
        [0x36, 0x49, 0x55, 0x22, 0x50, 0x00, 0x00], // &
        [0x00, 0x05, 0x03, 0x00, 0x00, 0x00, 0x00], // '
        [0x00, 0x1C, 0x22, 0x41, 0x00, 0x00, 0x00], // (
        [0x00, 0x41, 0x22, 0x1C, 0x00, 0x00, 0x00], // )
        [0x14, 0x08, 0x3E, 0x08, 0x14, 0x00, 0x00], // *
        [0x08, 0x08, 0x3E, 0x08, 0x08, 0x00, 0x00], // +
        [0x00, 0x50, 0x30, 0x00, 0x00, 0x00, 0x00], // ,
        [0x08, 0x08, 0x08, 0x08, 0x08, 0x00, 0x00], // -
        [0x00, 0x60, 0x60, 0x00, 0x00, 0x00, 0x00], // .
        [0x20, 0x10, 0x08, 0x04, 0x02, 0x00, 0x00], // /
        [0x3E, 0x51, 0x49, 0x45, 0x3E, 0x00, 0x00], // 0
        [0x00, 0x42, 0x7F, 0x40, 0x00, 0x00, 0x00], // 1
        [0x42, 0x61, 0x51, 0x49, 0x46, 0x00, 0x00], // 2
        [0x21, 0x41, 0x45, 0x4B, 0x31, 0x00, 0x00], // 3
        [0x18, 0x14, 0x12, 0x7F, 0x10, 0x00, 0x00], // 4
        [0x27, 0x45, 0x45, 0x45, 0x39, 0x00, 0x00], // 5
        [0x3C, 0x4A, 0x49, 0x49, 0x30, 0x00, 0x00], // 6
        [0x01, 0x71, 0x09, 0x05, 0x03, 0x00, 0x00], // 7
        [0x36, 0x49, 0x49, 0x49, 0x36, 0x00, 0x00], // 8
        [0x06, 0x49, 0x49, 0x29, 0x1E, 0x00, 0x00], // 9
        [0x00, 0x36, 0x36, 0x00, 0x00, 0x00, 0x00], // :
        [0x00, 0x56, 0x36, 0x00, 0x00, 0x00, 0x00], // ;
        [0x00, 0x08, 0x14, 0x22, 0x41, 0x00, 0x00], // <
        [0x14, 0x14, 0x14, 0x14, 0x14, 0x00, 0x00], // =
        [0x41, 0x22, 0x14, 0x08, 0x00, 0x00, 0x00], // >
        [0x02, 0x01, 0x51, 0x09, 0x06, 0x00, 0x00], // ?
        [0x32, 0x49, 0x79, 0x41, 0x3E, 0x00, 0x00], // @
        [0x7E, 0x11, 0x11, 0x11, 0x7E, 0x00, 0x00], // A
        [0x7F, 0x49, 0x49, 0x49, 0x36, 0x00, 0x00], // B
        [0x3E, 0x41, 0x41, 0x41, 0x22, 0x00, 0x00], // C
        [0x7F, 0x41, 0x41, 0x22, 0x1C, 0x00, 0x00], // D
        [0x7F, 0x49, 0x49, 0x49, 0x41, 0x00, 0x00], // E
        [0x7F, 0x09, 0x09, 0x01, 0x01, 0x00, 0x00], // F
        [0x3E, 0x41, 0x41, 0x51, 0x32, 0x00, 0x00], // G
        [0x7F, 0x08, 0x08, 0x08, 0x7F, 0x00, 0x00], // H
        [0x00, 0x41, 0x7F, 0x41, 0x00, 0x00, 0x00], // I
        [0x20, 0x40, 0x40, 0x40, 0x3F, 0x00, 0x00], // J
        [0x7F, 0x08, 0x14, 0x22, 0x41, 0x00, 0x00], // K
        [0x7F, 0x40, 0x40, 0x40, 0x40, 0x00, 0x00], // L
        [0x7F, 0x02, 0x04, 0x02, 0x7F, 0x00, 0x00], // M
        [0x7F, 0x04, 0x08, 0x10, 0x7F, 0x00, 0x00], // N
        [0x3E, 0x41, 0x41, 0x41, 0x3E, 0x00, 0x00], // O
        [0x7F, 0x09, 0x09, 0x09, 0x06, 0x00, 0x00], // P
        [0x3E, 0x41, 0x51, 0x21, 0x5E, 0x00, 0x00], // Q
        [0x7F, 0x09, 0x19, 0x29, 0x46, 0x00, 0x00], // R
        [0x46, 0x49, 0x49, 0x49, 0x31, 0x00, 0x00], // S
        [0x01, 0x01, 0x7F, 0x01, 0x01, 0x00, 0x00], // T
        [0x3F, 0x40, 0x40, 0x40, 0x3F, 0x00, 0x00], // U
        [0x1F, 0x20, 0x40, 0x20, 0x1F, 0x00, 0x00], // V
        [0x7F, 0x20, 0x18, 0x20, 0x7F, 0x00, 0x00], // W
        [0x63, 0x14, 0x08, 0x14, 0x63, 0x00, 0x00], // X
        [0x03, 0x04, 0x78, 0x04, 0x03, 0x00, 0x00], // Y
        [0x61, 0x51, 0x49, 0x45, 0x43, 0x00, 0x00], // Z
        [0x00, 0x00, 0x7F, 0x41, 0x41, 0x00, 0x00], // [
        [0x02, 0x04, 0x08, 0x10, 0x20, 0x00, 0x00], // backslash
        [0x41, 0x41, 0x7F, 0x00, 0x00, 0x00, 0x00], // ]
        [0x04, 0x02, 0x01, 0x02, 0x04, 0x00, 0x00], // ^
        [0x40, 0x40, 0x40, 0x40, 0x40, 0x00, 0x00], // _
        [0x00, 0x01, 0x02, 0x00, 0x00, 0x00, 0x00], // `
        [0x20, 0x54, 0x54, 0x54, 0x78, 0x00, 0x00], // a
        [0x7F, 0x48, 0x44, 0x44, 0x38, 0x00, 0x00], // b
        [0x38, 0x44, 0x44, 0x44, 0x20, 0x00, 0x00], // c
        [0x38, 0x44, 0x44, 0x48, 0x7F, 0x00, 0x00], // d
        [0x38, 0x54, 0x54, 0x54, 0x18, 0x00, 0x00], // e
        [0x08, 0x7E, 0x09, 0x01, 0x02, 0x00, 0x00], // f
        [0x08, 0x14, 0x54, 0x54, 0x38, 0x00, 0x00], // g
        [0x7F, 0x08, 0x04, 0x04, 0x78, 0x00, 0x00], // h
        [0x00, 0x44, 0x7D, 0x40, 0x00, 0x00, 0x00], // i
        [0x20, 0x40, 0x44, 0x3D, 0x00, 0x00, 0x00], // j
        [0x00, 0x7F, 0x10, 0x28, 0x44, 0x00, 0x00], // k
        [0x00, 0x41, 0x7F, 0x40, 0x00, 0x00, 0x00], // l
        [0x7C, 0x04, 0x18, 0x04, 0x78, 0x00, 0x00], // m
        [0x7C, 0x08, 0x04, 0x04, 0x78, 0x00, 0x00], // n
        [0x38, 0x44, 0x44, 0x44, 0x38, 0x00, 0x00], // o
        [0x7C, 0x14, 0x14, 0x14, 0x08, 0x00, 0x00], // p
        [0x08, 0x14, 0x14, 0x18, 0x7C, 0x00, 0x00], // q
        [0x7C, 0x08, 0x04, 0x04, 0x08, 0x00, 0x00], // r
        [0x48, 0x54, 0x54, 0x54, 0x20, 0x00, 0x00], // s
        [0x04, 0x3F, 0x44, 0x40, 0x20, 0x00, 0x00], // t
        [0x3C, 0x40, 0x40, 0x20, 0x7C, 0x00, 0x00], // u
        [0x1C, 0x20, 0x40, 0x20, 0x1C, 0x00, 0x00], // v
        [0x3C, 0x40, 0x30, 0x40, 0x3C, 0x00, 0x00], // w
        [0x44, 0x28, 0x10, 0x28, 0x44, 0x00, 0x00], // x
        [0x0C, 0x50, 0x50, 0x50, 0x3C, 0x00, 0x00], // y
        [0x44, 0x64, 0x54, 0x4C, 0x44, 0x00, 0x00], // z
        [0x00, 0x08, 0x36, 0x41, 0x00, 0x00, 0x00], // {
        [0x00, 0x00, 0x7F, 0x00, 0x00, 0x00, 0x00], // |
        [0x00, 0x41, 0x36, 0x08, 0x00, 0x00, 0x00], // }
        [0x02, 0x01, 0x02, 0x04, 0x02, 0x00, 0x00], // ~
    ];
}

fn draw_text_bitmap_font(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    x: i32,
    y: i32,
    text: &str,
    font_size: f64,
    color: Color,
    alpha: f64,
    font: &BitmapFontData,
) {
    if width == 0
        || height == 0
        || !font_size.is_finite()
        || font_size <= 0.0
        || font.cell_width == 0
        || font.cell_height == 0
    {
        return;
    }
    let columns = font.bitmap.width / font.cell_width;
    let rows = font.bitmap.height / font.cell_height;
    let Some(glyph_count) = columns.checked_mul(rows) else {
        return;
    };
    if columns == 0 || glyph_count == 0 {
        return;
    }
    let target_height = (font_size.ceil() as usize)
        .max(1)
        .min(height.saturating_mul(2).max(1));
    let target_width = ((font_size * font.cell_width as f64 / font.cell_height as f64).ceil()
        as usize)
        .max(1)
        .min(width.saturating_mul(2).max(1));
    let top = y.saturating_sub(i32::try_from(target_height).unwrap_or(i32::MAX));

    for (character_index, character) in text.chars().enumerate() {
        let codepoint = character as u32;
        let Some(glyph_index) = codepoint
            .checked_sub(font.first_codepoint)
            .and_then(|index| usize::try_from(index).ok())
            .filter(|index| *index < glyph_count)
        else {
            continue;
        };
        let source_left = (glyph_index % columns) * font.cell_width;
        let source_top = (glyph_index / columns) * font.cell_height;
        let destination_left = x.saturating_add(
            i32::try_from(character_index.saturating_mul(target_width)).unwrap_or(i32::MAX),
        );
        for destination_y in 0..target_height {
            let source_y = source_top + destination_y * font.cell_height / target_height;
            for destination_x in 0..target_width {
                let source_x = source_left + destination_x * font.cell_width / target_width;
                let sample = font.bitmap.pixels[source_y * font.bitmap.width + source_x];
                let mask = sample.r.max(sample.g).max(sample.b) as f64 / 255.0;
                let coverage = sample.alpha_unit() * mask;
                if coverage == 0.0 {
                    continue;
                }
                blend_pixel(
                    fb,
                    width,
                    height,
                    destination_left
                        .saturating_add(i32::try_from(destination_x).unwrap_or(i32::MAX)),
                    top.saturating_add(i32::try_from(destination_y).unwrap_or(i32::MAX)),
                    color.r as f64,
                    color.g as f64,
                    color.b as f64,
                    alpha * coverage,
                );
            }
        }
    }
}

fn draw_text_builtin(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    x: i32,
    y: i32,
    text: &str,
    font_size: f64,
    color: Color,
    alpha: f64,
) {
    let vector_face = font_size >= 10.0;
    let scale = (font_size / 7.0).max(1.0) as i32;
    let char_w = 5 * scale;
    let char_h = 7 * scale;
    let spacing = if vector_face {
        font_size * 0.82
    } else {
        f64::from(char_w + scale)
    };
    let baseline = f64::from(y);

    for (i, ch) in text.chars().enumerate() {
        let cx = f64::from(x) + i as f64 * spacing;
        if vector_face {
            if let Some(segments) = geometric_font::glyph(ch) {
                let top = baseline - font_size;
                let glyph_width = font_size * 0.68;
                let stroke_width = (font_size * 0.075).max(1.25);
                for &(x0, y0, x1, y1) in segments {
                    draw_line_thick(
                        fb,
                        width,
                        height,
                        cx + f64::from(x0) * glyph_width,
                        top + f64::from(y0) * font_size,
                        cx + f64::from(x1) * glyph_width,
                        top + f64::from(y1) * font_size,
                        color,
                        alpha,
                        stroke_width,
                    );
                }
                continue;
            }
        }
        if let Some(glyph) = font5x7::glyph(ch) {
            for (col, bits) in glyph.iter().take(5).enumerate() {
                for row in 0..7 {
                    if (bits >> row) & 1 != 0 {
                        for sy in 0..scale {
                            for sx in 0..scale {
                                let px = cx.round() as i32 + col as i32 * scale + sx;
                                let py = baseline.round() as i32 - char_h + row * scale + sy;
                                blend_pixel(
                                    fb,
                                    width,
                                    height,
                                    px,
                                    py,
                                    color.r as f64,
                                    color.g as f64,
                                    color.b as f64,
                                    alpha,
                                );
                            }
                        }
                    }
                }
            }
        }
    }
}

// ── Script parser ─────────────────────────────────────────────────

#[derive(Clone, Copy, Debug)]
struct Affine2D {
    a: f64,
    b: f64,
    c: f64,
    d: f64,
    e: f64,
    f: f64,
}
impl Default for Affine2D {
    fn default() -> Self {
        Self {
            a: 1.0,
            b: 0.0,
            c: 0.0,
            d: 1.0,
            e: 0.0,
            f: 0.0,
        }
    }
}
impl Affine2D {
    fn compose(self, rhs: Self) -> Self {
        Self {
            a: self.a * rhs.a + self.c * rhs.b,
            b: self.b * rhs.a + self.d * rhs.b,
            c: self.a * rhs.c + self.c * rhs.d,
            d: self.b * rhs.c + self.d * rhs.d,
            e: self.a * rhs.e + self.c * rhs.f + self.e,
            f: self.b * rhs.e + self.d * rhs.f + self.f,
        }
    }
    fn point(self, p: (f64, f64)) -> (f64, f64) {
        (
            self.a * p.0 + self.c * p.1 + self.e,
            self.b * p.0 + self.d * p.1 + self.f,
        )
    }
    fn is_identity(self) -> bool {
        (self.a - 1.0).abs() < 1e-12
            && self.b.abs() < 1e-12
            && self.c.abs() < 1e-12
            && (self.d - 1.0).abs() < 1e-12
            && self.e.abs() < 1e-12
            && self.f.abs() < 1e-12
    }
}

fn apply_transform(shape: &mut Shape, t: Affine2D) {
    if t.is_identity() {
        return;
    }
    shape.points = shape.points.iter().copied().map(|p| t.point(p)).collect();
    for cmd in &mut shape.path {
        let n = cmd.values.len();
        match cmd.op {
            'M' | 'L' => {
                if n >= 2 {
                    (cmd.values[0], cmd.values[1]) = t.point((cmd.values[0], cmd.values[1]));
                }
            }
            'Q' => {
                if n >= 4 {
                    (cmd.values[0], cmd.values[1]) = t.point((cmd.values[0], cmd.values[1]));
                    (cmd.values[2], cmd.values[3]) = t.point((cmd.values[2], cmd.values[3]));
                }
            }
            'C' => {
                if n >= 6 {
                    for i in (0..6).step_by(2) {
                        (cmd.values[i], cmd.values[i + 1]) =
                            t.point((cmd.values[i], cmd.values[i + 1]));
                    }
                }
            }
            _ => {}
        }
    }
    let original_x = shape.x;
    let original_y = shape.y;
    let original_w = shape.w;
    let original_h = shape.h;
    let origin = t.point((original_x, original_y));
    shape.x = origin.0;
    shape.y = origin.1;
    shape.w *= (t.a * t.a + t.b * t.b).sqrt();
    shape.h *= (t.c * t.c + t.d * t.d).sqrt();
    if matches!(shape.shape_type, ShapeType::Rect | ShapeType::Bitmap)
        && t.b.abs() <= 1e-12
        && t.c.abs() <= 1e-12
    {
        let opposite = t.point((original_x + original_w, original_y + original_h));
        shape.x = origin.0.min(opposite.0);
        shape.y = origin.1.min(opposite.1);
        shape.w = (opposite.0 - origin.0).abs();
        shape.h = (opposite.1 - origin.1).abs();
    }
    shape.r *= ((t.a * t.a + t.b * t.b).sqrt() + (t.c * t.c + t.d * t.d).sqrt()) * 0.5;
    shape.rx *= (t.a * t.a + t.b * t.b).sqrt();
    shape.ry *= (t.c * t.c + t.d * t.d).sqrt();
    if shape.shape_type == ShapeType::Rect && (t.b.abs() > 1e-12 || t.c.abs() > 1e-12) {
        let x = shape.x;
        let y = shape.y;
        let w = shape.w;
        let h = shape.h;
        shape.points = vec![(x, y), (x + w, y), (x + w, y + h), (x, y + h)];
        shape.shape_type = ShapeType::Polygon;
    }
}

fn parse_scene(source: &str) -> Result<Scene, Error> {
    let mut scene = Scene::default();
    let mut transform = Affine2D::default();
    let mut coordinate_transform = Affine2D::default();
    let mut active_clip = None;
    let mut grid_spec: Option<(f64, usize, usize)> = None;
    let mut sprites = HashMap::<String, usize>::new();
    let mut bitmap_font_images = HashMap::<String, BitmapData>::new();

    let mut active_layers = Vec::<String>::new();
    let mut group_depth = 0usize;
    for line in source.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with("//") {
            continue;
        }

        let tokens = tokenize_line(line);
        if tokens.is_empty() {
            continue;
        }

        let cmd = tokens[0].as_str();
        let before_shapes = scene.shapes.len();
        match cmd {
            "canvas" | "background" => parse_canvas(&tokens, &mut scene)?,
            "line" | "segment" => parse_line(&tokens, &mut scene)?,
            "brush" => parse_brush(&tokens, &mut scene)?,
            "rect" | "rectangle" => parse_rect(&tokens, &mut scene)?,
            "rounded_rectangle" => parse_rect(&tokens, &mut scene)?,
            "circle" => parse_circle(&tokens, &mut scene)?,
            "ellipse" | "oval" => parse_ellipse(&tokens, &mut scene)?,
            "polygon" | "triangle" => parse_polygon(&tokens, &mut scene)?,
            "polyline" => parse_polyline(&tokens, &mut scene)?,
            "pixel" => parse_pixel(&tokens, &mut scene)?,
            "bitmap" => parse_bitmap(&tokens, &mut scene)?,
            "bitmap_sprite" => parse_bitmap_sprite(&tokens, &mut scene, &mut sprites)?,
            "bitmap_warp" => parse_bitmap_warp(&tokens, &mut scene)?,
            "raster" => parse_inline_raster(&tokens, &mut scene)?,
            "raster_rle" => parse_inline_raster_rle(&tokens, &mut scene)?,
            "point" => parse_point(&tokens, &mut scene)?,
            "text" => parse_text(&tokens, &mut scene, &mut bitmap_font_images)?,
            "path" => parse_path(&tokens, &mut scene)?,
            "texture" => parse_texture(&tokens, &mut scene)?,
            "raster_filter" => parse_raster_filter(&tokens, &mut scene)?,
            "bezier" => parse_bezier(&tokens, &mut scene)?,
            "arc" => parse_arc(&tokens, &mut scene)?,
            "ngon" => parse_ngon(&tokens, &mut scene)?,
            "star" => parse_star(&tokens, &mut scene)?,
            "flood" => parse_flood(&tokens, &mut scene)?,
            "gradient" => parse_gradient(&tokens, &mut scene)?,
            "opacity" => parse_opacity(&tokens, &mut scene)?,
            "style" => parse_style_update(&tokens, &mut scene)?,
            "layer" => active_layers.push(parse_layer(&tokens, &mut scene)?),
            "endlayer" => {
                if active_layers.pop().is_none() {
                    return Err(Error::syntax("endlayer without layer"));
                }
            }
            "group" => {
                group_depth = group_depth.checked_add(1).ok_or(Error::IllegalQuantity)?;
            }
            "endgroup" => {
                if group_depth == 0 {
                    return Err(Error::syntax("endgroup without group"));
                }
                group_depth -= 1;
            }
            "meta" | "note" => {}
            "sprite" if tokens.len() >= 6 => {
                let id = tokens[1].to_ascii_uppercase();
                let shape = Shape {
                    shape_type: ShapeType::Rect,
                    id: id.clone(),
                    x: parse_coord(&tokens[2]),
                    y: parse_coord(&tokens[3]),
                    w: parse_coord(&tokens[4]),
                    h: parse_coord(&tokens[5]),
                    style: extract_style(&tokens[6..])?,
                    ..Default::default()
                };
                if let Some(index) = sprites.get(&id).copied() {
                    scene.shapes[index] = shape;
                } else {
                    sprites.insert(id, scene.shapes.len());
                    scene.shapes.push(shape);
                }
            }
            "movsprite" if tokens.len() >= 4 => {
                if let Some(index) = sprites.get(&tokens[1].to_ascii_uppercase()).copied() {
                    scene.shapes[index].x = parse_coord(&tokens[2]);
                    scene.shapes[index].y = parse_coord(&tokens[3]);
                }
            }
            "translate" if tokens.len() >= 3 => {
                transform = transform.compose(Affine2D {
                    e: parse_coord(&tokens[1]),
                    f: parse_coord(&tokens[2]),
                    ..Default::default()
                });
            }
            "rotate" if tokens.len() >= 2 => {
                let r = parse_coord(&tokens[1]).to_radians();
                transform = transform.compose(Affine2D {
                    a: r.cos(),
                    b: r.sin(),
                    c: -r.sin(),
                    d: r.cos(),
                    ..Default::default()
                });
            }
            "scale" if tokens.len() >= 2 => {
                let sx = parse_coord(&tokens[1]);
                let sy = if tokens.len() >= 3 {
                    parse_coord(&tokens[2])
                } else {
                    sx
                };
                transform = transform.compose(Affine2D {
                    a: sx,
                    d: sy,
                    ..Default::default()
                });
            }
            "coordinate_transform" if tokens.len() == 5 => {
                let scale_x = parse_coord(&tokens[1]);
                let scale_y = parse_coord(&tokens[2]);
                let translate_x = parse_coord(&tokens[3]);
                let translate_y = parse_coord(&tokens[4]);
                if !scale_x.is_finite()
                    || !scale_y.is_finite()
                    || !translate_x.is_finite()
                    || !translate_y.is_finite()
                    || scale_x == 0.0
                    || scale_y == 0.0
                {
                    return Err(Error::IllegalQuantity);
                }
                coordinate_transform = Affine2D {
                    a: scale_x,
                    d: scale_y,
                    e: translate_x,
                    f: translate_y,
                    ..Default::default()
                };
            }
            "clip" if tokens.len() == 5 => {
                let parse = |value: &str| {
                    value.parse::<usize>().map_err(|_| {
                        Error::syntax("clip coordinates must be non-negative integers")
                    })
                };
                let clip = ClipRect {
                    left: parse(&tokens[1])?,
                    top: parse(&tokens[2])?,
                    right: parse(&tokens[3])?,
                    bottom: parse(&tokens[4])?,
                };
                if clip.left > clip.right || clip.top > clip.bottom {
                    return Err(Error::IllegalQuantity);
                }
                active_clip = Some(clip);
            }
            "clip_reset" if tokens.len() == 1 => active_clip = None,
            "id" => {}
            "depth_grid" | "depth_perception" => {
                grid_spec = Some(parse_depth_grid_spec(&tokens));
            }
            "depth_point" => parse_depth_point(&tokens, &mut scene, grid_spec)?,
            "grid_on" => {
                let Some((h, r, c)) = grid_spec else {
                    return Err(Error::syntax(
                        "grid_on requires depth_grid or depth_perception",
                    ));
                };
                let plane = tokens.get(1).map(String::as_str).unwrap_or("both");
                if plane == "sky" || plane == "both" {
                    append_grid_plane(&mut scene, h, r, c, "sky");
                }
                if plane == "ground" || plane == "both" {
                    append_grid_plane(&mut scene, h, r, c, "ground");
                }
            }
            "grid_off" => scene
                .shapes
                .retain(|shape| !shape.id.starts_with("__depth_grid_")),
            "light_source" => parse_light_source(&tokens, &mut scene)?,
            _ => return Err(Error::syntax(format!("unsupported Artist command {cmd}"))),
        }
        for shape in &mut scene.shapes[before_shapes..] {
            if let Some(layer) = active_layers.last() {
                shape.layer = layer.clone();
            }
            shape.clip = active_clip;
            if !shape.device_space {
                apply_transform(shape, transform.compose(coordinate_transform));
            }
        }
    }

    Ok(scene)
}

fn tokenize_line(line: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    let mut in_quotes = false;
    let mut escape = false;

    for ch in line.chars() {
        if escape {
            current.push(ch);
            escape = false;
        } else if ch == '\\' {
            escape = true;
        } else if ch == '"' {
            in_quotes = !in_quotes;
            current.push(ch);
        } else if ch.is_whitespace() && !in_quotes {
            if !current.is_empty() {
                tokens.push(current.clone());
                current.clear();
            }
        } else {
            current.push(ch);
        }
    }
    if !current.is_empty() {
        tokens.push(current);
    }
    tokens
}

fn parse_kv(token: &str) -> Option<(String, String)> {
    token
        .find('=')
        .map(|eq| (token[..eq].to_string(), token[eq + 1..].to_string()))
}

fn extract_style(tokens: &[String]) -> Result<Style, Error> {
    let mut style = Style::default();
    for token in tokens {
        if let Some((key, val)) = parse_kv(token) {
            match key.as_str() {
                "fill" => {
                    if val == "none" {
                        style.fill = None;
                    } else if let Some(id) = gradient_reference(&val) {
                        style.gradient_id = id.to_string();
                        style.fill = Some(Color::WHITE);
                    } else {
                        style.fill = Some(parse_color(&val)?);
                    }
                }
                "stroke" => {
                    if val == "none" {
                        style.stroke = None;
                    } else {
                        style.stroke = Some(parse_color(&val)?);
                    }
                }
                "stroke-width" | "stroke_width" => {
                    style.stroke_width = val.parse().unwrap_or(1.0);
                }
                "opacity" => {
                    style.opacity = val.parse().unwrap_or(1.0);
                }
                "fill-opacity" | "fill_opacity" => {
                    // Combined with fill alpha
                }
                "font-family" | "font_family" => {
                    style.font_family = val;
                }
                "font-weight" | "font_weight" => {
                    style.font_weight = val;
                }
                "font-style" | "font_style" => {
                    style.font_style = val;
                }
                "text-align" | "text_align" => {
                    style.text_align = val;
                }
                "text-baseline" | "text_baseline" => {
                    style.text_baseline = val;
                }
                "fill-rule" | "fill_rule" => {
                    style.fill_rule = val;
                }
                "composite" | "blend" | "blend-mode" => {
                    if let Some(composite) = BlendMode::from_str(&val) {
                        style.composite = composite;
                    }
                }
                _ => {}
            }
        }
    }
    Ok(style)
}

fn gradient_reference(value: &str) -> Option<&str> {
    value
        .strip_prefix("url(#")
        .and_then(|value| value.strip_suffix(')'))
        .filter(|id| !id.is_empty())
}

fn parse_coord(s: &str) -> f64 {
    s.parse().unwrap_or(0.0)
}

fn parse_light_source(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() != 5 {
        return Err(Error::syntax(
            "light_source expects x, y, intensity, and color",
        ));
    }
    let x = parse_coord(&tokens[1]);
    let y = parse_coord(&tokens[2]);
    let intensity = parse_coord(&tokens[3]);
    if !x.is_finite() || !y.is_finite() || !(0.0..=1.0).contains(&intensity) {
        return Err(Error::IllegalQuantity);
    }

    let mut center = parse_color(&tokens[4])?;
    center.a = (center.a as f64 * intensity).round() as u8;
    let edge = Color::rgba(center.r, center.g, center.b, 0);
    let radius = (scene.width.max(scene.height) as f64 * 0.5).max(1.0);
    let id = format!("__light_{}_{}", scene.gradients.len(), scene.shapes.len());
    scene.gradients.push(GradientDef {
        id: id.clone(),
        kind: "radial".to_string(),
        x1: x,
        y1: y,
        x2: 0.0,
        y2: 0.0,
        fx: x,
        fy: y,
        r2: radius,
        stops: vec![(0.0, center), (1.0, edge)],
    });
    scene.shapes.push(Shape {
        id: format!("{id}_glow"),
        shape_type: ShapeType::Circle,
        x,
        y,
        r: radius,
        style: Style {
            fill: Some(Color::WHITE),
            stroke: None,
            gradient_id: id,
            composite: BlendMode::Screen,
            ..Default::default()
        },
        ..Default::default()
    });
    Ok(())
}

fn parse_depth_grid_spec(tokens: &[String]) -> (f64, usize, usize) {
    let mut horizon = 0.58;
    let mut rows = 8usize;
    let mut rays = 12usize;
    for token in tokens.iter().skip(1) {
        if let Some(v) = token.strip_prefix("horizon=") {
            horizon = v.trim_end_matches('%').parse::<f64>().unwrap_or(58.0);
            if horizon > 1.0 {
                horizon /= 100.0;
            }
        } else if let Some(v) = token.strip_prefix("rows=") {
            rows = v.parse().unwrap_or(rows);
        } else if let Some(v) = token.strip_prefix("rays=") {
            rays = v.parse().unwrap_or(rays);
        }
    }
    (
        horizon.clamp(0.05, 0.95),
        rows.clamp(1, 256),
        rays.clamp(3, 256),
    )
}

fn append_grid_plane(scene: &mut Scene, horizon: f64, rows: usize, rays: usize, plane: &str) {
    let hy = scene.height as f64 * horizon;
    let vp = scene.width as f64 * 0.5;
    let top = plane == "sky";
    let edge = if top { 0.0 } else { scene.height as f64 };
    let stroke = Color::rgba(130, 190, 220, 135);
    for i in 0..=rays {
        let x = scene.width as f64 * i as f64 / rays as f64;
        scene.shapes.push(Shape {
            id: format!("__depth_grid_{plane}_ray_{i}"),
            shape_type: ShapeType::Line,
            points: vec![(vp, hy), (x, edge)],
            style: Style {
                stroke: Some(stroke),
                stroke_width: 0.35,
                ..Default::default()
            },
            ..Default::default()
        });
    }
    // Use one shared span so sky and ground rows are exact mirrors around
    // the horizon, even when the horizon is not vertically centered.
    let mirror_span = hy.min(scene.height as f64 - hy);
    for row in 1..=rows {
        let t = (row as f64 / rows as f64).powf(2.25);
        let y = if top {
            hy - mirror_span * t
        } else {
            hy + mirror_span * t
        };
        scene.shapes.push(Shape {
            id: format!("__depth_grid_{plane}_row_{row}"),
            shape_type: ShapeType::Line,
            points: vec![(0.0, y), (scene.width as f64, y)],
            style: Style {
                stroke: Some(stroke),
                stroke_width: 0.35,
                ..Default::default()
            },
            ..Default::default()
        });
    }
    if plane == "ground" {
        scene.shapes.push(Shape {
            id: "__depth_grid_horizon".to_string(),
            shape_type: ShapeType::Line,
            points: vec![(0.0, hy), (scene.width as f64, hy)],
            style: Style {
                stroke: Some(Color::rgba(220, 190, 150, 220)),
                stroke_width: 2.0,
                ..Default::default()
            },
            ..Default::default()
        });
    }
}

fn parse_depth_point(
    tokens: &[String],
    scene: &mut Scene,
    spec: Option<(f64, usize, usize)>,
) -> Result<(), Error> {
    let Some((horizon, rows, rays)) = spec else {
        return Err(Error::syntax(
            "depth_point requires depth_grid or depth_perception",
        ));
    };
    let mut row = 1usize;
    let mut col = 0usize;
    let mut plane = "ground";
    let mut radius = 10.0;
    let mut fill = Color::WHITE;
    for token in tokens.iter().skip(1) {
        if let Some((k, v)) = parse_kv(token) {
            match k.as_str() {
                "row" => row = v.parse().unwrap_or(1),
                "col" => {
                    col = v
                        .bytes()
                        .next()
                        .map(|b| b.to_ascii_uppercase().saturating_sub(b'A') as usize)
                        .unwrap_or(0);
                }
                "plane" => plane = if v == "sky" { "sky" } else { "ground" },
                "radius" => radius = v.parse().unwrap_or(radius),
                "fill" => fill = parse_color(&v)?,
                _ => {}
            }
        }
    }
    row = row.clamp(1, rows);
    col = col.min(rays);
    let hy = scene.height as f64 * horizon;
    let edge = if plane == "sky" {
        0.0
    } else {
        scene.height as f64
    };
    let t = 1.0 - (row.saturating_sub(1) as f64 / rows.max(1) as f64);
    let y = hy + (edge - hy) * t;
    let x = scene.width as f64 * col as f64 / rays as f64
        + (scene.width as f64 * 0.5 - scene.width as f64 * col as f64 / rays as f64) * (1.0 - t);
    let scale = 0.35 + 0.65 * t;
    scene.shapes.push(Shape {
        id: format!("depth_point_{}_{}", row, col),
        shape_type: ShapeType::Circle,
        x,
        y: if plane == "ground" {
            y - radius * scale
        } else {
            y
        },
        r: radius * scale,
        style: Style {
            fill: Some(fill),
            stroke: None,
            ..Default::default()
        },
        ..Default::default()
    });
    Ok(())
}

fn parse_canvas(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 4 {
        scene.width = parse_coord(&tokens[1]).max(1.0) as u32;
        scene.height = parse_coord(&tokens[2]).max(1.0) as u32;
        scene.background = parse_color(&tokens[3])?;
    } else if tokens.len() >= 3 {
        scene.width = parse_coord(&tokens[1]).max(1.0) as u32;
        scene.height = parse_coord(&tokens[2]).max(1.0) as u32;
    }
    Ok(())
}

fn parse_brush(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() != 10 {
        return Err(Error::syntax(
            "brush expects x1, y1, x2, y2, size, color, hardness, opacity, and flow",
        ));
    }
    let x1 = parse_coord(&tokens[1]);
    let y1 = parse_coord(&tokens[2]);
    let x2 = parse_coord(&tokens[3]);
    let y2 = parse_coord(&tokens[4]);
    let size = parse_coord(&tokens[5]);
    let mut color = parse_color(&tokens[6])?;
    let hardness = parse_coord(&tokens[7]);
    let opacity = parse_coord(&tokens[8]);
    let flow = parse_coord(&tokens[9]);
    if ![x1, y1, x2, y2, size, hardness, opacity, flow]
        .iter()
        .all(|value| value.is_finite())
        || !(0.1..=2_048.0).contains(&size)
        || !(0.0..=1.0).contains(&hardness)
        || !(0.0..=1.0).contains(&opacity)
        || !(0.0..=1.0).contains(&flow)
    {
        return Err(Error::IllegalQuantity);
    }
    const LAYERS: usize = 8;
    let target_alpha = opacity * flow * color.alpha_unit();
    let layer_alpha = 1.0 - (1.0 - target_alpha).powf(1.0 / LAYERS as f64);
    color.a = (layer_alpha * 255.0).round().clamp(0.0, 255.0) as u8;
    for layer in 0..LAYERS {
        let fraction = layer as f64 / (LAYERS - 1) as f64;
        let width = size * (1.0 - fraction * (1.0 - hardness));
        scene.shapes.push(Shape {
            shape_type: ShapeType::Line,
            points: vec![(x1, y1), (x2, y2)],
            style: Style {
                stroke: Some(color),
                fill: None,
                stroke_width: width,
                ..Default::default()
            },
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_line(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 5 {
        let style = extract_style(&tokens[5..])?;
        scene.shapes.push(Shape {
            shape_type: ShapeType::Line,
            points: vec![
                (parse_coord(&tokens[1]), parse_coord(&tokens[2])),
                (parse_coord(&tokens[3]), parse_coord(&tokens[4])),
            ],
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_rect(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 5 {
        let style = extract_style(&tokens[5..])?;
        let rx = if tokens[0] == "rounded_rectangle" && tokens.len() > 5 {
            parse_coord(&tokens[5])
        } else {
            0.0
        };
        scene.shapes.push(Shape {
            shape_type: ShapeType::Rect,
            x: parse_coord(&tokens[1]),
            y: parse_coord(&tokens[2]),
            w: parse_coord(&tokens[3]),
            h: parse_coord(&tokens[4]),
            rx,
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_circle(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 4 {
        let style = extract_style(&tokens[4..])?;
        scene.shapes.push(Shape {
            shape_type: ShapeType::Circle,
            x: parse_coord(&tokens[1]),
            y: parse_coord(&tokens[2]),
            r: parse_coord(&tokens[3]),
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_flood(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 3 {
        scene.shapes.push(Shape {
            shape_type: ShapeType::FloodFill,
            x: parse_coord(&tokens[1]),
            y: parse_coord(&tokens[2]),
            style: extract_style(&tokens[3..])?,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_ellipse(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 5 {
        let style = extract_style(&tokens[5..])?;
        scene.shapes.push(Shape {
            shape_type: ShapeType::Ellipse,
            x: parse_coord(&tokens[1]),
            y: parse_coord(&tokens[2]),
            rx: parse_coord(&tokens[3]),
            ry: parse_coord(&tokens[4]),
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_polygon(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    let mut points = Vec::new();
    let mut i = 1;
    while i + 1 < tokens.len() {
        if tokens[i].contains('=') || tokens[i + 1].contains('=') {
            break;
        }
        points.push((parse_coord(&tokens[i]), parse_coord(&tokens[i + 1])));
        i += 2;
    }
    if points.len() >= 3 {
        let style = extract_style(&tokens[i..])?;
        scene.shapes.push(Shape {
            shape_type: ShapeType::Polygon,
            points,
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_polyline(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    let mut points = Vec::new();
    let mut i = 1;
    while i + 1 < tokens.len() {
        if tokens[i].contains('=') || tokens[i + 1].contains('=') {
            break;
        }
        points.push((parse_coord(&tokens[i]), parse_coord(&tokens[i + 1])));
        i += 2;
    }
    if points.len() >= 2 {
        let style = extract_style(&tokens[i..])?;
        // Store as Line with multiple points (polyline rendering)
        scene.shapes.push(Shape {
            shape_type: ShapeType::Line,
            points,
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn bitmap_texture_cache_key(path: &str, key: Option<Color>) -> String {
    match key {
        Some(key) => format!(
            "{path}\0{:02x}{:02x}{:02x}{:02x}",
            key.r, key.g, key.b, key.a
        ),
        None => format!("{path}\0none"),
    }
}

fn decode_bitmap_data(path: &str, key: Option<Color>) -> Result<BitmapData, Error> {
    let source_path = std::path::Path::new(path);
    let resident = image_codec::is_memory_image_path(source_path);
    let cache_key = bitmap_texture_cache_key(path, key);
    if resident {
        if let Some(bitmap) =
            BITMAP_TEXTURE_CACHE.with(|cache| cache.borrow().images.get(&cache_key).cloned())
        {
            return Ok(bitmap);
        }
    }

    let image = image_codec::decode_image(source_path)?;
    let pixels = image
        .pixels
        .iter()
        .zip(&image.alpha)
        .map(|(pixel, alpha)| {
            let mut color = Color::rgba(pixel[0], pixel[1], pixel[2], *alpha);
            if key.is_some_and(|key| color.r == key.r && color.g == key.g && color.b == key.b) {
                color.a = 0;
            }
            color
        })
        .collect::<Vec<_>>();
    let bitmap = BitmapData {
        width: image.width,
        height: image.height,
        pixels: Arc::from(pixels),
    };
    if resident {
        let bytes = bitmap
            .pixels
            .len()
            .saturating_mul(std::mem::size_of::<Color>());
        if bytes <= MAX_BITMAP_TEXTURE_CACHE_BYTES {
            BITMAP_TEXTURE_CACHE.with(|cache| {
                let mut cache = cache.borrow_mut();
                if cache.bytes.saturating_add(bytes) > MAX_BITMAP_TEXTURE_CACHE_BYTES {
                    cache.images.clear();
                    cache.bytes = 0;
                }
                cache.images.insert(cache_key, bitmap.clone());
                cache.bytes += bytes;
            });
        }
    }
    Ok(bitmap)
}

fn parse_bitmap(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() < 6 {
        return Ok(());
    }
    let path = unquote(&tokens[1]);
    let x = parse_coord(&tokens[2]);
    let y = parse_coord(&tokens[3]);
    let w = parse_coord(&tokens[4]);
    let h = parse_coord(&tokens[5]);
    let bitmap = decode_bitmap_data(&path, None)?;
    scene.shapes.push(Shape {
        shape_type: ShapeType::Bitmap,
        x,
        y,
        w,
        h,
        bitmap: Some(bitmap),
        ..Default::default()
    });
    Ok(())
}
fn parse_bitmap_sprite(
    tokens: &[String],
    scene: &mut Scene,
    sprites: &mut HashMap<String, usize>,
) -> Result<(), Error> {
    if tokens.len() < 7 {
        return Err(Error::syntax(
            "bitmap_sprite requires id, path, x, y, width, and height",
        ));
    }
    let id = tokens[1].to_ascii_uppercase();
    let path = unquote(&tokens[2]);
    let x = parse_coord(&tokens[3]);
    let y = parse_coord(&tokens[4]);
    let w = parse_coord(&tokens[5]);
    let h = parse_coord(&tokens[6]);
    let key = tokens[7..]
        .iter()
        .find_map(|token| parse_kv(token).filter(|(name, _)| name == "key"))
        .map(|(_, value)| parse_color(&value))
        .transpose()?;
    let tint = tokens[7..]
        .iter()
        .find_map(|token| parse_kv(token).filter(|(name, _)| name == "tint"))
        .map(|(_, value)| parse_color(&value))
        .transpose()?
        .unwrap_or(Color::WHITE);
    let angle = tokens[7..]
        .iter()
        .find_map(|token| parse_kv(token).filter(|(name, _)| name == "angle"))
        .map(|(_, value)| {
            value
                .parse::<f64>()
                .map_err(|_| Error::syntax("bitmap_sprite angle must be a finite number"))
        })
        .transpose()?;
    let aim = tokens[7..]
        .iter()
        .find_map(|token| parse_kv(token).filter(|(name, _)| name == "aim"))
        .map(|(_, value)| {
            value
                .parse::<f64>()
                .map_err(|_| Error::syntax("bitmap_sprite aim must be a finite number"))
        })
        .transpose()?;
    if angle.is_some_and(|angle| !angle.is_finite())
        || aim.is_some_and(|aim| !aim.is_finite() || !(-2.0..=2.0).contains(&aim))
    {
        return Err(Error::IllegalQuantity);
    }
    let (x, y, bitmap_warp) = if angle.is_some() || aim.is_some() {
        (
            x + w * 0.5,
            y + h,
            Some(BitmapWarp {
                angle: angle.unwrap_or(0.0),
                bend: 0.0,
                turn: 0.0,
                aim: aim.unwrap_or(0.0),
                light: 1.0,
            }),
        )
    } else {
        (x, y, None)
    };
    let shape = Shape {
        shape_type: ShapeType::Bitmap,
        id: id.clone(),
        x,
        y,
        w,
        h,
        bitmap: Some(decode_bitmap_data(&path, key)?),
        bitmap_tint: tint,
        bitmap_warp,
        ..Default::default()
    };
    if let Some(index) = sprites.get(&id).copied() {
        scene.shapes[index] = shape;
    } else {
        sprites.insert(id, scene.shapes.len());
        scene.shapes.push(shape);
    }
    Ok(())
}

fn parse_inline_raster(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() < 6 {
        return Err(Error::syntax(
            "raster requires x, y, width, height, and ARGB pixels",
        ));
    }
    let parse_size = |value: &str| {
        value
            .parse::<usize>()
            .map_err(|_| Error::syntax("raster dimensions must be non-negative integers"))
    };
    let x = parse_size(&tokens[1])?;
    let y = parse_size(&tokens[2])?;
    let width = parse_size(&tokens[3])?;
    let height = parse_size(&tokens[4])?;
    let expected = width.checked_mul(height).ok_or(Error::IllegalQuantity)?;
    if width == 0
        || height == 0
        || expected > MAX_ARTIST_PIXELS
        || tokens.len() != expected.saturating_add(5)
    {
        return Err(Error::syntax(
            "raster pixel count does not match its dimensions",
        ));
    }
    let pixels = tokens[5..]
        .iter()
        .map(|pixel| {
            if pixel.len() != 8 {
                return Err(Error::syntax(
                    "raster pixels must be eight-digit ARGB values",
                ));
            }
            let argb = u32::from_str_radix(pixel, 16)
                .map_err(|_| Error::syntax("raster pixels must be hexadecimal ARGB values"))?;
            Ok(Color::rgba(
                (argb >> 16) as u8,
                (argb >> 8) as u8,
                argb as u8,
                (argb >> 24) as u8,
            ))
        })
        .collect::<Result<Vec<_>, Error>>()?;
    scene.shapes.push(Shape {
        shape_type: ShapeType::Bitmap,
        x: x as f64,
        y: y as f64,
        w: width as f64,
        h: height as f64,
        bitmap: Some(BitmapData {
            width,
            height,
            pixels: Arc::from(pixels),
        }),
        device_space: true,
        ..Default::default()
    });
    Ok(())
}

fn parse_inline_raster_rle(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() < 6 {
        return Err(Error::syntax(
            "raster_rle requires x, y, width, height, and ARGB runs",
        ));
    }
    let parse_size = |value: &str| {
        value
            .parse::<usize>()
            .map_err(|_| Error::syntax("raster_rle dimensions must be non-negative integers"))
    };
    let x = parse_size(&tokens[1])?;
    let y = parse_size(&tokens[2])?;
    let width = parse_size(&tokens[3])?;
    let height = parse_size(&tokens[4])?;
    let expected = width.checked_mul(height).ok_or(Error::IllegalQuantity)?;
    if width == 0 || height == 0 || expected > MAX_ARTIST_PIXELS {
        return Err(Error::syntax(
            "raster_rle pixel count does not match its dimensions",
        ));
    }
    let mut pixels = Vec::with_capacity(expected);
    for token in &tokens[5..] {
        let (length, pixel) = token
            .split_once(':')
            .ok_or_else(|| Error::syntax("raster_rle runs must use count:ARGB"))?;
        let length = length
            .parse::<usize>()
            .map_err(|_| Error::syntax("raster_rle run counts must be positive integers"))?;
        if length == 0 || pixel.len() != 8 {
            return Err(Error::syntax(
                "raster_rle runs require a positive count and eight-digit ARGB",
            ));
        }
        let argb = u32::from_str_radix(pixel, 16)
            .map_err(|_| Error::syntax("raster_rle pixels must be hexadecimal ARGB values"))?;
        let next_len = pixels
            .len()
            .checked_add(length)
            .ok_or(Error::IllegalQuantity)?;
        if next_len > expected {
            return Err(Error::syntax(
                "raster_rle pixel count does not match its dimensions",
            ));
        }
        pixels.resize(
            next_len,
            Color::rgba(
                (argb >> 16) as u8,
                (argb >> 8) as u8,
                argb as u8,
                (argb >> 24) as u8,
            ),
        );
    }
    if pixels.len() != expected {
        return Err(Error::syntax(
            "raster_rle pixel count does not match its dimensions",
        ));
    }
    scene.shapes.push(Shape {
        shape_type: ShapeType::Bitmap,
        x: x as f64,
        y: y as f64,
        w: width as f64,
        h: height as f64,
        bitmap: Some(BitmapData {
            width,
            height,
            pixels: Arc::from(pixels),
        }),
        device_space: true,
        ..Default::default()
    });
    Ok(())
}

fn parse_bitmap_warp(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() < 10 {
        return Err(Error::syntax(
            "bitmap_warp requires path, anchor, size, angle, bend, turn, and light",
        ));
    }
    let path = unquote(&tokens[1]);
    let anchor_x = parse_coord(&tokens[2]);
    let anchor_y = parse_coord(&tokens[3]);
    let width = parse_coord(&tokens[4]);
    let height = parse_coord(&tokens[5]);
    let angle = parse_coord(&tokens[6]);
    let bend = parse_coord(&tokens[7]);
    let turn = parse_coord(&tokens[8]);
    let light = parse_coord(&tokens[9]);
    if width <= 0.0
        || height <= 0.0
        || !(-1.0..=1.0).contains(&bend)
        || !(-1.0..=1.0).contains(&turn)
        || !(0.0..=2.0).contains(&light)
    {
        return Err(Error::IllegalQuantity);
    }
    let image = image_codec::decode_image(std::path::Path::new(&path))?;
    let pixels = image
        .pixels
        .iter()
        .zip(&image.alpha)
        .map(|(pixel, alpha)| Color::rgba(pixel[0], pixel[1], pixel[2], *alpha))
        .collect::<Vec<_>>();
    scene.shapes.push(Shape {
        shape_type: ShapeType::Bitmap,
        x: anchor_x,
        y: anchor_y,
        w: width,
        h: height,
        bitmap_warp: Some(BitmapWarp {
            angle,
            bend,
            turn,
            aim: 0.0,
            light,
        }),
        bitmap: Some(BitmapData {
            width: image.width,
            height: image.height,
            pixels: Arc::from(pixels),
        }),
        ..Default::default()
    });
    Ok(())
}

fn parse_pixel(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 3 {
        let style = extract_style(&tokens[3..])?;
        scene.shapes.push(Shape {
            shape_type: ShapeType::Pixel,
            x: parse_coord(&tokens[1]),
            y: parse_coord(&tokens[2]),
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_point(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 4 {
        let style = extract_style(&tokens[4..])?;
        scene.shapes.push(Shape {
            shape_type: ShapeType::Circle,
            x: parse_coord(&tokens[1]),
            y: parse_coord(&tokens[2]),
            r: parse_coord(&tokens[3]),
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_bitmap_font(
    tokens: &[String],
    font_cache: &mut HashMap<String, BitmapData>,
) -> Result<Option<BitmapFontData>, Error> {
    let mut path = None;
    let mut cell_width = 0usize;
    let mut cell_height = 0usize;
    let mut first_codepoint = 32u32;
    for token in tokens {
        let Some((name, value)) = parse_kv(token) else {
            continue;
        };
        match name.as_str() {
            "bitmap-font" => path = Some(unquote(&value)),
            "font-cell-width" => {
                cell_width = value
                    .parse()
                    .map_err(|_| Error::syntax("font cell width must be an integer"))?
            }
            "font-cell-height" => {
                cell_height = value
                    .parse()
                    .map_err(|_| Error::syntax("font cell height must be an integer"))?
            }
            "font-first" => {
                first_codepoint = value
                    .parse()
                    .map_err(|_| Error::syntax("font first codepoint must be an integer"))?
            }
            _ => {}
        }
    }
    let Some(path) = path else {
        return Ok(None);
    };
    if cell_width == 0 || cell_height == 0 {
        return Err(Error::syntax("bitmap font cells must be nonzero"));
    }
    let bitmap = if let Some(bitmap) = font_cache.get(&path) {
        bitmap.clone()
    } else {
        let bitmap = decode_bitmap_data(&path, None)?;
        font_cache.insert(path.clone(), bitmap.clone());
        bitmap
    };
    if bitmap.width % cell_width != 0 || bitmap.height % cell_height != 0 {
        return Err(Error::syntax(
            "bitmap font image dimensions must be exact multiples of its cell size",
        ));
    }
    let glyph_count = (bitmap.width / cell_width)
        .checked_mul(bitmap.height / cell_height)
        .ok_or(Error::IllegalQuantity)?;
    if glyph_count == 0
        || first_codepoint
            .checked_add(u32::try_from(glyph_count).map_err(|_| Error::IllegalQuantity)?)
            .is_none()
    {
        return Err(Error::IllegalQuantity);
    }
    Ok(Some(BitmapFontData {
        bitmap,
        cell_width,
        cell_height,
        first_codepoint,
    }))
}

fn parse_text(
    tokens: &[String],
    scene: &mut Scene,
    font_cache: &mut HashMap<String, BitmapData>,
) -> Result<(), Error> {
    if tokens.len() >= 5 {
        let style = extract_style(&tokens[5..])?;
        let bitmap_font = parse_bitmap_font(&tokens[5..], font_cache)?;
        scene.shapes.push(Shape {
            shape_type: ShapeType::Text,
            x: parse_coord(&tokens[1]),
            y: parse_coord(&tokens[2]),
            font_size: parse_coord(&tokens[3]),
            text: unquote(&tokens[4]),
            style,
            bitmap_font,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_path(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 2 {
        let path_data = unquote(&tokens[1]);
        let style = extract_style(&tokens[2..])?;
        let path = parse_path_data(&path_data);
        scene.shapes.push(Shape {
            shape_type: ShapeType::Path,
            path,
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_texture(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() < 7 {
        return Err(Error::syntax(
            "texture requires path, seed, scale, octaves, and two colors",
        ));
    }
    let path_data = unquote(&tokens[1]);
    let seed = tokens[2]
        .parse::<i64>()
        .map_err(|_| Error::syntax("texture seed must be an integer"))?;
    let scale = tokens[3]
        .parse::<f64>()
        .map_err(|_| Error::syntax("texture scale must be numeric"))?;
    let octaves = tokens[4]
        .parse::<u8>()
        .map_err(|_| Error::syntax("texture octaves must be an integer"))?;
    if path_data.is_empty()
        || !scale.is_finite()
        || !(0.25..=4096.0).contains(&scale)
        || !(1..=8).contains(&octaves)
    {
        return Err(Error::IllegalQuantity);
    }
    scene.shapes.push(Shape {
        shape_type: ShapeType::TexturePath,
        path: parse_path_data(&path_data),
        style: extract_style(&tokens[7..])?,
        texture: Some(TexturePaint {
            seed,
            scale,
            octaves,
            low: parse_color(&tokens[5])?,
            high: parse_color(&tokens[6])?,
        }),
        ..Default::default()
    });
    Ok(())
}

fn parse_raster_filter(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    let mode = tokens
        .get(1)
        .map(|mode| mode.to_ascii_lowercase())
        .ok_or_else(|| Error::syntax("raster_filter requires a mode"))?;
    let values = tokens[2..]
        .iter()
        .map(|value| {
            value
                .parse::<f64>()
                .map_err(|_| Error::syntax("raster_filter parameters must be numeric"))
        })
        .collect::<Result<Vec<_>, _>>()?;
    if values.iter().any(|value| !value.is_finite()) {
        return Err(Error::RealOverflow);
    }
    let filter = match (mode.as_str(), values.as_slice()) {
        ("blur", [radius]) if (0.0..=32.0).contains(radius) => RasterFilter::Blur {
            radius: radius.round() as usize,
        },
        ("sharpen", [amount]) if (0.0..=4.0).contains(amount) => {
            RasterFilter::Sharpen { amount: *amount }
        }
        ("color", [brightness, contrast, saturation])
            if [brightness, contrast, saturation]
                .into_iter()
                .all(|value| (0.0..=4.0).contains(value)) =>
        {
            RasterFilter::Color {
                brightness: *brightness,
                contrast: *contrast,
                saturation: *saturation,
            }
        }
        _ => return Err(Error::IllegalQuantity),
    };
    scene.shapes.push(Shape {
        shape_type: ShapeType::RasterFilter,
        raster_filter: Some(filter),
        ..Default::default()
    });
    Ok(())
}

fn parse_path_data(data: &str) -> Vec<PathCommand> {
    let mut commands = Vec::new();
    let mut chars = data.chars().peekable();
    while let Some(&ch) = chars.peek() {
        if ch.is_alphabetic() {
            chars.next();
            let mut values = Vec::new();
            // Read all numbers after the command letter
            while let Some(&peek) = chars.peek() {
                if peek.is_alphabetic() {
                    break;
                }
                if peek.is_whitespace() || peek == ',' {
                    chars.next();
                    continue;
                }
                // Read a number
                let mut num = String::new();
                if peek == '-' || peek == '+' {
                    num.push(chars.next().unwrap());
                }
                while let Some(&d) = chars.peek() {
                    if d.is_ascii_digit() || d == '.' {
                        num.push(chars.next().unwrap());
                    } else {
                        break;
                    }
                }
                if let Ok(v) = num.parse::<f64>() {
                    values.push(v);
                }
            }
            commands.push(PathCommand { op: ch, values });
        } else {
            chars.next();
        }
    }
    commands
}

fn parse_bezier(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 9 {
        let style = extract_style(&tokens[9..])?;
        let p0 = (parse_coord(&tokens[1]), parse_coord(&tokens[2]));
        let c1 = (parse_coord(&tokens[3]), parse_coord(&tokens[4]));
        let c2 = (parse_coord(&tokens[5]), parse_coord(&tokens[6]));
        let p1 = (parse_coord(&tokens[7]), parse_coord(&tokens[8]));
        // Convert to path with C command
        scene.shapes.push(Shape {
            shape_type: ShapeType::Path,
            path: vec![
                PathCommand {
                    op: 'M',
                    values: vec![p0.0, p0.1],
                },
                PathCommand {
                    op: 'C',
                    values: vec![c1.0, c1.1, c2.0, c2.1, p1.0, p1.1],
                },
            ],
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_arc(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 7 {
        let cx = parse_coord(&tokens[1]);
        let cy = parse_coord(&tokens[2]);
        let rx = parse_coord(&tokens[3]);
        let ry = parse_coord(&tokens[4]);
        let start = parse_coord(&tokens[5]);
        let end = parse_coord(&tokens[6]);
        let style = extract_style(&tokens[7..])?;
        // Convert to path with A command (SVG arc)
        let sx = cx + rx * start.to_radians().cos();
        let sy = cy + ry * start.to_radians().sin();
        let ex = cx + rx * end.to_radians().cos();
        let ey = cy + ry * end.to_radians().sin();
        let large = if (end - start).abs() > 180.0 {
            1.0
        } else {
            0.0
        };
        scene.shapes.push(Shape {
            shape_type: ShapeType::Path,
            path: vec![
                PathCommand {
                    op: 'M',
                    values: vec![sx, sy],
                },
                PathCommand {
                    op: 'A',
                    values: vec![rx, ry, 0.0, large, 1.0, ex, ey],
                },
            ],
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_ngon(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 5 {
        let cx = parse_coord(&tokens[1]);
        let cy = parse_coord(&tokens[2]);
        let sides = parse_coord(&tokens[3]) as i32;
        let radius = parse_coord(&tokens[4]);
        let style = extract_style(&tokens[5..])?;
        // Compute points
        let mut points = Vec::new();
        for i in 0..sides {
            let angle = 2.0 * std::f64::consts::PI * (i as f64) / (sides as f64)
                - std::f64::consts::PI / 2.0;
            points.push((cx + radius * angle.cos(), cy + radius * angle.sin()));
        }
        scene.shapes.push(Shape {
            shape_type: ShapeType::Polygon,
            points,
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_star(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 6 {
        let cx = parse_coord(&tokens[1]);
        let cy = parse_coord(&tokens[2]);
        let n = parse_coord(&tokens[3]) as i32;
        let outer = parse_coord(&tokens[4]);
        let inner = parse_coord(&tokens[5]);
        let style = extract_style(&tokens[6..])?;
        // Compute star points
        let mut points = Vec::new();
        for i in 0..(n * 2) {
            let radius = if i % 2 == 0 { outer } else { inner };
            let angle = std::f64::consts::PI * (i as f64) / (n as f64) - std::f64::consts::PI / 2.0;
            points.push((cx + radius * angle.cos(), cy + radius * angle.sin()));
        }
        scene.shapes.push(Shape {
            shape_type: ShapeType::Polygon,
            points,
            style,
            ..Default::default()
        });
    }
    Ok(())
}

fn parse_gradient(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() < 6 {
        return Ok(());
    }
    let id = tokens[1].clone();
    let kind = if tokens.len() > 2 && tokens[2] == "kind=radial" {
        "radial".to_string()
    } else {
        "linear".to_string()
    };

    if kind == "radial" && tokens.len() < 9 {
        return Ok(());
    }
    let (x1, y1, x2, y2, fx, fy, r2, stops_start) = if kind == "radial" {
        (
            parse_coord(&tokens[3]),
            parse_coord(&tokens[4]),
            0.0,
            0.0,
            parse_coord(&tokens[5]),
            parse_coord(&tokens[6]),
            parse_coord(&tokens[8]),
            9,
        )
    } else {
        (
            parse_coord(&tokens[2]),
            parse_coord(&tokens[3]),
            parse_coord(&tokens[4]),
            parse_coord(&tokens[5]),
            0.0,
            0.0,
            0.0,
            6,
        )
    };

    let mut stops = Vec::new();
    for token in &tokens[stops_start..] {
        if let Some((key, val)) = parse_kv(token) {
            if key == "stop" {
                if let Some(comma) = val.find(',') {
                    let offset: f64 = val[..comma].parse().unwrap_or(0.0);
                    let color = parse_color(&val[comma + 1..])?;
                    stops.push((offset, color));
                }
            }
        }
    }
    scene.gradients.push(GradientDef {
        id,
        kind,
        x1,
        y1,
        x2,
        y2,
        fx,
        fy,
        r2,
        stops,
    });
    Ok(())
}

fn parse_opacity(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    if tokens.len() >= 2 {
        let opacity = parse_coord(&tokens[1]);
        // Apply to the most recent shape
        if let Some(shape) = scene.shapes.last_mut() {
            shape.style.opacity = opacity;
        }
    }
    Ok(())
}

fn parse_style_update(tokens: &[String], scene: &mut Scene) -> Result<(), Error> {
    let Some(shape) = scene.shapes.last_mut() else {
        return Ok(());
    };
    for token in tokens.iter().skip(1) {
        let Some((key, value)) = parse_kv(token) else {
            continue;
        };
        if matches!(key.as_str(), "composite" | "blend" | "blend-mode") {
            if let Some(mode) = BlendMode::from_str(&value) {
                shape.style.composite = mode;
            }
        }
    }
    Ok(())
}

fn parse_layer(tokens: &[String], scene: &mut Scene) -> Result<String, Error> {
    let id = tokens
        .get(1)
        .filter(|id| !id.is_empty())
        .cloned()
        .ok_or_else(|| Error::syntax("layer requires an identifier"))?;
    let mut visible = true;
    let mut opacity = 1.0_f64;
    for token in &tokens[2..] {
        if let Some((key, val)) = parse_kv(token) {
            match key.as_str() {
                "visible" => visible = val == "true",
                "opacity" => opacity = val.parse().unwrap_or(1.0),
                _ => {}
            }
        }
    }
    opacity = opacity.clamp(0.0, 1.0);
    scene.layers.push(ShapeLayer {
        id: id.clone(),
        name: String::new(),
        visible,
        opacity,
    });
    Ok(id)
}

fn unquote(s: &str) -> String {
    let s = s.trim();
    if s.starts_with('"') && s.ends_with('"') && s.len() >= 2 {
        s[1..s.len() - 1]
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
            .replace("\\n", "\n")
            .replace("\\r", "\r")
    } else {
        s.to_string()
    }
}

// ── Utilities ─────────────────────────────────────────────────────

fn fmt(value: f64) -> String {
    if value == value.trunc() && value.abs() < 1e15 {
        format!("{}", value as i64)
    } else {
        format!("{:.3}", value)
            .trim_end_matches('0')
            .trim_end_matches('.')
            .to_string()
    }
}

fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn xml_comment_escape(s: &str) -> String {
    s.replace("--", "")
}
// ── Arc flattening ──

/// Flatten an SVG arc command into line segments.
/// Approximates the arc with straight segments.
fn flatten_arc(
    cur: (f64, f64),
    rx: f64,
    ry: f64,
    x_axis_rot: f64,
    large_arc: bool,
    sweep: bool,
    end: (f64, f64),
) -> Vec<(f64, f64)> {
    // If endpoints are equal, no arc
    let dx = end.0 - cur.0;
    let dy = end.1 - cur.1;
    if dx.abs() < 1e-6 && dy.abs() < 1e-6 {
        return vec![end];
    }

    // If either radius is 0, treat as line
    if rx.abs() < 1e-6 || ry.abs() < 1e-6 {
        return vec![end];
    }

    // Convert to radians
    let phi = x_axis_rot.to_radians();
    let cos_phi = phi.cos();
    let sin_phi = phi.sin();

    // Step 1: compute (x1', y1')
    let x1p = (cos_phi * dx + sin_phi * dy) / 2.0;
    let y1p = (-sin_phi * dx + cos_phi * dy) / 2.0;

    // Step 2: compute (cx', cy')
    let rx2 = rx * rx;
    let ry2 = ry * ry;
    let x1p2 = x1p * x1p;
    let y1p2 = y1p * y1p;

    let lambda = (x1p2 * ry2 + y1p2 * rx2) / (rx2 * ry2);
    let factor = if lambda > 1.0 { lambda.sqrt() } else { 1.0 };

    let rx_adj = rx * factor;
    let ry_adj = ry * factor;
    let rx2_adj = rx_adj * rx_adj;
    let ry2_adj = ry_adj * ry_adj;

    let denom = rx2_adj * y1p2 + ry2_adj * x1p2;
    let num = rx2_adj * ry2_adj - denom;
    let coeff = if num < 0.0 { 0.0 } else { (num / denom).sqrt() };
    let sign = if large_arc == sweep { -1.0 } else { 1.0 };
    let cxp = sign * coeff * (rx_adj * y1p) / ry_adj;
    let cyp = sign * coeff * -(ry_adj * x1p) / rx_adj;

    // Step 3: compute (cx, cy)
    let cx = cos_phi * cxp - sin_phi * cyp + (cur.0 + end.0) / 2.0;
    let cy = sin_phi * cxp + cos_phi * cyp + (cur.1 + end.1) / 2.0;

    // Step 4: compute theta1 and delta_theta
    let ux = (x1p - cxp) / rx_adj;
    let uy = (y1p - cyp) / ry_adj;
    let vx = (-x1p - cxp) / rx_adj;
    let vy = (-y1p - cyp) / ry_adj;

    let theta1 = atan2(uy, ux);
    let mut delta = atan2(vy, vx) - theta1;
    if !sweep && delta > 0.0 {
        delta -= 2.0 * std::f64::consts::PI;
    } else if sweep && delta < 0.0 {
        delta += 2.0 * std::f64::consts::PI;
    }

    // Step 5: flatten
    let steps = ((delta.abs() / (std::f64::consts::PI / 8.0)).ceil() as i32).clamp(2, 64);
    let mut pts = Vec::with_capacity(steps as usize);
    for i in 1..=steps {
        let t = i as f64 / steps as f64;
        let angle = theta1 + delta * t;
        let x = cos_phi * (rx_adj * angle.cos()) - sin_phi * (ry_adj * angle.sin()) + cx;
        let y = sin_phi * (rx_adj * angle.cos()) + cos_phi * (ry_adj * angle.sin()) + cy;
        pts.push((x, y));
    }
    pts
}

fn atan2(y: f64, x: f64) -> f64 {
    y.atan2(x)
}

// ── Wu-Xiaolin anti-aliased line ──

fn draw_line_aa(
    fb: &mut [RasterPixel],
    width: usize,
    height: usize,
    x0: f64,
    y0: f64,
    x1: f64,
    y1: f64,
    color: Color,
    alpha: f64,
) {
    let steep = (y1 - y0).abs() > (x1 - x0).abs();
    let (mut x0, mut y0, mut x1, mut y1) = if steep {
        (y0, x0, y1, x1)
    } else {
        (x0, y0, x1, y1)
    };

    if x0 > x1 {
        std::mem::swap(&mut x0, &mut x1);
        std::mem::swap(&mut y0, &mut y1);
    }

    let dx = x1 - x0;
    let dy = y1 - y0;
    let gradient = if dx.abs() < 1e-6 { 1.0 } else { dy / dx };

    let xend = x0.round();
    let yend = y0 + gradient * (xend - x0);
    let xgap = 1.0 - frac(x0 + 0.5);
    let xpxl1 = xend as i32;
    let ypxl1 = yend.trunc() as i32;

    if steep {
        blend_pixel(
            fb,
            width,
            height,
            ypxl1,
            xpxl1,
            color.r as f64,
            color.g as f64,
            color.b as f64,
            alpha * (1.0 - frac(yend)) * xgap,
        );
        blend_pixel(
            fb,
            width,
            height,
            ypxl1 + 1,
            xpxl1,
            color.r as f64,
            color.g as f64,
            color.b as f64,
            alpha * frac(yend) * xgap,
        );
    } else {
        blend_pixel(
            fb,
            width,
            height,
            xpxl1,
            ypxl1,
            color.r as f64,
            color.g as f64,
            color.b as f64,
            alpha * (1.0 - frac(yend)) * xgap,
        );
        blend_pixel(
            fb,
            width,
            height,
            xpxl1,
            ypxl1 + 1,
            color.r as f64,
            color.g as f64,
            color.b as f64,
            alpha * frac(yend) * xgap,
        );
    }

    let mut intery = yend + gradient;

    let xend = x1.round();
    let yend = y1 + gradient * (xend - x1);
    let xgap = frac(x1 + 0.5);
    let xpxl2 = xend as i32;
    let ypxl2 = yend.trunc() as i32;

    if steep {
        blend_pixel(
            fb,
            width,
            height,
            ypxl2,
            xpxl2,
            color.r as f64,
            color.g as f64,
            color.b as f64,
            alpha * (1.0 - frac(yend)) * xgap,
        );
        blend_pixel(
            fb,
            width,
            height,
            ypxl2 + 1,
            xpxl2,
            color.r as f64,
            color.g as f64,
            color.b as f64,
            alpha * frac(yend) * xgap,
        );
    } else {
        blend_pixel(
            fb,
            width,
            height,
            xpxl2,
            ypxl2,
            color.r as f64,
            color.g as f64,
            color.b as f64,
            alpha * (1.0 - frac(yend)) * xgap,
        );
        blend_pixel(
            fb,
            width,
            height,
            xpxl2,
            ypxl2 + 1,
            color.r as f64,
            color.g as f64,
            color.b as f64,
            alpha * frac(yend) * xgap,
        );
    }

    // Rasterize interior pixels once, advancing the interpolated y each column.
    let xstart = xpxl1 + 1;
    let xstop = xpxl2;
    if xstart < xstop {
        let mut x = xstart;
        while x < xstop {
            let y = intery.trunc() as i32;
            let f = frac(intery);
            if steep {
                blend_pixel(
                    fb,
                    width,
                    height,
                    y,
                    x,
                    color.r as f64,
                    color.g as f64,
                    color.b as f64,
                    alpha * (1.0 - f),
                );
                blend_pixel(
                    fb,
                    width,
                    height,
                    y + 1,
                    x,
                    color.r as f64,
                    color.g as f64,
                    color.b as f64,
                    alpha * f,
                );
            } else {
                blend_pixel(
                    fb,
                    width,
                    height,
                    x,
                    y,
                    color.r as f64,
                    color.g as f64,
                    color.b as f64,
                    alpha * (1.0 - f),
                );
                blend_pixel(
                    fb,
                    width,
                    height,
                    x,
                    y + 1,
                    color.r as f64,
                    color.g as f64,
                    color.b as f64,
                    alpha * f,
                );
            }
            intery += gradient;
            x += 1;
        }
    }
}

fn frac(x: f64) -> f64 {
    x - x.floor()
}

// ── Gradient interpolation ──

fn sample_gradient(stops: &[(f64, Color)], t: f64) -> Color {
    if stops.is_empty() {
        return Color::BLACK;
    }
    if stops.len() == 1 {
        return stops[0].1;
    }
    let t = t.clamp(0.0, 1.0);
    for i in 0..stops.len() - 1 {
        let (t0, c0) = stops[i];
        let (t1, c1) = stops[i + 1];
        if t >= t0 && t <= t1 {
            if (t1 - t0).abs() < 1e-6 {
                return c1;
            }
            let f = (t - t0) / (t1 - t0);
            return Color::rgba(
                (c0.r as f64 + (c1.r as f64 - c0.r as f64) * f).round() as u8,
                (c0.g as f64 + (c1.g as f64 - c0.g as f64) * f).round() as u8,
                (c0.b as f64 + (c1.b as f64 - c0.b as f64) * f).round() as u8,
                (c0.a as f64 + (c1.a as f64 - c0.a as f64) * f).round() as u8,
            );
        }
    }
    stops.last().unwrap().1
}

// ── Blend mode compositing in PPM ──

fn rgb_to_hsl(r: f64, g: f64, b: f64) -> (f64, f64, f64) {
    let r = (r / 255.0).clamp(0.0, 1.0);
    let g = (g / 255.0).clamp(0.0, 1.0);
    let b = (b / 255.0).clamp(0.0, 1.0);
    let max = r.max(g).max(b);
    let min = r.min(g).min(b);
    let light = (max + min) * 0.5;
    let delta = max - min;
    if delta <= f64::EPSILON {
        return (0.0, 0.0, light);
    }
    let sat = delta / (1.0 - (2.0 * light - 1.0).abs());
    let mut hue = if (max - r).abs() <= f64::EPSILON {
        ((g - b) / delta) % 6.0
    } else if (max - g).abs() <= f64::EPSILON {
        (b - r) / delta + 2.0
    } else {
        (r - g) / delta + 4.0
    } / 6.0;
    if hue < 0.0 {
        hue += 1.0;
    }
    (hue, sat.clamp(0.0, 1.0), light)
}

fn hsl_to_rgb(h: f64, s: f64, l: f64) -> (f64, f64, f64) {
    if s <= f64::EPSILON {
        let v = l.clamp(0.0, 1.0) * 255.0;
        return (v, v, v);
    }
    let q = if l < 0.5 {
        l * (1.0 + s)
    } else {
        l + s - l * s
    };
    let p = 2.0 * l - q;
    let hue = |mut t: f64| {
        if t < 0.0 {
            t += 1.0;
        }
        if t > 1.0 {
            t -= 1.0;
        }
        if t < 1.0 / 6.0 {
            p + (q - p) * 6.0 * t
        } else if t < 1.0 / 2.0 {
            q
        } else if t < 2.0 / 3.0 {
            p + (q - p) * (2.0 / 3.0 - t) * 6.0
        } else {
            p
        }
    };
    (
        hue(h + 1.0 / 3.0) * 255.0,
        hue(h) * 255.0,
        hue(h - 1.0 / 3.0) * 255.0,
    )
}

fn blend_with_mode(
    mode: BlendMode,
    src_r: f64,
    src_g: f64,
    src_b: f64,
    dst_r: f64,
    dst_g: f64,
    dst_b: f64,
    alpha: f64,
) -> (f64, f64, f64) {
    let a = alpha.clamp(0.0, 1.0);
    match mode {
        BlendMode::Normal => (
            dst_r * (1.0 - a) + src_r * a,
            dst_g * (1.0 - a) + src_g * a,
            dst_b * (1.0 - a) + src_b * a,
        ),
        BlendMode::Multiply => {
            let r = src_r * dst_r / 255.0;
            let g = src_g * dst_g / 255.0;
            let b = src_b * dst_b / 255.0;
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Screen => {
            let r = 255.0 - (255.0 - src_r) * (255.0 - dst_r) / 255.0;
            let g = 255.0 - (255.0 - src_g) * (255.0 - dst_g) / 255.0;
            let b = 255.0 - (255.0 - src_b) * (255.0 - dst_b) / 255.0;
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Overlay => {
            let sr = src_r / 255.0;
            let sg = src_g / 255.0;
            let sb = src_b / 255.0;
            let dr = dst_r / 255.0;
            let dg = dst_g / 255.0;
            let db = dst_b / 255.0;
            let overlay = |s: f64, d: f64| -> f64 {
                if d < 0.5 {
                    2.0 * s * d
                } else {
                    1.0 - 2.0 * (1.0 - s) * (1.0 - d)
                }
            };
            let r = overlay(sr, dr) * 255.0;
            let g = overlay(sg, dg) * 255.0;
            let b = overlay(sb, db) * 255.0;
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Darken => {
            let r = src_r.min(dst_r);
            let g = src_g.min(dst_g);
            let b = src_b.min(dst_b);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Lighten => {
            let r = src_r.max(dst_r);
            let g = src_g.max(dst_g);
            let b = src_b.max(dst_b);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Difference => {
            let r = (src_r - dst_r).abs();
            let g = (src_g - dst_g).abs();
            let b = (src_b - dst_b).abs();
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Add => {
            let r = (src_r + dst_r).min(255.0);
            let g = (src_g + dst_g).min(255.0);
            let b = (src_b + dst_b).min(255.0);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Exclusion => {
            let r = src_r + dst_r - 2.0 * src_r * dst_r / 255.0;
            let g = src_g + dst_g - 2.0 * src_g * dst_g / 255.0;
            let b = src_b + dst_b - 2.0 * src_b * dst_b / 255.0;
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Xor => {
            let xor = |source: f64, destination: f64| {
                f64::from((source.round() as u8) ^ (destination.round() as u8))
            };
            let r = xor(src_r, dst_r);
            let g = xor(src_g, dst_g);
            let b = xor(src_b, dst_b);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::ColorDodge => {
            let dodge = |source: f64, destination: f64| {
                if source >= 255.0 {
                    255.0
                } else {
                    (destination * 255.0 / (255.0 - source)).min(255.0)
                }
            };
            let r = dodge(src_r, dst_r);
            let g = dodge(src_g, dst_g);
            let b = dodge(src_b, dst_b);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::ColorBurn => {
            let burn = |source: f64, destination: f64| {
                if source <= 0.0 {
                    0.0
                } else {
                    255.0 - ((255.0 - destination) * 255.0 / source).min(255.0)
                }
            };
            let r = burn(src_r, dst_r);
            let g = burn(src_g, dst_g);
            let b = burn(src_b, dst_b);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::HardLight => {
            let hard_light = |source: f64, destination: f64| {
                if source <= 127.5 {
                    2.0 * source * destination / 255.0
                } else {
                    255.0 - 2.0 * (255.0 - source) * (255.0 - destination) / 255.0
                }
            };
            let r = hard_light(src_r, dst_r);
            let g = hard_light(src_g, dst_g);
            let b = hard_light(src_b, dst_b);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::SoftLight => {
            let soft_light = |source: f64, destination: f64| {
                let source = source / 255.0;
                let destination = destination / 255.0;
                let result = if source <= 0.5 {
                    destination - (1.0 - 2.0 * source) * destination * (1.0 - destination)
                } else {
                    let curve = if destination <= 0.25 {
                        ((16.0 * destination - 12.0) * destination + 4.0) * destination
                    } else {
                        destination.sqrt()
                    };
                    destination + (2.0 * source - 1.0) * (curve - destination)
                };
                result * 255.0
            };
            let r = soft_light(src_r, dst_r);
            let g = soft_light(src_g, dst_g);
            let b = soft_light(src_b, dst_b);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Hue | BlendMode::Saturation | BlendMode::Color | BlendMode::Luminosity => {
            let (sh, ss, sl) = rgb_to_hsl(src_r, src_g, src_b);
            let (dh, ds, dl) = rgb_to_hsl(dst_r, dst_g, dst_b);
            let (h, sat, light) = match mode {
                BlendMode::Hue => (sh, ds, dl),
                BlendMode::Saturation => (dh, ss, dl),
                BlendMode::Color => (sh, ss, dl),
                BlendMode::Luminosity => (dh, ds, sl),
                _ => unreachable!(),
            };
            let (r, g, b) = hsl_to_rgb(h, sat, light);
            (
                dst_r * (1.0 - a) + r * a,
                dst_g * (1.0 - a) + g * a,
                dst_b * (1.0 - a) + b * a,
            )
        }
        BlendMode::Erase => (dst_r * (1.0 - a), dst_g * (1.0 - a), dst_b * (1.0 - a)),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hd_jobs_render_inline_while_4k_jobs_can_fan_out() {
        assert_eq!(raster_worker_count(1280 * 720, 720), 1);
        assert_eq!(raster_worker_count(2560 * 1440, 1440), 1);
        let expected_4k_workers = std::thread::available_parallelism()
            .map(usize::from)
            .unwrap_or(1)
            .min(8);
        assert_eq!(raster_worker_count(3840 * 2160, 2160), expected_4k_workers);
    }

    fn ppm_pixel(ppm: &[u8], width: usize, x: usize, y: usize) -> [u8; 3] {
        let mut newlines = 0;
        let data_start = ppm
            .iter()
            .position(|byte| {
                if *byte == b'\n' {
                    newlines += 1;
                }
                newlines == 3
            })
            .unwrap()
            + 1;
        let offset = data_start + (y * width + x) * 3;
        [ppm[offset], ppm[offset + 1], ppm[offset + 2]]
    }
    #[test]
    fn bitmap_ppm_skips_its_separator_and_rejects_oversized_dimensions() {
        use std::sync::atomic::{AtomicU64, Ordering};
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-bitmap-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir(&root).unwrap();

        let valid_path = root.join("valid.ppm");
        let mut valid = b"P6\n2 1\n255\n".to_vec();
        valid.extend_from_slice(&[1, 2, 3, 4, 5, 6]);
        std::fs::write(&valid_path, valid).unwrap();
        let scene = parse_scene(&format!(
            "canvas 2 1 black\nbitmap \"{}\" 0 0 2 1\n",
            valid_path.display()
        ))
        .unwrap();
        let bitmap = scene.shapes[0].bitmap.as_ref().unwrap();
        assert_eq!(
            bitmap.pixels.as_ref(),
            [Color::rgb(1, 2, 3), Color::rgb(4, 5, 6)]
        );

        let oversized_path = root.join("oversized.ppm");
        std::fs::write(&oversized_path, b"P6\n4294967295 4294967295\n255\n").unwrap();
        assert_eq!(
            parse_scene(&format!(
                "canvas 2 1 black\nbitmap \"{}\" 0 0 2 1\n",
                oversized_path.display()
            ))
            .unwrap_err(),
            Error::IllegalQuantity
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn layers_attach_shapes_and_apply_visibility_and_svg_opacity() {
        let source = "canvas 8 4 #000000\n\
layer hidden visible=false\n\
rect 0 0 4 4 fill=#ff0000 stroke=none\n\
endlayer\n\
rect 4 0 4 4 fill=#00ff00 stroke=none\n";
        let scene = parse_scene(source).unwrap();
        assert_eq!(scene.shapes[0].layer, "hidden");
        assert!(scene.shapes[1].layer.is_empty());

        let ppm = scene_to_ppm(&scene).unwrap();
        assert_eq!(ppm_pixel(&ppm, 8, 1, 1), [0, 0, 0]);
        assert_eq!(ppm_pixel(&ppm, 8, 6, 1), [0, 255, 0]);

        let svg = render_svg(
            "canvas 8 4 #000000\n\
layer dim opacity=0.25\n\
rect 0 0 8 4 fill=#ffffff stroke=none\n\
endlayer\n",
        )
        .unwrap();
        assert!(svg.contains("opacity=\"0.25\""));
        assert!(parse_scene("endlayer\n").is_err());
        assert!(parse_scene("endgroup\n").is_err());
    }

    #[test]
    fn depth_perception_grid_points_and_light_sources_render() {
        let scene = parse_scene(
            "canvas 20 20 #000000\n\
depth_perception horizon=50% rows=4 rays=4\n\
grid_on ground\n\
depth_point row=2 col=B plane=ground radius=2 fill=#00ff00\n",
        )
        .unwrap();
        assert!(scene
            .shapes
            .iter()
            .any(|shape| shape.id.starts_with("__depth_grid_ground")));
        assert!(scene
            .shapes
            .iter()
            .any(|shape| shape.id == "depth_point_2_1"));

        let ppm = render_ppm("canvas 20 20 #000000\nlight_source 10 10 1 #ff0000\n").unwrap();
        assert!(ppm_pixel(&ppm, 20, 10, 10)[0] > 220);
        assert_eq!(ppm_pixel(&ppm, 20, 0, 0), [0, 0, 0]);

        let svg = render_svg("canvas 20 20 #000000\nlight_source 10 10 0.5 #ff0000\n").unwrap();
        assert!(svg.contains("<radialGradient"));
        assert!(svg.contains("mix-blend-mode:screen"));
        assert!(parse_scene("grid_on both\n").is_err());
        assert!(parse_scene("depth_point row=1 col=A\n").is_err());
        assert!(parse_scene("unfinished_command 1 2 3\n").is_err());
        assert!(parse_scene("horizon 0.5\n").is_err());
        assert!(parse_scene("reference_image unused.png\n").is_err());
    }

    #[test]
    fn render_svg_basic() {
        let svg = render_svg("canvas 400 300 #000000\nline 10 10 100 100 stroke=#ffffff stroke-width=2\nrect 50 50 80 60 fill=#ff0000 stroke=#00ff00 stroke-width=3\ncircle 200 150 40 fill=#0000ff stroke=none\ntext 100 100 18 \"HELLO\" fill=#ffffff\n").unwrap();
        assert!(svg.contains("width=\"400\""));
        assert!(svg.contains("<line"));
        assert!(svg.contains("<rect"));
        assert!(svg.contains("<circle"));
        assert!(svg.contains("<text"));
        assert!(svg.contains("HELLO"));
    }

    #[test]
    fn render_svg_gradient() {
        let svg = render_svg("canvas 1024 768 #ffffff\ngradient sky 0 0 0 768 stop=0,#0000ff stop=1,#ff0000\nrect 0 0 1024 768 fill=url(#sky) stroke=none\n").unwrap();
        assert!(svg.contains("linearGradient"));
        assert!(svg.contains("stop-color"));
    }

    #[test]
    fn render_ppm_basic() {
        let ppm = render_ppm("canvas 100 100 #000000\nrect 10 10 50 50 fill=#ff0000 stroke=none\ncircle 75 75 20 fill=#00ff00 stroke=none\n").unwrap();
        assert!(ppm.starts_with(b"P6\n100 100\n255\n"));
        // Check that there are red pixels (in the rect area)
        let pixel_offset = b"P6\n100 100\n255\n".len() + (15 * 100 + 15) * 3;
        assert_eq!(ppm[pixel_offset], 255); // red channel
    }

    #[test]
    fn retained_raster_prefix_matches_a_cold_complete_render() {
        clear_raster_prefix_cache();
        let prefix = "canvas 64 32 #020617\n\
gradient sky 0 0 0 32 stop=0,#172554 stop=1,#020617\n\
rect 0 0 64 32 fill=url(#sky) stroke=none\n";
        let first = format!("{prefix}circle 12 16 6 fill=#ff0000 stroke=none\n");
        let second = format!("{prefix}circle 28 16 6 fill=#00ff00 stroke=none\n");
        let third = format!("{prefix}circle 44 16 6 fill=#00aaff stroke=none\n");

        render_ppm(&first).unwrap();
        assert_eq!(retained_raster_prefix_len(), 0);
        render_ppm(&second).unwrap();
        assert_eq!(retained_raster_prefix_len(), 1);
        let retained = render_ppm(&third).unwrap();

        clear_raster_prefix_cache();
        let cold = render_ppm(&third).unwrap();
        assert_eq!(retained, cold);
    }

    #[test]
    fn retained_raster_prefix_never_preserves_shapes_removed_by_cls() {
        clear_raster_prefix_cache();
        let prefix = "canvas 64 32 #020617\n\
rect 0 0 64 32 fill=#102040 stroke=none\n";
        let first = format!("{prefix}circle 16 16 8 fill=#ff0000 stroke=none\n");
        let second = format!("{prefix}circle 48 16 8 fill=#00ff00 stroke=none\n");

        render_ppm(&first).unwrap();
        render_ppm(&second).unwrap();
        assert_eq!(retained_raster_prefix_len(), 1);
        let cleared = render_ppm(prefix).unwrap();

        clear_raster_prefix_cache();
        let cold_clear = render_ppm(prefix).unwrap();
        assert_eq!(cleared, cold_clear);
        assert_eq!(ppm_pixel(&cleared, 64, 16, 16), [16, 32, 64]);
        assert_eq!(ppm_pixel(&cleared, 64, 48, 16), [16, 32, 64]);
    }

    #[test]
    fn raster_linear_and_radial_gradients_are_real_paints() {
        let linear = render_ppm(
            "canvas 8 2 #000000\n\
gradient sky 0 0 8 0 stop=0,#000000 stop=1,#ffffff\n\
rect 0 0 8 2 fill=url(#sky) stroke=none\n",
        )
        .unwrap();
        assert!(ppm_pixel(&linear, 8, 0, 0)[0] < 32);
        assert!(ppm_pixel(&linear, 8, 7, 0)[0] > 220);

        let radial = render_ppm(
            "canvas 9 9 #000000\n\
gradient glow kind=radial 4.5 4.5 4.5 4.5 0 5 stop=0,#ffffff stop=1,#ffffff00\n\
rect 0 0 9 9 fill=url(#glow) stroke=none\n",
        )
        .unwrap();
        assert!(ppm_pixel(&radial, 9, 4, 4)[0] > 240);
        assert!(ppm_pixel(&radial, 9, 0, 0)[0] < 16);
    }

    #[test]
    fn raster_rounded_rectangles_and_filled_strokes_render_correctly() {
        let rounded =
            render_ppm("canvas 20 20 black\nrounded_rectangle 2 2 16 16 6 fill=red stroke=none\n")
                .unwrap();
        assert_eq!(ppm_pixel(&rounded, 20, 2, 2), [0, 0, 0]);
        assert_eq!(ppm_pixel(&rounded, 20, 10, 10), [255, 0, 0]);

        let circle = render_ppm(
            "canvas 24 24 black\ncircle 12 12 6 fill=red stroke=#00ff00 stroke-width=2\n",
        )
        .unwrap();
        assert_eq!(ppm_pixel(&circle, 24, 12, 12), [255, 0, 0]);
        let edge = ppm_pixel(&circle, 24, 18, 12);
        assert!(edge[1] > 220 && edge[0] < 32);
    }

    #[test]
    fn thick_lines_and_polygon_slopes_have_bounded_edge_coverage() {
        let antialiased = render_ppm(
            "canvas 24 24 black\n\
line 2.25 3.75 20.5 16.25 stroke=white stroke-width=4\n\
polygon 3.2 20.4 12.7 5.3 21.1 20.4 fill=white stroke=none\n",
        )
        .unwrap();
        let data_start = antialiased
            .windows(1)
            .enumerate()
            .filter(|(_, byte)| byte[0] == b'\n')
            .nth(2)
            .unwrap()
            .0
            + 1;
        assert!(antialiased[data_start..]
            .iter()
            .any(|channel| (1..=254).contains(channel)));

        let offscreen = render_ppm(
            "canvas 8 8 black\n\
line 1e100 1e100 2e100 2e100 stroke=white stroke-width=4\n\
polygon -2e100 -2e100 -1e100 -2e100 -1e100 -1e100 fill=white stroke=none\n",
        )
        .unwrap();
        assert_eq!(ppm_pixel(&offscreen, 8, 0, 0), [0, 0, 0]);
        assert_eq!(ppm_pixel(&offscreen, 8, 7, 7), [0, 0, 0]);
    }

    #[test]
    fn raster_blend_commands_composite_the_latest_shape() {
        let ppm = render_ppm(
            "canvas 4 4 #ff0000\nrect 0 0 4 4 fill=#0000ff stroke=none\nstyle composite=screen\n",
        )
        .unwrap();
        assert_eq!(ppm_pixel(&ppm, 4, 2, 2), [255, 0, 255]);
    }

    #[test]
    fn sprites_render_at_their_latest_position() {
        let ppm = render_ppm(
            "canvas 20 20 black\nsprite ship 1 1 4 4 fill=red stroke=none\nmovsprite ship 10 10\n",
        )
        .unwrap();
        let header = b"P6\n20 20\n255\n";
        let pixel = |x: usize, y: usize| {
            let offset = header.len() + (y * 20 + x) * 3;
            [ppm[offset], ppm[offset + 1], ppm[offset + 2]]
        };
        assert_eq!(pixel(2, 2), [0, 0, 0]);
        assert_eq!(pixel(11, 11), [255, 0, 0]);
    }

    #[test]
    fn render_ppm_text_uses_upright_column_major_ascii_glyphs() {
        let ppm = render_ppm("canvas 8 8 #000000\ntext 0 7 7 \"A\" fill=#ffffff\n").unwrap();
        assert_eq!(ppm_pixel(&ppm, 8, 0, 0), [0, 0, 0]);
        assert_eq!(ppm_pixel(&ppm, 8, 1, 0), [255, 255, 255]);
        assert_eq!(ppm_pixel(&ppm, 8, 3, 0), [255, 255, 255]);
        assert_eq!(ppm_pixel(&ppm, 8, 4, 0), [0, 0, 0]);
        assert_eq!(ppm_pixel(&ppm, 8, 0, 1), [255, 255, 255]);
        assert_eq!(ppm_pixel(&ppm, 8, 4, 1), [255, 255, 255]);
        for x in 0..5 {
            assert_eq!(ppm_pixel(&ppm, 8, x, 4), [255, 255, 255]);
        }
        assert_eq!(ppm_pixel(&ppm, 8, 2, 6), [0, 0, 0]);
    }

    #[test]
    fn large_raster_text_uses_antialiased_geometric_strokes() {
        clear_raster_prefix_cache();
        let ppm = render_ppm("canvas 32 32 #000000\ntext 4 30 28 \"A\" fill=#ffffff\n").unwrap();
        assert!(ppm_pixel(&ppm, 32, 14, 2)[0] > 180);
        assert!(ppm_pixel(&ppm, 32, 4, 29)[0] > 180);
        assert!(ppm_pixel(&ppm, 32, 23, 29)[0] > 180);
        assert!(ppm_pixel(&ppm, 32, 13, 18)[0] > 180);
        assert_eq!(ppm_pixel(&ppm, 32, 14, 24), [0, 0, 0]);
        assert!((0..32).any(|y| {
            (0..32).any(|x| {
                let channel = ppm_pixel(&ppm, 32, x, y)[0];
                (1..=254).contains(&channel)
            })
        }));
    }

    #[test]
    fn transparent_bitmap_warp_keeps_clean_edges_and_anchors_its_stem() {
        let bitmap = BitmapData {
            width: 2,
            height: 1,
            pixels: Arc::<[Color]>::from([Color::rgba(255, 0, 0, 0), Color::rgba(0, 255, 0, 255)]),
        };
        assert_eq!(
            sample_bitmap_at(&bitmap, 0.5, 0.0),
            Color::rgba(0, 255, 0, 128)
        );

        let shape = Shape {
            shape_type: ShapeType::Bitmap,
            x: 20.0,
            y: 35.0,
            w: 18.0,
            h: 28.0,
            bitmap_warp: Some(BitmapWarp {
                angle: 12.0,
                bend: 0.55,
                turn: -0.45,
                aim: 0.0,
                light: 1.0,
            }),
            bitmap: Some(bitmap.clone()),
            ..Default::default()
        };
        let anchor = warped_bitmap_point(&shape, 0.5, 1.0);
        assert!((anchor.0 - 20.0).abs() < 1e-9);
        assert!((anchor.1 - 35.0).abs() < 1e-9);
        let mut framebuffer = vec![(0.0, 0.0, 0.0); 40 * 40];
        rasterize_warped_bitmap(&mut framebuffer, 40, 40, &shape, &bitmap, 1.0);
        assert!(framebuffer.iter().any(|pixel| pixel.1 > 64.0));
        assert!(framebuffer.iter().all(|pixel| pixel.0 < 1.0));
    }

    #[test]
    fn keyed_bitmap_sprite_angle_uses_a_fast_rigid_bottom_center_rotation() {
        let image = Arc::new(image_codec::RgbImage {
            width: 1,
            height: 2,
            pixels: vec![[255, 0, 0], [0, 0, 0]],
            alpha: vec![255, 255],
        });
        let path = image_codec::register_memory_image(&image, "ppm");
        let source = format!(
            "canvas 14 14 black\nbitmap_sprite SHOT \"{}\" 6 6 2 4 key=#000000 angle=90\n",
            path.display()
        );
        let scene = parse_scene(&source).unwrap();
        let shape = &scene.shapes[0];
        assert_eq!((shape.x, shape.y), (7.0, 10.0));
        assert_eq!(shape.bitmap_warp.as_ref().unwrap().angle, 90.0);
        assert_eq!(shape.bitmap.as_ref().unwrap().pixels[1].a, 0);

        let ppm = render_ppm(&source).unwrap();
        let left_red: usize = (0..14)
            .flat_map(|y| (0..7).map(move |x| (x, y)))
            .map(|(x, y)| usize::from(ppm_pixel(&ppm, 14, x, y)[0]))
            .sum();
        let right_red: usize = (0..14)
            .flat_map(|y| (8..14).map(move |x| (x, y)))
            .map(|(x, y)| usize::from(ppm_pixel(&ppm, 14, x, y)[0]))
            .sum();
        assert!(right_red > left_red, "left={left_red} right={right_red}");
        assert!(parse_scene(&format!(
            "canvas 2 2 black\nbitmap_sprite BAD \"{}\" 0 0 1 1 angle=nan\n",
            path.display()
        ))
        .is_err());
    }

    #[test]
    fn bitmap_sprite_aim_yaws_toward_target_without_rolling_image_rows() {
        let image = Arc::new(image_codec::RgbImage {
            width: 1,
            height: 2,
            pixels: vec![[255, 128, 32], [0, 0, 0]],
            alpha: vec![255, 255],
        });
        let path = image_codec::register_memory_image(&image, "ppm");
        let source = format!(
            "canvas 20 20 black\nbitmap_sprite SHIP \"{}\" 8 8 4 6 key=#000000 aim=-1\n",
            path.display()
        );
        let scene = parse_scene(&source).unwrap();
        let shape = &scene.shapes[0];
        let top_left = warped_bitmap_point(shape, 0.0, 0.0);
        let top_right = warped_bitmap_point(shape, 1.0, 0.0);
        let bottom_left = warped_bitmap_point(shape, 0.0, 1.0);
        let bottom_right = warped_bitmap_point(shape, 1.0, 1.0);
        let top_center = warped_bitmap_point(shape, 0.5, 0.0);
        let bottom_center = warped_bitmap_point(shape, 0.5, 1.0);

        assert!((top_left.1 - top_right.1).abs() < 1.0e-12);
        assert!((bottom_left.1 - bottom_right.1).abs() < 1.0e-12);
        assert!(top_center.0 < bottom_center.0);
        assert!((top_center.1 - (bottom_center.1 - shape.h)).abs() < 1.0e-12);
        assert!((top_right.0 - top_left.0) < shape.w);
        assert!(render_ppm(&source).unwrap()[b"P6\n20 20\n255\n".len()..]
            .chunks_exact(3)
            .any(|pixel| pixel[0] > 40));
    }

    #[test]
    fn procedural_texture_is_deterministic_varied_and_path_clipped() {
        clear_raster_prefix_cache();
        let source = "canvas 16 16 black\ntexture \"M 2 2 L 14 2 L 14 14 L 2 14 Z\" 42 3 4 #102010 #d0f080 opacity=1 composite=normal\n";
        let first = render_ppm(source).unwrap();
        clear_raster_prefix_cache();
        let second = render_ppm(source).unwrap();
        assert_eq!(first, second);
        assert_eq!(ppm_pixel(&first, 16, 0, 0), [0, 0, 0]);
        assert_ne!(ppm_pixel(&first, 16, 4, 4), ppm_pixel(&first, 16, 11, 11));

        clear_raster_prefix_cache();
        let different = render_ppm(
            "canvas 16 16 black\ntexture \"M 2 2 L 14 2 L 14 14 L 2 14 Z\" 43 3 4 #102010 #d0f080 opacity=1 composite=normal\n",
        )
        .unwrap();
        assert_ne!(first, different);
    }

    #[test]
    fn raster_filters_blur_sharpen_and_adjust_color() {
        clear_raster_prefix_cache();
        let blurred = render_ppm(
            "canvas 9 9 black\npixel 4 4 fill=white stroke=none\nraster_filter blur 1\n",
        )
        .unwrap();
        let center = ppm_pixel(&blurred, 9, 4, 4)[0];
        assert!((1..255).contains(&center));
        assert!(ppm_pixel(&blurred, 9, 3, 4)[0] > 0);

        clear_raster_prefix_cache();
        let color = render_ppm(
            "canvas 4 4 black\nrect 0 0 4 4 fill=#ff4000 stroke=none\nraster_filter color 1 1 0\nraster_filter sharpen 0.5\n",
        )
        .unwrap();
        let pixel = ppm_pixel(&color, 4, 2, 2);
        assert_eq!(pixel[0], pixel[1]);
        assert_eq!(pixel[1], pixel[2]);
        assert!(parse_scene("raster_filter blur 33\n").is_err());
        assert!(parse_scene("texture \"M0 0Z\" x 2 3 red green\n").is_err());
    }

    #[test]
    fn compact_inline_rasters_render_and_validate_exact_pixel_counts() {
        clear_raster_prefix_cache();
        let ppm =
            render_ppm("canvas 3 2 black\nraster_rle 0 0 3 2 2:ffff0000 1:ff00ff00 3:ff0000ff\n")
                .unwrap();
        assert_eq!(ppm_pixel(&ppm, 3, 0, 0), [255, 0, 0]);
        assert_eq!(ppm_pixel(&ppm, 3, 2, 0), [0, 255, 0]);
        assert_eq!(ppm_pixel(&ppm, 3, 2, 1), [0, 0, 255]);
        assert!(parse_scene("raster_rle 0 0 2 2 3:ffffffff\n").is_err());
        assert!(parse_scene("raster_rle 0 0 2 2 5:ffffffff\n").is_err());
        assert!(parse_scene("raster_rle 0 0 2 2 0:ffffffff 4:ffffffff\n").is_err());
    }

    #[test]
    fn color_parsing() {
        assert_eq!(parse_color("#ff0000").unwrap(), Color::rgb(255, 0, 0));
        assert_eq!(parse_color("#f00").unwrap(), Color::rgb(255, 0, 0));
        assert_eq!(
            parse_color("#ff000080").unwrap(),
            Color::rgba(255, 0, 0, 128)
        );
        assert_eq!(parse_color("none").unwrap(), Color::TRANSPARENT);
        assert_eq!(parse_color("red").unwrap(), Color::rgb(255, 0, 0));
        assert_eq!(parse_color("SKYBLUE").unwrap(), Color::rgb(135, 206, 235));
        assert_eq!(parse_color("Gold").unwrap(), Color::rgb(255, 215, 0));
        assert!(parse_color("#éa").is_err());
        assert!(parse_color("#zzzzzz").is_err());
    }

    #[test]
    fn flood_fill_respects_regions_bounded_by_separate_lines() {
        let source = "canvas 20 20 black\n\
line 3 3 16 3 stroke=white stroke-width=1\n\
line 16 3 16 16 stroke=white stroke-width=1\n\
line 16 16 3 16 stroke=white stroke-width=1\n\
line 3 16 3 3 stroke=white stroke-width=1\n\
flood 10 10 fill=gold stroke=none\n";
        let ppm = render_ppm(source).unwrap();
        let header = b"P6\n20 20\n255\n";
        let pixel = |x: usize, y: usize| {
            let offset = header.len() + (y * 20 + x) * 3;
            [ppm[offset], ppm[offset + 1], ppm[offset + 2]]
        };
        assert_eq!(pixel(10, 10), [255, 215, 0]);
        assert_eq!(pixel(3, 10), [255, 255, 255]);
        assert_eq!(pixel(0, 0), [0, 0, 0]);

        let svg = render_svg(source).unwrap();
        assert!(svg.contains("<path d=\"M"));
        assert!(svg.contains("fill=\"#ffd700\""));
    }

    #[test]
    fn flood_fill_with_border_crosses_non_border_colors_and_preserves_boundary() {
        let source = "canvas 9 9 black\n\
line 1 1 7 1 stroke=white stroke-width=1\n\
line 7 1 7 7 stroke=white stroke-width=1\n\
line 7 7 1 7 stroke=white stroke-width=1\n\
line 1 7 1 1 stroke=white stroke-width=1\n\
pixel 4 4 fill=red\n\
flood 3 3 fill=gold stroke=white\n";
        let ppm = render_ppm(source).unwrap();
        assert_eq!(ppm_pixel(&ppm, 9, 3, 3), [255, 215, 0]);
        assert_eq!(ppm_pixel(&ppm, 9, 4, 4), [255, 215, 0]);
        assert_eq!(ppm_pixel(&ppm, 9, 1, 4), [255, 255, 255]);
        assert_eq!(ppm_pixel(&ppm, 9, 0, 0), [0, 0, 0]);

        let translucent = source.replace("fill=gold", "fill=#00ff0080");
        let translucent_ppm = render_ppm(&translucent).unwrap();
        assert_eq!(ppm_pixel(&translucent_ppm, 9, 3, 3), [0, 128, 0]);
        assert_eq!(ppm_pixel(&translucent_ppm, 9, 4, 4), [127, 128, 0]);

        let svg = render_svg(source).unwrap();
        assert!(svg.contains("fill=\"#ffd700\""));
    }

    #[test]
    fn raster_and_svg_flood_reject_oversized_pixel_products_before_allocation() {
        assert_eq!(
            render_ppm("canvas 65535 65535 black\n").unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            render_svg("canvas 65535 65535 black\nflood 1 1 fill=red\n").unwrap_err(),
            Error::IllegalQuantity
        );
    }

    #[test]
    fn path_flattening() {
        let cmds = parse_path_data("M 10 10 C 20 0 30 20 40 10 Z");
        assert_eq!(cmds.len(), 3);
        assert_eq!(cmds[0].op, 'M');
        assert_eq!(cmds[1].op, 'C');
        assert_eq!(cmds[2].op, 'Z');
    }

    #[test]
    fn render_svg_blend_mode_has_one_well_formed_style_attribute() {
        let svg =
            render_svg("canvas 20 20 #ffffff\nrect 0 0 10 10 fill=#ff0000 composite=multiply\n")
                .unwrap();
        assert!(svg.contains("style=\"mix-blend-mode:multiply\""));
        assert!(!svg.contains("mix-blend-mode:multiply\"\""));
    }

    #[test]
    fn blend_mode_parsing() {
        assert_eq!(BlendMode::from_str("multiply"), Some(BlendMode::Multiply));
        assert_eq!(BlendMode::from_str("screen"), Some(BlendMode::Screen));
        assert_eq!(BlendMode::from_str("normal"), Some(BlendMode::Normal));
        assert_eq!(BlendMode::from_str("invalid"), None);
        assert_eq!(BlendMode::from_str("hue"), Some(BlendMode::Hue));
        assert_eq!(
            BlendMode::from_str("saturation"),
            Some(BlendMode::Saturation)
        );
        assert_eq!(BlendMode::from_str("color"), Some(BlendMode::Color));
        assert_eq!(
            BlendMode::from_str("luminosity"),
            Some(BlendMode::Luminosity)
        );
    }

    #[test]
    fn every_blend_mode_produces_bounded_finite_channels() {
        let modes = [
            BlendMode::Normal,
            BlendMode::Multiply,
            BlendMode::Screen,
            BlendMode::Overlay,
            BlendMode::Darken,
            BlendMode::Lighten,
            BlendMode::Difference,
            BlendMode::Xor,
            BlendMode::Add,
            BlendMode::Exclusion,
            BlendMode::ColorDodge,
            BlendMode::ColorBurn,
            BlendMode::HardLight,
            BlendMode::SoftLight,
            BlendMode::Erase,
            BlendMode::Hue,
            BlendMode::Saturation,
            BlendMode::Color,
            BlendMode::Luminosity,
        ];
        for mode in modes {
            let channels = blend_with_mode(mode, 222.0, 71.0, 149.0, 38.0, 187.0, 94.0, 0.63);
            assert!(
                [channels.0, channels.1, channels.2]
                    .into_iter()
                    .all(|channel| channel.is_finite() && (0.0..=255.0).contains(&channel)),
                "invalid output from {mode:?}: {channels:?}"
            );
        }
    }
    #[test]
    fn resident_bitmap_texture_cache_reuses_pixels_and_separates_chroma_keys() {
        let image = Arc::new(image_codec::RgbImage {
            width: 2,
            height: 1,
            pixels: vec![[0, 0, 0], [255, 64, 32]],
            alpha: vec![255, 255],
        });
        let path = image_codec::register_memory_image(&image, "ppm");
        let path = path.to_string_lossy();

        let first = decode_bitmap_data(&path, None).unwrap();
        let second = decode_bitmap_data(&path, None).unwrap();
        assert!(Arc::ptr_eq(&first.pixels, &second.pixels));

        let keyed = decode_bitmap_data(&path, Some(Color::BLACK)).unwrap();
        assert!(!Arc::ptr_eq(&first.pixels, &keyed.pixels));
        assert_eq!(keyed.pixels[0].a, 0);
        assert_eq!(keyed.pixels[1], Color::rgb(255, 64, 32));
    }
}
