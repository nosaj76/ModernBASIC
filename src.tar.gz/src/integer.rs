use crate::arithmetic;
use crate::error::Error;

/// Numeric compatibility mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NumericMode {
    /// Enforce the signed 16-bit integer range that the 6502 internals used
    /// for integer variables and line-number math.
    Legacy6502,
    /// Full signed 64-bit range with checked overflow/underflow.
    Modern,
}

impl NumericMode {
    /// Minimum value allowed in legacy mode.
    pub const LEGACY_MIN: i64 = i16::MIN as i64;
    /// Maximum value allowed in legacy mode.
    pub const LEGACY_MAX: i64 = i16::MAX as i64;
    /// Maximum string length in bytes for the modern 64-bit mode.
    pub const MODERN_MAX_STRING_BYTES: usize = 1_048_576; // 1 MiB
    /// Maximum string length in bytes for the legacy 6502 mode.
    pub const LEGACY_MAX_STRING_BYTES: usize = 255;

    /// Check whether `value` is within the legacy range.
    pub fn check_legacy(value: i64) -> Result<(), Error> {
        if !(Self::LEGACY_MIN..=Self::LEGACY_MAX).contains(&value) {
            return Err(Error::OutOfLegacyRange {
                value,
                min: Self::LEGACY_MIN,
                max: Self::LEGACY_MAX,
            });
        }
        Ok(())
    }

    /// Default byte limit for string values in this mode.
    pub const fn default_string_byte_limit(self) -> usize {
        match self {
            NumericMode::Legacy6502 => Self::LEGACY_MAX_STRING_BYTES,
            NumericMode::Modern => Self::MODERN_MAX_STRING_BYTES,
        }
    }
}

/// A BASIC integer value.
///
/// Internally the value is always an `i64`.  In `Modern` mode the full range
/// is available (subject to checked overflow); in `Legacy6502` mode the
/// signed 16-bit range is enforced on construction and after every operation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct BasicInteger {
    mode: NumericMode,
    value: i64,
}

// Intentionally fallible arithmetic methods returning Result.  The standard
// operator traits cannot be used here because their signatures do not permit
// returning a Result with BASIC-specific errors.
#[allow(clippy::should_implement_trait)]
impl BasicInteger {
    /// Construct a modern 64-bit integer.
    pub fn modern(value: i64) -> Self {
        BasicInteger {
            mode: NumericMode::Modern,
            value,
        }
    }

    /// Construct a legacy 6502 integer, enforcing the 16-bit signed range.
    pub fn legacy(value: i64) -> Result<Self, Error> {
        NumericMode::check_legacy(value)?;
        Ok(BasicInteger {
            mode: NumericMode::Legacy6502,
            value,
        })
    }

    /// Construct in a given mode.  Legacy mode enforces its range immediately.
    pub fn with_mode(mode: NumericMode, value: i64) -> Result<Self, Error> {
        match mode {
            NumericMode::Legacy6502 => BasicInteger::legacy(value),
            NumericMode::Modern => Ok(BasicInteger::modern(value)),
        }
    }

    /// The stored `i64` value.
    pub fn value(self) -> i64 {
        self.value
    }

    /// The compatibility mode.
    pub fn mode(self) -> NumericMode {
        self.mode
    }

    /// Checked addition.
    pub fn add(self, rhs: Self) -> Result<Self, Error> {
        let v = arithmetic::checked_add(self.value, rhs.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Checked subtraction.
    pub fn sub(self, rhs: Self) -> Result<Self, Error> {
        let v = arithmetic::checked_sub(self.value, rhs.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Checked multiplication.
    pub fn mul(self, rhs: Self) -> Result<Self, Error> {
        let v = arithmetic::checked_mul(self.value, rhs.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Checked division.
    pub fn div(self, rhs: Self) -> Result<Self, Error> {
        let v = arithmetic::checked_div(self.value, rhs.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Checked integer division (same semantics as `div` in this slice).
    pub fn idiv(self, rhs: Self) -> Result<Self, Error> {
        self.div(rhs)
    }

    /// Checked modulo.
    pub fn modulo(self, rhs: Self) -> Result<Self, Error> {
        let v = arithmetic::checked_mod(self.value, rhs.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Checked unary negation.
    pub fn neg(self) -> Result<Self, Error> {
        let v = arithmetic::checked_neg(self.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Bitwise AND.
    pub fn and(self, rhs: Self) -> Result<Self, Error> {
        let v = arithmetic::checked_and(self.value, rhs.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Bitwise OR.
    pub fn or(self, rhs: Self) -> Result<Self, Error> {
        let v = arithmetic::checked_or(self.value, rhs.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Bitwise XOR.
    pub fn xor(self, rhs: Self) -> Result<Self, Error> {
        let v = arithmetic::checked_xor(self.value, rhs.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Bitwise NOT.
    pub fn not(self) -> Result<Self, Error> {
        let v = arithmetic::checked_not(self.value)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Checked left shift.
    pub fn shl(self, shift: i64) -> Result<Self, Error> {
        let v = arithmetic::checked_shl(self.value, shift)?;
        BasicInteger::with_mode(self.mode, v)
    }

    /// Checked arithmetic right shift.
    pub fn shr(self, shift: i64) -> Result<Self, Error> {
        let v = arithmetic::checked_shr(self.value, shift)?;
        BasicInteger::with_mode(self.mode, v)
    }
}
