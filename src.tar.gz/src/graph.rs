//! Deterministic native SVG graphing.
//!
//! Graphing is a host-native CLI facility, not a calculator screen emulator.
//! BASIC expressions and numeric data are converted into standalone bounded
//! SVG documents without third-party dependencies or hidden display state.

use crate::error::Error;
use crate::eval::evaluate_value;
use crate::integer::NumericMode;
use crate::real::BasicReal;
use crate::value::{Value, Variables};

/// Default raster-independent SVG width.
pub const DEFAULT_GRAPH_WIDTH: usize = 800;
/// Default raster-independent SVG height.
pub const DEFAULT_GRAPH_HEIGHT: usize = 600;
/// Maximum total sampled or plotted points in one output document.
pub const MAX_GRAPH_EXTENT: usize = 1_000_000;
/// Maximum line series in one graph.
pub const MAX_GRAPH_SERIES: usize = 16;
/// Maximum grid subdivisions along each axis.
pub const MAX_GRID_LINES: usize = 100;
/// Maximum histogram bin count.
pub const MAX_HISTOGRAM_BINS: usize = 10_000;

const CLASSIC_COLORS: [&str; 10] = [
    "#1565c0", "#c62828", "#2e7d32", "#6a1b9a", "#ef6c00", "#00838f", "#ad1457", "#4527a0",
    "#558b2f", "#4e342e",
];
const CONTRAST_COLORS: [&str; 8] = [
    "#000000", "#e69f00", "#56b4e9", "#009e73", "#f0e442", "#0072b2", "#d55e00", "#cc79a7",
];
const MONOCHROME_COLORS: [&str; 6] = [
    "#111111", "#3a3a3a", "#5f5f5f", "#838383", "#a7a7a7", "#cccccc",
];

/// Built-in deterministic color palettes for SVG output.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GraphPalette {
    Classic,
    Contrast,
    Monochrome,
}

/// Explicit bounds and resource limits for Cartesian graph output.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct GraphOptions {
    pub x_min: f64,
    pub x_max: f64,
    pub y_min: f64,
    pub y_max: f64,
    pub width: usize,
    pub height: usize,
    pub samples: usize,
    pub grid_lines: usize,
    pub palette: GraphPalette,
}

impl GraphOptions {
    /// Construct a conventional 800×600 graph with one sample per horizontal
    /// pixel, including both endpoints.
    pub fn new(x_min: f64, x_max: f64, y_min: f64, y_max: f64) -> Self {
        Self {
            x_min,
            x_max,
            y_min,
            y_max,
            width: DEFAULT_GRAPH_WIDTH,
            height: DEFAULT_GRAPH_HEIGHT,
            samples: DEFAULT_GRAPH_WIDTH + 1,
            grid_lines: 0,
            palette: GraphPalette::Classic,
        }
    }

    fn validate(self) -> Result<Self, Error> {
        if !self.x_min.is_finite()
            || !self.x_max.is_finite()
            || !self.y_min.is_finite()
            || !self.y_max.is_finite()
            || self.x_min >= self.x_max
            || self.y_min >= self.y_max
            || !(64..=8192).contains(&self.width)
            || !(64..=8192).contains(&self.height)
            || !(2..=MAX_GRAPH_EXTENT).contains(&self.samples)
            || self.grid_lines > MAX_GRID_LINES
        {
            return Err(Error::IllegalQuantity);
        }
        Ok(self)
    }
}

/// Explicit histogram bounds and resource limits.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct HistogramOptions {
    pub x_min: f64,
    pub x_max: f64,
    pub bins: usize,
    pub width: usize,
    pub height: usize,
    pub grid_lines: usize,
    pub palette: GraphPalette,
}

impl HistogramOptions {
    /// Construct an 800×600 histogram with automatic vertical scaling.
    pub fn new(x_min: f64, x_max: f64, bins: usize) -> Self {
        Self {
            x_min,
            x_max,
            bins,
            width: DEFAULT_GRAPH_WIDTH,
            height: DEFAULT_GRAPH_HEIGHT,
            grid_lines: 0,
            palette: GraphPalette::Classic,
        }
    }

    fn validate(self) -> Result<Self, Error> {
        if !self.x_min.is_finite()
            || !self.x_max.is_finite()
            || self.x_min >= self.x_max
            || !(1..=MAX_HISTOGRAM_BINS).contains(&self.bins)
            || !(64..=8192).contains(&self.width)
            || !(64..=8192).contains(&self.height)
            || self.grid_lines > MAX_GRID_LINES
        {
            return Err(Error::IllegalQuantity);
        }
        Ok(self)
    }
}

#[derive(Debug)]
struct LineSeries {
    label: String,
    points: Vec<Option<(f64, f64)>>,
}

/// Render one BASIC expression as a standalone deterministic SVG document.
pub fn render_function_svg(
    mode: NumericMode,
    expression: &str,
    options: GraphOptions,
) -> Result<String, Error> {
    render_functions_svg(mode, &[expression], options)
}

/// Render multiple `Y=f(X)` BASIC expressions into one deterministic SVG.
pub fn render_functions_svg(
    mode: NumericMode,
    expressions: &[&str],
    options: GraphOptions,
) -> Result<String, Error> {
    let options = options.validate()?;
    validate_series_budget(expressions.len(), options.samples)?;
    let mut series = Vec::with_capacity(expressions.len());
    for (index, expression) in expressions.iter().enumerate() {
        let points = sample_cartesian(mode, expression, options)?;
        series.push(LineSeries {
            label: format!("Y{}={expression}", index + 1),
            points,
        });
    }
    render_line_plot(&series, options)
}

/// Sample one or more `Y=f(X)` expressions into deterministic RFC-4180-style
/// CSV. Domain errors become empty fields rather than fabricated values. The
/// first column is `X`; other headers preserve the supplied expressions.
pub fn export_functions_csv(
    mode: NumericMode,
    expressions: &[&str],
    x_min: f64,
    x_max: f64,
    samples: usize,
) -> Result<String, Error> {
    validate_parameter_bounds(x_min, x_max)?;
    if !(2..=MAX_GRAPH_EXTENT).contains(&samples) {
        return Err(Error::IllegalQuantity);
    }
    validate_series_budget(expressions.len(), samples)?;
    let mut csv = String::with_capacity(
        samples
            .saturating_mul(expressions.len().saturating_add(1))
            .saturating_mul(16),
    );
    csv.push('X');
    for expression in expressions {
        csv.push(',');
        push_csv_field(&mut csv, expression);
    }
    csv.push('\n');

    let mut variables = Variables::new();
    for index in 0..samples {
        let x = BasicReal::new(interpolate(x_min, x_max, index, samples))?;
        csv.push_str(&x.to_string());
        variables.insert("X".into(), Value::Real(x));
        for expression in expressions {
            csv.push(',');
            if let Some(value) = evaluate_graph_real(mode, expression, &variables)? {
                csv.push_str(&BasicReal::new(value)?.to_string());
            }
        }
        csv.push('\n');
    }
    Ok(csv)
}

/// Render `X=f(T), Y=g(T)` over an explicit parameter interval.
pub fn render_parametric_svg(
    mode: NumericMode,
    x_expression: &str,
    y_expression: &str,
    parameter_min: f64,
    parameter_max: f64,
    options: GraphOptions,
) -> Result<String, Error> {
    let options = options.validate()?;
    validate_parameter_bounds(parameter_min, parameter_max)?;
    let points = sample_parametric(
        mode,
        x_expression,
        y_expression,
        parameter_min,
        parameter_max,
        options.samples,
    )?;
    render_line_plot(
        &[LineSeries {
            label: format!("X={x_expression}; Y={y_expression}"),
            points,
        }],
        options,
    )
}

/// Render `R=f(T)` as a polar curve over an explicit angular interval.
pub fn render_polar_svg(
    mode: NumericMode,
    radius_expression: &str,
    angle_min: f64,
    angle_max: f64,
    options: GraphOptions,
) -> Result<String, Error> {
    let options = options.validate()?;
    validate_parameter_bounds(angle_min, angle_max)?;
    let mut variables = Variables::new();
    let mut points = Vec::with_capacity(options.samples);
    for index in 0..options.samples {
        let angle = interpolate(angle_min, angle_max, index, options.samples);
        variables.insert("T".into(), Value::Real(BasicReal::new(angle)?));
        let point = evaluate_graph_real(mode, radius_expression, &variables)?
            .map(|radius| (radius * angle.cos(), radius * angle.sin()));
        points.push(point);
    }
    render_line_plot(
        &[LineSeries {
            label: format!("R={radius_expression}"),
            points,
        }],
        options,
    )
}

/// Render paired finite numeric data as a deterministic scatter plot.
pub fn render_scatter_svg(
    x_values: &[f64],
    y_values: &[f64],
    options: GraphOptions,
) -> Result<String, Error> {
    let options = options.validate()?;
    if x_values.is_empty()
        || x_values.len() != y_values.len()
        || x_values.len() > MAX_GRAPH_EXTENT
        || x_values
            .iter()
            .chain(y_values)
            .any(|value| !value.is_finite())
    {
        return Err(Error::IllegalQuantity);
    }
    let mut svg = begin_svg(options);
    draw_grid(&mut svg, options);
    draw_axes(&mut svg, options);
    draw_bounds(&mut svg, options);
    svg.push_str(&format!(
        "<g fill=\"{}\" clip-path=\"url(#plot-area)\">\n",
        series_color(options.palette, 0)
    ));
    for (x, y) in x_values.iter().copied().zip(y_values.iter().copied()) {
        if x < options.x_min || x > options.x_max || y < options.y_min || y > options.y_max {
            continue;
        }
        svg.push_str(&format!(
            "<circle cx=\"{:.3}\" cy=\"{:.3}\" r=\"3\"/>\n",
            map_x(x, options),
            map_y(y, options)
        ));
    }
    svg.push_str("</g>\n");
    draw_legend(&mut svg, &["SCATTER".into()], options.palette);
    end_svg(&mut svg);
    Ok(svg)
}

/// Render finite numeric data into fixed-width bins with automatic count scale.
pub fn render_histogram_svg(values: &[f64], options: HistogramOptions) -> Result<String, Error> {
    let options = options.validate()?;
    if values.is_empty()
        || values.len() > MAX_GRAPH_EXTENT
        || values.iter().any(|value| !value.is_finite())
    {
        return Err(Error::IllegalQuantity);
    }
    let mut counts = vec![0_usize; options.bins];
    let range = options.x_max - options.x_min;
    for value in values.iter().copied() {
        if value < options.x_min || value > options.x_max {
            continue;
        }
        let index = if value == options.x_max {
            options.bins - 1
        } else {
            (((value - options.x_min) / range) * options.bins as f64) as usize
        };
        counts[index] = counts[index].checked_add(1).ok_or(Error::IntegerOverflow)?;
    }
    let maximum = counts.iter().copied().max().unwrap_or(0);
    if maximum == 0 {
        return Err(Error::IllegalQuantity);
    }
    let y_max = (maximum as f64 * 1.1).max(1.0);
    let graph_options = GraphOptions {
        x_min: options.x_min,
        x_max: options.x_max,
        y_min: 0.0,
        y_max,
        width: options.width,
        height: options.height,
        samples: 2,
        grid_lines: options.grid_lines,
        palette: options.palette,
    }
    .validate()?;
    let mut svg = begin_svg(graph_options);
    draw_grid(&mut svg, graph_options);
    draw_axes(&mut svg, graph_options);
    draw_bounds(&mut svg, graph_options);
    svg.push_str(&format!(
        "<g fill=\"{}\" fill-opacity=\"0.78\" stroke=\"white\" stroke-width=\"1\" clip-path=\"url(#plot-area)\">\n",
        series_color(options.palette, 0)
    ));
    let bar_width = options.width as f64 / options.bins as f64;
    for (index, count) in counts.into_iter().enumerate() {
        let x = index as f64 * bar_width;
        let y = map_y(count as f64, graph_options);
        let height = options.height as f64 - y;
        svg.push_str(&format!(
            "<rect x=\"{x:.3}\" y=\"{y:.3}\" width=\"{bar_width:.3}\" height=\"{height:.3}\"/>\n"
        ));
    }
    svg.push_str("</g>\n");
    draw_legend(
        &mut svg,
        &[format!("HISTOGRAM ({} bins)", options.bins)],
        options.palette,
    );
    end_svg(&mut svg);
    Ok(svg)
}

fn validate_series_budget(series: usize, samples: usize) -> Result<(), Error> {
    if !(1..=MAX_GRAPH_SERIES).contains(&series)
        || series
            .checked_mul(samples)
            .map_or(true, |points| points > MAX_GRAPH_EXTENT)
    {
        return Err(Error::IllegalQuantity);
    }
    Ok(())
}

fn validate_parameter_bounds(minimum: f64, maximum: f64) -> Result<(), Error> {
    if !minimum.is_finite() || !maximum.is_finite() || minimum >= maximum {
        return Err(Error::IllegalQuantity);
    }
    Ok(())
}

fn interpolate(minimum: f64, maximum: f64, index: usize, count: usize) -> f64 {
    let fraction = index as f64 / (count - 1) as f64;
    minimum + fraction * (maximum - minimum)
}

fn sample_cartesian(
    mode: NumericMode,
    expression: &str,
    options: GraphOptions,
) -> Result<Vec<Option<(f64, f64)>>, Error> {
    let mut variables = Variables::new();
    let mut points = Vec::with_capacity(options.samples);
    for index in 0..options.samples {
        let x = interpolate(options.x_min, options.x_max, index, options.samples);
        variables.insert("X".into(), Value::Real(BasicReal::new(x)?));
        points.push(evaluate_graph_real(mode, expression, &variables)?.map(|y| (x, y)));
    }
    Ok(points)
}

fn sample_parametric(
    mode: NumericMode,
    x_expression: &str,
    y_expression: &str,
    parameter_min: f64,
    parameter_max: f64,
    samples: usize,
) -> Result<Vec<Option<(f64, f64)>>, Error> {
    let mut variables = Variables::new();
    let mut points = Vec::with_capacity(samples);
    for index in 0..samples {
        let parameter = interpolate(parameter_min, parameter_max, index, samples);
        variables.insert("T".into(), Value::Real(BasicReal::new(parameter)?));
        let x = evaluate_graph_real(mode, x_expression, &variables)?;
        let y = evaluate_graph_real(mode, y_expression, &variables)?;
        points.push(x.zip(y));
    }
    Ok(points)
}

fn evaluate_graph_real(
    mode: NumericMode,
    expression: &str,
    variables: &Variables,
) -> Result<Option<f64>, Error> {
    match evaluate_value(
        mode,
        expression,
        variables,
        mode.default_string_byte_limit(),
    ) {
        Ok(Value::Integer(value)) => Ok(Some(BasicReal::from_integer(value)?.value())),
        Ok(Value::Real(value)) => Ok(Some(value.value())),
        Ok(Value::Complex(value)) if value.is_real() => Ok(Some(value.real().value())),
        Ok(Value::Complex(_) | Value::List(_) | Value::String(_)) => Err(Error::TypeMismatch),
        Err(Error::DivideByZero | Error::MathDomain { .. } | Error::RealOverflow) => Ok(None),
        Err(error) => Err(error),
    }
}

fn render_line_plot(series: &[LineSeries], options: GraphOptions) -> Result<String, Error> {
    validate_series_budget(series.len(), options.samples)?;
    let mut svg = begin_svg(options);
    draw_grid(&mut svg, options);
    draw_axes(&mut svg, options);
    draw_bounds(&mut svg, options);
    let mut labels = Vec::with_capacity(series.len());
    for (index, item) in series.iter().enumerate() {
        draw_line_series(
            &mut svg,
            &item.points,
            options,
            series_color(options.palette, index),
        );
        labels.push(item.label.clone());
    }
    draw_legend(&mut svg, &labels, options.palette);
    end_svg(&mut svg);
    Ok(svg)
}

fn begin_svg(options: GraphOptions) -> String {
    let mut svg = String::with_capacity(options.samples.saturating_mul(24).saturating_add(2048));
    svg.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    svg.push_str(&format!(
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{}\" height=\"{}\" viewBox=\"0 0 {} {}\">\n",
        options.width, options.height, options.width, options.height
    ));
    svg.push_str("<defs><clipPath id=\"plot-area\"><rect width=\"100%\" height=\"100%\"/></clipPath></defs>\n");
    svg.push_str("<rect width=\"100%\" height=\"100%\" fill=\"white\"/>\n");
    svg
}

fn end_svg(svg: &mut String) {
    svg.push_str("</svg>\n");
}

fn draw_grid(svg: &mut String, options: GraphOptions) {
    if options.grid_lines < 2 {
        return;
    }
    svg.push_str("<g stroke=\"#e0e0e0\" stroke-width=\"1\">\n");
    for index in 1..options.grid_lines {
        let x = index as f64 / options.grid_lines as f64 * options.width as f64;
        let y = index as f64 / options.grid_lines as f64 * options.height as f64;
        svg.push_str(&format!(
            "<line x1=\"{x:.3}\" y1=\"0\" x2=\"{x:.3}\" y2=\"{}\"/>\n",
            options.height
        ));
        svg.push_str(&format!(
            "<line x1=\"0\" y1=\"{y:.3}\" x2=\"{}\" y2=\"{y:.3}\"/>\n",
            options.width
        ));
    }
    svg.push_str("</g>\n");
}

fn draw_axes(svg: &mut String, options: GraphOptions) {
    svg.push_str("<g stroke=\"#757575\" stroke-width=\"1\">\n");
    if (options.x_min..=options.x_max).contains(&0.0) {
        let x = map_x(0.0, options);
        svg.push_str(&format!(
            "<line x1=\"{x:.3}\" y1=\"0\" x2=\"{x:.3}\" y2=\"{}\"/>\n",
            options.height
        ));
    }
    if (options.y_min..=options.y_max).contains(&0.0) {
        let y = map_y(0.0, options);
        svg.push_str(&format!(
            "<line x1=\"0\" y1=\"{y:.3}\" x2=\"{}\" y2=\"{y:.3}\"/>\n",
            options.width
        ));
    }
    svg.push_str("</g>\n");
}

fn draw_bounds(svg: &mut String, options: GraphOptions) {
    svg.push_str("<g fill=\"#555\" font-family=\"monospace\" font-size=\"11\">\n");
    svg.push_str(&format!(
        "<text x=\"4\" y=\"{}\">x={}</text>\n",
        options.height.saturating_sub(4),
        options.x_min
    ));
    svg.push_str(&format!(
        "<text x=\"{}\" y=\"{}\" text-anchor=\"end\">x={}</text>\n",
        options.width.saturating_sub(4),
        options.height.saturating_sub(4),
        options.x_max
    ));
    svg.push_str(&format!(
        "<text x=\"{}\" y=\"12\" text-anchor=\"end\">y={}</text>\n",
        options.width.saturating_sub(4),
        options.y_max
    ));
    svg.push_str(&format!(
        "<text x=\"{}\" y=\"{}\" text-anchor=\"end\">y={}</text>\n",
        options.width.saturating_sub(4),
        options.height.saturating_sub(18),
        options.y_min
    ));
    svg.push_str("</g>\n");
}

fn draw_line_series(
    svg: &mut String,
    points: &[Option<(f64, f64)>],
    options: GraphOptions,
    color: &str,
) {
    svg.push_str(&format!(
        "<g fill=\"none\" stroke=\"{color}\" stroke-width=\"2\" stroke-linejoin=\"round\" clip-path=\"url(#plot-area)\">\n"
    ));
    let mut path = String::new();
    let mut open = false;
    let mut previous: Option<(f64, f64)> = None;
    for point in points {
        let Some((x, y)) = *point else {
            finish_path(svg, &mut path, &mut open);
            previous = None;
            continue;
        };
        let raw_y = map_y(y, options);
        let screen = (
            map_x(x, options),
            raw_y.clamp(-(options.height as f64) * 4.0, options.height as f64 * 5.0),
        );
        if !screen.0.is_finite() || !screen.1.is_finite() {
            finish_path(svg, &mut path, &mut open);
            previous = None;
            continue;
        }
        if let Some((_, previous_y)) = previous {
            // A very large screen-space jump is treated as an asymptote rather
            // than drawing a misleading line across the whole graph.
            if (screen.1 - previous_y).abs() > options.height as f64 * 4.0 {
                finish_path(svg, &mut path, &mut open);
            }
        }
        if !open {
            path.push_str(&format!("M{:.3},{:.3}", screen.0, screen.1));
            open = true;
        } else {
            path.push_str(&format!(" L{:.3},{:.3}", screen.0, screen.1));
        }
        previous = Some(screen);
    }
    finish_path(svg, &mut path, &mut open);
    svg.push_str("</g>\n");
}

fn finish_path(svg: &mut String, path: &mut String, open: &mut bool) {
    if *open {
        svg.push_str("<path d=\"");
        svg.push_str(path);
        svg.push_str("\"/>\n");
        path.clear();
        *open = false;
    }
}

fn draw_legend(svg: &mut String, labels: &[String], palette: GraphPalette) {
    svg.push_str("<g font-family=\"monospace\" font-size=\"13\">\n");
    for (index, label) in labels.iter().enumerate() {
        let y = 18 + index * 16;
        let color = series_color(palette, index);
        svg.push_str(&format!("<text x=\"10\" y=\"{y}\" fill=\"{color}\">"));
        escape_xml_into(label, svg);
        svg.push_str("</text>\n");
    }
    svg.push_str("</g>\n");
}

fn series_color(palette: GraphPalette, index: usize) -> &'static str {
    let colors: &[&str] = match palette {
        GraphPalette::Classic => &CLASSIC_COLORS,
        GraphPalette::Contrast => &CONTRAST_COLORS,
        GraphPalette::Monochrome => &MONOCHROME_COLORS,
    };
    colors[index % colors.len()]
}

fn map_x(value: f64, options: GraphOptions) -> f64 {
    (value - options.x_min) / (options.x_max - options.x_min) * options.width as f64
}

fn map_y(value: f64, options: GraphOptions) -> f64 {
    (options.y_max - value) / (options.y_max - options.y_min) * options.height as f64
}

fn escape_xml_into(text: &str, output: &mut String) {
    for character in text.chars() {
        match character {
            '&' => output.push_str("&amp;"),
            '<' => output.push_str("&lt;"),
            '>' => output.push_str("&gt;"),
            '"' => output.push_str("&quot;"),
            '\'' => output.push_str("&apos;"),
            _ => output.push(character),
        }
    }
}

fn push_csv_field(output: &mut String, text: &str) {
    output.push('"');
    for character in text.chars() {
        if character == '"' {
            output.push('"');
        }
        output.push(character);
    }
    output.push('"');
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn renders_deterministic_bounded_svg() {
        let mut options = GraphOptions::new(-2.0, 2.0, -1.0, 4.0);
        options.width = 320;
        options.height = 240;
        options.samples = 81;
        options.grid_lines = 4;
        let first = render_function_svg(NumericMode::Modern, "X^2", options).unwrap();
        let second = render_function_svg(NumericMode::Modern, "X^2", options).unwrap();
        assert_eq!(first, second);
        assert!(first.starts_with("<?xml"));
        assert!(first.contains("<svg"));
        assert!(first.contains("<path"));
        assert!(first.contains("Y1=X^2"));
        assert!(first.contains("#e0e0e0"));
        assert!(first.contains("clip-path"));
        assert!(first.len() < 12_000);
    }

    #[test]
    fn discontinuities_and_xml_are_handled_safely() {
        let mut options = GraphOptions::new(-1.0, 1.0, -5.0, 5.0);
        options.samples = 101;
        let svg = render_function_svg(NumericMode::Modern, "1/X+0<2", options).unwrap();
        assert!(svg.matches("<path").count() >= 2);
        assert!(svg.contains("Y1=1/X+0&lt;2"));
    }

    #[test]
    fn multiple_parametric_and_polar_curves_render() {
        let mut options = GraphOptions::new(-2.0, 2.0, -2.0, 2.0);
        options.samples = 101;
        let multi = render_functions_svg(NumericMode::Modern, &["X", "X^2"], options).unwrap();
        assert!(multi.contains("Y1=X"));
        assert!(multi.contains("Y2=X^2"));
        assert!(multi.contains(CLASSIC_COLORS[1]));

        let parametric = render_parametric_svg(
            NumericMode::Modern,
            "COS(T)",
            "SIN(T)",
            0.0,
            std::f64::consts::TAU,
            options,
        )
        .unwrap();
        assert!(parametric.contains("X=COS(T); Y=SIN(T)"));

        let polar = render_polar_svg(
            NumericMode::Modern,
            "1+COS(T)",
            0.0,
            std::f64::consts::TAU,
            options,
        )
        .unwrap();
        assert!(polar.contains("R=1+COS(T)"));
    }

    #[test]
    fn sampled_function_data_is_deterministic_csv() {
        let first = export_functions_csv(NumericMode::Modern, &["X^2", "1/X", "X+0"], -1.0, 1.0, 3)
            .unwrap();
        let second =
            export_functions_csv(NumericMode::Modern, &["X^2", "1/X", "X+0"], -1.0, 1.0, 3)
                .unwrap();
        assert_eq!(first, second);
        assert_eq!(first.lines().next(), Some("X,\"X^2\",\"1/X\",\"X+0\""));
        assert_eq!(first.lines().count(), 4);
        assert!(first.contains("0,0,,0"));
    }

    #[test]
    fn scatter_and_histogram_render_bounded_data() {
        let options = GraphOptions::new(0.0, 5.0, 0.0, 10.0);
        let scatter = render_scatter_svg(&[1.0, 2.0, 3.0], &[2.0, 4.0, 8.0], options).unwrap();
        assert_eq!(scatter.matches("<circle").count(), 3);
        assert!(scatter.contains("SCATTER"));

        let histogram = render_histogram_svg(
            &[0.0, 0.5, 1.0, 1.5, 2.0],
            HistogramOptions::new(0.0, 2.0, 4),
        )
        .unwrap();
        assert_eq!(histogram.matches("<rect x=").count(), 4);
        assert!(histogram.contains("HISTOGRAM (4 bins)"));
    }

    #[test]
    fn rejects_invalid_limits_types_and_resource_products() {
        let mut options = GraphOptions::new(1.0, 1.0, -1.0, 1.0);
        assert_eq!(
            render_function_svg(NumericMode::Modern, "X", options).unwrap_err(),
            Error::IllegalQuantity
        );
        options = GraphOptions::new(-1.0, 1.0, -1.0, 1.0);
        assert_eq!(
            render_function_svg(NumericMode::Modern, "\"NO\"", options).unwrap_err(),
            Error::TypeMismatch
        );
        options.samples = MAX_GRAPH_EXTENT;
        assert_eq!(
            render_functions_svg(NumericMode::Modern, &["X", "-X"], options).unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            render_scatter_svg(&[1.0], &[], GraphOptions::new(0.0, 2.0, 0.0, 2.0)).unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            render_histogram_svg(&[5.0], HistogramOptions::new(0.0, 1.0, 10)).unwrap_err(),
            Error::IllegalQuantity
        );
    }
}
