//! Runtime definitions for native BASIC `DEF FN` expressions.
//!
//! Microsoft BASIC user functions are numeric, take one or more numeric parameters,
//! and retain a tokenized expression for evaluation when called. Definitions
//! are runtime state: executing another definition with the same name replaces
//! it, while `CLEAR` and program `LOAD` discard all definitions.

use std::collections::HashMap;

use crate::tokens::TokenInstance;

/// One parsed numeric user-function definition.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct UserFunctionDefinition {
    pub parameters: Vec<String>,
    pub body: Vec<TokenInstance>,
}

/// Per-run map of executed `DEF FN` statements.
#[derive(Debug, Default)]
pub(crate) struct UserFunctions {
    definitions: HashMap<String, UserFunctionDefinition>,
}

impl UserFunctions {
    /// Insert or replace one definition.
    pub fn define(&mut self, name: String, parameters: Vec<String>, body: Vec<TokenInstance>) {
        self.definitions
            .insert(name, UserFunctionDefinition { parameters, body });
    }

    /// Retrieve a definition by its normalized name.
    pub fn get(&self, name: &str) -> Option<&UserFunctionDefinition> {
        self.definitions.get(name)
    }

    /// Remove every runtime definition.
    pub fn clear(&mut self) {
        self.definitions.clear();
    }
}

/// Normalize the conventional compact spelling `FNA(...)` to function name
/// `A`. Identifiers beginning with `FN` are reserved for this purpose, as in
/// the original tokenized language.
pub(crate) fn compact_function_name(identifier: &str) -> Option<&str> {
    identifier
        .strip_prefix("FN")
        .filter(|name| !name.is_empty())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tokens::tokenize;

    #[test]
    fn definitions_replace_and_clear_without_source_text_conversion() {
        let mut functions = UserFunctions::default();
        let first = tokenize("X+1").unwrap();
        let second = tokenize("Y*2").unwrap();
        functions.define("A".into(), vec!["X".into()], first);
        functions.define("A".into(), vec!["Y".into()], second.clone());
        assert_eq!(functions.get("A").unwrap().parameters, ["Y"]);
        assert_eq!(functions.get("A").unwrap().body, second);
        functions.clear();
        assert!(functions.get("A").is_none());
    }

    #[test]
    fn compact_names_reserve_only_identifiers_with_a_suffix() {
        assert_eq!(compact_function_name("FNA"), Some("A"));
        assert_eq!(compact_function_name("FNSQUARE"), Some("SQUARE"));
        assert_eq!(compact_function_name("FN"), None);
        assert_eq!(compact_function_name("AFN"), None);
    }
}
