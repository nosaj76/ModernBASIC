// =============================================================================
// sound/instrument_model.rs — Instrument parameter definitions
//
// Extracted from hybrid.rs (section: INSTRUMENT MODEL).
// Contains all static parameter structs that define an instrument's character.
// No DSP code — just data descriptions.
// =============================================================================

use std::fmt;

// ─── Top-level instrument model ──────────────────────────────────────

#[derive(Clone, Debug)]
pub struct InstrumentModel {
    pub name: String,
    pub exciter: ExciterParams,
    pub resonator: ResonatorParams,
    pub radiation: RadiationParams,
    pub fx: FxParams,
    // Envelope (per-instrument ADSR)
    pub attack_ms: f32,
    pub decay_ms: f32,
    pub sustain: f32,
    pub release_ms: f32,
    // Performance
    pub vel_brightness: f32,
    pub key_tracking: f32,
    pub wg_coupling: f32,
    pub output_gain: f32,
    // Filter envelope (separate from amp ADSR)
    pub filter_env_amount: f32,
    pub filter_env_attack: f32,
    pub filter_env_decay: f32,
    pub filter_env_sustain: f32,
    pub filter_env_release: f32,
}

impl Default for InstrumentModel {
    fn default() -> Self {
        Self {
            name: String::from("Init"),
            exciter: ExciterParams::default(),
            resonator: ResonatorParams::default(),
            radiation: RadiationParams::default(),
            fx: FxParams::default(),
            attack_ms: 10.0,
            decay_ms: 50.0,
            sustain: 0.8,
            release_ms: 100.0,
            vel_brightness: 0.3,
            key_tracking: 0.3,
            wg_coupling: 0.15,
            output_gain: 3.5,
            filter_env_amount: 0.0,
            filter_env_attack: 10.0,
            filter_env_decay: 200.0,
            filter_env_sustain: 0.0,
            filter_env_release: 100.0,
        }
    }
}

impl fmt::Display for InstrumentModel {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Instrument(\"{}\")", self.name)
    }
}

// ─── Exciter layer ───────────────────────────────────────────────────

#[derive(Clone, Debug)]
pub struct ExciterParams {
    pub bow_noise: f32,
    pub bow_friction_rate: f32,
    pub bow_pressure: f32,
    pub bow_speed: f32,
    pub bow_position: f32,
    pub rosin: f32,
    pub scratch: f32,
    pub vibrato_rate: f32,
    pub vibrato_depth: f32,
    pub breath_noise: f32,
    pub lip_tension: f32,
    pub lip_pressure: f32,
    pub reed_stiffness: f32,
    pub reed_airflow: f32,
    pub transient_strength: f32,
    pub transient_duration: u32,
}

impl Default for ExciterParams {
    fn default() -> Self {
        Self {
            bow_noise: 0.0,
            bow_friction_rate: 5.0,
            bow_pressure: 0.0,
            bow_speed: 0.35,
            bow_position: 0.12,
            rosin: 0.5,
            scratch: 0.15,
            vibrato_rate: 0.0,
            vibrato_depth: 0.0,
            breath_noise: 0.0,
            lip_tension: 0.0,
            lip_pressure: 0.0,
            reed_stiffness: 0.0,
            reed_airflow: 0.0,
            transient_strength: 0.0,
            transient_duration: 0,
        }
    }
}

// ─── Resonator layer ─────────────────────────────────────────────────

#[derive(Clone, Debug)]
pub struct ResonatorParams {
    pub additive: Option<AdditiveParams>,
    pub waveguide: Option<WaveguideParams>,
    pub modal: Option<ModalParams>,
    pub filter_cutoff: f32,
    pub filter_resonance: f32,
    pub filter_type: FilterType,
}

impl Default for ResonatorParams {
    fn default() -> Self {
        Self {
            additive: None,
            waveguide: None,
            modal: None,
            filter_cutoff: 20000.0,
            filter_resonance: 0.0,
            filter_type: FilterType::Lowpass,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum FilterType {
    Lowpass,
    Highpass,
    Bandpass,
}

// ─── Additive partial bank ───────────────────────────────────────────

#[derive(Clone, Debug)]
pub struct AdditiveParams {
    pub partials: Vec<PartialParam>,
}

impl Default for AdditiveParams {
    fn default() -> Self {
        Self {
            partials: vec![PartialParam {
                ratio: 1.0,
                amplitude: 1.0,
                decay: 1.0,
                stretch: 0.0,
            }],
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct PartialParam {
    pub ratio: f32,
    pub amplitude: f32,
    pub decay: f32,
    pub stretch: f32,
}

// ─── Waveguide parameters ────────────────────────────────────────────

#[derive(Clone, Copy, Debug)]
pub struct WaveguideParams {
    pub damping: f32,
    pub brightness: f32,
    pub pluck_position: f32,
    pub harmonic_weights: [f32; 8], // measured harmonic amplitudes H1..H8
}

impl Default for WaveguideParams {
    fn default() -> Self {
        Self {
            damping: 0.5,
            brightness: 0.5,
            pluck_position: 0.12,
            harmonic_weights: [1.0; 8],
        }
    }
}

// ─── Modal resonance parameters ──────────────────────────────────────

#[derive(Clone, Debug, Default)]
pub struct ModalParams {
    pub modes: Vec<ModalModeParam>,
}

#[derive(Clone, Copy, Debug)]
pub struct ModalModeParam {
    pub freq_ratio: f32,
    pub amplitude: f32,
    pub decay: f32,
    pub bandwidth: f32,
}

// ─── Radiation parameters ────────────────────────────────────────────

#[derive(Clone, Debug)]
pub struct RadiationParams {
    pub high_shelf_gain: f32,
    pub high_shelf_freq: f32,
    pub air_absorption: f32,
}

impl Default for RadiationParams {
    fn default() -> Self {
        Self {
            high_shelf_gain: 1.0,
            high_shelf_freq: 4000.0,
            air_absorption: 0.001,
        }
    }
}

// ─── Spatial / seat positioning ──────────────────────────────────────

#[derive(Clone, Debug)]
pub struct Seat {
    pub distance: f32,
    pub angle: f32,
    pub room_size: f32,
    pub direct_ratio: f32,
}

impl Default for Seat {
    fn default() -> Self {
        Self {
            distance: 2.0,
            angle: 0.0,
            room_size: 0.3,
            direct_ratio: 0.7,
        }
    }
}

// ─── Effects parameters ──────────────────────────────────────────────

#[derive(Clone, Debug)]
pub struct FxParams {
    pub reverb_mix: f32,
    pub reverb_decay: f32,
    pub reverb_damping: f32,
    pub chorus_mix: f32,
    pub chorus_rate: f32,
    pub chorus_depth: f32,
    pub delay_mix: f32,
    pub delay_time: f32,
    pub delay_feedback: f32,
}

impl Default for FxParams {
    fn default() -> Self {
        Self {
            reverb_mix: 0.15,
            reverb_decay: 1.5,
            reverb_damping: 0.4,
            chorus_mix: 0.0,
            chorus_rate: 1.5,
            chorus_depth: 0.002,
            delay_mix: 0.0,
            delay_time: 0.3,
            delay_feedback: 0.3,
        }
    }
}
