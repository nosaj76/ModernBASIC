// =============================================================================
// instrument_synth/banjo_body.rs — disabled: harmonic weights handle the spectrum
// =============================================================================

pub struct BanjoBody;

impl BanjoBody {
    pub fn new(_sample_rate: f64) -> Self {
        Self
    }

    #[inline]
    pub fn tick(&mut self, input: f64) -> f64 {
        input
    }
}
