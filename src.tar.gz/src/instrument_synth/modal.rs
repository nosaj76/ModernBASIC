// =============================================================================
// instrument_synth/modal.rs — modal resonator for instrument bodies
//
// Models the resonant modes of a banjo drumhead / guitar body / etc. as a
// bank of damped sinusoids.  Each mode has a frequency, amplitude, and decay
// time.  The exciter (pluck) injects energy into every mode simultaneously.
// This is the classic modal synthesis approach used in physical modeling.
// =============================================================================

use std::f64::consts::TAU;

/// One damped sinusoidal mode.
struct Mode {
    freq: f64,
    amp: f64,
    decay: f64, // per-sample decay factor
    phase: f64,
    energy: f64,
}

impl Mode {
    fn new(freq: f64, amp: f64, decay_ms: f64, sample_rate: f64, seed: f64) -> Self {
        // Random starting phase to avoid all modes lining up.
        let phase = (freq.sin() * 12345.0 + seed).fract() * TAU;
        let decay = (-1000.0 / (decay_ms.max(1.0) * sample_rate)).exp();
        Self {
            freq,
            amp,
            decay,
            phase,
            energy: 0.0,
        }
    }

    #[inline]
    fn excite(&mut self, amount: f64) {
        self.energy += amount * self.amp;
    }

    #[inline]
    fn tick(&mut self, sample_rate: f64) -> f64 {
        self.phase += TAU * self.freq / sample_rate;
        if self.phase >= TAU {
            self.phase -= TAU;
        }
        let out = self.energy * self.phase.sin();
        self.energy *= self.decay;
        out
    }
}

/// Modal resonator for a banjo drumhead.
pub struct BanjoMembrane {
    modes: Vec<Mode>,
    sr: f64,
}

impl BanjoMembrane {
    pub fn new(sample_rate: f64) -> Self {
        // Measured strong resonant peaks from clean banjo samples.
        // (freq Hz, relative amplitude, decay ms)
        let mode_params = [
            (390.0, 0.55, 90.0),
            (580.0, 0.75, 70.0),
            (785.0, 0.50, 60.0),
            (980.0, 0.40, 55.0),
            (1175.0, 0.35, 50.0),
            (1560.0, 0.20, 40.0),
        ];

        let mut modes = Vec::new();
        for (i, (freq, amp, decay_ms)) in mode_params.iter().enumerate() {
            modes.push(Mode::new(*freq, *amp, *decay_ms, sample_rate, i as f64));
        }

        Self {
            modes,
            sr: sample_rate,
        }
    }

    /// Excite all membrane modes with the pluck energy.
    #[inline]
    pub fn excite(&mut self, amount: f64) {
        for m in &mut self.modes {
            m.excite(amount);
        }
    }

    /// Generate one sample of ringing membrane sound.
    #[inline]
    pub fn tick(&mut self) -> f64 {
        self.modes.iter_mut().map(|m| m.tick(self.sr)).sum::<f64>()
    }
}

/// Modal resonator for a guitar body (warmer, fewer high modes).
pub struct GuitarBody {
    modes: Vec<Mode>,
    sr: f64,
}

impl GuitarBody {
    pub fn new(sample_rate: f64) -> Self {
        let mode_params = [
            (196.0, 0.40, 150.0), // G3 air resonance
            (295.0, 0.30, 140.0),
            (440.0, 0.25, 120.0),
            (550.0, 0.15, 100.0),
        ];
        let mut modes = Vec::new();
        for (i, (freq, amp, decay_ms)) in mode_params.iter().enumerate() {
            modes.push(Mode::new(*freq, *amp, *decay_ms, sample_rate, i as f64));
        }
        Self {
            modes,
            sr: sample_rate,
        }
    }

    #[inline]
    pub fn excite(&mut self, amount: f64) {
        for m in &mut self.modes {
            m.excite(amount);
        }
    }

    #[inline]
    pub fn tick(&mut self) -> f64 {
        self.modes.iter_mut().map(|m| m.tick(self.sr)).sum::<f64>()
    }
}
