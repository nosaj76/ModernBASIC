// =============================================================================
// instrument_synth/santur_body.rs — metallic modal resonator for the santur
//
// The santur is a hammered dulcimer: struck strings over a wooden soundboard.
// Its signature is a bright, metallic, bell-like ring with slightly inharmonic
// partials. We model the struck-string output passing through a bank of
// damped sinusoidal modes tuned to the santur's characteristic resonances.
// =============================================================================

use std::f64::consts::TAU;

/// One damped sinusoidal mode.
struct Mode {
    freq: f64,
    amp: f64,
    decay: f64, // per-sample decay factor
    phase: f64,
    energy: f64,
}

impl Mode {
    fn new(freq: f64, amp: f64, decay_ms: f64, sample_rate: f64, seed: f64) -> Self {
        // Random starting phase to avoid all modes lining up.
        let phase = (freq.sin() * 12345.0 + seed).fract() * TAU;
        let decay = (-1000.0 / (decay_ms.max(1.0) * sample_rate)).exp();
        Self {
            freq,
            amp,
            decay,
            phase,
            energy: 0.0,
        }
    }

    #[inline]
    fn excite(&mut self, amount: f64) {
        self.energy += amount * self.amp;
    }

    #[inline]
    fn tick(&mut self, sample_rate: f64) -> f64 {
        self.phase += TAU * self.freq / sample_rate;
        if self.phase >= TAU {
            self.phase -= TAU;
        }
        let out = self.energy * self.phase.sin();
        self.energy *= self.decay;
        out
    }
}

/// Metallic modal resonator for the santur soundboard.
pub struct SanturBody {
    modes: Vec<Mode>,
    sr: f64,
}

impl SanturBody {
    pub fn new(sample_rate: f64) -> Self {
        // Characteristic santur resonances: bright, metallic, slightly
        // inharmonic partials that ring out after the mallet strike.
        // (freq Hz, relative amplitude, decay ms)
        let mode_params = [
            (880.0, 0.10, 120.0),
            (1320.0, 0.08, 100.0),
            (1760.0, 0.07, 90.0),
            (2200.0, 0.06, 80.0),
            (2640.0, 0.05, 70.0),
            (3520.0, 0.04, 60.0),
        ];

        let mut modes = Vec::new();
        for (i, (freq, amp, decay_ms)) in mode_params.iter().enumerate() {
            modes.push(Mode::new(*freq, *amp, *decay_ms, sample_rate, i as f64));
        }

        Self {
            modes,
            sr: sample_rate,
        }
    }

    /// Excite all body modes with the struck-string energy.
    #[inline]
    pub fn excite(&mut self, amount: f64) {
        for m in &mut self.modes {
            m.excite(amount);
        }
    }

    /// Generate one sample of ringing metallic body sound.
    #[inline]
    pub fn tick(&mut self) -> f64 {
        self.modes.iter_mut().map(|m| m.tick(self.sr)).sum::<f64>()
    }
}
