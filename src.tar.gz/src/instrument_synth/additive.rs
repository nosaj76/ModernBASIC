// =============================================================================
// sound/synthesis/additive.rs — Additive partial synthesis engine
//
// Extracted from hybrid.rs (section: ADDITIVE PARTIAL SYNTHESIS ENGINE).
// Generates sound by summing individually controlled sine partials,
// each with its own frequency ratio, amplitude, decay, and inharmonicity.
//
// No heap allocation in the audio path.
// =============================================================================

use crate::instrument_synth::instrument_model::{AdditiveParams, PartialParam};

/// Maximum number of partials per voice (fixed allocation).
const MAX_PARTIALS: usize = 64;

/// Runtime state for a single partial oscillator.
#[derive(Clone, Debug)]
pub struct RuntimePartial {
    /// Current phase (0..TAU).
    pub phase: f64,
    /// Phase increment per sample.
    pub phase_inc: f64,
    /// Current amplitude (decays over time).
    pub amplitude: f64,
    /// Amplitude decay factor per sample (0.99999.. for slow, 0.999.. for fast).
    pub decay_factor: f64,
    /// Whether this partial is active.
    pub active: bool,
}

impl Default for RuntimePartial {
    fn default() -> Self {
        Self {
            phase: 0.0,
            phase_inc: 0.0,
            amplitude: 0.0,
            decay_factor: 1.0,
            active: false,
        }
    }
}

impl RuntimePartial {
    /// Reset partial for a new note.
    pub fn trigger(&mut self, freq: f64, param: &PartialParam, sample_rate: f64) {
        let actual_freq =
            freq * param.ratio as f64 * (1.0 + param.stretch as f64 * (param.ratio as f64 - 1.0));
        self.phase = 0.0;
        self.phase_inc = actual_freq * std::f64::consts::TAU / sample_rate;
        self.amplitude = param.amplitude as f64;
        // Convert decay time to per-sample factor
        let decay_samples = param.decay as f64 * sample_rate;
        self.decay_factor = if decay_samples > 0.0 {
            (-3.0 / decay_samples).exp() // -60dB in decay_samples
        } else {
            1.0
        };
        self.active = self.amplitude > 1e-8;
    }

    /// Generate one sample and advance phase.
    #[inline]
    pub fn tick(&mut self) -> f64 {
        if !self.active {
            return 0.0;
        }
        let sample = self.phase.sin() * self.amplitude;
        self.phase += self.phase_inc;
        if self.phase >= std::f64::consts::TAU {
            self.phase -= std::f64::consts::TAU;
        }
        self.amplitude *= self.decay_factor;
        if self.amplitude < 1e-8 {
            self.active = false;
        }
        sample
    }
}

/// Polyphonic additive voice — a bank of runtime partials.
pub struct AdditiveVoice {
    /// Fixed-size partial array (no heap allocation in audio path).
    pub partials: [RuntimePartial; MAX_PARTIALS],
    /// How many partials are actually in use (≤ MAX_PARTIALS).
    pub active_count: usize,
    /// Whether any partial is still sounding.
    pub active: bool,
}

impl AdditiveVoice {
    pub fn new() -> Self {
        Self {
            partials: std::array::from_fn(|_| RuntimePartial::default()),
            active_count: 0,
            active: false,
        }
    }

    /// Trigger all partials for a new note.
    pub fn trigger(&mut self, freq: f64, params: &AdditiveParams, sample_rate: f64) {
        self.active_count = params.partials.len().min(MAX_PARTIALS);
        for (i, param) in params.partials.iter().take(MAX_PARTIALS).enumerate() {
            self.partials[i].trigger(freq, param, sample_rate);
        }
        // Deactivate unused slots
        for i in self.active_count..MAX_PARTIALS {
            self.partials[i].active = false;
        }
        self.active = true;
    }

    /// Generate one sample from all active partials.
    #[inline]
    pub fn tick(&mut self) -> f64 {
        if !self.active {
            return 0.0;
        }
        let mut sum = 0.0;
        let mut any_active = false;
        for i in 0..self.active_count {
            let s = self.partials[i].tick();
            sum += s;
            any_active |= self.partials[i].active;
        }
        self.active = any_active;
        sum
    }

    /// Release all partials (apply fast decay).
    pub fn release(&mut self, release_factor: f64) {
        for i in 0..self.active_count {
            if self.partials[i].active {
                self.partials[i].decay_factor = release_factor;
            }
        }
    }

    /// Check if any partial is still sounding.
    pub fn is_active(&self) -> bool {
        self.active
    }
}

impl Default for AdditiveVoice {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_single_partial() {
        let params = AdditiveParams {
            partials: vec![PartialParam {
                ratio: 1.0,
                amplitude: 1.0,
                decay: 1.0,
                stretch: 0.0,
            }],
        };
        let mut voice = AdditiveVoice::new();
        voice.trigger(440.0, &params, 44100.0);

        // Generate a few samples — should be non-zero
        let _s1 = voice.tick();
        let s2 = voice.tick();
        assert!(voice.is_active());
        // First sample is sin(0) = 0, second should be non-zero
        assert!(s2.abs() > 0.0);
    }

    #[test]
    fn test_partials_decay() {
        let params = AdditiveParams {
            partials: vec![PartialParam {
                ratio: 1.0,
                amplitude: 1.0,
                decay: 0.001,
                stretch: 0.0,
            }],
        };
        let mut voice = AdditiveVoice::new();
        voice.trigger(440.0, &params, 44100.0);

        // Run for many samples — should eventually go silent
        for _ in 0..100000 {
            voice.tick();
        }
        assert!(!voice.is_active());
    }
}
