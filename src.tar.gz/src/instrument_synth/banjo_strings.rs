use crate::instrument_synth::{WaveguideParams, WaveguideString};

const BANJO_STRINGS: [(f64, f64); 5] = [
    (392.00, 0.45),
    (146.83, 0.20),
    (196.00, 0.25),
    (246.94, 0.22),
    (293.66, 0.30),
];

pub struct BanjoStringSet {
    strings: Vec<WaveguideString>,
    amps: Vec<f64>,
    open_freqs: Vec<f64>,
    params: WaveguideParams,
    sample_rate: f64,
}

impl BanjoStringSet {
    pub fn new(params: WaveguideParams, sample_rate: f64) -> Self {
        let mut strings = Vec::with_capacity(5);
        let mut amps = Vec::with_capacity(5);
        let mut open_freqs = Vec::with_capacity(5);
        for (freq, amp) in BANJO_STRINGS {
            let mut wg = WaveguideString::new();
            wg.trigger(freq, &params, sample_rate);
            strings.push(wg);
            amps.push(amp);
            open_freqs.push(freq);
        }
        Self {
            strings,
            amps,
            open_freqs,
            params,
            sample_rate,
        }
    }

    pub fn pluck(&mut self, note_hz: f64) {
        let mut best_idx = 0;
        let mut best_score = f64::MAX;
        for (i, open) in self.open_freqs.iter().enumerate() {
            let ratio = note_hz / open;
            let semi = 12.0 * ratio.log2();
            let score = if semi < -2.0 { 1000.0 } else { semi.abs() };
            if score < best_score {
                best_score = score;
                best_idx = i;
            }
        }
        self.strings[best_idx].trigger(note_hz, &self.params, self.sample_rate);
        for (i, open) in self.open_freqs.iter().enumerate() {
            if i == best_idx {
                continue;
            }
            let ratio = note_hz / open;
            let nearest = ratio.round();
            if (ratio - nearest).abs() < 0.05 && nearest > 0.0 && nearest <= 4.0 {
                self.strings[i].inject((0.12 / nearest) as f32);
            }
        }
    }

    pub fn tick(&mut self) -> f32 {
        let mut out = 0.0_f32;
        for (wg, amp) in self.strings.iter_mut().zip(self.amps.iter()) {
            if wg.is_active() {
                out += wg.tick() * (*amp as f32);
            }
        }
        out
    }
}
