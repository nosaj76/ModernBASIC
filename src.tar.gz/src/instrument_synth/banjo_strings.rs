use crate::instrument_synth::{WaveguideParams, WaveguideString};

// Standard five-string banjo tuning: short G4 drone, then D3 G3 B3 D4.
const BANJO_OPEN_FREQUENCIES: [f64; 5] = [392.00, 146.83, 196.00, 246.94, 293.66];

pub struct BanjoStringSet {
    strings: [WaveguideString; 5],
    gains: [f32; 5],
    params: WaveguideParams,
    sample_rate: f64,
}

impl BanjoStringSet {
    pub fn new(params: WaveguideParams, sample_rate: f64) -> Self {
        Self {
            // Construction must be silent. Triggering every open string here
            // made each requested note begin as an unintended five-note chord.
            strings: std::array::from_fn(|_| WaveguideString::new()),
            gains: [0.0; 5],
            params,
            sample_rate,
        }
    }

    pub fn pluck(&mut self, note_hz: f64) {
        let best_idx = string_for_note(note_hz);
        self.gains.fill(0.0);
        self.strings[best_idx].trigger(note_hz, &self.params, self.sample_rate);
        self.gains[best_idx] = 1.0;

        // Quietly ring only open strings close to an integer harmonic. An
        // inactive delay line cannot be excited with `inject`, so initialize
        // each selected sympathetic string explicitly.
        for (i, open) in BANJO_OPEN_FREQUENCIES.iter().enumerate() {
            if i == best_idx {
                continue;
            }
            let ratio = note_hz / open;
            let nearest = ratio.round();
            if (ratio - nearest).abs() < 0.05 && nearest > 0.0 && nearest <= 4.0 {
                self.strings[i].trigger(*open, &self.params, self.sample_rate);
                self.gains[i] = 0.10 / nearest as f32;
            }
        }
    }

    pub fn tick(&mut self) -> f32 {
        let mut out = 0.0_f32;
        for (wg, gain) in self.strings.iter_mut().zip(self.gains) {
            if wg.is_active() {
                out += wg.tick() * gain;
            }
        }
        out
    }
}

fn string_for_note(note_hz: f64) -> usize {
    BANJO_OPEN_FREQUENCIES
        .iter()
        .enumerate()
        .filter_map(|(index, open)| {
            let semitones = 12.0 * (note_hz / open).log2();
            (semitones >= 0.0).then_some((index, semitones))
        })
        .min_by(|left, right| left.1.total_cmp(&right.1))
        .map(|(index, _)| index)
        // Notes below the tuning range use the lowest full-length string.
        .unwrap_or(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_new_banjo_voice_is_silent_until_plucked() {
        let mut strings = BanjoStringSet::new(WaveguideParams::default(), 44_100.0);
        assert!((0..512).all(|_| strings.tick() == 0.0));
        assert!(strings.strings.iter().all(|string| !string.is_active()));
    }

    #[test]
    fn fretted_notes_never_select_an_open_string_above_the_note() {
        assert_eq!(string_for_note(130.81), 1); // C3, below the lowest open D3.
        assert_eq!(string_for_note(146.83), 1); // Open D3.
        assert_eq!(string_for_note(261.63), 3); // C4 is fretted on B3.
        assert_eq!(string_for_note(440.00), 0); // A4 is fretted on short G4.
    }

    #[test]
    fn the_selected_string_has_stable_full_level() {
        let mut strings = BanjoStringSet::new(WaveguideParams::default(), 44_100.0);
        strings.pluck(261.63);
        assert_eq!(strings.gains[3], 1.0);
        assert!(strings.strings[3].is_active());
        assert!((0..512).any(|_| strings.tick().abs() > 0.001));
    }
}
