// =============================================================================
// sound/synthesis/waveguide.rs — Karplus–Strong waveguide string model
//
// Extracted from hybrid.rs (section: KARPLUS–STRONG WAVEGUIDE STRING MODEL).
// Physical model of a vibrating string using a delay line with feedback filter.
//
// No heap allocation in audio path (fixed-size delay buffer).
// =============================================================================

/// Maximum delay line length (supports frequencies down to ~20 Hz at 48 kHz).
const MAX_DELAY: usize = 2400;

/// Parameters for the one physical-string model used by ModernBASIC.
#[derive(Clone, Copy, Debug)]
pub struct WaveguideParams {
    pub damping: f32,
    pub brightness: f32,
    pub pluck_position: f32,
    pub harmonic_weights: [f32; 8],
}

impl Default for WaveguideParams {
    fn default() -> Self {
        Self {
            damping: 0.5,
            brightness: 0.5,
            pluck_position: 0.12,
            harmonic_weights: [1.0; 8],
        }
    }
}

/// A single waveguide string — delay line + lowpass feedback.
pub struct WaveguideString {
    /// Circular delay buffer (fixed allocation).
    buffer: [f32; MAX_DELAY],
    /// Write position in the delay buffer.
    write_pos: usize,
    /// Delay length in samples (fractional for tuning accuracy).
    delay_len: usize,
    /// One-pole lowpass state for damping.
    lp_state: f32,
    /// Damping coefficient (0..1, higher = more damping = duller sound).
    damping: f32,
    /// Brightness coefficient (controls lowpass cutoff).
    brightness: f32,
    /// Whether the string is active.
    pub active: bool,
}

impl WaveguideString {
    pub fn new() -> Self {
        Self {
            buffer: [0.0; MAX_DELAY],
            write_pos: 0,
            delay_len: 100,
            lp_state: 0.0,
            damping: 0.5,
            brightness: 0.5,
            active: false,
        }
    }

    /// Excite the string for a new note.
    ///
    /// `freq` — fundamental frequency in Hz.
    /// `params` — waveguide parameters (damping, brightness).
    /// `sample_rate` — audio sample rate.
    pub fn trigger(&mut self, freq: f64, params: &WaveguideParams, sample_rate: f64) {
        // Calculate delay length from frequency
        let period = sample_rate / freq;
        self.delay_len = (period as usize).clamp(2, MAX_DELAY - 1);
        self.damping = params.damping;
        self.brightness = params.brightness;
        self.lp_state = 0.0;

        // Pluck-position excitation.  Plucking a string at position `p`
        // (fraction of string length from the bridge) sets the harmonic
        // amplitudes to sin(n * PI * p).  Near the bridge (small p) the
        // fundamental is weak and the 2nd/3rd/4th harmonics dominate — the
        // banjo's signature.  We build the initial delay-line shape as the
        // weighted sum of the first several harmonics.
        let pluck_position = params.pluck_position as f64;
        let harmonics = 8;
        // Use measured harmonic weights if they differ from default all-1.0,
        // otherwise fall back to the pluck-position formula.
        let weights = params.harmonic_weights;
        let use_measured = weights.iter().any(|w| *w != 1.0);
        for i in 0..self.delay_len {
            let phase = i as f64 / self.delay_len as f64;
            let mut value = 0.0_f64;
            for n in 1..=harmonics {
                let amp = if use_measured {
                    weights[n - 1] as f64
                } else {
                    (std::f64::consts::PI * pluck_position * n as f64).sin()
                };
                value += amp * (std::f64::consts::TAU * n as f64 * phase).sin();
            }
            self.buffer[i] = value as f32;
        }
        // Normalize to roughly [-1, 1]
        let max_abs: f32 = self.buffer[..self.delay_len]
            .iter()
            .map(|s| s.abs())
            .fold(0.0_f32, f32::max)
            .max(0.0001);
        for i in 0..self.delay_len {
            self.buffer[i] /= max_abs;
        }
        // Add a small scrape of noise at the attack.
        let mut rng_state: u32 = (freq * 1000.0) as u32 ^ 0xDEADBEEF;
        let scrape_len = self.delay_len.min(6);
        for i in 0..scrape_len {
            rng_state ^= rng_state << 13;
            rng_state ^= rng_state >> 17;
            rng_state ^= rng_state << 5;
            let pos = (self.write_pos + i + 1) % self.delay_len;
            self.buffer[pos] += ((rng_state as f32 / u32::MAX as f32) * 2.0 - 1.0) * 0.12;
        }
        for i in self.delay_len..MAX_DELAY {
            self.buffer[i] = 0.0;
        }
        self.write_pos = 0;
        self.active = true;
    }

    /// Generate one output sample and advance the waveguide.
    #[inline]
    pub fn tick(&mut self) -> f32 {
        if !self.active {
            return 0.0;
        }

        // Read from delay line (oldest sample)
        let read_pos = (self.write_pos + 1) % self.delay_len;
        let delayed = self.buffer[read_pos];

        // One-pole lowpass filter (averaging filter with brightness control)
        // brightness 1.0 = no filtering, 0.0 = heavy filtering
        let coeff = self.brightness.clamp(0.01, 0.999);
        self.lp_state = coeff * delayed + (1.0 - coeff) * self.lp_state;

        // Apply damping (energy loss per round trip).
        // `damping` is interpreted as the fraction of energy lost over one
        // complete round trip of the delay line, so it must be distributed
        // across `delay_len` samples.  damping=0.5 means the note loses half
        // its energy after one period (plucked string decay).
        let per_sample_damping = self.damping / self.delay_len.max(1) as f32;
        let feedback = self.lp_state * (1.0 - per_sample_damping.clamp(0.0, 1.0));

        // Write filtered sample back into delay line
        self.buffer[self.write_pos] = feedback;

        // Advance write position
        self.write_pos = (self.write_pos + 1) % self.delay_len;

        // Check if string has decayed to silence
        if feedback.abs() < 1e-7 {
            // Check a few more points to be sure
            let mid = self.delay_len / 2;
            if self.buffer[mid].abs() < 1e-7 {
                self.active = false;
            }
        }

        delayed
    }

    /// Apply release damping (increase damping to fade out faster).
    pub fn release(&mut self, extra_damping: f32) {
        self.damping = (self.damping + extra_damping).min(1.0);
    }

    /// Check if the string has any energy left.
    pub fn is_active(&self) -> bool {
        self.active
    }

    /// Get the current energy level (RMS of delay buffer).
    pub fn energy(&self) -> f32 {
        if !self.active {
            return 0.0;
        }
        let sum: f32 = self.buffer[..self.delay_len].iter().map(|s| s * s).sum();
        (sum / self.delay_len as f32).sqrt()
    }
}

impl Default for WaveguideString {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_waveguide_produces_sound() {
        let params = WaveguideParams {
            damping: 0.3,
            brightness: 0.8,
            pluck_position: 0.12,
            harmonic_weights: [1.0; 8],
        };
        let mut wg = WaveguideString::new();
        wg.trigger(440.0, &params, 44100.0);

        let mut max_sample = 0.0f32;
        for _ in 0..1000 {
            let s = wg.tick();
            max_sample = max_sample.max(s.abs());
        }
        assert!(wg.is_active());
        assert!(max_sample > 0.01);
    }

    #[test]
    fn test_waveguide_decays() {
        let params = WaveguideParams {
            damping: 0.9,
            brightness: 0.3,
            pluck_position: 0.12,
            harmonic_weights: [1.0; 8],
        };
        let mut wg = WaveguideString::new();
        wg.trigger(440.0, &params, 44100.0);

        // Run for many samples — high damping should silence quickly
        for _ in 0..500000 {
            wg.tick();
        }
        assert!(!wg.is_active());
    }
}
