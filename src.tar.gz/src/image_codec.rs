//! Bounded still-image decoding and high-quality alpha-aware resampling.
//!
//! P6 PPM remains the dependency-free native interchange format. Common
//! photographic formats are decoded through a fixed-argument FFmpeg boundary;
//! no shell text, network URL, filter, or codec option comes from BASIC.

use std::collections::HashMap;
use std::fs::File;
use std::io::{BufRead, BufReader, Read};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, OnceLock, RwLock, Weak};

use crate::artist_scene::MAX_ARTIST_PIXELS;
use crate::error::Error;

pub(crate) const MAX_IMAGE_FILE_BYTES: usize = 256 * 1_048_576;
const MAX_PPM_HEADER_BYTES: usize = 64 * 1_024;
const MEMORY_IMAGE_PREFIX: &str = "/__modernbasic_memory_image__/";

static NEXT_MEMORY_IMAGE: AtomicU64 = AtomicU64::new(1);
static MEMORY_IMAGES: OnceLock<RwLock<HashMap<PathBuf, Weak<RgbImage>>>> = OnceLock::new();

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct RgbImage {
    pub(crate) width: usize,
    pub(crate) height: usize,
    pub(crate) pixels: Vec<[u8; 3]>,
    pub(crate) alpha: Vec<u8>,
}

impl RgbImage {
    pub(crate) fn to_ppm(&self) -> Result<Vec<u8>, Error> {
        validate_dimensions(self.width, self.height)?;
        if self.pixels.len() != self.width * self.height
            || self.alpha.len() != self.width * self.height
        {
            return Err(Error::Io("image pixel storage has the wrong length".into()));
        }
        let mut ppm = Vec::with_capacity(self.pixels.len() * 3 + 64);
        ppm.extend_from_slice(b"P6\n");
        ppm.extend_from_slice(format!("{} {}\n255\n", self.width, self.height).as_bytes());
        for (pixel, alpha) in self.pixels.iter().zip(&self.alpha) {
            let alpha = u16::from(*alpha);
            for channel in pixel {
                ppm.push(((u16::from(*channel) * alpha + 127) / 255) as u8);
            }
        }
        Ok(ppm)
    }
}

/// Register a decoded program asset under an engine-private virtual path.
///
/// Artist scenes remain serializable strings, so BITMAP commands retain this
/// path instead of a host filename. The registry stores only a weak reference:
/// the owning interpreter controls the asset lifetime and stale entries cannot
/// pin arbitrary images after a program is replaced.
pub(crate) fn register_memory_image(image: &Arc<RgbImage>, extension: &str) -> PathBuf {
    let id = NEXT_MEMORY_IMAGE.fetch_add(1, Ordering::Relaxed);
    let extension = extension
        .chars()
        .filter(|character| character.is_ascii_alphanumeric())
        .collect::<String>();
    let extension = if extension.is_empty() {
        "img"
    } else {
        &extension
    };
    let path = PathBuf::from(format!("{MEMORY_IMAGE_PREFIX}{id}.{extension}"));
    let registry = MEMORY_IMAGES.get_or_init(|| RwLock::new(HashMap::new()));
    if let Ok(mut registry) = registry.write() {
        registry.retain(|_, image| image.strong_count() != 0);
        registry.insert(path.clone(), Arc::downgrade(image));
    }
    path
}

fn memory_image(path: &Path) -> Option<Arc<RgbImage>> {
    if !path.to_string_lossy().starts_with(MEMORY_IMAGE_PREFIX) {
        return None;
    }
    MEMORY_IMAGES
        .get()
        .and_then(|registry| registry.read().ok())
        .and_then(|registry| registry.get(path).and_then(Weak::upgrade))
}

pub(crate) fn decode_image(path: &Path) -> Result<RgbImage, Error> {
    if let Some(image) = memory_image(path) {
        return Ok((*image).clone());
    }
    let metadata = std::fs::metadata(path)
        .map_err(|error| Error::Io(format!("cannot read image: {error}")))?;
    if !metadata.is_file() {
        return Err(Error::InvalidFilePath);
    }
    if metadata.len() > MAX_IMAGE_FILE_BYTES as u64 {
        return Err(Error::FileLimitExceeded {
            limit: MAX_IMAGE_FILE_BYTES,
        });
    }
    let extension = extension(path)?;
    if extension == "ppm" {
        let reader = BufReader::new(File::open(path)?);
        return read_ppm(reader)?.ok_or_else(|| Error::Io("empty PPM image".into()));
    }
    if !matches!(
        extension.as_str(),
        "png" | "jpg" | "jpeg" | "webp" | "bmp" | "tif" | "tiff"
    ) {
        return Err(Error::syntax(
            "BITMAP image must end in .ppm, .png, .jpg, .jpeg, .webp, .bmp, .tif, or .tiff",
        ));
    }
    let (width, height) = probe_image_dimensions(path)?;
    validate_dimensions(width, height)?;
    let ffmpeg = find_ffmpeg().ok_or_else(|| {
        Error::Io("compressed BITMAP input requires FFmpeg on the host system".into())
    })?;
    let mut child = Command::new(ffmpeg)
        .arg("-nostdin")
        .arg("-loglevel")
        .arg("error")
        .arg("-i")
        .arg(path)
        .arg("-frames:v")
        .arg("1")
        .arg("-an")
        .arg("-pix_fmt")
        .arg("rgba")
        .arg("-f")
        .arg("rawvideo")
        .arg("pipe:1")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot start image decoder: {error}")))?;
    let mut stdout = child
        .stdout
        .take()
        .ok_or_else(|| Error::Io("cannot open image decoder output".into()))?;
    let byte_count = width
        .checked_mul(height)
        .and_then(|pixels| pixels.checked_mul(4))
        .ok_or(Error::IntegerOverflow)?;
    let mut bytes = Vec::with_capacity(byte_count);
    if let Err(error) = stdout
        .by_ref()
        .take(byte_count as u64 + 1)
        .read_to_end(&mut bytes)
    {
        let _ = child.kill();
        let _ = child.wait();
        return Err(error.into());
    }
    let status = child.wait()?;
    if !status.success() {
        return Err(Error::Io(format!("image decoder exited with {status}")));
    }
    if bytes.len() != byte_count {
        return Err(Error::Io(
            "image decoder produced an incomplete frame".into(),
        ));
    }
    let mut pixels = Vec::with_capacity(width * height);
    let mut alpha = Vec::with_capacity(width * height);
    for pixel in bytes.chunks_exact(4) {
        pixels.push([pixel[0], pixel[1], pixel[2]]);
        alpha.push(pixel[3]);
    }
    Ok(RgbImage {
        width,
        height,
        pixels,
        alpha,
    })
}

pub(crate) fn probe_image_dimensions(path: &Path) -> Result<(usize, usize), Error> {
    if let Some(image) = memory_image(path) {
        return Ok((image.width, image.height));
    }
    if extension(path)? == "ppm" {
        let mut reader = BufReader::new(File::open(path)?);
        let magic = ppm_token(&mut reader)?.ok_or_else(|| Error::Io("empty PPM image".into()))?;
        if magic != b"P6" {
            return Err(Error::Io("bitmap must be P6 PPM".into()));
        }
        let width = parse_ppm_usize(
            &ppm_token(&mut reader)?.ok_or_else(|| Error::Io("missing PPM width".into()))?,
            "width",
        )?;
        let height = parse_ppm_usize(
            &ppm_token(&mut reader)?.ok_or_else(|| Error::Io("missing PPM height".into()))?,
            "height",
        )?;
        validate_dimensions(width, height)?;
        return Ok((width, height));
    }
    let ffprobe = find_ffprobe().ok_or_else(|| {
        Error::Io("compressed BITMAP input requires FFprobe on the host system".into())
    })?;
    let output = Command::new(ffprobe)
        .arg("-v")
        .arg("error")
        .arg("-select_streams")
        .arg("v:0")
        .arg("-show_entries")
        .arg("stream=width,height")
        .arg("-of")
        .arg("csv=p=0:s=x")
        .arg(path)
        .stdin(Stdio::null())
        .stderr(Stdio::null())
        .output()
        .map_err(|error| Error::Io(format!("cannot start image probe: {error}")))?;
    if !output.status.success() || output.stdout.len() > 128 {
        return Err(Error::Io("image probe failed".into()));
    }
    let text = std::str::from_utf8(&output.stdout)
        .map_err(|_| Error::Io("image probe returned invalid text".into()))?
        .trim();
    let (width, height) = text
        .split_once('x')
        .ok_or_else(|| Error::Io("image probe returned invalid dimensions".into()))?;
    let width = width
        .parse::<usize>()
        .map_err(|_| Error::Io("image probe returned invalid width".into()))?;
    let height = height
        .parse::<usize>()
        .map_err(|_| Error::Io("image probe returned invalid height".into()))?;
    validate_dimensions(width, height)?;
    Ok((width, height))
}

pub(crate) fn read_ppm<R: Read>(reader: R) -> Result<Option<RgbImage>, Error> {
    let mut reader = BufReader::new(reader);
    read_ppm_frame(&mut reader)
}

/// Read exactly one P6 frame while preserving buffered bytes for the next
/// frame in an image2pipe stream.
pub(crate) fn read_ppm_frame<R: BufRead>(reader: &mut R) -> Result<Option<RgbImage>, Error> {
    let Some(magic) = ppm_token(reader)? else {
        return Ok(None);
    };
    if magic != b"P6" {
        return Err(Error::Io("image stream must contain P6 PPM frames".into()));
    }
    let width = parse_ppm_usize(
        &ppm_token(reader)?.ok_or_else(|| Error::Io("missing PPM width".into()))?,
        "width",
    )?;
    let height = parse_ppm_usize(
        &ppm_token(reader)?.ok_or_else(|| Error::Io("missing PPM height".into()))?,
        "height",
    )?;
    let maximum = parse_ppm_usize(
        &ppm_token(reader)?.ok_or_else(|| Error::Io("missing PPM maximum".into()))?,
        "maximum value",
    )?;
    if maximum != 255 {
        return Err(Error::Io("PPM maximum value must be 255".into()));
    }
    validate_dimensions(width, height)?;
    let mut separator = [0_u8; 1];
    reader.read_exact(&mut separator)?;
    if !separator[0].is_ascii_whitespace() {
        return Err(Error::Io("PPM image has no pixel separator".into()));
    }
    if separator[0] == b'\r' && reader.fill_buf()?.first() == Some(&b'\n') {
        reader.consume(1);
    }
    let byte_count = width
        .checked_mul(height)
        .and_then(|count| count.checked_mul(3))
        .ok_or(Error::IntegerOverflow)?;
    let mut bytes = vec![0_u8; byte_count];
    reader.read_exact(&mut bytes)?;
    let pixels = bytes
        .chunks_exact(3)
        .map(|pixel| [pixel[0], pixel[1], pixel[2]])
        .collect();
    Ok(Some(RgbImage {
        width,
        height,
        pixels,
        alpha: vec![255; width * height],
    }))
}

pub(crate) fn fit_letterboxed(
    source: &RgbImage,
    target_width: usize,
    target_height: usize,
) -> Result<RgbImage, Error> {
    validate_dimensions(target_width, target_height)?;
    if source.width == target_width && source.height == target_height {
        return Ok(source.clone());
    }
    let scale = (target_width as f64 / source.width as f64)
        .min(target_height as f64 / source.height as f64);
    let scaled_width = ((source.width as f64 * scale).round() as usize).clamp(1, target_width);
    let scaled_height = ((source.height as f64 * scale).round() as usize).clamp(1, target_height);
    let scaled = resize_bilinear(source, scaled_width, scaled_height)?;
    let mut output = RgbImage {
        width: target_width,
        height: target_height,
        pixels: vec![[0, 0, 0]; target_width * target_height],
        alpha: vec![255; target_width * target_height],
    };
    let offset_x = (target_width - scaled_width) / 2;
    let offset_y = (target_height - scaled_height) / 2;
    for y in 0..scaled_height {
        let source_start = y * scaled_width;
        let target_start = (offset_y + y) * target_width + offset_x;
        output.pixels[target_start..target_start + scaled_width]
            .copy_from_slice(&scaled.pixels[source_start..source_start + scaled_width]);
        output.alpha[target_start..target_start + scaled_width]
            .copy_from_slice(&scaled.alpha[source_start..source_start + scaled_width]);
    }
    Ok(output)
}

pub(crate) fn resize_bilinear(
    source: &RgbImage,
    width: usize,
    height: usize,
) -> Result<RgbImage, Error> {
    validate_dimensions(width, height)?;
    if source.width == width && source.height == height {
        return Ok(source.clone());
    }
    let mut pixels = Vec::with_capacity(width * height);
    let mut alpha = Vec::with_capacity(width * height);
    for y in 0..height {
        let source_y = ((y as f64 + 0.5) * source.height as f64 / height as f64 - 0.5)
            .clamp(0.0, (source.height - 1) as f64);
        let y0 = source_y.floor() as usize;
        let y1 = (y0 + 1).min(source.height - 1);
        let fy = source_y - y0 as f64;
        for x in 0..width {
            let source_x = ((x as f64 + 0.5) * source.width as f64 / width as f64 - 0.5)
                .clamp(0.0, (source.width - 1) as f64);
            let x0 = source_x.floor() as usize;
            let x1 = (x0 + 1).min(source.width - 1);
            let fx = source_x - x0 as f64;
            let weights = [
                (1.0 - fx) * (1.0 - fy),
                fx * (1.0 - fy),
                (1.0 - fx) * fy,
                fx * fy,
            ];
            let indexes = [
                y0 * source.width + x0,
                y0 * source.width + x1,
                y1 * source.width + x0,
                y1 * source.width + x1,
            ];
            let alpha_unit = indexes
                .iter()
                .zip(weights)
                .map(|(index, weight)| f64::from(source.alpha[*index]) / 255.0 * weight)
                .sum::<f64>();
            let mut pixel = [0_u8; 3];
            for (channel, value) in pixel.iter_mut().enumerate() {
                let premultiplied = indexes
                    .iter()
                    .zip(weights)
                    .map(|(index, weight)| {
                        f64::from(source.pixels[*index][channel])
                            * (f64::from(source.alpha[*index]) / 255.0)
                            * weight
                    })
                    .sum::<f64>();
                *value = if alpha_unit <= f64::EPSILON {
                    0
                } else {
                    (premultiplied / alpha_unit).round().clamp(0.0, 255.0) as u8
                };
            }
            pixels.push(pixel);
            alpha.push((alpha_unit * 255.0).round().clamp(0.0, 255.0) as u8);
        }
    }
    Ok(RgbImage {
        width,
        height,
        pixels,
        alpha,
    })
}

pub(crate) fn find_ffmpeg() -> Option<PathBuf> {
    find_fixed_program("ffmpeg")
}

pub(crate) fn find_ffprobe() -> Option<PathBuf> {
    find_fixed_program("ffprobe")
}

fn find_fixed_program(name: &str) -> Option<PathBuf> {
    ["/usr/bin", "/bin"]
        .into_iter()
        .map(|directory| Path::new(directory).join(name))
        .find(|path| path.is_file())
}

fn extension(path: &Path) -> Result<String, Error> {
    path.extension()
        .and_then(|extension| extension.to_str())
        .map(str::to_ascii_lowercase)
        .ok_or_else(|| Error::syntax("image path requires a supported extension"))
}

fn validate_dimensions(width: usize, height: usize) -> Result<(), Error> {
    let pixels = width.checked_mul(height).ok_or(Error::IntegerOverflow)?;
    if width == 0 || height == 0 || pixels > MAX_ARTIST_PIXELS {
        return Err(Error::IllegalQuantity);
    }
    Ok(())
}

fn parse_ppm_usize(token: &[u8], name: &str) -> Result<usize, Error> {
    std::str::from_utf8(token)
        .ok()
        .and_then(|text| text.parse::<usize>().ok())
        .ok_or_else(|| Error::Io(format!("invalid PPM {name}")))
}

fn ppm_token<R: std::io::BufRead>(reader: &mut R) -> Result<Option<Vec<u8>>, Error> {
    let mut token = Vec::new();
    let mut comment = false;
    let mut consumed = 0_usize;
    loop {
        let available = reader.fill_buf()?;
        if available.is_empty() {
            return Ok((!token.is_empty()).then_some(token));
        }
        let byte = available[0];
        if !token.is_empty() && (byte.is_ascii_whitespace() || byte == b'#') {
            return Ok(Some(token));
        }
        reader.consume(1);
        consumed += 1;
        if consumed > MAX_PPM_HEADER_BYTES {
            return Err(Error::Io("PPM header is too large".into()));
        }
        if comment {
            if byte == b'\n' || byte == b'\r' {
                comment = false;
            }
        } else if byte == b'#' {
            comment = true;
        } else if !byte.is_ascii_whitespace() {
            token.push(byte);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ppm_round_trip_and_bilinear_letterbox_are_bounded() {
        let image = RgbImage {
            width: 2,
            height: 1,
            pixels: vec![[255, 0, 0], [0, 0, 255]],
            alpha: vec![255, 255],
        };
        let ppm = image.to_ppm().unwrap();
        assert_eq!(read_ppm(ppm.as_slice()).unwrap(), Some(image.clone()));
        let resized = resize_bilinear(&image, 3, 1).unwrap();
        assert_eq!(resized.pixels[1], [128, 0, 128]);
        let fitted = fit_letterboxed(&image, 4, 4).unwrap();
        assert_eq!(fitted.pixels[0], [0, 0, 0]);
        assert_eq!(fitted.pixels[4], [255, 0, 0]);
        assert!(resize_bilinear(&image, MAX_ARTIST_PIXELS, 2).is_err());

        let transparent_edge = RgbImage {
            width: 2,
            height: 1,
            pixels: vec![[255, 0, 0], [0, 255, 0]],
            alpha: vec![0, 255],
        };
        let resized_edge = resize_bilinear(&transparent_edge, 3, 1).unwrap();
        assert_eq!(resized_edge.pixels[1], [0, 255, 0]);
        assert_eq!(resized_edge.alpha[1], 128);
        let composited = transparent_edge.to_ppm().unwrap();
        assert_eq!(&composited[composited.len() - 6..], &[0, 0, 0, 0, 255, 0]);
    }
}
