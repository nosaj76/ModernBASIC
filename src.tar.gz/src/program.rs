use crate::error::Error;
use crate::file_io::DEFAULT_MAX_BINARY_PROGRAM_BYTES;
use crate::tokens::{decode_with_limit, detokenize, encode, tokenize, Token, TokenInstance};
use std::collections::BTreeMap;
use std::io::BufRead;

use crate::bounded_line::{read_bounded_line, BoundedLineError};

/// Default maximum byte length of one numbered program source line.
pub const DEFAULT_MAX_SOURCE_LINE_BYTES: usize = 1_048_576;

/// Highest line number representable by the native token and runtime model.
///
/// ModernBASIC stores line numbers as signed 64-bit token values, so the
/// program model accepts nonnegative values throughout that native range.
/// This preserves BASIC's ordered line-number behavior without carrying over
/// the storage ceiling imposed by classic 16-bit hardware.
pub const MAX_BASIC_LINE_NUMBER: u64 = i64::MAX as u64;

/// Signature and format revision used by tokenized Modern64BASIC programs.
pub const BINARY_PROGRAM_MAGIC: &[u8; 4] = b"M64B";
pub const BINARY_PROGRAM_VERSION: u8 = 1;
/// Maximum number of physical lines declared by one M64B image.
pub const MAX_BINARY_PROGRAM_LINES: usize = 100_000;
/// Maximum number of decoded token objects retained by one M64B image.
pub const MAX_BINARY_PROGRAM_TOKENS: usize = 1_000_000;

/// Ordered storage for numbered BASIC program lines.
///
/// This corresponds to the linked-list of lines maintained in `program.s`, but
/// it uses a `BTreeMap` keyed by line number and keeps each line as a vector
/// of token instances.  No raw 6502 memory layout is copied.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Program {
    lines: BTreeMap<u64, Vec<TokenInstance>>,
}

impl Program {
    /// Create an empty program.
    pub fn new() -> Self {
        Program {
            lines: BTreeMap::new(),
        }
    }

    /// Insert or replace a numbered line.  If the line body is empty, the line
    /// is deleted instead (matching the behaviour of typing only the line
    /// number at the 6502 prompt).
    pub fn insert_line(&mut self, text: &str) -> Result<(), Error> {
        let tokens = tokenize(text)?;
        let (number, body) = split_line_number(&tokens)?;
        if body.is_empty() {
            self.lines.remove(&number);
            return Ok(());
        }
        self.lines.insert(number, body.to_vec());
        Ok(())
    }

    /// Load numbered program lines from a bounded UTF-8 stream.
    pub fn read_from<R: BufRead + ?Sized>(
        &mut self,
        reader: &mut R,
        max_line_bytes: usize,
    ) -> Result<(), Error> {
        while let Some(line) =
            read_bounded_line(reader, max_line_bytes).map_err(|error| match error {
                BoundedLineError::Io(message) => Error::Io(message),
                BoundedLineError::Interrupted => Error::Io("I/O operation interrupted".into()),
                BoundedLineError::TooLong { limit } => Error::SourceLineTooLong { limit },
                BoundedLineError::InvalidUtf8 => Error::InvalidSourceEncoding,
            })?
        {
            if !line.trim().is_empty() {
                self.insert_line(&line)?;
            }
        }
        Ok(())
    }

    /// Delete a line by number, returning an error if it does not exist.
    pub fn delete(&mut self, number: u64) -> Result<(), Error> {
        if self.lines.remove(&number).is_none() {
            return Err(Error::LineNotFound(number));
        }
        Ok(())
    }

    /// Delete every stored line in the inclusive range and return the count.
    pub fn delete_range(&mut self, start: u64, end: u64) -> usize {
        if start > end {
            return 0;
        }
        let numbers = self
            .lines
            .range(start..=end)
            .map(|(&number, _)| number)
            .collect::<Vec<_>>();
        for number in &numbers {
            self.lines.remove(number);
        }
        numbers.len()
    }

    /// Renumber stored lines and literal control-flow destinations.
    pub fn renumber(
        &mut self,
        new_start: u64,
        old_start: u64,
        increment: u64,
    ) -> Result<usize, Error> {
        if increment == 0 {
            return Err(Error::IllegalQuantity);
        }
        let old_numbers = self
            .lines
            .range(old_start..)
            .map(|(&number, _)| number)
            .collect::<Vec<_>>();
        let mut mapping = BTreeMap::new();
        for (index, old) in old_numbers.iter().enumerate() {
            let index = u64::try_from(index).map_err(|_| Error::IllegalQuantity)?;
            let new = new_start
                .checked_add(increment.checked_mul(index).ok_or(Error::IllegalQuantity)?)
                .ok_or(Error::IllegalQuantity)?;
            if new > MAX_BASIC_LINE_NUMBER {
                return Err(Error::IllegalQuantity);
            }
            if new < old_start && self.lines.contains_key(&new) {
                return Err(Error::IllegalQuantity);
            }
            mapping.insert(*old, new);
        }

        let mut rebuilt = BTreeMap::new();
        for (old_number, mut body) in std::mem::take(&mut self.lines) {
            remap_line_references(&mut body, &mapping);
            let number = mapping.get(&old_number).copied().unwrap_or(old_number);
            if rebuilt.insert(number, body).is_some() {
                return Err(Error::IllegalQuantity);
            }
        }
        self.lines = rebuilt;
        Ok(mapping.len())
    }

    /// Return the stored line as tokens, if present.
    pub fn get(&self, number: u64) -> Option<&Vec<TokenInstance>> {
        self.lines.get(&number)
    }

    /// Produce a canonical listing: line number followed by detokenised body.
    pub fn list(&self) -> Vec<(u64, String)> {
        self.lines
            .iter()
            .map(|(&n, toks)| (n, detokenize(toks)))
            .collect()
    }

    /// Serialize an inclusive canonical line range for the native `LIST`
    /// command, rejecting the complete result before it exceeds `max_bytes`.
    pub fn to_listing_bytes(
        &self,
        start: u64,
        end: u64,
        max_bytes: usize,
    ) -> Result<Vec<u8>, Error> {
        let mut listing = Vec::new();
        if start > end {
            return Ok(listing);
        }
        for (&number, body) in self.lines.range(start..=end) {
            let line = format!("{number} {}\n", detokenize(body));
            let next = listing
                .len()
                .checked_add(line.len())
                .ok_or(Error::ListingLimitExceeded { limit: max_bytes })?;
            if next > max_bytes {
                return Err(Error::ListingLimitExceeded { limit: max_bytes });
            }
            listing.extend_from_slice(line.as_bytes());
        }
        Ok(listing)
    }

    /// Serialize canonical numbered source with a total byte limit.
    pub fn to_source_bytes(&self, max_bytes: usize) -> Result<Vec<u8>, Error> {
        let mut source = Vec::new();
        for (number, body) in self.list() {
            let line = format!("{number} {body}\n");
            let next = source
                .len()
                .checked_add(line.len())
                .ok_or(Error::FileLimitExceeded { limit: max_bytes })?;
            if next > max_bytes {
                return Err(Error::FileLimitExceeded { limit: max_bytes });
            }
            source.extend_from_slice(line.as_bytes());
        }
        Ok(source)
    }

    /// Serialize the program without detokenizing or reparsing its lines.
    ///
    /// The stable on-disk layout is `M64B`, one version byte, a little-endian
    /// `u32` line count, then `(u64 line, u32 byte count, encoded tokens)` for
    /// each line in ascending order.
    pub fn to_binary_bytes(&self, max_bytes: usize) -> Result<Vec<u8>, Error> {
        let line_count = u32::try_from(self.lines.len()).map_err(|_| Error::ProgramFull)?;
        let mut binary = Vec::new();
        binary.extend_from_slice(BINARY_PROGRAM_MAGIC);
        binary.push(BINARY_PROGRAM_VERSION);
        binary.extend_from_slice(&line_count.to_le_bytes());

        for (&number, body) in &self.lines {
            let encoded = encode(body);
            let encoded_len = u32::try_from(encoded.len())
                .map_err(|_| Error::FileLimitExceeded { limit: max_bytes })?;
            let next_len = binary
                .len()
                .checked_add(12)
                .and_then(|length| length.checked_add(encoded.len()))
                .ok_or(Error::FileLimitExceeded { limit: max_bytes })?;
            if next_len > max_bytes {
                return Err(Error::FileLimitExceeded { limit: max_bytes });
            }
            binary.extend_from_slice(&number.to_le_bytes());
            binary.extend_from_slice(&encoded_len.to_le_bytes());
            binary.extend_from_slice(&encoded);
        }
        if binary.len() > max_bytes {
            return Err(Error::FileLimitExceeded { limit: max_bytes });
        }
        Ok(binary)
    }

    /// Reconstruct a program directly from the tokenized binary format.
    pub fn from_binary_bytes(bytes: &[u8], max_bytes: usize) -> Result<Self, Error> {
        let max_bytes = max_bytes.min(DEFAULT_MAX_BINARY_PROGRAM_BYTES);
        if bytes.len() > max_bytes {
            return Err(Error::FileLimitExceeded { limit: max_bytes });
        }
        if bytes.len() < 9 || &bytes[..4] != BINARY_PROGRAM_MAGIC {
            return Err(Error::syntax("invalid M64B binary program header"));
        }
        if bytes[4] != BINARY_PROGRAM_VERSION {
            return Err(Error::syntax(format!(
                "unsupported M64B binary program version {}",
                bytes[4]
            )));
        }

        let line_count = u32::from_le_bytes(
            bytes[5..9]
                .try_into()
                .expect("the fixed-size header was validated"),
        );
        if line_count as usize > MAX_BINARY_PROGRAM_LINES {
            return Err(Error::ProgramLineLimitExceeded {
                limit: MAX_BINARY_PROGRAM_LINES,
            });
        }
        if u64::from(line_count) > MAX_BASIC_LINE_NUMBER + 1 {
            return Err(Error::ProgramFull);
        }

        let mut program = Self::new();
        let mut position = 9usize;
        let mut token_count = 0usize;
        for _ in 0..line_count {
            let header_end = position
                .checked_add(12)
                .ok_or_else(|| Error::syntax("binary program line header overflow"))?;
            let header = bytes
                .get(position..header_end)
                .ok_or_else(|| Error::syntax("truncated M64B line header"))?;
            let number = u64::from_le_bytes(
                header[..8]
                    .try_into()
                    .expect("the line header has a validated size"),
            );
            if number > MAX_BASIC_LINE_NUMBER {
                return Err(Error::IllegalQuantity);
            }
            let encoded_len = u32::from_le_bytes(
                header[8..12]
                    .try_into()
                    .expect("the line header has a validated size"),
            ) as usize;
            position = header_end;
            let encoded_end = position
                .checked_add(encoded_len)
                .ok_or_else(|| Error::syntax("binary program token length overflow"))?;
            let encoded = bytes
                .get(position..encoded_end)
                .ok_or_else(|| Error::syntax("truncated M64B token stream"))?;
            let remaining_tokens = MAX_BINARY_PROGRAM_TOKENS.saturating_sub(token_count);
            let body =
                decode_with_limit(encoded, remaining_tokens).map_err(|error| match error {
                    Error::ProgramTokenLimitExceeded { .. } => Error::ProgramTokenLimitExceeded {
                        limit: MAX_BINARY_PROGRAM_TOKENS,
                    },
                    other => other,
                })?;
            token_count =
                token_count
                    .checked_add(body.len())
                    .ok_or(Error::ProgramTokenLimitExceeded {
                        limit: MAX_BINARY_PROGRAM_TOKENS,
                    })?;
            if body.is_empty() {
                return Err(Error::syntax("M64B stored an empty numbered line"));
            }
            if program.lines.insert(number, body).is_some() {
                return Err(Error::syntax(format!(
                    "duplicate line number {number} in M64B program"
                )));
            }
            position = encoded_end;
        }
        if position != bytes.len() {
            return Err(Error::syntax("trailing bytes after M64B program"));
        }
        Ok(program)
    }

    /// Iterate over stored lines in ascending line-number order.
    pub fn iter(&self) -> impl Iterator<Item = (&u64, &Vec<TokenInstance>)> {
        self.lines.iter()
    }

    /// Merge every numbered line from `other`, replacing duplicate line
    /// numbers while preserving all non-conflicting lines.
    pub fn merge_from(&mut self, other: &Program) {
        for (&number, body) in other.iter() {
            self.lines.insert(number, body.clone());
        }
    }

    /// Remove every stored line.
    pub fn clear(&mut self) {
        self.lines.clear();
    }

    /// Number of stored lines.
    pub fn len(&self) -> usize {
        self.lines.len()
    }

    /// Whether the program store is empty.
    pub fn is_empty(&self) -> bool {
        self.lines.is_empty()
    }
}

#[derive(Clone, Copy)]
enum LineReferenceMode {
    None,
    One,
    Many,
}

fn remap_line_references(body: &mut [TokenInstance], mapping: &BTreeMap<u64, u64>) {
    let mut mode = LineReferenceMode::None;
    for index in 0..body.len() {
        let literal_end = match body.get(index + 1) {
            None | Some(TokenInstance::Colon) => true,
            Some(TokenInstance::Comma) => matches!(mode, LineReferenceMode::Many),
            Some(TokenInstance::Ident(name)) => name == "ELSE",
            _ => false,
        };
        // These zero operands control error handling rather than referring to
        // stored line zero. Ordinary GOTO/THEN/ELSE 0 still names that line.
        let prefix = &body[..index];
        let zero_sentinel = matches!(prefix.last(), Some(TokenInstance::Keyword(Token::Resume)))
            || prefix.ends_with(&[
                TokenInstance::Keyword(Token::On),
                TokenInstance::Keyword(Token::ErrorStmt),
                TokenInstance::Keyword(Token::Goto),
            ]);
        match &mut body[index] {
            TokenInstance::Colon => mode = LineReferenceMode::None,
            TokenInstance::Keyword(keyword) => {
                mode = match keyword {
                    Token::Goto | Token::Gosub => LineReferenceMode::Many,
                    Token::Then | Token::Restore | Token::Resume | Token::Run | Token::Return => {
                        LineReferenceMode::One
                    }
                    _ => LineReferenceMode::None,
                };
            }
            TokenInstance::Ident(name) if name == "ELSE" => {
                mode = LineReferenceMode::One;
            }
            TokenInstance::Number(number) if !matches!(mode, LineReferenceMode::None) => {
                if literal_end && !(*number == 0 && zero_sentinel) {
                    if let Ok(old) = u64::try_from(*number) {
                        if let Some(new) =
                            mapping.get(&old).and_then(|new| i64::try_from(*new).ok())
                        {
                            *number = new;
                        }
                    }
                }
                if !literal_end || matches!(mode, LineReferenceMode::One) {
                    mode = LineReferenceMode::None;
                }
            }
            TokenInstance::Comma if matches!(mode, LineReferenceMode::Many) => {}
            // A reference must be an adjacent, standalone numeric literal.
            // In particular, THEN A(100)=1 must not rewrite the subscript.
            _ => mode = LineReferenceMode::None,
        }
    }
}

/// Split the leading line number off a token stream.
fn split_line_number(tokens: &[TokenInstance]) -> Result<(u64, &[TokenInstance]), Error> {
    if let Some(TokenInstance::Number(n)) = tokens.first() {
        let n = u64::try_from(*n).map_err(|_| Error::IllegalQuantity)?;
        if n > MAX_BASIC_LINE_NUMBER {
            return Err(Error::IllegalQuantity);
        }
        Ok((n, &tokens[1..]))
    } else if matches!(
        tokens.first(),
        Some(TokenInstance::Keyword(crate::tokens::Token::Minus))
    ) && matches!(tokens.get(1), Some(TokenInstance::Number(_)))
    {
        Err(Error::IllegalQuantity)
    } else {
        Err(Error::syntax("missing line number"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn renumber_preserves_expressions_subscripts_and_zero_sentinels() {
        let mut program = Program::new();
        let lines = [
            "0 END",
            "10 IF X THEN A(100)=1 ELSE A(100)=2",
            "20 GOTO 100+X",
            "30 ON ERROR GOTO 0",
            "40 RESUME 0",
            "50 IF X THEN 100 ELSE 0",
            "100 END",
        ];
        for line in lines {
            program.insert_line(line).unwrap();
        }
        let before = program.list();
        program.renumber(1000, 0, 10).unwrap();
        let after = program.list();
        for index in [1, 2, 3, 4] {
            assert_eq!(after[index].1, before[index].1);
        }
        assert_eq!(after[5].1, "IF X THEN 1060 ELSE 1000");
    }

    #[test]
    fn renumber_updates_program_lines_and_control_flow_references() {
        let mut program = Program::new();
        for line in [
            "10 GOTO 100",
            "20 ON X GOSUB 100,200",
            "100 IF X THEN 200 ELSE 10",
            "200 RESTORE 100:END",
        ] {
            program.insert_line(line).unwrap();
        }
        program.renumber(1000, 10, 10).unwrap();
        assert_eq!(
            program.list(),
            vec![
                (1000, "GOTO 1020".into()),
                (1010, "ON X GOSUB 1020 , 1030".into()),
                (1020, "IF X THEN 1030 ELSE 1000".into()),
                (1030, "RESTORE 1020: END".into()),
            ]
        );
    }

    #[test]
    fn delete_range_removes_every_line_inclusively() {
        let mut program = Program::new();
        for line in ["10 PRINT 1", "20 PRINT 2", "30 PRINT 3", "40 END"] {
            program.insert_line(line).unwrap();
        }
        assert_eq!(program.delete_range(20, 30), 2);
        assert_eq!(
            program.list().iter().map(|(n, _)| *n).collect::<Vec<_>>(),
            vec![10, 40]
        );
    }

    #[test]
    fn line_replacement_and_deletion() {
        let mut p = Program::new();
        p.insert_line("10 PRINT A").unwrap();
        p.insert_line("20 PRINT B").unwrap();
        p.insert_line("10 PRINT C").unwrap(); // replace
        assert_eq!(p.len(), 2);

        let listing: Vec<String> = p
            .list()
            .into_iter()
            .map(|(n, s)| format!("{n} {s}"))
            .collect();
        assert_eq!(listing, vec!["10 PRINT C", "20 PRINT B"]);

        p.delete(10).unwrap();
        assert_eq!(p.len(), 1);
        assert!(p.delete(10).is_err());
    }

    #[test]
    fn merge_replaces_duplicate_lines_and_retains_others() {
        let mut base = Program::new();
        base.insert_line("10 PRINT 1").unwrap();
        base.insert_line("20 PRINT 2").unwrap();
        let mut other = Program::new();
        other.insert_line("20 PRINT 20").unwrap();
        other.insert_line("30 PRINT 3").unwrap();
        base.merge_from(&other);
        assert_eq!(
            base.list(),
            vec![
                (10, "PRINT 1".to_string()),
                (20, "PRINT 20".to_string()),
                (30, "PRINT 3".to_string()),
            ]
        );
    }

    #[test]
    fn iteration_is_ordered() {
        let mut p = Program::new();
        p.insert_line("30 PRINT C").unwrap();
        p.insert_line("10 PRINT A").unwrap();
        p.insert_line("20 PRINT B").unwrap();
        let collected: Vec<u64> = p.iter().map(|(&n, _)| n).collect();
        assert_eq!(collected, vec![10, 20, 30]);
    }

    #[test]
    fn negative_line_number_is_rejected() {
        let mut program = Program::new();
        assert_eq!(
            program.insert_line("-10 PRINT 1").unwrap_err(),
            Error::IllegalQuantity
        );
        assert!(program.is_empty());
    }

    #[test]
    fn native_line_number_range_is_not_limited_by_classic_storage() {
        let mut program = Program::new();
        program
            .insert_line("65529 PRINT 1")
            .expect("classic maximum line number is valid");
        program
            .insert_line("65530 PRINT 1")
            .expect("line numbers above the classic storage ceiling are valid");
        program
            .insert_line(&format!("{MAX_BASIC_LINE_NUMBER} PRINT 2"))
            .expect("maximum native line number is valid");
        assert!(program.insert_line("9223372036854775808 PRINT 1").is_err());

        let mut renumbered = Program::new();
        renumbered.insert_line("10 PRINT 1").unwrap();
        renumbered.insert_line("20 PRINT 2").unwrap();
        assert_eq!(
            renumbered.renumber(MAX_BASIC_LINE_NUMBER, 10, 1),
            Err(Error::IllegalQuantity)
        );
        assert!(renumbered.get(10).is_some());
        assert!(renumbered.get(20).is_some());
    }

    #[test]
    fn decimal_line_number_is_rejected() {
        let mut program = Program::new();
        assert_eq!(
            program.insert_line("10.5 PRINT 1").unwrap_err(),
            Error::syntax("missing line number")
        );
        assert!(program.is_empty());
    }

    #[test]
    fn bounded_reader_loads_program() {
        let mut input =
            std::io::BufReader::new(std::io::Cursor::new(b"20 PRINT B\r\n\n10 PRINT A\n"));
        let mut program = Program::new();
        program.read_from(&mut input, 64).unwrap();
        assert_eq!(program.len(), 2);
        assert_eq!(program.list()[0], (10, "PRINT A".to_string()));
    }

    #[test]
    fn canonical_source_serialization_is_bounded_and_reloadable() {
        let mut program = Program::new();
        program.insert_line("20 PRINT 2").unwrap();
        program.insert_line("10 PRINT 1").unwrap();
        let source = program.to_source_bytes(64).unwrap();
        assert_eq!(source, b"10 PRINT 1\n20 PRINT 2\n");
        assert_eq!(
            program.to_source_bytes(source.len() - 1).unwrap_err(),
            Error::FileLimitExceeded {
                limit: source.len() - 1
            }
        );

        let mut loaded = Program::new();
        loaded
            .read_from(&mut std::io::Cursor::new(source), 64)
            .unwrap();
        assert_eq!(loaded.list(), program.list());
    }

    #[test]
    fn binary_serialization_round_trips_encoded_tokens() {
        let mut program = Program::new();
        program.insert_line(r#"10 A$="A:B":PRINT A$;42.5"#).unwrap();
        program.insert_line("20 DATA 1,HELLO:REM payload").unwrap();
        program.insert_line("30 END").unwrap();

        let binary = program.to_binary_bytes(4096).unwrap();
        assert_eq!(&binary[..4], BINARY_PROGRAM_MAGIC);
        assert_eq!(binary[4], BINARY_PROGRAM_VERSION);
        assert_eq!(Program::from_binary_bytes(&binary, 4096).unwrap(), program);
        assert_eq!(
            program.to_binary_bytes(binary.len() - 1).unwrap_err(),
            Error::FileLimitExceeded {
                limit: binary.len() - 1
            }
        );
    }

    #[test]
    fn binary_deserialization_rejects_corrupt_and_trailing_data() {
        let mut program = Program::new();
        program.insert_line("10 PRINT 1").unwrap();
        let binary = program.to_binary_bytes(1024).unwrap();

        let mut wrong_magic = binary.clone();
        wrong_magic[0] = b'X';
        assert!(matches!(
            Program::from_binary_bytes(&wrong_magic, 1024),
            Err(Error::Syntax { .. })
        ));

        let mut trailing = binary;
        trailing.push(0);
        assert!(matches!(
            Program::from_binary_bytes(&trailing, 1024),
            Err(Error::Syntax { .. })
        ));
    }

    #[test]
    fn binary_deserialization_rejects_excessive_line_and_token_counts() {
        let mut excessive_lines = Vec::from(BINARY_PROGRAM_MAGIC.as_slice());
        excessive_lines.push(BINARY_PROGRAM_VERSION);
        excessive_lines.extend_from_slice(&((MAX_BINARY_PROGRAM_LINES + 1) as u32).to_le_bytes());
        assert_eq!(
            Program::from_binary_bytes(&excessive_lines, excessive_lines.len()).unwrap_err(),
            Error::ProgramLineLimitExceeded {
                limit: MAX_BINARY_PROGRAM_LINES
            }
        );

        let encoded_len = MAX_BINARY_PROGRAM_TOKENS + 1;
        let mut excessive_tokens = Vec::with_capacity(9 + 12 + encoded_len);
        excessive_tokens.extend_from_slice(BINARY_PROGRAM_MAGIC);
        excessive_tokens.push(BINARY_PROGRAM_VERSION);
        excessive_tokens.extend_from_slice(&1u32.to_le_bytes());
        excessive_tokens.extend_from_slice(&10u64.to_le_bytes());
        excessive_tokens.extend_from_slice(&(encoded_len as u32).to_le_bytes());
        excessive_tokens.resize(9 + 12 + encoded_len, b',');
        assert_eq!(
            Program::from_binary_bytes(&excessive_tokens, excessive_tokens.len()).unwrap_err(),
            Error::ProgramTokenLimitExceeded {
                limit: MAX_BINARY_PROGRAM_TOKENS
            }
        );
    }

    #[test]
    fn canonical_range_listing_is_inclusive_bounded_and_ordered() {
        let mut program = Program::new();
        program.insert_line("30 PRINT 3").unwrap();
        program.insert_line("10 PRINT 1").unwrap();
        program.insert_line("20 PRINT 2").unwrap();

        let listing = program.to_listing_bytes(15, 25, 64).unwrap();
        assert_eq!(listing, b"20 PRINT 2\n");
        assert!(program.to_listing_bytes(30, 20, 64).unwrap().is_empty());
        assert_eq!(
            program.to_listing_bytes(0, u64::MAX, 33).unwrap(),
            b"10 PRINT 1\n20 PRINT 2\n30 PRINT 3\n"
        );
        assert_eq!(
            program.to_listing_bytes(0, u64::MAX, 32).unwrap_err(),
            Error::ListingLimitExceeded { limit: 32 }
        );
    }

    #[test]
    fn bounded_reader_rejects_long_and_invalid_lines() {
        let mut long = std::io::BufReader::new(std::io::Cursor::new(b"10 PRINT 1\n"));
        let mut program = Program::new();
        assert_eq!(
            program.read_from(&mut long, 5).unwrap_err(),
            Error::SourceLineTooLong { limit: 5 }
        );

        let mut invalid = std::io::BufReader::new(std::io::Cursor::new([b'1', b'0', 0xff]));
        assert_eq!(
            program.read_from(&mut invalid, 10).unwrap_err(),
            Error::InvalidSourceEncoding
        );
    }
}
