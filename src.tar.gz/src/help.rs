//! Embedded, offline user-manual rendering and navigation.
//!
//! The maintained language reference is compiled into the executable.  The
//! graphical viewer therefore never reads a path supplied by a user and is
//! available in the boot appliance even when no writable filesystem exists.

use std::sync::OnceLock;

const USER_MANUAL_MARKDOWN: &str = include_str!("../docs/LANGUAGE_REFERENCE.md");
const MAX_SEARCH_CHARACTERS: usize = 128;

#[derive(Debug)]
enum ManualBlock {
    Blank,
    Heading(String),
    Paragraph(String),
    Bullet(String),
    Code(String),
}

/// Plain-text edition used by terminal sessions and black-box diagnostics.
pub(crate) fn manual_text() -> &'static str {
    static MANUAL: OnceLock<String> = OnceLock::new();
    MANUAL.get_or_init(|| render_manual(100).join("\n"))
}

#[derive(Debug, Default)]
pub(crate) struct HelpViewer {
    open: bool,
    top: usize,
    wrapped_width: usize,
    lines: Vec<String>,
    searching: bool,
    query: String,
    last_query: String,
    search_found: Option<bool>,
}

impl HelpViewer {
    pub(crate) fn is_open(&self) -> bool {
        self.open
    }

    pub(crate) fn show(&mut self, columns: usize) {
        self.open = true;
        self.top = 0;
        self.searching = false;
        self.query.clear();
        self.search_found = None;
        self.ensure_width(columns);
    }

    pub(crate) fn close(&mut self) {
        self.open = false;
        self.searching = false;
        self.query.clear();
    }

    pub(crate) fn ensure_width(&mut self, columns: usize) {
        let columns = columns.max(20);
        if self.wrapped_width == columns && !self.lines.is_empty() {
            return;
        }
        self.lines = render_manual(columns);
        self.wrapped_width = columns;
        self.top = self.top.min(self.lines.len().saturating_sub(1));
    }

    pub(crate) fn visible_lines(&self, rows: usize) -> &[String] {
        let end = self.top.saturating_add(rows).min(self.lines.len());
        &self.lines[self.top..end]
    }

    pub(crate) fn page_up(&mut self, rows: usize) {
        self.top = self.top.saturating_sub(rows.max(1));
    }

    pub(crate) fn page_down(&mut self, rows: usize) {
        self.top = self
            .top
            .saturating_add(rows.max(1))
            .min(self.last_page_top(rows));
    }

    pub(crate) fn line_up(&mut self) {
        self.top = self.top.saturating_sub(1);
    }

    pub(crate) fn line_down(&mut self, rows: usize) {
        self.top = self.top.saturating_add(1).min(self.last_page_top(rows));
    }

    pub(crate) fn first_page(&mut self) {
        self.top = 0;
    }

    pub(crate) fn last_page(&mut self, rows: usize) {
        self.top = self.last_page_top(rows);
    }

    pub(crate) fn begin_search(&mut self) {
        self.searching = true;
        self.query.clear();
        self.search_found = None;
    }

    pub(crate) fn cancel_search(&mut self) {
        self.searching = false;
        self.query.clear();
    }

    pub(crate) fn is_searching(&self) -> bool {
        self.searching
    }

    pub(crate) fn push_search_text(&mut self, text: &str) {
        for character in text.chars().filter(|character| !character.is_control()) {
            if self.query.chars().count() >= MAX_SEARCH_CHARACTERS {
                break;
            }
            self.query.push(character);
        }
    }

    pub(crate) fn backspace_search(&mut self) {
        self.query.pop();
    }

    pub(crate) fn finish_search(&mut self) -> bool {
        self.searching = false;
        if self.query.trim().is_empty() {
            self.query.clear();
            return false;
        }
        self.last_query = self.query.trim().to_string();
        self.query.clear();
        let found = self.find(&self.last_query.clone(), self.top);
        self.search_found = Some(found);
        found
    }

    pub(crate) fn find_next(&mut self) -> bool {
        if self.last_query.is_empty() || self.lines.is_empty() {
            return false;
        }
        let start = self.top.saturating_add(1) % self.lines.len();
        let found = self.find(&self.last_query.clone(), start);
        self.search_found = Some(found);
        found
    }

    pub(crate) fn title(&self, rows: usize) -> String {
        let rows = rows.max(1);
        let total_pages = self.lines.len().max(1).div_ceil(rows);
        let current_page = (self.top / rows).saturating_add(1).min(total_pages);
        format!("MODERNBASIC USER MANUAL  PAGE {current_page}/{total_pages}")
    }

    pub(crate) fn footer(&self) -> String {
        if self.searching {
            format!("FIND: {}_   ENTER SEARCH  ESC CANCEL", self.query)
        } else if self.search_found == Some(false) {
            format!("NO MATCH: {}   / NEW SEARCH  F1/ESC CLOSE", self.last_query)
        } else if self.search_found == Some(true) {
            format!(
                "FOUND: {}   F3 NEXT  / NEW SEARCH  F1/ESC CLOSE",
                self.last_query
            )
        } else {
            "UP/DOWN  PGUP/PGDN  HOME/END  / FIND  F3 NEXT  F1/ESC CLOSE".to_string()
        }
    }

    fn last_page_top(&self, rows: usize) -> usize {
        self.lines.len().saturating_sub(rows.max(1))
    }

    fn find(&mut self, query: &str, start: usize) -> bool {
        if query.is_empty() || self.lines.is_empty() {
            return false;
        }
        let query = query.to_ascii_lowercase();
        for offset in 0..self.lines.len() {
            let index = (start + offset) % self.lines.len();
            if self.lines[index].to_ascii_lowercase().contains(&query) {
                self.top = index;
                return true;
            }
        }
        false
    }
}

fn render_manual(columns: usize) -> Vec<String> {
    let columns = columns.max(20);
    let mut output = Vec::new();
    for block in parse_manual() {
        match block {
            ManualBlock::Blank => {
                if output.last().is_some_and(|line: &String| !line.is_empty()) {
                    output.push(String::new());
                }
            }
            ManualBlock::Heading(text) => {
                wrap_words(&text.to_ascii_uppercase(), "", "", columns, &mut output)
            }
            ManualBlock::Paragraph(text) => wrap_words(&text, "", "", columns, &mut output),
            ManualBlock::Bullet(text) => wrap_words(&text, "- ", "  ", columns, &mut output),
            ManualBlock::Code(text) => hard_wrap(&text, columns, &mut output),
        }
    }
    while output.last().is_some_and(String::is_empty) {
        output.pop();
    }
    output
}

fn parse_manual() -> Vec<ManualBlock> {
    let mut blocks = Vec::new();
    let mut paragraph = String::new();
    let mut bullet: Option<String> = None;
    let mut in_code = false;

    let flush =
        |blocks: &mut Vec<ManualBlock>, paragraph: &mut String, bullet: &mut Option<String>| {
            if let Some(text) = bullet.take() {
                blocks.push(ManualBlock::Bullet(text));
            }
            if !paragraph.is_empty() {
                blocks.push(ManualBlock::Paragraph(std::mem::take(paragraph)));
            }
        };

    for source_line in USER_MANUAL_MARKDOWN.lines() {
        let line = source_line.trim_end();
        if line.trim_start().starts_with("```") {
            flush(&mut blocks, &mut paragraph, &mut bullet);
            in_code = !in_code;
            continue;
        }
        if in_code {
            blocks.push(ManualBlock::Code(ascii_punctuation(line)));
            continue;
        }
        if line.trim().is_empty() {
            flush(&mut blocks, &mut paragraph, &mut bullet);
            if blocks
                .last()
                .is_some_and(|block| !matches!(block, ManualBlock::Blank))
            {
                blocks.push(ManualBlock::Blank);
            }
            continue;
        }
        if let Some(heading) = line.trim_start().strip_prefix('#') {
            flush(&mut blocks, &mut paragraph, &mut bullet);
            let heading = heading.trim_start_matches('#').trim();
            blocks.push(ManualBlock::Heading(clean_inline_markdown(heading)));
            continue;
        }
        if let Some(item) = line.trim_start().strip_prefix("- ") {
            flush(&mut blocks, &mut paragraph, &mut bullet);
            bullet = Some(clean_inline_markdown(item));
            continue;
        }
        if line.starts_with(char::is_whitespace) {
            if let Some(item) = bullet.as_mut() {
                append_words(item, &clean_inline_markdown(line.trim()));
                continue;
            }
        }
        if bullet.is_some() {
            flush(&mut blocks, &mut paragraph, &mut bullet);
        }
        append_words(&mut paragraph, &clean_inline_markdown(line.trim()));
    }
    flush(&mut blocks, &mut paragraph, &mut bullet);
    blocks
}

fn append_words(target: &mut String, text: &str) {
    if !target.is_empty() && !text.is_empty() {
        target.push(' ');
    }
    target.push_str(text);
}

fn clean_inline_markdown(text: &str) -> String {
    // Backticks and link destinations add noise in a fixed-font offline
    // viewer. Keep link labels and all language punctuation.
    let mut cleaned = String::with_capacity(text.len());
    let characters = text.chars().collect::<Vec<_>>();
    let mut index = 0usize;
    while index < characters.len() {
        match characters[index] {
            '`' => index += 1,
            '[' => {
                if let Some(close_label) = characters[index + 1..].iter().position(|c| *c == ']') {
                    let close_label = index + 1 + close_label;
                    if characters.get(close_label + 1) == Some(&'(') {
                        if let Some(close_target) =
                            characters[close_label + 2..].iter().position(|c| *c == ')')
                        {
                            cleaned.extend(characters[index + 1..close_label].iter());
                            index = close_label + 2 + close_target + 1;
                            continue;
                        }
                    }
                }
                cleaned.push('[');
                index += 1;
            }
            character => {
                cleaned.push(character);
                index += 1;
            }
        }
    }
    ascii_punctuation(&cleaned)
}

fn ascii_punctuation(text: &str) -> String {
    let mut output = String::with_capacity(text.len());
    for character in text.chars() {
        match character {
            '→' => output.push_str("->"),
            '—' | '–' => output.push('-'),
            '“' | '”' => output.push('"'),
            '’' => output.push('\''),
            character => output.push(character),
        }
    }
    output
}

fn wrap_words(
    text: &str,
    first_prefix: &str,
    continuation_prefix: &str,
    columns: usize,
    output: &mut Vec<String>,
) {
    let mut prefix = first_prefix;
    let mut line = prefix.to_string();
    let mut has_word = false;
    for word in text.split_whitespace() {
        let separator = usize::from(has_word);
        if line.chars().count() + separator + word.chars().count() <= columns {
            if has_word {
                line.push(' ');
            }
            line.push_str(word);
            has_word = true;
            continue;
        }
        if has_word {
            output.push(line);
            prefix = continuation_prefix;
            line = prefix.to_string();
        }
        let available = columns.saturating_sub(prefix.chars().count()).max(1);
        let characters = word.chars().collect::<Vec<_>>();
        let mut chunks = characters.chunks(available).peekable();
        while let Some(chunk) = chunks.next() {
            line.extend(chunk);
            if chunks.peek().is_some() {
                output.push(line);
                prefix = continuation_prefix;
                line = prefix.to_string();
            }
        }
        has_word = line.chars().count() > prefix.chars().count();
    }
    if has_word || (!first_prefix.is_empty() && text.is_empty()) {
        output.push(line);
    }
}

fn hard_wrap(text: &str, columns: usize, output: &mut Vec<String>) {
    if text.is_empty() {
        output.push(String::new());
        return;
    }
    let characters = text.chars().collect::<Vec<_>>();
    for chunk in characters.chunks(columns.max(1)) {
        output.push(chunk.iter().collect());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn embedded_manual_is_complete_plain_text_not_a_runtime_path() {
        let manual = manual_text();
        assert!(manual.contains("LANGUAGE REFERENCE"));
        assert!(manual.contains("STATEMENT INDEX"));
        assert!(manual.contains("SAFETY AND RESOURCE LIMITS"));
        assert!(!manual.contains("```"));
        assert!(manual.len() > 40_000);
        assert!(manual.lines().count() > 500);
    }

    #[test]
    fn viewer_wraps_unicode_safely_and_never_exceeds_its_width() {
        let lines = render_manual(37);
        assert!(lines.iter().all(|line| line.chars().count() <= 37));
        assert!(lines.iter().any(|line| line.contains("Unicode ->")));
    }

    #[test]
    fn viewer_navigation_and_wrapped_case_insensitive_search_are_bounded() {
        let mut viewer = HelpViewer::default();
        viewer.show(42);
        viewer.last_page(12);
        let last_top = viewer.top;
        viewer.page_down(12);
        assert_eq!(viewer.top, last_top);

        viewer.begin_search();
        viewer.push_search_text("resource limits");
        assert!(viewer.finish_search());
        assert!(viewer
            .visible_lines(4)
            .iter()
            .any(|line| { line.to_ascii_lowercase().contains("resource limits") }));
        viewer.line_up();
        viewer.first_page();
        viewer.line_up();
        assert_eq!(viewer.top, 0);
    }

    #[test]
    fn search_input_has_a_fixed_memory_bound() {
        let mut viewer = HelpViewer::default();
        viewer.show(80);
        viewer.begin_search();
        viewer.push_search_text(&"x".repeat(1_000));
        assert_eq!(viewer.query.chars().count(), MAX_SEARCH_CHARACTERS);
    }

    #[test]
    fn failed_search_is_reported_without_moving_beyond_the_manual() {
        let mut viewer = HelpViewer::default();
        viewer.show(80);
        viewer.begin_search();
        viewer.push_search_text("definitely-not-a-modernbasic-topic");
        assert!(!viewer.finish_search());
        assert!(viewer.footer().starts_with("NO MATCH:"));
        assert!(viewer.top < viewer.lines.len());
    }
}
