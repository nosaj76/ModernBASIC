//! Modern polyphonic synthesizer for ModernBASIC.
//!
//! The implementation keeps the useful C128/SID capabilities—independent
//! voices, waveforms, pulse width, ADSR envelopes, a resonant multimode filter,
//! tempo, note sequencing, and noise—while adding modern voice
//! counts, custom wave tables, SoundFont routing, and frequency sweeps. It does
//! not emulate a specific machine register map or inherit vintage limits.

use std::f64::consts::PI;
use std::io::Write;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};

use crate::error::Error;

/// Maximum BASIC voices retained by the fixed MIDI/channel interface.
pub const VOICE_COUNT: usize = 16;
/// Default oscillator layers in each native voice.
pub const DEFAULT_OSCILLATOR_COUNT: usize = 3;
/// Bounded maximum oscillator layers available to a native voice.
pub const MAX_OSCILLATOR_COUNT: usize = 8;
pub const DEFAULT_SAMPLE_RATE: u32 = 44_100;
pub const MAX_SYNTH_SECONDS: f64 = 1800.0;
pub const MAX_NOTE_BEATS: f64 = 64.0;
pub const MAX_REST_BEATS: f64 = 512.0;
pub const MAX_WAV_BYTES: usize = 512 * 1_048_576;
const AUDIO_RENDER_INTERRUPT_FRAMES: usize = 2_048;

pub(crate) fn check_audio_render_interrupt() -> Result<(), Error> {
    if crate::interpreter::take_interrupt() {
        Err(Error::Break)
    } else {
        Ok(())
    }
}

fn resize_track_with_silence(track: &mut Vec<f32>, final_frames: usize) -> Result<(), Error> {
    if track.len() >= final_frames {
        return Ok(());
    }
    track.reserve(final_frames - track.len());
    while track.len() < final_frames {
        check_audio_render_interrupt()?;
        track.resize(
            final_frames.min(track.len() + AUDIO_RENDER_INTERRUPT_FRAMES),
            0.0,
        );
    }
    Ok(())
}

pub(crate) fn is_audio_disabled() -> bool {
    std::env::var_os("MODERNBASIC_NO_AUDIO").is_some()
        || std::env::var_os("MODERN64BASIC_NO_AUDIO").is_some()
}

/// One interpreter task's live PCM process. Sessions deliberately do not
/// share process IDs, so stopping or replacing audio in one program window
/// cannot affect another window.
#[derive(Debug, Default)]
pub(crate) struct PlaybackSession {
    state: Arc<Mutex<PlaybackState>>,
}

#[derive(Debug, Default)]
struct PlaybackState {
    pid: u32,
    last_error: Option<String>,
}

/// A bounded native-synthesis arrangement selected by the host or a BASIC
/// program. Profiles describe software-rendering cost; the audio device only
/// receives the final stereo PCM stream.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SynthArrangement {
    pub voices: usize,
    pub oscillators: usize,
}

/// Named arrangements accepted by `SYNTHPROFILE` and the command line.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum SynthProfile {
    Auto,
    Compact,
    #[default]
    Standard,
    Extended,
    Maximum,
}

impl SynthProfile {
    pub fn parse(name: &str) -> Result<Self, Error> {
        match name.trim().to_ascii_uppercase().as_str() {
            "AUTO" => Ok(Self::Auto),
            "COMPACT" | "LIGHT" => Ok(Self::Compact),
            "STANDARD" | "DEFAULT" => Ok(Self::Standard),
            "EXTENDED" | "LARGE" => Ok(Self::Extended),
            "MAXIMUM" | "MAX" => Ok(Self::Maximum),
            _ => Err(Error::syntax(
                "synth profile must be AUTO, COMPACT, STANDARD, EXTENDED, or MAXIMUM",
            )),
        }
    }

    pub const fn name(self) -> &'static str {
        match self {
            Self::Auto => "AUTO",
            Self::Compact => "COMPACT",
            Self::Standard => "STANDARD",
            Self::Extended => "EXTENDED",
            Self::Maximum => "MAXIMUM",
        }
    }

    pub fn arrangement(self) -> SynthArrangement {
        match self {
            Self::Auto => scan_audio_hardware().recommended.arrangement(),
            Self::Compact => SynthArrangement {
                voices: 8,
                oscillators: 2,
            },
            Self::Standard => SynthArrangement {
                voices: VOICE_COUNT,
                oscillators: DEFAULT_OSCILLATOR_COUNT,
            },
            Self::Extended => SynthArrangement {
                voices: VOICE_COUNT,
                oscillators: 6,
            },
            Self::Maximum => SynthArrangement {
                voices: VOICE_COUNT,
                oscillators: MAX_OSCILLATOR_COUNT,
            },
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PlaybackBackend {
    Disabled,
    PulseAudio,
    Alsa,
    Unavailable,
}

impl PlaybackBackend {
    pub const fn name(self) -> &'static str {
        match self {
            Self::Disabled => "DISABLED",
            Self::PulseAudio => "PULSEAUDIO",
            Self::Alsa => "ALSA",
            Self::Unavailable => "NONE",
        }
    }
}

/// Host facts used by the opt-in automatic synthesis profile.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AudioHardwareProfile {
    pub logical_cpus: usize,
    pub memory_mib: Option<u64>,
    pub playback_backend: PlaybackBackend,
    pub recommended: SynthProfile,
}

/// Inspect software-rendering capacity and the available PCM playback command.
/// This is deliberately a conservative heuristic rather than a claim that the
/// sound card owns a fixed oscillator or voice count.
pub fn scan_audio_hardware() -> AudioHardwareProfile {
    let logical_cpus = std::thread::available_parallelism()
        .map(usize::from)
        .unwrap_or(1);
    let memory_mib = linux_memory_mib();
    let memory_is_below = |limit| memory_mib.is_some_and(|memory| memory < limit);
    let recommended = if logical_cpus <= 2 || memory_is_below(2_048) {
        SynthProfile::Compact
    } else if logical_cpus <= 4 || memory_is_below(4_096) {
        SynthProfile::Standard
    } else if logical_cpus <= 8 || memory_is_below(8_192) {
        SynthProfile::Extended
    } else {
        SynthProfile::Maximum
    };
    let playback_backend = if is_audio_disabled() {
        PlaybackBackend::Disabled
    } else if executable_on_path("paplay") {
        PlaybackBackend::PulseAudio
    } else if executable_on_path("aplay") {
        PlaybackBackend::Alsa
    } else {
        PlaybackBackend::Unavailable
    };
    AudioHardwareProfile {
        logical_cpus,
        memory_mib,
        playback_backend,
        recommended,
    }
}

fn linux_memory_mib() -> Option<u64> {
    let contents = std::fs::read_to_string("/proc/meminfo").ok()?;
    let kib = contents
        .lines()
        .find_map(|line| line.strip_prefix("MemTotal:"))?
        .split_whitespace()
        .next()?
        .parse::<u64>()
        .ok()?;
    Some(kib / 1_024)
}

fn executable_on_path(name: &str) -> bool {
    std::env::var_os("PATH")
        .map(|path| {
            std::env::split_paths(&path)
                .map(|directory| directory.join(name))
                .any(|candidate: PathBuf| candidate.is_file())
        })
        .unwrap_or(false)
}

impl PlaybackSession {
    /// Stop this task's background audio, including after BASIC has returned to READY.
    pub(crate) fn stop(&self) -> bool {
        let pid = {
            let mut state = self
                .state
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner());
            std::mem::take(&mut state.pid)
        };
        if pid == 0 {
            return false;
        }
        terminate_playback_process(pid);
        true
    }

    pub(crate) fn is_active(&self) -> bool {
        self.state
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .pid
            != 0
    }

    pub(crate) fn wait(&self) -> Result<(), Error> {
        while self.is_active() {
            if crate::interpreter::take_interrupt() {
                self.stop();
                return Err(Error::Break);
            }
            std::thread::sleep(std::time::Duration::from_millis(10));
        }
        self.take_error().map_or(Ok(()), Err)
    }

    /// Consume the most recent background playback error, if any.
    pub(crate) fn take_error(&self) -> Option<Error> {
        let mut error = self
            .state
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        error.last_error.take().map(Error::Io)
    }

    /// Start an available raw-PCM sink and let a background producer feed it.
    /// PulseAudio/PipeWire's `paplay` is preferred, with ALSA `aplay` as a fallback.
    pub(crate) fn playback_raw_async<F>(&self, sample_rate: u32, producer: F) -> Result<(), Error>
    where
        F: FnOnce(&mut dyn Write) -> Result<(), Error> + Send + 'static,
    {
        if is_audio_disabled() {
            return Ok(());
        }
        self.stop();
        if let Some(error) = self.take_error() {
            return Err(error);
        }
        let paplay = Command::new("paplay")
            .arg("--raw")
            .arg("--format")
            .arg("s16le")
            .arg("--rate")
            .arg(sample_rate.to_string())
            .arg("--channels")
            .arg("2")
            .stdin(Stdio::piped())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn();
        let mut child = match paplay {
            Ok(child) => child,
            Err(paplay_error) => Command::new("aplay")
                .arg("-q")
                .arg("-t")
                .arg("raw")
                .arg("-f")
                .arg("S16_LE")
                .arg("-r")
                .arg(sample_rate.to_string())
                .arg("-c")
                .arg("2")
                .stdin(Stdio::piped())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .spawn()
                .map_err(|aplay_error| {
                    Error::Io(format!(
                    "cannot start audio playback (paplay: {paplay_error}; aplay: {aplay_error})"
                ))
                })?,
        };
        let pid = child.id();
        let mut input = child
            .stdin
            .take()
            .ok_or_else(|| Error::Io("cannot open audio playback input".to_string()))?;
        self.state
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .pid = pid;
        let session_state = Arc::clone(&self.state);
        if let Err(error) = std::thread::Builder::new()
            .name("modernbasic-audio".to_string())
            .spawn(move || {
                let producer_error = producer(&mut input).err().map(|error| error.to_string());
                drop(input);
                let process_error = match child.wait() {
                    Ok(status) if status.success() => None,
                    Ok(status) => Some(format!("audio playback process exited with {status}")),
                    Err(error) => Some(format!("cannot wait for audio playback process: {error}")),
                };
                let mut state = session_state
                    .lock()
                    .unwrap_or_else(|poisoned| poisoned.into_inner());
                if state.pid == pid {
                    if let Some(error) = producer_error.or(process_error) {
                        eprintln!("ModernBASIC audio playback error: {error}");
                        state.last_error = Some(error);
                    }
                    state.pid = 0;
                }
            })
        {
            let mut state = self
                .state
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner());
            if state.pid == pid {
                state.pid = 0;
            }
            drop(state);
            terminate_playback_process(pid);
            return Err(Error::Io(format!(
                "cannot start audio playback thread: {error}"
            )));
        }
        Ok(())
    }

    /// Play one internally generated 44.1 kHz, stereo, 16-bit PCM WAV.
    pub(crate) fn playback_wav_async(&self, wav: Vec<u8>) -> Result<(), Error> {
        validate_stereo_pcm_wav(&wav)?;
        let pcm = wav[44..].to_vec();
        self.playback_raw_async(DEFAULT_SAMPLE_RATE, move |output| {
            output
                .write_all(&pcm)
                .map_err(|error| Error::Io(format!("cannot stream synthesized audio: {error}")))
        })
    }
}

impl Drop for PlaybackSession {
    fn drop(&mut self) {
        self.stop();
    }
}

fn terminate_playback_process(pid: u32) {
    let _ = Command::new("kill")
        .arg("-TERM")
        .arg(pid.to_string())
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status();
}

/// Mix two internally generated PCM WAVs onto one timeline. Shorter input is
/// padded with silence and only a clipping-prevention gain is applied.
pub(crate) fn mix_stereo_pcm_wavs(first: &[u8], second: &[u8]) -> Result<Vec<u8>, Error> {
    check_audio_render_interrupt()?;
    validate_stereo_pcm_wav(first)?;
    validate_stereo_pcm_wav(second)?;
    let first_pcm = &first[44..];
    let second_pcm = &second[44..];
    let samples = first_pcm.len().max(second_pcm.len()) / 2;
    let data_bytes = samples.checked_mul(2).ok_or(Error::IntegerOverflow)?;
    let total_bytes = data_bytes.checked_add(44).ok_or(Error::IntegerOverflow)?;
    if total_bytes > MAX_WAV_BYTES {
        return Err(Error::FileLimitExceeded {
            limit: MAX_WAV_BYTES,
        });
    }

    let sample_at = |pcm: &[u8], index: usize| -> i16 {
        pcm.get(index * 2..index * 2 + 2)
            .map(|bytes| i16::from_le_bytes([bytes[0], bytes[1]]))
            .unwrap_or(0)
    };
    let mut mixed = Vec::with_capacity(samples);
    for index in 0..samples {
        if index % AUDIO_RENDER_INTERRUPT_FRAMES == 0 {
            check_audio_render_interrupt()?;
        }
        mixed
            .push(i32::from(sample_at(first_pcm, index)) + i32::from(sample_at(second_pcm, index)));
    }
    let mut peak = 0_u32;
    for chunk in mixed.chunks(AUDIO_RENDER_INTERRUPT_FRAMES) {
        check_audio_render_interrupt()?;
        peak = chunk
            .iter()
            .map(|sample| sample.unsigned_abs())
            .max()
            .unwrap_or(0)
            .max(peak);
    }
    let peak = peak as f64;
    let scale = if peak > i16::MAX as f64 {
        i16::MAX as f64 / peak
    } else {
        1.0
    };

    let mut wav = pcm_wav_header(data_bytes)?;
    wav.reserve(data_bytes);
    for chunk in mixed.chunks(AUDIO_RENDER_INTERRUPT_FRAMES) {
        check_audio_render_interrupt()?;
        for sample in chunk {
            let sample = (*sample as f64 * scale)
                .round()
                .clamp(i16::MIN as f64, i16::MAX as f64) as i16;
            wav.extend_from_slice(&sample.to_le_bytes());
        }
    }
    Ok(wav)
}

fn validate_stereo_pcm_wav(wav: &[u8]) -> Result<(), Error> {
    if wav.len() < 44
        || &wav[..4] != b"RIFF"
        || &wav[8..12] != b"WAVE"
        || &wav[12..16] != b"fmt "
        || u16::from_le_bytes([wav[20], wav[21]]) != 1
        || u16::from_le_bytes([wav[22], wav[23]]) != 2
        || u32::from_le_bytes([wav[24], wav[25], wav[26], wav[27]]) != DEFAULT_SAMPLE_RATE
        || u16::from_le_bytes([wav[34], wav[35]]) != 16
        || &wav[36..40] != b"data"
        || (wav.len() - 44) % 4 != 0
    {
        return Err(Error::Io(
            "synthesizer produced an incompatible PCM WAV".to_string(),
        ));
    }
    Ok(())
}

pub(crate) fn pcm_wav_header(data_bytes: usize) -> Result<Vec<u8>, Error> {
    let data_bytes = u32::try_from(data_bytes).map_err(|_| Error::IntegerOverflow)?;
    let mut wav = Vec::with_capacity(44);
    wav.extend_from_slice(b"RIFF");
    wav.extend_from_slice(&36_u32.saturating_add(data_bytes).to_le_bytes());
    wav.extend_from_slice(b"WAVEfmt ");
    wav.extend_from_slice(&16_u32.to_le_bytes());
    wav.extend_from_slice(&1_u16.to_le_bytes());
    wav.extend_from_slice(&2_u16.to_le_bytes());
    wav.extend_from_slice(&DEFAULT_SAMPLE_RATE.to_le_bytes());
    wav.extend_from_slice(&(DEFAULT_SAMPLE_RATE * 4).to_le_bytes());
    wav.extend_from_slice(&4_u16.to_le_bytes());
    wav.extend_from_slice(&16_u16.to_le_bytes());
    wav.extend_from_slice(b"data");
    wav.extend_from_slice(&data_bytes.to_le_bytes());
    Ok(wav)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Waveform {
    Sine,
    Triangle,
    Saw,
    Pulse,
    Noise,
    Custom,
    /// Additive-synthesis banjo: fundamental-dominant plucked timbre
    /// with H2 at 0.6, H3 at 0.4, fast decay. Measured from real
    /// 5-string banjo FFT analysis. Pair with fast-attack ADSR.
    Banjo,
    /// Additive-synthesis guitar: warmer plucked-string timbre with a
    /// strong fundamental and progressively weaker upper harmonics. Pair
    /// with a moderate attack and longer sustain than the banjo.
    Guitar,
    /// Additive-synthesis bass: deep fundamental-dominant timbre with
    /// reduced upper harmonics. Pair with a slow attack and long sustain
    /// for sustained bass lines.
    Bass,
    /// Santur (hammered dulcimer): struck strings with a bright, metallic,
    /// bell-like tone. Fast attack, long ringing decay, inharmonic partials.
    /// Modeled as a waveguide string through a metallic modal body.
    Santur,
    /// Tar (Persian plucked lute): warm, slightly nasal plucked string with
    /// a membranous body resonance. Waveguide with moderate damping.
    Tar,
    /// Setar (delicate Persian lute): thin, delicate plucked string, softer
    /// and lighter than the tar. Waveguide with light damping.
    Setar,
    /// Ney (Persian end-blown flute): breathy sustained tone with air noise.
    /// Not a plucked string — a sustained oscillator with breath excitation.
    Ney,
}

impl Waveform {
    pub fn parse(name: &str) -> Result<Self, Error> {
        match name.trim().to_ascii_uppercase().as_str() {
            "SINE" => Ok(Self::Sine),
            "TRIANGLE" => Ok(Self::Triangle),
            "SAW" => Ok(Self::Saw),
            "PULSE" => Ok(Self::Pulse),
            "NOISE" => Ok(Self::Noise),
            "CUSTOM" => Ok(Self::Custom),
            "BANJO" => Ok(Self::Banjo),
            "GUITAR" => Ok(Self::Guitar),
            "BASS" => Ok(Self::Bass),
            "SANTUR" => Ok(Self::Santur),
            "TAR" => Ok(Self::Tar),
            "SETAR" => Ok(Self::Setar),
            "NEY" => Ok(Self::Ney),
            _ => Err(Error::syntax(
                "waveform must be SINE, TRIANGLE, SAW, PULSE, NOISE, CUSTOM, BANJO, GUITAR, BASS, SANTUR, TAR, SETAR, or NEY",
            )),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FilterMode {
    Off,
    LowPass,
    HighPass,
    BandPass,
    Notch,
}

impl FilterMode {
    pub fn parse(name: &str) -> Result<Self, Error> {
        match name.trim().to_ascii_uppercase().as_str() {
            "OFF" => Ok(Self::Off),
            "LOWPASS" => Ok(Self::LowPass),
            "HIGHPASS" => Ok(Self::HighPass),
            "BANDPASS" => Ok(Self::BandPass),
            "NOTCH" => Ok(Self::Notch),
            _ => Err(Error::syntax(
                "filter must be OFF, LOWPASS, HIGHPASS, BANDPASS, or NOTCH",
            )),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LfoTarget {
    Pitch,
    Level,
    Filter,
    PulseWidth,
}

impl LfoTarget {
    pub fn parse(name: &str) -> Result<Self, Error> {
        match name.trim().to_ascii_uppercase().as_str() {
            "PITCH" => Ok(Self::Pitch),
            "LEVEL" => Ok(Self::Level),
            "FILTER" => Ok(Self::Filter),
            "PULSEWIDTH" => Ok(Self::PulseWidth),
            _ => Err(Error::syntax(
                "LFO target must be PITCH, LEVEL, FILTER, or PULSEWIDTH",
            )),
        }
    }

    fn index(self) -> usize {
        match self {
            Self::Pitch => 0,
            Self::Level => 1,
            Self::Filter => 2,
            Self::PulseWidth => 3,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LfoWaveform {
    Sine,
    Triangle,
    Saw,
    Pulse,
    SampleHold,
}

impl LfoWaveform {
    pub fn parse(name: &str) -> Result<Self, Error> {
        match name.trim().to_ascii_uppercase().as_str() {
            "SINE" => Ok(Self::Sine),
            "TRIANGLE" => Ok(Self::Triangle),
            "SAW" => Ok(Self::Saw),
            "PULSE" => Ok(Self::Pulse),
            "SAMPLEHOLD" | "RANDOM" => Ok(Self::SampleHold),
            _ => Err(Error::syntax(
                "LFO waveform must be SINE, TRIANGLE, SAW, PULSE, or SAMPLEHOLD",
            )),
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct Oscillator {
    waveform: Waveform,
    ratio: f64,
    detune_cents: f64,
    level: f64,
    pulse_width: f64,
}

impl Oscillator {
    const fn primary() -> Self {
        Self {
            waveform: Waveform::Pulse,
            ratio: 1.0,
            detune_cents: 0.0,
            level: 1.0,
            pulse_width: 0.5,
        }
    }

    const fn silent() -> Self {
        Self {
            waveform: Waveform::Sine,
            ratio: 1.0,
            detune_cents: 0.0,
            level: 0.0,
            pulse_width: 0.5,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct FilterEnvelope {
    attack_ms: f64,
    decay_ms: f64,
    sustain: f64,
    release_ms: f64,
    amount_octaves: f64,
}

impl Default for FilterEnvelope {
    fn default() -> Self {
        Self {
            attack_ms: 0.0,
            decay_ms: 0.0,
            sustain: 1.0,
            release_ms: 0.0,
            amount_octaves: 0.0,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct Lfo {
    waveform: LfoWaveform,
    rate_hz: f64,
    depth: f64,
}

impl Default for Lfo {
    fn default() -> Self {
        Self {
            waveform: LfoWaveform::Sine,
            rate_hz: 0.0,
            depth: 0.0,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SoundFontEnvelope {
    pub attack_ms: f32,
    pub decay_ms: f32,
    pub sustain: f32,
    pub release_ms: f32,
}

/// Per-voice post-sampler processing selected by BASIC `DSP`.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SoundFontDsp {
    pub drive: f32,
    pub tone: f32,
    pub presence: f32,
    pub compression: f32,
    pub gate: f32,
}

#[derive(Debug, Clone, Copy)]
struct Voice {
    oscillators: [Oscillator; MAX_OSCILLATOR_COUNT],
    attack_ms: f64,
    decay_ms: f64,
    sustain: f64,
    release_ms: f64,
    volume: f64,
    sampled_volume: f64,
    pan: f64,
    native_layer: f64,
    sampled_layer: f64,
    layer_play: bool,
    sampled_envelope: Option<SoundFontEnvelope>,
    sampled_dsp: Option<SoundFontDsp>,
    filter: Filter,
    filter_key_track: f64,
    filter_envelope: FilterEnvelope,
    lfos: [Lfo; 4],
    glide_ms: f64,
    drive: f64,
}

impl Default for Voice {
    fn default() -> Self {
        let mut oscillators = [Oscillator::silent(); MAX_OSCILLATOR_COUNT];
        oscillators[0] = Oscillator::primary();
        Self {
            oscillators,
            attack_ms: 8.0,
            decay_ms: 80.0,
            sustain: 0.72,
            release_ms: 120.0,
            volume: 0.33,
            sampled_volume: 1.0,
            pan: 0.0,
            native_layer: 1.0,
            sampled_layer: 1.0,
            layer_play: false,
            sampled_envelope: None,
            sampled_dsp: None,
            filter: Filter::default(),
            filter_key_track: 0.0,
            filter_envelope: FilterEnvelope::default(),
            lfos: [Lfo::default(); 4],
            glide_ms: 0.0,
            drive: 0.0,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct Filter {
    mode: FilterMode,
    cutoff_hz: f64,
    resonance: f64,
}

impl Default for Filter {
    fn default() -> Self {
        Self {
            mode: FilterMode::Off,
            cutoff_hz: 4_000.0,
            resonance: 0.0,
        }
    }
}

#[derive(Debug, Clone)]
pub struct SidSynth {
    sample_rate: u32,
    tempo_bpm: f64,
    selected_voice: usize,
    active_voice_count: usize,
    active_oscillator_count: usize,
    master_volume: f64,
    enabled: bool,
    voices: [Voice; VOICE_COUNT],
    wave_tables: [Option<Vec<f32>>; VOICE_COUNT],
    tracks: [Vec<f32>; VOICE_COUNT],
    last_frequencies: [Option<f64>; VOICE_COUNT],
    noise_state: u32,
}

impl Default for SidSynth {
    fn default() -> Self {
        Self {
            sample_rate: DEFAULT_SAMPLE_RATE,
            tempo_bpm: 120.0,
            selected_voice: 0,
            active_voice_count: VOICE_COUNT,
            active_oscillator_count: DEFAULT_OSCILLATOR_COUNT,
            master_volume: 1.0,
            enabled: true,
            voices: [Voice::default(); VOICE_COUNT],
            wave_tables: std::array::from_fn(|_| None),
            tracks: std::array::from_fn(|_| Vec::new()),
            last_frequencies: [None; VOICE_COUNT],
            noise_state: 0x6d2b_79f5,
        }
    }
}

impl SidSynth {
    pub fn with_arrangement(arrangement: SynthArrangement) -> Result<Self, Error> {
        let mut synth = Self::default();
        synth.configure_arrangement(arrangement)?;
        Ok(synth)
    }

    pub fn configure_arrangement(&mut self, arrangement: SynthArrangement) -> Result<(), Error> {
        if !(1..=VOICE_COUNT).contains(&arrangement.voices)
            || !(1..=MAX_OSCILLATOR_COUNT).contains(&arrangement.oscillators)
        {
            return Err(Error::IllegalQuantity);
        }
        self.active_voice_count = arrangement.voices;
        self.active_oscillator_count = arrangement.oscillators;
        self.selected_voice = self.selected_voice.min(self.active_voice_count - 1);
        Ok(())
    }

    pub fn set_tempo(&mut self, bpm: f64) -> Result<(), Error> {
        if !bpm.is_finite() || !(1.0..=1_000.0).contains(&bpm) {
            return Err(Error::IllegalQuantity);
        }
        self.tempo_bpm = bpm;
        Ok(())
    }

    pub fn select_voice(&mut self, voice: i64) -> Result<(), Error> {
        self.selected_voice = self.active_voice_index(voice)?;
        Ok(())
    }

    pub fn set_voice_count(&mut self, count: i64) -> Result<(), Error> {
        if !(1..=VOICE_COUNT as i64).contains(&count) {
            return Err(Error::IllegalQuantity);
        }
        self.active_voice_count = count as usize;
        self.selected_voice = self.selected_voice.min(self.active_voice_count - 1);
        Ok(())
    }

    pub fn voice_count(&self) -> usize {
        self.active_voice_count
    }

    pub fn set_oscillator_count(&mut self, count: i64) -> Result<(), Error> {
        if !(1..=MAX_OSCILLATOR_COUNT as i64).contains(&count) {
            return Err(Error::IllegalQuantity);
        }
        self.active_oscillator_count = count as usize;
        Ok(())
    }

    pub fn oscillator_count(&self) -> usize {
        self.active_oscillator_count
    }

    pub(crate) fn voice_is_active(&self, voice: i64) -> bool {
        (1..=self.active_voice_count as i64).contains(&voice)
    }

    fn active_voice_index(&self, voice: i64) -> Result<usize, Error> {
        let index = voice_index(voice)?;
        if index >= self.active_voice_count {
            return Err(Error::IllegalQuantity);
        }
        Ok(index)
    }

    pub fn set_master_volume(&mut self, volume: f64) -> Result<(), Error> {
        if !volume.is_finite() || !(0.0..=1.0).contains(&volume) {
            return Err(Error::IllegalQuantity);
        }
        self.master_volume = volume;
        Ok(())
    }

    pub fn master_volume(&self) -> f32 {
        if self.enabled {
            self.master_volume as f32
        } else {
            0.0
        }
    }

    pub fn set_enabled(&mut self, enabled: bool) {
        self.enabled = enabled;
    }

    pub fn is_enabled(&self) -> bool {
        self.enabled
    }

    pub fn selected_voice(&self) -> usize {
        self.selected_voice
    }

    pub fn tempo_bpm(&self) -> f64 {
        self.tempo_bpm
    }

    /// Current channel level and pan for a SoundFont MIDI playback device.
    /// SoundFont voices run at full channel level because `VOL` is the one
    /// canonical BASIC level control; the native oscillator's conservative
    /// per-voice default must not attenuate sampled instruments a second time.
    pub(crate) fn soundfont_voice_mix(&self) -> [(f32, f32); VOICE_COUNT] {
        std::array::from_fn(|index| {
            if index < self.active_voice_count {
                (
                    (self.voices[index].sampled_volume * self.voices[index].sampled_layer) as f32,
                    self.voices[index].pan as f32,
                )
            } else {
                (0.0, 0.0)
            }
        })
    }

    pub fn set_voice_mix(
        &mut self,
        voice: i64,
        native_level: f64,
        sampled_level: f64,
    ) -> Result<(), Error> {
        if [native_level, sampled_level]
            .iter()
            .any(|level| !level.is_finite() || !(0.0..=1.0).contains(level))
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].native_layer = native_level;
        self.voices[index].sampled_layer = sampled_level;
        self.voices[index].layer_play = true;
        Ok(())
    }

    pub(crate) fn native_play_routes(&self) -> [bool; VOICE_COUNT] {
        std::array::from_fn(|index| {
            index < self.active_voice_count
                && self.voices[index].layer_play
                && self.voices[index].native_layer > 0.0
        })
    }

    /// Select the sampled PLAY destination independently for every BASIC
    /// voice. Voices without an explicit MIXER statement retain the existing
    /// SoundFont route whenever a SoundFont device is active.
    pub(crate) fn sampled_play_routes(&self) -> [bool; VOICE_COUNT] {
        std::array::from_fn(|index| {
            index < self.active_voice_count
                && (!self.voices[index].layer_play || self.voices[index].sampled_layer > 0.0)
        })
    }

    pub(crate) fn explicit_sampled_play_routes(&self) -> [bool; VOICE_COUNT] {
        std::array::from_fn(|index| {
            index < self.active_voice_count
                && self.voices[index].layer_play
                && self.voices[index].sampled_layer > 0.0
        })
    }

    pub(crate) fn play_sequence_uses_route(
        &self,
        voice: i64,
        sequence: &str,
        default_beats: f64,
        routes: [bool; VOICE_COUNT],
    ) -> Result<bool, Error> {
        let mut current_voice = voice;
        self.active_voice_index(current_voice)?;
        if sequence.split_whitespace().next().is_none() {
            return Err(Error::syntax("PLAY requires at least one note or rest"));
        }
        for token in sequence.split_whitespace() {
            if let Some(next_voice) = token
                .strip_prefix('V')
                .or_else(|| token.strip_prefix('v'))
                .and_then(|value| value.parse::<i64>().ok())
            {
                if self.voice_is_active(next_voice) {
                    current_voice = next_voice;
                    continue;
                }
            }
            let note = parse_note(token, default_beats)?;
            let index = self.active_voice_index(current_voice)?;
            if note.frequency.is_some() && routes[index] {
                return Ok(true);
            }
        }
        Ok(false)
    }

    pub fn has_score(&self) -> bool {
        self.tracks[..self.active_voice_count]
            .iter()
            .any(|track| !track.is_empty())
    }

    /// Explicit BASIC ADSR settings for sampled voices. `None` preserves the
    /// SoundFont preset's natural amplitude envelope.
    pub(crate) fn soundfont_voice_envelopes(&self) -> [Option<SoundFontEnvelope>; VOICE_COUNT] {
        std::array::from_fn(|index| {
            (index < self.active_voice_count)
                .then_some(self.voices[index].sampled_envelope)
                .flatten()
        })
    }

    /// Explicit BASIC DSP settings for sampled voices. `None` preserves the
    /// SoundFont renderer's unprocessed output and full written-note gate.
    pub(crate) fn soundfont_voice_dsp(&self) -> [Option<SoundFontDsp>; VOICE_COUNT] {
        std::array::from_fn(|index| {
            (index < self.active_voice_count)
                .then_some(self.voices[index].sampled_dsp)
                .flatten()
        })
    }

    /// Append stereo 16-bit SoundFont output to one native voice track.
    pub fn append_soundfont_pcm(&mut self, voice: i64, pcm: &[i16]) -> Result<(), Error> {
        if pcm.len() % 2 != 0 {
            return Err(Error::syntax("SoundFont PCM must contain stereo frames"));
        }
        let index = self.active_voice_index(voice)?;
        let frame_count = pcm.len() / 2;
        let final_frames = self.tracks[index]
            .len()
            .checked_add(frame_count)
            .ok_or(Error::IntegerOverflow)?;
        if final_frames as f64 / self.sample_rate as f64 > MAX_SYNTH_SECONDS {
            return Err(Error::syntax("synthesized track exceeds 30 minutes"));
        }
        let volume = self.voices[index].volume as f32;
        self.tracks[index].reserve(frame_count);
        for frame in pcm.chunks_exact(2) {
            let mono = (frame[0] as f32 + frame[1] as f32) / (2.0 * i16::MAX as f32);
            self.tracks[index].push(mono * volume);
        }
        Ok(())
    }

    /// Mix a rendered SoundFont note or chord at an absolute time instead of
    /// appending it. Symbolic scores can therefore retain arbitrary polyphony
    /// on one instrument track without manufacturing rests or stealing notes.
    pub fn mix_soundfont_pcm_at(
        &mut self,
        voice: i64,
        start_seconds: f64,
        pcm: &[i16],
    ) -> Result<(), Error> {
        if !start_seconds.is_finite() || !(0.0..=MAX_SYNTH_SECONDS).contains(&start_seconds) {
            return Err(Error::IllegalQuantity);
        }
        if pcm.is_empty() || pcm.len() % 2 != 0 {
            return Err(Error::syntax(
                "SoundFont score PCM must contain complete stereo frames",
            ));
        }
        let index = self.active_voice_index(voice)?;
        let start_frame = (start_seconds * self.sample_rate as f64).round() as usize;
        let frame_count = pcm.len() / 2;
        let final_frames = start_frame
            .checked_add(frame_count)
            .ok_or(Error::IntegerOverflow)?;
        if final_frames as f64 / self.sample_rate as f64 > MAX_SYNTH_SECONDS {
            return Err(Error::syntax("synthesized track exceeds 30 minutes"));
        }
        if self.tracks[index].len() < final_frames {
            resize_track_with_silence(&mut self.tracks[index], final_frames)?;
        }
        let volume = self.voices[index].volume as f32;
        for (offset, frame) in pcm.chunks_exact(2).enumerate() {
            if offset % AUDIO_RENDER_INTERRUPT_FRAMES == 0 {
                check_audio_render_interrupt()?;
            }
            let mono = (frame[0] as f32 + frame[1] as f32) / (2.0 * i16::MAX as f32);
            self.tracks[index][start_frame + offset] += mono * volume;
        }
        Ok(())
    }

    /// Reject a SoundFont event before its temporary stereo PCM is allocated
    /// when it would push the selected track beyond the 30-minute ceiling.
    pub fn validate_append_seconds(&self, voice: i64, seconds: f64) -> Result<(), Error> {
        if !seconds.is_finite() || seconds <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        let frame_count = (seconds * self.sample_rate as f64).round() as usize;
        let final_frames = self.tracks[index]
            .len()
            .checked_add(frame_count)
            .ok_or(Error::IntegerOverflow)?;
        if final_frames as f64 / self.sample_rate as f64 > MAX_SYNTH_SECONDS {
            return Err(Error::syntax("synthesized track exceeds 30 minutes"));
        }
        Ok(())
    }

    pub fn append_silence(&mut self, voice: i64, beats: f64) -> Result<(), Error> {
        let index = self.active_voice_index(voice)?;
        self.append_note(index, None, beats)
    }

    pub fn set_waveform(&mut self, voice: i64, waveform: Waveform) -> Result<(), Error> {
        let index = self.active_voice_index(voice)?;
        if waveform == Waveform::Custom && self.wave_tables[index].is_none() {
            return Err(Error::syntax(
                "CUSTOM waveform requires WAVE sample data for that voice",
            ));
        }
        self.voices[index].oscillators[0].waveform = waveform;
        Ok(())
    }

    pub fn set_oscillator(
        &mut self,
        voice: i64,
        oscillator: i64,
        waveform: Waveform,
        ratio: f64,
        detune_cents: f64,
        level: f64,
    ) -> Result<(), Error> {
        if !(1..=self.active_oscillator_count as i64).contains(&oscillator)
            || !ratio.is_finite()
            || !(0.0625..=16.0).contains(&ratio)
            || !detune_cents.is_finite()
            || !(-2_400.0..=2_400.0).contains(&detune_cents)
            || !level.is_finite()
            || !(0.0..=1.0).contains(&level)
        {
            return Err(Error::IllegalQuantity);
        }
        let voice_index = self.active_voice_index(voice)?;
        let oscillator_index = oscillator as usize - 1;
        if waveform == Waveform::Custom && self.wave_tables[voice_index].is_none() {
            return Err(Error::syntax(
                "CUSTOM oscillator requires WAVE sample data for that voice",
            ));
        }
        if oscillator_index > 0
            && matches!(
                waveform,
                Waveform::Banjo
                    | Waveform::Guitar
                    | Waveform::Bass
                    | Waveform::Santur
                    | Waveform::Tar
                    | Waveform::Setar
            )
        {
            return Err(Error::syntax(
                "BANJO, GUITAR, BASS, SANTUR, TAR, and SETAR physical models require oscillator 1",
            ));
        }
        let pulse_width = self.voices[voice_index].oscillators[oscillator_index].pulse_width;
        self.voices[voice_index].oscillators[oscillator_index] = Oscillator {
            waveform,
            ratio,
            detune_cents,
            level,
            pulse_width,
        };
        Ok(())
    }

    pub fn set_wave_table(&mut self, voice: i64, samples: &[f64]) -> Result<(), Error> {
        if samples.len() < 2
            || samples.len() > 65_536
            || samples
                .iter()
                .any(|sample| !sample.is_finite() || !(-1.0..=1.0).contains(sample))
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.wave_tables[index] = Some(samples.iter().map(|sample| *sample as f32).collect());
        self.voices[index].oscillators[0].waveform = Waveform::Custom;
        Ok(())
    }

    pub fn set_envelope(
        &mut self,
        voice: i64,
        attack_ms: f64,
        decay_ms: f64,
        sustain: f64,
        release_ms: f64,
    ) -> Result<(), Error> {
        if ![attack_ms, decay_ms, sustain, release_ms]
            .iter()
            .all(|value| value.is_finite())
            || attack_ms < 0.0
            || decay_ms < 0.0
            || release_ms < 0.0
            || !(0.0..=1.0).contains(&sustain)
            || attack_ms > 60_000.0
            || decay_ms > 60_000.0
            || release_ms > 60_000.0
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].attack_ms = attack_ms;
        self.voices[index].decay_ms = decay_ms;
        self.voices[index].sustain = sustain;
        self.voices[index].release_ms = release_ms;
        self.voices[index].sampled_envelope = Some(SoundFontEnvelope {
            attack_ms: attack_ms as f32,
            decay_ms: decay_ms as f32,
            sustain: sustain as f32,
            release_ms: release_ms as f32,
        });
        Ok(())
    }

    pub fn set_sampled_dsp(
        &mut self,
        voice: i64,
        drive: f64,
        tone: f64,
        presence: f64,
        compression: f64,
        gate: f64,
    ) -> Result<(), Error> {
        let values = [drive, tone, presence, compression, gate];
        if values
            .iter()
            .any(|value| !value.is_finite() || !(0.0..=1.0).contains(value))
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].sampled_dsp = Some(SoundFontDsp {
            drive: drive as f32,
            tone: tone as f32,
            presence: presence as f32,
            compression: compression as f32,
            gate: gate as f32,
        });
        Ok(())
    }

    pub fn set_pulse_width(&mut self, voice: i64, width: f64) -> Result<(), Error> {
        self.set_oscillator_pulse_width(voice, 1, width)
    }

    pub fn set_oscillator_pulse_width(
        &mut self,
        voice: i64,
        oscillator: i64,
        width: f64,
    ) -> Result<(), Error> {
        if !width.is_finite() || !(0.01..=0.99).contains(&width) {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        if !(1..=self.active_oscillator_count as i64).contains(&oscillator) {
            return Err(Error::IllegalQuantity);
        }
        self.voices[index].oscillators[oscillator as usize - 1].pulse_width = width;
        Ok(())
    }

    pub fn set_volume(&mut self, voice: i64, volume: f64) -> Result<(), Error> {
        if !volume.is_finite() || !(0.0..=1.0).contains(&volume) {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].volume = volume;
        self.voices[index].sampled_volume = volume;
        Ok(())
    }

    pub fn set_pan(&mut self, voice: i64, pan: f64) -> Result<(), Error> {
        if !pan.is_finite() || !(-1.0..=1.0).contains(&pan) {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].pan = pan;
        Ok(())
    }

    pub fn set_filter(
        &mut self,
        voice: i64,
        mode: FilterMode,
        cutoff_hz: f64,
        resonance: f64,
        key_track: f64,
    ) -> Result<(), Error> {
        let nyquist = self.sample_rate as f64 / 2.0;
        if !cutoff_hz.is_finite()
            || !resonance.is_finite()
            || !key_track.is_finite()
            || !(20.0..nyquist).contains(&cutoff_hz)
            || !(0.0..=1.0).contains(&resonance)
            || !(0.0..=1.0).contains(&key_track)
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].filter = Filter {
            mode,
            cutoff_hz,
            resonance,
        };
        self.voices[index].filter_key_track = key_track;
        Ok(())
    }

    pub fn set_filter_envelope(
        &mut self,
        voice: i64,
        attack_ms: f64,
        decay_ms: f64,
        sustain: f64,
        release_ms: f64,
        amount_octaves: f64,
    ) -> Result<(), Error> {
        if [attack_ms, decay_ms, sustain, release_ms, amount_octaves]
            .iter()
            .any(|value| !value.is_finite())
            || attack_ms < 0.0
            || decay_ms < 0.0
            || release_ms < 0.0
            || attack_ms > 60_000.0
            || decay_ms > 60_000.0
            || release_ms > 60_000.0
            || !(0.0..=1.0).contains(&sustain)
            || !(-8.0..=8.0).contains(&amount_octaves)
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].filter_envelope = FilterEnvelope {
            attack_ms,
            decay_ms,
            sustain,
            release_ms,
            amount_octaves,
        };
        Ok(())
    }

    pub fn set_lfo(
        &mut self,
        voice: i64,
        target: LfoTarget,
        waveform: LfoWaveform,
        rate_hz: f64,
        depth: f64,
    ) -> Result<(), Error> {
        let maximum_depth = match target {
            LfoTarget::Pitch => 24.0,
            LfoTarget::Level => 1.0,
            LfoTarget::Filter => 8.0,
            LfoTarget::PulseWidth => 0.49,
        };
        if !rate_hz.is_finite()
            || !(0.0..=100.0).contains(&rate_hz)
            || !depth.is_finite()
            || !(0.0..=maximum_depth).contains(&depth)
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].lfos[target.index()] = Lfo {
            waveform,
            rate_hz,
            depth,
        };
        Ok(())
    }

    pub fn set_glide(&mut self, voice: i64, milliseconds: f64) -> Result<(), Error> {
        if !milliseconds.is_finite() || !(0.0..=60_000.0).contains(&milliseconds) {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].glide_ms = milliseconds;
        Ok(())
    }

    pub fn set_drive(&mut self, voice: i64, amount: f64) -> Result<(), Error> {
        if !amount.is_finite() || !(0.0..=1.0).contains(&amount) {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        self.voices[index].drive = amount;
        Ok(())
    }

    pub fn clear(&mut self) {
        for track in &mut self.tracks {
            track.clear();
        }
        self.last_frequencies = [None; VOICE_COUNT];
    }

    /// Advance every active native voice to the longest current voice. This is
    /// the documented `M` control inside a PLAY string, not another statement.
    #[allow(dead_code)]
    pub(crate) fn synchronize_voices(&mut self) {
        let end = self.tracks[..self.active_voice_count]
            .iter()
            .map(Vec::len)
            .max()
            .unwrap_or(0);
        self.tracks[..self.active_voice_count]
            .iter_mut()
            .for_each(|track| track.resize(end, 0.0));
    }

    pub fn play_sequence(
        &mut self,
        voice: i64,
        sequence: &str,
        default_beats: f64,
    ) -> Result<(), Error> {
        if !default_beats.is_finite() || default_beats <= 0.0 || default_beats > MAX_REST_BEATS {
            return Err(Error::IllegalQuantity);
        }
        let mut current_voice = voice;
        let tokens = sequence.split_whitespace().collect::<Vec<_>>();
        if tokens.is_empty() {
            return Err(Error::syntax("PLAY requires at least one note or rest"));
        }
        for token in tokens {
            // Vn selects the active voice for subsequent notes.
            if let Some(v) = token.strip_prefix('V').or_else(|| token.strip_prefix('v')) {
                if let Ok(n) = v.parse::<i64>() {
                    if self.voice_is_active(n) {
                        current_voice = n;
                        continue;
                    }
                }
            }
            let index = self.active_voice_index(current_voice)?;
            let note = parse_note(token, default_beats)?;
            self.append_note(index, note.frequency, note.beats)?;
        }
        Ok(())
    }

    /// Queue PLAY notation only on native voices explicitly enabled by
    /// MIXER, while retaining each voice's complete musical cursor.
    pub fn play_sequence_routed(
        &mut self,
        voice: i64,
        sequence: &str,
        default_beats: f64,
        routes: [bool; VOICE_COUNT],
    ) -> Result<(), Error> {
        if !default_beats.is_finite() || default_beats <= 0.0 || default_beats > MAX_REST_BEATS {
            return Err(Error::IllegalQuantity);
        }
        let mut current_voice = voice;
        let tokens = sequence.split_whitespace().collect::<Vec<_>>();
        if tokens.is_empty() {
            return Err(Error::syntax("PLAY requires at least one note or rest"));
        }
        for token in tokens {
            if let Some(v) = token.strip_prefix('V').or_else(|| token.strip_prefix('v')) {
                if let Ok(n) = v.parse::<i64>() {
                    if self.voice_is_active(n) {
                        current_voice = n;
                        continue;
                    }
                }
            }
            let index = self.active_voice_index(current_voice)?;
            let note = parse_note(token, default_beats)?;
            self.append_note(
                index,
                routes[index].then_some(note.frequency).flatten(),
                note.beats,
            )?;
        }
        Ok(())
    }

    pub fn play_tone(
        &mut self,
        voice: i64,
        frequency_hz: f64,
        milliseconds: f64,
        volume: Option<f64>,
        waveform: Option<Waveform>,
    ) -> Result<(), Error> {
        if !frequency_hz.is_finite()
            || !milliseconds.is_finite()
            || !(0.0..=24_000.0).contains(&frequency_hz)
            || milliseconds <= 0.0
            || milliseconds > MAX_SYNTH_SECONDS * 1_000.0
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        let old = self.voices[index];
        if let Some(volume) = volume {
            self.set_volume(voice, volume)?;
        }
        if let Some(waveform) = waveform {
            self.set_waveform(voice, waveform)?;
        }
        let beats = milliseconds / 1_000.0 * self.tempo_bpm / 60.0;
        self.append_note(index, (frequency_hz > 0.0).then_some(frequency_hz), beats)?;
        self.voices[index] = old;
        Ok(())
    }

    /// Queue a smooth logarithmic frequency sweep. `steps` optionally turns
    /// the continuous glide into a bounded staircase of pitch changes.
    #[allow(clippy::too_many_arguments)]
    pub fn play_sweep(
        &mut self,
        voice: i64,
        start_hz: f64,
        end_hz: f64,
        milliseconds: f64,
        volume: Option<f64>,
        waveform: Option<Waveform>,
        steps: Option<usize>,
    ) -> Result<(), Error> {
        if !start_hz.is_finite()
            || !end_hz.is_finite()
            || !milliseconds.is_finite()
            || !(1.0..=24_000.0).contains(&start_hz)
            || !(1.0..=24_000.0).contains(&end_hz)
            || milliseconds <= 0.0
            || milliseconds > MAX_SYNTH_SECONDS * 1_000.0
            || steps.is_some_and(|count| count == 0 || count > 65_536)
        {
            return Err(Error::IllegalQuantity);
        }
        let index = self.active_voice_index(voice)?;
        let old = self.voices[index];
        if let Some(volume) = volume {
            self.set_volume(voice, volume)?;
        }
        if let Some(waveform) = waveform {
            self.set_waveform(voice, waveform)?;
        }
        let beats = milliseconds / 1_000.0 * self.tempo_bpm / 60.0;
        self.append_oscillator(index, start_hz, end_hz, beats, steps, None)?;
        self.voices[index] = old;
        Ok(())
    }

    pub(crate) fn playback_async(&mut self, session: &PlaybackSession) -> Result<(), Error> {
        if !self.enabled || self.tracks.iter().all(Vec::is_empty) || is_audio_disabled() {
            return Ok(());
        }
        let wav = self.render_wav()?;
        let pcm = wav
            .get(44..)
            .ok_or_else(|| Error::Io("synthesizer produced an invalid WAV header".to_string()))?
            .to_vec();
        session.playback_raw_async(self.sample_rate, move |output| {
            output
                .write_all(&pcm)
                .map_err(|error| Error::Io(format!("cannot stream synthesized audio: {error}")))
        })
    }

    pub fn render_wav(&self) -> Result<Vec<u8>, Error> {
        check_audio_render_interrupt()?;
        let frames = self.tracks[..self.active_voice_count]
            .iter()
            .map(Vec::len)
            .max()
            .unwrap_or(0);
        if frames == 0 {
            return Err(Error::syntax("no synthesized music has been created"));
        }
        let data_bytes = frames.checked_mul(4).ok_or(Error::IntegerOverflow)?;
        let total_bytes = data_bytes.checked_add(44).ok_or(Error::IntegerOverflow)?;
        if total_bytes > MAX_WAV_BYTES {
            return Err(Error::FileLimitExceeded {
                limit: MAX_WAV_BYTES,
            });
        }

        let mut left = vec![0.0_f32; frames];
        let mut right = vec![0.0_f32; frames];
        for (index, track) in self.tracks[..self.active_voice_count].iter().enumerate() {
            let pan = self.voices[index].pan as f32;
            let layer = self.voices[index].native_layer as f32;
            let left_gain = if pan > 0.0 { 1.0 - pan } else { 1.0 };
            let right_gain = if pan < 0.0 { 1.0 + pan } else { 1.0 };
            for (sample_index, ((left_target, right_target), sample)) in left
                .iter_mut()
                .zip(right.iter_mut())
                .zip(track.iter().copied())
                .enumerate()
            {
                if sample_index % AUDIO_RENDER_INTERRUPT_FRAMES == 0 {
                    check_audio_render_interrupt()?;
                }
                *left_target += sample * left_gain * layer;
                *right_target += sample * right_gain * layer;
            }
        }
        apply_master_output(&mut left, self.sample_rate, self.master_volume())?;
        apply_master_output(&mut right, self.sample_rate, self.master_volume())?;

        let mut wav = pcm_wav_header(data_bytes)?;
        wav.reserve(data_bytes);
        for (frame, (left_sample, right_sample)) in left.into_iter().zip(right).enumerate() {
            if frame % AUDIO_RENDER_INTERRUPT_FRAMES == 0 {
                check_audio_render_interrupt()?;
            }
            for sample in [left_sample, right_sample] {
                let sample = sample.clamp(-1.0, 1.0);
                let pcm = (sample * i16::MAX as f32).round() as i16;
                wav.extend_from_slice(&pcm.to_le_bytes());
            }
        }
        Ok(wav)
    }

    fn append_note(
        &mut self,
        voice_index: usize,
        frequency: Option<f64>,
        beats: f64,
    ) -> Result<(), Error> {
        let seconds = beats * 60.0 / self.tempo_bpm;
        if !seconds.is_finite() || seconds <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        let frame_count = (seconds * self.sample_rate as f64).round() as usize;
        let final_frames = self.tracks[voice_index]
            .len()
            .checked_add(frame_count)
            .ok_or(Error::IntegerOverflow)?;
        if final_frames as f64 / self.sample_rate as f64 > MAX_SYNTH_SECONDS {
            return Err(Error::syntax("synthesized track exceeds 30 minutes"));
        }
        if frequency.is_none() {
            resize_track_with_silence(&mut self.tracks[voice_index], final_frames)?;
            return Ok(());
        }

        let frequency = frequency.unwrap_or(0.0);
        let glide_frames =
            milliseconds_to_frames(self.voices[voice_index].glide_ms, self.sample_rate);
        let previous = self.last_frequencies[voice_index].unwrap_or(frequency);
        let (start_hz, transition_frames) = if glide_frames > 0 && previous != frequency {
            (previous, Some(glide_frames))
        } else {
            (frequency, None)
        };
        self.append_oscillator(
            voice_index,
            start_hz,
            frequency,
            beats,
            None,
            transition_frames,
        )
    }

    fn append_oscillator(
        &mut self,
        voice_index: usize,
        start_hz: f64,
        end_hz: f64,
        beats: f64,
        steps: Option<usize>,
        transition_frames: Option<usize>,
    ) -> Result<(), Error> {
        if !(1.0..=24_000.0).contains(&start_hz) || !(1.0..=24_000.0).contains(&end_hz) {
            return Err(Error::IllegalQuantity);
        }
        let seconds = beats * 60.0 / self.tempo_bpm;
        if !seconds.is_finite() || seconds <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        let frame_count = (seconds * self.sample_rate as f64).round() as usize;
        let final_frames = self.tracks[voice_index]
            .len()
            .checked_add(frame_count)
            .ok_or(Error::IntegerOverflow)?;
        if final_frames as f64 / self.sample_rate as f64 > MAX_SYNTH_SECONDS {
            return Err(Error::syntax("synthesized track exceeds 30 minutes"));
        }
        let voice = self.voices[voice_index];
        let primary_waveform = voice.oscillators[0].waveform;
        let custom_wave = self.wave_tables[voice_index].clone();
        let attack = milliseconds_to_frames(voice.attack_ms, self.sample_rate);
        let decay = milliseconds_to_frames(voice.decay_ms, self.sample_rate);
        let release = milliseconds_to_frames(voice.release_ms, self.sample_rate).min(frame_count);
        let release_start = frame_count.saturating_sub(release);
        let mut noise = self.noise_state
            ^ (voice_index as u32).wrapping_mul(0x9e37_79b9)
            ^ (self.tracks[voice_index].len() as u32).wrapping_mul(0x85eb_ca6b);
        noise ^= noise << 13;
        noise ^= noise >> 17;
        noise ^= noise << 5;
        let initial_phase = noise as f64 / u32::MAX as f64;
        let mut phases: [f64; MAX_OSCILLATOR_COUNT] = std::array::from_fn(|index| {
            (initial_phase + index as f64 * 0.381_966_011_250_105_1) % 1.0
        });
        let filter_attack =
            milliseconds_to_frames(voice.filter_envelope.attack_ms, self.sample_rate);
        let filter_decay = milliseconds_to_frames(voice.filter_envelope.decay_ms, self.sample_rate);
        let filter_release =
            milliseconds_to_frames(voice.filter_envelope.release_ms, self.sample_rate)
                .min(frame_count);
        let filter_release_start = frame_count.saturating_sub(filter_release);
        let mut filter_state = SvfState::default();
        let track_start_frame = self.tracks[voice_index].len();

        // For plucked-string instrument waveforms,
        // use Karplus-Strong waveguide synthesis.  Banjo uses a dedicated
        // 5-string string set so notes ring on the correct virtual string.
        let mut waveguide_string: Option<crate::instrument_synth::WaveguideString> = None;
        let mut banjo_string_set: Option<crate::instrument_synth::banjo_strings::BanjoStringSet> =
            None;
        if matches!(
            primary_waveform,
            Waveform::Banjo
                | Waveform::Guitar
                | Waveform::Bass
                | Waveform::Santur
                | Waveform::Tar
                | Waveform::Setar
        ) {
            let params = match primary_waveform {
                Waveform::Banjo => {
                    banjo_string_set =
                        Some(crate::instrument_synth::banjo_strings::BanjoStringSet::new(
                            crate::instrument_synth::WaveguideParams {
                                damping: 0.17,
                                brightness: 0.99,
                                pluck_position: 0.10,
                                harmonic_weights: [1.0, 0.7, 0.52, 0.35, 0.22, 0.12, 0.06, 0.03],
                            },
                            self.sample_rate as f64,
                        ));
                    None
                }
                Waveform::Guitar => Some(crate::instrument_synth::WaveguideParams {
                    damping: 0.06,
                    brightness: 0.8,
                    pluck_position: 0.18,
                    harmonic_weights: [1.0, 0.7, 0.5, 0.4, 0.3, 0.2, 0.1, 0.05],
                }),
                Waveform::Bass => Some(crate::instrument_synth::WaveguideParams {
                    damping: 0.03,
                    brightness: 0.65,
                    pluck_position: 0.20,
                    harmonic_weights: [1.0; 8],
                }),
                // Santur: struck with hard mallets near the bridge. Bright,
                // metallic, long ringing decay. Strong upper harmonics.
                Waveform::Santur => Some(crate::instrument_synth::WaveguideParams {
                    damping: 0.05,
                    brightness: 0.95,
                    pluck_position: 0.08,
                    harmonic_weights: [1.0, 0.8, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1],
                }),
                // Tar: warm, slightly nasal plucked lute with a membranous
                // body. Moderate damping, strong fundamental.
                Waveform::Tar => Some(crate::instrument_synth::WaveguideParams {
                    damping: 0.10,
                    brightness: 0.85,
                    pluck_position: 0.15,
                    harmonic_weights: [1.0, 0.6, 0.4, 0.3, 0.2, 0.12, 0.08, 0.04],
                }),
                // Setar: thin, delicate plucked lute. Light damping, softer
                // upper harmonics than the tar.
                Waveform::Setar => Some(crate::instrument_synth::WaveguideParams {
                    damping: 0.08,
                    brightness: 0.9,
                    pluck_position: 0.12,
                    harmonic_weights: [1.0, 0.5, 0.3, 0.2, 0.12, 0.08, 0.05, 0.02],
                }),
                _ => unreachable!(),
            };
            if let Some(params) = params {
                let mut string = crate::instrument_synth::WaveguideString::new();
                string.trigger(start_hz, &params, self.sample_rate as f64);
                waveguide_string = Some(string);
            } else if let Some(ref mut set) = banjo_string_set {
                // Route banjo notes to the correct virtual string and excite
                // only acoustically related sympathetic open strings.
                set.pluck(start_hz);
            }
        }

        // Pick transient: a very short burst of noise simulating the finger
        // scraping the string at the attack. Used for guitar; banjo's
        // harmonic waveguide excitation already provides its attack texture.
        let mut pick_noise_remaining: u32 = 0;
        let mut pick_noise_amp: f64 = 0.0;

        if primary_waveform == Waveform::Guitar {
            pick_noise_remaining = (0.005 * self.sample_rate as f64) as u32;
            pick_noise_amp = 0.15;
        }

        // Santur metallic body resonator — adds the bright, bell-like ring
        // characteristic of the hammered dulcimer.  Only used for santur.
        let mut santur_body: Option<crate::instrument_synth::santur_body::SanturBody> = None;
        if primary_waveform == Waveform::Santur {
            santur_body = Some(crate::instrument_synth::santur_body::SanturBody::new(
                self.sample_rate as f64,
            ));
        }

        self.tracks[voice_index].reserve(frame_count);
        for frame in 0..frame_count {
            if frame % AUDIO_RENDER_INTERRUPT_FRAMES == 0 {
                check_audio_render_interrupt()?;
            }
            let mut progress = if let Some(glide_frames) = transition_frames {
                frame as f64 / glide_frames.max(1) as f64
            } else if frame_count > 1 {
                frame as f64 / (frame_count - 1) as f64
            } else {
                1.0
            }
            .clamp(0.0, 1.0);
            if let Some(step_count) = steps {
                progress = (progress * step_count as f64).floor() / step_count as f64;
            }
            let frequency = start_hz * (end_hz / start_hz).powf(progress);
            let time_seconds = (track_start_frame + frame) as f64 / self.sample_rate as f64;
            let pitch_lfo = lfo_value(voice.lfos[LfoTarget::Pitch.index()], time_seconds);
            let level_lfo = lfo_value(voice.lfos[LfoTarget::Level.index()], time_seconds);
            let filter_lfo = lfo_value(voice.lfos[LfoTarget::Filter.index()], time_seconds);
            let pulse_lfo = lfo_value(voice.lfos[LfoTarget::PulseWidth.index()], time_seconds);
            let envelope = envelope_level(
                frame,
                frame_count,
                attack,
                decay,
                voice.sustain,
                release_start,
            );
            let mut oscillator_mix = 0.0_f64;
            for (oscillator_index, oscillator) in voice
                .oscillators
                .iter()
                .take(self.active_oscillator_count)
                .copied()
                .enumerate()
            {
                if oscillator.level == 0.0 {
                    continue;
                }
                let cents = oscillator.detune_cents + pitch_lfo * voice.lfos[0].depth * 100.0;
                let oscillator_frequency =
                    frequency * oscillator.ratio * 2.0_f64.powf(cents / 1_200.0);
                let phase_step = oscillator_frequency / self.sample_rate as f64;
                let phase = phases[oscillator_index];
                let pulse_width =
                    (oscillator.pulse_width + pulse_lfo * voice.lfos[3].depth).clamp(0.01, 0.99);
                let oscillator_sample = match oscillator.waveform {
                    Waveform::Sine => {
                        let angle = phase * 2.0 * PI;
                        angle.sin()
                    }
                    Waveform::Triangle => 1.0 - 4.0 * (phase - 0.5).abs(),
                    Waveform::Saw => {
                        let naive = phase * 2.0 - 1.0;
                        naive - poly_blep(phase, phase_step)
                    }
                    Waveform::Pulse => {
                        let naive = if phase < pulse_width { 1.0 } else { -1.0 };
                        naive + poly_blep(phase, phase_step)
                            - poly_blep((phase - pulse_width + 1.0) % 1.0, phase_step)
                    }
                    Waveform::Noise => {
                        noise ^= noise << 13;
                        noise ^= noise >> 17;
                        noise ^= noise << 5;
                        noise as f64 / u32::MAX as f64 * 2.0 - 1.0
                    }
                    Waveform::Custom => {
                        let table = custom_wave.as_ref().ok_or_else(|| {
                            Error::syntax("CUSTOM waveform requires WAVE sample data")
                        })?;
                        let position = phase * table.len() as f64;
                        let first = position.floor() as usize % table.len();
                        let second = (first + 1) % table.len();
                        let fraction = position - position.floor();
                        table[first] as f64 * (1.0 - fraction) + table[second] as f64 * fraction
                    }
                    // Ney: Persian end-blown flute. A sustained tone with a
                    // strong fundamental (triangle) blended with breath noise.
                    // The breath noise is shaped by the amplitude envelope so
                    // it swells with the note. Slight vibrato via the pitch LFO.
                    Waveform::Ney => {
                        let tone = 1.0 - 4.0 * (phase - 0.5).abs();
                        noise ^= noise << 13;
                        noise ^= noise >> 17;
                        noise ^= noise << 5;
                        let breath = noise as f64 / u32::MAX as f64 * 2.0 - 1.0;
                        // Blend: strong fundamental + ~6% breath noise.
                        tone * 0.94 + breath * 0.06
                    }
                    Waveform::Banjo
                    | Waveform::Guitar
                    | Waveform::Bass
                    | Waveform::Santur
                    | Waveform::Tar
                    | Waveform::Setar => {
                        debug_assert_eq!(oscillator_index, 0);
                        let raw: f64 = if let Some(ref mut set) = banjo_string_set {
                            set.tick() as f64
                        } else {
                            waveguide_string
                                .as_mut()
                                .map_or(0.0, |string| string.tick() as f64)
                        };
                        let mut out = raw;
                        // Santur: blend the struck-string with the metallic
                        // body ring for the bright, bell-like dulcimer tone.
                        // The body is excited only at the note onset so it
                        // rings out naturally rather than being pumped every
                        // frame (which would never decay).
                        if let Some(ref mut s) = santur_body {
                            if frame == 0 {
                                s.excite(0.5);
                            }
                            out = out * 0.85 + s.tick() * 0.15;
                        }
                        // Pick noise is disabled for banjo (harmonic weights cover
                        // the attack).  Guitar/bass keep a tiny scrape if enabled.
                        if pick_noise_remaining > 0 {
                            pick_noise_remaining -= 1;
                            let noise = ((frame
                                .wrapping_mul(6364136223846793005)
                                .wrapping_add(1442695040888963407))
                                as f64
                                / u64::MAX as f64)
                                * 2.0
                                - 1.0;
                            out += noise * pick_noise_amp;
                        }
                        out
                    }
                };
                oscillator_mix += oscillator_sample * oscillator.level;
                phases[oscillator_index] += phase_step;
                phases[oscillator_index] -= phases[oscillator_index].floor();
            }
            let driven = apply_drive_sample(oscillator_mix, voice.drive);
            let filter_envelope = envelope_level(
                frame,
                frame_count,
                filter_attack,
                filter_decay,
                voice.filter_envelope.sustain,
                filter_release_start,
            );
            let filter_octaves = filter_envelope * voice.filter_envelope.amount_octaves
                + filter_lfo * voice.lfos[2].depth;
            let key_tracking = (frequency / 440.0).powf(voice.filter_key_track);
            let cutoff_hz = (voice.filter.cutoff_hz * key_tracking * 2.0_f64.powf(filter_octaves))
                .clamp(20.0, self.sample_rate as f64 * 0.49);
            let filtered = filter_state.process(driven, self.sample_rate, voice.filter, cutoff_hz);
            // Small speakers lose fundamentals below roughly 220 Hz. Give
            // bass notes a controlled compensation before the final mix
            // normalization, without changing the user's voice volume.
            let bass_compensation = if frequency < 220.0 {
                1.0 + (220.0 - frequency) / 440.0
            } else {
                1.0
            };
            let level_modulation = (1.0 + level_lfo * voice.lfos[1].depth).clamp(0.0, 2.0);
            let sample = filtered * envelope * level_modulation * voice.volume * bass_compensation;
            self.tracks[voice_index].push(sample as f32);
        }
        self.last_frequencies[voice_index] = Some(end_hz);
        Ok(())
    }
}

/// Map ModernBASIC voices onto melodic General MIDI channels. MIDI channel
/// 10 is reserved for percussion and is therefore never selected implicitly;
/// an instrument role must come only from BASIC's `INSTRUMENT` statement.
pub(crate) fn midi_channel_for_voice(voice: i64) -> Result<usize, Error> {
    voice_index(voice).map(|index| match index {
        0..=8 => index,
        9..=14 => index + 1,
        // Sixteen BASIC voices fit across the fifteen melodic MIDI channels;
        // voice 16 shares channel 1 without changing its instrument role.
        _ => 0,
    })
}

#[derive(Debug, Clone, Copy)]
pub(crate) struct ParsedNote {
    pub(crate) frequency: Option<f64>,
    pub(crate) beats: f64,
    pub(crate) velocity: u8,
}
pub(crate) fn parse_note(token: &str, default_beats: f64) -> Result<ParsedNote, Error> {
    let (notation, velocity) = if let Some((notation, velocity)) = token.rsplit_once('@') {
        let velocity = velocity
            .parse::<u8>()
            .map_err(|_| Error::syntax("note velocity after '@' must be 1 through 127"))?;
        if velocity == 0 || velocity > 127 {
            return Err(Error::IllegalQuantity);
        }
        (notation, velocity)
    } else {
        (token, 127)
    };
    let (note_text, beats) = if let Some((note, length)) = notation.split_once(':') {
        let beats = length
            .parse::<f64>()
            .map_err(|_| Error::syntax("note duration after ':' must be a number of beats"))?;
        (note, beats)
    } else if let Some((note, denominator)) = notation.split_once('/') {
        // Musical notation: C4/4 = quarter, C4/8 = eighth, C4/16 = sixteenth
        // Dotted: C4/8. = dotted eighth (1.5x duration)
        let (denom_str, dotted) = if let Some(denominator) = denominator.strip_suffix('.') {
            (denominator, true)
        } else {
            (denominator, false)
        };
        let denominator = denom_str
            .parse::<f64>()
            .map_err(|_| Error::syntax("note length after '/' must be numeric"))?;
        if denominator <= 0.0 {
            return Err(Error::IllegalQuantity);
        }
        let mut beats = 4.0 / denominator;
        if dotted {
            beats *= 1.5;
        }
        (note, beats)
    } else {
        (notation, default_beats)
    };
    if !beats.is_finite() || beats <= 0.0 {
        return Err(Error::IllegalQuantity);
    }

    let upper = note_text.trim().to_ascii_uppercase();
    if matches!(upper.as_str(), "R" | "REST" | "-") {
        if beats > MAX_REST_BEATS {
            return Err(Error::IllegalQuantity);
        }
        return Ok(ParsedNote {
            frequency: None,
            beats,
            velocity,
        });
    }
    if beats > MAX_NOTE_BEATS {
        return Err(Error::IllegalQuantity);
    }
    let mut chars = upper.chars();
    let letter = chars
        .next()
        .ok_or_else(|| Error::syntax("empty note in PLAY sequence"))?;
    let semitone = match letter {
        'C' => 0,
        'D' => 2,
        'E' => 4,
        'F' => 5,
        'G' => 7,
        'A' => 9,
        'B' => 11,
        _ => return Err(Error::syntax("notes must use A through G or R for rest")),
    };
    let remainder = chars.collect::<String>();
    let (accidental, octave_text) = match remainder.as_bytes().first().copied() {
        Some(b'#') => (1, &remainder[1..]),
        Some(b'B') => (-1, &remainder[1..]),
        _ => (0, remainder.as_str()),
    };
    let octave = octave_text
        .parse::<i32>()
        .map_err(|_| Error::syntax("notes require an octave, for example C4 or F#3"))?;
    if !(-1..=9).contains(&octave) {
        return Err(Error::IllegalQuantity);
    }
    let midi = (octave + 1) * 12 + semitone + accidental;
    let frequency = 440.0 * 2.0_f64.powf((midi as f64 - 69.0) / 12.0);
    Ok(ParsedNote {
        frequency: Some(frequency),
        beats,
        velocity,
    })
}

pub(crate) fn voice_index(voice: i64) -> Result<usize, Error> {
    if (1..=VOICE_COUNT as i64).contains(&voice) {
        Ok(voice as usize - 1)
    } else {
        Err(Error::IllegalQuantity)
    }
}

fn milliseconds_to_frames(milliseconds: f64, sample_rate: u32) -> usize {
    (milliseconds / 1_000.0 * sample_rate as f64).round() as usize
}

fn apply_master_output(
    samples: &mut [f32],
    _sample_rate: u32,
    output_level: f32,
) -> Result<(), Error> {
    let level = output_level.clamp(0.0, 1.0);
    for chunk in samples.chunks_mut(AUDIO_RENDER_INTERRUPT_FRAMES) {
        check_audio_render_interrupt()?;
        for sample in chunk {
            *sample = (*sample * level).clamp(-1.0, 1.0);
        }
    }
    Ok(())
}

fn apply_drive_sample(sample: f64, amount: f64) -> f64 {
    if amount <= 0.0 {
        return sample;
    }
    let gain = 1.0 + amount * 11.0;
    (sample * gain).tanh() / gain.tanh()
}

fn lfo_value(lfo: Lfo, time_seconds: f64) -> f64 {
    if lfo.rate_hz <= 0.0 || lfo.depth <= 0.0 {
        return 0.0;
    }
    let cycles = time_seconds * lfo.rate_hz;
    let phase = cycles - cycles.floor();
    match lfo.waveform {
        LfoWaveform::Sine => (phase * 2.0 * PI).sin(),
        LfoWaveform::Triangle => 1.0 - 4.0 * (phase - 0.5).abs(),
        LfoWaveform::Saw => phase * 2.0 - 1.0,
        LfoWaveform::Pulse => {
            if phase < 0.5 {
                1.0
            } else {
                -1.0
            }
        }
        LfoWaveform::SampleHold => {
            let mut state = cycles.floor() as u64 ^ 0x9e37_79b9_7f4a_7c15;
            state ^= state >> 30;
            state = state.wrapping_mul(0xbf58_476d_1ce4_e5b9);
            state ^= state >> 27;
            state = state.wrapping_mul(0x94d0_49bb_1331_11eb);
            state ^= state >> 31;
            state as f64 / u64::MAX as f64 * 2.0 - 1.0
        }
    }
}

/// Topology-preserving state-variable filter. It remains stable while
/// FILTERADSR and the filter LFO move the cutoff on every sample.
#[derive(Debug, Default)]
struct SvfState {
    integrator_1: f64,
    integrator_2: f64,
}

impl SvfState {
    fn process(&mut self, input: f64, sample_rate: u32, filter: Filter, cutoff_hz: f64) -> f64 {
        if filter.mode == FilterMode::Off {
            return input;
        }
        let cutoff = cutoff_hz.clamp(20.0, sample_rate as f64 * 0.49);
        let g = (PI * cutoff / sample_rate as f64).tan();
        let damping = 2.0 - filter.resonance * 1.9;
        let a1 = 1.0 / (1.0 + g * (g + damping));
        let a2 = g * a1;
        let a3 = g * a2;
        let v3 = input - self.integrator_2;
        let band = a1 * self.integrator_1 + a2 * v3;
        let low = self.integrator_2 + a2 * self.integrator_1 + a3 * v3;
        self.integrator_1 = 2.0 * band - self.integrator_1;
        self.integrator_2 = 2.0 * low - self.integrator_2;
        let high = input - damping * band - low;
        match filter.mode {
            FilterMode::Off => input,
            FilterMode::LowPass => low,
            FilterMode::HighPass => high,
            FilterMode::BandPass => band,
            FilterMode::Notch => low + high,
        }
    }
}

// Ported from the proven RustBASIC voice core: PolyBLEP removes the
// discontinuity aliasing that made pulse and saw voices sound like noise.
fn poly_blep(phase: f64, step: f64) -> f64 {
    if step <= 0.0 {
        return 0.0;
    }
    if phase < step {
        let position = phase / step;
        2.0 * position - position * position - 1.0
    } else if phase > 1.0 - step {
        let position = (phase - 1.0) / step;
        position * position + 2.0 * position + 1.0
    } else {
        0.0
    }
}

fn envelope_level(
    frame: usize,
    total: usize,
    attack: usize,
    decay: usize,
    sustain: f64,
    release_start: usize,
) -> f64 {
    let attack_level = if attack > 0 && frame < attack {
        frame as f64 / attack as f64
    } else {
        1.0
    };
    let decay_level = if frame >= attack && decay > 0 && frame < attack.saturating_add(decay) {
        let position = (frame - attack) as f64 / decay as f64;
        1.0 - (1.0 - sustain) * position
    } else if frame >= attack.saturating_add(decay) {
        sustain
    } else {
        attack_level
    };
    if frame >= release_start && total > release_start {
        let remaining = total.saturating_sub(frame) as f64;
        let release_frames = total.saturating_sub(release_start) as f64;
        decay_level * (remaining / release_frames)
    } else {
        decay_level
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicBool, Ordering};

    #[test]
    fn native_rendering_observes_the_window_interrupt() {
        let interrupt = Arc::new(AtomicBool::new(false));
        crate::interpreter::set_thread_interrupt_flag(Some(Arc::clone(&interrupt)));

        let mut synth = SidSynth::default();
        interrupt.store(true, Ordering::SeqCst);
        assert_eq!(
            synth.play_tone(1, 440.0, 100.0, None, None),
            Err(Error::Break)
        );

        synth.tracks[0] = vec![0.25; AUDIO_RENDER_INTERRUPT_FRAMES * 2];
        interrupt.store(true, Ordering::SeqCst);
        assert_eq!(synth.render_wav(), Err(Error::Break));

        crate::interpreter::set_thread_interrupt_flag(None);
    }

    #[test]
    fn playback_sessions_keep_independent_process_ownership() {
        let first = PlaybackSession::default();
        let second = PlaybackSession::default();
        assert!(!Arc::ptr_eq(&first.state, &second.state));
        first.state.lock().unwrap().pid = u32::MAX;
        assert!(first.is_active());
        assert!(!second.is_active());
        first.state.lock().unwrap().pid = 0;
    }

    #[test]
    fn playback_errors_are_retained_until_consumed() {
        let session = PlaybackSession::default();
        session.state.lock().unwrap().last_error = Some("broken audio pipe".to_string());

        assert_eq!(
            session.take_error(),
            Some(Error::Io("broken audio pipe".to_string()))
        );
        assert_eq!(session.take_error(), None);
        assert_eq!(session.wait(), Ok(()));
    }

    #[test]
    fn note_parser_supports_sharps_flats_rests_and_lengths() {
        let c4 = parse_note("C4", 1.0).unwrap();
        let sharp = parse_note("C#4:0.5", 1.0).unwrap();
        let flat = parse_note("Db4/8", 1.0).unwrap();
        assert!((sharp.frequency.unwrap() - flat.frequency.unwrap()).abs() < 0.001);
        assert_eq!(sharp.beats, 0.5);
        assert_eq!(flat.beats, 0.5);
        assert_eq!(c4.velocity, 127);
        assert_eq!(parse_note("C4:0.5@96", 1.0).unwrap().velocity, 96);
        assert_eq!(parse_note("C4/8@48", 1.0).unwrap().velocity, 48);
        assert!(parse_note("C4@0", 1.0).is_err());
        assert!(parse_note("C4@128", 1.0).is_err());
        assert_eq!(parse_note("C4/8.", 1.0).unwrap().beats, 0.75);
        assert!(c4.frequency.unwrap() > 260.0);
        assert!(parse_note("R:2", 1.0).unwrap().frequency.is_none());
        assert_eq!(parse_note("R:188", 1.0).unwrap().beats, 188.0);
        assert!(parse_note("C4:188", 1.0).is_err());
        assert_eq!(parse_note("R:512", 1.0).unwrap().beats, 512.0);
        assert!(parse_note("R:512.1", 1.0).is_err());
    }

    #[test]
    fn voice_numbers_are_checked_without_pattern_expressions() {
        assert_eq!(voice_index(1).unwrap(), 0);
        assert_eq!(voice_index(VOICE_COUNT as i64).unwrap(), VOICE_COUNT - 1);
        assert!(voice_index(0).is_err());
        assert!(voice_index(VOICE_COUNT as i64 + 1).is_err());
    }

    #[test]
    fn named_and_detected_profiles_are_bounded() {
        assert_eq!(
            SynthProfile::Compact.arrangement(),
            SynthArrangement {
                voices: 8,
                oscillators: 2,
            }
        );
        assert_eq!(
            SynthProfile::Standard.arrangement(),
            SynthArrangement {
                voices: 16,
                oscillators: 3,
            }
        );
        assert_eq!(SynthProfile::Extended.arrangement().oscillators, 6);
        assert_eq!(SynthProfile::Maximum.arrangement().oscillators, 8);
        assert!(SynthProfile::parse("auto").is_ok());
        assert!(SynthProfile::parse("oversized").is_err());

        let hardware = scan_audio_hardware();
        let automatic = SynthProfile::Auto.arrangement();
        assert!(hardware.logical_cpus >= 1);
        assert_ne!(hardware.recommended, SynthProfile::Auto);
        assert!((1..=VOICE_COUNT).contains(&automatic.voices));
        assert!((1..=MAX_OSCILLATOR_COUNT).contains(&automatic.oscillators));
    }

    #[test]
    fn runtime_arrangement_can_trade_voices_for_more_oscillators() {
        let mut standard = SidSynth::default();
        assert_eq!(standard.voice_count(), 16);
        assert_eq!(standard.oscillator_count(), 3);
        assert!(standard
            .set_oscillator(1, 4, Waveform::Saw, 2.0, 0.0, 0.25)
            .is_err());

        let mut expanded = SidSynth::with_arrangement(SynthArrangement {
            voices: 12,
            oscillators: 6,
        })
        .unwrap();
        expanded
            .set_oscillator(12, 6, Waveform::Saw, 2.0, 0.0, 0.25)
            .unwrap();
        expanded.play_tone(12, 220.0, 20.0, None, None).unwrap();
        assert_eq!(expanded.voice_count(), 12);
        assert_eq!(expanded.oscillator_count(), 6);
        assert!(expanded.tracks[11].iter().any(|sample| sample.abs() > 0.0));
        assert!(expanded.select_voice(13).is_err());
        assert!(expanded.set_oscillator_count(0).is_err());
        assert!(expanded.set_oscillator_count(9).is_err());
    }

    #[test]
    fn polyphonic_song_renders_a_deterministic_pcm_wav() {
        let mut synth = SidSynth::default();
        synth.set_waveform(1, Waveform::Saw).unwrap();
        synth.set_waveform(2, Waveform::Triangle).unwrap();
        synth.play_sequence(1, "C4 E4 G4 C5", 0.25).unwrap();
        synth.play_sequence(2, "C3 R G3 R", 0.25).unwrap();
        let first = synth.render_wav().unwrap();
        let second = synth.render_wav().unwrap();
        assert_eq!(first, second);
        assert_eq!(&first[..4], b"RIFF");
        assert_eq!(&first[8..12], b"WAVE");
        assert!(first.len() > 44);
    }

    #[test]
    fn voices_are_independent_and_play_rest_is_silence() {
        let mut synth = SidSynth::default();
        synth.set_tempo(120.0).unwrap();
        synth.play_sequence(1, "C4 R C4", 1.0).unwrap();
        synth.play_sequence(2, "C3", 1.0).unwrap();

        let frames_per_beat = 22_050;
        assert_eq!(synth.tracks[0].len(), frames_per_beat * 3);
        assert_eq!(synth.tracks[1].len(), frames_per_beat);
        assert!(synth.tracks[0][frames_per_beat..frames_per_beat * 2]
            .iter()
            .all(|sample| *sample == 0.0));

        let wav = synth.render_wav().unwrap();
        assert_eq!(wav.len(), 44 + frames_per_beat * 3 * 4);
        assert_eq!(u16::from_le_bytes([wav[22], wav[23]]), 2);
    }

    #[test]
    fn absolute_soundfont_mix_preserves_overlapping_events() {
        let mut synth = SidSynth::default();
        let pcm = [1_000_i16, 1_000, 1_000, 1_000];
        synth.mix_soundfont_pcm_at(1, 0.0, &pcm).unwrap();
        synth
            .mix_soundfont_pcm_at(1, 1.0 / synth.sample_rate as f64, &pcm)
            .unwrap();
        assert_eq!(synth.tracks[0].len(), 3);
        assert!((synth.tracks[0][1] - synth.tracks[0][0] * 2.0).abs() < 0.000_001);
        assert!((synth.tracks[0][2] - synth.tracks[0][0]).abs() < 0.000_001);
        assert!(synth.mix_soundfont_pcm_at(1, -1.0, &pcm).is_err());
        assert!(synth.mix_soundfont_pcm_at(1, 0.0, &[1]).is_err());
    }

    #[test]
    fn master_output_applies_volume_and_clamps_hot_audio() {
        let mut quiet = SidSynth::default();
        quiet.tracks[0] = vec![0.01, -0.01];
        let quiet_wav = quiet.render_wav().unwrap();
        let quiet_sample =
            i16::from_le_bytes([quiet_wav[44], quiet_wav[45]]) as f32 / i16::MAX as f32;
        let quiet_right =
            i16::from_le_bytes([quiet_wav[46], quiet_wav[47]]) as f32 / i16::MAX as f32;
        // No gain boost — just volume scaling. Default volume is 1.0.
        assert!((quiet_sample - 0.01).abs() < 0.001);
        assert!((quiet_right - 0.01).abs() < 0.001);

        let mut hot = SidSynth::default();
        hot.tracks[0] = vec![0.8, -0.8];
        let hot_wav = hot.render_wav().unwrap();
        let hot_sample = i16::from_le_bytes([hot_wav[44], hot_wav[45]]) as f32 / i16::MAX as f32;
        // Clean clamp at 1.0, no limiter pumping.
        assert!((hot_sample - 0.8).abs() < 0.001);
    }

    #[test]
    fn master_volume_is_applied_and_mute_is_silent() {
        let mut synth = SidSynth::default();
        synth.tracks[0] = vec![0.01, -0.01];
        synth.set_master_volume(0.25).unwrap();
        let wav = synth.render_wav().unwrap();
        let sample = i16::from_le_bytes([wav[44], wav[45]]) as f32 / i16::MAX as f32;
        assert!((sample - 0.01 * 0.25).abs() < 0.001);

        synth.set_enabled(false);
        let muted = synth.render_wav().unwrap();
        assert!(muted[44..].iter().all(|byte| *byte == 0));
    }

    #[test]
    fn custom_wave_tables_and_frequency_sweeps_render_without_note_gaps() {
        let mut synth = SidSynth::default();
        synth
            .set_wave_table(1, &[-1.0, -0.25, 0.75, 1.0, 0.25])
            .unwrap();
        synth
            .play_sweep(1, 110.0, 880.0, 100.0, Some(0.5), None, None)
            .unwrap();
        assert_eq!(synth.tracks[0].len(), 4_410);
        assert!(synth.tracks[0].iter().any(|sample| sample.abs() > 0.001));
    }

    #[test]
    fn soundfont_voices_use_full_channel_level_without_hidden_attenuation() {
        let mut synth = SidSynth::default();
        synth.set_voice_count(2).unwrap();
        synth.set_volume(2, 0.4).unwrap();
        synth.set_pan(2, -0.25).unwrap();
        let mix = synth.soundfont_voice_mix();
        assert_eq!(mix[0], (1.0, 0.0));
        assert_eq!(mix[1], (0.4, -0.25));
        assert_eq!(mix[2], (0.0, 0.0));
    }

    #[test]
    fn sampled_dsp_is_opt_in_and_retains_each_basic_voice() {
        let mut synth = SidSynth::default();
        assert_eq!(synth.soundfont_voice_dsp()[2], None);
        synth.set_sampled_dsp(3, 0.4, 0.6, 0.8, 0.2, 0.35).unwrap();
        assert_eq!(
            synth.soundfont_voice_dsp()[2],
            Some(SoundFontDsp {
                drive: 0.4,
                tone: 0.6,
                presence: 0.8,
                compression: 0.2,
                gate: 0.35,
            })
        );
        assert_eq!(synth.soundfont_voice_dsp()[1], None);
        assert_eq!(
            synth.set_sampled_dsp(3, 0.0, 0.0, 0.0, 0.0, 1.01),
            Err(Error::IllegalQuantity)
        );
    }

    #[test]
    fn sampled_adsr_is_opt_in_and_retains_each_basic_voice() {
        let mut synth = SidSynth::default();
        assert_eq!(synth.soundfont_voice_envelopes()[0], None);
        synth.set_envelope(1, 3.0, 90.0, 0.9, 220.0).unwrap();
        assert_eq!(
            synth.soundfont_voice_envelopes()[0],
            Some(SoundFontEnvelope {
                attack_ms: 3.0,
                decay_ms: 90.0,
                sustain: 0.9,
                release_ms: 220.0,
            })
        );
        assert_eq!(synth.soundfont_voice_envelopes()[1], None);
    }

    #[test]
    fn modern_voices_never_acquire_an_implicit_percussion_role() {
        let mut synth = SidSynth::default();
        assert_eq!(synth.voice_count(), 16);
        assert_eq!(midi_channel_for_voice(1).unwrap(), 0);
        assert_eq!(midi_channel_for_voice(8).unwrap(), 7);
        assert_eq!(midi_channel_for_voice(9).unwrap(), 8);
        assert_eq!(midi_channel_for_voice(10).unwrap(), 10);
        assert_eq!(midi_channel_for_voice(16).unwrap(), 0);
        assert!((1..=16).all(|voice| midi_channel_for_voice(voice).unwrap() != 9));
        synth.set_voice_count(4).unwrap();
        assert!(synth.select_voice(5).is_err());
        assert!(synth.select_voice(4).is_ok());
    }

    #[test]
    fn moderate_pan_keeps_signal_in_both_stereo_channels() {
        let mut synth = SidSynth::default();
        synth.tracks[0] = vec![0.01];
        synth.set_pan(1, -0.25).unwrap();
        let wav = synth.render_wav().unwrap();
        let left = i16::from_le_bytes([wav[44], wav[45]]).unsigned_abs();
        let right = i16::from_le_bytes([wav[46], wav[47]]).unsigned_abs();
        assert!(left > right);
        assert!(right > 0);
    }

    #[test]
    fn pan_center_and_endpoints_write_the_expected_stereo_channels() {
        fn first_frame(pan: f64) -> (i16, i16) {
            let mut synth = SidSynth::default();
            synth.tracks[0] = vec![0.01];
            synth.set_pan(1, pan).unwrap();
            let wav = synth.render_wav().unwrap();
            assert_eq!(u16::from_le_bytes([wav[22], wav[23]]), 2);
            assert_eq!(u16::from_le_bytes([wav[32], wav[33]]), 4);
            (
                i16::from_le_bytes([wav[44], wav[45]]),
                i16::from_le_bytes([wav[46], wav[47]]),
            )
        }

        let center = first_frame(0.0);
        assert!(center.0 > 0);
        assert_eq!(center.0, center.1);

        let left = first_frame(-1.0);
        assert!(left.0 > 0);
        assert_eq!(left.1, 0);

        let right = first_frame(1.0);
        assert_eq!(right.0, 0);
        assert!(right.1 > 0);
    }

    #[test]
    fn per_voice_modulated_filter_is_stable_and_changes_the_timbre() {
        let mut plain = SidSynth::default();
        plain.set_waveform(1, Waveform::Saw).unwrap();
        plain.play_tone(1, 880.0, 500.0, None, None).unwrap();

        let mut filtered = SidSynth::default();
        filtered.set_waveform(1, Waveform::Saw).unwrap();
        filtered
            .set_filter(1, FilterMode::LowPass, 450.0, 0.72, 0.5)
            .unwrap();
        filtered
            .set_filter_envelope(1, 5.0, 180.0, 0.25, 90.0, 3.0)
            .unwrap();
        filtered
            .set_lfo(1, LfoTarget::Filter, LfoWaveform::Sine, 4.0, 0.75)
            .unwrap();
        filtered.play_tone(1, 880.0, 500.0, None, None).unwrap();

        assert_ne!(plain.tracks[0], filtered.tracks[0]);
        assert!(filtered.tracks[0]
            .iter()
            .all(|sample| sample.is_finite() && sample.abs() < 4.0));
    }

    #[test]
    fn three_oscillators_lfo_glide_and_drive_change_native_pcm() {
        let mut plain = SidSynth::default();
        plain.set_waveform(1, Waveform::Saw).unwrap();
        plain.play_sequence(1, "A3 A4", 0.25).unwrap();

        let mut patch = SidSynth::default();
        patch
            .set_oscillator(1, 1, Waveform::Saw, 1.0, -7.0, 0.7)
            .unwrap();
        patch
            .set_oscillator(1, 2, Waveform::Pulse, 0.5, 5.0, 0.35)
            .unwrap();
        patch
            .set_oscillator(1, 3, Waveform::Triangle, 2.0, 0.0, 0.2)
            .unwrap();
        patch.set_oscillator_pulse_width(1, 2, 0.32).unwrap();
        patch
            .set_lfo(1, LfoTarget::Pitch, LfoWaveform::Triangle, 5.0, 0.12)
            .unwrap();
        patch.set_glide(1, 90.0).unwrap();
        patch.set_drive(1, 0.3).unwrap();
        patch.play_sequence(1, "A3 A4", 0.25).unwrap();

        assert_eq!(plain.tracks[0].len(), patch.tracks[0].len());
        assert_ne!(plain.tracks[0], patch.tracks[0]);
        assert_eq!(patch.last_frequencies[0], Some(440.0));
        assert!(patch.tracks[0].iter().all(|sample| sample.is_finite()));
    }

    #[test]
    fn mixer_selects_synth_midi_or_both_per_voice() {
        let mut synth = SidSynth::default();
        assert!(!synth.native_play_routes()[0]);
        assert!(synth.sampled_play_routes()[0]);

        synth.set_voice_mix(1, 1.0, 0.0).unwrap();
        assert!(synth.native_play_routes()[0]);
        assert!(!synth.sampled_play_routes()[0]);

        synth.set_voice_mix(2, 0.0, 1.0).unwrap();
        assert!(!synth.native_play_routes()[1]);
        assert!(synth.sampled_play_routes()[1]);

        synth.set_voice_mix(3, 0.6, 0.8).unwrap();
        assert!(synth.native_play_routes()[2]);
        assert!(synth.sampled_play_routes()[2]);
        assert_eq!(synth.soundfont_voice_mix()[2].0, 0.8);

        let explicit = synth.explicit_sampled_play_routes();
        assert!(!synth
            .play_sequence_uses_route(1, "C4 V2 R", 1.0, explicit)
            .unwrap());
        assert!(synth
            .play_sequence_uses_route(1, "C4 V2 E4", 1.0, explicit)
            .unwrap());
    }

    #[test]
    fn stereo_wav_mixer_overlays_and_pads_without_clipping() {
        fn wav(samples: &[i16]) -> Vec<u8> {
            let mut wav = pcm_wav_header(samples.len() * 2).unwrap();
            for sample in samples {
                wav.extend_from_slice(&sample.to_le_bytes());
            }
            wav
        }
        let first = wav(&[20_000, -20_000, 1_000, -1_000]);
        let second = wav(&[20_000, -20_000]);
        let mixed = mix_stereo_pcm_wavs(&first, &second).unwrap();
        assert_eq!(mixed.len(), first.len());
        assert_eq!(&mixed[..4], b"RIFF");
        let pcm = mixed[44..]
            .chunks_exact(2)
            .map(|sample| i16::from_le_bytes([sample[0], sample[1]]))
            .collect::<Vec<_>>();
        assert_eq!(pcm.len(), 4);
        assert_eq!(pcm[0], i16::MAX);
        assert!(pcm[1] < 0);
        assert!(pcm[2] > 0);
        assert!(mix_stereo_pcm_wavs(b"bad", &second).is_err());
    }
}
