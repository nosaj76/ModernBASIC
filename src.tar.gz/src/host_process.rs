//! Host-process helpers shared by browser and desktop-file launchers.

use std::process::Child;
use std::sync::{Arc, Mutex};

use crate::error::Error;

/// Arrange for a host helper's exit status to be collected. Dropping `Child`
/// without waiting leaves a zombie on Unix.
pub(crate) fn reap_child(child: Child, context: &str) -> Result<(), Error> {
    let shared = Arc::new(Mutex::new(Some(child)));
    let worker = Arc::clone(&shared);
    let reaper = std::thread::Builder::new()
        .name("modernbasic-child-reaper".to_string())
        .spawn(move || {
            let child = worker
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
                .take();
            if let Some(mut child) = child {
                let _ = child.wait();
            }
        });
    if let Err(error) = reaper {
        terminate_unreaped_child(&shared);
        return Err(Error::Io(format!(
            "{context}: could not start child reaper: {error}"
        )));
    }
    Ok(())
}

fn terminate_unreaped_child(shared: &Mutex<Option<Child>>) {
    let child = shared
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .take();
    if let Some(mut child) = child {
        let _ = child.kill();
        let _ = child.wait();
    }
}
