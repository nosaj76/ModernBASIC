//! Native DATA/READ/RESTORE state for the ModernBASIC interpreter.
//!
//! This module corresponds to the `DATA`, `READ` and `RESTORE` handling in the
//! original `input.s`, `flow1.s`, `flow2.s` and `program.s`, but uses a Rust-
//! native side-by-side design.  DATA payloads are kept as opaque text captured
//! by the tokenizer; this module splits them into items on commas outside
//! quotes, tracks a bounded cursor in source/statement order, and converts
//! each item to the requested numeric or string value when READ consumes it.
//!
//! No 6502 memory layout, ROM address or interactive INPUT is emulated here.

use crate::error::Error;
use crate::integer::{BasicInteger, NumericMode};
use crate::program::Program;
use crate::real::BasicReal;
use crate::tokens::TokenInstance;
use crate::value::Value;

/// Default maximum number of DATA items for modern 64-bit mode.
pub const DEFAULT_MAX_DATA_ITEMS: usize = 1_000_000;
/// Tighter default for legacy 6502-compatible mode.
pub const LEGACY_MAX_DATA_ITEMS: usize = 65_536;

/// A single DATA item after a `DATA` payload has been split on commas outside
/// quotes.
#[derive(Debug, Clone)]
struct DataItem {
    /// Source line number that contributed this item.
    line: u64,
    /// Raw text of the field, exactly as it appeared between commas.
    text: String,
}

/// Bounded cursor over the DATA items in a program.
#[derive(Debug, Clone, Default)]
pub struct DataCursor {
    items: Vec<DataItem>,
    pos: usize,
}

impl DataCursor {
    /// Build a cursor from a program, collecting DATA payloads in ascending
    /// line and statement order and enforcing a total item limit.
    pub fn from_program(program: &Program, max_items: usize) -> Result<Self, Error> {
        let mut items = Vec::new();
        for (&line_number, body) in program.iter() {
            for token in body {
                if let TokenInstance::Data(payload) = token {
                    let fields = split_comma_fields(payload);
                    if fields.is_empty() {
                        // Bare `DATA` contributes no items.
                        continue;
                    }
                    let new_total = items
                        .len()
                        .checked_add(fields.len())
                        .ok_or(Error::DataLimitExceeded { limit: max_items })?;
                    if new_total > max_items {
                        return Err(Error::DataLimitExceeded { limit: max_items });
                    }
                    for field in fields {
                        items.push(DataItem {
                            line: line_number,
                            text: field,
                        });
                    }
                }
            }
        }
        Ok(Self { items, pos: 0 })
    }

    /// Reset the cursor to the first DATA item, as `RESTORE` does.
    pub fn reset(&mut self) {
        self.pos = 0;
    }

    /// Position at the first DATA item on or after `line`, as `RESTORE line` does.
    pub fn restore_line(&mut self, line: u64) {
        self.pos = self
            .items
            .iter()
            .position(|item| item.line >= line)
            .unwrap_or(self.items.len());
    }

    /// Total number of DATA items available.
    pub fn len(&self) -> usize {
        self.items.len()
    }

    /// Whether the program contains no DATA items.
    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    /// Read the next item as an exact integer under the given numeric mode.
    ///
    /// An empty field reads as zero. Any other field must be a complete numeric
    /// literal whose value is integral and in range. Invalid fields report an
    /// error tied to the source item or integer-conversion requirement.
    pub fn read_integer(&mut self, mode: NumericMode, read_line: u64) -> Result<i64, Error> {
        self.read_numeric(mode, read_line)?.to_integer()
    }

    /// Read the next item as an exact integer or finite native real.
    pub fn read_numeric(&mut self, mode: NumericMode, read_line: u64) -> Result<Value, Error> {
        let item = self
            .items
            .get(self.pos)
            .ok_or(Error::OutOfData { line: read_line })?;
        self.pos += 1;
        parse_numeric_value_field(&item.text, mode).map_err(|_| Error::BadData { line: item.line })
    }

    /// Read the next item as a string, enforcing the configured byte limit.
    ///
    /// String items may be quoted (`"..."`) or unquoted.  Exterior whitespace
    /// is trimmed, interior text is preserved, and quoted fields are checked for
    /// a matching closing quote.  Malformed quoted fields and any conversion
    /// error other than [`Error::StringTooLong`] report [`Error::BadData`]
    /// carrying the DATA source line.
    pub fn read_string(
        &mut self,
        max_string_bytes: usize,
        read_line: u64,
    ) -> Result<String, Error> {
        let item = self
            .items
            .get(self.pos)
            .ok_or(Error::OutOfData { line: read_line })?;
        self.pos += 1;
        parse_string_field(&item.text, max_string_bytes).map_err(|e| match e {
            Error::StringTooLong { .. } => e,
            _ => Error::BadData { line: item.line },
        })
    }
}

/// Split a DATA payload into fields on commas that are outside quotes.
///
/// A bare `DATA` statement has an empty payload and yields no items.  Empty
/// fields around commas are real empty items.
pub(crate) fn split_comma_fields(payload: &str) -> Vec<String> {
    if payload.trim().is_empty() {
        return Vec::new();
    }
    let mut fields = Vec::new();
    let mut current = String::new();
    let mut in_quote = false;
    for ch in payload.chars() {
        if ch == '"' {
            in_quote = !in_quote;
            current.push(ch);
        } else if ch == ',' && !in_quote {
            fields.push(current);
            current = String::new();
        } else {
            current.push(ch);
        }
    }
    fields.push(current);
    fields
}

/// Parse a complete numeric field as an exact integer or finite real.
pub(crate) fn parse_numeric_value_field(field: &str, mode: NumericMode) -> Result<Value, Error> {
    let trimmed = field.trim();
    if trimmed.is_empty() {
        let bi = BasicInteger::with_mode(mode, 0)?;
        return Ok(Value::Integer(bi.value()));
    }
    // Quoted fields are never valid numeric literals.
    if trimmed.starts_with('"') {
        return Err(Error::BadData { line: 0 });
    }
    let mut chars = trimmed.chars();
    let first = chars.next().ok_or(Error::BadData { line: 0 })?;
    if first != '+' && first != '-' && first != '.' && !first.is_ascii_digit() {
        return Err(Error::BadData { line: 0 });
    }
    if trimmed.contains(['.', 'e', 'E']) {
        return BasicReal::parse(trimmed)
            .map(Value::Real)
            .map_err(|_| Error::BadData { line: 0 });
    }
    if !chars.all(|c| c.is_ascii_digit()) {
        return Err(Error::BadData { line: 0 });
    }
    let value: i64 = trimmed.parse().map_err(|_| Error::BadData { line: 0 })?;
    let bi = BasicInteger::with_mode(mode, value)?;
    Ok(Value::Integer(bi.value()))
}

/// Parse a string DATA field, enforcing the byte limit.
pub(crate) fn parse_string_field(field: &str, max_string_bytes: usize) -> Result<String, Error> {
    let trimmed = field.trim();
    if trimmed.is_empty() {
        return Ok(String::new());
    }
    if let Some(quoted) = trimmed.strip_prefix('"') {
        // Quoted: find the matching closing quote and reject trailing garbage.
        let closing = quoted.find('"').ok_or(Error::BadData { line: 0 })?;
        if closing + 1 != quoted.len() {
            return Err(Error::BadData { line: 0 });
        }
        let content = &quoted[..closing];
        if content.len() > max_string_bytes {
            return Err(Error::StringTooLong {
                length: content.len(),
                limit: max_string_bytes,
            });
        }
        return Ok(content.to_string());
    }
    // A quote appearing anywhere in an unquoted field is malformed.  The
    // tokenizer deliberately preserves it so the error occurs only if READ
    // reaches this DATA item.
    if trimmed.contains('"') {
        return Err(Error::BadData { line: 0 });
    }
    if trimmed.len() > max_string_bytes {
        return Err(Error::StringTooLong {
            length: trimmed.len(),
            limit: max_string_bytes,
        });
    }
    Ok(trimmed.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bare_data_yields_no_items() {
        let mut p = Program::new();
        p.insert_line("10 DATA").unwrap();
        let cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(cursor.len(), 0);
    }

    #[test]
    fn whitespace_only_data_yields_no_items() {
        let mut p = Program::new();
        p.insert_line("10 DATA   ").unwrap();
        let cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(cursor.len(), 0);
    }

    #[test]
    fn payload_splits_on_commas_outside_quotes() {
        assert_eq!(
            split_comma_fields("1,\"2,3\",4"),
            vec!["1".to_string(), "\"2,3\"".to_string(), "4".to_string()]
        );
    }

    #[test]
    fn empty_fields_are_real_items() {
        assert_eq!(
            split_comma_fields(",,,"),
            vec![
                "".to_string(),
                "".to_string(),
                "".to_string(),
                "".to_string()
            ]
        );
        assert_eq!(
            split_comma_fields("1,,2"),
            vec!["1".to_string(), "".to_string(), "2".to_string()]
        );
    }

    #[test]
    fn quoted_colons_are_preserved() {
        let mut p = Program::new();
        p.insert_line("10 DATA \"A:B\",C").unwrap();
        let cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(cursor.len(), 2);
    }

    #[test]
    fn reset_replays_from_start() {
        let mut p = Program::new();
        p.insert_line("10 DATA 1,2").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), 1);
        cursor.reset();
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), 1);
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), 2);
        assert!(matches!(
            cursor.read_integer(NumericMode::Modern, 20).unwrap_err(),
            Error::OutOfData { line: 20 }
        ));
    }

    #[test]
    fn empty_numeric_field_reads_as_zero() {
        let mut p = Program::new();
        p.insert_line("10 DATA ,5").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), 0);
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), 5);
    }

    #[test]
    fn signed_base10_i64_is_accepted() {
        let mut p = Program::new();
        p.insert_line("10 DATA +42,-7,0,12345").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), 42);
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), -7);
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), 0);
        assert_eq!(cursor.read_integer(NumericMode::Modern, 20).unwrap(), 12345);
    }

    #[test]
    fn invalid_numeric_field_returns_bad_data() {
        let mut p = Program::new();
        p.insert_line("10 DATA \"123\",abc,+,.,1E").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        for _ in 0..5 {
            assert!(matches!(
                cursor.read_integer(NumericMode::Modern, 20).unwrap_err(),
                Error::BadData { line: 10 }
            ));
        }
    }

    #[test]
    fn decimal_and_exponent_fields_are_native_reals() {
        let mut p = Program::new();
        p.insert_line("10 DATA 1.5,-.25,1E2").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(
            cursor.read_numeric(NumericMode::Modern, 20).unwrap(),
            Value::real(1.5).unwrap()
        );
        assert_eq!(
            cursor.read_numeric(NumericMode::Modern, 20).unwrap(),
            Value::real(-0.25).unwrap()
        );
        assert_eq!(
            cursor.read_numeric(NumericMode::Modern, 20).unwrap(),
            Value::real(100.0).unwrap()
        );
    }

    #[test]
    fn legacy_numeric_out_of_range_is_bad_data() {
        let mut p = Program::new();
        p.insert_line("10 DATA 40000").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert!(matches!(
            cursor
                .read_integer(NumericMode::Legacy6502, 20)
                .unwrap_err(),
            Error::BadData { line: 10 }
        ));
    }

    #[test]
    fn string_item_trims_exterior_preserves_interior() {
        let mut p = Program::new();
        p.insert_line("10 DATA  hello world  ").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(cursor.read_string(255, 20).unwrap(), "hello world");
    }

    #[test]
    fn quoted_string_preserves_interior_whitespace() {
        let mut p = Program::new();
        p.insert_line("10 DATA \" hello \"").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert_eq!(cursor.read_string(255, 20).unwrap(), " hello ");
    }

    #[test]
    fn malformed_quoted_string_reports_bad_data() {
        let mut p = Program::new();
        p.insert_line("10 DATA \"unterminated").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert!(matches!(
            cursor.read_string(255, 20).unwrap_err(),
            Error::BadData { line: 10 }
        ));
    }

    #[test]
    fn quoted_string_with_trailing_garbage_is_bad_data() {
        let mut p = Program::new();
        p.insert_line("10 DATA \"A\"B").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert!(matches!(
            cursor.read_string(255, 20).unwrap_err(),
            Error::BadData { line: 10 }
        ));
    }

    #[test]
    fn quote_inside_unquoted_string_is_bad_data() {
        let mut p = Program::new();
        p.insert_line("10 DATA ABC\"DEF").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert!(matches!(
            cursor.read_string(255, 20).unwrap_err(),
            Error::BadData { line: 10 }
        ));
    }

    #[test]
    fn string_byte_limit_is_enforced() {
        let mut p = Program::new();
        p.insert_line("10 DATA ABCDE").unwrap();
        let mut cursor = DataCursor::from_program(&p, DEFAULT_MAX_DATA_ITEMS).unwrap();
        assert!(matches!(
            cursor.read_string(3, 20).unwrap_err(),
            Error::StringTooLong {
                length: 5,
                limit: 3
            }
        ));
    }

    #[test]
    fn data_limit_is_enforced() {
        let mut p = Program::new();
        p.insert_line("10 DATA 1,2,3,4,5").unwrap();
        let err = DataCursor::from_program(&p, 3).unwrap_err();
        assert!(matches!(err, Error::DataLimitExceeded { limit: 3 }));
    }
}
