use crate::error::Error;
use crate::value::Value;

use super::{expect_arity, finite_value, real_arg, value_list};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "DIST" => distance_2d(args),
        "DIST3D" => distance_3d(args),
        "ROTATE2D" => rotate_2d(args),
        "TOPOLAR" => to_polar(args),
        "TORECT" => to_rectangular(args),
        "AREACIRCLE" | "CIRCLEAREA" => circle_area(args),
        "AREAELLIPSE" | "ELLIPSEAREA" => ellipse_area(args),
        "AREARECT" | "RECTAREA" => rectangle_area(args),
        "AREATRIANGLE" | "TRIANGLEAREA" => triangle_area(args),
        "VOLUMESPHERE" | "SPHEREVOLUME" => sphere_volume(args),
        "VOLUMECYLINDER" | "CYLINDERVOLUME" => cylinder_volume(args),
        "VOLUMECONE" | "CONEVOLUME" => cone_volume(args),
        _ => Err(Error::syntax(format!("unknown geometry function {name}"))),
    }
}

fn distance_2d(args: &[Value]) -> Result<Value, Error> {
    expect_arity("DIST", args, 4, 4)?;
    let dx = real_arg(&args[2])? - real_arg(&args[0])?;
    let dy = real_arg(&args[3])? - real_arg(&args[1])?;
    finite_value(dx.hypot(dy))
}

fn distance_3d(args: &[Value]) -> Result<Value, Error> {
    expect_arity("DIST3D", args, 6, 6)?;
    let dx = real_arg(&args[3])? - real_arg(&args[0])?;
    let dy = real_arg(&args[4])? - real_arg(&args[1])?;
    let dz = real_arg(&args[5])? - real_arg(&args[2])?;
    finite_value(dx.hypot(dy).hypot(dz))
}

fn rotate_2d(args: &[Value]) -> Result<Value, Error> {
    expect_arity("ROTATE2D", args, 3, 3)?;
    let x = real_arg(&args[0])?;
    let y = real_arg(&args[1])?;
    let angle = real_arg(&args[2])?;
    let cosine = angle.cos();
    let sine = angle.sin();
    value_list([x * cosine - y * sine, x * sine + y * cosine])
}

fn to_polar(args: &[Value]) -> Result<Value, Error> {
    expect_arity("TOPOLAR", args, 2, 2)?;
    let x = real_arg(&args[0])?;
    let y = real_arg(&args[1])?;
    value_list([x.hypot(y), y.atan2(x)])
}

fn to_rectangular(args: &[Value]) -> Result<Value, Error> {
    expect_arity("TORECT", args, 2, 2)?;
    let radius = real_arg(&args[0])?;
    let angle = real_arg(&args[1])?;
    value_list([radius * angle.cos(), radius * angle.sin()])
}

fn circle_area(args: &[Value]) -> Result<Value, Error> {
    expect_arity("AREACIRCLE", args, 1, 1)?;
    let radius = nonnegative(real_arg(&args[0])?, "AREACIRCLE")?;
    finite_value(std::f64::consts::PI * radius * radius)
}

fn ellipse_area(args: &[Value]) -> Result<Value, Error> {
    expect_arity("AREAELLIPSE", args, 2, 2)?;
    let horizontal = nonnegative(real_arg(&args[0])?, "AREAELLIPSE")?;
    let vertical = nonnegative(real_arg(&args[1])?, "AREAELLIPSE")?;
    finite_value(std::f64::consts::PI * horizontal * vertical)
}

fn rectangle_area(args: &[Value]) -> Result<Value, Error> {
    expect_arity("AREARECT", args, 2, 2)?;
    finite_value(real_arg(&args[0])?.abs() * real_arg(&args[1])?.abs())
}

fn triangle_area(args: &[Value]) -> Result<Value, Error> {
    match args {
        [a, b, c] => {
            let a = nonnegative(real_arg(a)?, "AREATRIANGLE")?;
            let b = nonnegative(real_arg(b)?, "AREATRIANGLE")?;
            let c = nonnegative(real_arg(c)?, "AREATRIANGLE")?;
            if a + b < c || a + c < b || b + c < a {
                return Err(Error::MathDomain {
                    function: "AREATRIANGLE",
                });
            }
            let semiperimeter = (a + b + c) / 2.0;
            finite_value(
                (semiperimeter * (semiperimeter - a) * (semiperimeter - b) * (semiperimeter - c))
                    .max(0.0)
                    .sqrt(),
            )
        }
        [x1, y1, x2, y2, x3, y3] => {
            let x1 = real_arg(x1)?;
            let y1 = real_arg(y1)?;
            let x2 = real_arg(x2)?;
            let y2 = real_arg(y2)?;
            let x3 = real_arg(x3)?;
            let y3 = real_arg(y3)?;
            finite_value(((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0).abs())
        }
        _ => Err(Error::syntax(
            "AREATRIANGLE expects three side lengths or three x,y points",
        )),
    }
}

fn sphere_volume(args: &[Value]) -> Result<Value, Error> {
    expect_arity("VOLUMESPHERE", args, 1, 1)?;
    let radius = nonnegative(real_arg(&args[0])?, "VOLUMESPHERE")?;
    finite_value(4.0 * std::f64::consts::PI * radius.powi(3) / 3.0)
}

fn cylinder_volume(args: &[Value]) -> Result<Value, Error> {
    expect_arity("VOLUMECYLINDER", args, 2, 2)?;
    let radius = nonnegative(real_arg(&args[0])?, "VOLUMECYLINDER")?;
    let height = nonnegative(real_arg(&args[1])?, "VOLUMECYLINDER")?;
    finite_value(std::f64::consts::PI * radius * radius * height)
}

fn cone_volume(args: &[Value]) -> Result<Value, Error> {
    expect_arity("VOLUMECONE", args, 2, 2)?;
    let radius = nonnegative(real_arg(&args[0])?, "VOLUMECONE")?;
    let height = nonnegative(real_arg(&args[1])?, "VOLUMECONE")?;
    finite_value(std::f64::consts::PI * radius * radius * height / 3.0)
}

fn nonnegative(value: f64, function: &'static str) -> Result<f64, Error> {
    if value < 0.0 {
        Err(Error::MathDomain { function })
    } else {
        Ok(value)
    }
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    #[test]
    fn distance_3d_preserves_large_and_tiny_finite_distances() {
        for scale in [1.0e200, 1.0e-200] {
            let args = [0.0, 0.0, 0.0, 2.0 * scale, 3.0 * scale, 6.0 * scale]
                .map(|value| Value::real(value).unwrap());
            let result = evaluate("DIST3D", &args).unwrap();
            let actual = super::real_arg(&result).unwrap();
            assert!((actual / scale - 7.0).abs() < 1.0e-12);
        }
    }

    #[test]
    fn geometry_uses_radians_and_checked_dimensions() {
        assert_eq!(
            evaluate(
                "DIST",
                &[
                    Value::Integer(0),
                    Value::Integer(0),
                    Value::Integer(3),
                    Value::Integer(4),
                ],
            )
            .unwrap()
            .to_string(),
            "5"
        );
        assert!(evaluate("AREACIRCLE", &[Value::Integer(-1)]).is_err());
    }
}
