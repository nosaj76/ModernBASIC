use crate::error::Error;
use crate::value::Value;

use super::{expect_arity, finite_value, real_arg};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "FLOOR" => unary_round("FLOOR", args, f64::floor),
        "CEIL" | "CEILING" => unary_round("CEIL", args, f64::ceil),
        "TRUNC" => unary_round("TRUNC", args, f64::trunc),
        "ATAN2" => binary("ATAN2", args, |y, x| y.atan2(x)),
        "HYPOT" => binary("HYPOT", args, f64::hypot),
        "SEC" => reciprocal_trig("SEC", args, f64::cos),
        "CSC" => reciprocal_trig("CSC", args, f64::sin),
        "COT" => reciprocal_trig("COT", args, f64::tan),
        "SECH" => reciprocal_trig("SECH", args, f64::cosh),
        "CSCH" => reciprocal_trig("CSCH", args, f64::sinh),
        "COTH" => reciprocal_trig("COTH", args, f64::tanh),
        "EXP2" => unary("EXP2", args, f64::exp2),
        "EXP10" => unary("EXP10", args, |value| 10.0_f64.powf(value)),
        "EXPM1" => unary("EXPM1", args, f64::exp_m1),
        "LOG2" => domain_unary("LOG2", args, |value| value > 0.0, f64::log2),
        "LOG1P" => domain_unary("LOG1P", args, |value| value > -1.0, f64::ln_1p),
        "POW" => power(args),
        "CLAMP" => clamp(args),
        "LERP" => lerp(args),
        "SMOOTHSTEP" => smoothstep(args),
        "WRAP" => wrap(args),
        "MAPRANGE" => map_range(args),
        _ => Err(Error::syntax(format!("unknown scalar function {name}"))),
    }
}

fn unary_round(
    name: &'static str,
    args: &[Value],
    operation: fn(f64) -> f64,
) -> Result<Value, Error> {
    expect_arity(name, args, 1, 1)?;
    if let Value::Integer(value) = args[0] {
        return Ok(Value::Integer(value));
    }
    finite_value(operation(real_arg(&args[0])?))
}

fn unary(name: &'static str, args: &[Value], operation: fn(f64) -> f64) -> Result<Value, Error> {
    expect_arity(name, args, 1, 1)?;
    finite_value(operation(real_arg(&args[0])?))
}

fn domain_unary(
    name: &'static str,
    args: &[Value],
    domain: fn(f64) -> bool,
    operation: fn(f64) -> f64,
) -> Result<Value, Error> {
    expect_arity(name, args, 1, 1)?;
    let value = real_arg(&args[0])?;
    if !domain(value) {
        return Err(Error::MathDomain { function: name });
    }
    finite_value(operation(value))
}

fn binary(
    name: &'static str,
    args: &[Value],
    operation: fn(f64, f64) -> f64,
) -> Result<Value, Error> {
    expect_arity(name, args, 2, 2)?;
    finite_value(operation(real_arg(&args[0])?, real_arg(&args[1])?))
}

fn reciprocal_trig(
    name: &'static str,
    args: &[Value],
    operation: fn(f64) -> f64,
) -> Result<Value, Error> {
    expect_arity(name, args, 1, 1)?;
    let denominator = operation(real_arg(&args[0])?);
    if denominator == 0.0 {
        return Err(Error::DivideByZero);
    }
    finite_value(1.0 / denominator)
}

fn power(args: &[Value]) -> Result<Value, Error> {
    expect_arity("POW", args, 2, 2)?;
    let base = real_arg(&args[0])?;
    let exponent = real_arg(&args[1])?;
    if base == 0.0 && exponent < 0.0 {
        return Err(Error::DivideByZero);
    }
    if base < 0.0 && exponent.fract() != 0.0 {
        return Err(Error::MathDomain { function: "POW" });
    }
    finite_value(base.powf(exponent))
}

fn clamp(args: &[Value]) -> Result<Value, Error> {
    expect_arity("CLAMP", args, 3, 3)?;
    let value = real_arg(&args[0])?;
    let minimum = real_arg(&args[1])?;
    let maximum = real_arg(&args[2])?;
    if minimum > maximum {
        return Err(Error::IllegalQuantity);
    }
    finite_value(value.clamp(minimum, maximum))
}

fn lerp(args: &[Value]) -> Result<Value, Error> {
    expect_arity("LERP", args, 3, 3)?;
    let start = real_arg(&args[0])?;
    let end = real_arg(&args[1])?;
    let amount = real_arg(&args[2])?;
    finite_value(start + (end - start) * amount)
}

fn smoothstep(args: &[Value]) -> Result<Value, Error> {
    expect_arity("SMOOTHSTEP", args, 3, 3)?;
    let edge0 = real_arg(&args[0])?;
    let edge1 = real_arg(&args[1])?;
    let value = real_arg(&args[2])?;
    if edge0 == edge1 {
        return Err(Error::DivideByZero);
    }
    let amount = ((value - edge0) / (edge1 - edge0)).clamp(0.0, 1.0);
    finite_value(amount * amount * (3.0 - 2.0 * amount))
}

fn wrap(args: &[Value]) -> Result<Value, Error> {
    expect_arity("WRAP", args, 3, 3)?;
    let value = real_arg(&args[0])?;
    let minimum = real_arg(&args[1])?;
    let maximum = real_arg(&args[2])?;
    let width = maximum - minimum;
    if width <= 0.0 {
        return Err(Error::IllegalQuantity);
    }
    let wrapped = (value - minimum).rem_euclid(width) + minimum;
    finite_value(wrapped)
}

fn map_range(args: &[Value]) -> Result<Value, Error> {
    expect_arity("MAPRANGE", args, 5, 5)?;
    let value = real_arg(&args[0])?;
    let input_minimum = real_arg(&args[1])?;
    let input_maximum = real_arg(&args[2])?;
    let output_minimum = real_arg(&args[3])?;
    let output_maximum = real_arg(&args[4])?;
    if input_minimum == input_maximum {
        return Err(Error::DivideByZero);
    }
    let amount = (value - input_minimum) / (input_maximum - input_minimum);
    finite_value(output_minimum + amount * (output_maximum - output_minimum))
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    #[test]
    fn scalar_helpers_are_checked() {
        assert_eq!(
            evaluate(
                "CLAMP",
                &[Value::Integer(12), Value::Integer(0), Value::Integer(10)]
            )
            .unwrap()
            .to_string(),
            "10"
        );
        assert!(evaluate("LOG2", &[Value::Integer(0)]).is_err());
        assert!(evaluate("LOG1P", &[Value::Integer(-1)]).is_err());
        assert_eq!(
            evaluate("LOG1P", &[Value::Integer(0)]).unwrap().to_string(),
            "0"
        );
    }
}
