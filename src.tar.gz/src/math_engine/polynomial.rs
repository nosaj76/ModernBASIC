use crate::complex::BasicComplex;
use crate::error::Error;
use crate::value::Value;

use super::{
    checked_element_count, checked_operations, expect_arity, finite_value, nonnegative_usize,
    real_arg, real_list, value_list, MAX_LIST_ELEMENTS,
};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "POLYEVAL" => polynomial_evaluate(args),
        "POLYADD" => polynomial_binary(args, false, false),
        "POLYSUB" => polynomial_binary(args, true, false),
        "POLYMUL" => polynomial_binary(args, false, true),
        "POLYDERIV" => derivative(args),
        "POLYINT" => integral(args),
        "QUADRATIC" => quadratic(args),
        "POLYFIT" => polynomial_fit(args),
        _ => Err(Error::syntax(format!("unknown polynomial function {name}"))),
    }
}

fn polynomial_evaluate(args: &[Value]) -> Result<Value, Error> {
    expect_arity("POLYEVAL", args, 2, 2)?;
    let coefficients = real_list(&args[0])?;
    if coefficients.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    let x = real_arg(&args[1])?;
    let mut result = 0.0;
    for coefficient in coefficients {
        result = result * x + coefficient;
        if !result.is_finite() {
            return Err(Error::RealOverflow);
        }
    }
    finite_value(result)
}

fn polynomial_binary(args: &[Value], subtract: bool, multiply: bool) -> Result<Value, Error> {
    let name = if multiply {
        "POLYMUL"
    } else if subtract {
        "POLYSUB"
    } else {
        "POLYADD"
    };
    expect_arity(name, args, 2, 2)?;
    let left = real_list(&args[0])?;
    let right = real_list(&args[1])?;
    if left.is_empty() || right.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    if multiply {
        let length = left
            .len()
            .checked_add(right.len())
            .and_then(|value| value.checked_sub(1))
            .ok_or(Error::ArrayTooLarge)?;
        checked_element_count(length, MAX_LIST_ELEMENTS)?;
        checked_operations(
            left.len()
                .checked_mul(right.len())
                .ok_or(Error::ArrayTooLarge)?,
        )?;
        let mut result = vec![0.0; length];
        for (left_index, left_value) in left.iter().enumerate() {
            for (right_index, right_value) in right.iter().enumerate() {
                result[left_index + right_index] += left_value * right_value;
            }
        }
        return value_list(result);
    }

    let length = left.len().max(right.len());
    let left_offset = length - left.len();
    let right_offset = length - right.len();
    let mut result = vec![0.0; length];
    for (index, value) in left.into_iter().enumerate() {
        result[left_offset + index] += value;
    }
    for (index, value) in right.into_iter().enumerate() {
        if subtract {
            result[right_offset + index] -= value;
        } else {
            result[right_offset + index] += value;
        }
    }
    value_list(trim_leading_zeroes(result))
}

fn derivative(args: &[Value]) -> Result<Value, Error> {
    expect_arity("POLYDERIV", args, 1, 1)?;
    let coefficients = real_list(&args[0])?;
    if coefficients.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    if coefficients.len() == 1 {
        return value_list([0.0]);
    }
    let degree = coefficients.len() - 1;
    value_list(
        coefficients
            .into_iter()
            .take(degree)
            .enumerate()
            .map(|(index, coefficient)| coefficient * (degree - index) as f64),
    )
}

fn integral(args: &[Value]) -> Result<Value, Error> {
    expect_arity("POLYINT", args, 1, 2)?;
    let coefficients = real_list(&args[0])?;
    if coefficients.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    let constant = args.get(1).map(real_arg).transpose()?.unwrap_or(0.0);
    let degree = coefficients.len();
    let mut result = coefficients
        .into_iter()
        .enumerate()
        .map(|(index, coefficient)| coefficient / (degree - index) as f64)
        .collect::<Vec<_>>();
    result.push(constant);
    value_list(result)
}

fn quadratic(args: &[Value]) -> Result<Value, Error> {
    expect_arity("QUADRATIC", args, 3, 3)?;
    let a = real_arg(&args[0])?;
    let b = real_arg(&args[1])?;
    let c = real_arg(&args[2])?;
    if a == 0.0 {
        if b == 0.0 {
            return Err(Error::MathDomain {
                function: "QUADRATIC",
            });
        }
        return Ok(Value::List(vec![finite_value(-c / b)?]));
    }
    let discriminant = b * b - 4.0 * a * c;
    if discriminant >= 0.0 {
        let square_root = discriminant.sqrt();
        // Stable form avoids catastrophic cancellation for one root.
        let q = -0.5 * (b + b.signum() * square_root);
        let first = if q == 0.0 { -b / (2.0 * a) } else { q / a };
        let second = if q == 0.0 { first } else { c / q };
        Ok(Value::List(vec![
            finite_value(first)?,
            finite_value(second)?,
        ]))
    } else {
        let real = -b / (2.0 * a);
        let imaginary = (-discriminant).sqrt() / (2.0 * a.abs());
        Ok(Value::List(vec![
            Value::Complex(BasicComplex::new(real, imaginary)?),
            Value::Complex(BasicComplex::new(real, -imaginary)?),
        ]))
    }
}

fn polynomial_fit(args: &[Value]) -> Result<Value, Error> {
    expect_arity("POLYFIT", args, 3, 3)?;
    let x = real_list(&args[0])?;
    let y = real_list(&args[1])?;
    let degree = nonnegative_usize(&args[2])?;
    if x.len() != y.len() || x.is_empty() || degree >= x.len() {
        return Err(Error::IllegalQuantity);
    }
    let terms = degree + 1;
    checked_operations(
        x.len()
            .checked_mul(terms)
            .and_then(|value| value.checked_mul(terms))
            .ok_or(Error::ArrayTooLarge)?,
    )?;

    // Normal equations in ascending-power order.
    let mut normal = vec![vec![0.0; terms]; terms];
    let mut right = vec![0.0; terms];
    for (&x_value, &y_value) in x.iter().zip(&y) {
        let mut powers = vec![1.0; terms * 2 - 1];
        for index in 1..powers.len() {
            powers[index] = powers[index - 1] * x_value;
        }
        for row in 0..terms {
            right[row] += y_value * powers[row];
            for column in 0..terms {
                normal[row][column] += powers[row + column];
            }
        }
    }
    let mut coefficients = super::linalg::solve_linear(normal, right)?;
    coefficients.reverse();
    value_list(coefficients)
}

fn trim_leading_zeroes(values: Vec<f64>) -> Vec<f64> {
    let first_nonzero = values
        .iter()
        .position(|value| *value != 0.0)
        .unwrap_or(values.len().saturating_sub(1));
    values[first_nonzero..].to_vec()
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    fn list(values: &[i64]) -> Value {
        Value::List(values.iter().copied().map(Value::Integer).collect())
    }

    #[test]
    fn polynomial_operations_use_highest_degree_first() {
        assert_eq!(
            evaluate("POLYEVAL", &[list(&[1, 0, -1]), Value::Integer(3)])
                .unwrap()
                .to_string(),
            "8"
        );
        assert_eq!(
            evaluate("POLYDERIV", &[list(&[3, 2, 1])])
                .unwrap()
                .to_string(),
            "{6,2}"
        );
    }
}
