use crate::complex::BasicComplex;
use crate::error::Error;
use crate::value::Value;

use super::{
    checked_element_count, checked_operations, complex_arg, expect_arity, finite_value,
    nonnegative_usize, real_list, value_list, MAX_LIST_ELEMENTS, MAX_MATH_OPERATIONS,
};

#[derive(Debug, Clone, Copy)]
struct ComplexPair {
    real: f64,
    imaginary: f64,
}

impl ComplexPair {
    fn add(self, right: Self) -> Self {
        Self {
            real: self.real + right.real,
            imaginary: self.imaginary + right.imaginary,
        }
    }

    fn sub(self, right: Self) -> Self {
        Self {
            real: self.real - right.real,
            imaginary: self.imaginary - right.imaginary,
        }
    }

    fn mul(self, right: Self) -> Self {
        Self {
            real: self.real * right.real - self.imaginary * right.imaginary,
            imaginary: self.real * right.imaginary + self.imaginary * right.real,
        }
    }
}

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "FFT" => transform_function(args, false),
        "IFFT" => transform_function(args, true),
        "CONVOLVE" => convolve(args),
        "AUTOCORR" => autocorrelation(args),
        "XCORR" => cross_correlation(args),
        "HANN" | "HANNING" => window(args, Window::Hann),
        "HAMMING" => window(args, Window::Hamming),
        "BLACKMAN" => window(args, Window::Blackman),
        "ZCR" => zero_crossing_rate(args),
        "RESAMPLE" => resample(args),
        "PITCH" => pitch(args),
        "MIDINOTE" => midi_note(args),
        "NOTEFREQ" => note_frequency(args),
        "NOTECENTS" => note_cents(args),
        "NOTENAME" => note_name(args),
        _ => Err(Error::syntax(format!("unknown signal function {name}"))),
    }
}

fn transform_function(args: &[Value], inverse: bool) -> Result<Value, Error> {
    let name = if inverse { "IFFT" } else { "FFT" };
    expect_arity(name, args, 1, 1)?;
    let Value::List(values) = &args[0] else {
        return Err(Error::TypeMismatch);
    };
    let length = values.len();
    if length == 0 || !length.is_power_of_two() {
        return Err(Error::IllegalQuantity);
    }
    checked_element_count(length, MAX_LIST_ELEMENTS)?;
    checked_operations(length.saturating_mul(length.trailing_zeros() as usize + 1))?;
    let mut values = values
        .iter()
        .map(complex_arg)
        .map(|value| {
            value.map(|value| ComplexPair {
                real: value.real().value(),
                imaginary: value.imaginary().value(),
            })
        })
        .collect::<Result<Vec<_>, _>>()?;
    fft_in_place(&mut values, inverse);
    let output = values
        .into_iter()
        .map(|value| BasicComplex::new(value.real, value.imaginary).map(Value::Complex))
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Value::List(output))
}

fn fft_in_place(values: &mut [ComplexPair], inverse: bool) {
    let length = values.len();
    let mut reversed = 0_usize;
    for index in 1..length {
        let mut bit = length >> 1;
        while reversed & bit != 0 {
            reversed ^= bit;
            bit >>= 1;
        }
        reversed ^= bit;
        if index < reversed {
            values.swap(index, reversed);
        }
    }

    let direction = if inverse { 1.0 } else { -1.0 };
    let mut block = 2;
    while block <= length {
        let angle = direction * 2.0 * std::f64::consts::PI / block as f64;
        let root = ComplexPair {
            real: angle.cos(),
            imaginary: angle.sin(),
        };
        for start in (0..length).step_by(block) {
            let mut factor = ComplexPair {
                real: 1.0,
                imaginary: 0.0,
            };
            for offset in 0..block / 2 {
                let even = values[start + offset];
                let odd = values[start + offset + block / 2].mul(factor);
                values[start + offset] = even.add(odd);
                values[start + offset + block / 2] = even.sub(odd);
                factor = factor.mul(root);
            }
        }
        block <<= 1;
    }

    if inverse {
        let scale = length as f64;
        for value in values {
            value.real /= scale;
            value.imaginary /= scale;
        }
    }
}

fn convolve(args: &[Value]) -> Result<Value, Error> {
    expect_arity("CONVOLVE", args, 2, 2)?;
    let left = real_list(&args[0])?;
    let right = real_list(&args[1])?;
    if left.is_empty() || right.is_empty() {
        return Ok(Value::List(Vec::new()));
    }
    let length = left
        .len()
        .checked_add(right.len())
        .and_then(|value| value.checked_sub(1))
        .ok_or(Error::ArrayTooLarge)?;
    checked_element_count(length, MAX_LIST_ELEMENTS)?;
    checked_operations(
        left.len()
            .checked_mul(right.len())
            .ok_or(Error::ArrayTooLarge)?,
    )?;
    let mut result = vec![0.0; length];
    for (left_index, left_value) in left.iter().enumerate() {
        for (right_index, right_value) in right.iter().enumerate() {
            result[left_index + right_index] += left_value * right_value;
        }
    }
    value_list(result)
}

fn autocorrelation(args: &[Value]) -> Result<Value, Error> {
    expect_arity("AUTOCORR", args, 1, 2)?;
    let values = real_list(&args[0])?;
    let requested_lag = args.get(1).map(nonnegative_usize).transpose()?;
    if values.is_empty() {
        return if requested_lag.is_none() {
            Ok(Value::List(Vec::new()))
        } else {
            Err(Error::IllegalQuantity)
        };
    }

    let maximum_lag = requested_lag.unwrap_or(values.len() - 1);
    if maximum_lag >= values.len() {
        return Err(Error::IllegalQuantity);
    }
    let output_length = maximum_lag
        .checked_mul(2)
        .and_then(|value| value.checked_add(1))
        .ok_or(Error::ArrayTooLarge)?;
    checked_element_count(output_length, MAX_LIST_ELEMENTS)?;

    // At lag k there are n-k products. Account for both positive and
    // negative lags before doing any work so the usual math-operation bound
    // also applies to explicitly requested windows.
    let triangular = maximum_lag
        .checked_mul(maximum_lag + 1)
        .and_then(|value| value.checked_div(2))
        .ok_or(Error::ArrayTooLarge)?;
    let one_side = maximum_lag
        .checked_mul(values.len())
        .and_then(|value| value.checked_sub(triangular))
        .ok_or(Error::ArrayTooLarge)?;
    let operations = one_side
        .checked_mul(2)
        .and_then(|value| value.checked_add(values.len()))
        .ok_or(Error::ArrayTooLarge)?;
    checked_operations(operations)?;

    let maximum_lag = maximum_lag as isize;
    let mut result = Vec::with_capacity(output_length);
    for lag in -maximum_lag..=maximum_lag {
        let mut sum = 0.0;
        for (left_index, left_value) in values.iter().enumerate() {
            let right_index = left_index as isize - lag;
            if (0..values.len() as isize).contains(&right_index) {
                sum += left_value * values[right_index as usize];
            }
        }
        result.push(sum);
    }
    value_list(result)
}

fn cross_correlation(args: &[Value]) -> Result<Value, Error> {
    expect_arity("XCORR", args, 2, 2)?;
    cross_correlation_values(real_list(&args[0])?, real_list(&args[1])?)
}

fn cross_correlation_values(left: Vec<f64>, right: Vec<f64>) -> Result<Value, Error> {
    if left.is_empty() || right.is_empty() {
        return Ok(Value::List(Vec::new()));
    }
    let length = left
        .len()
        .checked_add(right.len())
        .and_then(|value| value.checked_sub(1))
        .ok_or(Error::ArrayTooLarge)?;
    checked_element_count(length, MAX_LIST_ELEMENTS)?;
    checked_operations(
        left.len()
            .checked_mul(right.len())
            .ok_or(Error::ArrayTooLarge)?,
    )?;
    let minimum_lag = -(right.len() as isize - 1);
    let maximum_lag = left.len() as isize - 1;
    let mut result = Vec::with_capacity(length);
    for lag in minimum_lag..=maximum_lag {
        let mut sum = 0.0;
        for (left_index, left_value) in left.iter().enumerate() {
            let right_index = left_index as isize - lag;
            if (0..right.len() as isize).contains(&right_index) {
                sum += left_value * right[right_index as usize];
            }
        }
        result.push(sum);
    }
    value_list(result)
}

#[derive(Debug, Clone, Copy)]
enum Window {
    Hann,
    Hamming,
    Blackman,
}

fn window(args: &[Value], window: Window) -> Result<Value, Error> {
    let name = match window {
        Window::Hann => "HANN",
        Window::Hamming => "HAMMING",
        Window::Blackman => "BLACKMAN",
    };
    expect_arity(name, args, 1, 1)?;
    let count = nonnegative_usize(&args[0])?;
    checked_element_count(count, MAX_LIST_ELEMENTS)?;
    if count == 0 {
        return Ok(Value::List(Vec::new()));
    }
    if count == 1 {
        return value_list([1.0]);
    }
    let denominator = (count - 1) as f64;
    value_list((0..count).map(|index| {
        let phase = 2.0 * std::f64::consts::PI * index as f64 / denominator;
        match window {
            Window::Hann => 0.5 - 0.5 * phase.cos(),
            Window::Hamming => 0.54 - 0.46 * phase.cos(),
            Window::Blackman => 0.42 - 0.5 * phase.cos() + 0.08 * (2.0 * phase).cos(),
        }
    }))
}

fn zero_crossing_rate(args: &[Value]) -> Result<Value, Error> {
    expect_arity("ZCR", args, 1, 1)?;
    let values = real_list(&args[0])?;
    if values.len() < 2 {
        return finite_value(0.0);
    }
    let crossings = values
        .windows(2)
        .filter(|pair| (pair[0] < 0.0 && pair[1] >= 0.0) || (pair[0] >= 0.0 && pair[1] < 0.0))
        .count();
    finite_value(crossings as f64 / (values.len() - 1) as f64)
}

fn resample(args: &[Value]) -> Result<Value, Error> {
    expect_arity("RESAMPLE", args, 2, 2)?;
    let values = real_list(&args[0])?;
    let count = nonnegative_usize(&args[1])?;
    checked_element_count(count, MAX_LIST_ELEMENTS)?;
    if count == 0 || values.is_empty() {
        return Ok(Value::List(Vec::new()));
    }
    if count == 1 || values.len() == 1 {
        return value_list(std::iter::repeat(values[0]).take(count));
    }
    let source_maximum = (values.len() - 1) as f64;
    let target_maximum = (count - 1) as f64;
    value_list((0..count).map(|index| {
        let position = index as f64 * source_maximum / target_maximum;
        let lower = position.floor() as usize;
        let upper = position.ceil() as usize;
        if lower == upper {
            values[lower]
        } else {
            let amount = position - lower as f64;
            values[lower] + (values[upper] - values[lower]) * amount
        }
    }))
}

fn pitch(args: &[Value]) -> Result<Value, Error> {
    expect_arity("PITCH", args, 2, 4)?;
    let input = real_list(&args[0])?;
    let sample_rate = super::real_arg(&args[1])?;
    if sample_rate <= 0.0 || input.len() < 4 {
        return if sample_rate <= 0.0 {
            Err(Error::IllegalQuantity)
        } else {
            finite_value(0.0)
        };
    }
    let minimum_hz = if args.len() > 2 {
        super::real_arg(&args[2])?
    } else {
        20.0_f64.min(sample_rate / 4.0)
    };
    let maximum_hz = if args.len() > 3 {
        super::real_arg(&args[3])?
    } else {
        (sample_rate / 2.0).min(5_000.0)
    };
    if minimum_hz <= 0.0 || maximum_hz <= minimum_hz || maximum_hz > sample_rate / 2.0 {
        return Err(Error::IllegalQuantity);
    }

    let minimum_lag = (sample_rate / maximum_hz).floor().max(2.0) as usize;
    let maximum_lag =
        ((sample_rate / minimum_hz).ceil() as usize).min(input.len().saturating_sub(2));
    if minimum_lag > maximum_lag {
        return finite_value(0.0);
    }
    let frame_limit = (MAX_MATH_OPERATIONS / maximum_lag.max(1)).max(maximum_lag + 2);
    let frame_length = input
        .len()
        .min(maximum_lag.saturating_mul(3).max(1_024))
        .min(frame_limit);
    if frame_length <= maximum_lag + 1 {
        return finite_value(0.0);
    }
    checked_operations(frame_length.saturating_mul(maximum_lag))?;

    let hop = (frame_length / 2).max(1);
    let mut frame_start = 0;
    let mut best_energy = -1.0;
    for start in (0..=input.len() - frame_length).step_by(hop) {
        let energy = input[start..start + frame_length]
            .iter()
            .map(|sample| sample * sample)
            .sum::<f64>();
        if energy > best_energy {
            best_energy = energy;
            frame_start = start;
        }
    }
    let frame = &input[frame_start..frame_start + frame_length];
    let mean = frame.iter().sum::<f64>() / frame.len() as f64;
    let rms = (frame
        .iter()
        .map(|sample| (sample - mean).powi(2))
        .sum::<f64>()
        / frame.len() as f64)
        .sqrt();
    if rms <= 1.0e-12 {
        return finite_value(0.0);
    }

    let mut difference = vec![0.0; maximum_lag + 1];
    for lag in 1..=maximum_lag {
        difference[lag] = (0..frame.len() - lag)
            .map(|index| {
                let delta = frame[index] - frame[index + lag];
                delta * delta
            })
            .sum();
    }
    let mut normalized = vec![1.0; maximum_lag + 1];
    let mut running_sum = 0.0;
    for lag in 1..=maximum_lag {
        running_sum += difference[lag];
        if running_sum > 0.0 {
            normalized[lag] = difference[lag] * lag as f64 / running_sum;
        }
    }

    let mut selected = None;
    let mut lag = minimum_lag;
    while lag <= maximum_lag {
        if normalized[lag] < 0.15 {
            while lag < maximum_lag && normalized[lag + 1] < normalized[lag] {
                lag += 1;
            }
            selected = Some(lag);
            break;
        }
        lag += 1;
    }
    let selected = selected.unwrap_or_else(|| {
        (minimum_lag..=maximum_lag)
            .min_by(|left, right| normalized[*left].total_cmp(&normalized[*right]))
            .unwrap_or(minimum_lag)
    });
    if normalized[selected] > 0.5 {
        return finite_value(0.0);
    }
    let refined = if selected > minimum_lag && selected < maximum_lag {
        let left = normalized[selected - 1];
        let center = normalized[selected];
        let right = normalized[selected + 1];
        let denominator = left - 2.0 * center + right;
        if denominator.abs() > f64::EPSILON {
            selected as f64 + 0.5 * (left - right) / denominator
        } else {
            selected as f64
        }
    } else {
        selected as f64
    };
    finite_value(sample_rate / refined)
}

fn midi_note(args: &[Value]) -> Result<Value, Error> {
    expect_arity("MIDINOTE", args, 1, 1)?;
    let frequency = super::real_arg(&args[0])?;
    if frequency <= 0.0 {
        return Err(Error::IllegalQuantity);
    }
    let note = (69.0 + 12.0 * (frequency / 440.0).log2()).round();
    if !(0.0..=127.0).contains(&note) {
        return Err(Error::IllegalQuantity);
    }
    Ok(Value::Integer(note as i64))
}

fn note_frequency(args: &[Value]) -> Result<Value, Error> {
    expect_arity("NOTEFREQ", args, 1, 1)?;
    let note = super::integer_arg(&args[0])?;
    if !(0..=127).contains(&note) {
        return Err(Error::IllegalQuantity);
    }
    finite_value(440.0 * 2.0_f64.powf((note as f64 - 69.0) / 12.0))
}

fn note_cents(args: &[Value]) -> Result<Value, Error> {
    expect_arity("NOTECENTS", args, 1, 1)?;
    let frequency = super::real_arg(&args[0])?;
    if frequency <= 0.0 {
        return Err(Error::IllegalQuantity);
    }
    let exact = 69.0 + 12.0 * (frequency / 440.0).log2();
    finite_value((exact - exact.round()) * 100.0)
}

fn note_name(args: &[Value]) -> Result<Value, Error> {
    expect_arity("NOTENAME", args, 1, 1)?;
    let Value::Integer(note) = midi_note(args)? else {
        unreachable!("MIDINOTE returns an integer");
    };
    const NAMES: [&str; 12] = [
        "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B",
    ];
    let pitch_class = note.rem_euclid(12) as usize;
    Ok(Value::String(format!(
        "{}{}",
        NAMES[pitch_class],
        note / 12 - 1
    )))
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::error::Error;
    use crate::value::Value;

    #[test]
    fn fft_and_convolution_return_basic_lists() {
        let impulse = Value::List(vec![
            Value::Integer(1),
            Value::Integer(0),
            Value::Integer(0),
            Value::Integer(0),
        ]);
        let transformed = evaluate("FFT", &[impulse]).unwrap();
        let Value::List(values) = transformed else {
            panic!("expected FFT list");
        };
        assert_eq!(values.len(), 4);

        let convolution = evaluate(
            "CONVOLVE",
            &[
                Value::List(vec![Value::Integer(1), Value::Integer(2)]),
                Value::List(vec![Value::Integer(1), Value::Integer(1)]),
            ],
        )
        .unwrap();
        assert_eq!(convolution.to_string(), "{1,3,2}");
    }

    #[test]
    fn autocorrelation_accepts_an_optional_symmetric_maximum_lag() {
        let data = Value::List((1..=5).map(Value::Integer).collect());
        assert_eq!(
            evaluate("AUTOCORR", std::slice::from_ref(&data))
                .unwrap()
                .to_string(),
            "{5,14,26,40,55,40,26,14,5}"
        );
        assert_eq!(
            evaluate("AUTOCORR", &[data.clone(), Value::Integer(2)])
                .unwrap()
                .to_string(),
            "{26,40,55,40,26}"
        );
        assert_eq!(
            evaluate("AUTOCORR", &[data.clone(), Value::Integer(0)])
                .unwrap()
                .to_string(),
            "{55}"
        );
        assert_eq!(
            evaluate("AUTOCORR", &[data, Value::Integer(5)]).unwrap_err(),
            Error::IllegalQuantity
        );
    }

    #[test]
    fn pitch_identifies_a440_and_note_conversions() {
        let sample_rate = 8_000;
        let samples = (0..4_000)
            .map(|index| {
                let phase = 2.0 * std::f64::consts::PI * 440.0 * index as f64 / sample_rate as f64;
                Value::real(phase.sin()).unwrap()
            })
            .collect();
        let result = evaluate(
            "PITCH",
            &[Value::List(samples), Value::Integer(sample_rate)],
        )
        .unwrap();
        let Value::Real(frequency) = result else {
            panic!("expected frequency");
        };
        assert!((frequency.value() - 440.0).abs() < 1.0);
        assert_eq!(
            evaluate("MIDINOTE", &[Value::real(440.0).unwrap()]).unwrap(),
            Value::Integer(69)
        );
        assert_eq!(
            evaluate("NOTENAME", &[Value::real(440.0).unwrap()]).unwrap(),
            Value::String("A4".to_string())
        );
        let Value::Real(cents) = evaluate("NOTECENTS", &[Value::real(440.0).unwrap()]).unwrap()
        else {
            panic!("expected cents");
        };
        assert!(cents.value().abs() < 1.0e-9);
    }

    #[test]
    fn pitch_returns_zero_for_silence() {
        let silence = Value::List(vec![Value::Integer(0); 2_048]);
        assert_eq!(
            evaluate("PITCH", &[silence, Value::Integer(8_000)])
                .unwrap()
                .to_string(),
            "0"
        );
    }
}
