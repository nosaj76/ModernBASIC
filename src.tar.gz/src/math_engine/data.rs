use crate::error::Error;
use crate::value::Value;

use super::{
    checked_element_count, expect_arity, finite_value, nonnegative_usize, real_arg, real_list,
    value_list, MAX_LIST_ELEMENTS,
};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "LINSPACE" => linspace(args),
        "ARANGE" => arange(args),
        "CUMSUM" => cumulative(args, false),
        "CUMPROD" => cumulative(args, true),
        "DIFF" => difference(args),
        "SORT" => sort(args),
        "REVERSE" => reverse(args),
        "UNIQUE" => unique(args),
        "HISTOGRAM" => histogram(args),
        _ => Err(Error::syntax(format!("unknown data function {name}"))),
    }
}

fn linspace(args: &[Value]) -> Result<Value, Error> {
    expect_arity("LINSPACE", args, 3, 3)?;
    let start = real_arg(&args[0])?;
    let stop = real_arg(&args[1])?;
    let count = nonnegative_usize(&args[2])?;
    checked_element_count(count, MAX_LIST_ELEMENTS)?;
    if count == 0 {
        return Ok(Value::List(Vec::new()));
    }
    if count == 1 {
        return value_list([start]);
    }
    let denominator = (count - 1) as f64;
    value_list((0..count).map(|index| start + (stop - start) * index as f64 / denominator))
}

fn arange(args: &[Value]) -> Result<Value, Error> {
    expect_arity("ARANGE", args, 1, 3)?;
    let (start, stop, step) = match args {
        [stop] => (0.0, real_arg(stop)?, 1.0),
        [start, stop] => (real_arg(start)?, real_arg(stop)?, 1.0),
        [start, stop, step] => (real_arg(start)?, real_arg(stop)?, real_arg(step)?),
        _ => unreachable!(),
    };
    if step == 0.0 {
        return Err(Error::DivideByZero);
    }
    if (stop > start && step < 0.0) || (stop < start && step > 0.0) {
        return Err(Error::IllegalQuantity);
    }
    if start == stop {
        return Ok(Value::List(Vec::new()));
    }
    let raw_count = ((stop - start) / step).ceil().max(0.0);
    if !raw_count.is_finite() || raw_count > MAX_LIST_ELEMENTS as f64 {
        return Err(Error::ArrayTooLarge);
    }
    let count = raw_count as usize;
    value_list((0..count).map(|index| start + index as f64 * step))
}

fn cumulative(args: &[Value], product: bool) -> Result<Value, Error> {
    let name = if product { "CUMPROD" } else { "CUMSUM" };
    expect_arity(name, args, 1, 1)?;
    let values = real_list(&args[0])?;
    let mut accumulator = if product { 1.0 } else { 0.0 };
    let mut result = Vec::with_capacity(values.len());
    for value in values {
        if product {
            accumulator *= value;
        } else {
            accumulator += value;
        }
        if !accumulator.is_finite() {
            return Err(Error::RealOverflow);
        }
        result.push(accumulator);
    }
    value_list(result)
}

fn difference(args: &[Value]) -> Result<Value, Error> {
    expect_arity("DIFF", args, 1, 2)?;
    let mut values = real_list(&args[0])?;
    let order = args.get(1).map(nonnegative_usize).transpose()?.unwrap_or(1);
    if order > values.len() {
        return Err(Error::IllegalQuantity);
    }
    for _ in 0..order {
        values = values.windows(2).map(|pair| pair[1] - pair[0]).collect();
    }
    value_list(values)
}

fn sort(args: &[Value]) -> Result<Value, Error> {
    expect_arity("SORT", args, 1, 1)?;
    let mut values = real_list(&args[0])?;
    values.sort_by(f64::total_cmp);
    value_list(values)
}

fn reverse(args: &[Value]) -> Result<Value, Error> {
    expect_arity("REVERSE", args, 1, 1)?;
    let Value::List(values) = &args[0] else {
        return Err(Error::TypeMismatch);
    };
    if values.len() > MAX_LIST_ELEMENTS {
        return Err(Error::ArrayTooLarge);
    }
    Ok(Value::List(values.iter().rev().cloned().collect()))
}

fn unique(args: &[Value]) -> Result<Value, Error> {
    expect_arity("UNIQUE", args, 1, 1)?;
    let mut values = real_list(&args[0])?;
    values.sort_by(f64::total_cmp);
    values.dedup_by(|left, right| left.to_bits() == right.to_bits());
    value_list(values)
}

fn histogram(args: &[Value]) -> Result<Value, Error> {
    expect_arity("HISTOGRAM", args, 2, 4)?;
    let values = real_list(&args[0])?;
    if values.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    let bins = nonnegative_usize(&args[1])?;
    if bins == 0 || bins > MAX_LIST_ELEMENTS.saturating_sub(1) {
        return Err(Error::IllegalQuantity);
    }
    let observed_minimum = values.iter().copied().fold(f64::INFINITY, f64::min);
    let observed_maximum = values.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    let minimum = args
        .get(2)
        .map(real_arg)
        .transpose()?
        .unwrap_or(observed_minimum);
    let maximum = args
        .get(3)
        .map(real_arg)
        .transpose()?
        .unwrap_or(observed_maximum);
    if minimum > maximum {
        return Err(Error::IllegalQuantity);
    }
    let width = if minimum == maximum {
        1.0
    } else {
        (maximum - minimum) / bins as f64
    };
    let mut counts = vec![0_i64; bins];
    for value in values {
        if value < minimum || value > maximum {
            continue;
        }
        let index = if value == maximum || minimum == maximum {
            bins - 1
        } else {
            ((value - minimum) / width).floor() as usize
        };
        counts[index] = counts[index].checked_add(1).ok_or(Error::IntegerOverflow)?;
    }
    let edges = (0..=bins)
        .map(|index| minimum + index as f64 * width)
        .map(finite_value)
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Value::List(vec![
        Value::List(counts.into_iter().map(Value::Integer).collect()),
        Value::List(edges),
    ]))
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    #[test]
    fn data_generation_and_difference_work() {
        let values = evaluate(
            "LINSPACE",
            &[Value::Integer(0), Value::Integer(1), Value::Integer(3)],
        )
        .unwrap();
        assert_eq!(values.to_string(), "{0,0.5,1}");
        let differences = evaluate("DIFF", &[values]).unwrap();
        assert_eq!(differences.to_string(), "{0.5,0.5}");
    }
}
