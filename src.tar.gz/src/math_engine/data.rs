use crate::error::Error;
use crate::value::Value;

use super::{
    checked_element_count, checked_operations, expect_arity, finite_value, nonnegative_usize,
    real_arg, real_list, value_list, MAX_LIST_ELEMENTS,
};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "LINSPACE" => linspace(args),
        "ARANGE" => arange(args),
        "CUMSUM" => cumulative(args, false),
        "CUMPROD" => cumulative(args, true),
        "DIFF" => difference(args),
        "SORT" => sort(args),
        "REVERSE" => reverse(args),
        "UNIQUE" => unique(args),
        "HISTOGRAM" => histogram(args),
        _ => Err(Error::syntax(format!("unknown data function {name}"))),
    }
}

fn linspace(args: &[Value]) -> Result<Value, Error> {
    expect_arity("LINSPACE", args, 3, 3)?;
    let start = real_arg(&args[0])?;
    let stop = real_arg(&args[1])?;
    let count = nonnegative_usize(&args[2])?;
    checked_element_count(count, MAX_LIST_ELEMENTS)?;
    if count == 0 {
        return Ok(Value::List(Vec::new()));
    }
    if count == 1 {
        return value_list([start]);
    }
    let denominator = (count - 1) as f64;
    value_list((0..count).map(|index| {
        if index == 0 {
            return start;
        }
        if index == count - 1 {
            return stop;
        }
        let fraction = index as f64 / denominator;
        if start.is_sign_negative() != stop.is_sign_negative() {
            // Opposite finite endpoints may have an infinite difference.
            start * (1.0 - fraction) + stop * fraction
        } else {
            start + (stop - start) * fraction
        }
    }))
}

fn arange(args: &[Value]) -> Result<Value, Error> {
    expect_arity("ARANGE", args, 1, 3)?;
    let (start, stop, step) = match args {
        [stop] => (0.0, real_arg(stop)?, 1.0),
        [start, stop] => (real_arg(start)?, real_arg(stop)?, 1.0),
        [start, stop, step] => (real_arg(start)?, real_arg(stop)?, real_arg(step)?),
        _ => unreachable!(),
    };
    if step == 0.0 {
        return Err(Error::DivideByZero);
    }
    if (stop > start && step < 0.0) || (stop < start && step > 0.0) {
        return Err(Error::IllegalQuantity);
    }
    if start == stop {
        return Ok(Value::List(Vec::new()));
    }
    let span = stop - start;
    let steps = if span.is_finite() {
        span / step
    } else {
        // Divide first when subtracting opposite endpoints overflows.
        stop / step - start / step
    };
    // Distinct endpoints with the correct step direction always include start,
    // even if the positive span/step ratio underflows to zero.
    let raw_count = steps.ceil().max(1.0);
    if !raw_count.is_finite() || raw_count > MAX_LIST_ELEMENTS as f64 {
        return Err(Error::ArrayTooLarge);
    }
    let count = raw_count as usize;
    value_list((0..count).map(|index| {
        let offset = index as f64 * step;
        if offset.is_finite() {
            start + offset
        } else {
            // Fuse the operations when the offset alone is not representable.
            (index as f64).mul_add(step, start)
        }
    }))
}

fn cumulative(args: &[Value], product: bool) -> Result<Value, Error> {
    let name = if product { "CUMPROD" } else { "CUMSUM" };
    expect_arity(name, args, 1, 1)?;
    let values = real_list(&args[0])?;
    let mut accumulator = if product { 1.0 } else { 0.0 };
    let mut result = Vec::with_capacity(values.len());
    for value in values {
        if product {
            accumulator *= value;
        } else {
            accumulator += value;
        }
        if !accumulator.is_finite() {
            return Err(Error::RealOverflow);
        }
        result.push(accumulator);
    }
    value_list(result)
}

fn difference(args: &[Value]) -> Result<Value, Error> {
    expect_arity("DIFF", args, 1, 2)?;
    let mut values = real_list(&args[0])?;
    let order = args.get(1).map(nonnegative_usize).transpose()?.unwrap_or(1);
    if order > values.len() {
        return Err(Error::IllegalQuantity);
    }
    // Sum the lengths of all successive difference passes before doing work.
    // Lists are capped at one million elements, so this count fits in u64.
    let count = values.len() as u64;
    let passes = order as u64;
    let operations = passes * (count.saturating_sub(1) + count - passes) / 2;
    checked_operations(usize::try_from(operations).unwrap_or(usize::MAX))?;
    for _ in 0..order {
        values = values.windows(2).map(|pair| pair[1] - pair[0]).collect();
    }
    value_list(values)
}

fn sort(args: &[Value]) -> Result<Value, Error> {
    expect_arity("SORT", args, 1, 1)?;
    let mut values = real_list(&args[0])?;
    values.sort_by(f64::total_cmp);
    value_list(values)
}

fn reverse(args: &[Value]) -> Result<Value, Error> {
    expect_arity("REVERSE", args, 1, 1)?;
    let Value::List(values) = &args[0] else {
        return Err(Error::TypeMismatch);
    };
    if values.len() > MAX_LIST_ELEMENTS {
        return Err(Error::ArrayTooLarge);
    }
    Ok(Value::List(values.iter().rev().cloned().collect()))
}

fn unique(args: &[Value]) -> Result<Value, Error> {
    expect_arity("UNIQUE", args, 1, 1)?;
    let mut values = real_list(&args[0])?;
    values.sort_by(f64::total_cmp);
    values.dedup_by(|left, right| left.to_bits() == right.to_bits());
    value_list(values)
}

fn histogram(args: &[Value]) -> Result<Value, Error> {
    expect_arity("HISTOGRAM", args, 2, 4)?;
    let values = real_list(&args[0])?;
    if values.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    let bins = nonnegative_usize(&args[1])?;
    if bins == 0 || bins > MAX_LIST_ELEMENTS.saturating_sub(1) {
        return Err(Error::IllegalQuantity);
    }
    let observed_minimum = values.iter().copied().fold(f64::INFINITY, f64::min);
    let observed_maximum = values.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    let minimum = args
        .get(2)
        .map(real_arg)
        .transpose()?
        .unwrap_or(observed_minimum);
    let maximum = args
        .get(3)
        .map(real_arg)
        .transpose()?
        .unwrap_or(observed_maximum);
    if minimum > maximum {
        return Err(Error::IllegalQuantity);
    }
    let width = if minimum == maximum {
        1.0
    } else {
        (maximum - minimum) / bins as f64
    };
    let mut counts = vec![0_i64; bins];
    for value in values {
        if value < minimum || value > maximum {
            continue;
        }
        let index = if value == maximum || minimum == maximum {
            bins - 1
        } else {
            // Division may round a value below maximum up to `bins`.
            (((value - minimum) / width).floor() as usize).min(bins - 1)
        };
        counts[index] = counts[index].checked_add(1).ok_or(Error::IntegerOverflow)?;
    }
    let edges = (0..=bins)
        .map(|index| minimum + index as f64 * width)
        .map(finite_value)
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Value::List(vec![
        Value::List(counts.into_iter().map(Value::Integer).collect()),
        Value::List(edges),
    ]))
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    fn reals(values: &[f64]) -> Value {
        Value::List(
            values
                .iter()
                .map(|value| Value::real(*value).unwrap())
                .collect(),
        )
    }

    #[test]
    fn linspace_handles_extreme_finite_endpoints() {
        for (start, stop, expected) in [
            (0.0, 1.0e308, vec![0.0, 5.0e307, 1.0e308]),
            (-1.0e308, 1.0e308, vec![-1.0e308, 0.0, 1.0e308]),
            (1.0e308, -1.0e308, vec![1.0e308, 0.0, -1.0e308]),
        ] {
            let result = evaluate(
                "LINSPACE",
                &[
                    Value::real(start).unwrap(),
                    Value::real(stop).unwrap(),
                    Value::Integer(3),
                ],
            )
            .unwrap();
            assert_eq!(result, reals(&expected));
        }
    }

    #[test]
    fn arange_handles_extreme_finite_ranges() {
        for sign in [1.0, -1.0] {
            let result = evaluate(
                "ARANGE",
                &[
                    Value::real(-1.0e308 * sign).unwrap(),
                    Value::real(1.0e308 * sign).unwrap(),
                    Value::real(5.0e307 * sign).unwrap(),
                ],
            )
            .unwrap();
            assert_eq!(
                result,
                reals(&[-1.0e308 * sign, -5.0e307 * sign, 0.0, 5.0e307 * sign])
            );
        }
    }

    #[test]
    fn arange_keeps_start_when_step_ratio_underflows() {
        let result = evaluate(
            "ARANGE",
            &[
                Value::Integer(0),
                Value::real(1.0e-300).unwrap(),
                Value::real(1.0e300).unwrap(),
            ],
        )
        .unwrap();
        assert_eq!(result, reals(&[0.0]));
    }

    #[test]
    fn arange_cancels_an_overflowing_offset_before_rounding() {
        let scale = 2.0_f64.powi(1023);
        let result = evaluate(
            "ARANGE",
            &[
                Value::real(-1.5 * scale).unwrap(),
                Value::real(1.5 * scale).unwrap(),
                Value::real(scale).unwrap(),
            ],
        )
        .unwrap();
        assert_eq!(result, reals(&[-1.5 * scale, -0.5 * scale, 0.5 * scale]));
    }

    #[test]
    fn difference_enforces_math_work_budget() {
        let values = Value::List(vec![Value::Integer(0); 5_000]);
        assert_eq!(
            evaluate("DIFF", &[values, Value::Integer(5_000)]),
            Err(crate::error::Error::IllegalQuantity)
        );
        assert_eq!(
            evaluate("DIFF", &[reals(&[1.0, 4.0, 9.0]), Value::Integer(2)]).unwrap(),
            reals(&[2.0])
        );
        assert_eq!(
            evaluate("DIFF", &[reals(&[1.0, 4.0]), Value::Integer(0)]).unwrap(),
            reals(&[1.0, 4.0])
        );
    }

    #[test]
    fn histogram_rounding_near_upper_bound_stays_in_last_bin() {
        let values = Value::List(vec![Value::real(0.999_999_999_999_999_9).unwrap()]);
        let result = evaluate(
            "HISTOGRAM",
            &[
                values,
                Value::Integer(3),
                Value::Integer(0),
                Value::Integer(1),
            ],
        )
        .unwrap();
        let Value::List(parts) = result else {
            panic!("expected histogram lists")
        };
        assert_eq!(
            parts[0],
            Value::List(vec![
                Value::Integer(0),
                Value::Integer(0),
                Value::Integer(1)
            ])
        );
    }

    #[test]
    fn data_generation_and_difference_work() {
        let values = evaluate(
            "LINSPACE",
            &[Value::Integer(0), Value::Integer(1), Value::Integer(3)],
        )
        .unwrap();
        assert_eq!(values.to_string(), "{0,0.5,1}");
        let differences = evaluate("DIFF", &[values]).unwrap();
        assert_eq!(differences.to_string(), "{0.5,0.5}");
    }
}
