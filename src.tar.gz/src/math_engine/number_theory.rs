use crate::error::Error;
use crate::value::Value;

use super::{bool_value, checked_operations, expect_arity, integer_arg, integer_list};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "ISPRIME" => is_prime_function(args),
        "NEXTPRIME" => next_prime(args),
        "FIBONACCI" | "FIB" => fibonacci(args),
        "DIVMOD" => divmod(args),
        "FACTORS" => factors(args),
        "PRIMEFACTORS" => prime_factors(args),
        _ => Err(Error::syntax(format!(
            "unknown number-theory function {name}"
        ))),
    }
}

fn is_prime_function(args: &[Value]) -> Result<Value, Error> {
    expect_arity("ISPRIME", args, 1, 1)?;
    let value = integer_arg(&args[0])?;
    Ok(bool_value(value >= 0 && is_prime(value as u64)))
}

fn next_prime(args: &[Value]) -> Result<Value, Error> {
    const MAX_CANDIDATES: usize = 1_000_000;
    expect_arity("NEXTPRIME", args, 1, 1)?;
    let input = integer_arg(&args[0])?;
    let mut candidate = input.max(2);
    if candidate > 2 && candidate % 2 == 0 {
        candidate = candidate.checked_add(1).ok_or(Error::IntegerOverflow)?;
    }
    for _ in 0..MAX_CANDIDATES {
        if is_prime(candidate as u64) {
            return Ok(Value::Integer(candidate));
        }
        candidate = candidate
            .checked_add(if candidate == 2 { 1 } else { 2 })
            .ok_or(Error::IntegerOverflow)?;
    }
    Err(Error::IllegalQuantity)
}

fn fibonacci(args: &[Value]) -> Result<Value, Error> {
    expect_arity("FIBONACCI", args, 1, 1)?;
    let index = integer_arg(&args[0])?;
    if !(0..=92).contains(&index) {
        return Err(Error::IllegalQuantity);
    }
    if index == 0 {
        return Ok(Value::Integer(0));
    }

    let mut previous = 0_i64;
    let mut current = 1_i64;
    for _ in 1..index {
        let next = previous
            .checked_add(current)
            .ok_or(Error::IntegerOverflow)?;
        previous = current;
        current = next;
    }
    Ok(Value::Integer(current))
}

fn divmod(args: &[Value]) -> Result<Value, Error> {
    expect_arity("DIVMOD", args, 2, 2)?;
    let dividend = integer_arg(&args[0])?;
    let divisor = integer_arg(&args[1])?;
    if divisor == 0 {
        return Err(Error::DivideByZero);
    }
    let quotient = dividend
        .checked_div(divisor)
        .ok_or(Error::IntegerOverflow)?;
    let remainder = dividend
        .checked_rem(divisor)
        .ok_or(Error::IntegerOverflow)?;
    Ok(Value::List(vec![
        Value::Integer(quotient),
        Value::Integer(remainder),
    ]))
}

fn factors(args: &[Value]) -> Result<Value, Error> {
    expect_arity("FACTORS", args, 1, 1)?;
    let input = integer_arg(&args[0])?;
    if input == 0 {
        return Err(Error::IllegalQuantity);
    }
    let magnitude = input.unsigned_abs();
    if is_prime(magnitude) {
        return integer_list(vec![
            1,
            i64::try_from(magnitude).map_err(|_| Error::IntegerOverflow)?,
        ]);
    }
    let mut low = Vec::new();
    let mut high = Vec::new();
    let mut divisor = 1_u64;
    let mut operations = 0;
    while divisor <= magnitude / divisor {
        operations += 1;
        checked_operations(operations)?;
        if magnitude % divisor == 0 {
            low.push(i64::try_from(divisor).map_err(|_| Error::IntegerOverflow)?);
            let other = magnitude / divisor;
            if other != divisor {
                high.push(i64::try_from(other).map_err(|_| Error::IntegerOverflow)?);
            }
        }
        divisor += 1;
    }
    high.reverse();
    low.extend(high);
    integer_list(low)
}

fn prime_factors(args: &[Value]) -> Result<Value, Error> {
    expect_arity("PRIMEFACTORS", args, 1, 1)?;
    let input = integer_arg(&args[0])?;
    if input == 0 {
        return Err(Error::IllegalQuantity);
    }
    let mut magnitude = input.unsigned_abs();
    let mut result = Vec::new();
    if input < 0 {
        result.push(-1);
    }
    while magnitude % 2 == 0 {
        result.push(2);
        magnitude /= 2;
    }
    if is_prime(magnitude) {
        result.push(i64::try_from(magnitude).map_err(|_| Error::IntegerOverflow)?);
        return integer_list(result);
    }
    let mut divisor = 3_u64;
    let mut operations = 0;
    while divisor <= magnitude / divisor {
        operations += 1;
        checked_operations(operations)?;
        while magnitude % divisor == 0 {
            result.push(i64::try_from(divisor).map_err(|_| Error::IntegerOverflow)?);
            magnitude /= divisor;
        }
        divisor += 2;
    }
    if magnitude > 1 {
        result.push(i64::try_from(magnitude).map_err(|_| Error::IntegerOverflow)?);
    }
    integer_list(result)
}

fn is_prime(value: u64) -> bool {
    if value < 2 {
        return false;
    }
    for prime in [2_u64, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37] {
        if value == prime {
            return true;
        }
        if value % prime == 0 {
            return false;
        }
    }

    let mut odd_part = value - 1;
    let shifts = odd_part.trailing_zeros();
    odd_part >>= shifts;

    // Deterministic Miller-Rabin bases for every 64-bit unsigned integer.
    for base in [2_u64, 325, 9_375, 28_178, 450_775, 9_780_504, 1_795_265_022] {
        let base = base % value;
        if base == 0 {
            continue;
        }
        let mut residue = modular_power(base, odd_part, value);
        if residue == 1 || residue == value - 1 {
            continue;
        }
        let mut witness = true;
        for _ in 1..shifts {
            residue = modular_multiply(residue, residue, value);
            if residue == value - 1 {
                witness = false;
                break;
            }
        }
        if witness {
            return false;
        }
    }
    true
}

fn modular_power(mut base: u64, mut exponent: u64, modulus: u64) -> u64 {
    let mut result = 1_u64;
    while exponent > 0 {
        if exponent & 1 == 1 {
            result = modular_multiply(result, base, modulus);
        }
        exponent >>= 1;
        if exponent > 0 {
            base = modular_multiply(base, base, modulus);
        }
    }
    result
}

fn modular_multiply(left: u64, right: u64, modulus: u64) -> u64 {
    ((u128::from(left) * u128::from(right)) % u128::from(modulus)) as u64
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    #[test]
    fn factorization_enforces_math_work_budget() {
        // Product of two billion-sized primes defeats small-divisor shortcuts.
        for name in ["FACTORS", "PRIMEFACTORS"] {
            assert_eq!(
                evaluate(name, &[Value::Integer(1_000_000_016_000_000_063)]),
                Err(crate::error::Error::IllegalQuantity)
            );
        }
    }

    #[test]
    fn large_primes_and_signed_edge_cases_remain_supported() {
        let prime = 2_305_843_009_213_693_951;
        assert_eq!(
            evaluate("FACTORS", &[Value::Integer(-prime)]).unwrap(),
            Value::List(vec![Value::Integer(1), Value::Integer(prime)])
        );
        assert_eq!(
            evaluate("PRIMEFACTORS", &[Value::Integer(-prime)]).unwrap(),
            Value::List(vec![Value::Integer(-1), Value::Integer(prime)])
        );
        assert_eq!(
            evaluate("FACTORS", &[Value::Integer(1)]).unwrap(),
            Value::List(vec![Value::Integer(1)])
        );
        assert_eq!(
            evaluate("FACTORS", &[Value::Integer(36)]).unwrap(),
            Value::List(
                [1, 2, 3, 4, 6, 9, 12, 18, 36]
                    .into_iter()
                    .map(Value::Integer)
                    .collect()
            )
        );
        assert_eq!(
            evaluate("PRIMEFACTORS", &[Value::Integer(i64::MIN)]).unwrap(),
            Value::List(
                std::iter::once(-1)
                    .chain(std::iter::repeat(2).take(63))
                    .map(Value::Integer)
                    .collect()
            )
        );
        assert_eq!(
            evaluate("FACTORS", &[Value::Integer(i64::MIN)]),
            Err(crate::error::Error::IntegerOverflow)
        );
    }

    #[test]
    fn prime_and_factor_functions_are_exact() {
        assert_eq!(
            evaluate("ISPRIME", &[Value::Integer(2_147_483_647)]).unwrap(),
            Value::Integer(-1)
        );
        assert_eq!(
            evaluate("FIBONACCI", &[Value::Integer(0)]).unwrap(),
            Value::Integer(0)
        );
        assert_eq!(
            evaluate("FIBONACCI", &[Value::Integer(1)]).unwrap(),
            Value::Integer(1)
        );
        assert_eq!(
            evaluate("FIBONACCI", &[Value::Integer(92)]).unwrap(),
            Value::Integer(7_540_113_804_746_346_429)
        );
        assert!(evaluate("FIBONACCI", &[Value::Integer(93)]).is_err());
        assert_eq!(
            evaluate("PRIMEFACTORS", &[Value::Integer(84)]).unwrap(),
            Value::List(vec![
                Value::Integer(2),
                Value::Integer(2),
                Value::Integer(3),
                Value::Integer(7),
            ])
        );
    }
}
