//! Checked advanced mathematics adapted from the broad donor math engine.
//!
//! The donor source contains hundreds of useful numerical algorithms, but it
//! uses a different runtime value and VM model.  This module is the native
//! ModernBASIC adaptation boundary: functions accept [`crate::value::Value`],
//! preserve finite-number and type checks, enforce deterministic size limits,
//! and return ordinary BASIC values.  Function names remain identifier encoded
//! so the historical one-byte Microsoft token table is not renumbered.

mod data;
mod financial;
mod geometry;
mod linalg;
mod number_theory;
mod polynomial;
mod probability;
mod scalar;
mod signal;
mod special;
mod statistics;

use crate::complex::BasicComplex;
use crate::error::Error;
use crate::real::BasicReal;
use crate::value::Value;

pub(crate) const MAX_LIST_ELEMENTS: usize = 1_000_000;
pub(crate) const MAX_MATRIX_ELEMENTS: usize = 1_000_000;
pub(crate) const MAX_MATH_OPERATIONS: usize = 10_000_000;

/// Return whether an identifier names an adapted advanced-math function.
pub(crate) fn is_builtin(name: &str) -> bool {
    matches!(
        normalize_name(name).as_str(),
        // Scalar, trigonometric, exponential, and game math.
        "FLOOR"
            | "CEIL"
            | "CEILING"
            | "TRUNC"
            | "ATAN2"
            | "HYPOT"
            | "SEC"
            | "CSC"
            | "COT"
            | "SECH"
            | "CSCH"
            | "COTH"
            | "EXP2"
            | "EXP10"
            | "EXPM1"
            | "LOG2"
            | "LOG1P"
            | "POW"
            | "CLAMP"
            | "LERP"
            | "SMOOTHSTEP"
            | "WRAP"
            | "MAPRANGE"
            // Number theory.
            | "ISPRIME"
            | "NEXTPRIME"
            | "FIBONACCI"
            | "FIB"
            | "DIVMOD"
            | "FACTORS"
            | "PRIMEFACTORS"
            // Special functions.
            | "GAMMA"
            | "LGAMMA"
            | "ERF"
            | "ERFC"
            | "BETA"
            // Statistics.
            | "TOTAL"
            | "PRODUCT"
            | "MODE"
            | "PERCENTILE"
            | "QUARTILE"
            | "GEOMEAN"
            | "HARMEAN"
            | "RMS"
            | "COVARIANCE"
            | "COVARP"
            | "SKEWNESS"
            | "KURTOSIS"
            // Data and list utilities.
            | "LINSPACE"
            | "ARANGE"
            | "CUMSUM"
            | "CUMPROD"
            | "DIFF"
            | "SORT"
            | "REVERSE"
            | "UNIQUE"
            | "HISTOGRAM"
            // Geometry.
            | "DIST"
            | "DIST3D"
            | "ROTATE2D"
            | "TOPOLAR"
            | "TORECT"
            | "AREACIRCLE"
            | "CIRCLEAREA"
            | "AREAELLIPSE"
            | "ELLIPSEAREA"
            | "AREARECT"
            | "RECTAREA"
            | "AREATRIANGLE"
            | "TRIANGLEAREA"
            | "VOLUMESPHERE"
            | "SPHEREVOLUME"
            | "VOLUMECYLINDER"
            | "CYLINDERVOLUME"
            | "VOLUMECONE"
            | "CONEVOLUME"
            // Linear algebra.
            | "DOT"
            | "CROSS"
            | "NORM"
            | "NORMALIZE"
            | "TRANSPOSE"
            | "MATMUL"
            | "DET"
            | "INVERSE"
            | "TRACE"
            | "IDENTITY"
            | "ZEROS"
            | "ONES"
            | "SOLVELINEAR"
            | "LINSOLVE"
            | "OUTER"
            | "DIAG"
            // Polynomial operations.
            | "POLYEVAL"
            | "POLYADD"
            | "POLYSUB"
            | "POLYMUL"
            | "POLYDERIV"
            | "POLYINT"
            | "QUADRATIC"
            | "POLYFIT"
            // Probability distributions.
            | "EXPPDF"
            | "EXPCDF"
            | "UNIFORMPDF"
            | "UNIFORMCDF"
            | "WEIBULLPDF"
            | "WEIBULLCDF"
            | "GAMMAPDF"
            | "GAMMACDF"
            | "CHISQPDF"
            | "CHISQCDF"
            // Signal processing.
            | "FFT"
            | "IFFT"
            | "CONVOLVE"
            | "AUTOCORR"
            | "XCORR"
            | "HANN"
            | "HANNING"
            | "HAMMING"
            | "BLACKMAN"
            | "ZCR"
            | "RESAMPLE"
            // Financial mathematics.
            | "PV"
            | "FV"
            | "PMT"
            | "NPV"
            | "IRR"
            | "COMPOUND"
    )
}

/// Evaluate one adapted advanced-math function.
pub(crate) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    let name = normalize_name(name);
    match name.as_str() {
        "FLOOR" | "CEIL" | "CEILING" | "TRUNC" | "ATAN2" | "HYPOT" | "SEC" | "CSC" | "COT"
        | "SECH" | "CSCH" | "COTH" | "EXP2" | "EXP10" | "EXPM1" | "LOG2" | "LOG1P" | "POW"
        | "CLAMP" | "LERP" | "SMOOTHSTEP" | "WRAP" | "MAPRANGE" => scalar::evaluate(&name, args),

        "ISPRIME" | "NEXTPRIME" | "FIBONACCI" | "FIB" | "DIVMOD" | "FACTORS" | "PRIMEFACTORS" => {
            number_theory::evaluate(&name, args)
        }

        "GAMMA" | "LGAMMA" | "ERF" | "ERFC" | "BETA" => special::evaluate(&name, args),

        "TOTAL" | "PRODUCT" | "MODE" | "PERCENTILE" | "QUARTILE" | "GEOMEAN" | "HARMEAN"
        | "RMS" | "COVARIANCE" | "COVARP" | "SKEWNESS" | "KURTOSIS" => {
            statistics::evaluate(&name, args)
        }

        "LINSPACE" | "ARANGE" | "CUMSUM" | "CUMPROD" | "DIFF" | "SORT" | "REVERSE" | "UNIQUE"
        | "HISTOGRAM" => data::evaluate(&name, args),

        "DIST" | "DIST3D" | "ROTATE2D" | "TOPOLAR" | "TORECT" | "AREACIRCLE" | "CIRCLEAREA"
        | "AREAELLIPSE" | "ELLIPSEAREA" | "AREARECT" | "RECTAREA" | "AREATRIANGLE"
        | "TRIANGLEAREA" | "VOLUMESPHERE" | "SPHEREVOLUME" | "VOLUMECYLINDER"
        | "CYLINDERVOLUME" | "VOLUMECONE" | "CONEVOLUME" => geometry::evaluate(&name, args),

        "DOT" | "CROSS" | "NORM" | "NORMALIZE" | "TRANSPOSE" | "MATMUL" | "DET" | "INVERSE"
        | "TRACE" | "IDENTITY" | "ZEROS" | "ONES" | "SOLVELINEAR" | "LINSOLVE" | "OUTER"
        | "DIAG" => linalg::evaluate(&name, args),

        "POLYEVAL" | "POLYADD" | "POLYSUB" | "POLYMUL" | "POLYDERIV" | "POLYINT" | "QUADRATIC"
        | "POLYFIT" => polynomial::evaluate(&name, args),

        "EXPPDF" | "EXPCDF" | "UNIFORMPDF" | "UNIFORMCDF" | "WEIBULLPDF" | "WEIBULLCDF"
        | "GAMMAPDF" | "GAMMACDF" | "CHISQPDF" | "CHISQCDF" => probability::evaluate(&name, args),

        "FFT" | "IFFT" | "CONVOLVE" | "AUTOCORR" | "XCORR" | "HANN" | "HANNING" | "HAMMING"
        | "BLACKMAN" | "ZCR" | "RESAMPLE" => signal::evaluate(&name, args),

        "PV" | "FV" | "PMT" | "NPV" | "IRR" | "COMPOUND" => financial::evaluate(&name, args),

        _ => Err(Error::syntax(format!("unknown math function {name}"))),
    }
}

/// Canonicalise names without creating multiple public dialect spellings.
/// Separators are ignored only so documentation can write `AREA.CIRCLE` while
/// source may use the compact classic-safe spelling `AREACIRCLE`.
fn normalize_name(name: &str) -> String {
    name.chars()
        .filter(|character| character.is_ascii_alphanumeric())
        .map(|character| character.to_ascii_uppercase())
        .collect()
}

pub(super) fn expect_arity(
    name: &'static str,
    args: &[Value],
    minimum: usize,
    maximum: usize,
) -> Result<(), Error> {
    if (minimum..=maximum).contains(&args.len()) {
        Ok(())
    } else if minimum == maximum {
        Err(Error::syntax(format!(
            "{name} expects {minimum} argument(s), got {}",
            args.len()
        )))
    } else {
        Err(Error::syntax(format!(
            "{name} expects {minimum}..={maximum} arguments, got {}",
            args.len()
        )))
    }
}

pub(super) fn real_arg(value: &Value) -> Result<f64, Error> {
    match value {
        Value::Integer(value) => Ok(BasicReal::from_integer(*value)?.value()),
        Value::Real(value) => Ok(value.value()),
        Value::Complex(_) | Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

pub(super) fn integer_arg(value: &Value) -> Result<i64, Error> {
    value.to_integer()
}

pub(super) fn nonnegative_usize(value: &Value) -> Result<usize, Error> {
    let value = integer_arg(value)?;
    if value < 0 {
        return Err(Error::IllegalQuantity);
    }
    usize::try_from(value).map_err(|_| Error::IllegalQuantity)
}

pub(super) fn finite_value(value: f64) -> Result<Value, Error> {
    BasicReal::new(value).map(Value::Real)
}

pub(super) fn bool_value(value: bool) -> Value {
    Value::Integer(if value { -1 } else { 0 })
}

pub(super) fn list_arg(value: &Value) -> Result<&[Value], Error> {
    match value {
        Value::List(values) => Ok(values),
        _ => Err(Error::TypeMismatch),
    }
}

pub(super) fn real_list(value: &Value) -> Result<Vec<f64>, Error> {
    let values = list_arg(value)?;
    if values.len() > MAX_LIST_ELEMENTS {
        return Err(Error::ArrayTooLarge);
    }
    values.iter().map(real_arg).collect()
}

pub(super) fn value_list(values: impl IntoIterator<Item = f64>) -> Result<Value, Error> {
    let values = values
        .into_iter()
        .map(finite_value)
        .collect::<Result<Vec<_>, _>>()?;
    if values.len() > MAX_LIST_ELEMENTS {
        return Err(Error::ArrayTooLarge);
    }
    Ok(Value::List(values))
}

pub(super) fn integer_list(values: impl IntoIterator<Item = i64>) -> Result<Value, Error> {
    let values = values.into_iter().map(Value::Integer).collect::<Vec<_>>();
    if values.len() > MAX_LIST_ELEMENTS {
        return Err(Error::ArrayTooLarge);
    }
    Ok(Value::List(values))
}

pub(super) fn complex_arg(value: &Value) -> Result<BasicComplex, Error> {
    match value {
        Value::Integer(value) => Ok(BasicComplex::new(
            BasicReal::from_integer(*value)?.value(),
            0.0,
        )?),
        Value::Real(value) => Ok(BasicComplex::new(value.value(), 0.0)?),
        Value::Complex(value) => Ok(*value),
        Value::List(_) | Value::String(_) => Err(Error::TypeMismatch),
    }
}

pub(super) fn checked_operations(operations: usize) -> Result<(), Error> {
    if operations > MAX_MATH_OPERATIONS {
        Err(Error::IllegalQuantity)
    } else {
        Ok(())
    }
}

pub(super) fn checked_element_count(count: usize, maximum: usize) -> Result<(), Error> {
    if count > maximum {
        Err(Error::ArrayTooLarge)
    } else {
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::{evaluate, is_builtin};
    use crate::value::Value;

    #[test]
    fn registry_accepts_compact_and_separator_names() {
        assert!(is_builtin("AREACIRCLE"));
        assert!(is_builtin("AREA.CIRCLE"));
        assert!(is_builtin("SOLVE_LINEAR"));
        assert!(!is_builtin("NOTAMATHFUNCTION"));
    }

    #[test]
    fn adapted_functions_return_basic_values() {
        assert_eq!(
            evaluate("FIBONACCI", &[Value::Integer(10)]).unwrap(),
            Value::Integer(55)
        );
        let result = evaluate(
            "DOT",
            &[
                Value::List(vec![Value::Integer(1), Value::Integer(2)]),
                Value::List(vec![Value::Integer(3), Value::Integer(4)]),
            ],
        )
        .unwrap();
        assert_eq!(result.to_string(), "11");
    }
}
