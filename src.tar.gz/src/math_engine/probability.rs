use crate::error::Error;
use crate::value::Value;

use super::special::{log_gamma_positive, regularized_gamma_p};
use super::{expect_arity, finite_value, real_arg};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "EXPPDF" => exponential_pdf(args),
        "EXPCDF" => exponential_cdf(args),
        "UNIFORMPDF" => uniform_pdf(args),
        "UNIFORMCDF" => uniform_cdf(args),
        "WEIBULLPDF" => weibull_pdf(args),
        "WEIBULLCDF" => weibull_cdf(args),
        "GAMMAPDF" => gamma_pdf(args),
        "GAMMACDF" => gamma_cdf(args),
        "CHISQPDF" => chi_square_pdf(args),
        "CHISQCDF" => chi_square_cdf(args),
        _ => Err(Error::syntax(format!(
            "unknown probability function {name}"
        ))),
    }
}

fn exponential_pdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("EXPPDF", args, 2, 2)?;
    let x = real_arg(&args[0])?;
    let rate = positive(real_arg(&args[1])?, "EXPPDF")?;
    finite_value(if x < 0.0 {
        0.0
    } else {
        rate * (-rate * x).exp()
    })
}

fn exponential_cdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("EXPCDF", args, 2, 2)?;
    let x = real_arg(&args[0])?;
    let rate = positive(real_arg(&args[1])?, "EXPCDF")?;
    finite_value(if x <= 0.0 { 0.0 } else { -(-rate * x).exp_m1() })
}

fn uniform_pdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("UNIFORMPDF", args, 3, 3)?;
    let x = real_arg(&args[0])?;
    let minimum = real_arg(&args[1])?;
    let maximum = real_arg(&args[2])?;
    if minimum >= maximum {
        return Err(Error::IllegalQuantity);
    }
    finite_value(if (minimum..=maximum).contains(&x) {
        1.0 / (maximum - minimum)
    } else {
        0.0
    })
}

fn uniform_cdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("UNIFORMCDF", args, 3, 3)?;
    let x = real_arg(&args[0])?;
    let minimum = real_arg(&args[1])?;
    let maximum = real_arg(&args[2])?;
    if minimum >= maximum {
        return Err(Error::IllegalQuantity);
    }
    finite_value(if x <= minimum {
        0.0
    } else if x >= maximum {
        1.0
    } else {
        (x - minimum) / (maximum - minimum)
    })
}

fn weibull_pdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("WEIBULLPDF", args, 3, 3)?;
    let x = real_arg(&args[0])?;
    let shape = positive(real_arg(&args[1])?, "WEIBULLPDF")?;
    let scale = positive(real_arg(&args[2])?, "WEIBULLPDF")?;
    if x < 0.0 {
        return finite_value(0.0);
    }
    if x == 0.0 {
        if shape < 1.0 {
            return Err(Error::RealOverflow);
        }
        return finite_value(if shape == 1.0 { 1.0 / scale } else { 0.0 });
    }
    let ratio = x / scale;
    finite_value(shape / scale * ratio.powf(shape - 1.0) * (-ratio.powf(shape)).exp())
}

fn weibull_cdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("WEIBULLCDF", args, 3, 3)?;
    let x = real_arg(&args[0])?;
    let shape = positive(real_arg(&args[1])?, "WEIBULLCDF")?;
    let scale = positive(real_arg(&args[2])?, "WEIBULLCDF")?;
    finite_value(if x <= 0.0 {
        0.0
    } else {
        -(-(x / scale).powf(shape)).exp_m1()
    })
}

fn gamma_pdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("GAMMAPDF", args, 3, 3)?;
    let x = real_arg(&args[0])?;
    let shape = positive(real_arg(&args[1])?, "GAMMAPDF")?;
    let scale = positive(real_arg(&args[2])?, "GAMMAPDF")?;
    if x < 0.0 {
        return finite_value(0.0);
    }
    if x == 0.0 {
        if shape < 1.0 {
            return Err(Error::RealOverflow);
        }
        return finite_value(if shape == 1.0 { 1.0 / scale } else { 0.0 });
    }
    let log_density =
        (shape - 1.0) * x.ln() - x / scale - log_gamma_positive(shape) - shape * scale.ln();
    finite_value(log_density.exp())
}

fn gamma_cdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("GAMMACDF", args, 3, 3)?;
    let x = real_arg(&args[0])?;
    let shape = positive(real_arg(&args[1])?, "GAMMACDF")?;
    let scale = positive(real_arg(&args[2])?, "GAMMACDF")?;
    if x <= 0.0 {
        return finite_value(0.0);
    }
    finite_value(regularized_gamma_p(shape, x / scale)?)
}

fn chi_square_pdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("CHISQPDF", args, 2, 2)?;
    let x = real_arg(&args[0])?;
    let degrees = positive(real_arg(&args[1])?, "CHISQPDF")?;
    gamma_pdf(&[
        finite_value(x)?,
        finite_value(degrees / 2.0)?,
        finite_value(2.0)?,
    ])
}

fn chi_square_cdf(args: &[Value]) -> Result<Value, Error> {
    expect_arity("CHISQCDF", args, 2, 2)?;
    let x = real_arg(&args[0])?;
    let degrees = positive(real_arg(&args[1])?, "CHISQCDF")?;
    if x <= 0.0 {
        return finite_value(0.0);
    }
    finite_value(regularized_gamma_p(degrees / 2.0, x / 2.0)?)
}

fn positive(value: f64, function: &'static str) -> Result<f64, Error> {
    if value <= 0.0 {
        Err(Error::MathDomain { function })
    } else {
        Ok(value)
    }
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    #[test]
    fn distribution_functions_are_bounded() {
        assert_eq!(
            evaluate("EXPCDF", &[Value::Integer(0), Value::Integer(2)])
                .unwrap()
                .to_string(),
            "0"
        );
        let cdf = evaluate("CHISQCDF", &[Value::Integer(2), Value::Integer(2)])
            .unwrap()
            .to_string()
            .parse::<f64>()
            .unwrap();
        assert!((cdf - 0.632_120_558_8).abs() < 1.0e-10);
    }
}
