use crate::error::Error;
use crate::value::Value;

use super::{expect_arity, finite_value, real_arg, real_list};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "TOTAL" => total(args),
        "PRODUCT" => product(args),
        "MODE" => mode(args),
        "PERCENTILE" => percentile_function(args),
        "QUARTILE" => quartile(args),
        "GEOMEAN" => geometric_mean(args),
        "HARMEAN" => harmonic_mean(args),
        "RMS" => root_mean_square(args),
        "COVARIANCE" => covariance(args, true),
        "COVARP" => covariance(args, false),
        "SKEWNESS" => skewness(args),
        "KURTOSIS" => kurtosis(args),
        _ => Err(Error::syntax(format!("unknown statistics function {name}"))),
    }
}

fn values(args: &[Value], name: &'static str) -> Result<Vec<f64>, Error> {
    expect_arity(name, args, 1, 1)?;
    let values = real_list(&args[0])?;
    if values.is_empty() {
        return Err(Error::IllegalQuantity);
    }
    Ok(values)
}

fn total(args: &[Value]) -> Result<Value, Error> {
    let values = values(args, "TOTAL")?;
    finite_value(kahan_sum(&values))
}

fn product(args: &[Value]) -> Result<Value, Error> {
    let values = values(args, "PRODUCT")?;
    let mut result = 1.0;
    for value in values {
        result *= value;
        if !result.is_finite() {
            return Err(Error::RealOverflow);
        }
    }
    finite_value(result)
}

fn mode(args: &[Value]) -> Result<Value, Error> {
    let mut values = values(args, "MODE")?;
    values.sort_by(f64::total_cmp);
    let mut best_value = values[0];
    let mut best_count = 1_usize;
    let mut current_value = values[0];
    let mut current_count = 1_usize;
    for value in values.into_iter().skip(1) {
        if value.to_bits() == current_value.to_bits() {
            current_count += 1;
        } else {
            if current_count > best_count {
                best_count = current_count;
                best_value = current_value;
            }
            current_value = value;
            current_count = 1;
        }
    }
    if current_count > best_count {
        best_value = current_value;
    }
    finite_value(best_value)
}

fn percentile_function(args: &[Value]) -> Result<Value, Error> {
    expect_arity("PERCENTILE", args, 2, 2)?;
    let values = real_list(&args[0])?;
    let percentile = real_arg(&args[1])?;
    if values.is_empty() || !(0.0..=100.0).contains(&percentile) {
        return Err(Error::IllegalQuantity);
    }
    finite_value(percentile_value(values, percentile / 100.0))
}

fn quartile(args: &[Value]) -> Result<Value, Error> {
    expect_arity("QUARTILE", args, 2, 2)?;
    let values = real_list(&args[0])?;
    let quartile = real_arg(&args[1])?;
    if values.is_empty() || !(0.0..=4.0).contains(&quartile) {
        return Err(Error::IllegalQuantity);
    }
    finite_value(percentile_value(values, quartile / 4.0))
}

fn geometric_mean(args: &[Value]) -> Result<Value, Error> {
    let values = values(args, "GEOMEAN")?;
    if values.iter().any(|value| *value <= 0.0) {
        return Err(Error::MathDomain {
            function: "GEOMEAN",
        });
    }
    finite_value((values.iter().map(|value| value.ln()).sum::<f64>() / values.len() as f64).exp())
}

fn harmonic_mean(args: &[Value]) -> Result<Value, Error> {
    let values = values(args, "HARMEAN")?;
    if values.contains(&0.0) {
        return Err(Error::DivideByZero);
    }
    finite_value(values.len() as f64 / values.iter().map(|value| 1.0 / value).sum::<f64>())
}

fn root_mean_square(args: &[Value]) -> Result<Value, Error> {
    let values = values(args, "RMS")?;
    // Normalize before squaring to avoid overflowing large inputs or losing
    // small inputs to underflow when the RMS itself is representable.
    let scale = values.iter().map(|value| value.abs()).fold(0.0, f64::max);
    if scale == 0.0 {
        return finite_value(0.0);
    }
    let mean_square = values
        .iter()
        .map(|value| (value / scale).powi(2))
        .sum::<f64>()
        / values.len() as f64;
    finite_value(scale * mean_square.sqrt())
}

fn covariance(args: &[Value], sample: bool) -> Result<Value, Error> {
    let name = if sample { "COVARIANCE" } else { "COVARP" };
    expect_arity(name, args, 2, 2)?;
    let left = real_list(&args[0])?;
    let right = real_list(&args[1])?;
    if left.len() != right.len() || left.is_empty() || (sample && left.len() < 2) {
        return Err(Error::IllegalQuantity);
    }
    let left_mean = kahan_sum(&left) / left.len() as f64;
    let right_mean = kahan_sum(&right) / right.len() as f64;
    let numerator = left
        .iter()
        .zip(&right)
        .map(|(left, right)| (left - left_mean) * (right - right_mean))
        .sum::<f64>();
    let denominator = if sample { left.len() - 1 } else { left.len() };
    finite_value(numerator / denominator as f64)
}

fn skewness(args: &[Value]) -> Result<Value, Error> {
    let values = values(args, "SKEWNESS")?;
    let count = values.len();
    if count < 3 {
        return Err(Error::IllegalQuantity);
    }
    let mean = kahan_sum(&values) / count as f64;
    let mut sum2 = 0.0;
    let mut sum3 = 0.0;
    for value in values {
        let deviation = value - mean;
        sum2 += deviation * deviation;
        sum3 += deviation * deviation * deviation;
    }
    if sum2 == 0.0 {
        return finite_value(0.0);
    }
    let n = count as f64;
    let sample_deviation = (sum2 / (n - 1.0)).sqrt();
    finite_value(n / ((n - 1.0) * (n - 2.0)) * sum3 / sample_deviation.powi(3))
}

fn kurtosis(args: &[Value]) -> Result<Value, Error> {
    let values = values(args, "KURTOSIS")?;
    let count = values.len();
    if count < 4 {
        return Err(Error::IllegalQuantity);
    }
    let mean = kahan_sum(&values) / count as f64;
    let mut sum2 = 0.0;
    let mut sum4 = 0.0;
    for value in values {
        let deviation = value - mean;
        let square = deviation * deviation;
        sum2 += square;
        sum4 += square * square;
    }
    if sum2 == 0.0 {
        return finite_value(0.0);
    }
    let n = count as f64;
    let variance = sum2 / (n - 1.0);
    let first = n * (n + 1.0) / ((n - 1.0) * (n - 2.0) * (n - 3.0));
    let second = 3.0 * (n - 1.0).powi(2) / ((n - 2.0) * (n - 3.0));
    finite_value(first * sum4 / variance.powi(2) - second)
}

fn percentile_value(mut values: Vec<f64>, fraction: f64) -> f64 {
    values.sort_by(f64::total_cmp);
    if values.len() == 1 {
        return values[0];
    }
    let position = fraction * (values.len() - 1) as f64;
    let lower = position.floor() as usize;
    let upper = position.ceil() as usize;
    if lower == upper {
        values[lower]
    } else {
        let amount = position - lower as f64;
        let left = values[lower];
        let right = values[upper];
        if left.is_sign_negative() != right.is_sign_negative() {
            // The distance between opposite finite extremes can overflow.
            left * (1.0 - amount) + right * amount
        } else {
            left + (right - left) * amount
        }
    }
}

fn kahan_sum(values: &[f64]) -> f64 {
    let mut sum = 0.0;
    let mut correction = 0.0;
    for value in values {
        let adjusted = *value - correction;
        let next = sum + adjusted;
        correction = (next - sum) - adjusted;
        sum = next;
    }
    sum
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    fn list(values: &[i64]) -> Value {
        Value::List(values.iter().copied().map(Value::Integer).collect())
    }

    fn real_list(values: &[f64]) -> Value {
        Value::List(
            values
                .iter()
                .map(|value| Value::real(*value).unwrap())
                .collect(),
        )
    }

    #[test]
    fn rms_preserves_large_and_small_finite_magnitudes() {
        for magnitude in [1.0e308, 1.0e-300, f64::MAX] {
            let result = evaluate("RMS", &[real_list(&[magnitude, -magnitude])]).unwrap();
            let actual = super::real_arg(&result).unwrap();
            assert!((actual / magnitude - 1.0).abs() < 1.0e-14);
        }
        assert_eq!(
            evaluate("RMS", &[list(&[0, 0])]).unwrap(),
            Value::real(0.0).unwrap()
        );
    }

    #[test]
    fn percentiles_interpolate_opposite_extremes_without_overflow() {
        for (percentile, expected) in [(25, -5.0e307), (50, 0.0), (75, 5.0e307)] {
            for (name, fraction) in [("PERCENTILE", percentile), ("QUARTILE", percentile / 25)] {
                let result = evaluate(
                    name,
                    &[real_list(&[-1.0e308, 1.0e308]), Value::Integer(fraction)],
                )
                .unwrap();
                let actual = super::real_arg(&result).unwrap();
                assert!((actual - expected).abs() <= 1.0e292, "{name}: {actual}");
            }
        }
    }

    #[test]
    fn statistics_are_list_native() {
        assert_eq!(
            evaluate("TOTAL", &[list(&[1, 2, 3, 4])])
                .unwrap()
                .to_string(),
            "10"
        );
        assert_eq!(
            evaluate("PERCENTILE", &[list(&[1, 2, 3, 4, 5]), Value::Integer(50)])
                .unwrap()
                .to_string(),
            "3"
        );
    }
}
