use crate::error::Error;
use crate::value::Value;

use super::{expect_arity, finite_value, real_arg, real_list};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "PV" => present_value(args),
        "FV" => future_value(args),
        "PMT" => payment(args),
        "NPV" => net_present_value_function(args),
        "IRR" => internal_rate_of_return(args),
        "COMPOUND" => compound(args),
        _ => Err(Error::syntax(format!("unknown financial function {name}"))),
    }
}

fn present_value(args: &[Value]) -> Result<Value, Error> {
    expect_arity("PV", args, 3, 5)?;
    let rate = real_arg(&args[0])?;
    let periods = real_arg(&args[1])?;
    let payment = real_arg(&args[2])?;
    let future = args.get(3).map(real_arg).transpose()?.unwrap_or(0.0);
    let due = due_flag(args.get(4))?;
    if periods < 0.0 || rate <= -1.0 {
        return Err(Error::IllegalQuantity);
    }
    if rate == 0.0 {
        return finite_value(-future - payment * periods);
    }
    let factor = (1.0 + rate).powf(periods);
    finite_value(-(future + payment * (1.0 + rate * due) * (factor - 1.0) / rate) / factor)
}

fn future_value(args: &[Value]) -> Result<Value, Error> {
    expect_arity("FV", args, 3, 5)?;
    let rate = real_arg(&args[0])?;
    let periods = real_arg(&args[1])?;
    let payment = real_arg(&args[2])?;
    let present = args.get(3).map(real_arg).transpose()?.unwrap_or(0.0);
    let due = due_flag(args.get(4))?;
    if periods < 0.0 || rate <= -1.0 {
        return Err(Error::IllegalQuantity);
    }
    if rate == 0.0 {
        return finite_value(-present - payment * periods);
    }
    let factor = (1.0 + rate).powf(periods);
    finite_value(-present * factor - payment * (1.0 + rate * due) * (factor - 1.0) / rate)
}

fn payment(args: &[Value]) -> Result<Value, Error> {
    expect_arity("PMT", args, 3, 5)?;
    let rate = real_arg(&args[0])?;
    let periods = real_arg(&args[1])?;
    let present = real_arg(&args[2])?;
    let future = args.get(3).map(real_arg).transpose()?.unwrap_or(0.0);
    let due = due_flag(args.get(4))?;
    if periods <= 0.0 || rate <= -1.0 {
        return Err(Error::IllegalQuantity);
    }
    if rate == 0.0 {
        return finite_value(-(present + future) / periods);
    }
    let factor = (1.0 + rate).powf(periods);
    finite_value(-(present * factor + future) * rate / ((1.0 + rate * due) * (factor - 1.0)))
}

fn net_present_value_function(args: &[Value]) -> Result<Value, Error> {
    expect_arity("NPV", args, 2, 2)?;
    let rate = real_arg(&args[0])?;
    let cashflows = real_list(&args[1])?;
    if rate <= -1.0 {
        return Err(Error::IllegalQuantity);
    }
    finite_value(net_present_value(rate, &cashflows))
}

fn internal_rate_of_return(args: &[Value]) -> Result<Value, Error> {
    const MAX_ITERATIONS: usize = 200;
    const TOLERANCE: f64 = 1.0e-12;
    expect_arity("IRR", args, 1, 2)?;
    let cashflows = real_list(&args[0])?;
    if cashflows.len() < 2
        || !cashflows.iter().any(|value| *value < 0.0)
        || !cashflows.iter().any(|value| *value > 0.0)
    {
        return Err(Error::IllegalQuantity);
    }
    let mut rate = args.get(1).map(real_arg).transpose()?.unwrap_or(0.1);
    rate = rate.max(-0.999_999_999);
    for _ in 0..MAX_ITERATIONS {
        let mut value = 0.0;
        let mut derivative = 0.0;
        let base = 1.0 + rate;
        for (period, cashflow) in cashflows.iter().enumerate() {
            value += cashflow / base.powi(period as i32);
            if period > 0 {
                derivative -= period as f64 * cashflow / base.powi(period as i32 + 1);
            }
        }
        if value.abs() <= TOLERANCE {
            return finite_value(rate);
        }
        if derivative == 0.0 || !derivative.is_finite() {
            break;
        }
        let next = rate - value / derivative;
        if !next.is_finite() || next <= -1.0 {
            break;
        }
        if (next - rate).abs() <= TOLERANCE {
            return finite_value(next);
        }
        rate = next;
    }

    // Deterministic bracket search and bisection fallback.
    let mut lower = -0.999_999;
    let mut lower_value = net_present_value_zero_based(lower, &cashflows);
    let mut upper = 1.0;
    let mut upper_value = net_present_value_zero_based(upper, &cashflows);
    for _ in 0..64 {
        if lower_value.signum() != upper_value.signum() {
            break;
        }
        upper = upper * 2.0 + 1.0;
        upper_value = net_present_value_zero_based(upper, &cashflows);
    }
    if lower_value.signum() == upper_value.signum() {
        return Err(Error::MathDomain { function: "IRR" });
    }
    for _ in 0..MAX_ITERATIONS {
        let middle = (lower + upper) / 2.0;
        let middle_value = net_present_value_zero_based(middle, &cashflows);
        if middle_value.abs() <= TOLERANCE || (upper - lower).abs() <= TOLERANCE {
            return finite_value(middle);
        }
        if lower_value.signum() == middle_value.signum() {
            lower = middle;
            lower_value = middle_value;
        } else {
            upper = middle;
        }
    }
    Err(Error::MathDomain { function: "IRR" })
}

fn compound(args: &[Value]) -> Result<Value, Error> {
    expect_arity("COMPOUND", args, 3, 4)?;
    let principal = real_arg(&args[0])?;
    let rate = real_arg(&args[1])?;
    let periods = real_arg(&args[2])?;
    let frequency = args.get(3).map(real_arg).transpose()?.unwrap_or(1.0);
    if periods < 0.0 || frequency <= 0.0 || 1.0 + rate / frequency < 0.0 {
        return Err(Error::IllegalQuantity);
    }
    finite_value(principal * (1.0 + rate / frequency).powf(periods * frequency))
}

fn due_flag(value: Option<&Value>) -> Result<f64, Error> {
    let due = value.map(real_arg).transpose()?.unwrap_or(0.0);
    if due == 0.0 {
        Ok(0.0)
    } else if due == 1.0 {
        Ok(1.0)
    } else {
        Err(Error::IllegalQuantity)
    }
}

fn net_present_value(rate: f64, cashflows: &[f64]) -> f64 {
    cashflows
        .iter()
        .enumerate()
        .map(|(index, value)| value / (1.0 + rate).powi(index as i32 + 1))
        .sum()
}

fn net_present_value_zero_based(rate: f64, cashflows: &[f64]) -> f64 {
    cashflows
        .iter()
        .enumerate()
        .map(|(index, value)| value / (1.0 + rate).powi(index as i32))
        .sum()
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    #[test]
    fn financial_functions_follow_cashflow_sign_convention() {
        let payment = evaluate(
            "PMT",
            &[
                Value::real(0.01).unwrap(),
                Value::Integer(12),
                Value::Integer(1_000),
            ],
        )
        .unwrap()
        .to_string()
        .parse::<f64>()
        .unwrap();
        assert!(payment < 0.0);
    }
}
