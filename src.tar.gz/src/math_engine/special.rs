use crate::error::Error;
use crate::value::Value;

use super::{expect_arity, finite_value, real_arg};

const LANCZOS_G: f64 = 7.0;
const LANCZOS_COEFFICIENTS: [f64; 9] = [
    0.999_999_999_999_809_9,
    676.520_368_121_885_1,
    -1_259.139_216_722_402_8,
    771.323_428_777_653_1,
    -176.615_029_162_140_6,
    12.507_343_278_686_905,
    -0.138_571_095_265_720_12,
    9.984_369_578_019_572e-6,
    1.505_632_735_149_311_6e-7,
];

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "GAMMA" => {
            expect_arity("GAMMA", args, 1, 1)?;
            finite_value(gamma(real_arg(&args[0])?)?)
        }
        "LGAMMA" => {
            expect_arity("LGAMMA", args, 1, 1)?;
            finite_value(log_gamma_abs(real_arg(&args[0])?)?)
        }
        "ERF" => {
            expect_arity("ERF", args, 1, 1)?;
            finite_value(erf(real_arg(&args[0])?))
        }
        "ERFC" => {
            expect_arity("ERFC", args, 1, 1)?;
            finite_value(1.0 - erf(real_arg(&args[0])?))
        }
        "BETA" => {
            expect_arity("BETA", args, 2, 2)?;
            let left = real_arg(&args[0])?;
            let right = real_arg(&args[1])?;
            if left <= 0.0 || right <= 0.0 {
                return Err(Error::MathDomain { function: "BETA" });
            }
            finite_value(
                (log_gamma_positive(left) + log_gamma_positive(right)
                    - log_gamma_positive(left + right))
                .exp(),
            )
        }
        _ => Err(Error::syntax(format!("unknown special function {name}"))),
    }
}

pub(super) fn gamma(value: f64) -> Result<f64, Error> {
    if value <= 0.0 && value.fract() == 0.0 {
        return Err(Error::MathDomain { function: "GAMMA" });
    }
    if value < 0.5 {
        let sine = (std::f64::consts::PI * value).sin();
        if sine == 0.0 {
            return Err(Error::MathDomain { function: "GAMMA" });
        }
        return Ok(std::f64::consts::PI / (sine * gamma(1.0 - value)?));
    }
    Ok(log_gamma_positive(value).exp())
}

pub(super) fn log_gamma_abs(value: f64) -> Result<f64, Error> {
    if value <= 0.0 && value.fract() == 0.0 {
        return Err(Error::MathDomain { function: "LGAMMA" });
    }
    if value < 0.5 {
        let sine = (std::f64::consts::PI * value).sin().abs();
        if sine == 0.0 {
            return Err(Error::MathDomain { function: "LGAMMA" });
        }
        return Ok(std::f64::consts::PI.ln() - sine.ln() - log_gamma_positive(1.0 - value));
    }
    Ok(log_gamma_positive(value))
}

pub(super) fn log_gamma_positive(value: f64) -> f64 {
    let shifted = value - 1.0;
    let mut series = LANCZOS_COEFFICIENTS[0];
    for (index, coefficient) in LANCZOS_COEFFICIENTS.iter().enumerate().skip(1) {
        series += coefficient / (shifted + index as f64);
    }
    let t = shifted + LANCZOS_G + 0.5;
    0.5 * (2.0 * std::f64::consts::PI).ln() + (shifted + 0.5) * t.ln() - t + series.ln()
}

pub(super) fn erf(value: f64) -> f64 {
    // Abramowitz and Stegun 7.1.26; maximum absolute error about 1.5e-7.
    let sign = if value < 0.0 { -1.0 } else { 1.0 };
    let x = value.abs();
    let t = 1.0 / (1.0 + 0.327_591_1 * x);
    let polynomial =
        (((((1.061_405_429 * t - 1.453_152_027) * t) + 1.421_413_741) * t - 0.284_496_736) * t
            + 0.254_829_592)
            * t;
    sign * (1.0 - polynomial * (-x * x).exp())
}

/// Regularized lower incomplete gamma P(a, x).
pub(super) fn regularized_gamma_p(a: f64, x: f64) -> Result<f64, Error> {
    const MAX_ITERATIONS: usize = 10_000;
    const EPSILON: f64 = 1.0e-14;
    const TINY: f64 = 1.0e-300;

    if a <= 0.0 || x < 0.0 {
        return Err(Error::MathDomain {
            function: "GAMMACDF",
        });
    }
    if x == 0.0 {
        return Ok(0.0);
    }
    let log_scale = a * x.ln() - x - log_gamma_positive(a);
    if x < a + 1.0 {
        let mut sum = 1.0 / a;
        let mut term = sum;
        let mut denominator = a;
        for _ in 1..=MAX_ITERATIONS {
            denominator += 1.0;
            term *= x / denominator;
            sum += term;
            if term.abs() <= sum.abs() * EPSILON {
                return Ok((sum * log_scale.exp()).clamp(0.0, 1.0));
            }
        }
        return Err(Error::IllegalQuantity);
    }

    // Continued fraction for Q(a,x), then return 1-Q.
    let mut b = x + 1.0 - a;
    let mut c = 1.0 / TINY;
    let mut d = 1.0 / b.max(TINY);
    let mut fraction = d;
    for iteration in 1..=MAX_ITERATIONS {
        let index = iteration as f64;
        let numerator = -index * (index - a);
        b += 2.0;
        d = numerator * d + b;
        if d.abs() < TINY {
            d = TINY;
        }
        c = b + numerator / c;
        if c.abs() < TINY {
            c = TINY;
        }
        d = 1.0 / d;
        let delta = d * c;
        fraction *= delta;
        if (delta - 1.0).abs() <= EPSILON {
            let q = log_scale.exp() * fraction;
            return Ok((1.0 - q).clamp(0.0, 1.0));
        }
    }
    Err(Error::IllegalQuantity)
}

#[cfg(test)]
mod tests {
    use super::{erf, gamma, regularized_gamma_p};

    #[test]
    fn special_function_reference_values() {
        assert!((gamma(5.0).unwrap() - 24.0).abs() < 1.0e-10);
        assert!((erf(1.0) - 0.842_700_79).abs() < 2.0e-7);
        assert!(
            (regularized_gamma_p(1.0, 1.0).unwrap() - (1.0 - (-1.0_f64).exp())).abs() < 1.0e-12
        );
    }
}
