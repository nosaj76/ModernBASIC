// Indexed elimination loops intentionally coordinate pivot and mutable rows.
#![allow(clippy::needless_range_loop)]

use crate::error::Error;
use crate::value::Value;

use super::{
    checked_element_count, checked_operations, expect_arity, finite_value, nonnegative_usize,
    real_list, value_list, MAX_MATRIX_ELEMENTS,
};

pub(super) fn evaluate(name: &str, args: &[Value]) -> Result<Value, Error> {
    match name {
        "DOT" => dot(args),
        "CROSS" => cross(args),
        "NORM" => norm(args),
        "NORMALIZE" => normalize(args),
        "TRANSPOSE" => transpose(args),
        "MATMUL" => matmul(args),
        "DET" => determinant_function(args),
        "INVERSE" => inverse_function(args),
        "TRACE" => trace(args),
        "IDENTITY" => filled_matrix(args, MatrixFill::Identity),
        "ZEROS" => filled_matrix(args, MatrixFill::Zero),
        "ONES" => filled_matrix(args, MatrixFill::One),
        "SOLVELINEAR" | "LINSOLVE" => solve_linear_function(args),
        "OUTER" => outer(args),
        "DIAG" => diag(args),
        _ => Err(Error::syntax(format!(
            "unknown linear-algebra function {name}"
        ))),
    }
}

fn dot(args: &[Value]) -> Result<Value, Error> {
    expect_arity("DOT", args, 2, 2)?;
    let left = real_list(&args[0])?;
    let right = real_list(&args[1])?;
    if left.len() != right.len() {
        return Err(Error::MatrixDimensionMismatch);
    }
    checked_operations(left.len())?;
    finite_value(
        left.iter()
            .zip(&right)
            .map(|(left, right)| left * right)
            .sum(),
    )
}

fn cross(args: &[Value]) -> Result<Value, Error> {
    expect_arity("CROSS", args, 2, 2)?;
    let left = real_list(&args[0])?;
    let right = real_list(&args[1])?;
    if left.len() != 3 || right.len() != 3 {
        return Err(Error::MatrixDimensionMismatch);
    }
    value_list([
        left[1] * right[2] - left[2] * right[1],
        left[2] * right[0] - left[0] * right[2],
        left[0] * right[1] - left[1] * right[0],
    ])
}

fn norm(args: &[Value]) -> Result<Value, Error> {
    expect_arity("NORM", args, 1, 1)?;
    let vector = real_list(&args[0])?;
    finite_value(stable_norm(&vector))
}

fn normalize(args: &[Value]) -> Result<Value, Error> {
    expect_arity("NORMALIZE", args, 1, 1)?;
    let vector = real_list(&args[0])?;
    let magnitude = stable_norm(&vector);
    if magnitude == 0.0 {
        return Err(Error::DivideByZero);
    }
    value_list(vector.into_iter().map(|value| value / magnitude))
}

fn transpose(args: &[Value]) -> Result<Value, Error> {
    expect_arity("TRANSPOSE", args, 1, 1)?;
    let matrix = matrix_arg(&args[0])?;
    if matrix.is_empty() {
        return Ok(Value::List(Vec::new()));
    }
    let rows = matrix.len();
    let columns = matrix[0].len();
    checked_element_count(rows.saturating_mul(columns), MAX_MATRIX_ELEMENTS)?;
    let mut result = vec![vec![0.0; rows]; columns];
    for row in 0..rows {
        for column in 0..columns {
            result[column][row] = matrix[row][column];
        }
    }
    matrix_value(result)
}

fn matmul(args: &[Value]) -> Result<Value, Error> {
    expect_arity("MATMUL", args, 2, 2)?;
    let left = matrix_arg(&args[0])?;
    if left.is_empty() {
        return Ok(Value::List(Vec::new()));
    }
    if is_vector(&args[1]) {
        let right = real_list(&args[1])?;
        let left_columns = left[0].len();
        if left_columns != right.len() {
            return Err(Error::MatrixDimensionMismatch);
        }
        checked_operations(
            left.len()
                .checked_mul(left_columns)
                .ok_or(Error::ArrayTooLarge)?,
        )?;
        return value_list(left.iter().map(|row| {
            row.iter()
                .zip(&right)
                .map(|(left, right)| left * right)
                .sum::<f64>()
        }));
    }
    let right = matrix_arg(&args[1])?;
    if right.is_empty() {
        return Ok(Value::List(Vec::new()));
    }
    multiply_matrices(&left, &right).and_then(matrix_value)
}

fn determinant_function(args: &[Value]) -> Result<Value, Error> {
    expect_arity("DET", args, 1, 1)?;
    let matrix = matrix_arg(&args[0])?;
    finite_value(determinant(matrix)?)
}

fn inverse_function(args: &[Value]) -> Result<Value, Error> {
    expect_arity("INVERSE", args, 1, 1)?;
    matrix_value(inverse(matrix_arg(&args[0])?)?)
}

fn trace(args: &[Value]) -> Result<Value, Error> {
    expect_arity("TRACE", args, 1, 1)?;
    let matrix = matrix_arg(&args[0])?;
    let (rows, columns) = dimensions(&matrix);
    if rows != columns {
        return Err(Error::MatrixNotSquare { rows, columns });
    }
    finite_value((0..rows).map(|index| matrix[index][index]).sum())
}

#[derive(Debug, Clone, Copy)]
enum MatrixFill {
    Zero,
    One,
    Identity,
}

fn filled_matrix(args: &[Value], fill: MatrixFill) -> Result<Value, Error> {
    let name = match fill {
        MatrixFill::Zero => "ZEROS",
        MatrixFill::One => "ONES",
        MatrixFill::Identity => "IDENTITY",
    };
    let (rows, columns) = match fill {
        MatrixFill::Identity => {
            expect_arity(name, args, 1, 1)?;
            let size = nonnegative_usize(&args[0])?;
            (size, size)
        }
        MatrixFill::Zero | MatrixFill::One => {
            expect_arity(name, args, 1, 2)?;
            let rows = nonnegative_usize(&args[0])?;
            let columns = args
                .get(1)
                .map(nonnegative_usize)
                .transpose()?
                .unwrap_or(rows);
            (rows, columns)
        }
    };
    let elements = rows.checked_mul(columns).ok_or(Error::ArrayTooLarge)?;
    checked_element_count(elements, MAX_MATRIX_ELEMENTS)?;
    let initial = if matches!(fill, MatrixFill::One) {
        1.0
    } else {
        0.0
    };
    let mut matrix = vec![vec![initial; columns]; rows];
    if matches!(fill, MatrixFill::Identity) {
        for index in 0..rows {
            matrix[index][index] = 1.0;
        }
    }
    matrix_value(matrix)
}

fn solve_linear_function(args: &[Value]) -> Result<Value, Error> {
    expect_arity("SOLVELINEAR", args, 2, 2)?;
    let matrix = matrix_arg(&args[0])?;
    let right = real_list(&args[1])?;
    value_list(solve_linear(matrix, right)?)
}

fn outer(args: &[Value]) -> Result<Value, Error> {
    expect_arity("OUTER", args, 2, 2)?;
    let left = real_list(&args[0])?;
    let right = real_list(&args[1])?;
    let elements = left
        .len()
        .checked_mul(right.len())
        .ok_or(Error::ArrayTooLarge)?;
    checked_element_count(elements, MAX_MATRIX_ELEMENTS)?;
    checked_operations(elements)?;
    matrix_value(
        left.iter()
            .map(|left| right.iter().map(|right| left * right).collect())
            .collect(),
    )
}

fn diag(args: &[Value]) -> Result<Value, Error> {
    expect_arity("DIAG", args, 1, 1)?;
    if is_vector(&args[0]) {
        let vector = real_list(&args[0])?;
        let elements = vector
            .len()
            .checked_mul(vector.len())
            .ok_or(Error::ArrayTooLarge)?;
        checked_element_count(elements, MAX_MATRIX_ELEMENTS)?;
        let mut result = vec![vec![0.0; vector.len()]; vector.len()];
        for (index, value) in vector.into_iter().enumerate() {
            result[index][index] = value;
        }
        matrix_value(result)
    } else {
        let matrix = matrix_arg(&args[0])?;
        let (rows, columns) = dimensions(&matrix);
        value_list((0..rows.min(columns)).map(|index| matrix[index][index]))
    }
}

pub(super) fn matrix_arg(value: &Value) -> Result<Vec<Vec<f64>>, Error> {
    let Value::List(rows) = value else {
        return Err(Error::TypeMismatch);
    };
    if rows.is_empty() {
        return Ok(Vec::new());
    }
    let mut matrix = Vec::with_capacity(rows.len());
    let mut columns = None;
    for row in rows {
        let values = real_list(row)?;
        if let Some(expected) = columns {
            if values.len() != expected {
                return Err(Error::MatrixDimensionMismatch);
            }
        } else {
            columns = Some(values.len());
        }
        matrix.push(values);
    }
    let elements = matrix
        .len()
        .checked_mul(columns.unwrap_or(0))
        .ok_or(Error::ArrayTooLarge)?;
    checked_element_count(elements, MAX_MATRIX_ELEMENTS)?;
    Ok(matrix)
}

pub(super) fn matrix_value(matrix: Vec<Vec<f64>>) -> Result<Value, Error> {
    let elements = matrix
        .len()
        .checked_mul(matrix.first().map(Vec::len).unwrap_or(0))
        .ok_or(Error::ArrayTooLarge)?;
    checked_element_count(elements, MAX_MATRIX_ELEMENTS)?;
    let rows = matrix
        .into_iter()
        .map(|row| {
            row.into_iter()
                .map(finite_value)
                .collect::<Result<Vec<_>, _>>()
                .map(Value::List)
        })
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Value::List(rows))
}

pub(super) fn multiply_matrices(
    left: &[Vec<f64>],
    right: &[Vec<f64>],
) -> Result<Vec<Vec<f64>>, Error> {
    let (left_rows, left_columns) = dimensions(left);
    let (right_rows, right_columns) = dimensions(right);
    if left_columns != right_rows {
        return Err(Error::MatrixDimensionMismatch);
    }
    let elements = left_rows
        .checked_mul(right_columns)
        .ok_or(Error::ArrayTooLarge)?;
    checked_element_count(elements, MAX_MATRIX_ELEMENTS)?;
    checked_operations(
        elements
            .checked_mul(left_columns)
            .ok_or(Error::ArrayTooLarge)?,
    )?;
    let mut result = vec![vec![0.0; right_columns]; left_rows];
    for row in 0..left_rows {
        for column in 0..right_columns {
            let mut sum = 0.0;
            for inner in 0..left_columns {
                sum += left[row][inner] * right[inner][column];
            }
            if !sum.is_finite() {
                return Err(Error::RealOverflow);
            }
            result[row][column] = sum;
        }
    }
    Ok(result)
}

pub(super) fn determinant(mut matrix: Vec<Vec<f64>>) -> Result<f64, Error> {
    let (rows, columns) = dimensions(&matrix);
    if rows != columns {
        return Err(Error::MatrixNotSquare { rows, columns });
    }
    if rows == 0 {
        return Ok(1.0);
    }
    checked_operations(rows.saturating_mul(rows).saturating_mul(rows))?;
    let mut sign = 1.0;
    let mut result = 1.0;
    for pivot_column in 0..rows {
        let pivot_row = (pivot_column..rows)
            .max_by(|left, right| {
                matrix[*left][pivot_column]
                    .abs()
                    .total_cmp(&matrix[*right][pivot_column].abs())
            })
            .unwrap_or(pivot_column);
        if matrix[pivot_row][pivot_column].abs() <= f64::EPSILON {
            return Ok(0.0);
        }
        if pivot_row != pivot_column {
            matrix.swap(pivot_row, pivot_column);
            sign = -sign;
        }
        let pivot = matrix[pivot_column][pivot_column];
        result *= pivot;
        if !result.is_finite() {
            return Err(Error::RealOverflow);
        }
        for row in pivot_column + 1..rows {
            let factor = matrix[row][pivot_column] / pivot;
            for column in pivot_column + 1..rows {
                matrix[row][column] -= factor * matrix[pivot_column][column];
            }
        }
    }
    Ok(sign * result)
}

pub(super) fn inverse(matrix: Vec<Vec<f64>>) -> Result<Vec<Vec<f64>>, Error> {
    let (rows, columns) = dimensions(&matrix);
    if rows != columns {
        return Err(Error::MatrixNotSquare { rows, columns });
    }
    checked_operations(
        rows.saturating_mul(rows)
            .saturating_mul(rows)
            .saturating_mul(2),
    )?;
    let mut augmented = vec![vec![0.0; rows * 2]; rows];
    for row in 0..rows {
        augmented[row][..rows].copy_from_slice(&matrix[row]);
        augmented[row][rows + row] = 1.0;
    }
    for pivot_column in 0..rows {
        let pivot_row = (pivot_column..rows)
            .max_by(|left, right| {
                augmented[*left][pivot_column]
                    .abs()
                    .total_cmp(&augmented[*right][pivot_column].abs())
            })
            .unwrap_or(pivot_column);
        if augmented[pivot_row][pivot_column].abs() <= f64::EPSILON {
            return Err(Error::MathDomain {
                function: "INVERSE",
            });
        }
        augmented.swap(pivot_row, pivot_column);
        let pivot = augmented[pivot_column][pivot_column];
        for column in 0..rows * 2 {
            augmented[pivot_column][column] /= pivot;
        }
        for row in 0..rows {
            if row == pivot_column {
                continue;
            }
            let factor = augmented[row][pivot_column];
            for column in 0..rows * 2 {
                augmented[row][column] -= factor * augmented[pivot_column][column];
            }
        }
    }
    Ok(augmented
        .into_iter()
        .map(|row| row[rows..].to_vec())
        .collect())
}

pub(super) fn solve_linear(
    mut matrix: Vec<Vec<f64>>,
    mut right: Vec<f64>,
) -> Result<Vec<f64>, Error> {
    let (rows, columns) = dimensions(&matrix);
    if rows != columns {
        return Err(Error::MatrixNotSquare { rows, columns });
    }
    if right.len() != rows {
        return Err(Error::MatrixDimensionMismatch);
    }
    checked_operations(rows.saturating_mul(rows).saturating_mul(rows))?;
    for pivot_column in 0..rows {
        let pivot_row = (pivot_column..rows)
            .max_by(|left, right_index| {
                matrix[*left][pivot_column]
                    .abs()
                    .total_cmp(&matrix[*right_index][pivot_column].abs())
            })
            .unwrap_or(pivot_column);
        if matrix[pivot_row][pivot_column].abs() <= f64::EPSILON {
            return Err(Error::MathDomain {
                function: "SOLVELINEAR",
            });
        }
        matrix.swap(pivot_row, pivot_column);
        right.swap(pivot_row, pivot_column);
        for row in pivot_column + 1..rows {
            let factor = matrix[row][pivot_column] / matrix[pivot_column][pivot_column];
            matrix[row][pivot_column] = 0.0;
            for column in pivot_column + 1..rows {
                matrix[row][column] -= factor * matrix[pivot_column][column];
            }
            right[row] -= factor * right[pivot_column];
        }
    }
    let mut result = vec![0.0; rows];
    for row in (0..rows).rev() {
        let known = (row + 1..rows)
            .map(|column| matrix[row][column] * result[column])
            .sum::<f64>();
        result[row] = (right[row] - known) / matrix[row][row];
        if !result[row].is_finite() {
            return Err(Error::RealOverflow);
        }
    }
    Ok(result)
}

fn stable_norm(values: &[f64]) -> f64 {
    let scale = values.iter().map(|value| value.abs()).fold(0.0, f64::max);
    if scale == 0.0 {
        0.0
    } else {
        scale
            * values
                .iter()
                .map(|value| (value / scale).powi(2))
                .sum::<f64>()
                .sqrt()
    }
}

fn dimensions(matrix: &[Vec<f64>]) -> (usize, usize) {
    (matrix.len(), matrix.first().map(Vec::len).unwrap_or(0))
}

fn is_vector(value: &Value) -> bool {
    matches!(value, Value::List(values) if values.iter().all(|value| !matches!(value, Value::List(_))))
}

#[cfg(test)]
mod tests {
    use super::evaluate;
    use crate::value::Value;

    fn matrix(values: &[[i64; 2]; 2]) -> Value {
        Value::List(
            values
                .iter()
                .map(|row| Value::List(row.iter().copied().map(Value::Integer).collect()))
                .collect(),
        )
    }

    #[test]
    fn determinant_inverse_and_solve_are_available() {
        let a = matrix(&[[4, 7], [2, 6]]);
        assert_eq!(
            evaluate("DET", std::slice::from_ref(&a))
                .unwrap()
                .to_string(),
            "10"
        );
        let inverse = evaluate("INVERSE", std::slice::from_ref(&a)).unwrap();
        assert!(matches!(inverse, Value::List(_)));
        let solution = evaluate(
            "SOLVELINEAR",
            &[a, Value::List(vec![Value::Integer(1), Value::Integer(0)])],
        )
        .unwrap();
        assert!(matches!(solution, Value::List(_)));
    }
}
