//! Explicit, bounded access to Linux/host web services.
//!
//! ModernBASIC does not implement TCP, TLS, browser engines, or hardware
//! drivers. HTTP transfers use curl through fixed arguments, and interactive
//! browsing is handed to the operating system's default browser. Programs must
//! receive the network capability explicitly through RunOptions.

use std::io::{Read, Write};
use std::process::{Command, Stdio};

use crate::error::Error;

pub const DEFAULT_MAX_NETWORK_BYTES: usize = 16 * 1_048_576;
pub const MAX_NETWORK_URL_BYTES: usize = 4_096;
const NETWORK_TIMEOUT_SECONDS: u64 = 30;

#[derive(Debug, Clone, Copy)]
pub(crate) enum WebMethod<'a> {
    Get,
    Post {
        body: &'a [u8],
        content_type: &'a str,
    },
}

pub(crate) fn is_http_url(value: &str) -> bool {
    value
        .get(..7)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("http://"))
        || value
            .get(..8)
            .is_some_and(|prefix| prefix.eq_ignore_ascii_case("https://"))
}

pub(crate) fn validate_http_url(url: &str) -> Result<(), Error> {
    if url.is_empty()
        || url.len() > MAX_NETWORK_URL_BYTES
        || url
            .chars()
            .any(|character| character.is_control() || character.is_whitespace())
    {
        return Err(Error::InvalidNetworkUrl);
    }
    let authority = if url
        .get(..7)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("http://"))
    {
        &url[7..]
    } else if url
        .get(..8)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("https://"))
    {
        &url[8..]
    } else {
        return Err(Error::InvalidNetworkUrl);
    };
    let authority = authority
        .split(['/', '?', '#'])
        .next()
        .ok_or(Error::InvalidNetworkUrl)?;
    if authority.is_empty() || authority.contains('@') {
        return Err(Error::InvalidNetworkUrl);
    }
    Ok(())
}

pub(crate) fn fetch(url: &str, method: WebMethod<'_>, max_bytes: usize) -> Result<Vec<u8>, Error> {
    validate_http_url(url)?;
    if max_bytes == 0 {
        return Err(Error::NetworkLimitExceeded { limit: 0 });
    }

    let mut command = Command::new("curl");
    command
        .arg("--disable")
        .arg("--fail")
        .arg("--location")
        .arg("--silent")
        .arg("--show-error")
        .arg("--max-time")
        .arg(NETWORK_TIMEOUT_SECONDS.to_string())
        .arg("--max-filesize")
        .arg(max_bytes.to_string())
        .arg("--proto")
        .arg("=http,https")
        .arg("--proto-redir")
        .arg("=http,https")
        .arg("--user-agent")
        .arg(concat!("ModernBASIC/", env!("CARGO_PKG_VERSION")));

    let post_body = match method {
        WebMethod::Get => None,
        WebMethod::Post { body, content_type } => {
            if content_type.is_empty()
                || content_type.len() > 255
                || content_type.chars().any(|character| character.is_control())
            {
                return Err(Error::syntax("WEB POST content type is invalid"));
            }
            command
                .arg("--request")
                .arg("POST")
                .arg("--header")
                .arg(format!("Content-Type: {content_type}"))
                .arg("--data-binary")
                .arg("@-");
            Some(body)
        }
    };

    command
        .arg(url)
        .stdin(if post_body.is_some() {
            Stdio::piped()
        } else {
            Stdio::null()
        })
        .stdout(Stdio::piped())
        .stderr(Stdio::null());

    let mut child = command
        .spawn()
        .map_err(|error| Error::Io(format!("cannot start curl: {error}")))?;
    if let Some(body) = post_body {
        let Some(mut stdin) = child.stdin.take() else {
            let _ = child.kill();
            let _ = child.wait();
            return Err(Error::Io("cannot open curl request input".into()));
        };
        if let Err(error) = stdin.write_all(body) {
            let _ = child.kill();
            let _ = child.wait();
            return Err(error.into());
        }
    }

    let Some(stdout) = child.stdout.take() else {
        let _ = child.kill();
        let _ = child.wait();
        return Err(Error::Io("cannot open curl response output".into()));
    };
    let take_limit = u64::try_from(max_bytes)
        .unwrap_or(u64::MAX)
        .saturating_add(1);
    let mut bytes = Vec::new();
    if let Err(error) = stdout.take(take_limit).read_to_end(&mut bytes) {
        let _ = child.kill();
        let _ = child.wait();
        return Err(error.into());
    }
    if bytes.len() > max_bytes {
        let _ = child.kill();
        let _ = child.wait();
        return Err(Error::NetworkLimitExceeded { limit: max_bytes });
    }
    let status = child.wait()?;
    if !status.success() {
        return Err(Error::Io(format!("web request failed with {status}")));
    }
    Ok(bytes)
}

pub(crate) fn open_browser(url: &str) -> Result<(), Error> {
    validate_http_url(url)?;
    open_with_host(url)
}

#[cfg(target_os = "windows")]
fn open_with_host(url: &str) -> Result<(), Error> {
    let child = Command::new("cmd")
        .args(["/C", "start", ""])
        .arg(url)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot open web browser: {error}")))?;
    crate::host_process::reap_child(child, "cannot open web browser")
}

#[cfg(target_os = "macos")]
fn open_with_host(url: &str) -> Result<(), Error> {
    let child = Command::new("open")
        .arg(url)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot open web browser: {error}")))?;
    crate::host_process::reap_child(child, "cannot open web browser")
}

#[cfg(all(unix, not(target_os = "macos")))]
fn open_with_host(url: &str) -> Result<(), Error> {
    let child = Command::new("xdg-open")
        .arg(url)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| Error::Io(format!("cannot open web browser: {error}")))?;
    crate::host_process::reap_child(child, "cannot open web browser")
}

#[cfg(not(any(target_os = "windows", target_os = "macos", unix)))]
fn open_with_host(_url: &str) -> Result<(), Error> {
    Err(Error::Io(
        "opening a web browser is unsupported on this platform".into(),
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn accepts_only_bounded_http_urls_without_embedded_credentials() {
        for url in [
            "http://example.com",
            "https://example.com/path?q=1#part",
            "HTTPS://localhost:8443/api",
            "http://[::1]/",
        ] {
            validate_http_url(url).unwrap();
            assert!(is_http_url(url));
        }

        for url in [
            "",
            "ftp://example.com",
            "file:///etc/passwd",
            "https://",
            "https://user:secret@example.com/",
            "https://example.com/a b",
            "https://example.com/\nnext",
        ] {
            assert_eq!(validate_http_url(url), Err(Error::InvalidNetworkUrl));
        }

        let oversized = format!("https://example.com/{}", "a".repeat(MAX_NETWORK_URL_BYTES));
        assert_eq!(validate_http_url(&oversized), Err(Error::InvalidNetworkUrl));
    }
}
