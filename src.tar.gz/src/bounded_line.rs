//! Bounded UTF-8 line reading shared by program loading and runtime input.
//!
//! The standard `BufRead::read_line` grows its destination until a newline is
//! found.  This helper drains an oversized line while retaining at most
//! `limit + 1` bytes, so hostile files and input streams cannot force an
//! unbounded allocation.

use std::io::BufRead;

/// Internal failures produced while reading one physical line.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum BoundedLineError {
    Io(String),
    Interrupted,
    TooLong { limit: usize },
    InvalidUtf8,
}

/// Read one line without its LF or optional preceding CR.
///
/// Returns `Ok(None)` only when EOF is reached before any byte is read.  A line
/// longer than `limit` bytes is fully drained before `TooLong` is returned.
pub(crate) fn read_bounded_line<R: BufRead + ?Sized>(
    reader: &mut R,
    limit: usize,
) -> Result<Option<String>, BoundedLineError> {
    let mut retained = Vec::new();
    let retain_limit = limit.saturating_add(1);
    let mut content_len = 0usize;
    let mut length_overflowed = false;
    let mut saw_any = false;
    let mut last_content_byte = None;

    loop {
        let buffer = reader.fill_buf().map_err(|error| {
            if error.kind() == std::io::ErrorKind::Interrupted {
                BoundedLineError::Interrupted
            } else {
                BoundedLineError::Io(error.to_string())
            }
        })?;
        if buffer.is_empty() {
            if !saw_any {
                return Ok(None);
            }
            break;
        }
        saw_any = true;

        let newline = buffer.iter().position(|&byte| byte == b'\n');
        let content_end = newline.unwrap_or(buffer.len());
        let content = &buffer[..content_end];
        if let Some(&byte) = content.last() {
            last_content_byte = Some(byte);
        }

        if let Some(total) = content_len.checked_add(content.len()) {
            content_len = total;
        } else {
            length_overflowed = true;
        }

        let room = retain_limit.saturating_sub(retained.len());
        let keep = room.min(content.len());
        retained.extend_from_slice(&content[..keep]);

        let consumed = content_end + usize::from(newline.is_some());
        reader.consume(consumed);
        if newline.is_some() {
            break;
        }
    }

    let has_cr = last_content_byte == Some(b'\r');
    let effective_len = content_len.saturating_sub(usize::from(has_cr));
    if length_overflowed || effective_len > limit {
        return Err(BoundedLineError::TooLong { limit });
    }
    if has_cr {
        retained.pop();
    }

    String::from_utf8(retained)
        .map(Some)
        .map_err(|_| BoundedLineError::InvalidUtf8)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{BufReader, Cursor};

    #[test]
    fn reads_lf_crlf_and_final_unterminated_lines() {
        let mut input = BufReader::new(Cursor::new(b"A\nB\r\nC"));
        assert_eq!(
            read_bounded_line(&mut input, 1).unwrap().as_deref(),
            Some("A")
        );
        assert_eq!(
            read_bounded_line(&mut input, 1).unwrap().as_deref(),
            Some("B")
        );
        assert_eq!(
            read_bounded_line(&mut input, 1).unwrap().as_deref(),
            Some("C")
        );
        assert_eq!(read_bounded_line(&mut input, 1).unwrap(), None);
    }

    #[test]
    fn oversized_line_is_drained_before_error() {
        let mut input = BufReader::new(Cursor::new(b"TOO-LONG\nOK\n"));
        assert_eq!(
            read_bounded_line(&mut input, 3).unwrap_err(),
            BoundedLineError::TooLong { limit: 3 }
        );
        assert_eq!(
            read_bounded_line(&mut input, 3).unwrap().as_deref(),
            Some("OK")
        );
    }

    #[test]
    fn empty_line_is_not_eof() {
        let mut input = BufReader::new(Cursor::new(b"\n"));
        assert_eq!(
            read_bounded_line(&mut input, 0).unwrap().as_deref(),
            Some("")
        );
        assert_eq!(read_bounded_line(&mut input, 0).unwrap(), None);
    }

    #[test]
    fn invalid_utf8_is_rejected() {
        let mut input = BufReader::new(Cursor::new([0xff, b'\n']));
        assert_eq!(
            read_bounded_line(&mut input, 8).unwrap_err(),
            BoundedLineError::InvalidUtf8
        );
    }

    struct InterruptedReader;

    impl std::io::Read for InterruptedReader {
        fn read(&mut self, _destination: &mut [u8]) -> std::io::Result<usize> {
            Err(std::io::Error::new(
                std::io::ErrorKind::Interrupted,
                "RUN/STOP",
            ))
        }
    }

    impl BufRead for InterruptedReader {
        fn fill_buf(&mut self) -> std::io::Result<&[u8]> {
            Err(std::io::Error::new(
                std::io::ErrorKind::Interrupted,
                "RUN/STOP",
            ))
        }

        fn consume(&mut self, _amount: usize) {}
    }

    #[test]
    fn interrupted_io_is_preserved_for_run_stop() {
        assert_eq!(
            read_bounded_line(&mut InterruptedReader, 8).unwrap_err(),
            BoundedLineError::Interrupted
        );
    }
}
