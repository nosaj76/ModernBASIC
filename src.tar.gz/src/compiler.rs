//! Native interpreter packaging for stored Modern64BASIC programs.
//!
//! `COMPILE` does not transpile BASIC statements to Rust. It emits a small Rust
//! entry point and a tokenized program image, then
//! asks Cargo/rustc to optimize and statically link that entry point with the
//! ModernBASIC runtime. Keeping statement execution in the shared runtime is
//! deliberate: native executables retain exactly the interpreter-tested
//! semantics for control flow, graphics, sound, files, and future statements,
//! while startup avoids source parsing and tokenization.

use std::ffi::OsStr;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::Command;

use crate::error::Error;
use crate::file_io::DEFAULT_MAX_BINARY_PROGRAM_BYTES;
use crate::program::Program;
use crate::tokens::{tokenize, Token, TokenInstance};

const GENERATED_PACKAGE: &str = "modernbasic_compiled_program";

/// Files produced by one native compilation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CompileArtifacts {
    pub executable: PathBuf,
    pub build_directory: PathBuf,
    pub rust_source: PathBuf,
    pub cargo_manifest: PathBuf,
}

/// Generate a rebuildable Rust project and compile it as an optimized native
/// executable. Cargo invokes rustc with the release profile (`-O`) and links
/// the local `modernbasic` library into the resulting ELF on Linux.
pub fn compile_program(program: &Program, output: &Path) -> Result<CompileArtifacts, Error> {
    let build_directory = derived_build_directory(output)?;
    compile_program_in(program, output, &build_directory)
}

/// Compile using a build directory that has already passed the caller's
/// sandbox path policy.
pub(crate) fn compile_program_in(
    program: &Program,
    output: &Path,
    build_directory: &Path,
) -> Result<CompileArtifacts, Error> {
    let artifacts = generate_build_project_in(program, output, build_directory)?;
    let cargo_target_directory = artifacts.build_directory.join("target");
    let cargo = std::env::var_os("CARGO").unwrap_or_else(|| "cargo".into());
    let result = Command::new(cargo)
        .arg("build")
        .arg("--release")
        .arg("--manifest-path")
        .arg(&artifacts.cargo_manifest)
        .arg("--target-dir")
        .arg(&cargo_target_directory)
        .output()
        .map_err(|error| Error::Io(format!("could not start native Rust compiler: {error}")))?;

    if !result.status.success() {
        let stderr = bounded_diagnostic(&result.stderr);
        let stdout = bounded_diagnostic(&result.stdout);
        let detail = if stderr.trim().is_empty() {
            stdout
        } else {
            stderr
        };
        return Err(Error::Io(format!("native compilation failed:\n{detail}")));
    }

    let built = cargo_target_directory
        .join("release")
        .join(executable_name(GENERATED_PACKAGE));
    fs::copy(&built, &artifacts.executable).map_err(|error| {
        Error::Io(format!(
            "native compiler succeeded but {} could not be installed: {error}",
            artifacts.executable.display()
        ))
    })?;
    Ok(artifacts)
}

/// Emit the permanent source, binary image, and Cargo manifest used by
/// [`compile_program`]. The directory is named `<output>.build` so users can
/// later rebuild it with `cargo build --release`.
pub fn generate_build_project(program: &Program, output: &Path) -> Result<CompileArtifacts, Error> {
    let build_directory = derived_build_directory(output)?;
    generate_build_project_in(program, output, &build_directory)
}

fn generate_build_project_in(
    program: &Program,
    output: &Path,
    build_directory: &Path,
) -> Result<CompileArtifacts, Error> {
    let file_name = output
        .file_name()
        .filter(|name| !name.is_empty())
        .ok_or(Error::InvalidFilePath)?;
    let parent = output.parent().unwrap_or_else(|| Path::new("."));
    let expected_build_directory = parent.join(format!("{}.build", file_name.to_string_lossy()));
    if build_directory != expected_build_directory {
        return Err(Error::InvalidFilePath);
    }
    reject_symlink_components(parent)?;
    reject_symlink_components(build_directory)?;
    ensure_plain_directory(build_directory)?;
    let source_directory = build_directory.join("src");
    reject_symlink_components(&source_directory)?;
    ensure_plain_directory(&source_directory)?;

    let crate_root = Path::new(env!("CARGO_MANIFEST_DIR"));
    let cargo_manifest = build_directory.join("Cargo.toml");
    let rust_source = source_directory.join("main.rs");
    let program_image = source_directory.join("program.m64b");
    let binary = program.to_binary_bytes(DEFAULT_MAX_BINARY_PROGRAM_BYTES)?;

    write_plain_file(
        &cargo_manifest,
        generated_manifest(&toml_string(crate_root.as_os_str())).as_bytes(),
    )?;
    write_plain_file(&rust_source, generated_main(program).as_bytes())?;
    write_plain_file(&program_image, &binary)?;

    Ok(CompileArtifacts {
        executable: output.to_path_buf(),
        build_directory: build_directory.to_path_buf(),
        rust_source,
        cargo_manifest,
    })
}

fn derived_build_directory(output: &Path) -> Result<PathBuf, Error> {
    let file_name = output
        .file_name()
        .filter(|name| !name.is_empty())
        .ok_or(Error::InvalidFilePath)?;
    let parent = output.parent().unwrap_or_else(|| Path::new("."));
    Ok(parent.join(format!("{}.build", file_name.to_string_lossy())))
}

fn reject_symlink_components(path: &Path) -> Result<(), Error> {
    let mut current = PathBuf::new();
    for component in path.components() {
        current.push(component.as_os_str());
        match fs::symlink_metadata(&current) {
            Ok(metadata) if metadata.file_type().is_symlink() => {
                return Err(Error::InvalidFilePath)
            }
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(error.into()),
        }
    }
    Ok(())
}

fn ensure_plain_directory(path: &Path) -> Result<(), Error> {
    match fs::symlink_metadata(path) {
        Ok(metadata) if metadata.file_type().is_symlink() || !metadata.is_dir() => {
            return Err(Error::InvalidFilePath)
        }
        Ok(_) => {}
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => fs::create_dir(path)?,
        Err(error) => return Err(error.into()),
    }
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(Error::InvalidFilePath);
    }
    Ok(())
}

fn write_plain_file(path: &Path, bytes: &[u8]) -> Result<(), Error> {
    match fs::symlink_metadata(path) {
        Ok(metadata) if metadata.file_type().is_symlink() || !metadata.is_file() => {
            return Err(Error::InvalidFilePath)
        }
        Ok(_) => {}
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => return Err(error.into()),
    }
    let mut file = OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(true)
        .open(path)?;
    file.write_all(bytes)?;
    file.flush()?;
    Ok(())
}

fn generated_manifest(crate_path: &str) -> String {
    format!(
        "[package]\nname = \"{GENERATED_PACKAGE}\"\nversion = \"0.1.0\"\nedition = \"2021\"\npublish = false\n\n[dependencies]\nmodernbasic = {{ path = {crate_path} }}\n\n[profile.release]\nopt-level = 3\nlto = \"thin\"\ncodegen-units = 1\nstrip = \"symbols\"\n"
    )
}

fn generated_main(program: &Program) -> String {
    let listing = program
        .list()
        .into_iter()
        .map(|(number, body)| format!("// {number} {}\n", body.replace('\n', " ")))
        .collect::<String>();
    let runtime = if program_uses_graphics(program) {
        "use modernbasic::shell::{run_shell, ShellOptions};\n\
         fn run() -> Result<(), Error> {\n\
             let image = include_bytes!(\"program.m64b\");\n\
             let program = Program::from_binary_bytes(image, image.len())?;\n\
             let working_directory = std::env::current_dir()?;\n\
             let options = RunOptions::modern().with_file_root(working_directory);\n\
             let mut shell = ShellOptions::new(options);\n\
             shell.initial_program_image = Some(program);\n\
             run_shell(shell)\n\
         }\n"
        .to_string()
    } else {
        "use std::io;\n\
         use modernbasic::interpreter::ExecutionSession;\n\
         fn run() -> Result<(), Error> {\n\
             let image = include_bytes!(\"program.m64b\");\n\
             let program = Program::from_binary_bytes(image, image.len())?;\n\
             let working_directory = std::env::current_dir()?;\n\
             let options = RunOptions::modern().with_file_root(working_directory);\n\
             let mut session = ExecutionSession::new(&program, options)?;\n\
             let stdin = io::stdin();\n\
             let stdout = io::stdout();\n\
             let mut input = stdin.lock();\n\
             let mut output = stdout.lock();\n\
             session.run_with_input(&mut input, &mut output)?;\n\
             Ok(())\n\
         }\n"
        .to_string()
    };
    format!(
        "// Generated by Modern64BASIC {}.\n\
         // This is a native-packaged interpreter, not BASIC-to-Rust transpilation.\n\
         // The M64B image is decoded directly; no BASIC source parser runs at startup.\n\
         {listing}\
         use modernbasic::error::Error;\n\
         use modernbasic::interpreter::RunOptions;\n\
         use modernbasic::program::Program;\n\n\
         {runtime}\n\
         fn main() {{\n\
             if let Err(error) = run() {{\n\
                 eprintln!(\"?{{error}}\");\n\
                 std::process::exit(1);\n\
             }}\n\
         }}\n",
        env!("CARGO_PKG_VERSION")
    )
}

fn program_uses_graphics(program: &Program) -> bool {
    program.list().into_iter().any(|(_, body)| {
        tokenize(&body).is_ok_and(|tokens| {
            tokens.iter().enumerate().any(|(index, token)| match token {
                TokenInstance::Ident(name) => {
                    crate::interpreter::is_graphics_statement(name)
                        || matches!(
                            name.as_str(),
                            "VIEW"
                                | "WINDOW"
                                | "PCOPY"
                                | "GRAPH"
                                | "DISPGRAPH"
                                | "SCREENCONTROL"
                                | "SCREENLOCK"
                                | "SCREENUNLOCK"
                        )
                }
                TokenInstance::Keyword(Token::Get | Token::Put) => {
                    matches!(tokens.get(index + 1), Some(TokenInstance::LParen))
                }
                _ => false,
            })
        })
    })
}

fn toml_string(value: &OsStr) -> String {
    let value = value.to_string_lossy();
    let escaped = value.replace('\\', "\\\\").replace('"', "\\\"");
    format!("\"{escaped}\"")
}

fn bounded_diagnostic(bytes: &[u8]) -> String {
    const MAX_DIAGNOSTIC_BYTES: usize = 64 * 1024;
    String::from_utf8_lossy(&bytes[..bytes.len().min(MAX_DIAGNOSTIC_BYTES)]).into_owned()
}

#[cfg(windows)]
fn executable_name(name: &str) -> String {
    format!("{name}.exe")
}

#[cfg(not(windows))]
fn executable_name(name: &str) -> String {
    name.to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};

    fn temp_output(name: &str) -> PathBuf {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        std::env::temp_dir()
            .join(format!(
                "modernbasic-compile-{}-{}",
                std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ))
            .join(name)
    }

    #[test]
    fn generated_project_embeds_binary_program_and_is_rebuildable() {
        let mut program = Program::new();
        program.insert_line(r#"10 PRINT "NATIVE""#).unwrap();
        program.insert_line("20 END").unwrap();
        let output = temp_output("hello");
        fs::create_dir(output.parent().unwrap()).unwrap();
        let artifacts = generate_build_project(&program, &output).unwrap();

        assert!(artifacts.cargo_manifest.is_file());
        assert!(artifacts.rust_source.is_file());
        let image = fs::read(artifacts.build_directory.join("src/program.m64b")).unwrap();
        assert_eq!(
            Program::from_binary_bytes(&image, image.len()).unwrap(),
            program
        );
        let source = fs::read_to_string(&artifacts.rust_source).unwrap();
        assert!(source.contains("ExecutionSession"));
        assert!(source.contains("native-packaged interpreter"));
        assert!(source.contains("// 10 PRINT \"NATIVE\""));

        fs::remove_dir_all(output.parent().unwrap()).unwrap();
    }

    #[test]
    fn generated_graphics_program_opens_the_x11_shell() {
        let mut program = Program::new();
        program.insert_line("10 SCREEN 320,200").unwrap();
        program.insert_line("20 CIRCLE 100,100,20").unwrap();
        program.insert_line("30 END").unwrap();
        let output = temp_output("graphics");
        fs::create_dir(output.parent().unwrap()).unwrap();
        let artifacts = generate_build_project(&program, &output).unwrap();
        let source = fs::read_to_string(&artifacts.rust_source).unwrap();
        assert!(source.contains("run_shell"));
        assert!(source.contains("initial_program_image = Some(program)"));
        assert!(!source.contains("ExecutionSession"));
        fs::remove_dir_all(output.parent().unwrap()).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn generated_project_rejects_symlinked_build_directory() {
        use std::os::unix::fs::symlink;

        let program = Program::new();
        let output = temp_output("escaped");
        let root = output.parent().unwrap();
        fs::create_dir(root).unwrap();
        let outside = temp_output("outside");
        fs::create_dir_all(&outside).unwrap();
        let build_directory = derived_build_directory(&output).unwrap();
        symlink(&outside, &build_directory).unwrap();

        assert_eq!(
            generate_build_project(&program, &output).unwrap_err(),
            Error::InvalidFilePath
        );
        assert!(!outside.join("Cargo.toml").exists());
        assert!(!outside.join("src/main.rs").exists());

        fs::remove_dir_all(root).unwrap();
        fs::remove_dir_all(outside.parent().unwrap()).unwrap();
    }
}
