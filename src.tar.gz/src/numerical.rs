//! Bounded deterministic numerical methods for TI-BASIC-style scalar math.

use crate::error::Error;
use crate::real::BasicReal;

const MAX_INTEGRATION_EVALUATIONS: usize = 1_000_000;
const MAX_REFINEMENT_DEPTH: usize = 20;
const MAX_SEARCH_ITERATIONS: usize = 256;

pub(crate) fn derivative<F>(mut function: F, point: f64, step: f64) -> Result<BasicReal, Error>
where
    F: FnMut(f64) -> Result<f64, Error>,
{
    if !point.is_finite() || !step.is_finite() || step <= 0.0 {
        return Err(Error::IllegalQuantity);
    }
    let upper = function(point + step)?;
    let lower = function(point - step)?;
    BasicReal::new((upper - lower) / (2.0 * step))
}

pub(crate) fn integrate<F>(
    mut function: F,
    lower: f64,
    upper: f64,
    tolerance: f64,
) -> Result<BasicReal, Error>
where
    F: FnMut(f64) -> Result<f64, Error>,
{
    if !lower.is_finite() || !upper.is_finite() || !tolerance.is_finite() || tolerance <= 0.0 {
        return Err(Error::IllegalQuantity);
    }
    if lower == upper {
        return BasicReal::new(0.0);
    }
    let (lower, upper, sign) = if lower < upper {
        (lower, upper, 1.0)
    } else {
        (upper, lower, -1.0)
    };

    let middle = lower + (upper - lower) / 2.0;
    let lower_value = function(lower)?;
    let middle_value = function(middle)?;
    let upper_value = function(upper)?;
    let whole = simpson(lower, upper, lower_value, middle_value, upper_value);
    let mut evaluations = 3;
    let result = adaptive_simpson(
        &mut function,
        lower,
        upper,
        lower_value,
        middle_value,
        upper_value,
        whole,
        tolerance,
        0,
        &mut evaluations,
    )?;
    BasicReal::new(sign * result)
}

#[allow(clippy::too_many_arguments)]
fn adaptive_simpson<F>(
    function: &mut F,
    lower: f64,
    upper: f64,
    lower_value: f64,
    middle_value: f64,
    upper_value: f64,
    whole: f64,
    tolerance: f64,
    depth: usize,
    evaluations: &mut usize,
) -> Result<f64, Error>
where
    F: FnMut(f64) -> Result<f64, Error>,
{
    if depth >= MAX_REFINEMENT_DEPTH || *evaluations + 2 > MAX_INTEGRATION_EVALUATIONS {
        return Err(Error::IllegalQuantity);
    }
    let middle = lower + (upper - lower) / 2.0;
    let left_middle = lower + (middle - lower) / 2.0;
    let right_middle = middle + (upper - middle) / 2.0;
    let left_middle_value = function(left_middle)?;
    let right_middle_value = function(right_middle)?;
    *evaluations += 2;

    let left = simpson(lower, middle, lower_value, left_middle_value, middle_value);
    let right = simpson(middle, upper, middle_value, right_middle_value, upper_value);
    let difference = left + right - whole;
    if difference.abs() <= 15.0 * tolerance {
        return Ok(left + right + difference / 15.0);
    }

    let left_result = adaptive_simpson(
        function,
        lower,
        middle,
        lower_value,
        left_middle_value,
        middle_value,
        left,
        tolerance / 2.0,
        depth + 1,
        evaluations,
    )?;
    let right_result = adaptive_simpson(
        function,
        middle,
        upper,
        middle_value,
        right_middle_value,
        upper_value,
        right,
        tolerance / 2.0,
        depth + 1,
        evaluations,
    )?;
    Ok(left_result + right_result)
}

fn simpson(lower: f64, upper: f64, lower_value: f64, middle_value: f64, upper_value: f64) -> f64 {
    (upper - lower) * (lower_value + 4.0 * middle_value + upper_value) / 6.0
}

#[derive(Debug, Clone, Copy)]
pub(crate) enum Extremum {
    Minimum,
    Maximum,
}

pub(crate) fn extremum<F>(
    mut function: F,
    lower: f64,
    upper: f64,
    tolerance: f64,
    extremum: Extremum,
) -> Result<BasicReal, Error>
where
    F: FnMut(f64) -> Result<f64, Error>,
{
    if !lower.is_finite()
        || !upper.is_finite()
        || lower >= upper
        || !tolerance.is_finite()
        || tolerance <= 0.0
    {
        return Err(Error::IllegalQuantity);
    }
    let ratio = (5.0_f64.sqrt() - 1.0) / 2.0;
    let mut left = lower;
    let mut right = upper;
    let mut first = right - ratio * (right - left);
    let mut second = left + ratio * (right - left);
    let mut first_value = function(first)?;
    let mut second_value = function(second)?;

    for _ in 0..MAX_SEARCH_ITERATIONS {
        if (right - left).abs() <= tolerance {
            return BasicReal::new(left + (right - left) / 2.0);
        }
        let first_preferred = match extremum {
            Extremum::Minimum => first_value <= second_value,
            Extremum::Maximum => first_value >= second_value,
        };
        if first_preferred {
            right = second;
            second = first;
            second_value = first_value;
            first = right - ratio * (right - left);
            first_value = function(first)?;
        } else {
            left = first;
            first = second;
            first_value = second_value;
            second = left + ratio * (right - left);
            second_value = function(second)?;
        }
    }
    Err(Error::IllegalQuantity)
}

pub(crate) fn solve<F>(
    mut function: F,
    lower: f64,
    upper: f64,
    tolerance: f64,
) -> Result<BasicReal, Error>
where
    F: FnMut(f64) -> Result<f64, Error>,
{
    if !lower.is_finite()
        || !upper.is_finite()
        || lower >= upper
        || !tolerance.is_finite()
        || tolerance <= 0.0
    {
        return Err(Error::IllegalQuantity);
    }
    let mut left = lower;
    let mut right = upper;
    let mut left_value = function(left)?;
    let right_value = function(right)?;
    if left_value == 0.0 {
        return BasicReal::new(left);
    }
    if right_value == 0.0 {
        return BasicReal::new(right);
    }
    if left_value.is_sign_positive() == right_value.is_sign_positive() {
        return Err(Error::IllegalQuantity);
    }

    for _ in 0..MAX_SEARCH_ITERATIONS {
        let middle = left + (right - left) / 2.0;
        let middle_value = function(middle)?;
        if middle_value == 0.0 || (right - left).abs() <= tolerance {
            return BasicReal::new(middle);
        }
        if left_value.is_sign_positive() == middle_value.is_sign_positive() {
            left = middle;
            left_value = middle_value;
        } else {
            right = middle;
        }
    }
    Err(Error::IllegalQuantity)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn derivative_integral_extrema_and_root_are_accurate() {
        let derivative = derivative(|x| Ok(x * x), 3.0, 1e-5).unwrap();
        assert!((derivative.value() - 6.0).abs() < 1e-8);

        let integral = integrate(|x| Ok(x * x), 0.0, 3.0, 1e-10).unwrap();
        assert!((integral.value() - 9.0).abs() < 1e-10);
        let reverse = integrate(|x| Ok(x * x), 3.0, 0.0, 1e-10).unwrap();
        assert!((reverse.value() + 9.0).abs() < 1e-10);

        let minimum = extremum(
            |x| Ok((x - 2.0).powi(2)),
            -10.0,
            10.0,
            1e-10,
            Extremum::Minimum,
        )
        .unwrap();
        assert!((minimum.value() - 2.0).abs() < 1e-8);
        let maximum = extremum(
            |x| Ok(-(x - 2.0).powi(2)),
            -10.0,
            10.0,
            1e-10,
            Extremum::Maximum,
        )
        .unwrap();
        assert!((maximum.value() - 2.0).abs() < 1e-8);

        let root = solve(|x| Ok(x * x - 2.0), 0.0, 2.0, 1e-12).unwrap();
        assert!((root.value() - 2.0_f64.sqrt()).abs() < 1e-10);
    }

    #[test]
    fn invalid_bounds_tolerances_and_brackets_are_rejected() {
        assert_eq!(
            derivative(Ok::<f64, Error>, 0.0, 0.0).unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            integrate(Ok::<f64, Error>, 0.0, 1.0, 0.0).unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            extremum(Ok::<f64, Error>, 1.0, 0.0, 1e-8, Extremum::Minimum,).unwrap_err(),
            Error::IllegalQuantity
        );
        assert_eq!(
            solve(|x| Ok(x * x + 1.0), -1.0, 1.0, 1e-8).unwrap_err(),
            Error::IllegalQuantity
        );
    }
}
