//! Native runtime input support.
//!
//! This module handles bounded line reading, INPUT-field conversion, and raw
//! byte reads for `GET`.  It intentionally contains no terminal, device, 6502
//! buffer, or memory-map emulation; callers provide any `BufRead` source.

use std::io::BufRead;

use crate::bounded_line::{read_bounded_line, BoundedLineError};
use crate::data::{parse_numeric_value_field, parse_string_field, split_comma_fields};
use crate::error::Error;
use crate::integer::{BasicInteger, NumericMode};
use crate::value::Value;

/// Maximum bytes in one runtime input line in modern mode.
pub const DEFAULT_MAX_INPUT_BYTES: usize = 1_048_576;
/// Historical-sized runtime input line limit in legacy mode.
pub const LEGACY_MAX_INPUT_BYTES: usize = 255;
/// Maximum physical lines one INPUT statement may consume.
pub const DEFAULT_MAX_INPUT_LINES: usize = 100;

/// Read one bounded runtime input line.
pub(crate) fn read_input_line<R: BufRead + ?Sized>(
    reader: &mut R,
    max_bytes: usize,
    statement_line: u64,
) -> Result<Option<String>, Error> {
    read_bounded_line(reader, max_bytes).map_err(|error| match error {
        BoundedLineError::Io(message) => Error::Io(message),
        BoundedLineError::Interrupted => Error::Break,
        BoundedLineError::TooLong { limit } => Error::InputLineTooLong {
            line: statement_line,
            limit,
        },
        BoundedLineError::InvalidUtf8 => Error::BadInput {
            line: statement_line,
        },
    })
}

/// Read exactly one raw byte for a native `GET` statement.
pub(crate) fn read_get_byte<R: BufRead + ?Sized>(
    reader: &mut R,
    statement_line: u64,
) -> Result<u8, Error> {
    let byte = {
        let buffer = reader.fill_buf().map_err(|error| {
            if error.kind() == std::io::ErrorKind::Interrupted {
                Error::Break
            } else {
                Error::Io(error.to_string())
            }
        })?;
        buffer.first().copied().ok_or(Error::EndOfInput {
            line: statement_line,
        })?
    };
    reader.consume(1);
    Ok(byte)
}

/// Convert one historical byte-sized `GET` value for its destination type.
///
/// String destinations map bytes `1..=255` to the corresponding Unicode code
/// point, matching `CHR$`/`ASC`; a NUL byte represents the historical empty
/// "no key" value. Numeric destinations accept one ASCII digit, plus NUL or
/// space as zero.
pub(crate) fn convert_get_byte(
    byte: u8,
    string_destination: bool,
    mode: NumericMode,
    max_string_bytes: usize,
    statement_line: u64,
) -> Result<Value, Error> {
    if string_destination {
        let text = if byte == 0 {
            String::new()
        } else {
            char::from(byte).to_string()
        };
        if text.len() > max_string_bytes {
            return Err(Error::StringTooLong {
                length: text.len(),
                limit: max_string_bytes,
            });
        }
        return Ok(Value::String(text));
    }

    let value = match byte {
        0 | b' ' => 0,
        b'0'..=b'9' => i64::from(byte - b'0'),
        _ => {
            return Err(Error::BadInput {
                line: statement_line,
            })
        }
    };
    Ok(Value::Integer(
        BasicInteger::with_mode(mode, value)?.value(),
    ))
}

/// Split an INPUT line on commas outside quotes.
pub(crate) fn split_input_fields(line: &str) -> Vec<String> {
    split_comma_fields(line)
}

/// Convert one input field according to its destination variable type.
pub(crate) fn convert_input_field(
    field: &str,
    string_destination: bool,
    mode: NumericMode,
    max_string_bytes: usize,
) -> Result<Value, Error> {
    if string_destination {
        parse_string_field(field, max_string_bytes).map(Value::String)
    } else {
        parse_numeric_value_field(field, mode)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{BufReader, Cursor};

    #[test]
    fn quoted_commas_remain_in_one_field() {
        assert_eq!(
            split_input_fields(r#""A,B", 2"#),
            vec![r#""A,B""#.to_string(), " 2".to_string()]
        );
    }

    #[test]
    fn conversions_follow_destination_type() {
        assert_eq!(
            convert_input_field("42", false, NumericMode::Modern, 255).unwrap(),
            Value::Integer(42)
        );
        assert_eq!(
            convert_input_field(r#"" A ""#, true, NumericMode::Modern, 255).unwrap(),
            Value::String(" A ".to_string())
        );
    }

    #[test]
    fn runtime_line_limit_is_structured() {
        let mut input = BufReader::new(Cursor::new(b"1234\n"));
        assert_eq!(
            read_input_line(&mut input, 3, 20).unwrap_err(),
            Error::InputLineTooLong { line: 20, limit: 3 }
        );
    }

    struct InterruptedReader;

    impl std::io::Read for InterruptedReader {
        fn read(&mut self, _destination: &mut [u8]) -> std::io::Result<usize> {
            Err(std::io::Error::new(
                std::io::ErrorKind::Interrupted,
                "RUN/STOP",
            ))
        }
    }

    impl BufRead for InterruptedReader {
        fn fill_buf(&mut self) -> std::io::Result<&[u8]> {
            Err(std::io::Error::new(
                std::io::ErrorKind::Interrupted,
                "RUN/STOP",
            ))
        }

        fn consume(&mut self, _amount: usize) {}
    }

    #[test]
    fn run_stop_interrupts_input_instead_of_submitting_an_empty_field() {
        assert_eq!(
            read_input_line(&mut InterruptedReader, 255, 10).unwrap_err(),
            Error::Break
        );
    }

    #[test]
    fn run_stop_interrupts_get_instead_of_returning_a_control_byte() {
        assert_eq!(
            read_get_byte(&mut InterruptedReader, 10).unwrap_err(),
            Error::Break
        );
    }

    #[test]
    fn get_reads_raw_bytes_without_line_buffering() {
        let mut input = BufReader::new(Cursor::new([b'A', b'\n']));
        assert_eq!(read_get_byte(&mut input, 10).unwrap(), b'A');
        assert_eq!(read_get_byte(&mut input, 10).unwrap(), b'\n');
        assert_eq!(
            read_get_byte(&mut input, 10).unwrap_err(),
            Error::EndOfInput { line: 10 }
        );
    }

    #[test]
    fn get_conversion_preserves_bytes_and_checks_numeric_input() {
        assert_eq!(
            convert_get_byte(0xff, true, NumericMode::Modern, 2, 20).unwrap(),
            Value::String("ÿ".to_string())
        );
        assert_eq!(
            convert_get_byte(b'7', false, NumericMode::Modern, 2, 20).unwrap(),
            Value::Integer(7)
        );
        assert_eq!(
            convert_get_byte(b'X', false, NumericMode::Modern, 2, 20).unwrap_err(),
            Error::BadInput { line: 20 }
        );
    }
}
