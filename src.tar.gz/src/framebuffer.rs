/// ScreenBuffer — backing store for the graphics framebuffer.
///
/// Complements TextGrid (which handles text cells) by managing the
/// pixel-level graphics layer. Provides:
///   - Explicit (x, y) pixel writes
///   - Dirty-rect tracking for efficient partial redraws
///   - Snapshot/restore for PCOPY-style operations
///   - Overlap-preserving resize

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ScreenBuffer {
    pub width: usize,
    pub height: usize,
    /// ARGB pixel data (0xAARRGGBB), row-major
    pub pixels: Vec<u32>,
    /// Dirty region: (x, y, w, h) — bounding box of changes since last reset
    dirty: Option<(usize, usize, usize, usize)>,
    /// Background fill color for new/cleared regions
    pub clear_color: u32,
}

impl ScreenBuffer {
    pub fn new(width: usize, height: usize, clear_color: u32) -> Self {
        let Some(pixel_count) = width.checked_mul(height) else {
            return Self {
                width: 0,
                height: 0,
                pixels: Vec::new(),
                dirty: None,
                clear_color,
            };
        };
        Self {
            width,
            height,
            pixels: vec![clear_color; pixel_count],
            dirty: None,
            clear_color,
        }
    }

    /// Set a single pixel. Tracks dirty rect.
    pub fn set_pixel(&mut self, x: usize, y: usize, color: u32) {
        if x < self.width && y < self.height {
            let Some(pixel) = y
                .checked_mul(self.width)
                .and_then(|row| row.checked_add(x))
                .and_then(|index| self.pixels.get_mut(index))
            else {
                return;
            };
            if *pixel != color {
                *pixel = color;
                self.mark_dirty(x, y, 1, 1);
            }
        }
    }

    /// Get a pixel value
    pub fn get_pixel(&self, x: usize, y: usize) -> u32 {
        if x < self.width && y < self.height {
            y.checked_mul(self.width)
                .and_then(|row| row.checked_add(x))
                .and_then(|index| self.pixels.get(index))
                .copied()
                .unwrap_or(0)
        } else {
            0
        }
    }

    /// Fill entire buffer with clear_color
    pub fn clear(&mut self) {
        self.pixels.fill(self.clear_color);
        self.dirty = Some((0, 0, self.width, self.height));
    }

    /// Fill a rectangular region
    pub fn fill_rect(&mut self, x: usize, y: usize, w: usize, h: usize, color: u32) {
        let x1 = x.min(self.width);
        let y1 = y.min(self.height);
        let x2 = x.saturating_add(w).min(self.width);
        let y2 = y.saturating_add(h).min(self.height);
        for py in y1..y2 {
            for px in x1..x2 {
                if let Some(pixel) = py
                    .checked_mul(self.width)
                    .and_then(|row| row.checked_add(px))
                    .and_then(|index| self.pixels.get_mut(index))
                {
                    *pixel = color;
                }
            }
        }
        if x2 > x1 && y2 > y1 {
            self.mark_dirty(x1, y1, x2 - x1, y2 - y1);
        }
    }

    /// Get the dirty region since last reset. Returns None if clean.
    pub fn dirty_rect(&self) -> Option<(usize, usize, usize, usize)> {
        self.dirty
    }

    /// Check if any pixels changed since last reset
    pub fn is_dirty(&self) -> bool {
        self.dirty.is_some()
    }

    /// Reset dirty tracking (call after presenting to screen)
    pub fn reset_dirty(&mut self) {
        self.dirty = None;
    }

    /// Take a snapshot (for PCOPY)
    pub fn snapshot(&self) -> Vec<u32> {
        self.pixels.clone()
    }

    /// Restore from a snapshot
    pub fn restore(&mut self, snapshot: &[u32]) {
        let copy_len = snapshot.len().min(self.pixels.len());
        self.pixels[..copy_len].copy_from_slice(&snapshot[..copy_len]);
        self.dirty = Some((0, 0, self.width, self.height));
    }

    /// Resize preserving content where possible.
    /// New regions filled with clear_color.
    pub fn resize(&mut self, new_w: usize, new_h: usize) {
        if new_w == self.width && new_h == self.height {
            return;
        }

        let Some(pixel_count) = new_w.checked_mul(new_h) else {
            return;
        };
        let mut new_pixels = vec![self.clear_color; pixel_count];
        let copy_w = self.width.min(new_w);
        let copy_h = self.height.min(new_h);
        for y in 0..copy_h {
            let Some(src_start) = y.checked_mul(self.width) else {
                break;
            };
            let Some(dst_start) = y.checked_mul(new_w) else {
                break;
            };
            let Some(src_end) = src_start.checked_add(copy_w) else {
                break;
            };
            let Some(dst_end) = dst_start.checked_add(copy_w) else {
                break;
            };
            let (Some(source), Some(destination)) = (
                self.pixels.get(src_start..src_end),
                new_pixels.get_mut(dst_start..dst_end),
            ) else {
                break;
            };
            destination.copy_from_slice(source);
        }
        self.pixels = new_pixels;
        self.width = new_w;
        self.height = new_h;
        self.dirty = Some((0, 0, new_w, new_h));
    }

    /// Blit another buffer on top at an offset (for sprite compositing etc.)
    pub fn blit(&mut self, src: &[u32], src_w: usize, src_h: usize, dst_x: usize, dst_y: usize) {
        let Some(src_len) = src_w.checked_mul(src_h) else {
            return;
        };
        if src.len() < src_len || dst_x >= self.width || dst_y >= self.height {
            return;
        }
        let copy_w = src_w.min(self.width - dst_x);
        let copy_h = src_h.min(self.height - dst_y);
        if copy_w == 0 || copy_h == 0 {
            return;
        }

        for sy in 0..copy_h {
            let Some(dy) = dst_y.checked_add(sy) else {
                break;
            };
            for sx in 0..copy_w {
                let Some(dx) = dst_x.checked_add(sx) else {
                    break;
                };
                let Some(pixel) = sy
                    .checked_mul(src_w)
                    .and_then(|row| row.checked_add(sx))
                    .and_then(|index| src.get(index))
                    .copied()
                else {
                    return;
                };
                // Alpha-only transparency
                if pixel >> 24 != 0 {
                    if let Some(destination) = dy
                        .checked_mul(self.width)
                        .and_then(|row| row.checked_add(dx))
                        .and_then(|index| self.pixels.get_mut(index))
                    {
                        *destination = pixel;
                    }
                }
            }
        }
        self.mark_dirty(dst_x, dst_y, copy_w, copy_h);
    }

    /// Copy an opaque device-space raster with one slice copy per scanline.
    /// Graphics PUT has already resolved clipping, alpha, and raster actions,
    /// so repeating per-pixel bounds checks and dirty-rectangle expansion here
    /// only wastes frame time.
    pub fn blit_opaque(
        &mut self,
        src: &[u32],
        src_w: usize,
        src_h: usize,
        dst_x: usize,
        dst_y: usize,
    ) {
        let Some(src_len) = src_w.checked_mul(src_h) else {
            return;
        };
        if src.len() < src_len || dst_x >= self.width || dst_y >= self.height {
            return;
        }
        let copy_w = src_w.min(self.width - dst_x);
        let copy_h = src_h.min(self.height - dst_y);
        if copy_w == 0 || copy_h == 0 {
            return;
        }
        for row in 0..copy_h {
            let source_start = row * src_w;
            let destination_start = (dst_y + row) * self.width + dst_x;
            self.pixels[destination_start..destination_start + copy_w]
                .copy_from_slice(&src[source_start..source_start + copy_w]);
        }
        self.mark_dirty(dst_x, dst_y, copy_w, copy_h);
    }

    /// Expand dirty rect to include a new region
    fn mark_dirty(&mut self, x: usize, y: usize, w: usize, h: usize) {
        self.dirty = Some(match self.dirty {
            None => (x, y, w, h),
            Some((dx, dy, dw, dh)) => {
                let nx = dx.min(x);
                let ny = dy.min(y);
                let nx2 = dx.saturating_add(dw).max(x.saturating_add(w));
                let ny2 = dy.saturating_add(dh).max(y.saturating_add(h));
                (nx, ny, nx2 - nx, ny2 - ny)
            }
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn overflowing_dimensions_degrade_to_an_empty_buffer() {
        let buffer = ScreenBuffer::new(usize::MAX, 2, 0xff00_0000);
        assert_eq!(buffer.width, 0);
        assert_eq!(buffer.height, 0);
        assert!(buffer.pixels.is_empty());
    }

    #[test]
    fn oversized_rectangles_are_clamped_without_overflow() {
        let mut buffer = ScreenBuffer::new(2, 2, 0);
        buffer.fill_rect(1, 1, usize::MAX, usize::MAX, 7);
        assert_eq!(buffer.pixels, vec![0, 0, 0, 7]);
        assert_eq!(buffer.dirty_rect(), Some((1, 1, 1, 1)));
    }

    #[test]
    fn blit_rejects_short_sources_and_out_of_range_destinations() {
        let mut buffer = ScreenBuffer::new(2, 2, 0);
        buffer.blit(&[0xffff_ffff], 2, 2, 0, 0);
        buffer.blit(&[0xffff_ffff], 1, 1, usize::MAX, usize::MAX);
        assert_eq!(buffer.pixels, vec![0; 4]);
        assert!(!buffer.is_dirty());
    }

    #[test]
    fn blit_clamps_to_the_destination_edges() {
        let mut buffer = ScreenBuffer::new(2, 2, 0);
        buffer.blit(&[0xff00_0001, 2, 0xffff_ffff, 0xff12_3456], 2, 2, 1, 1);
        assert_eq!(buffer.pixels, vec![0, 0, 0, 0xff00_0001]);
        assert_eq!(buffer.dirty_rect(), Some((1, 1, 1, 1)));
    }

    #[test]
    fn opaque_blits_copy_scanlines_and_track_one_dirty_region() {
        let mut buffer = ScreenBuffer::new(4, 3, 0);
        buffer.blit_opaque(&[1, 2, 3, 4], 2, 2, 1, 1);
        assert_eq!(buffer.pixels, vec![0, 0, 0, 0, 0, 1, 2, 0, 0, 3, 4, 0]);
        assert_eq!(buffer.dirty_rect(), Some((1, 1, 2, 2)));
    }

    #[test]
    fn resize_ignores_overflowing_dimensions() {
        let mut buffer = ScreenBuffer::new(2, 2, 3);
        buffer.resize(usize::MAX, 2);
        assert_eq!((buffer.width, buffer.height), (2, 2));
        assert_eq!(buffer.pixels, vec![3; 4]);
    }
}
