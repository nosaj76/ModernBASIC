//! Interactive numbered-program editor and execution environment.

use std::fs::{self, File};
use std::io::{BufRead, BufReader, Write};
use std::path::{Component, Path, PathBuf};

use crate::bounded_line::{read_bounded_line, BoundedLineError};
use crate::error::Error;
use crate::file_io::DEFAULT_MAX_FILE_BYTES;
use crate::interpreter::{ExecutionSession, RunOptions, SessionResult, SessionState};
use crate::program::{Program, DEFAULT_MAX_SOURCE_LINE_BYTES, MAX_BASIC_LINE_NUMBER};

const REPL_HELP: &str = r#"Commands:
  <number> <statement>  insert or replace a program line
  <number>              delete a program line
  LIST [n|n-m|-m|n-]    list all or part of the program
  DELETE n|n-m|-m|n-    delete stored program lines
  RENUM [new],[old],[inc] renumber lines and references
  RUN [number]          run the program, optionally at a line
  STEP [count]          execute one or more stored statements, then pause
  CONT                  continue after STOP
  LOAD <file.bas>       replace the program with a source file
  SAVE <file.bas>       save canonical BASIC source
  LOADB <file.m64b>     replace the program from tokenized binary
  SAVEB <file.m64b>     save a tokenized binary program
  COMPILE <output>      build a standalone optimized native executable
  MERGE <file.bas>      merge numbered lines into the program
  VERIFY <file.bas>     compare a file with canonical program source
  OLD                   restore the program replaced by NEW/LOAD
  AUTO [start],[step]   enter automatic line-number mode
  EDIT <number>         replace one stored line body
  STATUS / LENGTH       report environment/program status
  DIR [path]            group subfolders, .bas programs, then other files
  DIR <pattern>         list only matching files, such as DIR *.DAT
  DIR /S [path]         recursively list every file and subfolder
  TREE [path]           recursively browse a directory (bounded)
  CD [path]             change/print the current directory
  CHDIR [path]          alias for CD
  CD / or CD \          return to the BASIC root; CD .. moves to parent
  Visible paths start at programs; host paths remain hidden
  Paths match host names case-insensitively inside the BASIC root
  PWD                   print the BASIC-visible directory
  MKDIR / RMDIR         create/remove an empty directory
  KILL <file>           delete a sandboxed file
  NAME old AS new       rename a sandboxed path
  COPY source AS dest   copy a sandboxed file
  NEW                   clear the program
  <statement>           execute any BASIC statement immediately
  PRINT <items>         direct-mode BASIC PRINT, including ',' and ';'
  LET/DIM/INPUT/...     direct statements retain variables and arrays
  EVAL <expression>     evaluate through direct-mode PRINT
  HELP                  show these commands
  QUIT                  leave ModernBASIC"#;
const MAX_REPL_STEP_COUNT: usize = 1_000_000;

const MAX_DIRECTORY_BROWSER_ENTRIES: usize = 100_000;
const MAX_DIRECTORY_TREE_DEPTH: usize = 64;
const BASIC_ROOT_NAME: &str = "programs";

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum BrowserEntryKind {
    Directory,
    File,
    Link,
    Other,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum BrowserEntryGroup {
    Folder,
    BasicProgram,
    OtherFile,
}

impl BrowserEntryGroup {
    fn for_entry(entry: &BrowserEntry) -> Self {
        if entry.kind == BrowserEntryKind::Directory {
            Self::Folder
        } else if entry.kind == BrowserEntryKind::File && is_basic_program(&entry.name) {
            Self::BasicProgram
        } else {
            Self::OtherFile
        }
    }

    fn heading(self) -> &'static str {
        match self {
            Self::Folder => "DIRECTORY FOLDERS",
            Self::BasicProgram => "BASIC PROGRAMS",
            Self::OtherFile => "OTHER FILES",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct BrowserEntry {
    path: PathBuf,
    name: String,
    kind: BrowserEntryKind,
    bytes: u64,
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
struct DirectorySummary {
    files: usize,
    directories: usize,
    links: usize,
    other: usize,
    bytes: u64,
}

impl DirectorySummary {
    fn include(&mut self, entry: &BrowserEntry) {
        match entry.kind {
            BrowserEntryKind::Directory => self.directories += 1,
            BrowserEntryKind::File => {
                self.files += 1;
                self.bytes = self.bytes.saturating_add(entry.bytes);
            }
            BrowserEntryKind::Link => self.links += 1,
            BrowserEntryKind::Other => self.other += 1,
        }
    }

    fn write<W: Write>(&self, output: &mut W) -> Result<(), Error> {
        writeln!(output, "{} FILE(S), {} BYTE(S)", self.files, self.bytes)?;
        writeln!(output, "{} DIR(S)", self.directories)?;
        if self.links > 0 || self.other > 0 {
            writeln!(
                output,
                "{} LINK(S), {} OTHER ITEM(S)",
                self.links, self.other
            )?;
        }
        Ok(())
    }
}

pub(crate) struct ReplFilesystem {
    root: PathBuf,
    cwd: PathBuf,
}

impl ReplFilesystem {
    pub(crate) fn new(configured_root: Option<&Path>) -> Result<Self, Error> {
        let root = fs::canonicalize(match configured_root {
            Some(root) => root.to_path_buf(),
            None => std::env::current_dir()?,
        })?;
        if !root.is_dir() {
            return Err(Error::InvalidFilePath);
        }
        Ok(Self {
            cwd: root.clone(),
            root,
        })
    }

    pub(crate) fn display_cwd<W: Write>(&self, output: &mut W) -> Result<(), Error> {
        writeln!(output, "CURRENT DIRECTORY {}", self.basic_path(&self.cwd)?)?;
        Ok(())
    }

    pub(crate) fn basic_path(&self, path: &Path) -> Result<String, Error> {
        let relative = path
            .strip_prefix(&self.root)
            .map_err(|_| Error::InvalidFilePath)?;
        if relative.as_os_str().is_empty() {
            return Ok(BASIC_ROOT_NAME.to_string());
        }
        Ok(format!(
            "{BASIC_ROOT_NAME}/{}",
            relative.to_string_lossy().replace('\\', "/")
        ))
    }

    pub(crate) fn cwd(&self) -> &Path {
        &self.cwd
    }

    pub(crate) fn existing_path(&self, argument: &str) -> Result<PathBuf, Error> {
        let requested = unquote_path(argument)?;
        self.resolve_existing_request(&requested)
    }

    pub(crate) fn output_path(&self, argument: &str) -> Result<PathBuf, Error> {
        let requested = unquote_path(argument)?;
        let parent_request = requested.parent().ok_or(Error::InvalidFilePath)?;
        let parent = if parent_request.as_os_str().is_empty() {
            self.cwd.clone()
        } else {
            self.resolve_existing_request(parent_request)?
        };
        if !parent.is_dir() {
            return Err(Error::InvalidFilePath);
        }
        let name = requested.file_name().ok_or(Error::InvalidFilePath)?;
        if let Some(existing) = self.case_insensitive_child(&parent, name)? {
            return self.checked_canonical(existing);
        }
        Ok(parent.join(name))
    }

    fn resolve_existing_request(&self, requested: &Path) -> Result<PathBuf, Error> {
        if requested.is_absolute() {
            if let Ok(canonical) = fs::canonicalize(requested) {
                if let Ok(checked) = self.checked_path(canonical) {
                    return Ok(checked);
                }
            }
            let relative = requested
                .strip_prefix(&self.root)
                .or_else(|_| requested.strip_prefix(Path::new("/")))
                .map_err(|_| Error::InvalidFilePath)?;
            let relative = basic_root_relative(relative).unwrap_or_else(|| relative.to_path_buf());
            return self.resolve_components(&self.root, &relative);
        }
        if let Some(relative) = basic_root_relative(requested) {
            return self.resolve_components(&self.root, &relative);
        }
        self.resolve_components(&self.cwd, requested)
    }

    fn resolve_components(&self, start: &Path, relative: &Path) -> Result<PathBuf, Error> {
        let mut current = self.checked_canonical(start)?;
        for component in relative.components() {
            current = match component {
                Component::CurDir => current,
                Component::ParentDir => {
                    if current == self.root {
                        current
                    } else {
                        let parent = current.parent().ok_or(Error::InvalidFilePath)?;
                        self.checked_canonical(parent)?
                    }
                }
                Component::Normal(name) => {
                    let visible_directory = self.basic_path(&current)?;
                    let child = self
                        .case_insensitive_child(&current, name)?
                        .ok_or_else(|| {
                            Error::Io(format!(
                                "path not found: {visible_directory}/{}",
                                name.to_string_lossy()
                            ))
                        })?;
                    self.checked_canonical(child)?
                }
                Component::RootDir | Component::Prefix(_) => return Err(Error::InvalidFilePath),
            };
        }
        Ok(current)
    }

    fn case_insensitive_child(
        &self,
        directory: &Path,
        requested: &std::ffi::OsStr,
    ) -> Result<Option<PathBuf>, Error> {
        let exact = directory.join(requested);
        if fs::symlink_metadata(&exact).is_ok() {
            return Ok(Some(exact));
        }
        let requested = requested.to_string_lossy();
        let mut found = None;
        for entry in fs::read_dir(directory)? {
            let entry = entry?;
            if !entry
                .file_name()
                .to_string_lossy()
                .eq_ignore_ascii_case(&requested)
            {
                continue;
            }
            if found.is_some() {
                return Err(Error::InvalidFilePath);
            }
            found = Some(entry.path());
        }
        Ok(found)
    }

    fn checked_canonical(&self, path: impl AsRef<Path>) -> Result<PathBuf, Error> {
        self.checked_path(fs::canonicalize(path)?)
    }

    fn checked_path(&self, path: PathBuf) -> Result<PathBuf, Error> {
        if !path.starts_with(&self.root) {
            return Err(Error::InvalidFilePath);
        }
        Ok(path)
    }

    fn make_dir(&self, argument: &str) -> Result<(), Error> {
        fs::create_dir(self.output_path(argument)?)?;
        Ok(())
    }

    fn remove_dir(&self, argument: &str) -> Result<(), Error> {
        let target = self.existing_path(argument)?;
        if target == self.root || target == self.cwd || !target.is_dir() {
            return Err(Error::InvalidFilePath);
        }
        fs::remove_dir(target)?;
        Ok(())
    }

    pub(crate) fn kill(&self, argument: &str) -> Result<(), Error> {
        let target = self.existing_path(argument)?;
        if !target.is_file() {
            return Err(Error::InvalidFilePath);
        }
        fs::remove_file(target)?;
        Ok(())
    }

    fn rename(&self, argument: &str) -> Result<(), Error> {
        let upper = argument.to_ascii_uppercase();
        let Some(split_at) = upper.find(" AS ") else {
            return Err(Error::syntax("NAME expects old-path AS new-path"));
        };
        let source = self.existing_path(&argument[..split_at])?;
        let destination = self.output_path(&argument[split_at + 4..])?;
        fs::rename(source, destination)?;
        Ok(())
    }

    fn copy(&self, argument: &str) -> Result<(), Error> {
        let upper = argument.to_ascii_uppercase();
        let split_at = upper
            .find(" AS ")
            .or_else(|| upper.find(" TO "))
            .ok_or_else(|| Error::syntax("COPY expects source AS destination"))?;
        let source = self.existing_path(&argument[..split_at])?;
        let destination = self.output_path(&argument[split_at + 4..])?;
        if !source.is_file() {
            return Err(Error::InvalidFilePath);
        }
        fs::copy(source, destination)?;
        Ok(())
    }

    pub(crate) fn change_dir(&mut self, argument: &str) -> Result<(), Error> {
        if argument.trim().is_empty() {
            return Ok(());
        }
        let canonical = self.existing_path(argument)?;
        if !canonical.is_dir() || !canonical.starts_with(&self.root) {
            return Err(Error::InvalidFilePath);
        }
        self.cwd = canonical;
        Ok(())
    }

    pub(crate) fn list<W: Write>(&self, argument: &str, output: &mut W) -> Result<(), Error> {
        let raw = argument.trim();
        let (directory, pattern, grouped_default) = if raw.is_empty() {
            (self.cwd.clone(), "*".to_string(), true)
        } else {
            let requested = unquote_path(raw)?;
            if requested.file_name().is_none() {
                let directory = self.resolve_existing_request(&requested)?;
                if !directory.is_dir() {
                    return Err(Error::InvalidFilePath);
                }
                (directory, "*".to_string(), true)
            } else {
                let name = requested.file_name().ok_or(Error::InvalidFilePath)?;
                let pattern = name.to_str().ok_or(Error::InvalidFilePath)?.to_string();
                let parent_request = requested.parent().ok_or(Error::InvalidFilePath)?;
                let parent = if parent_request.as_os_str().is_empty() {
                    self.cwd.clone()
                } else {
                    self.resolve_existing_request(parent_request)?
                };
                if !pattern.contains('*') && !pattern.contains('?') {
                    if let Some(child) = self.case_insensitive_child(&parent, name)? {
                        let child = self.checked_canonical(child)?;
                        if child.is_dir() {
                            return self.list_directory(&child, "*", true, output);
                        }
                    }
                }
                (parent, pattern, false)
            }
        };
        self.list_directory(&directory, &pattern, grouped_default, output)
    }

    fn list_directory<W: Write>(
        &self,
        directory: &Path,
        pattern: &str,
        grouped_default: bool,
        output: &mut W,
    ) -> Result<(), Error> {
        if !directory.is_dir() || !directory.starts_with(&self.root) {
            return Err(Error::InvalidFilePath);
        }
        let mut entries = self.browser_entries(directory)?;
        if !grouped_default {
            writeln!(output, "MATCHING FILES")?;
        }
        let mut summary = DirectorySummary::default();
        if grouped_default {
            entries.sort_by(|left, right| {
                BrowserEntryGroup::for_entry(left)
                    .cmp(&BrowserEntryGroup::for_entry(right))
                    .then_with(|| {
                        left.name
                            .to_ascii_uppercase()
                            .cmp(&right.name.to_ascii_uppercase())
                    })
            });
        }
        let mut current_group = None;
        for entry in entries {
            if !grouped_default && !wildcard_match(pattern, &entry.name) {
                continue;
            }
            if grouped_default {
                let group = BrowserEntryGroup::for_entry(&entry);
                if current_group != Some(group) {
                    writeln!(output, "{}", group.heading())?;
                    current_group = Some(group);
                }
            }
            summary.include(&entry);
            match entry.kind {
                BrowserEntryKind::Directory => writeln!(output, "<DIR>  {}", entry.name)?,
                BrowserEntryKind::File => writeln!(output, "{:>10}  {}", entry.bytes, entry.name)?,
                BrowserEntryKind::Link => writeln!(output, "<LINK> {}", entry.name)?,
                BrowserEntryKind::Other => writeln!(output, "<OTHER> {}", entry.name)?,
            }
        }
        summary.write(output)?;
        Ok(())
    }

    fn tree<W: Write>(&self, argument: &str, output: &mut W) -> Result<(), Error> {
        let directory = if argument.trim().is_empty() {
            self.cwd.clone()
        } else {
            self.existing_path(argument)?
        };
        if !directory.is_dir() || !directory.starts_with(&self.root) {
            return Err(Error::InvalidFilePath);
        }
        writeln!(output, "TREE {}", self.basic_path(&directory)?)?;
        let mut summary = DirectorySummary::default();
        let mut visited = 0usize;
        self.write_tree_directory(&directory, 0, &mut visited, &mut summary, output)?;
        summary.write(output)?;
        Ok(())
    }

    fn write_tree_directory<W: Write>(
        &self,
        directory: &Path,
        depth: usize,
        visited: &mut usize,
        summary: &mut DirectorySummary,
        output: &mut W,
    ) -> Result<(), Error> {
        if depth > MAX_DIRECTORY_TREE_DEPTH {
            return Err(Error::Io(format!(
                "directory tree depth limit ({MAX_DIRECTORY_TREE_DEPTH}) exceeded"
            )));
        }
        for entry in self.browser_entries(directory)? {
            *visited = (*visited).saturating_add(1);
            if *visited > MAX_DIRECTORY_BROWSER_ENTRIES {
                return Err(Error::Io(format!(
                    "directory browser entry limit ({MAX_DIRECTORY_BROWSER_ENTRIES}) exceeded"
                )));
            }
            summary.include(&entry);
            let indent = "  ".repeat(depth);
            match entry.kind {
                BrowserEntryKind::Directory => {
                    writeln!(output, "{indent}<DIR>  {}", entry.name)?;
                    let child = self.checked_canonical(&entry.path)?;
                    self.write_tree_directory(&child, depth + 1, visited, summary, output)?;
                }
                BrowserEntryKind::File => {
                    writeln!(output, "{indent}{:>10}  {}", entry.bytes, entry.name)?
                }
                BrowserEntryKind::Link => writeln!(output, "{indent}<LINK> {}", entry.name)?,
                BrowserEntryKind::Other => writeln!(output, "{indent}<OTHER> {}", entry.name)?,
            }
        }
        Ok(())
    }

    fn browser_entries(&self, directory: &Path) -> Result<Vec<BrowserEntry>, Error> {
        if !directory.is_dir() || !directory.starts_with(&self.root) {
            return Err(Error::InvalidFilePath);
        }
        let mut entries = Vec::new();
        for entry in fs::read_dir(directory)? {
            if entries.len() >= MAX_DIRECTORY_BROWSER_ENTRIES {
                return Err(Error::Io(format!(
                    "directory browser entry limit ({MAX_DIRECTORY_BROWSER_ENTRIES}) exceeded"
                )));
            }
            let entry = entry?;
            let file_type = entry.file_type()?;
            let kind = if file_type.is_dir() {
                BrowserEntryKind::Directory
            } else if file_type.is_file() {
                BrowserEntryKind::File
            } else if file_type.is_symlink() {
                BrowserEntryKind::Link
            } else {
                BrowserEntryKind::Other
            };
            let bytes = if kind == BrowserEntryKind::File {
                entry.metadata()?.len()
            } else {
                0
            };
            entries.push(BrowserEntry {
                path: entry.path(),
                name: entry.file_name().to_string_lossy().to_string(),
                kind,
                bytes,
            });
        }
        entries.sort_by(|left, right| {
            left.kind.cmp(&right.kind).then_with(|| {
                left.name
                    .to_ascii_uppercase()
                    .cmp(&right.name.to_ascii_uppercase())
            })
        });
        Ok(entries)
    }
}

fn is_basic_program(name: &str) -> bool {
    Path::new(name)
        .extension()
        .and_then(|extension| extension.to_str())
        .is_some_and(|extension| extension.eq_ignore_ascii_case("bas"))
}

fn basic_root_relative(path: &Path) -> Option<PathBuf> {
    let mut components = path.components();
    let first = components.find(|component| !matches!(component, Component::CurDir))?;
    match first {
        Component::Normal(name) => name
            .to_string_lossy()
            .eq_ignore_ascii_case(BASIC_ROOT_NAME)
            .then(|| components.collect()),
        _ => None,
    }
}

fn unquote_path(argument: &str) -> Result<PathBuf, Error> {
    parse_path_argument(argument)
}

fn wildcard_match(pattern: &str, name: &str) -> bool {
    let pattern = pattern.to_ascii_uppercase().into_bytes();
    let name = name.to_ascii_uppercase().into_bytes();
    let (mut p, mut n, mut star, mut retry_n) = (0, 0, None, 0);
    while n < name.len() {
        if p < pattern.len() && (pattern[p] == b'?' || pattern[p] == name[n]) {
            p += 1;
            n += 1;
        } else if p < pattern.len() && pattern[p] == b'*' {
            star = Some(p);
            p += 1;
            retry_n = n;
        } else if let Some(star_at) = star {
            p = star_at + 1;
            retry_n += 1;
            n = retry_n;
        } else {
            return false;
        }
    }
    while p < pattern.len() && pattern[p] == b'*' {
        p += 1;
    }
    p == pattern.len()
}

/// Run the interactive BASIC environment over caller-supplied streams.
///
/// Keeping the streams generic makes the same environment usable from a
/// terminal and from deterministic scripted regression tests.
pub fn run_repl<R: BufRead + ?Sized, W: Write>(
    input: &mut R,
    output: &mut W,
    base_options: RunOptions,
) -> Result<(), Error> {
    run_repl_with_prompt_callback(input, output, base_options, || {})
}

pub(crate) fn run_repl_with_prompt_callback<R: BufRead + ?Sized, W: Write, F: FnMut()>(
    input: &mut R,
    output: &mut W,
    base_options: RunOptions,
    on_prompt: F,
) -> Result<(), Error> {
    run_repl_with_prompt_options(input, output, base_options, true, on_prompt)
}

pub(crate) fn run_repl_with_prompt_options<R: BufRead + ?Sized, W: Write, F: FnMut()>(
    input: &mut R,
    output: &mut W,
    base_options: RunOptions,
    show_startup_prompt: bool,
    on_prompt: F,
) -> Result<(), Error> {
    run_repl_with_initial_program_options(
        input,
        output,
        base_options,
        show_startup_prompt,
        None,
        false,
        on_prompt,
    )
}

pub(crate) fn run_repl_with_initial_program_options<R: BufRead + ?Sized, W: Write, F: FnMut()>(
    input: &mut R,
    output: &mut W,
    base_options: RunOptions,
    show_startup_prompt: bool,
    initial_program: Option<Program>,
    run_initial_program: bool,
    on_prompt: F,
) -> Result<(), Error> {
    let mut on_prompt = on_prompt;
    let mut filesystem = ReplFilesystem::new(base_options.file_root.as_deref())?;
    let mut program = initial_program.unwrap_or_default();
    let mut session = ExecutionSession::new(&program, base_options.clone())?;
    let mut old_program: Option<Program> = None;
    let mut auto: Option<(u64, u64)> = None;
    let mut edit_line: Option<u64> = None;

    if run_initial_program {
        match session.run_with_input(input, output) {
            Ok(_) => program = session.active_program().clone(),
            Err(error) => write_repl_error(output, error)?,
        }
    }
    if show_startup_prompt {
        writeln!(output, "READY.")?;
    }
    let mut first_prompt = true;

    loop {
        if show_startup_prompt || !first_prompt {
            write!(output, " ")?;
        }
        first_prompt = false;
        output.flush()?;
        on_prompt();

        let line = match read_bounded_line(input, DEFAULT_MAX_SOURCE_LINE_BYTES) {
            Ok(Some(line)) => line,
            Ok(None) => {
                writeln!(output)?;
                return Ok(());
            }
            Err(error) => {
                write_repl_error(output, bounded_line_error(error))?;
                continue;
            }
        };
        let line = line.trim();

        if let Some(number) = edit_line.take() {
            if line.is_empty() {
                writeln!(output, "EDIT CANCELLED.")?;
            } else {
                let source = if line.as_bytes().first().is_some_and(u8::is_ascii_digit) {
                    line.to_string()
                } else {
                    format!("{number} {line}")
                };
                match program.insert_line(&source) {
                    Ok(()) => {
                        if let Err(error) = session.replace_program(&program) {
                            program = session.active_program().clone();
                            write_repl_error(output, error)?;
                        }
                    }
                    Err(error) => write_repl_error(output, error)?,
                }
            }
            continue;
        }

        if let Some((number, increment)) = auto {
            if line.is_empty() {
                auto = None;
                writeln!(output, "AUTO OFF.")?;
            } else {
                match program.insert_line(&format!("{number} {line}")) {
                    Ok(()) => {
                        if let Err(error) = session.replace_program(&program) {
                            program = session.active_program().clone();
                            write_repl_error(output, error)?;
                        } else {
                            auto = number.checked_add(increment).map(|next| (next, increment));
                            if auto.is_none() {
                                write_repl_error(output, Error::IllegalQuantity)?;
                            }
                        }
                    }
                    Err(error) => write_repl_error(output, error)?,
                }
            }
            continue;
        }

        if line.is_empty() {
            continue;
        }

        if is_numbered_repl_line(line) {
            match program.insert_line(line) {
                Ok(()) => {
                    if let Err(error) = session.replace_program(&program) {
                        program = session.active_program().clone();
                        write_repl_error(output, error)?;
                    }
                }
                Err(error) => write_repl_error(output, error)?,
            }
            continue;
        }

        if looks_like_bare_expression(line) {
            let expression = format!("PRINT {line}");
            match session.execute_direct_with_input(&expression, input, output) {
                Ok(_) => program = session.active_program().clone(),
                Err(error) => write_repl_error(output, error)?,
            }
            continue;
        }

        let (command, argument) = split_command(line);

        match command.as_str() {
            "HELP" => writeln!(output, "{REPL_HELP}")?,
            "QUIT" | "EXIT" | "BYE" => return Ok(()),
            "PWD" if argument.is_empty() => filesystem.display_cwd(output)?,
            "CD" | "CHDIR" => match filesystem.change_dir(argument) {
                Ok(()) => {
                    session.set_file_root(filesystem.cwd().to_path_buf())?;
                    filesystem.display_cwd(output)?;
                }
                Err(error) => write_repl_error(output, error)?,
            },
            "DIR" | "FILES" | "CAT" | "CATALOG" | "LS" => {
                let result = if let Some(path) = recursive_directory_argument(argument) {
                    filesystem.tree(path, output)
                } else {
                    filesystem.list(argument, output)
                };
                if let Err(error) = result {
                    write_repl_error(output, error)?;
                }
            }
            "TREE" => {
                if let Err(error) = filesystem.tree(argument, output) {
                    write_repl_error(output, error)?;
                }
            }
            "MKDIR" => match filesystem.make_dir(argument) {
                Ok(()) => writeln!(output, "DIRECTORY CREATED.")?,
                Err(error) => write_repl_error(output, error)?,
            },
            "RMDIR" => match filesystem.remove_dir(argument) {
                Ok(()) => writeln!(output, "DIRECTORY REMOVED.")?,
                Err(error) => write_repl_error(output, error)?,
            },
            "KILL" => match filesystem.kill(argument) {
                Ok(()) => writeln!(output, "FILE DELETED.")?,
                Err(error) => write_repl_error(output, error)?,
            },
            "NAME" | "REN" | "RENAME" => match filesystem.rename(argument) {
                Ok(()) => writeln!(output, "FILE RENAMED.")?,
                Err(error) => write_repl_error(output, error)?,
            },
            "DELETE" => match parse_list_range(argument) {
                Ok((start, end)) if !argument.is_empty() => {
                    let count = program.delete_range(start, end);
                    session.replace_program(&program)?;
                    writeln!(output, "{count} LINE(S) DELETED.")?;
                }
                Ok(_) => write_repl_error(output, Error::syntax("DELETE requires a line range"))?,
                Err(error) => write_repl_error(output, error)?,
            },
            "RENUM" | "RENUMBER" => match parse_renum_arguments(argument) {
                Ok((new_start, old_start, increment)) => {
                    match program.renumber(new_start, old_start, increment) {
                        Ok(count) => {
                            session.replace_program(&program)?;
                            writeln!(output, "{count} LINE(S) RENUMBERED.")?;
                        }
                        Err(error) => write_repl_error(output, error)?,
                    }
                }
                Err(error) => write_repl_error(output, error)?,
            },
            "COPY" => match filesystem.copy(argument) {
                Ok(()) => writeln!(output, "FILE COPIED.")?,
                Err(error) => write_repl_error(output, error)?,
            },
            "AUTO" => match parse_auto_arguments(argument) {
                Ok(values) => {
                    auto = Some(values);
                    writeln!(output, "AUTO {},{}.", values.0, values.1)?;
                }
                Err(error) => write_repl_error(output, error)?,
            },
            "EDIT" => match argument.parse::<u64>() {
                Ok(number) if program.get(number).is_some() => {
                    output.write_all(&program.to_listing_bytes(
                        number,
                        number,
                        base_options.max_listing_bytes,
                    )?)?;
                    writeln!(output, "EDIT {number}: TYPE REPLACEMENT BODY")?;
                    edit_line = Some(number);
                }
                Ok(number) => write_repl_error(output, Error::LineNotFound(number))?,
                Err(_) => write_repl_error(output, Error::syntax("EDIT expects a line number"))?,
            },
            "OLD" if argument.is_empty() => match old_program.take() {
                Some(previous) => {
                    old_program = Some(program);
                    program = previous;
                    session = ExecutionSession::new(
                        &program,
                        base_options.clone().with_file_root(filesystem.cwd()),
                    )?;
                    writeln!(output, "OLD PROGRAM RESTORED.")?;
                }
                None => writeln!(output, "?NO OLD PROGRAM")?,
            },
            "STATUS" if argument.is_empty() => {
                writeln!(output, "MODERNBASIC {}", env!("CARGO_PKG_VERSION"))?;
                writeln!(output, "PROGRAM LINES: {}", program.len())?;
                writeln!(
                    output,
                    "CURRENT DIRECTORY: {}",
                    filesystem.basic_path(filesystem.cwd())?
                )?;
            }
            "LENGTH" if argument.is_empty() => {
                let bytes = program.to_source_bytes(DEFAULT_MAX_FILE_BYTES)?.len();
                writeln!(output, "PROGRAM LINES: {}", program.len())?;
                writeln!(output, "SOURCE BYTES: {bytes}")?;
            }
            "NEW" | "SCRATCH" if argument.is_empty() => {
                old_program = Some(program.clone());
                program.clear();
                session = ExecutionSession::new(
                    &program,
                    base_options.clone().with_file_root(filesystem.cwd()),
                )?;
            }
            "LIST" => match parse_list_range(argument) {
                Ok((start, end)) => {
                    match program.to_listing_bytes(start, end, base_options.max_listing_bytes) {
                        Ok(listing) => output.write_all(&listing)?,
                        Err(error) => write_repl_error(output, error)?,
                    }
                }
                Err(error) => write_repl_error(output, error)?,
            },
            "RUN" => {
                session.restart_ready();
                let source = if argument.is_empty() {
                    "RUN".to_string()
                } else {
                    format!("RUN {argument}")
                };
                let result = session.execute_direct_with_input(&source, input, output);
                program = session.active_program().clone();
                write_execution_ready(&mut session, result, output)?;
            }
            "STEP" => match parse_step_count(argument) {
                Ok(count) => {
                    if matches!(
                        session.state(),
                        SessionState::Ready | SessionState::Terminated(_) | SessionState::Faulted
                    ) {
                        session.restart_ready();
                    }
                    let result = (|| {
                        let mut result = session.step_with_input(input, output)?;
                        for _ in 1..count {
                            if result.state != SessionState::Paused {
                                break;
                            }
                            result = session.step_with_input(input, output)?;
                        }
                        Ok(result)
                    })();
                    program = session.active_program().clone();
                    write_execution_ready(&mut session, result, output)?;
                }
                Err(error) => write_repl_error(output, error)?,
            },
            "CONT" if argument.is_empty() => {
                let result = session.resume_with_input(input, output);
                program = session.active_program().clone();
                write_execution_ready(&mut session, result, output)?;
            }
            "MERGE" => match filesystem.existing_path(argument) {
                Ok(path) => match load_program(&path) {
                    Ok(loaded) => {
                        let count = loaded.len();
                        let mut merged = program.clone();
                        merged.merge_from(&loaded);
                        match session.replace_program(&merged) {
                            Ok(()) => {
                                program = merged;
                                writeln!(output, "MERGED {count} LINE(S).")?;
                            }
                            Err(error) => write_repl_error(output, error)?,
                        }
                    }
                    Err(error) => write_repl_error(output, error)?,
                },
                Err(error) => write_repl_error(output, error)?,
            },
            "LOAD" => {
                match filesystem.existing_path(argument) {
                    Ok(path) => match load_program(&path) {
                        Ok(loaded) => {
                            match ExecutionSession::new(
                                &loaded,
                                base_options
                                    .clone()
                                    .with_file_root(filesystem.cwd())
                                    .with_asset_root(
                                        path.parent().ok_or(Error::InvalidFilePath)?,
                                    ),
                            ) {
                                Ok(mut replacement) => {
                                    let prepared = replacement.prepare_program_assets()?;
                                    old_program = Some(program.clone());
                                    program = loaded;
                                    session = replacement;
                                    if prepared == 0 {
                                        writeln!(output, "LOADED {} LINE(S).", program.len())?;
                                    } else {
                                        writeln!(
                                            output,
                                            "LOADED {} LINE(S); PREPARED {prepared} ASSET(S).",
                                            program.len()
                                        )?;
                                    }
                                }
                                Err(error) => write_repl_error(output, error)?,
                            }
                        }
                        Err(error) => write_repl_error(output, error)?,
                    },
                    Err(error) => write_repl_error(output, error)?,
                }
                writeln!(output, "READY.")?;
            }
            "LOADB" => {
                match filesystem.existing_path(argument) {
                    Ok(path) => match load_binary_program(&path) {
                        Ok(loaded) => {
                            match ExecutionSession::new(
                                &loaded,
                                base_options
                                    .clone()
                                    .with_file_root(filesystem.cwd())
                                    .with_asset_root(
                                        path.parent().ok_or(Error::InvalidFilePath)?,
                                    ),
                            ) {
                                Ok(mut replacement) => {
                                    let prepared = replacement.prepare_program_assets()?;
                                    old_program = Some(program.clone());
                                    program = loaded;
                                    session = replacement;
                                    if prepared == 0 {
                                        writeln!(output, "LOADED {} LINE(S).", program.len())?;
                                    } else {
                                        writeln!(
                                            output,
                                            "LOADED {} LINE(S); PREPARED {prepared} ASSET(S).",
                                            program.len()
                                        )?;
                                    }
                                }
                                Err(error) => write_repl_error(output, error)?,
                            }
                        }
                        Err(error) => write_repl_error(output, error)?,
                    },
                    Err(error) => write_repl_error(output, error)?,
                }
                writeln!(output, "READY.")?;
            }
            "SAVE" => match filesystem.output_path(argument) {
                Ok(path) => match save_program(&program, &path) {
                    Ok(()) => writeln!(output, "SAVED {} LINE(S).", program.len())?,
                    Err(error) => write_repl_error(output, error)?,
                },
                Err(error) => write_repl_error(output, error)?,
            },
            "SAVEB" => match filesystem.output_path(argument) {
                Ok(path) => match save_binary_program(&program, &path) {
                    Ok(()) => writeln!(output, "SAVED {} LINE(S).", program.len())?,
                    Err(error) => write_repl_error(output, error)?,
                },
                Err(error) => write_repl_error(output, error)?,
            },
            "VERIFY" => match filesystem.existing_path(argument) {
                Ok(path) => match fs::read(path) {
                    Ok(bytes) => match program.to_source_bytes(DEFAULT_MAX_FILE_BYTES) {
                        Ok(source) if source == bytes => writeln!(output, "VERIFY OK.")?,
                        Ok(_) => writeln!(output, "?VERIFY FAILED")?,
                        Err(error) => write_repl_error(output, error)?,
                    },
                    Err(error) => write_repl_error(output, Error::from(error))?,
                },
                Err(error) => write_repl_error(output, error)?,
            },
            "EVAL" => {
                if argument.is_empty() {
                    write_repl_error(output, Error::syntax("expression required"))?;
                } else {
                    let source = format!("PRINT {argument}");
                    if let Err(error) = session.execute_direct_with_input(&source, input, output) {
                        write_repl_error(output, error)?;
                    }
                }
            }
            _ => match session.execute_direct_with_input(line, input, output) {
                Ok(result) => {
                    program = session.active_program().clone();
                    if result.state == SessionState::Stopped {
                        writeln!(output, "BREAK. TYPE STEP OR CONT TO RESUME.")?;
                    }
                }
                Err(error) => write_repl_error(output, error)?,
            },
        }
    }
}

fn split_command(line: &str) -> (String, &str) {
    if line.eq_ignore_ascii_case("CD..") {
        return ("CD".to_string(), "..");
    }
    if line
        .get(..2)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("CD"))
        && line
            .as_bytes()
            .get(2)
            .is_some_and(|separator| *separator == b'/' || *separator == b'\\')
    {
        return ("CD".to_string(), &line[2..]);
    }
    let split_at = line.find(char::is_whitespace).unwrap_or(line.len());
    (
        line[..split_at].to_ascii_uppercase(),
        line[split_at..].trim(),
    )
}

fn is_numbered_repl_line(line: &str) -> bool {
    let digits = line
        .as_bytes()
        .iter()
        .take_while(|byte| byte.is_ascii_digit())
        .count();
    if digits == 0 {
        return false;
    }
    match line.as_bytes().get(digits) {
        None => true,
        Some(byte) => byte.is_ascii_whitespace() || byte.is_ascii_alphabetic(),
    }
}

fn looks_like_bare_expression(line: &str) -> bool {
    if line
        .as_bytes()
        .first()
        .is_some_and(|byte| byte.is_ascii_digit() || b".+-(\"".contains(byte))
    {
        return true;
    }
    !line.chars().any(char::is_whitespace)
        && !line.contains('=')
        && line
            .as_bytes()
            .iter()
            .any(|byte| b"()+-*/^<>".contains(byte))
}

fn recursive_directory_argument(argument: &str) -> Option<&str> {
    let argument = argument.trim();
    if argument.eq_ignore_ascii_case("/S") {
        return Some("");
    }
    if argument
        .get(..3)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("/S "))
    {
        return Some(argument.get(3..)?.trim());
    }
    let split_at = argument.len().checked_sub(3)?;
    if argument
        .get(split_at..)
        .is_some_and(|suffix| suffix.eq_ignore_ascii_case(" /S"))
    {
        return Some(argument.get(..split_at)?.trim());
    }
    None
}

fn parse_step_count(argument: &str) -> Result<usize, Error> {
    if argument.is_empty() {
        return Ok(1);
    }
    let count = argument
        .parse::<usize>()
        .map_err(|_| Error::syntax("STEP expects a positive statement count"))?;
    if count == 0 || count > MAX_REPL_STEP_COUNT {
        return Err(Error::IllegalQuantity);
    }
    Ok(count)
}

fn parse_list_range(argument: &str) -> Result<(u64, u64), Error> {
    let argument = argument.trim();
    let line_number = |value: &str| -> Result<u64, Error> {
        let line = value
            .parse::<u64>()
            .map_err(|_| Error::syntax("LIST expects n, n-m, -m, or n-"))?;
        (line <= MAX_BASIC_LINE_NUMBER)
            .then_some(line)
            .ok_or(Error::IllegalQuantity)
    };
    if argument.is_empty() {
        return Ok((0, u64::MAX));
    }
    if let Some((start, end)) = argument.split_once('-') {
        if end.contains('-') {
            return Err(Error::syntax("LIST expects n, n-m, -m, or n-"));
        }
        let start = if start.trim().is_empty() {
            0
        } else {
            line_number(start.trim())?
        };
        let end = if end.trim().is_empty() {
            u64::MAX
        } else {
            line_number(end.trim())?
        };
        return Ok((start, end));
    }
    let line = line_number(argument)?;
    Ok((line, line))
}

fn parse_auto_arguments(argument: &str) -> Result<(u64, u64), Error> {
    if argument.trim().is_empty() {
        return Ok((10, 10));
    }
    let parts = argument.split(',').map(str::trim).collect::<Vec<_>>();
    if parts.len() > 2 {
        return Err(Error::syntax("AUTO expects [start],[increment]"));
    }
    let start = match parts.first().copied().unwrap_or("") {
        "" => 10,
        value => {
            let line = value
                .parse::<u64>()
                .map_err(|_| Error::syntax("AUTO expects nonnegative integers"))?;
            (line <= MAX_BASIC_LINE_NUMBER)
                .then_some(line)
                .ok_or(Error::IllegalQuantity)?
        }
    };
    let increment = match parts.get(1).copied().unwrap_or("") {
        "" => 10,
        value => value
            .parse::<u64>()
            .map_err(|_| Error::syntax("AUTO expects nonnegative integers"))?,
    };
    if increment == 0 {
        return Err(Error::IllegalQuantity);
    }
    Ok((start, increment))
}

fn parse_renum_arguments(argument: &str) -> Result<(u64, u64, u64), Error> {
    if argument.trim().is_empty() {
        return Ok((10, 0, 10));
    }
    let parts = argument.split(',').map(str::trim).collect::<Vec<_>>();
    if parts.len() > 3 {
        return Err(Error::syntax("RENUM expects [new],[old],[increment]"));
    }
    let parse = |index: usize, default: u64| -> Result<u64, Error> {
        match parts.get(index).copied().unwrap_or("") {
            "" => Ok(default),
            value => {
                let number = value
                    .parse::<u64>()
                    .map_err(|_| Error::syntax("RENUM expects nonnegative integers"))?;
                if index < 2 && number > MAX_BASIC_LINE_NUMBER {
                    return Err(Error::IllegalQuantity);
                }
                Ok(number)
            }
        }
    };
    let values = (parse(0, 10)?, parse(1, 0)?, parse(2, 10)?);
    if values.2 == 0 {
        return Err(Error::IllegalQuantity);
    }
    Ok(values)
}

fn parse_path_argument(argument: &str) -> Result<PathBuf, Error> {
    let argument = argument.trim();
    if argument.is_empty() {
        return Err(Error::syntax("file path required"));
    }
    if argument.starts_with('"') {
        if argument.len() < 2 || !argument.ends_with('"') {
            return Err(Error::syntax("unterminated quoted file path"));
        }
        let path = &argument[1..argument.len() - 1];
        if path.is_empty() {
            return Err(Error::syntax("file path required"));
        }
        return Ok(PathBuf::from(path.replace('\\', "/")));
    }
    Ok(PathBuf::from(argument.replace('\\', "/")))
}

fn load_program(path: &PathBuf) -> Result<Program, Error> {
    let file = File::open(path)?;
    let mut reader = BufReader::new(file);
    let mut program = Program::new();
    program.read_from(&mut reader, DEFAULT_MAX_SOURCE_LINE_BYTES)?;
    Ok(program)
}

fn save_program(program: &Program, path: &PathBuf) -> Result<(), Error> {
    let source = program.to_source_bytes(DEFAULT_MAX_FILE_BYTES)?;
    std::fs::write(path, source)?;
    Ok(())
}

fn load_binary_program(path: &PathBuf) -> Result<Program, Error> {
    let bytes = std::fs::read(path)?;
    Program::from_binary_bytes(&bytes, DEFAULT_MAX_FILE_BYTES)
}

fn save_binary_program(program: &Program, path: &PathBuf) -> Result<(), Error> {
    let binary = program.to_binary_bytes(DEFAULT_MAX_FILE_BYTES)?;
    std::fs::write(path, binary)?;
    Ok(())
}

fn bounded_line_error(error: BoundedLineError) -> Error {
    match error {
        BoundedLineError::Io(message) => Error::Io(message),
        BoundedLineError::Interrupted => Error::Break,
        BoundedLineError::TooLong { limit } => Error::SourceLineTooLong { limit },
        BoundedLineError::InvalidUtf8 => Error::InvalidSourceEncoding,
    }
}

fn write_repl_error<W: Write>(output: &mut W, error: Error) -> Result<(), Error> {
    if error == Error::Break {
        writeln!(output, "BREAK")?;
    } else {
        writeln!(output, "?{error}")?;
    }
    Ok(())
}

fn write_execution_ready<W: Write>(
    session: &mut ExecutionSession,
    result: Result<SessionResult, Error>,
    output: &mut W,
) -> Result<(), Error> {
    session.finish_terminal_output_line(output)?;
    match result {
        Ok(result) if result.state == SessionState::Stopped => {
            writeln!(output, "BREAK. TYPE STEP OR CONT TO RESUME.")?;
        }
        Ok(result) if result.state == SessionState::Paused => {
            if let Some(line) = session.next_line() {
                writeln!(output, "PAUSED BEFORE LINE {line}. TYPE STEP OR CONT.")?;
            } else {
                writeln!(output, "PAUSED. TYPE STEP OR CONT.")?;
            }
        }
        Ok(_) => {}
        Err(error) => write_repl_error(output, error)?,
    }
    // Wait for audio playback and speech to finish before printing READY.
    // The program is not truly finished while sound or speech is still active.
    while session.audio_is_active() {
        std::thread::sleep(std::time::Duration::from_millis(100));
    }
    writeln!(output, "READY.")?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{BufReader, Cursor};
    use std::sync::atomic::{AtomicU64, Ordering};

    fn scripted_repl(source: &str) -> String {
        scripted_repl_with_options(source, RunOptions::modern())
    }

    fn scripted_repl_with_options(source: &str, options: RunOptions) -> String {
        let mut input = BufReader::new(Cursor::new(source.as_bytes()));
        let mut output = Vec::new();
        run_repl(&mut input, &mut output, options).unwrap();
        String::from_utf8(output).unwrap()
    }

    #[test]
    fn prompt_callback_reports_actual_ready_boundaries() {
        let mut input = BufReader::new(Cursor::new(b"10 END\nRUN\nQUIT\n"));
        let mut output = Vec::new();
        let mut prompts = 0usize;
        run_repl_with_prompt_callback(&mut input, &mut output, RunOptions::modern(), || {
            prompts += 1
        })
        .unwrap();
        assert_eq!(prompts, 3);
    }

    #[test]
    fn startup_load_can_put_loaded_message_before_the_only_ready_banner() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-startup-load-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("hello.bas"), b"10 END\n").unwrap();

        let mut input = BufReader::new(Cursor::new(b"LOAD hello.bas\nQUIT\n"));
        let mut output = Vec::new();
        run_repl_with_prompt_options(
            &mut input,
            &mut output,
            RunOptions::modern().with_file_root(&root),
            false,
            || {},
        )
        .unwrap();
        let output = String::from_utf8(output).unwrap();
        assert!(output.starts_with("LOADED 1 LINE(S).\nREADY.\n "));
        assert_eq!(output.matches("READY.").count(), 1);

        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn filesystem_navigation_lists_and_changes_the_virtual_directory() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-navigation-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(root.join("WORK/MUSIC")).unwrap();
        std::fs::write(root.join("WORK/MUSIC/SONG.BAS"), b"10 END\n").unwrap();
        let output = scripted_repl_with_options(
            "PWD\nDIR\nCD \"WORK/MUSIC\"\nPWD\nDIR \"*.BAS\"\nCD ..\nPWD\nQUIT\n",
            RunOptions::modern().with_file_root(&root),
        );
        assert!(output.contains("CURRENT DIRECTORY programs"));
        assert!(output.contains("<DIR>  WORK"));
        assert!(output.contains("CURRENT DIRECTORY programs/WORK/MUSIC"));
        assert!(output.contains("SONG.BAS"));
        assert!(output.contains("CURRENT DIRECTORY programs/WORK"));
        assert!(!output.contains(root.to_string_lossy().as_ref()));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn default_directory_view_groups_programs_before_other_files() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-program-view-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(root.join("assets")).unwrap();
        std::fs::write(root.join("game.bas"), b"10 END\n").unwrap();
        std::fs::write(root.join("DEMO.BAS"), b"20 END\n").unwrap();
        std::fs::write(root.join("scores.dat"), b"1000\n").unwrap();
        std::fs::write(root.join("notes.txt"), b"draft\n").unwrap();

        let filesystem = ReplFilesystem::new(Some(&root)).unwrap();

        let mut default_output = Vec::new();
        filesystem.list("", &mut default_output).unwrap();
        let default_output = String::from_utf8(default_output).unwrap();
        assert!(default_output.contains("DIRECTORY FOLDERS"));
        assert!(default_output.contains("BASIC PROGRAMS"));
        assert!(default_output.contains("OTHER FILES"));
        assert!(default_output.contains("<DIR>  assets"));
        assert!(default_output.contains("game.bas"));
        assert!(default_output.contains("DEMO.BAS"));
        assert!(default_output.contains("scores.dat"));
        assert!(default_output.contains("notes.txt"));
        assert!(
            default_output.find("game.bas").unwrap() < default_output.find("scores.dat").unwrap()
        );
        assert!(default_output.contains("4 FILE(S), 25 BYTE(S)"));

        let mut all_output = Vec::new();
        filesystem.list("*", &mut all_output).unwrap();
        let all_output = String::from_utf8(all_output).unwrap();
        assert!(all_output.contains("scores.dat"));
        assert!(all_output.contains("notes.txt"));

        let mut data_output = Vec::new();
        filesystem.list("*.DAT", &mut data_output).unwrap();
        let data_output = String::from_utf8(data_output).unwrap();
        assert!(data_output.contains("scores.dat"));
        assert!(!data_output.contains("game.bas"));

        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn file_browser_reports_nested_paths_counts_patterns_root_parent_and_tree() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-browser-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let examples = root.join("examples");
        let nested = examples.join("nested");
        std::fs::create_dir_all(&nested).unwrap();
        std::fs::write(examples.join("hello.bas"), b"10 END\n").unwrap();
        std::fs::write(nested.join("deep.bas"), b"20 END\n").unwrap();

        let output = scripted_repl_with_options(
            "PWD\nDIR\nCD /EXAMPLES\nPWD\nDIR\nCD..\nPWD\nCD\\EXAMPLES\\NESTED\nPWD\nDIR\nCD /\nCD ..\nCD PROGRAMS/EXAMPLES\nPWD\nCD /\nTREE \\\nDIR /S /EXAMPLES\nDIR /EXAMPLES/*.BAS\nDIR /EXAMPLES/MISSING*.BAS\nSTATUS\nQUIT\n",
            RunOptions::modern().with_file_root(&root),
        );

        assert!(output.contains("<DIR>  examples"));
        assert!(output.contains("CURRENT DIRECTORY programs/examples"));
        assert!(output.contains("CURRENT DIRECTORY programs/examples/nested"));
        assert!(output.contains("DIRECTORY FOLDERS"));
        assert!(!output
            .lines()
            .any(|line| line.trim() == "DIRECTORY programs"));
        assert!(output.contains("BASIC PROGRAMS"));
        assert!(output.contains("TREE programs\n"));
        assert!(output.contains("  <DIR>  nested"));
        assert!(output.contains("hello.bas"));
        assert!(output.contains("deep.bas"));
        assert!(output.contains("1 FILE(S), 7 BYTE(S)"));
        assert!(output.contains("0 FILE(S), 0 BYTE(S)"));
        assert!(output.contains("1 DIR(S)"));
        assert!(output.contains("CURRENT DIRECTORY: programs"));
        assert!(!output.contains(root.to_string_lossy().as_ref()));
        assert_eq!(split_command("CD.."), ("CD".to_string(), ".."));
        assert_eq!(recursive_directory_argument("/S"), Some(""));
        assert_eq!(
            recursive_directory_argument("/s /EXAMPLES"),
            Some("/EXAMPLES")
        );
        assert_eq!(
            recursive_directory_argument(r#""EXAMPLES/NESTED" /S"#),
            Some(r#""EXAMPLES/NESTED""#)
        );
        assert_eq!(
            split_command(r"CD\EXAMPLES"),
            ("CD".to_string(), r"\EXAMPLES")
        );
        assert_eq!(
            parse_path_argument(r"\EXAMPLES\NESTED").unwrap(),
            PathBuf::from("/EXAMPLES/NESTED")
        );
        assert_eq!(
            basic_root_relative(Path::new("PROGRAMS/EXAMPLES/NESTED")),
            Some(PathBuf::from("EXAMPLES/NESTED"))
        );
        assert_eq!(basic_root_relative(Path::new("EXAMPLES")), None);

        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn uppercase_basic_paths_resolve_lowercase_host_directories_and_files() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-casefold-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let examples = root.join("examples");
        std::fs::create_dir_all(&examples).unwrap();
        std::fs::write(
            examples.join("hello.bas"),
            b"10 PRINT \"CASE PATH OK\"\n20 END\n",
        )
        .unwrap();

        let output = scripted_repl_with_options(
            "DIR EXAMPLES\nCD EXAMPLES\nLOAD HELLO.BAS\nRUN\nSAVE HELLO.BAS\nCD ..\nDIR EXAMPLES/*.BAS\nQUIT\n",
            RunOptions::modern().with_file_root(&root),
        );
        assert!(output.contains("CASE PATH OK\n"));
        assert!(output.contains("MATCHING FILES"));
        assert!(!output.contains(root.to_string_lossy().as_ref()));
        assert!(output.contains("hello.bas"));
        assert!(!examples.join("HELLO.BAS").exists());
        assert_eq!(
            std::fs::read_to_string(examples.join("hello.bas")).unwrap(),
            "10 PRINT \"CASE PATH OK\"\n20 END\n"
        );

        std::fs::create_dir(root.join("Mix")).unwrap();
        std::fs::create_dir(root.join("mIX")).unwrap();
        let filesystem = ReplFilesystem::new(Some(&root)).unwrap();
        assert_eq!(
            filesystem.existing_path("MIX").unwrap_err(),
            Error::InvalidFilePath
        );

        #[cfg(unix)]
        {
            use std::os::unix::fs::symlink;

            let outside = root.with_extension("outside");
            std::fs::create_dir_all(&outside).unwrap();
            std::fs::write(outside.join("must-not-be-listed.bas"), b"10 END\n").unwrap();
            symlink(&outside, root.join("escape")).unwrap();
            assert_eq!(
                filesystem.existing_path("ESCAPE").unwrap_err(),
                Error::InvalidFilePath
            );
            let mut tree_output = Vec::new();
            filesystem.tree("", &mut tree_output).unwrap();
            let tree_output = String::from_utf8(tree_output).unwrap();
            assert!(tree_output.contains("<LINK> escape"));
            assert!(!tree_output.contains("must-not-be-listed.bas"));
            std::fs::remove_dir_all(outside).unwrap();
        }
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn filesystem_management_and_program_io_follow_the_current_directory() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-management-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&root).unwrap();
        let output = scripted_repl_with_options(
            "MKDIR \"WORK\"\nCD \"WORK\"\n10 PRINT \"NAVIGATION OK\"\nSAVE \"A.BAS\"\nNAME \"A.BAS\" AS \"B.BAS\"\nNEW\nLOAD \"B.BAS\"\nRUN\nKILL \"B.BAS\"\nCD ..\nRMDIR \"WORK\"\nDIR\nQUIT\n",
            RunOptions::modern().with_file_root(&root),
        );
        assert!(output.contains("SAVED 1 LINE(S)."));
        assert!(output.contains("LOADED 1 LINE(S)."));
        assert!(output.contains("NAVIGATION OK\n"));
        assert!(!root.join("WORK").exists());
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn basic_file_channels_follow_cd_without_losing_the_program() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-channel-cwd-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(root.join("WORK")).unwrap();
        let output = scripted_repl_with_options(
            "10 OPEN 1,\"RESULT.TXT\",\"WRITE\"\n20 PRINT# 1,\"IN CURRENT DIRECTORY\"\n30 CLOSE 1\nCD \"WORK\"\nRUN\nLIST\nQUIT\n",
            RunOptions::modern().with_file_root(&root),
        );
        assert!(output.contains("10 OPEN"));
        assert_eq!(
            std::fs::read_to_string(root.join("WORK/RESULT.TXT")).unwrap(),
            "IN CURRENT DIRECTORY\n"
        );
        assert!(!root.join("RESULT.TXT").exists());
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn auto_edit_old_status_and_length_are_real_commands() {
        let output = scripted_repl(
            "10 PRINT \"ORIGINAL\"\nSTATUS\nLENGTH\nNEW\nOLD\nEDIT 10\nPRINT \"EDITED\"\nAUTO 20,10\nPRINT \"AUTO\"\nEND\n\nLIST\nQUIT\n",
        );
        assert!(output.contains("PROGRAM LINES: 1"));
        assert!(output.contains("SOURCE BYTES:"));
        assert!(output.contains("OLD PROGRAM RESTORED."));
        assert!(output.contains("10 PRINT \"EDITED\"\n"));
        assert!(output.contains("20 PRINT \"AUTO\"\n30 END\n"));
        assert!(!output.contains("10 PRINT \"ORIGINAL\"\n20"));
    }

    #[test]
    fn merge_verify_and_copy_are_real_ready_prompt_commands() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-file-commands-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("PART.BAS"), b"20 PRINT \"MERGED\"\n30 END\n").unwrap();
        let output = scripted_repl_with_options(
            "10 PRINT \"FIRST\"\nMERGE \"PART.BAS\"\nSAVE \"WHOLE.BAS\"\nVERIFY \"WHOLE.BAS\"\nCOPY \"WHOLE.BAS\" AS \"COPY.BAS\"\nLIST\nQUIT\n",
            RunOptions::modern().with_file_root(&root),
        );
        assert!(output.contains("MERGED 2 LINE(S)."));
        assert!(output.contains("VERIFY OK."));
        assert!(output.contains("FILE COPIED."));
        assert!(output.contains("10 PRINT \"FIRST\"\n20 PRINT \"MERGED\"\n30 END\n"));
        assert_eq!(
            std::fs::read(root.join("WHOLE.BAS")).unwrap(),
            std::fs::read(root.join("COPY.BAS")).unwrap()
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn delete_and_renum_are_real_ready_prompt_commands() {
        let output = scripted_repl(
            "10 GOTO 100\n20 PRINT \"DELETE ME\"\n100 PRINT \"KEPT\"\n110 END\nDELETE 20\nRENUM 1000,10,10\nLIST\nQUIT\n",
        );
        assert!(output.contains("1 LINE(S) DELETED."));
        assert!(output.contains("3 LINE(S) RENUMBERED."));
        assert!(output.contains("1000 GOTO 1010\n"));
        assert!(output.contains("1010 PRINT \"KEPT\"\n1020 END\n"));
        assert!(!output.contains("DELETE ME"));
    }

    #[test]
    fn edits_lists_runs_stops_continues_and_evaluates() {
        let output = scripted_repl(
            "10 PRINT 2+2\n20 STOP\n30 PRINT \"DONE\"\nLIST 10-20\nRUN\nCONT\nEVAL SQR(81)\nQUIT\n",
        );
        let banner = "READY.\n ";
        assert!(output.starts_with(banner));
        assert!(output.contains("10 PRINT 2 + 2\n20 STOP\n"));
        assert!(output.contains("4\nBREAK. TYPE STEP OR CONT TO RESUME.\nREADY.\n "));
        assert!(output.contains("DONE\nREADY.\n "));
        assert!(output.contains("9\n"));
    }

    #[test]
    fn bare_direct_mode_expressions_are_evaluated() {
        let output = scripted_repl("2+2\nSQR(81)\nQUIT\n");
        assert!(output.contains("4\n"));
        assert!(output.contains("9\n"));
        assert!(!output.contains("?syntax"));
    }

    #[test]
    fn step_is_statement_precise_and_run_restarts_after_stop() {
        let output = scripted_repl(
            "10 A=1:GOSUB 100:PRINT A:STOP\n20 END\n100 A=A+1:RETURN\nSTEP 2\nSTEP\nSTEP\nSTEP\nRUN\nRUN\nQUIT\n",
        );

        assert!(output.contains("PAUSED BEFORE LINE 100. TYPE STEP OR CONT."));
        assert!(output.contains("PAUSED BEFORE LINE 10. TYPE STEP OR CONT."));
        assert_eq!(
            output
                .matches("2\nBREAK. TYPE STEP OR CONT TO RESUME.")
                .count(),
            2
        );
        assert!(!output.contains("?cannot continue"));
    }

    #[test]
    fn completed_run_prints_ready_on_a_fresh_output_line() {
        let output =
            scripted_repl("10 PRINT \"NO NEWLINE\";\n20 END\nRUN\nPRINT \"AFTER\"\nQUIT\n");
        assert!(output.contains("NO NEWLINE\nREADY.\n AFTER\n"));
        assert!(!output.contains("NO NEWLINEREADY."));
    }

    #[test]
    fn runtime_input_uses_the_interactive_stream() {
        let output = scripted_repl("10 INPUT A\n20 PRINT A*2\nRUN\n21\nQUIT\n");
        assert!(output.contains("? 42\n"));
    }

    #[test]
    fn save_new_load_and_run_round_trip() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-repl-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("round-trip.bas");
        let script =
            "10 PRINT \"ROUND TRIP\"\nSAVE \"round-trip.bas\"\nNEW\nLIST\nLOAD \"round-trip.bas\"\nRUN\nQUIT\n";
        let output = scripted_repl_with_options(script, RunOptions::modern().with_file_root(&root));
        assert!(output.contains("SAVED 1 LINE(S)."));
        assert!(output.contains("LOADED 1 LINE(S)."));
        assert!(output.contains("ROUND TRIP\n"));
        assert_eq!(
            std::fs::read_to_string(&path).unwrap(),
            "10 PRINT \"ROUND TRIP\"\n"
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn saveb_new_loadb_and_run_round_trip_without_source_parsing() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-repl-binary-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&root).unwrap();
        let script = "10 PRINT \"BINARY ROUND TRIP\"\nSAVEB \"round-trip.m64b\"\nNEW\nLOADB \"round-trip.m64b\"\nRUN\nQUIT\n";
        let output = scripted_repl_with_options(script, RunOptions::modern().with_file_root(&root));
        assert!(output.contains("SAVED 1 LINE(S)."));
        assert!(output.contains("LOADED 1 LINE(S)."));
        assert!(output.contains("BINARY ROUND TRIP\n"));
        assert_eq!(
            &std::fs::read(root.join("round-trip.m64b")).unwrap()[..4],
            b"M64B"
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn load_prepares_declared_audio_before_commit_and_keeps_the_old_program_on_failure() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-ready-assets-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("invalid.sf2"), b"not a SoundFont").unwrap();
        std::fs::write(
            root.join("music.bas"),
            b"10 SOUNDFONT \"invalid.sf2\"\n20 PRINT \"NEW\"\n",
        )
        .unwrap();

        let output = scripted_repl_with_options(
            "10 PRINT \"OLD\"\nLOAD \"music.bas\"\nRUN\nQUIT\n",
            RunOptions::modern().with_file_root(&root),
        );
        assert!(output.contains("SoundFont load error"));
        assert!(!output.contains("LOADED 2 LINE(S)"));
        assert!(output.contains("OLD\nREADY."));
        assert!(!output.contains("NEW\n"));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn load_resolves_static_assets_from_the_program_directory() {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let root = std::env::temp_dir().join(format!(
            "modernbasic-program-assets-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let program_dir = root.join("album");
        std::fs::create_dir_all(&program_dir).unwrap();
        std::fs::write(
            program_dir.join("pixel.ppm"),
            b"P6\n1 1\n255\n\x12\x34\x56",
        )
        .unwrap();
        std::fs::write(
            program_dir.join("show.bas"),
            b"10 SCREEN 1,1,\"black\"\n20 BITMAP \"pixel.ppm\",0,0,1,1\n30 PRINT \"ASSET READY\"\n40 END\n",
        )
        .unwrap();

        let output = scripted_repl_with_options(
            "LOAD \"album/show.bas\"\nRUN\nQUIT\n",
            RunOptions::modern().with_file_root(&root),
        );
        assert!(output.contains("LOADED 4 LINE(S); PREPARED 1 ASSET(S)."));
        assert!(output.contains("ASSET READY\n"));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn bad_direct_command_does_not_close_environment() {
        let output = scripted_repl("BOGUS\nPRINT 6*7\nQUIT\n");
        assert!(output.contains("?syntax error:"));
        assert!(output.contains("42\n"));
    }

    #[test]
    fn direct_mode_retains_variables_and_runs_inline_loops() {
        let output = scripted_repl("A=5\nPRINT A\nFORI=1TO3:PRINTI:NEXTI\nQUIT\n");
        assert!(output.contains("5\n"));
        assert!(output.contains("1\n2\n3\n"));
    }

    #[test]
    fn list_ranges_are_parsed_deterministically() {
        assert_eq!(parse_list_range("").unwrap(), (0, u64::MAX));
        assert_eq!(parse_list_range("10").unwrap(), (10, 10));
        assert_eq!(parse_list_range("10-20").unwrap(), (10, 20));
        assert_eq!(parse_list_range("-20").unwrap(), (0, 20));
        assert_eq!(parse_list_range("10-").unwrap(), (10, u64::MAX));
        assert!(parse_list_range("10-20-30").is_err());
        assert!(matches!(
            parse_list_range("65530"),
            Err(Error::IllegalQuantity)
        ));
        assert!(matches!(
            parse_auto_arguments("65530,10"),
            Err(Error::IllegalQuantity)
        ));
        assert!(matches!(
            parse_renum_arguments("65530,0,10"),
            Err(Error::IllegalQuantity)
        ));
    }
}
