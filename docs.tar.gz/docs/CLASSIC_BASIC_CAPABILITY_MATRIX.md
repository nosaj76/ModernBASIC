# Classic BASIC programming-capability matrix

This matrix records the review of the documents in
/home/jason/projects/OSprojects/BASIC/BASIC_documents against the actual
ModernBASIC 0.8.2 source and tests. It is an outcome map, not a dialect or
source-compatibility claim.

## Scope and status

The review includes programming statements, functions, program execution,
graphics, sound, and program-visible file I/O. It excludes editor commands,
disk catalogs, monitor/debugger commands that do not execute a BASIC program,
machine-specific boot and operating-system commands, and device-transfer
protocols.

Status meanings:

| Status | Meaning |
| --- | --- |
| Direct | ModernBASIC has the behavior as a native statement, function, or structured form. |
| Composed | The same programming outcome is available through a small ModernBASIC composition or a modern retained-device abstraction. |
| Virtualized | A hardware operation is implemented against bounded language-owned state, never raw host hardware. |
| Excluded | It is an editor, OS, storage-management, monitor, assembler, or device-protocol command outside this review. |
| Boundary | Deliberately not provided because it would mean runtime source injection or uncontrolled host integration. |

## Documents reviewed

| Supplied source | Use in this review |
| --- | --- |
| basicmanual_1964.pdf | Visually reviewed scan. LET, PRINT, FOR/NEXT, GOTO, IF/THEN, DEF, READ/DATA, and END are all direct. |
| BASIC_4th_Edition_Jan68_text.pdf | Dartmouth program control, arrays, functions, data, and matrix behavior. |
| MS-BASIC.pdf | Microsoft statement index, sequential/random files, error handling, program control, formatting, and bounded hardware-facing forms. |
| BASIC_Language_Reference_Manual_Mar80.pdf | OASIS/Phase One structured control, MAT forms, files, errors, and statement-level STEP/TRACE behavior. |
| BBC BASIC Reference Manual-opt.pdf | BBC procedures/functions, local data, structured control, graphics/viewports, files, and sound. |
| Commodore 128 Programmer's Reference Guide.pdf and the companion C128 HTML | C128 graphics, shapes, sprites, collision, sound, structured loops, and files. |
| Amiga_BASIC_1985_Commodore.pdf | Amiga graphics regions, screens/windows, events, objects, sound, speech, files, and IDE single-step behavior. |
| beginbas.pdf and bb_pages/p-001.png through p-147.png | Visually reviewed TI beginner material: PRINT, CLEAR, LET, SOUND, HCHAR/VCHAR, INPUT, GOTO, COLOR, FOR/NEXT, RANDOMIZE, IF/THEN, KEY, SCREEN, and CHAR. beginbas_raw.txt contains only form-feed extraction artifacts. |
| TI84_Plus_CE_ProgrammingGuide_EN-1.pdf | TI control, graphing, list/statistics, input/output, program calls, and calculator device-transfer distinctions. |
| myBASIC.txt | Design evidence for sorted numbered execution, explicit program counters, line stepping, GOTO, GOSUB, and RETURN. |
| linux_basic.txt and RUSTBASIC_DEV_GUIDE.md | Architecture and operating-environment ideas. System/OS commands are out of scope; statements were checked only when they describe program behavior. |
| COMPATIBILITY_AUDIT_2026-04-11.md, STATEMENT_CONFORMANCE_AUDIT_2026-04-11.md, MATH_CAPABILITY_AUDIT_2026-04-12.md, and BEGINBAS_GRAPHICS_AUDIT_2026-07-18.md | Used as leads and warnings. They describe older or different trees and were not treated as implementation truth. |
| riscvBASIC.txt | RISC-V assembler reference, not a BASIC statement manual; excluded from language coverage. |
| sound research documents | Background material rather than BASIC language references; excluded from statement coverage. |

## Normalized capability matrix

| Programming capability | ModernBASIC equivalent | Status |
| --- | --- | --- |
| Numbered program storage and ordered fall-through | Numbered lines with colon-separated statements and a compiled statement program counter | Direct |
| One-statement execution | READY <code>STEP [count]</code>, exact colon-statement boundaries, and next-source-line reporting | Direct |
| Continue after a pause or STOP | <code>CONT</code>; STEP and CONT preserve the exact next statement | Direct |
| Fresh restart | <code>RUN</code> always creates a new execution session, including after STOP | Direct |
| Unconditional branch | <code>GOTO</code> and <code>GO TO</code> | Direct |
| Classic subroutine | <code>GOSUB</code>/<code>GO SUB</code> and <code>RETURN</code>, including same-line return addresses | Direct |
| Computed branch/call | <code>ON expression GOTO</code> and <code>ON expression GOSUB</code> | Direct |
| Conditional execution | Inline and block <code>IF/THEN/ELSE</code> | Direct |
| Counted and conditional loops | <code>FOR/NEXT</code>, <code>WHILE/WEND</code>, <code>DO/LOOP</code>, <code>REPEAT/UNTIL</code>, and structured EXIT | Direct |
| Multiway selection | Standard and BBC <code>SELECT CASE</code> forms | Direct |
| Named procedures and functions | <code>SUB</code>, <code>FUNCTION</code>, <code>DEF FN</code>, BYVAL/BYREF, local/STATIC/SHARED state, and recursion | Direct |
| Variables, constants, arrays, and records | LET/implicit assignment, CONST, DIM, REDIM PRESERVE, OPTION BASE, TYPE, nested records, and LBOUND/UBOUND | Direct |
| Embedded data | <code>DATA</code>, <code>READ</code>, and targeted <code>RESTORE</code> | Direct |
| Console input and output | PRINT, WRITE, INPUT, LINE INPUT, TAB/SPC, PRINT USING, WIDTH, and nonblocking INKEY$ | Direct |
| Cursor/character-cell graphics | <code>TEXT x,y,...</code>, pixel drawing, and program-defined glyph shapes replace machine character memory and terminal escape codes | Composed |
| Random behavior | RND, RANDOMIZE, RAND/RANDINT and modern distributions | Direct |
| Error trapping | ON ERROR GOTO, ERROR, ERR/ERL, RESUME/RESUME NEXT/target | Direct |
| Sequential, random, and binary files | Sandboxed OPEN/CLOSE, PRINT#/WRITE#/INPUT#/LINE INPUT#, FIELD/LSET/RSET, GET/PUT, SEEK, LOC/LOF/EOF | Direct |
| Matrix programming | MAT assignment, add/subtract/multiply/scale, transpose, inverse/determinant, ZER/CON/IDN, INPUT/PRINT/READ | Direct |
| Matrix file output | Iterate array bounds and use WRITE# or direct record PUT | Composed |
| Timing and pause | Interruptible monotonic <code>WAIT milliseconds</code> and TIMER traps | Direct |
| Trace and debugging | TRON/TROFF plus exact READY STEP; STEP counts statements, not physical lines | Direct |
| Keyboard, mouse, timer, collision events | INKEY$, MOUSE functions, ON TIMER, ON COLLISION, and explicit polling | Direct |
| Graphics primitives and fills | SCREEN, PSET/PRESET, LINE, rectangles, rounded rectangles, circles, ellipses, arcs, Bezier paths, polygons, classic flood PAINT plus deterministic path-clipped PAINT TEXTURE and bounded PAINT FILTER finishing, BRUSH hardness/opacity/flow, colors, gradients, alpha, and blend modes | Direct |
| Drawing transforms and organization | TRANSLATE, ROTATE, SCALE, validated GROUP nesting, and visible/opacity-bearing LAYER scopes | Direct |
| Depth drawing and light | DEPTHGRID/DEPTHPERCEPTION, GRIDON/OFF/POINT, and native LIGHT radial illumination | Direct |
| Retained point-perspective world | PERSPECTIVE, classic PSET/SPRITE extensions, and the single OBJECT family store XYZ pixels, billboards, sprites, camera, dimensions, motion, and point lights in one map; projection scales by focal-length/depth and draws far-to-near | Direct |
| Graphics operating modes | SCREEN TEXT, GRAPHICS2D, GRAPHICS3D, and SPLIT; logical resolution plus host display profile/size are independently configurable | Direct |
| Shape capture/replay | Retained sprites, common-format alpha-aware BITMAP and BITMAP WARP texture deformation, BUFFER/FRAME/FLIP, FLIPBOOK playback/video export, and screenshot/image export replace machine-specific framebuffer GET/PUT and SSHAPE/GSHAPE formats | Composed |
| Sprites and collision | SPRITE, MOVESPRITE, two- or three-axis motion/acceleration, XYZ depth scale, live queries, projected collision query/trap | Direct |
| Multiple screens, windows, and menus | One configurable logical resolution-independent screen; draw panels/menus with shapes and TEXT, then poll mouse/keys | Composed |
| Function graphing | Cartesian, parametric, polar, scatter, histogram, axes/grid/window/zoom/style statements | Direct |
| Sound, music, waveform, and speech | SOUND, PLAY, WAVE/OSCILLATOR, ADSR/filter/LFO/effects, SoundFont instruments, WAVEFILE, SAY, and SING | Direct |
| Web data, downloads, browsing, and online media | Capability-gated WEB GET/POST/DOWNLOAD, WEB OPEN through the host browser, and direct HTTP(S) PLAY AUDIO/VIDEO streams | Native host API |
| Memory and I/O ports | PEEK/POKE/DEF SEG and INP/OUT/WAIT use bounded virtual memory and virtual ports | Virtualized |
| Machine-code calls | CALL/SYS/USR reach only explicitly registered host services | Virtualized |
| Runtime string-to-code execution | Ordinary expressions, FUNCTION, SELECT CASE, and the READY EVAL command are available; programs cannot inject new source text into the active evaluator | Boundary |

## Manual-family mappings

### Dartmouth 1964 and 1968

Every programming statement in the 1964 introductory set maps directly:
LET, PRINT, FOR/NEXT, GOTO, IF/THEN, DEF, READ/DATA, and END. The 1968
array, subroutine, function, and MAT material maps to DIM, GOSUB/RETURN,
DEF FN/FUNCTION, and native MAT operations. Dartmouth matrix results can be
written to a file with ordinary bounded loops and WRITE#.

### Microsoft BASIC

The programming statement families map as follows:

- CALL, GOSUB/RETURN, GOTO, ON GOTO/GOSUB, IF, FOR/NEXT, WHILE/WEND,
  STOP/CONT, RUN, END, CHAIN, COMMON, and SWAP are direct.
- DATA/READ/RESTORE, DIM/ERASE, DEF FN and DEF type forms, LET, INPUT,
  LINE INPUT, PRINT/PRINT USING, WRITE, LPRINT, WIDTH, RANDOMIZE, and REM
  are direct.
- OPEN/CLOSE, file-channel input/output, random FIELD/LSET/RSET/GET/PUT, and
  binary positioning are direct and sandboxed.
- ERROR/ERR/ERL, ON ERROR, RESUME, and CLEAR are direct.
- DEF SEG, PEEK/POKE, INP/OUT/WAIT, CALL/SYS/USR use bounded virtual or
  registered-service state.
- Editor/storage operations such as AUTO, DELETE, LIST, LOAD, SAVE, MERGE,
  RENUM, FILES, and KILL remain READY commands and are not programming
  statements in this matrix.

### OASIS/Phase One BASIC

CASE/CEND maps to SELECT CASE/END SELECT; IFEND and FNEND map to END IF and
END FUNCTION. CHAIN, CLEAR, CLOSE, COMMON, DATA, DEF, DIM, ELSE, END,
FOR/NEXT, GET/PUT, GOSUB/GOTO, IF/THEN, INPUT, LET, ON ERROR/GOSUB/GOTO,
OPEN, OPTION, PRINT/USING, RANDOMIZE, READ, REM, RESTORE, RESUME, RETURN,
RUN, STOP, WAIT, WHILE/WEND, and WRITE are direct.

MAT INPUT/PRINT/READ and matrix arithmetic are direct. MAT WRITE is composed
from bounds plus WRITE# or direct PUT. READNEXT's next-record outcome is the
omitted-record random GET form. LINPUT USING is LINE INPUT followed by normal
validation. SLEEP maps to WAIT; QUIT maps to END. CSI, LINK, MOUNT, and
UNLOCK are system/device commands and are excluded. READY STEP now follows
the manual's statement-count behavior.

### BBC BASIC

BBC outcomes are covered by block IF, FOR, REPEAT/UNTIL, WHILE, SELECT CASE,
PROC-like SUB procedures, FN/FUNCTION values, local/STATIC/SHARED variables,
arrays and MAT operations, random/sequential files, graphics primitives,
logical viewports through SCREEN and transforms, keyboard polling, timing,
and multi-voice sound. OSCLI, assembler, VDU byte protocols, and direct
machine memory are excluded or virtualized; their program-visible drawing and
input outcomes use native graphics and input APIs.

### Commodore 128 BASIC

DRAW, BOX, CIRCLE, PAINT, COLOR, GRAPHIC, and LOCATE-like drawing outcomes map
to the native logical screen, drawing cursor, and TEXT. SSHAPE/GSHAPE outcomes
map to retained BITMAP/sprite/buffer operations rather than Commodore memory
layouts. SPRITE, MOVSPR, collision, SOUND, PLAY, ENVELOPE/filter/tempo
outcomes, DO/LOOP/UNTIL, files, and ordinary control statements have direct
native equivalents. BANK, BOOT, BLOAD/BSAVE, DMA/monitor, and physical device
channels are system or hardware commands and are excluded.

### Amiga BASIC

Area fills, drawing, colors, points, circles, lines, patterns, regions, objects,
animation, collision, timer, mouse, menu interaction, sound, waveforms, and
speech map to native graphics, retained sprites/buffers, polling/traps, audio,
and SAY/SING. A ModernBASIC program draws its own panels and menus inside one
logical screen instead of creating several host OS windows. Machine-specific
screen modes become logical SCREEN dimensions. Amiga GET/PUT region outcomes
use retained objects, BITMAP, buffering, and image export rather than exposing
framebuffer memory. The IDE statement-step behavior is provided by READY
STEP and exact CONT. Amiga OBJECT outcomes also inform the single ModernBASIC
OBJECT family; retained XYZ forms of PSET and SPRITE share its world map,
perspective scale, layering, lighting, motion, and projected collision without accepting the Amiga dotted dialect statement set.

### TI beginner material and TI-84 Plus CE

The beginner statements PRINT, CLEAR, LET, SOUND, HCHAR/VCHAR, INPUT, GOTO,
COLOR, FOR/NEXT, RANDOMIZE, IF/THEN, KEY, SCREEN, and CHAR all have direct or
drawn-glyph equivalents.

TI control maps as follows: Lbl/Goto becomes numbered GOTO; prgm/Return becomes
SUB/CALL or GOSUB/RETURN; IS>/DS< becomes assignment plus IF; Menu becomes
INPUT/INKEY$/mouse plus SELECT CASE; Pause becomes STOP for operator
continuation or WAIT for timed continuation; DelVar becomes ERASE/CLEAR or
procedure-local scope. Disp and Output(row,column) use PRINT or graphics TEXT.
Graph styles/colors, windows, plots, lists, statistics, and getKey outcomes are
native. Calculator link/send/get/archive commands are device-management
operations and are excluded.

## Deliberate modern boundaries

These are not silent omissions:

- Programs cannot evaluate arbitrary source strings or mutate their own stored
  source while running. This keeps validation, resource accounting, and STEP
  behavior deterministic. Use FUNCTION, SELECT CASE, arrays, or host-approved
  services.
- Arbitrary host font discovery is not part of the logical graphics device;
  TEXT uses portable built-in rendering.
- Framebuffer region formats are not exposed. Retained shapes, sprites,
  bitmaps, buffers, and exported images provide the corresponding result
  without machine memory layouts.
- The runtime owns one logical screen. Multiple host OS windows and native
  desktop menus are replaced by program-drawn panels/menus plus input polling.
- Printer ports, calculator links, raw disk blocks, ROM calls, and privileged
  hardware access are outside the language boundary.

Within those boundaries, every manual-derived programming family has either a
direct native implementation, a documented modern composition, or a bounded
virtualized equivalent. The test suite—not the historical spellings—is the
authority for executable behavior.
