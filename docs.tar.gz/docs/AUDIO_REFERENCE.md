# Audio reference

ModernBASIC has one audio engine with two sound sources:

- a built-in oscillator for tones, sweeps, custom waves, and ordinary `PLAY`;
- a sampled General MIDI SoundFont device selected by `SOUNDFONT` and `INSTRUMENT`.

No vintage chip, ROM, or hardware register map is emulated.

## Statement summary

```text
CLEAR
SYNTHPROFILE profile$
VOICES count
OSCILLATORS count
BEEP
TEMPO bpm
VOICE voice
WAVE wave-definition
WAVE voice,wave-definition[,pulse-width]
WAVEFORM ...                         accepted WAVE alias
ADSR attack-ms,decay-ms,sustain,release-ms
ADSR voice,attack-ms,decay-ms,sustain,release-ms
ENVELOPE ...                         accepted ADSR alias
PULSEWIDTH width
PULSEWIDTH voice,width
PULSEWIDTH voice,oscillator,width
OSCILLATOR voice,slot,waveform,ratio,detune-cents,level
VOL level
VOL voice,level
STEREO voice,position
PAN position
MIXER voice,synth-level,midi-level
FILTER voice,mode[,cutoff-hz[,resonance[,key-track]]]
FILTERADSR voice,attack-ms,decay-ms,sustain,release-ms,amount
LFO voice,target,waveform,rate-hz,depth
GLIDE voice,duration-ms
DRIVE voice,amount
PLAY sequence$[,default-beats]
PLAY voice,sequence$[,default-beats]
PLAY AUDIO source$
PLAY VIDEO source$
PLAY FLIPBOOK id[,loops[,soundtrack$]]
SOUND start-hz,voice,duration-ms[,level][,end-hz][,steps]
SOUND ON | OFF | WAIT | RESUME
SOUNDFONT path$
SOUNDFONT voice,path$
SOUNDFONT first-voice,last-voice,path$
INSTRUMENT voice,name-or-program
EXPRESSION voice,level
MODULATION voice,level
SUSTAIN voice,level
PITCHBEND voice,position
REVERB voice,level
CHORUS voice,level
WAVEFILE path$
SAY text$[,rate-wpm][,pitch-hz][,level][,voice$][,mode$]
SING lyrics$,sequence$[,default-beats][,level][,voice$][,mode$]
```

The engine has a bounded maximum of 16 voices; the active count comes from the
current synthesis profile or `VOICES`. `VOICE n` selects an active implicit
voice used by the one-argument `WAVE`, four-argument `ADSR`, one-argument
`PULSEWIDTH`, `PAN`, `BEEP`, and `PLAY sequence$` forms.

`VOL level` sets the master output level; `VOL voice,level` sets one voice's
level within that master. Both accept normalized values from 0 through 1.

The three explicit media subcommands extend the classic verb without changing
note parsing. `PLAY AUDIO` decodes a local WAV, MP3, FLAC, Ogg, Opus, M4A, or
AAC asset or a direct HTTP(S) audio stream. `PLAY VIDEO` decodes a local MP4,
WebM, Matroska, MOV, AVI, or M4V or a direct HTTP(S) video stream, then projects
its complete frames while playing its audio track when present. Local paths
remain inside the file/output sandbox; URLs require the explicit `--network`
capability. `PLAY FLIPBOOK` consumes an ordered retained still sequence.

`PLAY` is a media decoder, not a browser or DRM bypass. Open ordinary YouTube,
Netflix, and other site pages with `WEB OPEN`; the Linux browser handles their
JavaScript, accounts, and licensed playback. See the networking section of the
language reference.

## PLAY notation

`PLAY` uses whitespace-separated tokens. Each note contains a letter, optional
accidental, and required octave:

```text
C4       middle C using default length
F#3      F sharp in octave 3
Db4      D flat in octave 4
C4:0.5   half a beat
C4/4     quarter note, one beat
C4/8     eighth note, half a beat
C4/8.    dotted eighth, three-quarters of a beat
C4/4@96 quarter note at MIDI velocity 96 (1 through 127)
R:2      two-beat rest
REST/4   one-beat rest
V2       use voice 2 for following tokens
```

Examples:

```basic
10 PLAY "C4/4@72 E4/4@84 G4/2@104"
20 PLAY 2,"C3:1 R:1 G3:2"
30 PLAY "V1 C4:1 V2 E4:2 V1 G4:1"
```

Every voice has an independent position. Switching with `Vn` resumes at that
voice's own cursor; it does not accidentally continue on the previous voice's
MIDI channel.

## Synthesis arrangements

The deterministic default remains `STANDARD`: 16 voices with three oscillator
layers per voice. Programs can select a named arrangement before creating audio:

```basic
10 CLEAR
20 SYNTHPROFILE "EXTENDED"
30 VOICES 12
40 OSCILLATORS 6
```

Profiles are `COMPACT` (8 x 2), `STANDARD` (16 x 3), `EXTENDED`
(16 x 6), and `MAXIMUM` (16 x 8). `SYNTHPROFILE "AUTO"` inspects available
logical CPUs, system memory, and the `paplay`/`aplay` playback command, then
selects a conservative profile. Playback availability does not limit WAV export:
the native engine renders software PCM before sending it to the audio device.

`VOICES count` selects 1 through 16 active voices. `OSCILLATORS count` selects
1 through 8 active oscillator slots in every native voice and can override a
profile. Put the profile first and exact overrides after it. Configure the
arrangement after `CLEAR` and before notes so reducing the active voice count
does not exclude already queued tracks. Host defaults can also be selected with
`--synth-profile`, `--synth-voices`, and `--synth-oscillators`; BASIC statements
then make the choice local to a program. `modernbasic audio-profile` reports the
current host scan and recommended arrangement.

## Oscillator controls

Every native voice contains the configured number of oscillator slots (three by
default). `WAVE` is the direct waveform control for oscillator 1 and accepts `SINE`, `TRIANGLE`, `SAW`, `PULSE`,
`NOISE`, `BANJO`, `GUITAR`, `BASS`, or a quoted custom table containing 2
through 65,536 values in the range -1 through 1:

```basic
10 VOICE 1
20 WAVE "PULSE",.35
30 ADSR 8,80,.72,120
40 VOL .8
50 FILTER 1,"LOWPASS",2400,.2
60 PLAY "C4/4 E4/4 G4/2"
70 WAVEFILE "oscillator.wav"
80 END
```

Numeric waveform identifiers remain accepted by `WAVE`/`WAVEFORM`:

| Value | Waveform |
| ---: | --- |
| 0 | Triangle |
| 1 | Saw |
| 2 | Pulse |
| 3 | Sine |
| 4 | Noise |

Attack, decay, and release are milliseconds. Sustain, volume, pulse width, and
resonance are normalized 0 through 1. Stereo position is -1 through 1.

`OSCILLATOR` builds a layered native voice. Slots are 1 through the configured
count, with a bounded maximum of 8; ratio is
0.0625 through 16 relative to the written or `SOUND` frequency; detune is
-2400 through 2400 cents; and level is 0 through 1. Oscillator 1 starts as a
full-level pulse wave, while oscillators 2 and 3 start silent. The physical
`BANJO`, `GUITAR`, and `BASS` models occupy oscillator 1.
`PULSEWIDTH voice,oscillator,width` controls any pulse slot.

`FILTER` is per voice. Its modes are `OFF`, `LOWPASS`, `HIGHPASS`, `BANDPASS`,
and `NOTCH`. Cutoff is 20 Hz through the audio Nyquist limit, resonance is 0
through 1, and optional key tracking is 0 through 1. `FILTERADSR` supplies a
separate cutoff contour; amount is -8 through 8 octaves. `LFO` independently
configures the `PITCH`, `LEVEL`, `FILTER`, or `PULSEWIDTH` target. Its
waveforms are `SINE`, `TRIANGLE`, `SAW`, `PULSE`, and `SAMPLEHOLD`; rate is 0
through 100 Hz. Pitch depth is in semitones, filter depth in octaves, and
level/pulse-width depths are normalized. Each target retains its own LFO, so
several modulations can run together. `GLIDE` sets 0 through 60,000
milliseconds of portamento. `DRIVE` adds normalized oscillator saturation
before the filter.

```basic
10 TEMPO 104
20 MIXER 1,1,0
30 OSCILLATOR 1,1,"SAW",1,-7,.70
40 OSCILLATOR 1,2,"PULSE",.5,5,.35
50 OSCILLATOR 1,3,"TRIANGLE",2,0,.18
60 PULSEWIDTH 1,2,.32
70 ADSR 1,4,130,.55,180
80 FILTER 1,"LOWPASS",850,.68,.45
90 FILTERADSR 1,5,180,.25,120,3.2
100 LFO 1,"PITCH","TRIANGLE",5.2,.10
110 GLIDE 1,75
120 DRIVE 1,.28
130 PLAY 1,"C3/8 G3/8 Bb3/8 C4/4 G3/8 C4/2"
140 END
```

`SOUND` generates a tone at the supplied frequency; it does not parse musical
notes or use `PLAY` notation. When the frequency is that of a musical note, the
generated tone can be used as that note. Its required arguments are frequency
in hertz, voice number, and duration in milliseconds. The voice keeps its
complete native patch: oscillators, ADSR, pulse widths, filter and filter
contour, LFOs, glide, drive, `VOL`, and `STEREO`. `SOUND` produces a steady
tone when `end-hz` is
omitted and a logarithmic sweep when it is present. A positive `steps` value
makes the sweep discrete. The optional normalized level applies only to that
tone. `PLAY` remains the separate statement for named-note notation, rests, and
beat-based sequencing.

```basic
10 WAVE 1,"TRIANGLE":ADSR 1,8,80,.7,140
20 SOUND 261.63,1,500
30 SOUND 329.63,1,500
40 SOUND 392,1,1000,.65
50 SOUND RESUME
60 END
```

## Sampled SoundFont instruments

`SOUNDFONT` loads an uncompressed SoundFont 2 bank. Paths beginning with
`soundfont/` address the dedicated root-level backend hardware directory and
remain stable when BASIC uses `CD`. Other paths resolve beneath the current
BASIC file root. Use it before `INSTRUMENT` and `PLAY`:

```basic
10 CLEAR
20 SOUNDFONT "soundfont/MuseScore_General.sf2"
30 TEMPO 88
40 INSTRUMENT 1,"ACOUSTIC GRAND PIANO"
50 INSTRUMENT 2,"VIOLIN"
60 INSTRUMENT 3,"STANDARD DRUM KIT"
70 VOL 1,.8
80 STEREO 2,-.2
90 EXPRESSION 2,.86
100 MODULATION 2,.14
110 SUSTAIN 1,.7
120 PITCHBEND 2,.02
130 REVERB 1,.24
140 CHORUS 2,.12
150 PLAY 1,"C4/4@76 E4/4@86 G4/4@98 C5/2@108"
160 PLAY 2,"E4/4@68 G4/4@76 C5/4@86 E5/2@96"
170 PLAY 3,"C2/4@116 F#2/8@72 F#2/8@68 D2/4@108"
180 PRINT "PLAYBACK STARTING"
190 END
```

`SOUNDFONT path$` selects one global bank. `SOUNDFONT voice,path$` binds a bank
to one BASIC voice, and `SOUNDFONT first-voice,last-voice,path$` binds it to an
inclusive range. This lets guitars, acoustic drums, bass, keyboards, and other
banks play together from one program and one sample-accurate `PLAY` timeline.
A later binding replaces an earlier binding for the affected voices.

For multiple operating-system users, keep programs and output files in a
different `--file-root` for each account and select one administrator-owned,
read-only bank directory with `--soundfont-root`. Instrument selection and
audio queues are process-local, so concurrent users do not alter one another's
sound controls.

The path must end in `.sf2` and is limited to 512 MiB. Both the backend and
user-bank paths reject traversal and symlinks. All `SOUNDFONT` statements must
occur before sampled notes have been queued. Compressed `.sf3`, SFZ, VST, and
Audio Unit instruments are not loaded by the built-in engine.

In a stored program, `SOUNDFONT` is an asset declaration: its voice numbers and
`.sf2` path must be literals. The loader opens and parses every distinct bank
before it commits the new program or reports the next prompt. The declaration
may appear in a colon-separated or inline `IF ... THEN` statement; source order
still controls its effect during execution. Success is reported as `LOADED
...; PREPARED ... ASSET(S).`; a missing or invalid bank leaves the previous
program intact. `RUN` then installs the prepared banks from memory instead of
reopening hundreds of megabytes at the first note. A relative user-bank path is
resolved from the loaded program's directory. The reserved `soundfont/` prefix
continues to select the configured read-only backend bank directory.

`INSTRUMENT` selects a General MIDI program for one BASIC voice. Names are
case-insensitive; `PIANO` is shorthand for program 0, and numeric programs range
from 0 through 127. Drum-kit names explicitly route only the selected voice to
MIDI percussion. Common drum notes include C2 (bass drum), D2 (snare), and
F#2 (closed hi-hat), depending on the selected kit.

Sampled-instrument controls are programmed directly in BASIC. `VOL` and
`STEREO` set per-voice level and pan. An explicit `ADSR` shapes the sampled
voice's attack, decay, sustain, and release; without it, the bank's natural
envelope is preserved. `EXPRESSION`, `MODULATION`, `SUSTAIN`, `REVERB`, and
`CHORUS` take a voice and a normalized value from 0 through 1.
`PITCHBEND` takes a voice and a position from -1 through 1; the standard range
is two semitones down or up. A note suffix such as `C4/4@96` sets its MIDI
attack velocity from 1 through 127. These controller values are channel-wide
settings for the queued render; this release does not provide DAW-style timed
automation curves or plug-in hosting.

`DSP voice,drive,tone,presence,compression,gate` configures one sampled
instrument after SoundFont rendering and before voices are mixed. All five
settings are normalized from 0 through 1. `drive` provides soft amplifier
saturation, `tone` controls the cabinet low-pass range, `presence` emphasizes
pick and strike detail, `compression` controls peaks, and `gate` selects the
fraction of each written note held before the SoundFont release begins. DSP is
opt-in and isolated per BASIC voice. A `drive` value of zero uses a transparent
clean path and does not apply the saturation curve.

```basic
100 DSP 1,.55,.48,.70,.30,.48
110 DSP 2,.28,.40,.72,.48,.64
```

## Selecting synth, MIDI, or both

`MIXER voice,synth-level,midi-level` routes subsequent `PLAY` notes for one
voice. Each level is 0 through 1:

```basic
10 MIXER 1,1,0       ' computer synthesizer only
20 MIXER 2,0,1       ' MIDI/SoundFont instrument only
30 MIXER 3,.65,1     ' both sources layered
```

Zero disables that destination; its notes are not scheduled there. Nonzero
values set the source balance. `VOL voice,level` is the overall voice level,
after that balance. Without `MIXER`, automatic routing remains: `PLAY` uses the
native generator when no SoundFont device is active and the MIDI/SoundFont
device when one is active. An explicit nonzero MIDI level makes `PLAY` connect
the configured or default SoundFont device if necessary. Use `SOUNDFONT` and
`INSTRUMENT` first when a specific bank and instrument are required.

This MIDI layer is the built-in sample-accurate General MIDI/SoundFont
renderer; it does not send events to an external hardware MIDI port. `SOUND`
always addresses the computer sound generator and never becomes `PLAY` or a
MIDI note command. When both queues contain music, live playback and
`WAVEFILE` overlay them on one timeline and preserve the programmed balance.

When `SOUNDFONT` is omitted, the engine searches for
`soundfont/MuseScore_General.sf2` in the root-level backend and then common
Linux locations for MuseScore General, FluidR3 GM, and TimGM6mb. The source
release does not bundle a default root-level GM bank.

For the recommended lossless MuseScore General bank, run:

```sh
./install-soundfont.sh
cargo run --release -- run programs/examples/soundfont.bas
```

The installer downloads the approximately 206 MiB SF2 and its MIT license from
[MuseScore’s official mirror](https://ftp.osuosl.org/pub/musescore/soundfont/MuseScore_General/).
On Debian or Ubuntu, `sudo apt install fluid-soundfont-gm` installs the
MIT-licensed FluidR3 GM alternative, which ModernBASIC discovers automatically.
Keep a bank’s license with redistributed copies and check its terms before
publishing or selling rendered audio.

## Queue and playback controls

- `SOUND OFF` stops live music and speech and mutes later output.
- `SOUND ON` re-enables output.
- `SOUND WAIT` leaves queued audio pending.
- `SOUND RESUME` starts the current queue in the background.
- `END` and `STOP` start queued audio when necessary and wait for playback to
  finish, so a BASIC program does not exit ahead of its music.
- `CLEAR` stops playback, clears speech, discards notes, resets instruments,
  restores oscillator defaults, and clears ordinary program state.
- `PLAY`, `SOUND RESUME`, `END`, and `STOP` never create an audio file.
- Only an explicit `WAVEFILE` statement writes a file. It writes the native
  mix, the SoundFont score, retained `SING` vocals, or their layered combination
  as programmed.
- A generated WAV can be muxed into program-driven MP4 or WebM output with
  `VIDEO START path$,fps,wav-path$`; both paths remain inside the output sandbox.

Live playback uses `paplay` when available and falls back to `aplay`. MIDI-only
sampled scores are rendered and written in bounded 2,048-frame chunks, so the first
audio does not wait for the complete song to render. Chunk boundaries preserve
ADSR, cabinet/filter, presence, drive, and compressor state. Deterministic
`WAVEFILE` export and native-plus-MIDI playback perform a complete render so
the two sources can be combined sample-accurately; clipping prevention keeps
the programmed relative balance.
Output is 44.1 kHz, signed 16-bit stereo PCM.

Run `./audio-test.sh` for a generated-WAV check followed by a four-note live
speaker test. `./audio-test.sh --no-play` performs only the deterministic WAV
check, which is suitable for a headless machine.

## Speech

`SAY` calls eSpeak NG or eSpeak directly without a shell. The defaults are 150
words per minute, 110 Hz, level 1, voice `en-us`, and mode `QUEUE`.

Modes are:

- `QUEUE`: speak after earlier queued requests;
- `INTERRUPT`: stop active and queued speech, then speak;
- `WAIT`: block the BASIC statement until speech finishes.

Rate is 40 through 450 words per minute, pitch is 65 through 320 Hz, and level
is 0 through 1.

### Timed singing

`SING` gives the eSpeak voice a musical contour by assigning one lyric syllable
to every non-rest note. Separate syllables with hyphens; whitespace also starts
a new syllable. The note string uses `PLAY` pitch, duration, dotted-note, rest,
and velocity notation. Rests consume time without consuming a syllable. The
current `TEMPO` converts beats to time, and an optional `default-beats` replaces
the normal one-beat default.

```basic
10 TEMPO 112
20 SING "Hap-py birth-day to you","G4/8 G4/8 A4/4 G4/4 C5/4 B4/2"
```

The optional level is 0 through 1. A note's `@velocity` scales that level. Voice
names and `QUEUE`, `INTERRUPT`, or `WAIT` modes match `SAY`; `WAIT` is the
`SING` default so a batch program cannot exit before its vocal completes. Every
note and rest still occupies its written time.

The vocal renderer removes device-start gaps by converting the complete line to
one continuous 44.1 kHz stereo PCM stream. It automatically applies an 8 ms
attack, a release of up to 24 ms, as much as 15 ms of adjacent-note crossfade,
and restrained stereo room reflections. Written rests prevent a dry crossfade
but let the room decay continue naturally. A short syllable leaves a shaped
tail inside its note; a long syllable is released at the note boundary instead
of being cut off abruptly. These smoothing effects are deliberately subtle and
do not require extra BASIC arguments.

One statement accepts at most 4,096 combined notes and rests and at most 30
minutes. Notes must lie in the practical C2-through-C6 vocal range and must last
at least 20 milliseconds. The number of lyric syllables must exactly equal the
number of non-rest notes; `Vn` voice switches are rejected because the selected
eSpeak voice applies to the complete vocal line.

This is an intentionally synthetic singer, not a studio vocal model. The
eSpeak pitch control follows the written melody but is not sample-accurate
equal-tempered synthesis. Each validated `SING` statement is retained for an
optional `WAVEFILE`: the first vocal starts at frame zero, later vocals append
on the vocal timeline, and the result is mixed sample-accurately with queued
native and SoundFont music. `INTERRUPT` replaces earlier retained vocals just
as it replaces the live speech queue. Live `SING` still runs when its statement
executes; export re-renders the retained score. Both paths require eSpeak NG or
eSpeak, and live playback additionally requires `paplay` or `aplay`.

## Removed 0.7-era spellings

The current source restores `VOICES` as a bounded native-synthesis arrangement
control and adds `OSCILLATORS` plus `SYNTHPROFILE`. It intentionally does not
expose `VOLUME`, `MUSIC CLEAR/SCORE/PLAY/SAVE`, `STRUM`, or `HIT`. Use the
bounded statements documented above. `REVERB`, `CHORUS`, `EXPRESSION`, and
`MODULATION` are voice-local controls applied with standard General MIDI
controller semantics to that voice's sampled track; voices that reuse a MIDI
channel do not overwrite one another's queued score settings.
