# Language reference

This document summarizes the current 0.8.2 implementation. It is a guide to
ModernBASIC, not a claim that every historical dialect manual is reproduced
page for page.

## Program model

- Stored source uses line numbers from 1 through 65,529.
- A line number followed by text inserts or replaces a line.
- A line number alone deletes that line.
- Colons separate statements without splitting strings, comments, or `DATA`.
- Immediate statements use the same tokenizer and execution engine as stored
  statements.
- `STOP` retains an exact statement-level continuation point for READY
  `CONT`. `CONT` is a session command, not an executable statement inside a
  stored program.
- READY `STEP [count]` executes exact statements rather than whole physical
  lines; colon-separated statements, GOTO/GOSUB targets, and RETURN addresses
  remain individually observable. `RUN` always starts a fresh session.

## Values and expressions

ModernBASIC uses checked signed 64-bit integers, finite binary64 reals,
owned UTF-8 strings, complex numbers, and lists. Traditional suffix typing is
accepted. Arithmetic overflow, invalid conversion, non-finite results, and
illegal quantities are errors rather than host-language wraparound.

Implemented expression areas include:

- ordinary arithmetic and comparison, checked `MOD`, integer `DIV`/`\`, and
  boolean/bitwise `NOT`, `AND`, `OR`, `XOR`, and BBC `EOR`;
- classic bare and argument-taking `RND`, plus checked `FACT`/`FACTORIAL`;
- string slicing, ASCII case conversion, search, formatting, `DEC`, and
  `BIN$`/`OCT$`/`HEX$`;
- trigonometric, hyperbolic, exponential, rounding, and special functions;
- number theory, probability, statistics, regression, and finance;
- polynomial, numerical, signal, geometry, and linear-algebra functions;
- complex arithmetic and list-oriented analysis;
- `LBOUND(array[,dimension])` and `UBOUND(array[,dimension])`, including
  `OPTION BASE`, resized, record-field, local, `STATIC`, and BYREF arrays;
- host-local seconds-since-midnight `TIMER`, local/session `DATE$` and `TIME$`,
  logical text-row `CSRLIN`/`CSRLIN()`,
  nonblocking `INKEY$`/`INKEY$()`, and live `PCOLLISION(sprite[,sprite])`;
- bounded host-approved `COMMAND$` and `ENVIRON$(name-or-index)` process
  context.

`PI()` is the unambiguous built-in constant. Bare `PI` remains an assignable
classic numeric variable, which preserves Microsoft-family variable semantics
but differs from dialects that reserve bare `PI` as a constant.

`COMMAND$` and `COMMAND$()` return the command tail approved by the host.
`ENVIRON$(name$)` performs an ASCII-case-insensitive lookup, while
`ENVIRON$(n)` returns the one-based nth `NAME=VALUE` entry. A missing name or an
index beyond the supplied entries returns an empty string; a nonpositive index
is an illegal quantity. Duplicate names retain their original position but use
the final spelling and value.

Both sources are empty by default. Library hosts opt in with
`RunOptions::with_command_line`, `with_environment`, or
`with_environment_variable`. The CLI accepts repeatable `--env NAME=VALUE`
options and joins arguments following `--` with one space for `COMMAND$`, for
example `modernbasic run --env MODE=production program.bas -- input.dat -v`.
ModernBASIC never imports ambient process variables implicitly. At most 255
environment entries are accepted, and the command plus normalized environment
must fit the configured string-byte budget.

## Statement index

This index describes the executable statement surface. Built-in expression
functions such as `ABS()`, `SIN()`, `SPRITEX()`, and `OBJECTZ()` are not
statements and are therefore not repeated here. Canonical spellings appear in
the main lists; accepted compatibility aliases are collected separately so an
alias is not mistaken for a second implementation.

Statements are case-insensitive. A colon separates statements on one source
line. `REM` and apostrophe introduce comments, and `?` tokenizes as `PRINT`.
Traditional suffixes are `$` for string, `%` for integer, `&` for long, `!`
for single precision, and `#` for double precision.

### Assignment, declarations, and data

```text
[LET] target = expression
MID$(string$,start[,length]) = replacement$
expression -> variable                 Unicode → is also accepted

CONST name=expression[,name=expression...]
DIM declaration[,declaration...]
REDIM [PRESERVE] declaration[,declaration...]
ERASE array[,array...]
OPTION BASE 0|1
SWAP variable,variable
CHANGE source TO destination
RANDOMIZE [seed]
CLEAR
SHARED name[,name...]
STATIC declaration[,declaration...]
COMMON name[,name...]

DATA values
READ target[,target...]
RESTORE [line]
```

`DIM` accepts ordinary arrays, typed primitive scalars and arrays, and
user-defined record scalars and arrays. `CLEAR` has the accepted `CLR` alias.

### Records and procedures

```text
TYPE name
    field AS INTEGER|LONG|SINGLE|DOUBLE|STRING [* bytes]|record-type
END TYPE

SUB name[([BYVAL|BYREF] parameter,...)]
END SUB
EXIT SUB

FUNCTION name[([BYVAL|BYREF] parameter,...)]
END FUNCTION
EXIT FUNCTION

CALL name[(arguments)]
DEF FNname(parameter[,parameter...])=expression
DEF SEG [= expression]
DEF USR[n]=service-address
DEFINT letter-range
DEFSNG letter-range
DEFDBL letter-range
DEFSTR letter-range
```

The spaced default-type forms such as `DEF INT A-Z` are accepted too. The
standalone spelling `DEFTYPE` is reserved by the tokenizer but has no
executable statement form; programs should use `DEFINT`, `DEFSNG`, `DEFDBL`,
or `DEFSTR`.

### Input and output

```text
PRINT [items]
PRINT USING format$;items
WRITE [items]
INPUT [prompt;]variable[,variable...]
LINE INPUT [prompt;]string-variable
GET variable

WIDTH columns
LOCATE row[,column[,cursor-visible]]
VIEW PRINT [top TO bottom]
HOME
HTAB column
VTAB row
TEXTCOLOR [foreground[,background]]
LPRINT [items]
LLIST [range]
NULL count
TRON
TROFF
```

`GET variable` is the console/key-input form. File-channel `GET #` is listed
with the file statements below. `LINEINPUT` is accepted as the compact spelling
of `LINE INPUT`.

Text rows are one-based 1 through 25 and columns are one-based 1 through 80;
explicit out-of-range `LOCATE`, `HTAB`, `VTAB`, or `VIEW PRINT` coordinates
raise `IllegalQuantity`. `VIEW PRINT` with no bounds restores the full screen.
`HOME` clears through the text backend and moves to column 1 at the active
region's top. `TEXTCOLOR` accepts zero through `0xFFFFFF`; one argument changes
the foreground, two change both colors, and no arguments restore defaults.
These identifier-encoded names remain ordinary assignable variables when
immediately followed by `=`.

`PRINT` column tracking and `WIDTH` wrapping count Unicode characters rather
than UTF-8 bytes. Numeric `PRINT USING` fields accept only integer and real
values; strings, complex values, and lists report `TypeMismatch`.

### Control flow

```text
END
STOP
SLEEP [seconds]

GOTO line                         GO TO line is accepted
GOSUB line                        GO SUB line is accepted
RETURN

IF condition THEN statement-or-line [ELSE statement-or-line]
IF condition GOTO line
IF condition THEN
    block
[ELSE
    block]
END IF

FOR variable=start TO limit [STEP increment]
NEXT [variable]
WHILE condition
WEND
DO [WHILE|UNTIL condition]
LOOP [WHILE|UNTIL condition]
REPEAT
UNTIL condition

EXIT FOR
EXIT WHILE
EXIT DO
EXIT REPEAT
```

`SLEEP` uses seconds and accepts fractional durations. A queued keypress ends
both timed and indefinite sleep; Ctrl+Escape/BREAK remains interruptible.

`RETURN` has no destination argument. It resumes at the exact statement after
the corresponding `GOSUB`. Block-IF endings `ENDIF`, `IFEND`, and `IF END` are
accepted aliases for `END IF`.

Selection supports both the standard and BBC-family structured forms:

```text
SELECT CASE expression
CASE value[,value...]
CASE low TO high
CASE IS comparison value
CASE ELSE
END SELECT

CASE expression OF
WHEN value-or-range
OTHERWISE
ENDCASE
```

`ENDSELECT`, `ENDCASE`, `END CASE`, and `CEND` are accepted compact endings.

### Computed branches, errors, and events

```text
ON expression GOTO line[,line...]
ON expression GOSUB line[,line...]

ON ERROR GOTO line
ERROR code
RESUME
RESUME NEXT
RESUME line

ON TIMER(seconds) GOSUB line
TIMER ON|OFF|STOP

ON COLLISION GOSUB line
COLLISION ON|OFF|STOP
```

### Files, memory, and host-approved services

```text
OPEN path$ FOR INPUT|OUTPUT|APPEND|RANDOM|BINARY AS #channel [LEN=record-size]
OPEN mode$,#channel,path$
OPEN #channel,path$,mode$
CLOSE [#channel[,#channel...]]

PRINT #channel,items
WRITE #channel,items
INPUT #channel,variables
LINE INPUT #channel,string-variable
GET #channel,...
PUT #channel,...
FIELD #channel,width AS string$[,width AS string$...]
LSET string$=expression$
RSET string$=expression$
SEEK #channel,position
CMD #channel[,print-list]

KILL path$
NAME old$ AS new$
CHAIN path$[,line]
MERGE path$
LOAD path$
SAVE path$
VERIFY path$

POKE address,value
OUT port,value
WAIT milliseconds
WAIT port,mask[,xor]
SYS service-address[,arguments]
CALL service-address[,arguments]
```

`PRINT#`, `WRITE#`, `INPUT#`, `LINE INPUT#`, and `GET#` are accepted compact
file-channel spellings. `PEEK`, `INP`, and `USR` are expression functions, not
statements. Memory, ports, and callable services are bounded virtual or
host-approved resources; these forms never expose unrestricted host hardware.

### Networking and host web services

```text
WEB OPEN url$
WEB GET url$,response$
WEB POST url$,body$,response$[,content-type$]
WEB DOWNLOAD url$,path$

PLAY AUDIO source$
PLAY VIDEO source$
```

Network access is a host capability and is disabled by default. Start a CLI
session with `--network`, or set `RunOptions::network_enabled` through the
library API. `WEB OPEN` hands an HTTP(S) address to the operating system's
default browser; on Linux this uses `xdg-open`. The browser remains responsible
for HTML, JavaScript, logins, cookies, accessibility, downloads initiated by a
page, and licensed/DRM playback. ModernBASIC does not embed or emulate a browser
engine.

`WEB GET` returns one UTF-8 response in a string variable. `WEB POST` sends a
string body and returns a UTF-8 response; its default content type is
`application/json`, and an optional fourth argument selects another content
type. Use `WEB DOWNLOAD` for binary data: it performs an HTTP(S) GET and writes
the response beneath the output sandbox. The host `curl` executable performs
HTTP, redirects, and TLS through fixed arguments. URLs are limited to HTTP and
HTTPS, embedded credentials are rejected, redirects cannot change protocol,
requests time out, and responses are bounded by `--max-network-bytes` (16 MiB
by default). Downloads must also fit the configured file limit.

`PLAY AUDIO` and `PLAY VIDEO` accept either an existing sandboxed local path
or a direct HTTP(S) media URL when the capability is enabled. For a stored
program, the loader reads or fetches the complete bounded source before
`READY.`; FFmpeg later decodes those retained bytes through fixed arguments and
the existing 30-minute media-duration ceiling. A normal YouTube, Netflix, or
other web-page URL is not a direct media source; pass that page to `WEB OPEN`
so the installed browser can handle its site logic and any licensed playback.

### Matrix statements

```text
MAT READ A[,B[(dimensions)]...]
MAT INPUT A
MAT PRINT A[,B...]
MAT PRINT A;
MAT target=source
MAT target=left+right
MAT target=left-right
MAT target=left*right
MAT target=(scalar-expression)*source
MAT target=TRN(source)
MAT target=INV(source)
MAT target=ZER[(dimensions)]
MAT target=CON[(dimensions)]
MAT target=IDN[(dimensions)]
```

`INV` stores the determinant in `DET`. Matrices may be vectors, row vectors,
or two-dimensional matrices; higher-rank matrix operations are rejected.

### Program-state commands accepted by the statement parser

The following commands alter the stored program or execution session. The
interpreter accepts them through the statement parser, but they are not
ordinary data-processing statements and should normally be entered at
`READY.`:

```text
RUN [line]
LIST [range]
NEW
LOAD path$
SAVE path$
MERGE path$
VERIFY path$
```

READY `CONT` resumes a stopped session. A stored `CONT` does not perform that
operation and reports `CAN'T CONTINUE`.

Microsoft `#` file-channel punctuation is tokenized directly. `OPEN` accepts
both `OPEN path$ FOR mode AS #channel` and the MS/GW-BASIC
`OPEN mode$,#channel,path$` shorthand. File access is bounded and sandboxed
beneath the configured root. `RANDOM` files support the classic
`FIELD`/`LSET`/`RSET` buffer workflow with `GET #channel[,record]` and
`PUT #channel[,record]`; an omitted record selects the record after the last
successful transfer. `BINARY` files support byte `PUT`, raw-byte destination
lists with `GET#`, and one-based `SEEK`.

A user-defined record can be transferred directly with
`GET|PUT #channel,[record-or-byte-position],record-variable`. The position may
be left empty to use the current binary position or next random record, as in
`PUT #1,,item`. Scalar records, indexed record-array elements, and nested
subrecords are supported. Direct layouts use portable little-endian signed
32-bit `INTEGER`, signed 64-bit `LONG`, IEEE binary32 `SINGLE`, IEEE binary64
`DOUBLE`, and exact UTF-8 bytes for `STRING * n`, in declaration order with no
alignment padding. A random record may be larger than the direct layout; unused
bytes are zero-filled. Dynamic `STRING` fields remain valid in memory but must
be changed to `STRING * n` for direct fixed-layout transfer. Short binary and
random reads leave the destination and logical file position unchanged.

Single-line numeric `DEF FN` definitions accept one or more parameters.

`REDIM [PRESERVE] name(bounds)[,...]` dynamically resizes numeric or string
arrays. Plain `REDIM` resets the resized arrays. `PRESERVE` retains explicitly
stored values throughout the coordinate region shared by the old and new
same-rank shapes, including multidimensional arrays; shrinking discards values
outside that overlap. The complete comma-separated resize commits atomically and
remains subject to the configured array and retained-storage limits.
`LBOUND(name[,dimension])` and `UBOUND(name[,dimension])` return the stored
inclusive bounds; BASIC dimension numbers are one-based regardless of the
array's subscript base. They do not allocate a missing array.

`CONST name=expression[,...]` evaluates each initializer once and creates an
immutable numeric or string scalar. Later constants in the same declaration may
use earlier ones. Assignment, `READ`, `INPUT`, `GET`, `SWAP`, `MID$`, and
other scalar destination forms cannot change a constant. `CLEAR` removes
mutable program state while retaining declared constants.

Stored programs may declare structured procedures with
`SUB name[([BYVAL|BYREF] parameter,...)]` through `END SUB` and invoke them with
`CALL name[(argument,...)]`. Unqualified parameters and explicit `BYVAL`
parameters are evaluated before entry and copied into each recursive call.
An explicit `BYREF` parameter requires an exact-type assignable variable or
array element and aliases that storage immediately; scalar record fields and
record-array fields are valid arguments. An alias forwarded through nested or
recursive `SUB`/`FUNCTION` calls continues to name the original target and does
not duplicate its retained-storage charge. A whole-array formal uses explicit
`BYREF name()` and its actual argument must use `name()`; BYVAL whole arrays
are rejected. Whole-array aliases have an exact element kind and participate
in ordinary element access, `READ`, `MAT`, `REDIM [PRESERVE]`, `ERASE`, and
bound queries. Record field arrays such as `PEOPLE.AGE()` are valid. A whole
array of records uses the exact-type formal `BYREF name() AS type`; each field
aliases the caller without copying and nested forwarding preserves the original
record storage.

Parameters and undeclared scalars are otherwise local to each recursive call.
`DIM name AS type` and `DIM name(bounds) AS type` inside a procedure create
per-call typed scalar or array storage, including user-defined records, unless
the base name is declared `SHARED`. `STATIC name[,...]` retains ordinary
scalars, `STATIC name AS type` retains typed primitive or record scalars, and
`STATIC name(bounds) [AS type]` retains primitive or record arrays and their
first established shape between calls.
Local array capacity and payload are released on return. `SHARED name[,...]`
routes named scalars and arrays to program-global storage. Existing arrays
declared outside a procedure remain global and readable there. Recursive local
record arrays isolate every field; STATIC record fields and metadata persist
without contaminating same-named procedures. `EXIT SUB` returns early.
Procedure calls share the configured call-depth and retained-storage budgets
with classic `GOSUB` and ordinary variables; failed binding/dimensioning is
atomic and trappable, and declaration/control-block structure is validated
before execution.

`FUNCTION name[([BYVAL|BYREF] parameter,...)]` through `END FUNCTION` declares
a multi-line value-returning procedure. Assigning to the function name sets its
return value; an unassigned numeric or string return slot has that type's
default value. `EXIT FUNCTION` returns early. Functions support recursion,
calls to structured `SUB` procedures, and the same parameter-mode, local,
`SHARED`, `STATIC`, array, depth, and storage rules as `SUB`. Only the selected
branches of `IF`, loop conditions, `SELECT CASE`, and `PIECEWISE` invoke
functions, so stateful functions preserve language short-circuit behavior.
Stored `SUB` and `FUNCTION` declarations may be called from a running program
or directly at the `READY.` prompt. Single-line `DEF FN` and multi-line
`FUNCTION` calls compose in either direction, evaluate arguments once, retain
lazy `PIECEWISE` branches, preserve complex results, and share a bounded
cross-recursion depth.

`TYPE name` through `END TYPE` declares a record layout. Each field uses
`field AS INTEGER|LONG|SINGLE|DOUBLE|STRING`; `STRING * bytes` declares a
fixed-width string that truncates or space-pads assignments. A field may also
use `field AS another_type` to nest a user-defined record. Forward TYPE
references are accepted, while missing types and direct or indirect recursive
layouts are rejected before execution. Layout validation is bounded to 256
nested levels and 65,536 flattened primitive fields. Field names follow
ordinary ModernBASIC identifier rules and therefore cannot be reserved
statement words. `DIM value AS type` creates a scalar record and
`DIM values(bounds) AS type` creates an array of records. Multi-level paths
such as `value.address.city` and
`values(index).address.coordinates.x` are accepted; listings canonicalize
the latter to `values.address.coordinates.x(index)`.

Record fields participate in normal typed assignment, expressions,
`DATA`/`READ`, `INPUT`, `LINE INPUT`, file input, raw `GET`, storage limits,
and array bounds. `REDIM [PRESERVE] values(bounds)` resizes every field array
atomically, preserving their common coordinate region when requested, and
`ERASE values` releases every field array and its retained payload. A stored
TYPE declaration is also available to `DIM` commands entered at `READY.`.
Exact-type `destination = source` assignment copies every field of scalar
records or indexed record-array elements by value. The source is captured
before any destination write, and storage-limit failure rolls the whole copy
back rather than leaving a partially updated record. Nested subrecords are
also assignable as whole values when their declared TYPEs match exactly.
Typed whole-array formals can receive either a root record array or one of its
nested subrecord arrays and can forward either alias through further
`SUB`/`FUNCTION` calls.

## Program editing

The graphical and terminal `READY.` environments provide the following
commands. These are editor, session, or filesystem commands rather than
stored-program statements:

```text
<number> <statement>                  insert or replace one stored line
<number>                              delete one stored line
<statement>                           execute a BASIC statement immediately

LIST [n|n-m|-m|n-]
DELETE n|n-m|-m|n-
RENUM [new],[old],[increment]
AUTO [start],[increment]
EDIT line
RUN [line]
STEP [count]
CONT

LOAD path$
SAVE path$
MERGE path$
VERIFY path$
OLD
NEW
STATUS
LENGTH
EVAL expression

PWD
CD [path]
DIR [/S] [path|pattern]
TREE [path]
MKDIR path
RMDIR path
KILL path
NAME old AS new
COPY source AS destination

HELP
QUIT
```

Accepted READY aliases are `RENUMBER` for `RENUM`, `SCRATCH` for `NEW`,
`CHDIR` for `CD`, `FILES`/`CAT`/`CATALOG`/`LS` for `DIR`,
`REN`/`RENAME` for `NAME`, and `EXIT`/`BYE` for `QUIT`. `AUTO`, `DELETE`,
`EDIT`, and `RENUM` deliberately reject execution from inside a running
program. `KILL` and `NAME` also have sandboxed executable statement forms.

Plain `DIR`, or `DIR` with a directory path, groups entries as `DIRECTORY
FOLDERS`, `BASIC PROGRAMS`, and `OTHER FILES`. This keeps `.bas` programs
prominent while leaving their data and support files available at the bottom.
A pattern such as `DIR *.dat` narrows the listing under `MATCHING FILES`.
`DIR /S` and `TREE` remain explicit recursive views of every file and subfolder.

The READY file browser reports only BASIC-visible paths. Its root is `programs`,
so child directories appear as `programs/examples` or `programs/music`; the
long canonical host path remains internal. Listings do not repeat the root
name; they begin with the `DIRECTORY FOLDERS`, `BASIC PROGRAMS`, and `OTHER
FILES` section headings. File sizes, entry counts, and byte totals are reported.
Existing components and wildcards are case-insensitive. `/` and `\` are
BASIC-root aliases, both slash styles work as
separators, parent navigation clamps at the root, and recursive `TREE` browsing
is bounded and does not follow symbolic links.

### Asset preparation at READY

Creating an execution session, CLI `run`, and interactive `LOAD`/`LOADB`
discover and prepare all static inputs declared by the stored program before
the session reaches `READY.`. This includes explicit `SOUNDFONT` banks,
`BITMAP` and `BITMAP WARP` images, every `FLIPBOOK CREATE` frame, `PLAY AUDIO`
and `PLAY VIDEO` sources, and declared playback or video soundtracks. SoundFonts
are parsed, images are decoded, and media files or approved HTTP(S) responses
are retained as immutable bytes. `INSTRUMENT` also prepares the default sampled
bank. `RUN` uses these in-memory objects and does not reopen or refetch their
sources.

Static asset paths and any `SOUNDFONT` voice range must therefore be literals in
a stored program, including asset statements nested after `THEN` or a colon.
Relative paths are resolved from the loaded program's directory, independently
of the runtime file current directory; later `CD` commands do not retarget the
prepared assets. A failed asset preparation is atomic: the new program never
reaches `READY.` and an interactive load keeps the prior program. Generated
outputs named by `SAVEIMAGE`, `SCREENSHOT`, `RENDER`, `DISPLAY`, or `WAVEFILE`
are not premature inputs; when produced, their decoded image or audio bytes are
retained immediately for later `BITMAP`, `FLIPBOOK`, playback, or soundtrack
use in the same run. Ordinary `OPEN` data files, web-service operations, and
output encoders remain runtime operations by design.

## Graphics

The canonical graphics statement families are:

```text
SCREEN       CLS          COLOR          PALETTE
PSET         PRESET       LINE           BRUSH
RECTANGLE    CIRCLE       ELLIPSE        PAINT
MOVE         DRAWTO       DRAW           POLYGON
GRADIENT     RADIALGRADIENT
ARC          BEZIER       ROUNDEDRECT
OPACITY      BLEND
TRANSLATE    ROTATE       SCALE
NGON         STAR         PATH           BITMAP
PERSPECTIVE  OBJECT       LIGHT
DEPTHGRID    DEPTHPERCEPTION
GRIDON       GRIDOFF      GRIDPOINT
LAYER        ENDLAYER     GROUP          ENDGROUP
TEXT
SPRITE       MOVESPRITE   SPRITEMOTION   ADVANCESPRITES
BUFFER       FRAME        FLIP
SCREENSHOT   SAVEIMAGE    DISPLAY
FLIPBOOK     VIDEO
```

The principal family subcommands and operating modes are:

```text
SCREEN TEXT|GRAPHICS|GRAPHICS2D|GRAPHICS3D|SPLIT
SCREEN classic-mode
SCREEN width,height[,background]

PAINT (x,y)[,fill[,border]]
PAINT TEXTURE path$,seed,scale,octaves,color1,color2[,opacity[,blend$]]
PAINT FILTER "BLUR",radius
PAINT FILTER "SHARPEN",amount
PAINT FILTER "COLOR",brightness,contrast,saturation

BITMAP path$,x,y,width,height
BITMAP WARP path$,anchor-x,anchor-y,width,height,angle,bend,turn[,light]

OBJECT SHAPE id,x,y,z,width,height,fill[,stroke]
OBJECT MOVE id,x,y,z
OBJECT SCALE id,width,height
OBJECT CAMERA x,y,z
OBJECT LIGHT id,x,y,z,intensity,range,color
OBJECT REMOVE id
OBJECT CLEAR

FLIPBOOK CREATE id,template$,first,last,fps
FLIPBOOK REMOVE id
FLIPBOOK CLEAR

VIDEO START path$,fps[,soundtrack$]
VIDEO FRAME
VIDEO STOP
VIDEO EXPORT flipbook-id,path$[,soundtrack$]
```

Accepted graphics aliases are `RECT` for `RECTANGLE`, `OVAL` for `ELLIPSE`,
`BEGINLAYER` for `LAYER`, `BEGINGROUP` for `GROUP`, `BLIT` for `SPRITE`, and
`RENDER` for `SAVEIMAGE`. Each pair reaches one implementation rather than
duplicating the feature.

The organized calculator-style graph family is:

```text
GRAPH CLEAR
GRAPH DISPLAY [path$]
GRAPH WINDOW xmin,xmax,xscale,ymin,ymax,yscale
GRAPH FUNCTION expression[,color]        GRAPH PLOT is an alias
GRAPH INVERSE expression[,color]
GRAPH LINE ...                           GRAPH CIRCLE ...
GRAPH TEXT ...
GRAPH HORIZONTAL ...                     GRAPH VERTICAL ...
GRAPH TANGENT ...                        GRAPH SHADE ...
GRAPH GRID ON|OFF
GRAPH AXES ON|OFF
GRAPH LABELS ON|OFF
GRAPH COORDS ON|OFF
GRAPH ZOOM STANDARD|TRIG|DECIMAL|SQUARE
```

The direct TI-style graph spellings are:

```text
CLRDRAW       DISPGRAPH
ZSTANDARD     ZTRIG         ZDECIMAL      ZSQUARE
AXESON        AXESOFF
LABELON       LABELOFF
COORDON       COORDOFF
GLINE         HORIZONTAL    VERTICAL      GCIRCLE
DRAWF         DRAWINV       TANGENT       SHADE
FNON          FNOFF         GRAPHSTYLE
PXL-ON        PXL-OFF       PXL-CHANGE
PT-ON         PT-OFF        PT-CHANGE
GTEXT
```

Direct `GRIDON` and `GRIDOFF` belong to the retained depth-grid graphics
family because that dispatcher has priority. Use `GRAPH GRID ON` and
`GRAPH GRID OFF` for the calculator graph grid. Scatter, histogram,
parametric, and polar renderers are command-line library facilities, not BASIC
statements.

The Artist-derived renderer is built into the Rust library; no external
graphics compatibility renderer is selected at runtime.

`RECT` and `RECTANGLE` accept either
`x,y,width,height[,stroke[,fill[,stroke_width]]]` or the endpoint form
`(x1,y1)-(x2,y2)[,stroke[,fill[,stroke_width]]]`. Graphics colors may be
palette indexes, hexadecimal strings, or case-insensitive names such as
`"RED"`, `"SKYBLUE"`, and `"GOLD"`; `#RRGGBBAA` adds an alpha channel.
Lines, circles, ellipses, rounded rectangles, and their filled/stroked edges
use subpixel coverage in the integrated raster and video renderer.
`BRUSH (x1,y1)-(x2,y2),size,color[,hardness[,opacity[,flow]]]` paints an
antialiased soft or hard stroke. `size` is 0.1 through 2048 logical pixels;
hardness, opacity, and flow are independently normalized from 0 through 1.
The retained command is rendered identically for the live screen, still-image
output, and video frames.

`MOVE x,y` changes the current drawing point. `DRAWTO
x,y[,color[,width]]` draws from that point and makes the destination the new
current point. Additional `DRAWTO` fields are not part of the language syntax.

`BITMAP path$,x,y,width,height` accepts bounded P6 PPM plus PNG, JPEG, WebP,
BMP, and TIFF stills. Compressed images are decoded locally through fixed
FFmpeg arguments; URLs and decoder options are not accepted. Alpha from formats
that carry it is retained, and premultiplied bilinear filtering prevents dark
fringes at transparent edges.

`BITMAP WARP path$,anchor-x,anchor-y,width,height,angle,bend,turn[,light]` is
the deformable form in the same statement family. The source bottom center is
anchored at `(anchor-x,anchor-y)`; angle is clockwise degrees, bend and turn are
normalized from -1 through 1, and optional light is 0 through 2 with a default
of 1. A bounded texture mesh curves the centerline, foreshortens and shades the
turned surface, and preserves source alpha. This suits leaves, flags, cloth, and
other photographed or painted flexible objects without introducing a second
bitmap command. PNG export follows the complete raster path, so imported
photographic pixels, alpha compositing, warping, and vector painting all survive
into the exported still instead of being dropped by a vector-only conversion.

`PAINT (x,y)[,fill[,border]]` flood-fills the connected region containing the
seed pixel. The optional classic border color is accepted and validated, but
the current retained renderer does not use a separate border color to stop the
fill; the connected region in the rendered raster determines the boundary.
Custom screens are limited to 16,777,216 pixels so framebuffer and flood-fill
allocations remain bounded.

Modern raster painting stays in that classic statement family:

```basic
PAINT TEXTURE path$,seed,scale,octaves,color1,color2[,opacity[,blend$]]
PAINT FILTER "BLUR",radius
PAINT FILTER "SHARPEN",amount
PAINT FILTER "COLOR",brightness,contrast,saturation
```

`PAINT TEXTURE` synthesizes deterministic smooth fractal detail and clips it to
each closed subpath. `seed` selects the repeatable pattern, `scale` is 0.25
through 4096 logical pixels, `octaves` is 1 through 8, opacity is 0 through 1,
and the optional blend uses the existing `BLEND` mode names. Layer two or more
scales to build macro color variation and fine surface grain without a source
bitmap. `PAINT FILTER` finishes the complete raster accumulated so far: blur
radius is 0 through 32 pixels, sharpen amount is 0 through 4, and the three
color multipliers are each 0 through 4. These are retained, deterministic,
memory-bounded raster operations used by screen presentation, PPM/PNG capture,
FLIPBOOK, and VIDEO output. Like imported bitmap pixels, procedural textures and
finished pixels are raster effects and are not emitted as editable SVG objects.

`SCREEN width,height[,background]` defines the logical graphics device, not a
request to change the physical monitor mode. All drawing, sprite, collision,
mouse, screenshot, and video coordinates use that logical pixel grid. Resizing
the host window never changes the BASIC screen or its aspect ratio. The native
shell defaults to `--graphics-scale fit`, centering the complete device with
black letterbox or pillarbox bars. `--graphics-scale stretch` explicitly fills
the host graphics region and may distort the image. Initial window profiles are
`--display-profile compact` (800x600), `desktop` (1100x760), `hd` (1280x720),
and `fullhd` (1920x1080); `--width` and `--height` override either dimension,
and the shell clamps the initial size to the available physical display. These
host options do not alter BASIC language behavior or exported image/video
resolution. `SCREEN TEXT`, `SCREEN GRAPHICS`, `SCREEN GRAPHICS2D`,
`SCREEN GRAPHICS3D`, and `SCREEN SPLIT` select the visible operating mode
without changing the host display. A numeric or
`SCREEN width,height[,background]` configuration resets the logical graphics
device to 2D and clears retained perspective state.

Point-perspective graphics reuse classic pixel and sprite statements and keep
one organized `OBJECT` family:

```basic
10 SCREEN 1280,720,"#07111F"
20 PERSPECTIVE 640,300,700,1,10000,.25
30 PSET (-30,0,180),"WHITE"
40 OBJECT SHAPE TOWER,0,0,100,20,80,"GOLD","BROWN"
50 SPRITE SHIP,(25,0,70),12,8,"SKYBLUE","WHITE"
60 OBJECT LIGHT SUN,-40,80,30,1.2,500,"WHITE"
70 MOVESPRITE SHIP,30,5,60
80 SPRITEMOTION SHIP,2,0,-4,0,0,1
```

`PERSPECTIVE horizon-x,horizon-y,focal-length[,near,far,ambient]` configures
the vanishing point, depth clipping, and base light. It also selects 3D mode.
Every retained world pixel, object, and 3D sprite stores X, Y, and Z in memory;
positive Y is up, the camera looks toward positive Z, and Z supplies depth.

Classic `PSET (x,y)[,color]` remains an immediate 2D canvas pixel.
`PSET (x,y,z)[,color]` stores a one-world-unit pixel at that XYZ coordinate;
its projected square grows nearer the camera and shrinks farther away.
`PRESET (x,y,z)` removes the retained pixel at that exact coordinate.

Classic `SPRITE id,x,y,width,height[,fill[,stroke]]` remains a 2D screen
sprite. `SPRITE id,(x,y,z),width,height[,fill[,stroke]]` stores an XYZ sprite
whose coordinate is its bottom-center anchor. `MOVESPRITE id,x,y[,z]` moves
either form; omitting Z preserves an XYZ sprite depth. `SPRITEMOTION` keeps its
2D `id,vx,vy[,ax,ay]` form and adds
`id,vx,vy,vz[,ax,ay,az]`. `ADVANCESPRITES seconds` integrates all axes.
`SPRITEX`, `SPRITEY`, `SPRITEZ`, `SPRITESCALE`, `SPRITEVX`, `SPRITEVY`,
`SPRITEVZ`, `SPRITEAX`, `SPRITEAY`, and `SPRITEAZ` query retained state. A 2D
sprite reports Z zero and scale one. Collision tests use the current projected
bounds of XYZ sprites.

`OBJECT SHAPE id,x,y,z,width,height,fill[,stroke]` stores a billboard object
with the same bottom-center convention. `OBJECT MOVE`, `OBJECT SCALE`,
`OBJECT CAMERA`, `OBJECT LIGHT`, `OBJECT REMOVE`, and `OBJECT CLEAR` are the
only mutating members of that family; there are no alternate aliases.
`OBJECTX`, `OBJECTY`, `OBJECTZ`, `OBJECTSCALE`, `OBJECTWIDTH`, and
`OBJECTHEIGHT` query retained object state.

Projection uses `screen-scale=focal-length/(entity-z-camera-z)`. Entities
outside the near/far interval are clipped. Every visible pixel, object, and
sprite is sorted together from far to near, so depth controls both scaling and
layering. Each `OBJECT LIGHT id,x,y,z,intensity,range,color` applies the same
bounded distance-attenuated shading to every retained entity type. This creates
the 3D illusion on the 2D canvas without a polygonal 3D renderer.

`SCREEN GRAPHICS2D` hides the projected world without deleting it;
`SCREEN GRAPHICS3D` shows it again. `CLS` clears ordinary drawing state, while
`OBJECT CLEAR` releases the complete XYZ memory map and its lights. A numeric
`SCREEN` configuration also resets the world. Live display, SVG/PPM/PNG export,
screenshots, and video all use the same projection.

`GRADIENT id,x1,y1,x2,y2,color1,color2` and
`RADIALGRADIENT id,cx,cy,radius,color1,color2` define smooth paints. Pass
`"url(#id)"` as a shape's fill to use one in live raster, SVG, screenshot, and
video output. For example:

```basic
10 GRADIENT SKY,0,0,0,720,"#050817","#4A285D"
20 RECTANGLE 0,0,1280,720,"none","url(#SKY)",1
```

`OPACITY value` and `BLEND mode$` modify the most recently drawn shape.
Available raster/SVG modes are `normal`, `multiply`, `screen`, `overlay`,
`darken`, `lighten`, `difference`, `xor`, `add`, `exclusion`, `color-dodge`,
`color-burn`, `hard-light`, `soft-light`, `erase`, `hue`, `saturation`,
`color`, and `luminosity`. Raster compositing uses bounded shape-local work
buffers rather than allocating two full screens for every effect.

`TEXT x,y,size,text$[,color]` draws scalable, correctly mapped printable ASCII
text in the integrated raster/video path. At display sizes, capitals, digits,
and common presentation punctuation use an antialiased geometric stroke face;
tiny or unsupported glyphs use the compact bitmap fallback. Both faces are
portable and require no host font service. Arbitrary font-family or font-file
selection is not yet part of the BASIC graphics device.

`CLS [color]` deterministically clears the selected drawing buffer, its sprite
state, and its current drawing point. A front-buffer clear is presented
immediately; a back-buffer clear becomes visible only at `FLIP`, preserving
tear-free double-buffer rules. `CLS` in text mode clears text, while an
argument-free `CLS` in `SCREEN SPLIT` clears both the text region and selected
graphics buffer. Retained raster acceleration is required to produce the exact
same pixels as a cold render after a clear.

`SPRITE id,x,y,width,height[,fill[,stroke]]` creates or replaces a visible
axis-aligned sprite, and `MOVESPRITE id,x,y` moves it. `PCOLLISION(a,b)` tests
one pair; `PCOLLISION(a)` tests that sprite against all others. A true query is
`-1`, false is `0`, and edge-only contact is not overlap. `ON COLLISION GOSUB
line` registers an edge-triggered handler; `COLLISION ON`, `OFF`, and `STOP`
enable, discard, or suspend delivery. The matching `RETURN` re-arms the trap.

`SPRITEMOTION id,vx,vy[,ax,ay]` gives a classic 2D sprite velocity and
optional acceleration in logical pixels per second. The retained XYZ form and
its depth queries are defined in the point-perspective section above.
`ADVANCESPRITES seconds` advances every sprite with deterministic
constant-acceleration motion; one step is limited to 60 seconds. `SPRITEX`,
`SPRITEY`, `SPRITEVX`, `SPRITEVY`, `SPRITEAX`, and `SPRITEAY` query either
sprite form, for example `SPRITEX(SHIP)`. Explicit stepping makes animation
repeatable during testing and video export instead of coupling physics to host
rendering speed.

`FLIPBOOK CREATE id,template$,first,last,fps` creates an ordered movie asset
from frames already decoded and retained in RAM at program load. The template contains exactly
one contiguous number field, for example `"page####.ppm"`; frame 7 then maps
to `page0007.ppm`. Every numbered still must already exist in the sandbox, FPS
is 1 through 120, and the sequence is bounded to 30 minutes. `FLIPBOOK REMOVE
id` removes one retained sequence and `FLIPBOOK CLEAR` removes all of them.

`PLAY FLIPBOOK id[,loops[,soundtrack$]]` projects complete frames sequentially
at the retained rate, which is the electronic equivalent of flipping a paper
book. It checks Ctrl+Escape between frames and preserves the logical screen's
aspect ratio by bilinear scaling and letterboxing. `VIDEO EXPORT
id,path$[,soundtrack$]` sends the same retained still sequence directly to an
MP4, WebM, or animated GIF. It is the declarative counterpart to procedural
`VIDEO START`/`FRAME`/`STOP`; there is one frame stream and one encoder, not a
duplicate movie implementation.

Classic named-note forms such as `PLAY "C4/4 E4/4"` are unchanged. The explicit
modern forms `PLAY AUDIO source$` and `PLAY VIDEO source$` decode sandboxed
local media or, with the network capability enabled, direct HTTP(S) media
streams. `PLAY FLIPBOOK` plays a retained still sequence. Local audio supports
WAV, MP3, FLAC, Ogg, Opus, M4A, and AAC; local video supports MP4, WebM,
Matroska, MOV, AVI, and M4V. Direct podcast/audio or video stream URLs may be
played. Web pages such as YouTube and Netflix are opened with `WEB OPEN` so the
host browser—not the media decoder—handles site code, accounts, and licensed
playback.

`VIDEO START path$,fps[,soundtrack$]` begins a bounded program-generated
recording;
`VIDEO FRAME` appends the currently displayed graphics screen, and `VIDEO STOP`
finishes it. Paths must end in `.mp4`, `.webm`, or `.gif`, the frame rate is 1
through 120, all frames retain the first frame's dimensions, and a recording is
limited to 30 minutes. An optional soundtrack must be an existing sandboxed
`.wav` output (normally created by `WAVEFILE`) and is supported for MP4 and
WebM; GIF remains silent. Short audio is padded with silence and long audio is
clipped so the submitted video frames define the recording duration. Encoding
uses the host FFmpeg executable through a fixed
argument interface—BASIC cannot supply filters, shell text, camera input, or
editor commands. `END` and BASIC `STOP` safely finish an active nonempty
recording. Generated `VIDEO`, `WAVEFILE`, `SCREENSHOT`, `SAVEIMAGE`, `RENDER`,
and explicit graph-display files use the separately sandboxed output root when
one is configured; packaged CLI and shell sessions gather them in the project
root's `output/` directory. Ordinary BASIC data files remain under the file
root. MP4 output uses a high-quality H.264 CRF 17 encode, a bounded real-time
encoder configuration, and the compatible 4:2:0 pixel format. See
`programs/demos/modernbasic_capabilities_presentation.bas` for a live,
wall-clock-synchronized program-generated soundtrack and animation (with an
explicit `RECORDING=1` export mode), and
`programs/demos/programmed_animation_video.bas` for a complete six-second,
1920x1080, 60 fps graphics-only programmed scene. It uses
`BUFFER` and `FLIP` so live display presents complete frames instead of partial
redraws.

Graphical-shell programs can poll `MOUSEX()`, `MOUSEY()`, `MOUSEINSIDE()`, and
`MOUSEBUTTON(1..3)`. Coordinates are mapped through the fitted viewport to the
logical BASIC screen even when the native window is resized; letterbox and
pillarbox bars are outside the device and make `MOUSEINSIDE()` false.
`INKEY$()` removes the oldest queued key
without waiting; printable keys are returned as characters and navigation keys
as names such as `LEFT`, `RIGHT`, `UP`, `DOWN`, `ENTER`, or `ESC`. The queue is
bounded to 64 entries. Headless runs return zero/false mouse state and an empty
key string.

## Audio

See [AUDIO_REFERENCE.md](AUDIO_REFERENCE.md) for parameter ranges and note
notation. The complete canonical audio statement family is:

```text
SYNTHPROFILE  VOICES       OSCILLATORS   TEMPO
VOICE         WAVE         OSCILLATOR    ADSR
PULSEWIDTH    VOL          STEREO        PAN
MIXER         FILTER       FILTERADSR    LFO
GLIDE         DRIVE        DSP
EXPRESSION    MODULATION   SUSTAIN       PITCHBEND
REVERB        CHORUS
PLAY          SOUND        BEEP
SOUNDFONT     INSTRUMENT
WAVEFILE      SAY          SING
```

The media and playback subforms are:

```text
PLAY sequence$[,default-beats]
PLAY voice,sequence$[,default-beats]
PLAY AUDIO source$
PLAY VIDEO source$
PLAY FLIPBOOK id[,loops[,soundtrack$]]

SOUND frequency,voice,duration-ms[,level][,end-frequency][,steps]
SOUND ON|OFF|WAIT|RESUME
```

`WAVEFORM` is an accepted alias for `WAVE` and `ENVELOPE` is an accepted alias
for `ADSR`; there is no dialect selector or duplicate audio engine. Global
`CLEAR` resets audio state along with the rest of mutable program state.

The canonical arbitrary-frequency oscillator statement is
`SOUND frequency,voice,duration-ms[,level][,end-frequency][,steps]`. Its first
three arguments are required. It generates a tone, which can represent a
musical note when the supplied frequency is that note's frequency. It does not
interpret note notation: `PLAY` is the separate named-note and sequencing
statement. The complete native voice patch configures `SOUND`: a profile-selected
bank of 1 through 8 `OSCILLATOR` slots, `WAVE` for slot 1, `PULSEWIDTH`, `ADSR`, per-voice
`FILTER`, `FILTERADSR`, targeted `LFO`, `GLIDE`, `DRIVE`, `VOL`, and `STEREO`.
`MIXER voice,synth-level,midi-level` independently routes `PLAY` to the
computer synthesizer, the MIDI/SoundFont instrument, or both.

## Safety and resource limits

Default batch runs limit executed statements, string size, retained storage,
array elements, `DATA` items, matrix work, files, stacks, audio duration, and
render dimensions. The interactive shell may run without a finite statement
budget because it provides a user BREAK path; the other bounds remain active.
Expression syntax is limited to 32 nested delimiter, unary, call, list, or
right-associative power levels; exceeding that budget returns a structured
runtime error rather than exhausting the host stack.

`WAIT milliseconds` is an interruptible native delay. Classic
`WAIT port,mask[,xor]` observes the bounded virtual port bank; it never executes
privileged host I/O. `SYS` and `CALL` can reach only services registered through
the host library API. `PEEK` and `POKE` never address arbitrary host memory.
`ENVIRON$` and `COMMAND$` expose only the bounded values explicitly supplied in
`RunOptions`; unrelated host variables and invocation details remain private.
Network statements are disabled unless the host grants the network capability.
HTTP response and file limits remain active after permission is granted; the
browser and media decoder receive only validated HTTP(S) addresses through
fixed host command arguments.
`ON TIMER(seconds) GOSUB line` accepts a positive interval up to one day;
`TIMER ON`, `OFF`, and `STOP` control statement-boundary delivery. Timer and
collision handlers use the bounded GOSUB stack, do not re-enter themselves,
and are deferred while a structured procedure frame is active.

## Compatibility position

Historical manuals are design and test sources. ModernBASIC accepts many
familiar forms, but it exposes one coherent modern language rather than trying
to reproduce incompatible hardware side effects. Parser acceptance and a
passing certification example do not by themselves prove complete behavioral
equivalence to an entire vintage manual.

The previously recorded portable gaps—whole-record binary-file transfer,
`DEF FN`/multi-line `FUNCTION` composition, and bounded `ENVIRON$`/`COMMAND$`
access—are implemented. Device-specific screen, sprite, disk, printer, and
sound protocols still vary across the supplied machines, and continued manual
alignment can uncover semantic edge cases. ModernBASIC is therefore a broad,
usable modern BASIC rather than a claim of page-for-page equivalence to every
Dartmouth, Microsoft, BBC, Commodore, Amiga, and TI manual.
