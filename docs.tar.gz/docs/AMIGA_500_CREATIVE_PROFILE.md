# Amiga 500 creative-programming profile

ModernBASIC targets the useful results an Amiga 500 owner could program in
BASIC, not binary compatibility with Amiga BASIC and not emulation of the
68000, custom chips, Kickstart, or Workbench. Programs use one coherent modern
language and safe host services.

## Covered creative-programming outcomes

| A500-era goal | ModernBASIC facility |
| --- | --- |
| Draw titles, diagrams, sets, charts, and scenes | Pixels, antialiased lines, pressure-style brushes, rounded rectangles, circles/ellipses, arcs, curves, paths, polygons, stars, text, fills, gradients, transforms, layers, groups, and common photographic bitmaps |
| Select, light, and composite colors | A 256-entry programmable palette, named and RGBA hexadecimal colors, linear/radial gradient paints, opacity, and 19 raster/SVG blend modes |
| Avoid visible partial redraws | Two independent graphics buffers selected with `BUFFER` and presented with `FLIP` |
| Move screen or perspective objects | `SPRITE`, `MOVESPRITE`, `SPRITEMOTION`, and deterministic `ADVANCESPRITES` two- or three-axis velocity/acceleration stepping |
| Create a 3D illusion on a 2D canvas | Retained XYZ pixels, billboard objects, and sprites share focal-depth scaling, far-to-near layering, point-light shading, and projected collision |
| React to object contact | `PCOLLISION`, `ON COLLISION GOSUB`, and collision enable/suspend/disable controls |
| Build interactive animation | Nonblocking `INKEY$()` plus logical-screen `MOUSEX()`, `MOUSEY()`, `MOUSEINSIDE()`, and `MOUSEBUTTON()` polling |
| Synchronize a scene | `FRAME`, `WAIT`, `TIMER`, and `ON TIMER GOSUB` |
| Produce soundtracks and effects | 16 synthesizer voices, waveforms, envelopes, filters, panning, SoundFonts, note sequencing, tone/sweep effects, DSP, and WAV export |
| Use a synthetic voice | `SAY` for speech and `SING` for timed lyric-to-note performance |
| Save still artwork | PNG screenshots, common still-image import, bilinear scaling, and rendered SVG/PNG/PPM output |
| Program a finished animation/video | `FLIPBOOK` retains complete still sequences; `PLAY FLIPBOOK` projects them; `VIDEO EXPORT` or `VIDEO START`/`FRAME`/`STOP` encode MP4, WebM, or GIF |
| Store scripts, assets, scores, and data | Sandboxed text, random, binary, and typed-record file operations |
| Write substantial applications | Structured procedures, functions, records, arrays/matrices, error handling, timers, and bounded host-service registration |

Custom animated artwork is not limited to the rectangular collision sprite.
A program can compose polygons, paths, text, bitmap assets, and other primitives
around a sprite or tracked position on every frame. Classic 2D sprites retain rectangular screen bounds. XYZ sprites use their current
perspective-scaled screen rectangle, so changing depth also changes visible size and
collision bounds deterministically.

## Video scope

The video feature supports creation plus sandboxed local or direct HTTP(S)
playback. A BASIC program can draw and capture procedural frames, or save
hundreds of complete painted stills and retain them as one FLIPBOOK. PLAY
FLIPBOOK projects that sequence; VIDEO EXPORT encodes the same frames. With the
host network capability enabled, PLAY AUDIO and PLAY VIDEO can decode direct
online media streams through a fixed FFmpeg boundary. Full sites such as
YouTube and Netflix use WEB OPEN and the installed browser. This supports title
sequences, educational animation, music visualizers, demonstrations, cartoons,
painted frame-by-frame motion, and program-generated game footage.

It is not yet a full Photoshop-class interactive retouching UI, camera
interface, nonlinear clip timeline, broadcast switcher, or Video Toaster clone.
It can both preserve photo-grade imported stills and synthesize detailed pixels
inside arbitrary closed paths with multi-scale texture plus bounded blur,
sharpen, and color finishing; brushes, gradients, layers, alpha, blend modes,
and raster PNG output compose with that pipeline. Neither PLAY nor WEB bypasses
DRM; licensed playback remains the browser's job. Audio can be rendered with
`WAVEFILE` and supplied to either VIDEO path for MP4 or WebM; GIF remains
silent.

## Modern substitutions

- Programmed graphics and software rendering replace direct blitter, copper,
  planar-memory, HAM/EHB, overscan, and raster-register programming.
- The shell window and logical graphics screen replace Intuition screen/window
  structures. Programs can draw their own panels, buttons, menus, and multiple
  view regions with ordinary graphics and mouse polling.
- Keyboard and mouse input replace a required Amiga joystick. There is no
  physical game-controller API in this profile.
- Sandboxed files and registered host services replace arbitrary device files,
  physical serial/parallel control, and unrestricted Amiga shared-library calls.
- Native 64-bit memory, checked language-owned virtual memory, and bounded
  virtual ports replace chip/fast RAM addresses and privileged hardware I/O.

These substitutions preserve programmable outcomes while excluding machine-
specific behavior that is unsafe, obsolete, or contrary to the single modern
dialect. They do not promise that an unchanged Amiga BASIC listing will run.

## Acceptance example

`programs/demos/programmed_animation_video.bas` generates a 1920 by 1080 scene
with smooth linear/radial lighting, alpha aurora ribbons and atmosphere,
randomized twinkling stars, three hand-shaped nonrepeating gradient-painted
mountain ranges, reflective water, a cinematic vignette, and a left-flying
gradient-lit spacecraft with screen-blended engine bloom, glass, motion trails,
and reflection. It double-buffers its live display and creates 360 graphics-only
frames in a six-second high-quality H.264 MP4 at 60 frames per second. Generated
media is gathered in the root-level `output/` directory, separate from `.bas`
sources. It uses no photo or video editor.

`programs/demos/stickman_flipbook.bas` is the canonical flipbook acceptance: it
paints 72 separate 640x480 old-paper pages, moves the stick figure by small limb
increments, retains `stickman####.ppm`, plays it twice, and exports both GIF and
H.264 MP4. `programs/demos/leaves_flipbook.bas` is the procedural-detail
acceptance: BASIC itself constructs a serrated leaf mask and paints its gradient,
multi-scale texture, surface sheen, mottling, curved venation, stem, and soft
shadow--without `BITMAP` or an imported leaf. Wind deforms the blade while
face-on turn, light, and Z-derived scale vary across 120 separate 960x540
frames. It exports a still, GIF, and H.264 MP4 from the same FLIPBOOK.
`programs/demos/feather_flipbook.bas` applies the same no-import pipeline to an
asymmetric translucent white feather with a curved shaft, separated diagonal
barbs, frayed gaps, downy wisps, surface texture, and shadow. Strong wind bend,
a full end-over-end tumble, two edge-on axial flips with reversed-face shading,
travel, and depth scaling animate the complete feather rather than a leaf-like
solid vane.
All three demos completed in the 2026-08-24 release acceptance with exact frame
counts and dimensions.
