# Alignment with the supplied BASIC documents

The reference archive contains valuable manuals, audits, a separate RustBASIC
development guide, graphics research, and a RustySynth source snapshot. They
do not all describe the same codebase or the same moment in the design.

## Evidence used directly

- Dartmouth and Microsoft manuals informed line-numbered program structure,
  control flow, `DATA`, matrices, and Microsoft file-channel punctuation.
- BBC, Commodore, and Amiga manuals informed familiar audio and graphics names.
- The RustySynth snapshot supplied the third-party license notice required by
  the vendored SoundFont code.
- The 2026 audits were used as gap lists and as warnings against equating
  parser coverage with full behavioral equivalence.

## Evidence not treated as current implementation truth

`RUSTBASIC_DEV_GUIDE.md` describes a repository with `src/statements/`,
`src/commands/`, `src/functions/`, a VM, physics modules, and simultaneous
historical dialect acceptance. The attached ModernBASIC 0.8 source instead
has a consolidated interpreter and one public Modern dialect. Its locked
waveform table also conflicts with parts of the current code's naming.

The statement and compatibility audits refer to another tree with hundreds of
individual statement files and certification programs. Those reported pass
counts cannot be transferred to this package. They remain useful targets for
future manual-derived tests.

The graphics audit compares a TI beginner's book with a separate Artist CLI.
ModernBASIC includes an Artist-derived renderer, but that does not prove that
every external Artist command is a BASIC statement.

## Current defensible claim

ModernBASIC implements a broad, native, classic-style BASIC surface informed
by several historical families. Its supported A500-era creative outcomes and
modern substitutions are defined in
[AMIGA_500_CREATIVE_PROFILE.md](AMIGA_500_CREATIVE_PROFILE.md). It is not
defensible to claim page-for-page behavioral replication, unchanged Amiga
BASIC source compatibility, or hardware emulation. Stronger claims require
current, executable, manual-derived tests against this exact 0.8.2 tree.
