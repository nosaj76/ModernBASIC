# Modern64BASIC 0.8.2 missing-feature review

Audit date: 2026-08-26

Codebase name: the source and executable identify the project as `ModernBASIC`; this report uses `Modern64BASIC` when referring to the requested product direction.

Audit basis: the working tree supplied for review, including its current uncommitted changes.

## Scope and method

This is a source audit, not a keyword-name comparison. A feature counts as present only when the current parser and runtime provide the behavior. Identifier-encoded statements count as native features even when they have no `Token` enum byte. A similarly named feature with materially different semantics is marked partial rather than present.

The primary evidence is:

- [`src/tokens.rs`](../src/tokens.rs): the complete token enum, text mappings, identifier-encoded statement catalogue, punctuation, and tokenization rules;
- [`src/interpreter.rs`](../src/interpreter.rs): the complete statement dispatcher and implementations, including READY/session behavior, structured procedures, files, graphics, sound, errors, and events;
- [`src/functions.rs`](../src/functions.rs): token and identifier built-ins, including string, conversion, date/time, and mathematical functions;
- [`src/eval.rs`](../src/eval.rs): expression grammar, precedence, runtime-backed functions, arrays, and operators.

Supporting evidence came from `src/program.rs`, `src/repl.rs`, `src/input.rs`, `src/file_io.rs`, `src/graphics.rs`, `src/framebuffer.rs`, `src/screen.rs`, and the language/conformance documentation and tests.

### Status and risk terms

| Term | Meaning |
| --- | --- |
| Present | The requested spelling and material behavior exist. |
| Partial | A close feature exists, but syntax or observable semantics needed by the reference dialect are missing. |
| Composed | The result is possible with existing Modern64BASIC facilities, but compatible source will not run unchanged. |
| Missing | No source-level facility provides the feature. |
| Relevance H/M/L/N | High, medium, low, or not appropriate for a safe standalone-OS BASIC. |
| Break risk None/Low/Medium/High | Expected compatibility risk if added. “Low” usually means a context-sensitive new statement; “Medium” usually means an existing array/function or variable spelling could change meaning; “High” changes established output, calling semantics, concurrency, or the security boundary. |

## Executive findings

Modern64BASIC is already strong in the classic language core. It has numbered program storage and READY editing, assignment, arrays and records, all principal classic control forms, structured procedures, data, error traps, sequential/random/binary files, virtual memory and ports, substantial graphics, a much larger audio system than the references, and broad numeric/string built-ins. The byte-token table understates that coverage: `SUB`, `FUNCTION`, `TYPE`, graphics, sound, `CHAIN`, `MERGE`, and many other statements are deliberately identifier-encoded and dispatched natively.

The important missing clusters are:

1. **Text-screen control and input events.** `LOCATE`, `CSRLIN`, `VIEW PRINT`, `HOME`, `HTAB`, `VTAB`, `SLEEP`, `TEXTCOLOR`, and live bare/parenthesized `INKEY$` are partially implemented. A complete text grid, `INPUT$`, held-key query, `KEY(n)` event family, joystick/gamepad family, and portable attributed output remain absent.
2. **Raster-compatible graphics state.** Retained scenes now carry per-buffer generations and lazily refresh `ScreenBuffer` on pixel access. Main-screen `POINT`/`SCRN`, graphics `GET`/`PUT`, `PCOPY`, `VIEW`, classic `WINDOW`, and `PMAP` still need source syntax and state integration.
3. **Exact macro-language compatibility.** Modern `DRAW` omits several Microsoft draw-string commands. Modern `PLAY` uses its own absolute-octave, whitespace-separated notation rather than GW/QBASIC music macro language. `PRINT USING` recognizes many markers but does not yet implement several of their semantics correctly.
4. **A source/preprocessor/module layer.** There is no `#INCLUDE`, conditional compilation, macro definition, namespace, enum, visibility, or external declaration layer. The numbered-line-only `Program` loader currently has nowhere to represent unnumbered directives.
5. **Native ABI, object, and concurrency features from FreeBASIC/QB64.** Raw assembly, calling conventions, external symbols, overloads, operators, constructors, properties, inheritance-style visibility, threads, and mutexes are absent. Many are not good direct fits for this interpreter or its safety boundary.
6. **Apple-specific compatibility.** Applesoft text modes/attributes, cursor controls, shape tables, ampersand extensions, memory-limit controls, and convenience persistence commands are mostly absent, although their outcomes can often be composed from the modern graphics, file, or registered-service APIs.

The safest high-value direction is to complete the screen/input/raster abstraction and formatting/file semantics first; add a bounded source-preprocessing layer second; and expose host integration only through typed, capability-gated services. Raw `ASM`, unrestricted `SHELL`, and arbitrary ABI entry points should remain outside the default language.

## What is already present

This summary prevents implemented identifier extensions from being reported as omissions.

| Reference family | Present implementation |
| --- | --- |
| Classic core | `PRINT`, `INPUT`, `LET`/implicit assignment, `DIM`, `FOR/NEXT`, `WHILE/WEND`, inline and block `IF/THEN/ELSE`, `GOTO`, `GOSUB/RETURN`, `ON ... GOTO/GOSUB`, `DATA/READ/RESTORE`, comments, `END`, `STOP`, and fresh `RUN`. |
| READY/program editing | `LIST`, `NEW`, `LOAD`, `SAVE`, `MERGE`, `DELETE`, `EDIT`, `AUTO`, `RENUM`, statement-level `STEP`, `TRON/TROFF`, and exact `STOP`/READY `CONT`. The editing commands intentionally reject use from a running stored program. |
| Classic memory/services | Bounded virtual `PEEK/POKE/DEF SEG`, virtual `INP/OUT/WAIT`, and registered-service `CALL/SYS/DEF USR/USR`. These do not expose raw host memory, ports, or machine code. |
| Procedures/types | `DEF FN`, multi-line `SUB` and `FUNCTION`, `END SUB/FUNCTION`, explicit `BYVAL/BYREF`, `CALL`, recursion, `SHARED`, declared `STATIC` values, early exits, `CONST`, `TYPE/END TYPE`, `DIM ... AS`, nested records, `REDIM [PRESERVE]`, and `LBOUND/UBOUND`. |
| Structured control | `SELECT CASE`, BBC-style `CASE OF`, `DO/LOOP WHILE/UNTIL`, `REPEAT/UNTIL`, and `EXIT FOR/WHILE/DO/REPEAT/SUB/FUNCTION`. |
| Classic files | Sandboxed sequential, append, random, and binary `OPEN`; `PRINT#`, `WRITE#`, `INPUT#`, `LINE INPUT#`, `FIELD/LSET/RSET`, file `GET/PUT`, `SEEK`, `LOC/LOF/EOF`, `KILL`, `NAME`, `CHAIN`, `COMMON`, and `VERIFY`. |
| Strings/conversions | `INSTR`, `MID$`, `LEFT$`, `RIGHT$`, `UCASE$`, `LCASE$`, `LTRIM$`, `RTRIM$`, `TRIM$`, `SPACE$`, `STRING$`, `STR$`, `VAL`, `BIN$`, `HEX$`, `OCT$`, `CHR$`, `ASC`, and `LEN`. |
| Arithmetic/operators | Checked `+ - * / ^`, comparisons, integer `\`/`DIV`, `MOD`, `NOT`, `AND`, `OR`, `XOR`/BBC `EOR`, string concatenation/comparison, complex arithmetic, and list broadcasting. |
| Graphics | `SCREEN`, `CLS`, graphics `COLOR`, palettes, `PSET/PRESET`, classic-style `LINE` and `CIRCLE`, flood `PAINT`, modern `DRAW`, shapes, paths, transforms, buffers/`FLIP`, sprites, retained perspective, graph windows, graph pixel/point tests, image/video output, and mouse polling. |
| Text screen/input (partial) | `LOCATE`, `CSRLIN`, `VIEW PRINT`, `HOME`, `HTAB`, `VTAB`, `TEXTCOLOR`, timed/key-abortable `SLEEP`, and live bare or parenthesized `INKEY$`. These track logical cursor/region/color state and emit shell events, but do not yet provide a complete attributed text-cell grid or every historical option. |
| Sound | `BEEP`, `SOUND`, modern `PLAY`, synthesizer voices, SoundFonts, effects, WAV export, speech, and singing. |
| Errors/events/time | `ON ERROR GOTO`, `ERROR`, `ERR`, `ERL`, `RESUME [NEXT\|line]`, `TIMER`, `ON TIMER`, `TIMER ON/OFF/STOP`, and collision traps. |
| Host context | Bounded, explicitly supplied `COMMAND$` and `ENVIRON$`; READY `CD/CHDIR` and `PWD`; network and media operations only when host-enabled. |

## Classic Microsoft and QBASIC/QuickBASIC gaps

### Screen, graphics, keyboard, controller, and communications

| Missing or partial feature | Dialect(s) | Relevance | Break risk if added | Suggested implementation |
| --- | --- | --- | --- | --- |
| Graphics `GET` region capture | GW-BASIC/BASICA; QBASIC/QuickBASIC; QB64 | H: essential for ports, animation, and pixel editing | Medium: `GET` already means console input or file input, so dispatch must distinguish coordinate syntax | Add a typed image/region store and recognize only `GET (x1,y1)-(x2,y2),array` at statement start. Rasterize the current retained scene first, enforce pixel/byte limits, and preserve the existing console/file forms. |
| Graphics `PUT` region replay | GW-BASIC/BASICA; QBASIC/QuickBASIC; QB64 | H | Medium: `PUT` already means random/binary file output | Contextually recognize coordinate-plus-array syntax; replay bounded captured rasters with explicit `PSET/PRESET/AND/OR/XOR` modes. Do not overload file `PUT` by name alone. |
| `VIEW` graphics viewport | GW-BASIC; QBASIC; QB64 | H: portable clipping and layout | Low if recognized only with viewport syntax; otherwise `VIEW` can be a variable | Store a clip rectangle in `GraphicsDevice`, apply it to Artist output and raster queries, and support `VIEW`, `VIEW SCREEN`, and optional fill/border forms. |
| `WINDOW` logical coordinate mapping | GW-BASIC; QBASIC; QB64 | H | Medium: `GRAPH WINDOW` already controls the separate TI graph subsystem; the two states must not be conflated | Add a main-screen world-to-device transform scoped by `VIEW`. Keep `GRAPH WINDOW` unchanged. Define y-up/y-down behavior explicitly and test `WINDOW SCREEN`. |
| `PMAP` coordinate conversion | GW-BASIC; QBASIC | M/H once `WINDOW` exists | Medium: `PMAP(...)` currently parses as an array access | Add a runtime-backed function over the main graphics transform. To limit array-name breakage, reserve it only as a call and document the new built-in collision. |
| `POINT` main-screen pixel/color query | GW-BASIC; QBASIC; QB64 | H | Medium: `POINT(...)` is currently a valid implicit array reference | First make the retained scene and raster backing coherent. Then expose `POINT(x,y)` and cursor-query overloads. Return a documented palette index or packed color; do not reuse TI `PT-TEST`, which reports only graph-point occupancy. |
| Graphics `SCREEN(row,col[,flag])` query | GW-BASIC/QBASIC (function form) | M | Medium: `SCREEN` is already a statement and could also be an implicit array | Implement only the parenthesized expression form after a text-grid model exists; leave statement dispatch unchanged. |
| `PCOPY` | QuickBASIC/QBASIC | M/H for page flipping | Low: no current statement conflict | `ScreenBuffer` already has snapshot/restore primitives and `GraphicsDevice` has two buffers. Add page identifiers and copy both retained scene state and its coherent raster, not only stale framebuffer pixels. |
| `SCREENLOCK` | FreeBASIC/QB64 | M: batching is useful, but `BUFFER` already covers much of the outcome | Low | Add a nesting-counted presentation lock that suppresses screen events while retaining commands; do not lock an OS framebuffer directly. |
| `SCREENUNLOCK` | FreeBASIC/QB64 | M | Low | Flush the pending retained scene when the lock depth returns to zero. Pair errors and cleanup on `END`, `STOP`, and runtime errors. |
| `SCREENCONTROL` | FreeBASIC/QB64 | M/H for a standalone graphical environment | Medium: platform-dependent observable behavior | Provide a portable subset through `ScreenEvent`: title, fullscreen, resizable state, logical/host size, scale mode, and pointer visibility. Reject raw window handles/pointers. |
| `SCREENINFO` | FreeBASIC/QB64 | H | Medium: the call currently looks like an array | Expose logical screen dimensions, display dimensions, color depth, and scale profile from `GraphicsDevice`/`screen::display_info`; prefer explicit scalar query functions if exact QB64 multi-output syntax is undesirable. |
| `LOCATE` (partial) | GW-BASIC/QBASIC | H: a BASIC OS needs cursor-addressable text | Low contextually; assignment to `LOCATE` remains valid | One-based rows 1..25, columns 1..80, and cursor visibility are implemented with range errors and shell cursor events. Cursor-shape options and a complete backing text grid remain. |
| `CSRLIN` (partial) | QuickBASIC; FreeBASIC/QB64 | H with `LOCATE` | Medium | Bare and parenthesized forms return the tracked logical row. A complete terminal-grid model is still needed for screen-cell inspection. |
| `VIEW PRINT` (partial) | QuickBASIC/QBASIC | H for full-screen text UIs | Low | A validated row region constrains logical newline movement; `HOME` returns to its top. Full region-aware cell clearing/scrollback rendering remains backend-limited. |
| Text-mode `COLOR`/`TEXTCOLOR` (partial) | GW-BASIC/QBASIC; Applesoft has related attributes | H | Medium: graphics `COLOR` retains its established meaning | `TEXTCOLOR [foreground[,background]]` tracks validated RGB/palette-style integer values and emits shell color events. Output spans do not yet retain per-cell historical attributes, and classic overloaded `COLOR` is not accepted. |
| `KEY` function-key definition/display statement | GW-BASIC/QBASIC | M | Low contextually | Maintain a bounded function-key macro table owned by the execution session and optionally a text-screen key-label row. Do not inject macros into source; enqueue their text as input. |
| `ON KEY(n) GOSUB` | GW-BASIC/QBASIC | H for event-driven UI | Medium: introduces asynchronous control-flow state | Generalize the existing timer/collision event-trap machinery to key events delivered at statement boundaries, with non-reentrancy and bounded queues. |
| `KEY(n) ON/OFF/STOP` | QBASIC/QuickBASIC | H with `ON KEY` | Low after the trap exists | Reuse `EventMode`, keeping a per-key target/mode/active latch. |
| `INKEY` no-dollar alias | FreeBASIC/QB64 | M | Medium: `INKEY(...)` currently means an array | Alias only the call form to the live key queue and preserve `INKEY$`. |
| Bare classic `INKEY$` live behavior (partial) | GW-BASIC/QBASIC/QuickBASIC | H | Medium: bare `INKEY$` now consumes the same queue as `INKEY$()` | Live FIFO press consumption is implemented. Held-key state, key-release tracking, and historical scan-code encodings remain absent. |
| `MULTIKEY`/held-key state | FreeBASIC/QB64 | H for games | Medium: GUI backends currently retain a press queue, not a key-down set | Subscribe to key-release events, maintain a normalized held-key bitset, clear it on focus loss, and expose deterministic key constants. |
| `INPUT$(count[,#channel])` | GW-BASIC/QBASIC | H for byte-oriented console/file work | Medium: `INPUT$(...)` currently parses as an implicit string array; expression evaluation also has no input-reader borrow | Add a pre-evaluation runtime function resolver that can consume bounded bytes from the active input or file channel. Cap count before allocation and preserve `INPUT` statement parsing. |
| C64 `GET` nonblocking keyboard semantics | Commodore BASIC V2 | M/H for C64 ports | Medium: current unqualified `GET` is a blocking raw-byte read from the supplied `BufRead` | Either add a C64-compatible nonblocking form backed by the GUI key queue or document `INKEY$()` as the canonical replacement. Do not silently change batch-mode `GET`. |
| `PEN` query | GW-BASIC/QBASIC | L: light pens are obsolete; pointer coordinates cover the useful outcome | Medium: `PEN(...)` currently looks like an array | If compatibility is desired, map position/status queries to pointer state. Otherwise document `MOUSEX/Y/BUTTON` as the replacement. |
| `PEN ON/OFF/STOP` and pen trap control | QBASIC/QuickBASIC | L | Low/Medium | Implement only as an optional pointer-event compatibility layer over generalized statement-boundary events. |
| `STICK` | GW-BASIC/QBASIC | M for gamepad-capable OS BASIC | Medium: call collides with arrays and requires a new host input capability | Add a normalized controller service with dead-zone/scaling and deterministic “no device” values. Avoid PC game-port semantics. |
| `STRIG` | GW-BASIC/QBASIC | M | Medium | Expose controller button state through the same service. |
| `STRIG ON/OFF/STOP` and trigger traps | QBASIC/QuickBASIC | M | Medium | Reuse generalized input event traps rather than adding another bespoke scheduler. |
| `COM ON/OFF/STOP` and communications events | QBASIC/QuickBASIC | M/H for a standalone OS BASIC, but only with explicit device grants | High if it opens ambient serial devices | Add a capability-gated serial/channel abstraction and statement-boundary event delivery. Paths/devices must be host-approved; never scan or open arbitrary devices implicitly. |

### Declarations, files, formatting, and classic semantic gaps

| Missing or partial feature | Dialect(s) | Relevance | Break risk if added | Suggested implementation |
| --- | --- | --- | --- | --- |
| `DIM SHARED` syntax | QBASIC/QuickBASIC; FreeBASIC/QB64 | H compatibility; global `DIM` plus procedure `SHARED` already supplies the outcome | Low if parsed only immediately after `DIM` | Desugar module-level `DIM SHARED ...` into ordinary global dimensions plus shared visibility metadata. Keep current procedure-local `DIM` behavior. |
| `SUB name(...) STATIC` procedure modifier | QuickBASIC | M | Medium: current `STATIC` means explicit persistent declarations only | Add a definition flag making all local values persistent, while explicit `SHARED` and parameters retain their current rules. Do not change existing procedures by default. |
| QuickBASIC default-`BYREF` calling semantics | QuickBASIC/QBASIC | M compatibility gap; explicit `BYREF` is present | High: an unqualified parameter is currently `BYVAL` in `parse_procedure_parameter` | Keep Modern64BASIC's established `BYVAL` default. If exact dialect compatibility is required, add an `OPTION PARAM BYREF`/compatibility mode rather than globally changing existing programs. |
| `DECLARE SUB/FUNCTION` | QuickBASIC/QBASIC; FreeBASIC | M: useful for interfaces, unnecessary for forward discovery because declarations are pre-collected | Low if validation-only | Parse declarations during structured validation, verify later definitions/signatures, and emit no runtime statement. It should not be required for calls. |
| `DECLARE ... LIB`, `LIB`, or typed external declarations | QuickBASIC; FreeBASIC/QB64 | H for OS integration only as a safe capability API | High: arbitrary dynamic-library loading crosses the current registered-service boundary | Bind declarations to host-registered named services with typed `Value` arguments/results. Optional library loading must use an allowlist and fixed symbols, never arbitrary BASIC-provided paths plus addresses. |
| `INTERRUPT` | QuickBASIC | L/N as a literal software interrupt; M as a named system-service call | High | Do not expose CPU interrupts. Offer a compatibility wrapper around registered services, or reject it with a clear security-boundary error. |
| `CLOSE` with no channels or a channel list | Microsoft BASIC/QBASIC; FreeBASIC/QB64 | H | Low | Extend `execute_close` to split top-level comma arguments; no arguments closes all BASIC channels atomically/best-effort with defined error handling. The current implementation accepts exactly one channel. |
| File `LOCK`/`UNLOCK` | QuickBASIC/FreeBASIC/QB64 | H for a multi-program OS | Medium: platform and cross-process semantics | Add whole-file and optional byte-range locks to `FileStore`. Define advisory behavior and release locks on close/error/session teardown. Use a small platform layer rather than exposing host descriptors. |
| Complete `WIDTH` forms | GW-BASIC/BASICA; QBASIC/QuickBASIC | M/H for redirected output and text-mode ports | Low/Medium: simple `WIDTH n` already changes the console wrapping width | Retain `WIDTH n`; add context-specific `WIDTH #channel,n` and printer/text-device forms backed by per-target column widths. Screen-dimension forms should resize the logical text terminal, not silently resize the host window. |
| Physical/printer `LPRINT` | GW-BASIC/QBASIC | M: useful as spooling, not as a raw printer port | High if sent to ambient printers; current behavior is stdout | Keep stdout behavior for compatibility or add an explicitly configured spool channel/output file. Never auto-select a host printer. |
| `LPRINT USING` and `PRINT# ... USING` | Microsoft BASIC/QBASIC | M/H | Low once formatting is factored | Reuse one formatter for console, printer/spool, and file channels. Current special handling exists only for console `PRINT USING`. |
| Complete `PRINT USING` semantics | Microsoft BASIC; QBASIC/QuickBASIC; FreeBASIC/QB64 | H | High for output-sensitive existing programs | Replace the current ad-hoc formatter with a parsed format-cycle engine. Implement actual comma insertion, exponential fields, trailing signs, overflow `%`, value-type errors, format repetition, extra/missing-value rules, Unicode-safe fixed string widths, and correct output-column tracking. Add golden tests from each dialect. |
| Full Microsoft `DRAW` macro language | GW-BASIC/BASICA; QBASIC/QuickBASIC | M/H for source ports | Medium: the statement exists but behavior expands | Retain the implemented `U/D/L/R/E/F/G/H`, `B`, `N`, `C`, and `M`; add angle (`A`/`TA`), scale (`S`), substring execution (`X` with bounded recursion), and paint (`P`) commands with the exact sticky/non-sticky state rules. |
| Microsoft/QBASIC `PLAY` music macro language | GW-BASIC/BASICA; QBASIC/QuickBASIC | M/H for source ports | High: current `PLAY` has a documented, incompatible absolute-octave notation | Do not reinterpret existing strings. Add an explicit `PLAY MML ...` form or compatibility option implementing octave/length/tempo/articulation, dotted notes, accidentals, pauses, foreground/background, and variable-string insertion. |
| `FORMAT`/`FORMAT$` general function | FreeBASIC/QB64 | H | Medium: `FORMAT(...)` currently means an array reference | Implement a side-effect-free formatting built-in using a documented modern format grammar, preferably sharing the numeric/string core with `PRINT USING` without pretending the grammars are identical. |
| `COMMAND(index)` argv semantics | FreeBASIC/QB64 | M/H | Medium: `COMMAND$` currently exposes one bounded joined tail | Preserve `COMMAND$`; optionally expose `ARGC`/`ARGV$(n)` or `COMMAND(n)` from a structured, explicitly supplied argument vector rather than reparsing the joined string. |
| `ENVIRON` setter statement | Microsoft/FreeBASIC/QB64 | M | Medium: process-global mutation would be surprising | Mutate only the session-owned environment overlay already supplied through `RunOptions`. Do not mutate the host process environment. |

## Commodore BASIC V2 comparison

Nearly every item in the requested C64 list has a direct, READY-only, or virtualized equivalent: `POKE`, `PEEK`, `SYS`, `WAIT`, `RND`, `GET`, `GET#`, `INPUT#`, `PRINT#`, `CMD`, `USR`, editing commands, classic control/data, `TAB`, `SPC`, `POS`, the requested string functions, and the requested scalar math functions.

The material gaps are therefore semantic rather than missing names:

| Gap | Relevance | Break risk | Suggested implementation |
| --- | --- | --- | --- |
| C64 `GET` is nonblocking, while Modern64BASIC `GET` consumes a byte from `BufRead` and can block | H for unmodified C64 games | Medium | Provide an explicit C64 compatibility form/mode backed by the screen key queue; keep batch `GET` stable. |
| `SYS`/`USR` cannot call arbitrary machine addresses | N as literal C64 behavior; H as a safe service API | High/security boundary | Retain the registered-service model. Add named service aliases, not raw host execution. |
| C64 device numbers and secondary addresses are not emulated by `OPEN`/`CMD` | L for a portable OS BASIC | High if host devices are inferred | Keep logical sandbox channels. A C64 device-compatibility adapter should be explicit and isolated. |
| PETSCII/screen-memory behavior is absent | M for faithful ports, L for new programs | High if it changes current UTF-8/ASCII semantics | Add opt-in PETSCII conversion and a virtual C64 screen device; do not change `CHR$`/`ASC` globally. |

## Applesoft BASIC gaps

These features are genuinely absent as Applesoft spellings even when a modern composition exists.

| Missing or partial feature | Dialect | Relevance | Break risk if added | Suggested implementation |
| --- | --- | --- | --- | --- |
| `HIMEM` | Applesoft BASIC | L/N: Modern64BASIC has host-set storage limits and bounded virtual memory | High if a program can enlarge host budgets | At most allow a compatibility value that can lower a session-local allocation ceiling. Never let BASIC raise `RunOptions` limits. |
| `LOMEM` | Applesoft BASIC | L/N | High | Same policy as `HIMEM`; a virtual-memory marker may be exposed for ports but should not control Rust allocations. |
| `SPEED` | Applesoft BASIC | N/L: historical text-output pacing | Low | Usually document as unsupported. If desired for demos, implement bounded optional print throttling, defaulting to immediate output. |
| `INVERSE` text attribute | Applesoft BASIC | M/H for text UIs | Low contextually | Add to the text-terminal attribute state; do not confuse it with the existing matrix `INVERSE(...)` function. |
| `NORMAL` text attribute | Applesoft BASIC | M/H | Low | Reset text attributes in the terminal abstraction. |
| `FLASH` text attribute | Applesoft BASIC | L/M | Medium: rendering and terminal support vary | Represent blink as a logical attribute; GUI can render it, terminal backend may degrade to inverse or normal. |
| `GR` mode | Applesoft BASIC | M compatibility alias | Low | Map to a documented low-resolution logical `SCREEN` mode without emulating Apple memory. |
| `HGR` mode | Applesoft BASIC | M | Low | Map to a documented high-resolution screen profile. |
| `HGR2` mode | Applesoft BASIC | M | Low | Map to a second high-resolution profile or alias `HGR` with a compatibility notice. |
| `TEXT` as a mode-switch statement | Applesoft BASIC | M | Medium: Modern64BASIC `TEXT` already means draw text in graphics | Recognize only the zero-argument form as `SCREEN TEXT`; keep argument-taking graphics `TEXT` unchanged. |
| `VTAB` (partial) | Applesoft BASIC | H for ports/text UI | Low | Implemented for validated rows 1..25 while preserving the current column; exact Apple screen-mode dimensions are not emulated. |
| `HTAB` (partial) | Applesoft BASIC | H | Low | Implemented for validated columns 1..80 while preserving the current row. |
| `HOME` (partial) | Applesoft BASIC | H | Low | Clears through the text backend event and moves to column 1 at the active `VIEW PRINT` top; a full cell-grid clear model remains. |
| `HCOLOR=` | Applesoft BASIC | M | Low contextually | Treat statement-start `HCOLOR = expression` as graphics foreground palette selection. |
| `COLOR=` | Applesoft BASIC | M | Medium: Modern `COLOR` already has different syntax/state | Recognize the equals form as a compatibility alias for the active Apple graphics mode. |
| `PLOT` | Applesoft BASIC | M | Low | Alias to `PSET`, applying the active Apple color and low-resolution coordinate transform. |
| `HPLOT` | Applesoft BASIC | M/H | Low | Parse `HPLOT x,y [TO x,y ...]` and lower it to `PSET`/`LINE`. |
| `HLIN` | Applesoft BASIC | M | Low | Lower `HLIN x1,x2 AT y` to `LINE`. |
| `VLIN` | Applesoft BASIC | M | Low | Lower `VLIN y1,y2 AT x` to `LINE`. |
| `SCRN` pixel query | Applesoft BASIC | H with ports | Medium: `SCRN(...)` currently looks like an array | Implement over the same coherent raster used by `POINT`, returning the active Apple palette index. |
| Applesoft shape-table `DRAW` | Applesoft BASIC | L/M; modern/Microsoft `DRAW` already exists | High: same statement spelling has incompatible data and state | Use an explicit `DRAW SHAPE` compatibility form or dialect option. Do not overload ordinary modern draw strings by guessing. |
| `XDRAW` | Applesoft BASIC | L/M | Low with an explicit shape API | Replay a captured/loaded vector shape using XOR compositing in the coherent raster path. |
| `ROT` shape rotation | Applesoft BASIC | L/M | Low | Store it only in an opt-in Apple shape context; modern `ROTATE` remains the general transform. |
| `SCALE` shape scale | Applesoft BASIC | L/M | High: `SCALE` is already a modern graphics transform statement | Require Apple shape context or a distinct `SHAPE SCALE` form; never reinterpret existing `SCALE` programs. |
| `SHLOAD` | Applesoft BASIC | L | Medium: needs a binary shape format and file access | If ports justify it, load a bounded documented portable shape format from `FileStore`, not raw Apple memory dumps by default. |
| `STORE` | Applesoft BASIC | M: convenient array persistence | Medium: `STORE` is also TI assignment terminology and a plausible variable | Prefer explicit `ARRAY SAVE` syntax or contextual Apple compatibility; serialize type, dimensions, bounds, and values through sandboxed files. |
| `RECALL` | Applesoft BASIC | M | Low/Medium | Pair with atomic `ARRAY LOAD`; validate size/type before replacing the destination. |
| `AMPER` / `&` extension dispatch | Applesoft BASIC | M as a safe extension hook; N as arbitrary machine-language dispatch | High/security and tokenizer impact (`&H`, `&O`, `&B` are radix literals) | Preserve radix scanning. If desired, accept statement-start `& name,args` and route only to registered named services; never jump through a memory address. |
| `ON ERR`/`ONERR` alias | Applesoft BASIC | H compatibility, since `ON ERROR GOTO` already exists | Low | Recognize `ON ERR GOTO` and compact `ONERR GOTO` contextually and lower to the existing error trap. |
| `POP` | Applesoft BASIC | M | Medium: changes classic call-stack state | Pop exactly one classic `GOSUB` frame, reject use during an active event frame if unsafe, and leave structured procedure frames untouched. |
| `DEL` alias | Applesoft BASIC | L/M | Low | Add as a READY-only alias for `DELETE`; do not permit runtime source mutation. |
| `DSP` debugger/source display | Applesoft BASIC | L/M | Low, except `DSP` is already an audio-effects statement with arguments | Reserve only a READY/debug-context form, or use a distinct trace-display command. |
| `NODSP` | Applesoft BASIC | L/M | Low | Pair with the READY/debug display mode; it should not affect audio `DSP`. |

## Modern FreeBASIC/QB64 language-layer gaps

### Preprocessing and source composition

| Missing feature | Dialect(s) | Relevance | Break risk if added | Suggested implementation |
| --- | --- | --- | --- | --- |
| `#IF` | FreeBASIC/QB64 | H for portable OS programs | Medium: `#` is currently the file-channel marker and loaded source requires line numbers | Add a bounded preprocessing pass before `Program::insert_line`; recognize directives only at physical-line start. Preserve source maps for errors and excluded line numbers. |
| `#ELSE` | FreeBASIC/QB64 | H with `#IF` | Medium | Implement in the same nesting-checked directive stack; reject orphan/duplicate branches. |
| `#ENDIF` | FreeBASIC/QB64 | H with `#IF` | Medium | Close the directive stack and report originating file/line on mismatch. |
| `#INCLUDE` | FreeBASIC/QB64 | H | High: includes interact with line-number uniqueness, sandbox roots, recursion, and byte budgets | Resolve only through `FileStore`, canonicalize beneath the BASIC root, cap depth/total bytes, detect cycles, and define collision rules for numbered lines. A module-oriented include format is safer than blind textual insertion. |
| `#DEFINE` | FreeBASIC/QB64 | M/H | High for textual macros because they can alter tokenization and compact keywords | Start with named compile-time constants and parameterless token macros. Expand token streams with depth/size limits; avoid unrestricted character-text substitution. |

The present `Program` type accepts only numbered physical source lines. A real preprocessor therefore belongs above `Program::read_from`, not in statement dispatch. READY insertion also needs a policy: either directives are batch-file-only, or the program store must retain directive/source metadata.

### Native ABI and linkage

| Missing feature | Dialect(s) | Relevance | Break risk if added | Suggested implementation |
| --- | --- | --- | --- | --- |
| `ASM` | FreeBASIC/QB64 | N in the default safe interpreter | High/security, portability, executable-memory, and crash risk | Do not add raw inline assembly. Provide registered typed system services or an out-of-process extension protocol. |
| `CDECL` | FreeBASIC/QB64 | L/N without native FFI | High | If a trusted extension ABI is ever added, calling convention belongs in host registration metadata, not executable BASIC source. |
| `PASCAL` | FreeBASIC/QB64 | L/N | High | Same as `CDECL`; mostly obsolete on the target platform. |
| `STDCALL` | FreeBASIC/QB64 | L/N | High | Same as `CDECL`; irrelevant to ordinary x86-64 System V execution. |
| `EXTERN` | FreeBASIC/QB64 | M/H as typed capability declaration | High | Bind names to host-provided service signatures. No ambient symbol lookup. |
| `EXPORT` declaration modifier | FreeBASIC/QB64 | M for embedding | Medium | Let the host query explicitly exported `SUB`/`FUNCTION` definitions through the library API; do not expose machine symbols from interpreted code. |
| `ALIAS` external-name mapping | FreeBASIC/QB64 | M with `EXTERN` | Medium | Resolve a BASIC-safe name to a registered service name during validation. |

### Type system, modules, object model, and concurrency

| Missing feature | Dialect(s) | Relevance | Break risk if added | Suggested implementation |
| --- | --- | --- | --- | --- |
| `ENUM` | FreeBASIC/QB64 | H: readable constants fit the language well | Low | Collect enum declarations during structured validation and lower members to immutable integer `CONST`s with duplicate/overflow checks. |
| `NAMESPACE` | FreeBASIC/QB64 | H as programs grow | High: `.` already denotes nested record fields and the tokenizer lacks `::` | Introduce an explicit namespace separator and qualified symbol table. Avoid overloading record dots. This requires changes to procedure/type/function lookup and serialization. |
| `UNION` | FreeBASIC/QB64 | M for binary records; otherwise low | High: overlaps values and undermines current typed-record invariants | If added, limit it to fixed-layout binary records with a tagged or explicitly active field. Enforce size/alignment and atomic file transfers. |
| `PRIVATE` | FreeBASIC/QB64 | M, meaningful only with modules/namespaces | Medium | Add declaration visibility during symbol collection; default policy must preserve existing global accessibility. |
| `PUBLIC` | FreeBASIC/QB64 | M | Medium | Pair with module/export tables; do not use as a runtime statement. |
| `OVERLOAD` | FreeBASIC/QB64 | M | High: current procedures are keyed by one canonical name | Add a signature key by arity and declared parameter types, plus deterministic ambiguity rules. Requires typed scalar parameters first. |
| User-defined `OPERATOR` | FreeBASIC/QB64 | L/M | High: evaluator dispatch and precedence are currently fixed | Defer until a richer static type system exists. Never let declarations redefine core operators for primitive values. |
| `CONSTRUCTOR` | FreeBASIC/QB64 | L/M | High: current records are value containers with deterministic defaults | Prefer named factory `FUNCTION`s. Automatic lifecycle hooks require record temporaries, copy/move rules, and error-safe unwinding. |
| `DESTRUCTOR` | FreeBASIC/QB64 | L/N for managed Rust-owned values | High | Do not add until resource-owning user types exist; deterministic host resources should remain scoped runtime objects, not arbitrary record fields. |
| `PROPERTY` | FreeBASIC/QB64 | L/M | High: dotted names currently directly identify record fields | Prefer explicit getter/setter functions. A property system would require method lookup and assignment desugaring throughout lvalue/eval code. |
| `THREAD` | FreeBASIC/QB64 | M/H for OS applications, but raw shared-state threads are a poor fit | High: nondeterminism, output/input races, graphics ownership, events, and storage budgets | Prefer cooperative tasks or isolated workers with message passing and per-task limits. If OS threads are exposed, prohibit shared interpreter internals. |
| `MUTEX` | FreeBASIC/QB64 | M only if shared threads exist | High | Prefer channels. If mutexes are later necessary, use named session-owned handles, automatic release, deadlock diagnostics, and no raw pointers. |

Modern64BASIC already has `BYREF`, `BYVAL`, `STATIC`, and `SHARED`, but they should not be described as full FreeBASIC compatibility: unqualified procedure parameters default to `BYVAL`, scalar parameter `AS type` signatures are limited, and `STATIC` is declaration-based rather than a complete module/object storage-class system.

## Modern runtime/OS and file gaps

| Missing or partial feature | Dialect(s) | Relevance | Break risk if added | Suggested implementation |
| --- | --- | --- | --- | --- |
| `SLEEP` (partial) | QBASIC/FreeBASIC/QB64 | H compatibility | Low | Implemented in seconds, including fractional durations; both timed and indefinite forms abort on a queued key and remain BREAK-interruptible. Historical unit/return-value variants are not emulated. |
| `CURDIR$`/`CURDIR` | FreeBASIC/QB64 | H for a standalone OS BASIC | Medium: call syntax currently means an array | Expose the BASIC-visible sandbox-relative directory from session filesystem state, never the hidden host prefix. Interpreter sessions need the same cwd model as READY. |
| Program-level `CHDIR` | FreeBASIC/QB64 | H | Medium: READY `CD/CHDIR` exists, but runs currently use a fixed file root | Add a session-relative cwd within the immutable sandbox root. Resolve all subsequent BASIC paths through it and reject escape/symlink traversal. |
| `SHELL` | QBASIC/FreeBASIC/QB64 | N as arbitrary shell text; M as a controlled launcher | High/security | Do not pass strings to `/bin/sh`. If needed, expose a capability-gated launcher with an allowlisted executable ID and separately evaluated argv list. |
| `EXEC` | FreeBASIC/QB64 | M/H for an OS BASIC when controlled | High/security and process lifecycle | Provide a safer non-shell process service: allowlisted executable, argv array, cwd inside sandbox, bounded captured output, timeout, and explicit async handle. |
| Main-screen `INKEY`/keycode functions | FreeBASIC/QB64 | H | Medium | Build on the normalized queue/held-key input service described above. |
| Main-screen `VIEW`/`WINDOW` and graphics `GET/PUT` | FreeBASIC/QB64 | H | See the classic graphics table | Implement once in the shared graphics abstraction, not as separate dialect backends. |
| File sharing/access clauses and robust locks | QuickBASIC/FreeBASIC/QB64 | H in a multi-process environment | Medium/High | Extend `OPEN` with portable access/share policy only where the host can enforce it; pair with `LOCK/UNLOCK` and deterministic errors. |

## Operator audit

`src/eval.rs` implements a Microsoft-compatible precedence ladder: `XOR/EOR`,
`OR`, `AND`, `NOT`, comparisons, addition/subtraction, multiplication/real
division/integer division/`MOD`/`NPR`/`NCR`, unary signs, right-associative
power, and postfix factorial. Microsoft-style relational true is `-1` and
false is `0`.

Two classic Microsoft logical operators are absent even though they are not named in the supplied feature list:

| Missing operator | Dialect(s) | Relevance | Break risk if added | Suggested implementation |
| --- | --- | --- | --- | --- |
| `EQV` | GW-BASIC/BASICA/QuickBASIC | M/H for exact expression ports | Medium: `EQV` is currently an identifier in expressions | Add a precedence level below `OR` and above `IMP` (or exactly follow the selected Microsoft grammar), applying checked integer bitwise equivalence. Add tokenizer protection only in operator context. |
| `IMP` | GW-BASIC/BASICA/QuickBASIC | M/H | Medium | Add the lowest-precedence bitwise implication operator with Microsoft integer conversion and truth-table tests. |

Short-circuit `ANDALSO`/`ORELSE`, shifts, and assignment operators are also absent, but they were not part of the supplied comparison surface.

## Architectural constraints that affect implementation

### 1. The one-byte keyword range is full

The classic/native byte-coded range ends at `0xFF`. Later statement tokens use an escaped `u16` representation, while the large modern statement surface normally remains `Ident`. New features should therefore not renumber any existing token. Prefer:

- preprocessing before tokenization for `#...` directives;
- context-sensitive statement recognition for new statement spellings;
- identifier-call recognition for new functions, with an explicit compatibility note about array-name collisions;
- escaped extension tokens only when stable binary token identity is genuinely needed.

Unconditionally adding names to compact classic keyword matching is especially risky: it can split existing variable names because compact syntax deliberately accepts forms such as `GOTO100` and `FORI=...`.

### 2. Unknown calls are arrays

In expressions, an identifier followed by parentheses is a built-in only if it is explicitly recognized; otherwise it is an array reference. Consequently, adding `POINT`, `PMAP`, `SCREENINFO`, `FORMAT`, `INPUT$`, `CURDIR$`, `MULTIKEY`, or similar functions changes the meaning of existing arrays with those names. That is a real Medium compatibility risk, not a theoretical parser detail.

Mitigations include a compatibility version gate, a `SYSTEM.` namespace for new nonclassic queries, warning on newly shadowed arrays, or very careful call-shape recognition. Classic mandatory names such as `POINT` may justify the collision; modern convenience names should prefer a namespace.

### 3. Retained scenes and framebuffers use a lazy coherent raster

`GraphicsDevice` owns both `ArtistScene` command lists and `ScreenBuffer`s. Drawing and retained perspective changes increment per-buffer generations; the first framebuffer/pixel query lazily rasterizes the current Artist source and records the synchronized generation. This removes the stale-clear-state foundation problem, although `POINT`, graphics `GET/PUT`, `SCRN`, and `PCOPY` syntax are still unimplemented.

The remaining integration work is:

1. apply pixel writes/captured-region replay in a representation that survives later retained rendering (for example a raster layer command);
2. make future `PCOPY`, graphics `GET/PUT`, and pixel-query syntax agree on draw versus display buffer;
3. reuse the generation cache for those operations rather than adding separate raster paths.

### 4. Text output has partial program-visible terminal state

The interpreter now tracks row, Unicode-character column, a `VIEW PRINT` region, cursor visibility, and text colors, and emits ordered GUI screen events. It still lacks a shared logical cell grid and attributed output stream, so backend-perfect clearing, scrolling, screen-cell queries, cursor shapes, and historical Apple attributes remain partial.

### 5. Input ownership does not currently reach expression functions

Statements receive a mutable `BufRead`, but `ExpressionRuntime` does not. This is why a true `INPUT$` function is more involved than adding a name to `functions.rs`. A resolver that evaluates runtime-backed, side-effecting functions before the ordinary expression parser—or a carefully designed input provider in the runtime context—is needed. It must preserve left-to-right, single-evaluation behavior.

### 6. Host integration is intentionally capability-gated

Virtual memory/ports and registered services are deliberate safety boundaries. The same design should govern serial ports, processes, external symbols, time setters, and extensions. A standalone OS BASIC benefits from those capabilities, but being “standalone” is not authorization to inherit ambient secrets, open arbitrary devices, execute shell text, or jump to addresses.

## Recommended roadmap

### Priority 0: finish the native screen/input/file contract

1. Complete the partial logical terminal with attributed cells, region-aware backend clearing/scrolling, cursor shapes, and classic `COLOR` compatibility around the implemented `LOCATE`, `CSRLIN`, `VIEW PRINT`, `HOME`, `HTAB`, `VTAB`, and `TEXTCOLOR` state.
2. Build `POINT`/`SCRN`, graphics `GET/PUT`, `PCOPY`, `VIEW`, `WINDOW`, and `PMAP` on the implemented coherent raster generation cache.
3. Extend the implemented live bare/parenthesized `INKEY$` queue with `INPUT$`, held keys/`MULTIKEY`, and `ON KEY`/`KEY(n)` controls using the existing event scheduler.
4. Replace `PRINT USING` with a conformance-tested formatter shared by console/file/spool targets; add close-all/multi-close and file locks.

### Priority 1: high-value compatibility and OS conveniences

1. Add contextual/desugared aliases: `DIM SHARED`, `DECLARE`, remaining Apple drawing aliases, and `ON ERR`; complete any dialect-specific `SLEEP` variants only when their units are explicit.
2. Add session cwd plus `CURDIR$` and program `CHDIR` without weakening the sandbox.
3. Add portable `SCREENINFO`/`SCREENCONTROL` and safe batching aliases for lock/unlock.
4. Add an explicit `PLAY MML` compatibility mode and complete Microsoft `DRAW` strings without changing existing modern `PLAY` programs.

### Priority 2: bounded source and module facilities

1. Introduce source files/source maps above `Program`, then sandboxed `#INCLUDE` and conditional compilation.
2. Add token-bounded constants/macros, followed by `ENUM`.
3. Add namespaces and visibility only after choosing a qualifier that cannot be mistaken for record-field access.
4. Add typed named external-service declarations for embedding; retain host registration as the authority.

### Defer or deliberately reject

- raw `ASM`, interrupts, raw calling conventions, arbitrary address/pointer access;
- unrestricted `SHELL` and ambient-library loading;
- Apple `HIMEM`/`LOMEM` controls that can raise host resource budgets;
- object lifecycle hooks and raw shared-state threads until the language has a compelling type/resource model;
- literal light-pen/game-port emulation unless a target application needs it.

## Bottom line

Modern64BASIC is not missing the core of classic BASIC. Its principal deficit is the layer that makes a BASIC feel like a complete interactive operating environment: addressable text, coherent queryable graphics pages, complete input/event state, exact formatting, and safe program-visible filesystem/process context. Those features are both more relevant to the standalone-OS design and less disruptive than attempting to clone FreeBASIC's native compiler ABI or object system.

The most important compatibility warning is that adding functions is not automatically additive: unknown calls currently become arrays. The most important implementation warning is that pixel-reading features must reconcile retained Artist scenes with framebuffer state first. The most important security rule is to extend the existing capability model rather than exposing raw machine or shell facilities.
