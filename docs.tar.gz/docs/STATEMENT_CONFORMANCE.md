# Statement conformance and native x86-64 policy

ModernBASIC implements one coherent language. It preserves classic numbered
program control and recognizable Microsoft/Dartmouth/TI/BBC forms, but executes
them as native Rust on a modern operating system. It does not expose arbitrary
host memory, privileged x86 I/O instructions, or machine-code entry points.

## Executable statement families

The interpreter dispatches and regression-tests these families:

- Core program control: `END`, `STOP`, `RUN`, `CONT`, `GOTO`, `GO TO`, `GO SUB`, `IF`,
  inline/block `ELSE`, `ON GOTO`, `ON GOSUB`, `GOSUB`, `RETURN`, `FOR`, `NEXT`,
  `WHILE`, `WEND`, `DO`, `LOOP`, `REPEAT`, `UNTIL`, structured `EXIT`, and
  standard/BBC `SELECT CASE` forms. Validated `SUB`/`END SUB` and numeric/string
  `FUNCTION`/`END FUNCTION` procedures add default/explicit `BYVAL` and explicit
  exact-type `BYREF` parameters, scalar/array-element/record-field aliases,
  exact-type primitive and typed whole-record array aliases, nested alias
  forwarding, recursion, per-call typed primitive/record scalars and arrays,
  persistent typed `STATIC` primitive/record scalars and arrays, `SHARED`, early
  `EXIT`, expression calls, and classic `GOSUB`
  interoperability. `ON TIMER` and `ON COLLISION` add bounded, non-reentrant,
  statement-boundary GOSUB event delivery. Stored declarations are callable
  during `RUN` and from the `READY.` prompt.
- Data and variables: `LET`, implicit assignment, `CONST`, `DIM`, atomic
  `REDIM`/`REDIM PRESERVE`, `DATA`, `READ`, `RESTORE`, `INPUT`, `LINE INPUT`,
  `GET`, `SWAP`, `CHANGE`, storage-releasing `ERASE`, `CLEAR`, `DEF FN`, type
  declarations, `RANDOMIZE`, and `OPTION BASE`. Single-line numeric `DEF FN`
  accepts one or more parameters and composes bidirectionally with multi-line
  `FUNCTION`, including lazy branches, single-evaluation arguments, complex
  results, BYREF effects, and bounded cross-recursion. `LBOUND`/`UBOUND` report
  actual multidimensional shapes through local, `STATIC`, record-field, and
  BYREF array names.
- User-defined records: validated `TYPE`/`END TYPE`, primitive and nested
  `AS` field declarations with forward references and cycle rejection,
  dynamic/fixed strings, scalar and array `DIM ... AS type`, multi-level dotted
  field lvalues/expressions, typed input and `READ`, atomic record-array
  `REDIM [PRESERVE]`, record-aware `ERASE`, scoped local/STATIC storage,
  exact-type whole-record/subrecord assignment, and typed root/subrecord array
  formals.
- Output: `PRINT`, `PRINT USING`, `WRITE`, `WIDTH`, `LPRINT`, `LLIST`, `LIST`,
  `TRON`, `TROFF`, and `NULL`.
- Sandboxed files: standard and MS/GW mode-first `OPEN`, `CLOSE`, `PRINT#`,
  `WRITE#`, `INPUT#`, `LINE INPUT #`, `GET#`, `FIELD`, `LSET`, `RSET`,
  `PUT`, `SEEK`, `LOAD`, `SAVE`, `VERIFY`, `KILL`, `NAME`, `CHAIN`, `MERGE`,
  and `COMMON`. Random files support classic buffered records and portable
  direct fixed-layout scalar, array-element, and nested TYPE records; binary
  files support the same direct records at one-based byte positions alongside
  existing byte I/O. Short block reads and random buffers commit atomically.
- Errors and sessions: `ON ERROR GOTO`, `ERROR`, `RESUME`, `NEW`, exact
  statement-level READY `STEP [count]`, STOP/CONT continuation, fresh RUN,
  and the
  READY-only editing commands `AUTO`, `DELETE`, `EDIT`, and `RENUM`.
- Dartmouth matrices: the supported `MAT` assignment, arithmetic, input,
  print, read, transpose, inverse, determinant, identity, zero, and constant
  forms.
- Graphics and animation: the native Artist-backed drawing statements, buffered
  screens, visible movable sprites, deterministic velocity/acceleration frame
  stepping, pair/any-sprite collision queries and traps, logical-screen mouse
  polling, nonblocking keyboard polling, layers, transforms, antialiased
  primitives and BRUSH strokes, deterministic path-clipped `PAINT TEXTURE`, bounded
  blur/sharpen/color `PAINT FILTER` finishing, common still imports with alpha-preserving
  premultiplied scaling and anchored BITMAP WARP deformation, RGBA colors, true raster linear/radial gradient paints, 19
  raster/SVG blend modes, depth-grid operations, a retained XYZ perspective memory map for pixels, objects, and sprites with
  focal-depth scaling, three-axis sprite motion, projected collision, camera movement,
  global far-to-near ordering, bounded point-light shading, explicit 2D/3D screen modes, rendering, screenshots, and
  TI graph/window statements.
  Retained FLIPBOOK still sequences can be projected or encoded to bounded MP4,
  WebM, or GIF output; PLAY AUDIO and PLAY VIDEO handle sandboxed local media
  and capability-gated direct HTTP(S) streams. This is a complete-frame
  producer/playback API, not yet a full Photoshop-style retouching UI or
  nonlinear video editor.
- Networking and web: `WEB GET`, `WEB POST`, and `WEB DOWNLOAD` provide
  bounded HTTP(S) data access through fixed curl arguments; `WEB OPEN` delegates
  full browsing and licensed playback to the host's installed browser. The
  family is disabled by default and must be enabled by the host.
- Sound: `SYNTHPROFILE`, `VOICES`, `OSCILLATORS`, `TEMPO`, `VOICE`, `WAVE`, `OSCILLATOR`, `ADSR`, `PULSEWIDTH`, `VOL`,
  `STEREO`, `PAN`, `MIXER`, `FILTER`, `FILTERADSR`, `LFO`, `GLIDE`, `DRIVE`,
  `PLAY`, `SOUND`, `BEEP`, `SOUNDFONT`, `INSTRUMENT`,
  `EXPRESSION`, `MODULATION`, `SUSTAIN`, `PITCHBEND`, `REVERB`, `CHORUS`, `DSP`,
  `WAVEFILE`, `SAY`, and timed lyric-to-note `SING`.

`AUTO`, `DELETE`, `EDIT`, and `RENUM` deliberately report that they are
READY-only when placed inside a running program. They operate on the stored
program in the interactive environment, which is the classic BASIC behavior.

## Modern hardware adaptation

| Classic operation | ModernBASIC behavior |
| --- | --- |
| `PEEK` / `POKE` | Access a bounded, language-owned 1 MiB byte arena. `DEF SEG` selects a checked segment within that arena. |
| `INP` / `OUT` | Read and write a bounded 65,536-byte virtual port bank. No privileged x86 port instruction is executed. |
| `WAIT milliseconds` | Interruptible native monotonic delay, limited to one hour per statement. |
| `WAIT port,mask[,xor]` | Classic masked wait against the virtual port bank; Ctrl+Escape or the host interrupt API breaks the wait. |
| `SYS` / `CALL` / `USR` | Invoke only host services explicitly registered with the execution session. Unregistered addresses return a structured error. |
| `COMMAND$` / `ENVIRON$` | Read only the bounded command tail and ordered environment explicitly approved in `RunOptions`; both are empty by default and ambient process secrets are never inherited. |
| `CMD` | Redirect output only to an already-open sandboxed BASIC file channel. |
| File statements | Resolve beneath the configured BASIC user root; traversal, absolute escape, and symlink escape are rejected. |
| `WEB` and streaming `PLAY` | Disabled by default; when approved, accept validated HTTP(S) only and use fixed curl/browser/FFmpeg interfaces. Linux retains drivers, DNS, TLS, and browser responsibilities. |
| Graphics and sound | Use native X11, software rendering, PCM audio, and SoundFont synthesis. Video frame export invokes only a fixed-argument FFmpeg encoder; BASIC cannot inject commands or request capture/editing operations. |

This boundary gives old programs familiar semantics while preventing a BASIC
program from reading arbitrary process memory, executing raw machine code, or
performing privileged hardware access on the x86-64 host.

## Verification policy

`verify.sh` checks formatting, every Cargo target, the complete unit and
integration suite, Clippy with warnings denied, rustdoc, and an optimized
release build. `smoke-test.sh` then exercises the packaged executable. A release
is accepted only after both scripts pass on the target Linux/x86-64 system.
