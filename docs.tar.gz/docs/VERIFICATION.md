# Verification status

## Package-level checks completed in this workspace

- Compared the actual 0.7 and 0.8 attachment contents rather than relying on
  prior project memory.
- Confirmed the older archive's internal version is 0.7.6 despite its filename.
- Preserved the four modified Rust/test files found beyond the attached 0.8
  repository revision before applying the 0.8 series repairs.
- Removed `.git` history and Python bytecode from the release tree.
- Synchronized `Cargo.toml` and `Cargo.lock` at version 0.8.2.
- Retained the 492 tests that passed on the target workstation for 0.8.1 and
  expanded the suite to 727 tests. The additional coverage includes editor,
  parser, math, graphics, resource-limit, file-format, error-handler,
  navigation/history, case-folded path, READY-return, native `WAIT`, classic
  integer operators, inline/block `ELSE`, structured loops/exits, and
  standard/BBC `SELECT CASE`, multi-parameter `DEF FN`, `GO SUB`,
  `LINE INPUT #`, mode-first `OPEN`, Dartmouth `CHANGE`, atomic
  `REDIM [PRESERVE]`, immutable `CONST`, corrected `ERASE` accounting, and
  structured recursive `SUB` scope/storage/control-boundary regressions, and
  multi-line numeric/string `FUNCTION` recursion, scoping, storage, direct
  calls, control-flow laziness, and depth/type/declaration validation, plus
  user-defined `TYPE` scalar/array fields, fixed strings, typed I/O, atomic
  resize/erase behavior, declaration boundaries, binary token-codec fuzzing,
  offline-by-default web/media capability enforcement, HTTP(S)-only URL
  validation, CLI network-option parsing, and real localhost `WEB GET`,
  `WEB POST`, and binary `WEB DOWNLOAD` transfers,
  and explicit `BYVAL`/`BYREF` scalar, array-element, record-field, recursive
  forwarding, exact-type, and retained-storage behavior. New procedure-array
  coverage includes exact-type whole-array forwarding, per-call local arrays,
  persistent STATIC arrays, transactional `AS` type scope, `LBOUND`/`UBOUND`,
  visible moved sprites, collision queries, and timer/collision trap lifecycle.
  Record-array coverage now also includes recursive local isolation, persistent
  STATIC field/type separation, atomic failure rollback, exact-type whole-record
  aliases, nested forwarding, FUNCTION use, resize, and caller-visible erasure.
  It also covers scalar/element whole-record copy and rollback, recursive local
  record scalars, typed primitive/record STATIC persistence and type conflicts,
  record-base SHARED scope, keyword-prefixed `CALL` procedure names, nested
  TYPE forward references and cycle rejection, multi-level scalar/array paths,
  exact-type subrecord copy, and root/subrecord typed-array forwarding. File
  coverage now also locks down classic comma-free and explicit random
  `FIELD`/`LSET`/`RSET` transfers, portable direct TYPE records in random and
  binary modes, nested record arrays and subrecords, all fixed-layout primitive
  kinds, comma-containing channel expressions, exact little-endian bytes,
  current-position forms, short-read rollback, dynamic-string rejection, and a
  1,000-record reverse-order checksum stress. `DEF FN`/`FUNCTION` composition
  coverage includes both call directions, laziness, single evaluation, complex
  results, BYREF mutation, and bounded cross-recursion. Process-context coverage
  now includes bare and parenthesized `COMMAND$`, named and indexed `ENVIRON$`,
  case-insensitive duplicate normalization, default isolation from ambient host
  variables, invalid/bounded context rejection, CLI forwarding, and 5,000
  repeated lookups across the 255-entry boundary.
  Singing coverage maps hyphenated syllables to `PLAY` notes, dotted durations,
  rests, tempo, velocity-scaled level, and the C2-through-C6 vocal contour. It
  also checks mismatch/range/duration rejection, timed-rest completion, compact
  tokenization, headless CLI execution, and the 4,096-event statement boundary.
  Smoothed-renderer tests additionally cover 16-bit WAV decoding, exact PCM
  score length, attack shaping, adjacent-note crossfade, room decay through a
  rest, and asynchronous renderer-error delivery.
  Creative-animation coverage now also includes deterministic sprite velocity
  and acceleration stepping, six live motion queries, invalid motion/identifier
  bounds, logical-screen mouse defaults and button validation, bounded FIFO
  `INKEY$()` behavior, strict PPM frame validation, VIDEO lifecycle/format/rate/
  dimension errors, headless end-to-end BASIC frame capture, and expression or
  variable `LINE` widths without ambiguity with classic `B`/`BF` box modes, and
  separation of generated media from ordinary BASIC files through `output_root`.
  Flipbook/media coverage adds exact numbered-template expansion, bounded
  one-frame-at-a-time PPM streaming, bilinear letterboxing, end-to-end BASIC still
  generation, FLIPBOOK retention/projection, VIDEO EXPORT, BRUSH rendering,
  deterministic multi-octave path-clipped PAINT TEXTURE, bounded blur/sharpen/color
  PAINT FILTER finishing, and alpha-preserving premultiplied BITMAP WARP deformation
  with a fixed stem anchor.
  Direct release probes also generated WAV and exercised PLAY AUDIO, encoded a
  real GIF and H.264 MP4, decoded that MP4 through PLAY VIDEO, imported a PNG,
  bilinearly rescaled it, and preserved it through PPM and raster PNG export.
  Logical-screen coverage additionally verifies aspect-preserving host-window
  fitting, stretch opt-in, exact mouse-coordinate mapping, black-bar exclusion,
  physical-display clamping, atomic rejected `SCREEN` changes, and repeated
  buffer swaps, exports, resolution changes, and extreme off-screen geometry.
  Audio-readiness coverage verifies atomic `LOAD` rollback for an invalid
  declared bank, prepared-bank reuse, and exact ADSR/DSP state equivalence
  across odd live-render chunks. Vocal coverage verifies retained `SING` scores
  form a bounded sequential 44.1 kHz stereo export. Raster typography coverage
  checks exact pixels
  in an upright column-major ASCII glyph instead of merely checking that some
  text-shaped pixels exist.
- Checked shell syntax with `bash -n`.
- Expanded the release smoke test with a non-audio core-language program and a
  sandboxed `WRITE#`/`INPUT#` round trip, plus `ON ERROR`/`RESUME` retry
  behavior, uppercase access to the lowercase examples directory, and bounded
  nested file-browser reporting. It now also generates and validates a native
  RIFF/WAVE, generates and probes a real two-frame H.264 MP4 when FFmpeg is
  installed, and checks all 321 tracked BASIC sources for unique increasing
  line numbers and removed legacy statements.
- Added `audio-test.sh` for a headless WAV check and an optional live four-note
  `paplay`/`aplay` acceptance test.
- Checked archive paths, source-module presence, version markers, prohibited
  release artifacts, and balanced Rust delimiters with a lexical static scan.

## Dynamic verification status

On 2026-08-26 this workspace passed the required release checks after the
text-terminal, expression-precedence, graphics-coherence, fullscreen, and
per-task audio review: formatting, warning-free optimized build, 727 tests
(384 library, 7 binary, and 336 integration), and Clippy with warnings denied.
The suite now includes Unicode `PRINT` wrapping, validated text coordinates,
`VIEW PRINT`/`HOME`, key-abortable timed `SLEEP`, keyword-name assignments,
comparison-before-`NOT`, `PRINT USING` type safety, lazy scene rasterization,
and independent audio/speech session ownership. The earlier full verification
also included warning-strict private-item
rustdoc, and a locked optimized release build. `./smoke-test.sh` then passed and checked
unique increasing line numbers and removed statements across all 321 tracked
BASIC sources, including `programs/examples/perspective_world.bas`. Behavioral
coverage checks exact statement stepping across colon boundaries and
GOTO/GOSUB/RETURN, stepping beyond STOP followed by CONT, 2D/3D screen-mode
switching, and the unified retained XYZ map: pixels, objects, and sprites share
depth scaling, camera-relative clipping, far-to-near layering, point-light
shading, sprite motion, projected collision, queries, and raster output.

Networking verification uses an in-process localhost HTTP server to check
UTF-8 GET/POST responses and byte-exact downloads without depending on an
external service. Separate tests prove that WEB operations and HTTP(S) media
playback fail before host access unless `RunOptions` grants the capability,
and that non-HTTP addresses are rejected even after permission is granted.
The retained-still acceptance produced 72 distinct 640x480 stickman PPM pages,
an 8.2 MiB 640x480 GIF, and an H.264 MP4. The finalized one-leaf acceptance ran
under the default 100,000-statement guard, produced 120 distinct 960x540 PPM
pages, a 25 MiB 120-frame GIF, a 126 KiB still, and a 412 KiB 120-frame
five-second H.264 MP4. Its ordinary numbered BASIC source contains no `BITMAP`
and imports no leaf image: it constructs the wind/depth-deformed mask, then
paints multi-scale deterministic texture, gradient lighting, clipped sheen,
mottling, curved veins, stem, shadow, and sharpening itself. The feather
acceptance also ran under the default statement guard and produced 120 distinct
960x540 pages, a 17 MiB 120-frame GIF, a 54 KiB still, and a 497 KiB
five-second H.264 MP4. Its no-import BASIC source paints translucent asymmetric
vanes, multi-scale texture, rachis, separated diagonal barbs, frayed gaps, downy
wisps, sheen, and shadow. Wind produces strong centerline bending while one full
end-over-end tumble and two edge-on axial flips reverse the visible face and
shading; position and Z-derived scale also change through the seamless cycle.
All movies were encoded by VIDEO EXPORT from the same FLIPBOOK sequences used
by live playback.

A maintained-source scan found no unfinished implementation markers or Rust
placeholder macros. The renderer cleanup removed abandoned duplicate
gradient and circle rasterizers, an unconnected PPM clip-mask helper, and its
invalid SVG clip reference path; the active generalized gradient and shape
coverage pipeline remains.

The perspective design was also checked against the retained scene and horizon
model in the perspective-engine project and the focal-depth camera, clipping,
and painter ordering in Artist. ModernBASIC keeps these behind one BASIC-facing
engine rather than exposing a second renderer. The classic-document outcome
review is recorded in `docs/CLASSIC_BASIC_CAPABILITY_MATRIX.md`.

On 2026-08-23 this workspace passed the complete `./verify.sh` sequence:
repository-wide formatting, all-target checking, all 664 tests, Clippy with
warnings denied, warning-strict private-item rustdoc, and a locked optimized
release build. The packaged release smoke suite also passed; the prior
`audio-test.sh --no-play` acceptance was repeated successfully. The smoke suite
validated the runnable BASIC catalog, while direct
release-CLI probes covered the repaired math aliases, statistics,
autocorrelation, deep-expression rejection, large list/resource bounds, and
graph rendering. A direct optimized TYPE stress populated 5,001 records, grew
the record array to 7,501 with preservation, then shrank it to 2,501 while
retaining boundary values and defaulting newly exposed fields correctly.
An optimized BYREF stress then exercised 5,001 array-element calls, 91-level
SUB forwarding, 91-level FUNCTION forwarding, 1,001 typed record-field calls,
and local/STATIC reference targets; every checksum matched its closed-form
expected value.
The program-generated video path was accepted twice: the release smoke test
encoded and probed a two-frame 16 by 16 H.264 stream at 24 fps, and the complete
animation demo encoded 360 frames at 1920 by 1080, 60 fps, and exactly 6.0
seconds in 147.20 seconds of wall time. FFprobe reported H.264 High profile,
YUV420P, the expected dimensions and rates, and exact frame counts in both
cases. Pixel-level raster regressions separately cover linear/radial gradient
paints, radial radius parsing, rounded edge coverage, simultaneous fill/stroke,
distance-covered thick lines, four-subscanline polygon slopes, antialiased
geometric display text, exact retained-prefix output, removal of cached shape
tails after `CLS`, buffer-local clearing with drawing-point reset, split-screen
text/graphics clearing, parallel RGB packing,
extreme off-screen bounds, post-shape blend commands, and bounded output from
all 19 blend modes. A separate cross-codec stress encoded eight 24 by 18
frames at 20 fps through every supported extension; FFprobe reported H.264,
VP9, and GIF respectively, with the exact dimensions, rate, and eight-frame
count for all three outputs.
The Full-HD capabilities presentation was rendered and visually inspected at
four points in its timeline after adding the antialiased geometric display
face. The complete BASIC-generated artifact finished in 13.21 seconds—faster
than its playback duration. FFprobe reported H.264 High profile, YUV420P,
1920 by 1080, 30 fps, exactly 450 frames, stereo AAC at 44.1 kHz, and exactly
15.0 seconds. The separately retained PCM soundtrack is also exactly 15.0
seconds with a measured -1.9 dB peak. Its four acts exercise animated
individual letters, three independently moved sprites and collision state,
gradients, alpha/blend/Bezier/subpixel drawing, and data-driven math graphics.
The same source now defaults to a file-free live mode whose frame number follows
wall-clock time, skips late frames instead of drifting from audio, and restarts
frame zero and native synthesized playback together every 15 seconds. Its score
uses only direct `SOUND frequency,voice,duration` tones on three independently
`WAVE`-configured voices. Their frequencies form the music; `PLAY` notation is
not used.
An additional optimized combined stress mutated 5,001 elements through a
whole-array alias, forwarded that alias through 51 recursive calls, performed
1,000 local/STATIC array calls, checked stored bounds, moved and rendered
colliding sprites, and dispatched both collision and timer GOSUB traps. Its
nine scalar/query results matched the expected values exactly.
The final optimized record-value stress initialized 2,001 two-field records,
resized them to 2,501 through `BYREF name() AS type`, forwarded the alias through
41 recursive calls, copied scalar and indexed records by value, and executed
500 local-record plus STATIC-record calls. It also used the keyword-prefixed
procedure names `SCALEALL` and `FORWARD`; the checksum/value/bound/count results
were exactly `4006002`, `4001`, `2500`, and `500`.
The direct random-record stress wrote and then read 1,000 portable 20-byte TYPE
records in reverse order. Its integer and real checksums were exactly `500500`
and `125125`, and the host file length was exactly 20,000 bytes.
An interactive release-binary acceptance loaded the packaged 445 MiB clean
guitar bank and reported one prepared audio asset before `READY.`. `RUN` reused
that parsed bank, streamed playback through the live PulseAudio/PipeWire sink,
withheld the following `READY.` until the song completed, then exited cleanly.
Automated X11 acceptance also confirmed program entry/run,
Up/Down history, F2 and Ctrl+Up list editing, Escape cancellation, sandboxed
directory navigation, continuous graphics repaint, visible Ctrl+Escape `BREAK`
return to text/`READY.`, and clean window shutdown. The live four-note playback
command completed through the host audio stack. Shell syntax passed for all
launch/verification scripts, and a timestamp probe confirmed `run.sh` rebuilds
the optimized binary whenever Rust sources or Cargo manifests are newer.
Manual-derived CLI certifications completed at 62/62 for MS/GW-BASIC, 37/37
for BBC BASIC, and 35/35 for C128 BASIC. Dartmouth completed at 43/44 and
Amiga BASIC at 37/38; each has only the documented bare-`PI` dialect
distinction. File-I/O certifications ran beneath disposable sandbox roots
after their hard-coded `/tmp` filenames were changed in the input stream to
relative names; the source fixtures were not modified.

Direct CLI stress also populated 15,000 numeric array elements, preserved them
through growth and shrink operations, and resized safely to the configured
1,000,000-element boundary. A deliberately larger fill hit the 100,000-statement
execution guard cleanly.


The attached repository history records that an earlier 0.8.0 revision passed
its then-current 477 tests, Clippy, rustdoc, and release build on 2026-08-17.
That older record is retained only as provenance; the successful 0.8.1 target
verification is the direct baseline for 0.8.2.

Run the following before treating a future source revision as a binary release:

```sh
./verify.sh
./smoke-test.sh
```

Expected full verification stages:

1. `cargo fmt --check`
2. `cargo check --all-targets --locked`
3. `cargo test --all-targets --locked`
4. `cargo clippy --all-targets --locked -- -D warnings`
5. rustdoc with warnings denied
6. optimized locked release build
7. CLI smoke tests for version, native 64-bit arithmetic, program execution,
   core non-audio BASIC behavior, SVG graph export, bounded virtual hardware,
   sandboxed file round trips, WAV generation, and runnable-catalog structure

After the automated checks pass, open `./run.sh` for the graphical keyboard
acceptance check:

1. Enter `10 PRINT "ONE"` and `20 END`.
2. Press ordinary Up/Down and confirm they recall submitted statements and
   commands.
3. With a program loaded, press Ctrl+Up/Ctrl+Down without first pressing F2;
   confirm the program is captured and only stored numbered lines are selected
   for editing. Confirm Ctrl+Left/Ctrl+Right move the character cursor without
   closing the shell.
4. Press Escape and confirm list-edit mode closes without requesting BREAK.
5. Run a graphics loop and confirm Ctrl+Escape immediately returns to the text
   screen, reports `BREAK`, and returns the session to `READY.`. Confirm plain
   Escape changes the view without interrupting the running program.
6. Enter `PWD`, `DIR`, `CD MUSIC`, and `PWD`. Confirm the display uses only
   `programs` and `programs/music`, with no host `/home/...` prefix.
7. Run `./audio-test.sh`. Confirm it reports a valid WAV and that four notes are
   audible. If live audio is intentionally unavailable, run
   `./audio-test.sh --no-play` and record the missing host player separately.
