# Migration from the attached 0.7 package

The attached 0.7.5 archive identifies itself as version **0.7.6**
inside `Cargo.toml`. Treat the internal manifest as authoritative when
comparing builds.

## Architectural changes

0.8 is a substantial source revision rather than a cosmetic version bump:

- `speech.rs` is new.
- SoundFont scheduling and rendering are substantially expanded.
- Audio statement routing was consolidated in `interpreter.rs`.
- Obsolete `.orig` sources were removed.
- The separate DSP/transcription executable and its large analysis cache were
  removed from the current runtime direction.
- The package remains a single ModernBASIC language; the supplied RustBASIC
  multi-dialect development guide describes a different repository layout and
  must not be applied mechanically.

## Audio source migration

| Older source | Current 0.8.2 source |
| --- | --- |
| `VOICES n` | Supported again: select 1 through 16 active native voices. Use `OSCILLATORS n` for 1 through 8 layers or `SYNTHPROFILE` for a named arrangement. |
| `VOLUME x` | `VOL x` |
| `VOLUME n,x` | `VOL n,x` |
| `SOUNDFONT path$` | Supported directly for a sandboxed `.sf2` bank; place it before `INSTRUMENT` and `PLAY`. |
| `EXPRESSION n,x` | Channel expression with normalized `x` from 0 through 1. |
| `MODULATION n,x` | Channel vibrato/modulation with normalized `x` from 0 through 1. |
| `SUSTAIN n,x` | Channel sustain pedal with normalized `x` from 0 through 1. |
| `PITCHBEND n,x` | Channel pitch position from -1 through 1. |
| `REVERB n,x` / `CHORUS n,x` | Channel effect sends with normalized `x` from 0 through 1. |
| `MUSIC CLEAR` | `CLEAR` if full program/audio reset is intended. |
| `MUSIC SCORE ...` | Use one or more `PLAY` statements with independent voices. |
| `MUSIC PLAY` | `SOUND RESUME`, `END`, or `STOP` |
| `MUSIC SAVE path$` | `WAVEFILE path$` |

SoundFont BASIC voices are 1 through 16. Old experimental programs that use
voice 0 should be corrected to start at voice 1.

## PLAY migration

Use explicit whitespace-separated note tokens:

```basic
10 PLAY 1,"C4/4@72 E4/4@86 G4/2@104"
20 PLAY 2,"C3:1 R:1 G3:2"
```

Each token carries its octave. Lengths may be written as beats (`:0.5`) or
musical denominators (`/8`, `/8.`). Append `@velocity` to sampled notes to set
attack strength from 1 through 127. Do not rely on stale compact `O4 Q C`
examples from the deleted 0.8 documentation snapshot; that grammar is not what
the attached source implements.

## Tests and packaging

The 0.7 archive contains an external statement-case harness that is not present
in the attached 0.8 working tree. The 0.8 source instead has a larger in-crate
suite: this repaired tree contains 511 `#[test]` functions, including 211 in
`tests/integration_tests.rs`.

The old statement fixtures should be ported selectively, not copied wholesale,
because several encode removed audio spellings or earlier behavior. A passing
0.7 fixture is evidence to examine, not permission to reintroduce incompatible
syntax into the one ModernBASIC language.

