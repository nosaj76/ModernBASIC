# Program editor and user files

ModernBASIC keeps classic numbered lines while providing keyboard editing in
the native graphical shell.

## Default directory

When ModernBASIC is started without `--file-root`, it searches for the
installed `programs` directory and uses it as the BASIC user root. The launcher
changes to the project directory before starting the executable, so the normal
command is enough:

```sh
./run.sh
```

At `READY.`:

```basic
PWD
DIR
CD "examples"
DIR
DIR "*.dat"
DIR *
TREE /
CD /
```

The visible BASIC root is simply `programs`; no `/home/...` host prefix is
shown. `PWD` and `CD` therefore report `programs` at the root and paths such as
`programs/examples` or `programs/music` below it. These displayed paths can be
typed back into `CD`, `DIR`, `LOAD`, and the other file commands. Plain `DIR`,
and `DIR` with a directory path, show all user entries without exposing their
host paths. Listings are divided into `DIRECTORY FOLDERS`, `BASIC PROGRAMS`,
and `OTHER FILES`, in that order. This keeps `.bas` programs prominent while
retaining access to their data and support files at the bottom. Use a pattern
such as `DIR *.dat` to narrow the listing under `MATCHING FILES`. Listings
report totals for the visible entries.
`TREE [path]` and `DIR /S [path]` recursively browse nested directories with
fixed entry and depth limits. `CD /` and `CD \` return to `programs`; `CD ..`
and compact `CD..` move to the parent but remain at the root when already
there. Forward and backslashes are both accepted as BASIC separators.

Paths cannot escape the user root. Symbolic links are displayed but recursive
browsing does not follow them, and canonical path checks still reject a link
that would leave the root. An explicit `--file-root` still overrides the
default.

Existing files and directory components are resolved case-insensitively within
that root. These therefore select the same packaged directory even while the
graphical shell is in uppercase-input mode:

```basic
CD examples
CD EXAMPLES
CD "examples"
```

Listings retain each file or subfolder's real spelling beneath `programs`, but
never print the absolute host prefix. A new output file keeps the spelling typed
by the BASIC program, while an existing file is reused case-insensitively
instead of creating a second name that differs only by case.

## Editing a listed program

1. Load or enter a program containing at least one numbered line.
2. Press **F2** to execute `LIST`, or press **Ctrl+Up**/**Ctrl+Down** directly.
   Direct program navigation automatically lists and captures a loaded program;
   an empty program leaves navigation inactive.
3. Press **Ctrl+Up** or **Ctrl+Down** to select a numbered line. The complete
   canonical line is copied into the editable input row.
4. Use **Left**, **Right**, **Home**, **End**, **Backspace**, and **Delete** to
   edit the line.
5. Press **Enter** to replace the stored line.
6. Continue with **Ctrl+Up** or **Ctrl+Down**, or press **Escape** to leave
   list-edit mode.

Page Up and Page Down scroll a long listing. Entering a line number without a
body deletes that line, following classic BASIC rules.

Ordinary **Up** and **Down** browse the shared READY history. That history
contains commands such as `RUN` and numbered statements such as
`20 PRINT "HELLO"`. History navigation remains available while list-edit mode
is active. Submitting a non-numbered command, pressing Escape, or using
`NEW`/`LOAD`/`RUN` leaves list-edit mode so stale lines cannot be selected.

**Ctrl+Left** and **Ctrl+Right** move the character cursor safely and cannot be
mistaken for control-letter shortcuts.

**Ctrl+U** toggles the graphical input mode between `CAPS:ON` and `CAPS:OFF`.
The status line displays this shortcut. Lowercase typed inside a quoted string
or path is preserved even while the general input mode is uppercase.

**Ctrl+Escape** is the hard BREAK shortcut. It also returns a graphics/demo
view to the text screen so `BREAK` and `READY.` are visible. Plain Escape
cancels the current shell input or exits a graphics/list-edit view without
interrupting a running program.

When `RUN` or `CONT` returns control after completion, `STOP`, `BREAK`, or a
runtime error, the text screen prints the classic `READY.` line before accepting
the next command. A program ending with a semicolon is moved to a fresh line
before that prompt is printed.

The terminal environment retains the command form:

```basic
EDIT 120
```

It prints line 120 and asks for a replacement body.

## Opening and saving programs

```basic
DIR
LOAD "examples/hello.bas"
LIST
SAVE "examples/myprogram.bas"
VERIFY "examples/myprogram.bas"
```

Supplying a program to the graphical launcher now loads it automatically:

```sh
./run.sh shell programs/examples/hello.bas
```
