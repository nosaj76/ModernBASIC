10 REM ═════════════════════════════════════════════════
20 REM  LANDSCAPE PAINTING DEMO - Modern64BASIC 0.8.2
30 REM  Demonstrates: gradients, paths, bezier curves,
40 REM  circles, polygons, texture paint, blend modes
50 REM ═════════════════════════════════════════════════
60 W=800:H=600
70 SCREEN W,H,"#0a0a1a"
80 REM ── Sky gradient (top to horizon) ──
90 GRADIENT SKY,0,0,0,H*0.6,"#0a0a3a","#ffa040"
100 RECTANGLE 0,0,W,H*0.6,"none","url(#SKY)",1
110 REM ── Sun with radial gradient glow ──
120 RADIALGRADIENT SUNGLOW,560,200,120,"#ffe080","#ff800000"
130 ELLIPSE (560,200),120,120,"none","url(#SUNGLOW)",1
140 BLEND "screen"
150 CIRCLE (560,200),45,"none","#ffd060",1
160 BLEND "normal"
170 REM ── Distant mountains via PATH ──
180 M$="M 0 360 L 120 280 L 200 320 L 300 250 L 420 310 L 550 270 L 680 330 L 800 300 L 800 400 L 0 400 Z"
190 PATH M$,"#1a1a3a","#202050",1
200 REM ── Mid hills with gradient ──
210 GRADIENT HILL,0,340,0,420,"#101030","#1a2040"
220 M2$="M 0 400 L 100 340 L 250 380 L 380 330 L 520 370 L 680 340 L 800 380 L 800 500 L 0 500 Z"
230 PATH M2$,"none","url(#HILL)",1
240 REM ── Foreground field with gradient ──
250 GRADIENT FLD,0,420,0,H,"#1a3030","#0a1a10"
260 RECTANGLE 0,420,W,H-420,"none","url(#FLD)",1
270 REM ── Real trees: trunk + foliage circles ──
280 FOR I=1 TO 5
290 TX=80+I*140:TY=420
300 REM foliage - overlapping circles for organic shape
310 CR=28+I*3
320 CIRCLE (TX,TY-55),CR,"#0a2a10","#0e3a14",1
330 CIRCLE (TX-14,TY-48),CR*0.8,"#0a2a10","#0e3a14",1
340 CIRCLE (TX+14,TY-48),CR*0.8,"#0a2a10","#0e3a14",1
350 CIRCLE (TX,TY-72),CR*0.7,"#0a2a10","#0c3010",1
360 NEXT I
370 REM ── River using BEZIER curves ──
380 BEZIER 0,450,200,430,500,470,800,440,"#2060a090",4
390 BEZIER 0,455,200,435,500,475,800,445,"#3090c080",2
400 REM ── Stars in upper sky using PSET ──
410 FOR I=1 TO 40
420 SX=RND(1)*W:SY=RND(1)*150
430 PSET (SX,SY),"#ffffff"
440 NEXT I

450 REM ── Texture paint on field for grass effect ──
460 P$="M 0 420 L 800 420 L 800 600 L 0 600 Z"
470 PAINT TEXTURE P$,42,8,3,"#0a2010","#1a4020",0.5,"OVERLAY"
475 PAINT FILTER "SHARPEN",0.4
480 REM ── Title text ──
490 TEXT 20,570,20,"LANDSCAPE - PAINTED IN MODERNBASIC 0.8.2","#a0c0e0"
500 SAVEIMAGE "landscape_demo.png"
510 PRINT "Landscape painting saved to output/landscape_demo.png"
520 END
