10 REM ====================================
20 REM BASIC1 SUPER SCIENTIFIC CALCULATOR
30 REM All Dartmouth BASIC Math Functions
40 REM ====================================
50 CLS
60 PRINT "╔════════════════════════════════════════╗"
70 PRINT "║   BASIC1 SUPER CALCULATOR v1.0        ║"
80 PRINT "║   Scientific & Engineering Functions   ║"
90 PRINT "╚════════════════════════════════════════╝"
100 PRINT
110 PRINT "CATEGORIES:"
120 PRINT "  1. Basic Math (+, -, *, /, ^)"
130 PRINT "  2. Trigonometry (SIN, COS, TAN, etc.)"
140 PRINT "  3. Inverse Trig (ASIN, ACOS, ATN)"
150 PRINT "  4. Hyperbolic (SINH, COSH, TANH)"
160 PRINT "  5. Exponential & Logarithm"
170 PRINT "  6. Rounding & Special Functions"
180 PRINT "  7. Unit Conversions"
190 PRINT "  8. Constants & Quick Reference"
200 PRINT "  0. Exit"
210 PRINT
220 PRINT "Choose category (0-8): ";
230 INPUT C
240 IF C = 0 THEN 2000
241 IF C = 1 THEN GOSUB 300
250 IF C = 2 THEN GOSUB 500
260 IF C = 3 THEN GOSUB 700
270 IF C = 4 THEN GOSUB 900
280 IF C = 5 THEN GOSUB 1100
290 IF C = 6 THEN GOSUB 1300
295 IF C = 7 THEN GOSUB 1500
296 IF C = 8 THEN GOSUB 1700
297 GOTO 50
300 REM ===== BASIC MATH =====
310 CLS
320 PRINT "BASIC MATH OPERATIONS"
330 PRINT "====================="
340 PRINT
350 PRINT "Enter first number: ";
360 INPUT A
370 PRINT "Enter operation (+,-,*,/,^): ";
380 INPUT O$
390 PRINT "Enter second number: ";
400 INPUT B
410 PRINT
411 IF O$ = "+" THEN R = A + B
412 IF O$ = "-" THEN R = A - B
413 IF O$ = "*" THEN R = A * B
420 IF O$ = "/" THEN R = A / B
430 IF O$ = "^" THEN R = A ^ B
440 PRINT "RESULT: "; A; " "; O$; " "; B; " = "; R
450 PRINT
460 PRINT "Press ENTER to continue..."
470 INPUT X$
480 RETURN
500 REM ===== TRIGONOMETRY =====
510 CLS
520 PRINT "TRIGONOMETRY (Input in Radians)"
530 PRINT "================================"
540 PRINT "Tip: Use PI = 3.14159... or DEG to convert"
550 PRINT
560 PRINT "Enter angle in radians: ";
570 INPUT X
580 PRINT
581 PRINT "SIN("; X; ") = "; SIN(X)
590 PRINT "COS("; X; ") = "; COS(X)
600 PRINT "TAN("; X; ") = "; TAN(X)
610 PRINT "COT("; X; ") = "; COT(X)
620 PRINT "SEC("; X; ") = "; SEC(X)
630 PRINT "CSC("; X; ") = "; CSC(X)
640 PRINT
650 PRINT "In degrees: "; X * 180 / PI; " degrees"
660 PRINT
670 PRINT "Press ENTER to continue..."
680 INPUT X$
690 RETURN
700 REM ===== INVERSE TRIG =====
710 CLS
720 PRINT "INVERSE TRIGONOMETRY"
730 PRINT "===================="
740 PRINT "Domain: ASIN/ACOS require -1 ≤ x ≤ 1"
750 PRINT
760 PRINT "Enter value: ";
770 INPUT X
780 PRINT
781 IF X >= -1 AND X <= 1 THEN PRINT "ASIN("; X; ") = "; ASIN(X); " rad = "; ASIN(X)*180/PI; " deg"
790 IF X >= -1 AND X <= 1 THEN PRINT "ACOS("; X; ") = "; ACOS(X); " rad = "; ACOS(X)*180/PI; " deg"
800 PRINT "ATN("; X; ") = "; ATN(X); " rad = "; ATN(X)*180/PI; " deg"
810 PRINT
820 PRINT "Press ENTER to continue..."
830 INPUT X$
840 RETURN
900 REM ===== HYPERBOLIC =====
910 CLS
920 PRINT "HYPERBOLIC FUNCTIONS"
930 PRINT "===================="
940 PRINT
950 PRINT "Enter value: ";
960 INPUT X
970 PRINT
971 PRINT "SINH("; X; ") = "; SINH(X)
980 PRINT "COSH("; X; ") = "; COSH(X)
990 PRINT "TANH("; X; ") = "; TANH(X)
1000 PRINT
1010 PRINT "Identity check: COSH²-SINH² = "; COSH(X)^2 - SINH(X)^2; " (should be 1)"
1020 PRINT
1030 PRINT "Press ENTER to continue..."
1040 INPUT X$
1050 RETURN
1100 REM ===== EXPONENTIAL & LOG =====
1110 CLS
1120 PRINT "EXPONENTIAL & LOGARITHM"
1130 PRINT "======================="
1140 PRINT
1150 PRINT "Enter value: ";
1160 INPUT X
1170 PRINT
1171 PRINT "EXP("; X; ") = e^x = "; EXP(X)
1180 IF X > 0 THEN PRINT "LOG("; X; ") = ln(x) = "; LOG(X)
1190 IF X > 0 THEN PRINT "LOG10("; X; ") = "; LOG(X)/LOG(10)
1200 PRINT "SQR("; ABS(X); ") = √|x| = "; SQR(ABS(X))
1210 PRINT
1220 PRINT "Press ENTER to continue..."
1230 INPUT X$
1240 RETURN
1300 REM ===== ROUNDING =====
1310 CLS
1320 PRINT "ROUNDING & SPECIAL FUNCTIONS"
1330 PRINT "============================"
1340 PRINT
1350 PRINT "Enter value: ";
1360 INPUT X
1370 PRINT
1371 PRINT "INT("; X; ") = "; INT(X); " (floor)"
1380 PRINT "ROUND("; X; ") = "; ROUND(X)
1390 PRINT "FLOOR("; X; ") = "; FLOOR(X)
1400 PRINT "CEIL("; X; ") = "; CEIL(X)
1410 PRINT "FIX("; X; ") = "; FIX(X); " (same as INT)"
1420 PRINT "FRACTIONAL PART = "; X-FIX(X)
1430 PRINT "ABS("; X; ") = "; ABS(X); " (absolute value)"
1440 PRINT "SGN("; X; ") = "; SGN(X); " (-1, 0, or 1)"
1450 PRINT
1460 PRINT "Press ENTER to continue..."
1470 INPUT X$
1480 RETURN
1500 REM ===== CONVERSIONS =====
1510 CLS
1520 PRINT "UNIT CONVERSIONS"
1530 PRINT "================"
1540 PRINT
1550 PRINT "Enter value: ";
1560 INPUT X
1570 PRINT
1571 PRINT "RAD("; X; ") = "; RAD(X); " radians (from degrees)"
1580 PRINT "DEG("; X; ") = "; DEG(X); " degrees (from radians)"
1590 PRINT
1600 PRINT "Example: 90° = "; RAD(90); " radians"
1610 PRINT "Example: π rad = "; DEG(PI); " degrees"
1620 PRINT
1630 PRINT "Press ENTER to continue..."
1640 INPUT X$
1650 RETURN
1700 REM ===== CONSTANTS =====
1710 CLS
1720 PRINT "MATHEMATICAL CONSTANTS"
1730 PRINT "======================"
1740 PRINT
1750 PRINT "PI     = "; PI
1760 PRINT "e      = "; EXP(1)
1770 PRINT "√2     = "; SQR(2)
1780 PRINT "√3     = "; SQR(3)
1790 PRINT "φ (phi)= "; (1 + SQR(5)) / 2; " (golden ratio)"
1800 PRINT
1810 PRINT "QUICK REFERENCE:"
1820 PRINT "  sin²x + cos²x = 1"
1830 PRINT "  tan(x) = sin(x)/cos(x)"
1840 PRINT "  e^(iπ) + 1 = 0 (Euler's identity)"
1850 PRINT "  ln(e) = 1"
1860 PRINT "  log₁₀(10) = 1"
1870 PRINT
1880 PRINT "Random: RND = "; RND
1890 PRINT
1900 PRINT "Press ENTER to continue..."
1910 INPUT X$
1920 RETURN
2000 REM ===== EXIT =====
2010 CLS
2020 PRINT "Thank you for using BASIC1 Super Calculator!"
2030 PRINT
2040 END
