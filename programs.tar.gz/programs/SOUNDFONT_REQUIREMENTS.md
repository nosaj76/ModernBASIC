# Optional SoundFont requirements

The ModernBASIC runtime and all native-synthesis programs work without a
SoundFont. Programs containing an explicit `SOUNDFONT` declaration require the
named `.sf2` bank to be installed beneath the project-level `soundfont/`
directory or supplied through `--soundfont-root`.

The catalog references these optional banks:

- `MuseScore_General.sf2` - installed by `./install-soundfont.sh`.
- FreePats guitar/bass and AVL Red Zeppelin banks - installed by
  `./install-rock-soundfonts.sh` together with their licenses.
- `GeneralUser_GS.sf2` - must be supplied separately with its license.
- `Persa.sf2` - must be supplied separately with its license.
- `Guzheng_Custom.sf2` - must be supplied separately with its license.

Third-party banks with incomplete or unknown redistribution terms are not
embedded in the source archive. Keep each bank's original attribution and
license beside the installed file. The interpreter treats `soundfont/...` as a
backend instrument path, independent of the current BASIC `CD` directory.
