10 REM TEST ON ERROR GOTO
20 ON ERROR GOTO 1000
30 PRINT "Testing error handling..."
40 PRINT "Attempting division by zero:"
50 X = 1 / 0
60 PRINT "RESUME NEXT CONTINUED"
70 GOTO 1050
1000 REM Error handler
1010 PRINT "Error trapped! ERR ="; ERR
1020 PRINT "Error at line:"; ERL
1030 PRINT "Resuming after error..."
1040 RESUME NEXT
1050 PRINT "Continued successfully!"
1060 END
9999 PRINT "ERROR: Should not reach here"
