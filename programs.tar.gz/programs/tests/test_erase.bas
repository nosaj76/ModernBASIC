10 REM TEST ERASE - Array deallocation
20 DIM A(10,10)
30 PRINT "Array A(10,10) created"
40 A(5,5) = 99
50 PRINT "A(5,5) ="; A(5,5)
60 PRINT "Erasing array A..."
70 ERASE A
80 PRINT "Array A erased"
90 PRINT "Re-dimensioning A(2,2)..."
100 DIM A(2,2)
110 PRINT "New array A(2,2) created"
120 A(1,1) = 42
130 PRINT "A(1,1) ="; A(1,1)
140 END
