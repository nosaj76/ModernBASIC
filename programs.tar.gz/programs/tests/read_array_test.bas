1 REM Test READ into arrays
10 DIM A(10)
20 READ A(0), A(1), A(2)
30 DATA 10, 20, 30
40 PRINT "A(0)="; A(0); " A(1)="; A(1); " A(2)="; A(2)
50 END
