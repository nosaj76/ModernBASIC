1 REM Test if indices consume DATA
10 DIM A(10)
20 READ A(1), A(2)
30 DATA 10, 20
40 PRINT "A(1)="; A(1); " A(2)="; A(2)
50 END
