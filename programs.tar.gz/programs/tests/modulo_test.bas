10 PRINT "Testing Modulo Operator"
20 PRINT "9 MOD 100 = "; 9 MOD 100
30 END
