10 PRINT "CHAIN START"
20 CHAIN "msbasic_manual_chain_target.bas"
30 PRINT "CHAIN FAILED"
40 END
