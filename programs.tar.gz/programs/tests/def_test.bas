10 REM Test DEF (user-defined functions)
20 DEF FNA(N) = INT(N / 10) MOD 10
30 DEF FNB(X) = X * X + 1
40 PRINT "Testing DEF functions:"
50 FOR I = 1 TO 5
60   LET A = 123
70   PRINT "FNA("; A; ") = "; FNA(A)
80   PRINT "FNB("; I; ") = "; FNB(I)
90 NEXT I
100 END
