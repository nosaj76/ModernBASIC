10 REM =====================================================
20 REM   "SILICON DREAMS" — A Musical in Three Acts
30 REM   A RUSTBASIC Production
40 REM =====================================================
50 PRINT
60 PRINT "  ╔══════════════════════════════════╗"
70 PRINT "  ║                                  ║"
80 PRINT "  ║       S I L I C O N              ║"
90 PRINT "  ║         D R E A M S              ║"
100 PRINT "  ║                                  ║"
110 PRINT "  ║    A Musical in Three Acts       ║"
120 PRINT "  ║                                  ║"
130 PRINT "  ╚══════════════════════════════════╝"
140 PRINT
150 PRINT "  Press ENTER to begin..."
155 INPUT A$
160 PRINT
170 REM
180 REM ── ACT I: OVERTURE — "Boot Sequence" ──
190 REM A bright, rising theme. The machine awakens.
200 REM
210 PRINT "  ┌────────────────────────────────┐"
220 PRINT "  │  ACT I: BOOT SEQUENCE          │"
230 PRINT "  │  'The machine awakens'         │"
240 PRINT "  └────────────────────────────────┘"
250 PRINT
260 REM Rising arpeggios — power on
270 PLAY "T160 MN O3 L8 CEG O4 CE L4 G R8"
280 REM Repeat higher — systems coming alive
290 PLAY "T160 O4 L8 CEG O5 CE L4 G R8"
300 REM Fanfare — ready
310 PLAY "T140 O4 L4 C E G L2 O5 C R4"
320 REM Gentle melody — first thoughts
330 PLAY "T120 MN O4 L4 E D C D L2 E R4"
340 PLAY "T120 O4 L4 G F E D L2 C R4"
350 REM Confidence building
360 PLAY "T130 O4 L4 C E G O5 C L8 B A G F L2 E R4"
370 REM Triumphant conclusion
380 PLAY "T120 O4 L2 G L4 A B L1 O5 C"
390 PRINT "  [The machine hums to life]"
400 PRINT
410 PRINT "  Press ENTER for Act II..."
420 INPUT A$
430 REM
440 REM ── ACT II: COMPUTATION — "The Algorithm Waltz" ──
450 REM 3/4 time. Elegant. Mathematical. A dance of numbers.
460 REM
470 PRINT "  ┌────────────────────────────────┐"
480 PRINT "  │  ACT II: THE ALGORITHM WALTZ   │"
490 PRINT "  │  'A dance of numbers'          │"
500 PRINT "  └────────────────────────────────┘"
510 PRINT
520 REM Waltz theme — 3/4 feel via note grouping
530 PLAY "T144 MN O4 L4 E L8 D# E L4 B R4 L4 C"
540 PLAY "T144 O4 L4 E L8 D# E L4 B D C"
550 PLAY "T144 O3 L2 A R4"
560 REM Repeat with variation
570 PLAY "T144 O4 L4 E L8 D# E L4 B R4 L4 C"
580 PLAY "T144 O4 L4 E L8 E F L4 G A B"
590 PLAY "T144 O5 L2 C R4"
600 REM Bridge — minor key tension (the algorithm struggles)
610 PLAY "T120 O4 L4 A L8 G# A L4 O5 C O4 A"
620 PLAY "T120 O4 L4 F L8 E F L4 A F"
630 PLAY "T120 O4 L2 D R4"
640 REM Resolution — convergence achieved
650 PLAY "T132 O4 L4 G A B O5 C D E"
660 PLAY "T120 ML O4 L1 G"
670 PLAY "MN"
680 PRINT "  [Eigenvalues converge]"
690 PRINT
700 PRINT "  Press ENTER for Act III..."
710 INPUT A$
720 REM
730 REM ── ACT III: FINALE — "Recursive Dreams" ──
740 REM The machine contemplates infinity.
750 REM Grand, sweeping, then quiet and reflective.
760 REM
770 PRINT "  ┌────────────────────────────────┐"
780 PRINT "  │  ACT III: RECURSIVE DREAMS     │"
790 PRINT "  │  'Contemplating infinity'      │"
800 PRINT "  └────────────────────────────────┘"
810 PRINT
820 REM Grand opening — full power
830 PLAY "T100 ML O3 L2 C O4 C L4 E G L2 O5 C"
840 PLAY "MN"
850 PLAY "T100 O5 L4 C B A G L2 F E"
860 REM Development — the recursive descent
870 PLAY "T110 O5 L4 E D C O4 B A G F E"
880 PLAY "T110 O4 L4 E D C O3 B A G F E"
890 REM Silence... then rebirth
900 PLAY "T80 O3 L2 R R"
910 PLAY "T80 O3 L1 C"
920 REM Final theme — slow, reflective
930 PLAY "T72 O4 L4 E R8 L4 G R8 L2 A"
940 PLAY "T72 O4 L4 G R8 L4 F R8 L2 E"
950 PLAY "T72 O4 L4 E R8 L4 D R8 L2 C"
960 REM The final chord — sustained
970 PLAY "T60 ML O3 L1 C"
980 PLAY "MN"
990 PRINT
1000 PRINT "  [The machine dreams]"
1010 PRINT
1020 REM
1030 REM ── CURTAIN CALL ──
1040 REM
1050 PRINT "  ╔══════════════════════════════════╗"
1060 PRINT "  ║                                  ║"
1070 PRINT "  ║          ~ F I N ~               ║"
1080 PRINT "  ║                                  ║"
1090 PRINT "  ║  Music by RUSTBASIC MOS 6581     ║"
1100 PRINT "  ║  Libretto by Claude              ║"
1110 PRINT "  ║                                  ║"
1120 PRINT "  ╚══════════════════════════════════╝"
1130 PRINT
1140 REM Curtain call — quick happy ending
1150 PLAY "T180 O4 L8 C E G O5 C L4 R L8 O4 C E G O5 C L2 R"
1160 PLAY "T160 O5 L2 C L4 R L1 C"
1170 PRINT "  [Applause]"
1180 END
