1 REM Simple READ/DATA test
10 READ A, B, C
20 DATA 1, 2, 3
30 PRINT "A="; A; " B="; B; " C="; C
40 END
