10 REM Simple INPUT test to verify fix
20 PRINT "Testing INPUT fix..."
30 INPUT "Enter a number: "; A
40 PRINT "You entered: "; A
50 INPUT B, C
60 PRINT "B="; B; " C="; C
70 INPUT "Name: "; N$
80 PRINT "Hello "; N$
90 END
