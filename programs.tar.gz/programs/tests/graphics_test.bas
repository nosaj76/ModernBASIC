10 REM ═══════════════════════════════════════════════
20 REM  Graphics Test — Verifies pixel rendering
30 REM ═══════════════════════════════════════════════
40 SCREEN 1024, 768
50 PRINT " GRAPHICS TEST"
60 PRINT
70 REM ── Rainbow horizontal lines ──
80 FOR I=0 TO 15
90 LINE (0,I*8)-(200,I*8),I
100 NEXT I
110 REM ── Concentric circles ──
120 FOR I=1 TO 12
130 CIRCLE (512,300),I*20,I MOD 15 + 1
140 NEXT I
150 REM ── Filled rectangles ──
160 FOR I=1 TO 8
170 RECT 650,50+I*30,I*25,20,I
180 NEXT I
190 REM ── Diagonal lines ──
200 FOR I=0 TO 15
210 LINE (300,500)-(300+I*20,700),I+1
220 NEXT I
230 REM ── Pixel dots ──
240 FOR I=0 TO 100
250 PSET (RND(1)*1023,RND(1)*767),INT(RND(1)*15)+1
260 NEXT I
270 PRINT " PRESS ESC TO EXIT"
280 SCREENSHOT "graphics_test.png" : END
