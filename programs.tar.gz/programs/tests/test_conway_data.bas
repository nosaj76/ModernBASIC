10 DIM L(1,8)
20 DATA 5, 10, 1, 1, 1
30 READ G, M, L(0,3), L(1,3), L(1,2)
40 PRINT "G ="; G
50 PRINT "M ="; M
60 PRINT "L(0,3) ="; L(0,3)
70 PRINT "L(1,3) ="; L(1,3)
80 PRINT "L(1,2) ="; L(1,2)
90 END
