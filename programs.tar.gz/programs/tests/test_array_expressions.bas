10 REM Test array expressions in PRINT
20 DIM L(1,8)
30 LET L(0,3) = 42
40 LET L(1,5) = 99
50 PRINT "Test 1: L(0,3) ="; L(0,3)
60 PRINT "Test 2: L(1,5) ="; L(1,5)
70 LET X = L(0,3) + L(1,5)
80 PRINT "Test 3: Sum ="; X
90 IF L(0,3) = 42 THEN PRINT "Test 4: PASS"
100 END
