
10 PRINT "Error Handling Tests"
20 PRINT "===================="
30 PRINT "These tests SHOULD produce errors"
40 PRINT

100 PRINT "Test 1: Division by Zero"
110 PRINT "Attempting 10 / 0..."
120 PRINT 10 / 0
130 PRINT "This line should NOT print"
140 END






