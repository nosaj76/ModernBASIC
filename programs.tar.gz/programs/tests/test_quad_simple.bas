10 REM Simple QUAD test
20 DEF FNF(X) = X * X
30 PRINT "Testing QUAD integration..."
40 STATA = FNINT(X ^ 2, X, 0, 2)
50 PRINT "Integral of x^2 from 0 to 2 = "; STATA
60 PRINT "Expected: 2.666667"
70 PRINT "CURRENT FNINT INTEGRATION"
80 END
