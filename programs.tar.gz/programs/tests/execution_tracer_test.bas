10 REM EXECUTION TRACER TEST
20 REM Enable tracing to see detailed VM execution
30 PRINT "Execution Tracer Demo"
40 PRINT "====================="
50 PRINT "Run this with trace enabled to see VM internals"
60 PRINT
70 REM Simple program to trace
80 INPUT "Name: "; N$
90 FOR I = 1 TO 3
100   PRINT "Hello "; N$; " ("; I; ")"
110   SOUND 800,1,100
120 NEXT I
130 GOSUB 200
140 END
200 REM Subroutine
210 PRINT "In subroutine"
220 RETURN
