1 REM Test 5 array items like GoL line 120
10 DIM L(2, 10)
20 READ G, M, L(0,3), L(1,3), L(1,2)
30 DATA 11, 10, 1, 1, 1
40 PRINT "G="; G; " M="; M
50 PRINT "L(0,3)="; L(0,3)
60 PRINT "L(1,3)="; L(1,3)
70 PRINT "L(1,2)="; L(1,2)
80 END
