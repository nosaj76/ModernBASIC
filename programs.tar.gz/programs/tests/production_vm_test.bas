10 REM =================================================
20 REM PRODUCTION VM ARCHITECTURE TEST
30 REM Tests clean execution state, tracing, and reliability
40 REM =================================================
50 PRINT "PRODUCTION VM TEST SUITE"
60 PRINT "========================"
70 PRINT
80 REM Test 1: Basic execution flow
90 PRINT "Test 1: Basic Execution Flow"
100 FOR I = 1 TO 3
110   PRINT "Loop "; I
120 NEXT I
130 PRINT "✓ FOR/NEXT working"
140 PRINT
150 REM Test 2: INPUT state management
160 PRINT "Test 2: INPUT State Management"
170 INPUT "Enter test value: "; A
180 PRINT "You entered: "; A
190 PRINT "✓ INPUT state transitions working"
200 PRINT
210 REM Test 3: SOUND state management  
220 PRINT "Test 3: SOUND State Management"
230 SOUND 1000,1,250
240 PRINT "✓ SOUND blocking completed"
250 PRINT
260 REM Test 4: GOSUB/RETURN with clean stack
270 PRINT "Test 4: GOSUB/RETURN Stack Management"
280 GOSUB 400
290 PRINT "✓ GOSUB/RETURN working"
300 PRINT
310 REM Test 5: Complex nested execution
320 PRINT "Test 5: Complex Nested Execution"
330 FOR I = 1 TO 2
340   GOSUB 450
350   INPUT "Value for loop "; I; ": "; B
360   PRINT "Loop "; I; " value: "; B
370 NEXT I
380 PRINT "✓ Nested execution working"
390 PRINT
395 PRINT "ALL TESTS PASSED - PRODUCTION VM READY!"
396 END
400 REM Simple subroutine
410 PRINT "  -> In subroutine"
420 RETURN
450 REM Nested subroutine  
460 PRINT "  -> Nested call for loop "; I
470 RETURN
