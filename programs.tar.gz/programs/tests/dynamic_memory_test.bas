10 REM DYNAMIC MEMORY USAGE TEST
20 REM Verifies that FRE() properly decreases as memory is consumed
30 PRINT "DYNAMIC MEMORY USAGE TEST"
40 PRINT "========================"
50 PRINT
60 REM Test 1: Initial memory state
70 PRINT "Test 1: Initial Memory State"
80 LET INITIAL = FRE(0)
90 PRINT "Initial free memory: "; INITIAL; " bytes"
100 PRINT
110 REM Test 2: Memory usage by variables
120 PRINT "Test 2: Variable Memory Usage"
130 PRINT "Creating variables..."
140 FOR I = 1 TO 10
150   LET V = I * I
160   LET CURRENT = FRE(0)
170   PRINT "After var "; I; ": "; CURRENT; " bytes free"
180 NEXT I
190 PRINT
200 REM Test 3: Array memory consumption
210 PRINT "Test 3: Array Memory Usage"
220 DIM ARRAY1(50)
230 LET MA = FRE(0)
240 PRINT "After DIM ARRAY1(50): "; MA; " bytes"
250 DIM ARRAY2(20, 30)
260 LET MB = FRE(0)
270 PRINT "After DIM ARRAY2(20,30): "; MB; " bytes"
280 PRINT "Array memory used: "; MA - MB; " bytes"
290 PRINT
300 REM Test 4: String variable memory
310 PRINT "Test 4: String Memory Usage"
320 LET S1$ = "This is a short string"
330 LET S1M = FRE(0)
340 LET S2$ = "This is a much longer string that should consume more memory than the previous short string"
350 LET S2M = FRE(0)
360 PRINT "After short string: "; S1M; " bytes"
370 PRINT "After long string: "; S2M; " bytes"
380 PRINT "Long string used: "; S1M - S2M; " extra bytes"
390 PRINT
400 REM Test 5: DEF function memory
410 PRINT "Test 5: DEF Function Memory"
420 LET BD = FRE(0)
430 DEF FNA(X) = X * X + 2 * X + 1
440 DEF FNB(Y) = SIN(Y) + COS(Y) * TAN(Y)
450 LET AD = FRE(0)
460 PRINT "Before DEF functions: "; BD; " bytes"
470 PRINT "After DEF functions: "; AD; " bytes"
480 PRINT "DEF functions used: "; BD - AD; " bytes"
490 PRINT
500 REM Test 6: Memory usage summary
510 PRINT "MEMORY USAGE SUMMARY:"
520 PRINT "====================="
530 LET FINAL = FRE(0)
540 LET TU = INITIAL - FINAL
550 PRINT "Initial memory: "; INITIAL; " bytes"
560 PRINT "Final memory: "; FINAL; " bytes"
570 PRINT "Total consumed: "; TU; " bytes"
580 PRINT "Usage percentage: "; (TU * 100) / INITIAL; "%"
590 PRINT
600 REM Test 7: Verify memory is dynamic
610 PRINT "DYNAMIC BEHAVIOR TEST:"
620 PRINT "======================"
630 IF FINAL < INITIAL THEN PRINT "✓ Memory properly decreases with usage"
640 IF FINAL >= INITIAL THEN PRINT "✗ Memory reporting is still static"
650 IF TU > 0 THEN PRINT "✓ FRE() function is now dynamic"
660 IF TU = 0 THEN PRINT "✗ FRE() function is still broken"
670 PRINT
680 PRINT "Memory system status: ";
690 IF TU > 0 THEN PRINT "DYNAMIC (FIXED!)"
700 IF TU = 0 THEN PRINT "STATIC (BROKEN)"
710 END
