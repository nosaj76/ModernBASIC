10 PRINT "LinBASIC Expected-Error Tests"
20 PRINT "============================="
30 PRINT

200 PRINT "TEST B: READ exhaustion (should ERROR)"
210 PRINT "  Next line should throw ?OUT OF DATA"
220 READ A
230 READ B
240 PRINT "  FAIL (should not reach here)"
250 DATA 10
260 END

