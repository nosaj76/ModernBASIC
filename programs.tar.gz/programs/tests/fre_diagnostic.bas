10 REM Simple FRE Diagnostic Test
20 PRINT "Testing FRE function directly..."
30 PRINT "FRE(0) = "; FRE(0)
40 PRINT "FRE(1) = "; FRE(1)
50 LET X = FRE(0)
60 PRINT "Assigned to variable: "; X
70 END
