1 REM Simplified Conway's Game of Life structure
10 LET G = 5
20 FOR I = 1 TO G
30   GOSUB 100
40   IF I MOD 3 <> 2 THEN 60
50   GOSUB 200
60 NEXT I
70 PRINT "COMPLETE"
80 END
100 REM Update routine
110 PRINT "Update "; I
120 RETURN
200 REM Print routine
210 PRINT "Print "; I
220 RETURN
