10 REM Test: String Array Initialization
20 REM Tests that uninitialized string array elements are empty
30 PRINT "String Array Initialization Test"
40 PRINT "================================"
50 PRINT
100 REM Test 1: DIM'd array, no assignments
110 DIM A$(5)
120 PRINT "Test 1: DIM A$(5) - all elements should be empty"
130 FOR I = 0 TO 5
140   PRINT "  A$("; I; ") = '"; A$(I); "'"
150 NEXT I
160 PRINT
200 REM Test 2: DIM'd array, one assignment
210 DIM B$(10)
220 B$(5) = "MIDDLE"
230 PRINT "Test 2: DIM B$(10), only B$(5) assigned"
240 PRINT "  B$(0) = '"; B$(0); "' (should be empty)"
250 PRINT "  B$(3) = '"; B$(3); "' (should be empty)"
260 PRINT "  B$(5) = '"; B$(5); "' (should be 'MIDDLE')"
270 PRINT "  B$(7) = '"; B$(7); "' (should be empty)"
280 PRINT "  B$(10) = '"; B$(10); "' (should be empty)"
290 PRINT
300 REM Test 3: 2D array
310 DIM C$(3,3)
320 C$(1,1) = "CENTER"
330 PRINT "Test 3: DIM C$(3,3), only C$(1,1) assigned"
340 PRINT "  C$(0,0) = '"; C$(0,0); "' (should be empty)"
350 PRINT "  C$(0,1) = '"; C$(0,1); "' (should be empty)"
360 PRINT "  C$(1,0) = '"; C$(1,0); "' (should be empty)"
370 PRINT "  C$(1,1) = '"; C$(1,1); "' (should be 'CENTER')"
380 PRINT "  C$(2,2) = '"; C$(2,2); "' (should be empty)"
390 PRINT
400 REM Test 4: Implicit array growth
410 E$(10) = "TENTH"
420 PRINT "Test 4: E$(10) = 'TENTH' (implicit growth)"
430 PRINT "  E$(0) = '"; E$(0); "' (should be empty)"
440 PRINT "  E$(5) = '"; E$(5); "' (should be empty)"
450 PRINT "  E$(10) = '"; E$(10); "' (should be 'TENTH')"
460 PRINT
500 REM Test 5: Overwrite test
510 DIM F$(5)
520 F$(0) = "FIRST"
530 F$(1) = "SECOND"
540 F$(2) = "THIRD"
550 PRINT "Test 5: Multiple assignments"
560 PRINT "  F$(0) = '"; F$(0); "' (should be 'FIRST')"
570 PRINT "  F$(1) = '"; F$(1); "' (should be 'SECOND')"
580 PRINT "  F$(2) = '"; F$(2); "' (should be 'THIRD')"
590 PRINT "  F$(3) = '"; F$(3); "' (should be empty)"
600 PRINT "  F$(4) = '"; F$(4); "' (should be empty)"
610 PRINT "  F$(5) = '"; F$(5); "' (should be empty)"
620 PRINT
900 PRINT "================================"
910 PRINT "Test Complete!"
920 PRINT
930 PRINT "Expected Results:"
940 PRINT "  - All unassigned elements should show ''"
950 PRINT "  - Assigned elements should show their values"
960 PRINT "  - No element should show garbage or wrong values"
970 END
