10 REM TEST MAT INV - Matrix Inversion
20 REM Test with a simple 2x2 matrix
30 DIM A(2,2), B(2,2), C(2,2)
40 REM Matrix A = [[4, 7], [2, 6]]
50 DATA 4,7,2,6
60 MAT READ A
70 PRINT "Original Matrix A:"
80 MAT PRINT A
90 REM Compute inverse
100 MAT B = INV(A)
110 PRINT "Inverse Matrix B:"
120 MAT PRINT B
130 REM Verify: A * B should equal identity
140 MAT C = A * B
150 PRINT "A * INV(A) (should be identity):"
160 MAT PRINT C
170 END
