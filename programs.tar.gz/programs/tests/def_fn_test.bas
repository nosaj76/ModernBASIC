1 REM Test DEF FN like Conway uses
10 DIM A(5,5)
20 DEF FNA(N) = INT(N / 10) MOD 10
30 LET A(2,2) = 123
40 LET X = 2
50 LET Y = 2
60 LET R = FNA(A(X,Y))
70 PRINT "A(2,2) = "; A(2,2)
80 PRINT "FNA(A(2,2)) = "; R
90 END
