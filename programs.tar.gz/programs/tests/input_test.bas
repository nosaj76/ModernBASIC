10 REM Simple INPUT test
20 PRINT "What's your name?"
30 INPUT N$
40 PRINT "Hello, "; N$
50 PRINT "Enter a number:"
60 INPUT X
70 PRINT "Your number doubled is "; X * 2
80 END
