1 REM test_chain_b.bas - Second program
10 PRINT "Program B running..."
20 PRINT "X from Program A ="; X
30 PRINT "Chain complete!"
40 END
