1 REM Test nested FOR loops
10 FOR I = 1 TO 3
20   GOSUB 100
30   IF I MOD 3 <> 2 THEN 50
40   PRINT "Special case"
50 NEXT I
60 PRINT "DONE"
70 END
100 REM Subroutine with nested loops
110 FOR Y = 1 TO 2
120   FOR X = 1 TO 2
130     PRINT "I="; I; " Y="; Y; " X="; X
140   NEXT X
150 NEXT Y
160 RETURN
