1 REM Test CONT functionality
10 PRINT "Before STOP"
20 LET X = 42
30 STOP
40 PRINT "After CONT, X ="; X
50 END
