10 REM TEST FILE I/O
20 PRINT "Testing file output..."
30 OPEN "test.txt" FOR OUTPUT AS #1
40 PRINT #1, "Line 1: Hello"
50 PRINT #1, "Line 2: World"
60 PRINT #1, "Line 3: BASIC"
70 CLOSE #1
80 PRINT "File written successfully"
90 PRINT
100 PRINT "Testing file input..."
110 OPEN "test.txt" FOR INPUT AS #1
120 INPUT #1, A$
130 PRINT "Read: "; A$
140 INPUT #1, B$
150 PRINT "Read: "; B$
160 INPUT #1, C$
170 PRINT "Read: "; C$
180 CLOSE #1
190 PRINT "File read successfully"
200 END
