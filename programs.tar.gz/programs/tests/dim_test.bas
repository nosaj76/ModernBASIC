1 REM Test DIM semantics
10 DIM L(1,8)
20 PRINT "DIM L(1,8) created"
30 LET L(0,3) = 1
40 PRINT "L(0,3) = "; L(0,3)
50 LET L(1,8) = 2
60 PRINT "L(1,8) = "; L(1,8)
70 LET L(1,3) = 3
80 PRINT "L(1,3) = "; L(1,3)
90 END
