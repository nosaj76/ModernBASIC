
10 PRINT "String Array Test Suite"
20 PRINT "======================="
30 PRINT

100 PRINT "Test 1: Basic 1D String Array"
110 DIM A$(5)
120 A$(0) = "HELLO"
130 A$(1) = "WORLD"
140 A$(2) = "FROM"
150 A$(3) = "LINBASIC"
160 PRINT "A$(0) = "; A$(0)
170 PRINT "A$(1) = "; A$(1)
180 PRINT "A$(2) = "; A$(2)
190 PRINT "A$(3) = "; A$(3)
200 PRINT

300 PRINT "Test 2: 2D String Array"
310 DIM B$(2,2)
320 B$(0,0) = "A"
330 B$(0,1) = "B"
340 B$(1,0) = "C"
350 B$(1,1) = "D"
360 PRINT "B$(0,0) = "; B$(0,0)
370 PRINT "B$(0,1) = "; B$(0,1)
380 PRINT "B$(1,0) = "; B$(1,0)
390 PRINT "B$(1,1) = "; B$(1,1)
400 PRINT

500 PRINT "Test 3: Namespace Separation"
510 DIM X(3), X$(3)
520 X(1) = 42
530 X$(1) = "TEXT"
540 PRINT "X(1) =  "; X(1); " (numeric)"
550 PRINT "X$(1) = "; X$(1); " (string)"
560 PRINT

600 PRINT "Test 4: Unset Elements"
610 DIM C$(5)
620 C$(2) = "SET"
630 PRINT "C$(0) = '"; C$(0); "' (should be empty)"
640 PRINT "C$(2) = '"; C$(2); "' (should be 'SET')"
650 PRINT

700 PRINT "Test 5: String Arrays in Loops"
710 DIM D$(3)
720 FOR I = 0 TO 3
730   D$(I) = "ITEM"
740 NEXT I
750 FOR I = 0 TO 3
760   PRINT "D$("; I; ") = "; D$(I)
770 NEXT I
780 PRINT

800 PRINT "Test 6: Implicit String Array Growth"
810 E$(0) = "FIRST"
820 E$(5) = "SIXTH"
830 E$(10) = "ELEVENTH"
840 PRINT "E$(0) =  "; E$(0)
850 PRINT "E$(5) =  "; E$(5)
860 PRINT "E$(10) = "; E$(10)
870 PRINT

900 PRINT "======================="
910 PRINT "All Tests Complete!"
920 END
