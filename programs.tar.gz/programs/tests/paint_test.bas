10 REM ═══════════════════════════════════════════════
20 REM  Paint/Flood Fill Test
30 REM  (requires PAINT command patch)
40 REM ═══════════════════════════════════════════════
50 SCREEN 1024, 768
60 PRINT " PAINT TEST"
70 REM ── Draw a house outline ──
80 LINE (400,500)-(600,500),1
90 LINE (600,500)-(600,350),1
100 LINE (600,350)-(500,250),1
110 LINE (500,250)-(400,350),1
120 LINE (400,350)-(400,500),1
130 REM ── Fill the walls ──
140 PAINT (500,400),7
150 REM ── Fill the roof ──
160 PAINT (500,300),4
170 REM ── Draw a door ──
180 RECT 470,400,60,100,3
190 REM ── Draw windows ──
200 RECT 420,370,40,40,14
210 RECT 540,370,40,40,14
220 PRINT " PRESS ESC TO EXIT"
230 SCREENSHOT "paint_test.png" : END
