1 REM test_chain_a.bas - First program
10 PRINT "Program A starting..."
20 X = 42
30 PRINT "X ="; X
40 PRINT "Chaining to Program B..."
50 COMMON X : CHAIN "test_chain_b.bas"
