10 PRINT "LinBASIC Expected-Error Tests"
20 PRINT "============================="
30 PRINT

100 PRINT "TEST A: DIM after implicit use (should ERROR)"
110 LET Q(2) = 5
120 PRINT "  Next line should throw ?REDIMENSIONED ARRAY"
130 DIM Q(10)
140 PRINT "  FAIL (should not reach here)"
150 END

