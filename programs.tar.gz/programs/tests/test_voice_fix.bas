10 REM Test voice routing fix
20 VOICE 2
30 PLAY "C4 D4 E4"
40 PRINT "Test complete"
