1 REM Test Conway's update loop structure
10 DIM A(5,5)
20 DEF FNA(N) = INT(N / 10) MOD 10
30 LET M = 3
40 REM Initialize some values
50 LET A(2,2) = 1
60 GOSUB 100
70 PRINT "DONE"
80 END
100 REM Update routine (simplified Conway)
110 FOR Y = 1 TO M
120   FOR X = 1 TO M
130     LET A(X,Y) = 10 * A(X,Y)
140   NEXT X
150 NEXT Y
160 FOR Y = 1 TO M
170   FOR X = 1 TO M
180     LET N1 = FNA(A(X,Y))
190     PRINT "X="; X; " Y="; Y; " N1="; N1
200   NEXT X
210 NEXT Y
220 RETURN
