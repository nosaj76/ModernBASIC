
10 PRINT "Array Test Suite"
20 PRINT "================"
30 PRINT

100 PRINT "Test 1: 2D Array Write/Read"
105 DIM B(3,4)
110 LET B(3,4) = 99
120 PRINT "Set B(3,4) = 99"
130 PRINT "Read B(3,4) = "; B(3,4)
140 IF B(3,4) = 99 THEN 145
142 PRINT "FAIL": GOTO 150
145 PRINT "PASS"
150 PRINT

200 PRINT "Test 2: Array Growth"
210 LET A(5) = 42
220 PRINT "Set A(5) = 42"
230 LET A(10) = 100
240 PRINT "Set A(10) = 100"
250 PRINT "A(5) = "; A(5)
260 PRINT "A(10) = "; A(10)
270 IF A(5) = 42 THEN 275
272 PRINT "FAIL": GOTO 280
275 PRINT "PASS"
280 PRINT

300 PRINT "Test 3: Unset Elements"
310 LET C(5,5) = 99
320 PRINT "Set C(5,5) = 99"
330 PRINT "C(5,5) = "; C(5,5)
340 PRINT "C(0,0) = "; C(0,0); " (should be 0)"
350 IF C(0,0) = 0 THEN 355
352 PRINT "FAIL": GOTO 360
355 PRINT "PASS"
360 PRINT

400 PRINT "Test 4: DIM Array"
410 DIM D(10,10)
420 LET D(5,5) = 55
430 PRINT "Set D(5,5) = 55"
440 PRINT "D(5,5) = "; D(5,5)
450 IF D(5,5) = 55 THEN 455
452 PRINT "FAIL": GOTO 460
455 PRINT "PASS"
460 PRINT

500 PRINT "Test 5: Matrix in Loops"
510 DIM M(2,2)
520 FOR I = 0 TO 2
530   FOR J = 0 TO 2
540     LET M(I,J) = I * 10 + J
550   NEXT J
560 NEXT I
570 PRINT "M(0,0) = "; M(0,0); " (expect 0)"
580 PRINT "M(1,2) = "; M(1,2); " (expect 12)"
590 PRINT "M(2,1) = "; M(2,1); " (expect 21)"
600 IF M(1,2) = 12 THEN 605
602 PRINT "FAIL": GOTO 610
605 PRINT "PASS"
610 PRINT

700 PRINT "Test 6: Matrix Multiply"
710 DIM AA(1,1), BB(1,1), CC(1,1)
720 REM Set up 2x2 matrices
730 LET AA(0,0) = 1
740 LET AA(0,1) = 2
750 LET AA(1,0) = 3
760 LET AA(1,1) = 4
770 LET BB(0,0) = 2
780 LET BB(0,1) = 0
790 LET BB(1,0) = 1
800 LET BB(1,1) = 2
810 REM Multiply: C = A * B
820 FOR I = 0 TO 1
830   FOR J = 0 TO 1
840     LET CC(I,J) = 0
850     FOR K = 0 TO 1
860       LET CC(I,J) = CC(I,J) + AA(I,K) * BB(K,J)
870     NEXT K
880   NEXT J
890 NEXT I
900 PRINT "C(0,0) = "; CC(0,0); " (expect 4)"
910 PRINT "C(0,1) = "; CC(0,1); " (expect 4)"
920 PRINT "C(1,0) = "; CC(1,0); " (expect 10)"
930 PRINT "C(1,1) = "; CC(1,1); " (expect 8)"
940 IF CC(0,0) = 4 AND CC(0,1) = 4 AND CC(1,0) = 10 AND CC(1,1) = 8 THEN 945
942 PRINT "FAIL": GOTO 950
945 PRINT "PASS"
950 PRINT

1000 PRINT "================"
1010 PRINT "All Tests Done!"
1020 END
