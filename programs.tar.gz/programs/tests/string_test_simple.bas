1 REM Test with explicit LET keyword
10 DIM A$(5)
20 LET A$(0) = "HELLO"
30 PRINT A$(0)
40 END
