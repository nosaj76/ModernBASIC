1 REM Test DATA collection
10 PRINT "About to read 7 values"
20 READ A, B, C, D, E, F, G
30 DATA 1, 2, 3, 4, 5, 6, 7
40 PRINT "A="; A; " B="; B; " C="; C
50 PRINT "D="; D; " E="; E; " F="; F; " G="; G
60 END
