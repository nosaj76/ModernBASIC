10 REM COMPREHENSIVE INPUT LINE ADVANCEMENT TEST
20 REM This test verifies INPUT doesn't cause infinite loops
30 PRINT "=== INPUT LINE ADVANCEMENT TEST ==="
40 PRINT
50 PRINT "Test 1: Simple INPUT followed by next line"
60 INPUT "Enter 1: "; A
70 PRINT "You entered: "; A; " (should show once)"
80 PRINT
90 PRINT "Test 2: Multiple INPUTs in sequence"
100 INPUT "Enter 2: "; B
110 INPUT "Enter 3: "; C
120 PRINT "B="; B; " C="; C
130 PRINT
140 PRINT "Test 3: INPUT in difficulty selection pattern"
150 PRINT "SELECT TEST LEVEL: 1=EASY 2=HARD"
160 INPUT LEVEL
170 IF LEVEL=1 THEN PRINT "EASY MODE SELECTED"
180 IF LEVEL=2 THEN PRINT "HARD MODE SELECTED"
190 PRINT
200 PRINT "=== ALL TESTS COMPLETE ==="
210 PRINT "If you see this without infinite loops, INPUT is fixed!"
220 END
