10 REM Test COT and P functions
15 P = 3.141592653589793
20 PRINT "Testing COT function:"
30 PRINT "COT(45 degrees) = "; COT(45 * P / 180)
40 REM EXPLICIT DEGREE CONVERSION
50 PRINT "COT(45 * P / 180) in DEG mode = "; COT(45 * P / 180)
60 REM RADIANS ARE EXPLICIT
70 PRINT "COT(P/4) IN RAD MODE = "; COT(P / 4)
80 PRINT
90 PRINT "Testing P constant:"
100 PRINT "PI = "; P
110 PRINT "2 * P = "; 2 * P
120 PRINT "Circumference of circle (r=5) = "; 2 * P * 5
130 PRINT
140 PRINT "Testing COT trigonometric identity:"
150 PRINT "COT(30 * P / 180) * TAN(30 * P / 180) should equal 1:"
160 REM EXPLICIT DEGREE CONVERSION
170 PRINT "COT(30 DEG) * TAN(30 DEG) = "; COT(30 * P / 180) * TAN(30 * P / 180)
180 PRINT
190 PRINT "Testing COT = COS/SIN:"
200 PRINT "COT(60 DEG) = "; COT(60 * P / 180)
210 PRINT "COS(60 DEG) / SIN(60 DEG) = "; COS(60 * P / 180) / SIN(60 * P / 180)
220 PRINT
230 PRINT "Testing COT division by zero:"
240 ON ERROR GOTO 260
250 PRINT "COT(0) = "; COT(0)
260 PRINT "Error caught: Division by zero at COT(0)"
270 PRINT
280 PRINT "All tests completed!"
