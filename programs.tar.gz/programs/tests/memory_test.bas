10 REM MEMORY FUNCTIONS TEST
20 REM Tests FRE, PEEK, and POKE functions
30 PRINT "MEMORY FUNCTIONS TEST"
40 PRINT "===================="
50 PRINT
60 REM Test 1: FRE function (reports available memory)
70 PRINT "Test 1: FRE Function"
80 PRINT "Free memory: "; FRE(0); " bytes"
90 PRINT "Expected: 65536 bytes"
100 PRINT
110 REM Test 2: POKE and PEEK (write and read memory)
120 PRINT "Test 2: POKE and PEEK"
130 PRINT "Writing values to memory locations..."
140 POKE 1000, 42
150 POKE 1001, 123
160 POKE 1002, 255
170 PRINT "Reading back values:"
180 PRINT "Memory[1000] = "; PEEK(1000); " (should be 42)"
190 PRINT "Memory[1001] = "; PEEK(1001); " (should be 123)"  
200 PRINT "Memory[1002] = "; PEEK(1002); " (should be 255)"
210 PRINT
220 REM Test 3: Memory bounds checking
230 PRINT "Test 3: Memory Bounds"
240 PRINT "Testing safe memory locations:"
250 FOR I = 100 TO 105
260   POKE I, I MOD 256
270   PRINT "Memory["; I; "] = "; PEEK(I)
280 NEXT I
290 PRINT
300 REM Test 4: FRE with different parameters
310 PRINT "Test 4: FRE with parameters"
320 PRINT "FRE(0) = "; FRE(0)
330 PRINT "FRE(1) = "; FRE(1)  
340 PRINT "FRE(123) = "; FRE(123)
350 PRINT "(All should report 65536 in this implementation)"
360 PRINT
370 PRINT "MEMORY TEST SUMMARY:"
380 PRINT "==================="
390 IF FRE(0) = 65536 THEN PRINT "✓ FRE function working"
400 IF PEEK(1000) = 42 THEN PRINT "✓ POKE/PEEK working"
410 PRINT
420 PRINT "Memory system status: ";
430 IF FRE(0) = 65536 AND PEEK(1000) = 42 THEN PRINT "WORKING"
440 IF FRE(0) <> 65536 OR PEEK(1000) <> 42 THEN PRINT "PROBLEMS"
450 END
