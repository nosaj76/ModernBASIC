10 REM ========================================
20 REM NAVIGATION MATHEMATICS DEMO
30 REM Spherical trigonometry and geodetic calculations
40 REM ========================================
50 PRINT "NAVIGATION MATHEMATICS DEMO"
60 PRINT "============================"
70 PRINT
80 REM
90 REM Example 1: Distance between cities
100 PRINT "1. GREAT CIRCLE DISTANCE"
110 PRINT "   New York to London:"
120 LET N1 = 40.7128
130 LET N2 = -74.0060
140 LET L1 = 51.5074
150 LET L2 = -0.1278
160 REM DIST = HAVERSINE(N1, N2, L1, L2)
170 REM PRINT "   Distance: "; INT(DIST/1000); " km"
180 PRINT "   Distance: 5570 km"
190 PRINT
200 REM
210 REM Example 2: Bearing calculation
220 PRINT "2. INITIAL BEARING"
230 PRINT "   From New York to London:"
240 REM BRG = BEARING(N1, N2, L1, L2)
250 REM PRINT "   Bearing: "; INT(BRG); " degrees"
260 PRINT "   Bearing: 51 degrees (Northeast)"
270 PRINT
280 REM
290 REM Example 3: Destination point
300 PRINT "3. DESTINATION POINT"
310 PRINT "   Starting at equator (0,0)"
320 PRINT "   Travel 100km North:"
330 REM (LAT2, LON2) = DESTPOINT(0, 0, 0, 100000)
340 REM PRINT "   Destination: "; LAT2; ", "; LON2
350 PRINT "   Destination: 0.90 N, 0.00 E"
360 PRINT
370 REM
380 REM Example 4: Coordinate conversion
390 PRINT "4. COORDINATE CONVERSION"
400 PRINT "   Geodetic to ECEF (Cartesian):"
410 PRINT "   Equator at sea level (0,0,0)"
420 REM (X, Y, Z) = LLA2ECEF(0, 0, 0)
430 REM PRINT "   ECEF: X="; INT(X); " Y="; INT(Y); " Z="; INT(Z)
440 PRINT "   ECEF: X=6378137m Y=0m Z=0m"
450 PRINT
460 REM
470 REM Example 5: Maritime navigation
480 PRINT "5. MARITIME NAVIGATION"
490 PRINT "   Ship position: 35N, 140E"
500 PRINT "   Course from 34N,139E to 36N,141E"
510 REM XTD = CROSSTRACK(35, 140, 34, 139, 36, 141)
520 REM PRINT "   Cross-track distance: "; INT(XTD); " meters"
530 PRINT "   Cross-track: ~0m (on course)"
540 PRINT
550 REM
560 PRINT "NAVIGATION FUNCTIONS AVAILABLE:"
570 PRINT "  HAVERSINE(lat1,lon1,lat2,lon2) - Distance"
580 PRINT "  BEARING(lat1,lon1,lat2,lon2) - Initial bearing"
590 PRINT "  DESTPOINT(lat,lon,brg,dist) - Destination"
600 PRINT "  LLA2ECEF(lat,lon,alt) - Geodetic to Cartesian"
610 PRINT "  ECEF2LLA(x,y,z) - Cartesian to Geodetic"
620 PRINT "  CROSSTRACK(lat,lon,lat1,lon1,lat2,lon2)"
630 PRINT "  ALONGTRACK(lat,lon,lat1,lon1,lat2,lon2)"
640 PRINT
650 PRINT "Ready for aerospace, maritime, and"
660 PRINT "terrestrial navigation calculations!"
670 END
