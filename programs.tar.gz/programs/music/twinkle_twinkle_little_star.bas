10 REM TWINKLE, TWINKLE, LITTLE STAR - TRADITIONAL MELODY
20 TEMPO 104
30 LYRICS$="Twin-kle twin-kle lit-tle star How I won-der what you are Up a-bove the world so high Like a dia-mond in the sky Twin-kle twin-kle lit-tle star How I won-der what you are"
40 NOTES$="C4/4@96 C4/4@96 G4/4@108 G4/4@108 A4/4@112 A4/4@112 G4/2@104 R/4 F4/4@100 F4/4@100 E4/4@96 E4/4@96 D4/4@92 D4/4@92 C4/2@88 R/4 G4/4@100 G4/4@100 F4/4@98 F4/4@98 E4/4@94 E4/4@94 D4/2@90 R/4 G4/4@100 G4/4@100 F4/4@98 F4/4@98 E4/4@94 E4/4@94 D4/2@90 R/4 C4/4@96 C4/4@96 G4/4@108 G4/4@108 A4/4@112 A4/4@112 G4/2@104 R/4 F4/4@100 F4/4@100 E4/4@96 E4/4@96 D4/4@92 D4/4@92 C4/2@84"
50 PRINT "Singing Twinkle, Twinkle, Little Star..."
60 SING LYRICS$,NOTES$,1,.82,"en-us","WAIT"
70 END
