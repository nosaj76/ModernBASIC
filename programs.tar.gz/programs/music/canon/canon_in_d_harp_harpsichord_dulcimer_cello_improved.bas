10 REM ============================================================
20 REM  PACHELBEL CANON IN D - HARP LEAD ENSEMBLE
30 REM  HARP LEAD, HARPSICHORD RHYTHM, DULCIMER CHIME SUPPORT, CELLO
40 REM  Composed by Johann Pachelbel, ca. 1680-1706, Public Domain
50 REM  Reorchestrated for ModernBASIC
60 REM  Four distinct musical roles - no doubled competing lead
70 REM  Fourteen 16-beat cycles plus a 4-beat final cadence
80 REM  Every voice is synchronized to exactly 228 beats
90 REM ============================================================
100 CLEAR
110 TEMPO 86
120 VOL .78
130 REM ONE FLOWING PULSE; DENSITY CREATES THE RISE AND FALL
140 REM ============================================================
150 REM === VOICE 1: HARP - THE ONLY LEAD ===
160 VOICE 1
170 INSTRUMENT 1,"HARP"
180 VOL 1,.38
190 STEREO 1,-.25
200 REM Cycles 1-2: clear lyrical opening
210 PLAY "F#5:2 E5:2 D5:2 C#5:2 B4:2 A4:2 B4:2 C#5:2 D5:2 C#5:2 B4:2 A4:2 G4:2 F#4:2 G4:2 E4:2"
220 REM Cycles 3-4: the line opens outward
230 PLAY "D4:1 F#4:1 A4:1 G4:1 F#4:1 D4:1 F#4:1 E4:1 D4:1 B3:1 D4:1 A4:1 G4:1 B4:1 A4:1 G4:1 F#4:1 D4:1 E4:1 C#5:1 D5:1 F#5:1 A5:1 A4:1 B4:1 G4:1 A4:1 F#4:1 D4:1 D5:1 D5:1.5 C#5:0.5"
240 REM Cycle 5: flowing bridge
250 PLAY "D5:0.5 C#5:0.5 D5:0.5 D4:0.5 C#4:0.5 A4:0.5 E4:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 B4:0.5 C#5:0.5 F#5:0.5 A5:0.5 B5:0.5 G5:0.5 F#5:0.5 E5:0.5 G5:0.5 F#5:0.5 E5:0.5 D5:0.5 C#5:0.5 B4:0.5 A4:0.5 G4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 E4:0.5"
260 REM Cycles 6-7: broad central melody
270 PLAY "F#4:1 F#5:1 E5:1.75 R:1.25 D5:1 F#5:2 B5:2 A5:2 B5:2 C#6:2 D6:1 D5:1 C#5:1.75 R:1.25 B4:1 D5:2 D5:3 D5:1 D5:1 G5:1 E5:1 A5:1"
280 REM Cycle 8: first quick variation
290 PLAY "A5:0.5 F#5:0.25 G5:0.25 A5:0.5 F#5:0.25 G5:0.25 A5:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 G5:0.25 F#5:0.5 D5:0.25 E5:0.25 F#5:0.5 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 A4:0.25 G4:0.25 A4:0.25 F#4:0.25 G4:0.25 A4:0.25 G4:0.5 B4:0.25 A4:0.25 G4:0.5 F#4:0.25 E4:0.25 F#4:0.25 E4:0.25 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 G4:0.5 B4:0.25 A4:0.25 B4:0.5 C#5:0.25 D5:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 G5:0.25 A5:0.25"
300 REM Cycle 9: second quick variation
310 PLAY "F#5:0.5 D5:0.25 E5:0.25 F#5:0.5 E5:0.25 D5:0.25 E5:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 E5:0.25 D5:0.25 C#5:0.25 D5:0.5 B4:0.25 C#5:0.25 D5:0.5 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 F#4:0.25 E4:0.25 F#4:0.25 D5:0.25 C#5:0.25 D5:0.25 B4:0.5 D5:0.25 C#5:0.25 B4:0.5 A4:0.25 G4:0.25 A4:0.25 G4:0.25 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 B4:0.5 D5:0.25 C#5:0.25 D5:0.5 C#5:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 D5:0.25 C#5:0.25 D5:0.25 B4:0.25 C#5:0.25"
320 REM Cycles 10-11: space and breath after the peak
330 PLAY "D5:1 R:1 C#5:1 R:1 B4:1 R:1 D5:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1 R:1 A4:1 R:1 A4:1 R:1 F#4:1 R:1 A4:1 R:1 G4:1 R:1 F#4:1 R:1 G4:1 R:1 E5:1"
340 REM Cycle 12: intimate return
350 PLAY "F#5:0.5 F#4:0.5 G4:0.5 F#4:0.5 E4:0.5 E5:0.5 F#5:0.5 E5:0.5 D5:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 A3:0.5 G3:0.5 A3:0.5 B3:0.5 B4:0.5 A4:0.5 B4:0.5 A4:0.5 A3:0.5 G3:0.5 A3:0.5 D4:0.5 B4:0.5 A4:0.5 B4:0.5 C#5:0.5 C#4:0.5 B3:0.5 C#4:0.5"
360 REM Cycle 13: concise recapitulation
370 PLAY "F#5:1 E5:1 D5:1 C#5:1 B4:1 A4:1 B4:1 C#5:1 D5:1 C#5:1 B4:1 A4:1 G4:1 F#4:1 G4:1 E4:1"
380 REM Cycle 14: harp cadence remains in the spotlight
390 PLAY "D4:1 F#4:1 A4:1 D5:1 F#5:1 D5:1 A4:1 F#4:1 G4:1 B4:1 D5:1 G5:1 A4:1 C#5:1 E5:1 A5:1"
400 PLAY "D5:4"
410 REM ============================================================
420 REM === VOICE 2: HARPSICHORD - RHYTHMIC ENGINE ===
430 VOICE 2
440 INSTRUMENT 2,"HARPSICHORD"
450 VOL 2,.25
460 STEREO 2,.30
470 REM Cycles 1-2: clipped chord pulses under the harp
480 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
490 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
500 REM Cycle 3: lighter two-note continuo
510 PLAY "D4:1 A4:1 C#4:1 A4:1 B3:1 F#4:1 C#4:1 F#4:1 B3:1 G4:1 A3:1 F#4:1 B3:1 G4:1 C#4:1 E4:1"
520 REM Cycle 4: pulse returns and gathers energy
530 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
540 REM Cycles 5-9: continuous rolling rhythm drives the center
550 PLAY "D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 E4:0.5 A4:0.5 C#5:0.5 A4:0.5 D4:0.5 F#4:0.5 B4:0.5 F#4:0.5 C#4:0.5 F#4:0.5 A4:0.5 F#4:0.5 D4:0.5 G4:0.5 B4:0.5 G4:0.5 D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 D4:0.5 G4:0.5 B4:0.5 G4:0.5 E4:0.5 A4:0.5 C#5:0.5 A4:0.5"
560 PLAY "A4:0.5 F#4:0.5 D4:0.5 F#4:0.5 C#5:0.5 A4:0.5 E4:0.5 A4:0.5 B4:0.5 F#4:0.5 D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 C#4:0.5 F#4:0.5 B4:0.5 G4:0.5 D4:0.5 G4:0.5 A4:0.5 F#4:0.5 D4:0.5 F#4:0.5 B4:0.5 G4:0.5 D4:0.5 G4:0.5 C#5:0.5 A4:0.5 E4:0.5 A4:0.5"
570 PLAY "D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 E4:0.5 A4:0.5 C#5:0.5 A4:0.5 D4:0.5 F#4:0.5 B4:0.5 F#4:0.5 C#4:0.5 F#4:0.5 A4:0.5 F#4:0.5 D4:0.5 G4:0.5 B4:0.5 G4:0.5 D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 D4:0.5 G4:0.5 B4:0.5 G4:0.5 E4:0.5 A4:0.5 C#5:0.5 A4:0.5"
580 PLAY "A4:0.5 F#4:0.5 D4:0.5 F#4:0.5 C#5:0.5 A4:0.5 E4:0.5 A4:0.5 B4:0.5 F#4:0.5 D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 C#4:0.5 F#4:0.5 B4:0.5 G4:0.5 D4:0.5 G4:0.5 A4:0.5 F#4:0.5 D4:0.5 F#4:0.5 B4:0.5 G4:0.5 D4:0.5 G4:0.5 C#5:0.5 A4:0.5 E4:0.5 A4:0.5"
590 PLAY "D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 E4:0.5 A4:0.5 C#5:0.5 A4:0.5 D4:0.5 F#4:0.5 B4:0.5 F#4:0.5 C#4:0.5 F#4:0.5 A4:0.5 F#4:0.5 D4:0.5 G4:0.5 B4:0.5 G4:0.5 D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 D4:0.5 G4:0.5 B4:0.5 G4:0.5 E4:0.5 A4:0.5 C#5:0.5 A4:0.5"
600 REM Cycles 10-13: thin the rhythm so the harp can breathe
610 PLAY "A4:0.5 F#4:0.5 D4:0.5 F#4:0.5 C#5:0.5 A4:0.5 E4:0.5 A4:0.5 B4:0.5 F#4:0.5 D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 C#4:0.5 F#4:0.5 B4:0.5 G4:0.5 D4:0.5 G4:0.5 A4:0.5 F#4:0.5 D4:0.5 F#4:0.5 B4:0.5 G4:0.5 D4:0.5 G4:0.5 C#5:0.5 A4:0.5 E4:0.5 A4:0.5"
620 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
630 PLAY "D4:1 A4:1 C#4:1 A4:1 B3:1 F#4:1 C#4:1 F#4:1 B3:1 G4:1 A3:1 F#4:1 B3:1 G4:1 C#4:1 E4:1"
640 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
650 REM Cycle 14 and final chord: gather into the tonic
660 PLAY "D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 E4:0.5 A4:0.5 C#5:0.5 A4:0.5 D4:0.5 F#4:0.5 B4:0.5 F#4:0.5 C#4:0.5 F#4:0.5 A4:0.5 F#4:0.5 D4:0.5 G4:0.5 B4:0.5 G4:0.5 D4:0.5 F#4:0.5 A4:0.5 F#4:0.5 D4:0.5 G4:0.5 B4:0.5 G4:0.5 E4:0.5 A4:0.5 C#5:0.5 A4:0.5"
670 PLAY "D4:1 F#4:1 A4:1 D5:1"
680 REM ============================================================
690 REM === VOICE 3: DULCIMER - CHIMING AUGMENTATION ===
700 VOICE 3
710 INSTRUMENT 3,"DULCIMER"
720 VOL 3,.16
730 STEREO 3,.12
740 REM Cycle 1: enter late so the harp owns the opening
750 PLAY "R:8 A5:1 R:1 F#6:1 R:1 G5:1 R:1 E6:1 R:1"
760 REM Cycles 2-4: isolated harmonic glints
770 PLAY "R:1 D6:1 R:1 A5:1 R:1 B5:1 R:1 F#6:1 R:1 G6:1 R:1 D6:1 R:1 E6:1 R:1 C#6:1"
780 PLAY "D6:1 R:1 A5:1 R:1 C#6:1 R:1 A5:1 R:1 D6:1 R:1 B5:1 R:1 C#6:1 R:1 A5:1 R:1"
790 PLAY "G5:1 R:1 D6:1 R:1 A5:1 R:1 F#6:1 R:1 G5:1 R:1 D6:1 R:1 E6:1 R:1 C#6:1 R:1"
800 REM Cycle 5: dotted sparkle prepares the rise
810 PLAY "D6:0.5 R:0.5 C#6:0.5 R:0.5 D6:0.5 R:0.5 A5:0.5 R:0.5 B5:0.5 R:0.5 F#6:0.5 R:0.5 E6:0.5 R:0.5 C#6:0.5 R:0.5 D6:0.5 R:0.5 F#6:0.5 R:0.5 A6:0.5 R:0.5 F#6:0.5 R:0.5 E6:0.5 R:0.5 D6:0.5 R:0.5 C#6:0.5 R:0.5 B5:0.5 R:0.5"
820 REM Cycle 6: long-spaced answering tones
830 PLAY "R:1 A5:1 R:1 E6:1 R:1 F#6:1 R:1 C#6:1 R:1 D6:1 R:1 A5:1 R:1 B5:1 R:1 E6:1"
840 REM Cycles 7-8: chiming crowns augment the central climax
850 PLAY "F#6:0.5 A6:0.5 D7:1 E6:0.5 A6:0.5 C#7:1 F#6:0.5 B6:0.5 D7:1 F#6:0.5 A6:0.5 C#7:1 G6:0.5 B6:0.5 D7:1 F#6:0.5 A6:0.5 D7:1 G6:0.5 B6:0.5 D7:1 E6:0.5 A6:0.5 C#7:1"
860 PLAY "A6:0.5 F#6:0.5 D6:1 A6:0.5 E6:0.5 C#6:1 B6:0.5 F#6:0.5 D6:1 A6:0.5 F#6:0.5 C#6:1 B6:0.5 G6:0.5 D6:1 A6:0.5 F#6:0.5 D6:1 B6:0.5 G6:0.5 D6:1 A6:0.5 E6:0.5 C#6:1"
870 REM Cycles 9-10: sparse high bells over the last quick passage
880 PLAY "D7:1 R:1 C#7:1 R:1 B6:1 R:1 A6:1 R:1 G6:1 R:1 F#6:1 R:1 G6:1 R:1 A6:1 R:1"
890 PLAY "A6:1 R:1 E6:1 R:1 F#6:1 R:1 C#6:1 R:1 D6:1 R:1 A5:1 R:1 B5:1 R:1 E6:1 R:1"
900 REM Cycles 11-13: retreat into a low, soft counterlight
910 PLAY "D6:1 R:1 C#6:1 R:1 B5:1 R:1 A5:1 R:1 G5:1 R:1 F#5:1 R:1 E5:1 R:1 C#6:1 R:1"
920 PLAY "F#5:1 R:1 A5:1 R:1 G5:1 R:1 F#5:1 R:1 E5:1 R:1 D5:1 R:1 E5:1 R:1 A5:1 R:1"
930 PLAY "A5:1 R:1 F#5:1 R:1 E5:1 R:1 D5:1 R:1 B5:1 R:1 A5:1 R:1 G5:1 R:1 E5:1 R:1"
940 REM Cycle 14 and final ring: support, never cover, the harp cadence
950 PLAY "D6:1 R:1 A5:1 R:1 B5:1 R:1 F#6:1 R:1 G6:1 R:1 D6:1 R:1 E6:1 R:1 C#6:1 R:1"
960 PLAY "D6:4"
970 REM ============================================================
980 REM === VOICE 4: CELLO - EVOLVING GROUND BASS ===
990 VOICE 4
1000 INSTRUMENT 4,"CELLO"
1010 VOL 4,.46
1020 STEREO 4,0
1030 REM Cycles 1-2: plain ground establishes the architecture
1040 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1050 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1060 REM Cycles 3-5: fifths, thirds, and open-string breadth
1070 PLAY "D2:1 A2:1 A1:1 E2:1 B1:1 F#2:1 F#1:1 C#2:1 G1:1 D2:1 D2:1 A2:1 G1:1 D2:1 A1:1 E2:1"
1080 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
1090 PLAY "D2:1 A2:1 A1:1 E2:1 B1:1 F#2:1 F#1:1 C#2:1 G1:1 D2:1 D2:1 A2:1 G1:1 D2:1 A1:1 E2:1"
1100 REM Cycle 6: chromatic approaches lift into the quick variations
1110 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
1120 REM Cycles 7-8: gently syncopated bowing under the climax
1130 PLAY "D2:1.5 A2:0.5 A1:1.5 E2:0.5 B1:1.5 F#2:0.5 F#1:1.5 C#2:0.5 G1:1.5 D2:0.5 D2:1.5 A2:0.5 G1:1.5 D2:0.5 A1:1.5 E2:0.5"
1140 PLAY "D2:0.5 A2:1.5 A1:0.5 E2:1.5 B1:0.5 F#2:1.5 F#1:0.5 C#2:1.5 G1:0.5 D2:1.5 D2:0.5 A2:1.5 G1:0.5 D2:1.5 A1:0.5 E2:1.5"
1150 REM Cycles 9-10: walking line, then warm thirds
1160 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
1170 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
1180 REM Cycles 11-12: return to the original ground for repose
1190 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1200 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1210 REM Cycle 13: last walking approach
1220 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
1230 REM Cycle 14: final ground and expanded dominant cadence
1240 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:1 D2:1 A1:1 E2:1"
1250 PLAY "D2:4"
1260 REM ============================================================
1270 SOUND RESUME
1280 END
