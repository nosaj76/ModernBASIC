10 REM ============================================================
20 REM  PACHELBEL CANON IN D - CONCERT FOR FIVE PIANOS
30 REM  D MAJOR - 4/4 - FLOWING MULTI-PIANO ARRANGEMENT
40 REM  Composed by Johann Pachelbel, ca. 1680-1706, Public Domain
50 REM  Reorchestrated for ModernBASIC
60 REM  Piano I: cantabile lead
70 REM  Piano II: continuous flowing arpeggios
80 REM  Piano III: rhythmic chordwork
90 REM  Piano IV: warm inner counterpoint and suspensions
100 REM  Piano V: ground bass and bass variations
110 REM  Fourteen 16-beat cycles plus a 4-beat final cadence
120 REM  Every piano is synchronized to exactly 228 beats
130 REM ============================================================
140 CLEAR
150 TEMPO 80
160 VOL .76
170 REM ONE STEADY PULSE; TEXTURE AND REGISTER SHAPE THE DYNAMICS
180 REM ============================================================
190 REM === PIANO I: CANTABILE LEAD ===
200 VOICE 1
210 INSTRUMENT 1,"PIANO"
220 VOL 1,.31
230 STEREO 1,-.08
240 REM Cycles 1-2: unhurried opening statement
250 PLAY "F#5:2 E5:2 D5:2 C#5:2 B4:2 A4:2 B4:2 C#5:2 D5:2 C#5:2 B4:2 A4:2 G4:2 F#4:2 G4:2 E4:2"
260 REM Cycles 3-4: the melody opens across the keyboard
270 PLAY "D4:1 F#4:1 A4:1 G4:1 F#4:1 D4:1 F#4:1 E4:1 D4:1 B3:1 D4:1 A4:1 G4:1 B4:1 A4:1 G4:1 F#4:1 D4:1 E4:1 C#5:1 D5:1 F#5:1 A5:1 A4:1 B4:1 G4:1 A4:1 F#4:1 D4:1 D5:1 D5:1.5 C#5:0.5"
280 REM Cycle 5: first flowing variation
290 PLAY "D5:0.5 C#5:0.5 D5:0.5 D4:0.5 C#4:0.5 A4:0.5 E4:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 B4:0.5 C#5:0.5 F#5:0.5 A5:0.5 B5:0.5 G5:0.5 F#5:0.5 E5:0.5 G5:0.5 F#5:0.5 E5:0.5 D5:0.5 C#5:0.5 B4:0.5 A4:0.5 G4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 E4:0.5"
300 REM Cycles 6-7: broad central melody
310 PLAY "F#4:1 F#5:1 E5:1.75 R:1.25 D5:1 F#5:2 B5:2 A5:2 B5:2 C#6:2 D6:1 D5:1 C#5:1.75 R:1.25 B4:1 D5:2 D5:3 D5:1 D5:1 G5:1 E5:1 A5:1"
320 REM Cycle 8: first quick variation
330 PLAY "A5:0.5 F#5:0.25 G5:0.25 A5:0.5 F#5:0.25 G5:0.25 A5:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 G5:0.25 F#5:0.5 D5:0.25 E5:0.25 F#5:0.5 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 A4:0.25 G4:0.25 A4:0.25 F#4:0.25 G4:0.25 A4:0.25 G4:0.5 B4:0.25 A4:0.25 G4:0.5 F#4:0.25 E4:0.25 F#4:0.25 E4:0.25 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 G4:0.5 B4:0.25 A4:0.25 B4:0.5 C#5:0.25 D5:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 G5:0.25 A5:0.25"
340 REM Cycle 9: second quick variation
350 PLAY "F#5:0.5 D5:0.25 E5:0.25 F#5:0.5 E5:0.25 D5:0.25 E5:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 E5:0.25 D5:0.25 C#5:0.25 D5:0.5 B4:0.25 C#5:0.25 D5:0.5 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 F#4:0.25 E4:0.25 F#4:0.25 D5:0.25 C#5:0.25 D5:0.25 B4:0.5 D5:0.25 C#5:0.25 B4:0.5 A4:0.25 G4:0.25 A4:0.25 G4:0.25 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 B4:0.5 D5:0.25 C#5:0.25 D5:0.5 C#5:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 D5:0.25 C#5:0.25 D5:0.25 B4:0.25 C#5:0.25"
360 REM Cycles 10-11: breathing space after the peak
370 PLAY "D5:1 R:1 C#5:1 R:1 B4:1 R:1 D5:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1 R:1 A4:1 R:1 A4:1 R:1 F#4:1 R:1 A4:1 R:1 G4:1 R:1 F#4:1 R:1 G4:1 R:1 E5:1"
380 REM Cycle 12: intimate return
390 PLAY "F#5:0.5 F#4:0.5 G4:0.5 F#4:0.5 E4:0.5 E5:0.5 F#5:0.5 E5:0.5 D5:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 A3:0.5 G3:0.5 A3:0.5 B3:0.5 B4:0.5 A4:0.5 B4:0.5 A4:0.5 A3:0.5 G3:0.5 A3:0.5 D4:0.5 B4:0.5 A4:0.5 B4:0.5 C#5:0.5 C#4:0.5 B3:0.5 C#4:0.5"
400 REM Cycle 13: concise recapitulation
410 PLAY "F#5:1 E5:1 D5:1 C#5:1 B4:1 A4:1 B4:1 C#5:1 D5:1 C#5:1 B4:1 A4:1 G4:1 F#4:1 G4:1 E4:1"
420 REM Cycle 14 and final cadence
430 PLAY "D4:1 F#4:1 A4:1 D5:1 F#5:1 D5:1 A4:1 F#4:1 G4:1 B4:1 D5:1 G5:1 A4:1 C#5:1 E5:1 A5:1"
440 PLAY "D5:4"
450 REM ============================================================
460 REM === PIANO II: CONTINUOUS EIGHTH-NOTE ARPEGGIOS ===
470 VOICE 2
480 INSTRUMENT 2,"PIANO"
490 VOL 2,.18
500 STEREO 2,-.42
510 REM Cycles 1-4: close-position arpeggios, alternating direction
520 PLAY "D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5"
530 PLAY "A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5 B3:0.5 F#3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5"
540 PLAY "D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5"
550 PLAY "A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5 B3:0.5 F#3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5"
560 REM Cycles 5-9: wider arpeggios give the center more breadth
570 PLAY "D3:0.5 A3:0.5 D4:0.5 A3:0.5 E3:0.5 A3:0.5 E4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 B3:0.5 D4:0.5 B3:0.5 D3:0.5 A3:0.5 D4:0.5 A3:0.5 D3:0.5 B3:0.5 D4:0.5 B3:0.5 E3:0.5 C#4:0.5 E4:0.5 C#4:0.5"
580 PLAY "D4:0.5 A3:0.5 D3:0.5 A3:0.5 E4:0.5 A3:0.5 E3:0.5 A3:0.5 B3:0.5 F#3:0.5 D3:0.5 F#3:0.5 C#4:0.5 A3:0.5 C#3:0.5 A3:0.5 D4:0.5 B3:0.5 D3:0.5 B3:0.5 D4:0.5 A3:0.5 D3:0.5 A3:0.5 D4:0.5 B3:0.5 D3:0.5 B3:0.5 E4:0.5 C#4:0.5 E3:0.5 C#4:0.5"
590 PLAY "D3:0.5 A3:0.5 D4:0.5 A3:0.5 E3:0.5 A3:0.5 E4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 B3:0.5 D4:0.5 B3:0.5 D3:0.5 A3:0.5 D4:0.5 A3:0.5 D3:0.5 B3:0.5 D4:0.5 B3:0.5 E3:0.5 C#4:0.5 E4:0.5 C#4:0.5"
600 PLAY "D4:0.5 A3:0.5 D3:0.5 A3:0.5 E4:0.5 A3:0.5 E3:0.5 A3:0.5 B3:0.5 F#3:0.5 D3:0.5 F#3:0.5 C#4:0.5 A3:0.5 C#3:0.5 A3:0.5 D4:0.5 B3:0.5 D3:0.5 B3:0.5 D4:0.5 A3:0.5 D3:0.5 A3:0.5 D4:0.5 B3:0.5 D3:0.5 B3:0.5 E4:0.5 C#4:0.5 E3:0.5 C#4:0.5"
610 PLAY "D3:0.5 A3:0.5 D4:0.5 A3:0.5 E3:0.5 A3:0.5 E4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 B3:0.5 D4:0.5 B3:0.5 D3:0.5 A3:0.5 D4:0.5 A3:0.5 D3:0.5 B3:0.5 D4:0.5 B3:0.5 E3:0.5 C#4:0.5 E4:0.5 C#4:0.5"
620 REM Cycles 10-12: return inward beneath the quieter lead
630 PLAY "A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5 B3:0.5 F#3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5"
640 PLAY "D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5"
650 PLAY "A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5 B3:0.5 F#3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5"
660 REM Cycles 13-14: widened final ascent and descent
670 PLAY "D3:0.5 A3:0.5 D4:0.5 A3:0.5 E3:0.5 A3:0.5 E4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 B3:0.5 D4:0.5 B3:0.5 D3:0.5 A3:0.5 D4:0.5 A3:0.5 D3:0.5 B3:0.5 D4:0.5 B3:0.5 E3:0.5 C#4:0.5 E4:0.5 C#4:0.5"
680 PLAY "D4:0.5 A3:0.5 F#3:0.5 D3:0.5 E4:0.5 C#4:0.5 A3:0.5 E3:0.5 B3:0.5 F#3:0.5 D3:0.5 B2:0.5 A3:0.5 F#3:0.5 C#3:0.5 A2:0.5 B3:0.5 G3:0.5 D3:0.5 G2:0.5 A3:0.5 F#3:0.5 D3:0.5 A2:0.5 B3:0.5 G3:0.5 D3:0.5 G2:0.5 C#4:0.5 A3:0.5 E3:0.5 A2:0.5"
690 PLAY "D3:1 F#3:1 A3:1 D4:1"
700 REM ============================================================
710 REM === PIANO III: RHYTHMIC CHORDWORK ===
720 VOICE 3
730 INSTRUMENT 3,"PIANO"
740 VOL 3,.14
750 STEREO 3,.42
760 REM Cycles 1-2: simple two-note pulse
770 PLAY "D4:1 A4:1 C#4:1 A4:1 B3:1 F#4:1 C#4:1 F#4:1 B3:1 G4:1 A3:1 F#4:1 B3:1 G4:1 C#4:1 E4:1"
780 PLAY "D4:1 A4:1 C#4:1 A4:1 B3:1 F#4:1 C#4:1 F#4:1 B3:1 G4:1 A3:1 F#4:1 B3:1 G4:1 C#4:1 E4:1"
790 REM Cycles 3-5: short chord attacks followed by air
800 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
810 PLAY "R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5"
820 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
830 REM Cycles 6-9: alternating on-beat and off-beat accents
840 PLAY "R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5"
850 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
860 PLAY "R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5"
870 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
880 REM Cycles 10-14: progressively relax toward the cadence
890 PLAY "D4:1 A4:1 C#4:1 A4:1 B3:1 F#4:1 C#4:1 F#4:1 B3:1 G4:1 A3:1 F#4:1 B3:1 G4:1 C#4:1 E4:1"
900 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
910 PLAY "D4:1 A4:1 C#4:1 A4:1 B3:1 F#4:1 C#4:1 F#4:1 B3:1 G4:1 A3:1 F#4:1 B3:1 G4:1 C#4:1 E4:1"
920 PLAY "D4:0.5 F#4:0.5 A4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5 D4:0.5 F#4:0.5 B4:0.5 R:0.5 C#4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 D4:0.5 F#4:0.5 A4:0.5 R:0.5 D4:0.5 G4:0.5 B4:0.5 R:0.5 E4:0.5 A4:0.5 C#5:0.5 R:0.5"
930 PLAY "D4:1 A4:1 C#4:1 A4:1 B3:1 F#4:1 C#4:1 F#4:1 B3:1 G4:1 A3:1 F#4:1 B3:1 G4:1 C#4:1 E4:1"
940 PLAY "D4:1 F#4:1 A4:1 D5:1"
950 REM ============================================================
960 REM === PIANO IV: INNER COUNTERPOINT AND SUSPENSIONS ===
970 VOICE 4
980 INSTRUMENT 4,"PIANO"
990 VOL 4,.12
1000 STEREO 4,.16
1010 REM Cycles 1-4: warm chord tones move by small intervals
1020 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
1030 PLAY "A4:2 E4:2 D4:2 C#4:2 B3:2 A3:2 B3:2 E4:2"
1040 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
1050 PLAY "D4:2 C#4:2 B3:2 A3:2 G3:2 F#3:2 G3:2 A3:2"
1060 REM Cycles 5-9: inner line rises through the central build
1070 PLAY "A4:2 E4:2 F#4:2 C#4:2 D4:2 A4:2 B4:2 E4:2"
1080 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
1090 PLAY "A4:2 A4:2 B4:2 A4:2 B4:2 A4:2 G4:2 E4:2"
1100 PLAY "A4:2 E4:2 D4:2 C#4:2 B3:2 A3:2 B3:2 E4:2"
1110 PLAY "D4:2 C#4:2 B3:2 A3:2 G3:2 F#3:2 G3:2 A3:2"
1120 REM Cycles 10-13: descending voice-leading calms the texture
1130 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
1140 PLAY "D4:2 C#4:2 B3:2 A3:2 G3:2 F#3:2 G3:2 A3:2"
1150 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
1160 PLAY "A4:2 E4:2 D4:2 C#4:2 B3:2 A3:2 B3:2 E4:2"
1170 REM Cycle 14 and final inner resolution
1180 PLAY "F#4:2 E4:2 D4:2 C#4:2 B3:2 A3:2 G3:2 E4:2"
1190 PLAY "D4:4"
1200 REM ============================================================
1210 REM === PIANO V: GROUND BASS AND BASS VARIATIONS ===
1220 VOICE 5
1230 INSTRUMENT 5,"PIANO"
1240 VOL 5,.29
1250 STEREO 5,0
1260 REM Cycles 1-2: plain ground establishes D-A-Bm-F#m-G-D-G-A
1270 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1280 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1290 REM Cycles 3-5: open fifths and warm thirds
1300 PLAY "D2:1 A2:1 A1:1 E2:1 B1:1 F#2:1 F#1:1 C#2:1 G1:1 D2:1 D2:1 A2:1 G1:1 D2:1 A1:1 E2:1"
1310 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
1320 PLAY "D2:1 A2:1 A1:1 E2:1 B1:1 F#2:1 F#1:1 C#2:1 G1:1 D2:1 D2:1 A2:1 G1:1 D2:1 A1:1 E2:1"
1330 REM Cycle 6: chromatic approaches lead into the climax
1340 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
1350 REM Cycles 7-8: alternating long-short bass articulation
1360 PLAY "D2:1.5 A2:0.5 A1:1.5 E2:0.5 B1:1.5 F#2:0.5 F#1:1.5 C#2:0.5 G1:1.5 D2:0.5 D2:1.5 A2:0.5 G1:1.5 D2:0.5 A1:1.5 E2:0.5"
1370 PLAY "D2:0.5 A2:1.5 A1:0.5 E2:1.5 B1:0.5 F#2:1.5 F#1:0.5 C#2:1.5 G1:0.5 D2:1.5 D2:0.5 A2:1.5 G1:0.5 D2:1.5 A1:0.5 E2:1.5"
1380 REM Cycles 9-10: walking line, then consonant thirds
1390 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
1400 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
1410 REM Cycles 11-12: original ground returns for repose
1420 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1430 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1440 REM Cycle 13: final walking approach
1450 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
1460 REM Cycle 14 and final low tonic
1470 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:1 D2:1 A1:1 E2:1"
1480 PLAY "D2:4"
1490 REM ============================================================
1500 SOUND RESUME
1510 END
