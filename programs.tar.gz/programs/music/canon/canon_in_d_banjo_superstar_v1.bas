10 REM ============================================================
20 REM  PACHELBEL CANON IN D - BANJO SUPERSTAR
30 REM  Composed by Johann Pachelbel, ca. 1680-1706, Public Domain
40 REM  Arranged as a featured five-string banjo showcase in D
50 REM  Banjo layers 1-3 combine into ONE large, articulate banjo
60 REM  D tuning concept: aDF#AD; high A is the fifth-string drone
70 REM  Techniques: slides, hammer-ons, pull-offs, chokes, pinches
80 REM  Forward, reverse, alternating-thumb, Foggy Mountain rolls
90 REM  Clawhammer bum-ditty, drop-thumb, melodic and single-string
100 REM  Steel guitar supplies restrained boom-chuck and bass only
110 REM  Chords: D A Bm F#m G D G A - two beats per chord
120 REM  Every voice synchronized to exactly 228 beats
130 REM ============================================================
140 CLEAR
150 TEMPO 96
160 VOL .78
170 SOUNDFONT 1,"soundfont/MuseScore_General.sf2"
180 SOUNDFONT 2,"soundfont/MuseScore_General.sf2"
190 SOUNDFONT 3,"soundfont/MuseScore_General.sf2"
200 SOUNDFONT 4,"soundfont/MuseScore_General.sf2"
210 SOUNDFONT 5,"soundfont/MuseScore_General.sf2"
220 REM ============================================================
230 REM === VOICE 1: FEATURED BANJO - MELODY AND FRETWORK ===
240 VOICE 1
250 INSTRUMENT 1,105
260 VOL 1,.52
270 STEREO 1,0
280 REM Cycles 1-2: exposed theme, slides and restrained pull-offs
290 PLAY "E5:.125 F#5:1.875 E5:2 D5:2 C#5:2 B4:2 A4:2 A4:.125 B4:1.875 C#5:2 D5:2 C#5:2 B4:2 A4:2 G4:2 G4:.125 F#4:1.875 G4:2 F#4:.125 E4:1.875"
300 TEMPO 100
310 VOL 1,.55
320 REM Cycles 3-4: hammer-ons, pull-offs and alternating-thumb lead
330 PLAY "D4:.75 E4:.125 F#4:.125 F#4:1 A4:.75 G4:.125 A4:.125 G4:1 F#4:.75 G4:.125 F#4:.125 D4:1 D4:.125 F#4:.875 E4:1 D4:1 B3:.75 C#4:.125 D4:.125 D4:1 A4:1 G4:1 A4:.125 B4:.875 A4:1 G4:1 F#4:.75 G4:.125 F#4:.125 D4:1 E4:.75 B4:.125 C#5:.125 C#5:1 D5:.125 F#5:.875 A5:1 A4:1 B4:.75 A4:.125 B4:.125 G4:1 A4:1 F#4:1 D4:.75 A4:.125 D5:.125 D5:1 D5:1.5 C#5:.5"
335 PLAY "R:1"
340 TEMPO 104
350 VOL 1,.58
360 REM Cycle 5: melodic-style cross-string cascade
370 PLAY "C#5:.125 D5:.375 C#5:.5 D5:.5 D4:.5 C#4:.5 A4:.5 E4:.5 E4:.125 F#4:.375 D4:.5 D5:.5 C#5:.5 B4:.5 B4:.125 C#5:.375 F#5:.5 A5:.5 B5:.5 G5:.5 F#5:.5 E5:.5 G5:.5 F#5:.5 E5:.5 D5:.5 C#5:.5 B4:.5 A4:.5 G4:.5 F#4:.5 E4:.5 G4:.5 F#4:.5 E4:.5"
380 REM Cycles 6-7: high-neck singing line with choke-like turns
390 PLAY "F#4:1 E5:.125 F#5:.875 E5:1.5 F#5:.125 E5:.125 R:1.25 C#5:.125 D5:.875 F#5:2 B5:1.75 C#6:.125 B5:.125 A5:2 B5:2 C#6:1.75 D6:.125 C#6:.125 D6:1 D5:1 C#5:1.5 D5:.125 C#5:.125 R:1.25 A4:.125 B4:.875 D5:2 D5:2.5 E5:.125 D5:.375 D5:1 G5:1 E5:1 A5:1"
395 PLAY "R:1"
400 TEMPO 116
410 VOL 1,.62
420 REM Cycle 8: Scruggs break - drive notes framed by roll layers
430 PLAY "A5:.5 F#5:.25 G5:.25 A5:.5 F#5:.25 G5:.25 A5:.25 A4:.25 B4:.25 C#5:.25 D5:.25 E5:.25 F#5:.25 G5:.25 F#5:.5 D5:.25 E5:.25 F#5:.5 F#4:.25 G4:.25 A4:.25 B4:.25 A4:.25 G4:.25 A4:.25 F#4:.25 G4:.25 A4:.25 G4:.5 B4:.25 A4:.25 G4:.5 F#4:.25 E4:.25 F#4:.25 E4:.25 D4:.25 E4:.25 F#4:.25 G4:.25 A4:.25 B4:.25 G4:.5 B4:.25 A4:.25 B4:.5 C#5:.25 D5:.25 A4:.25 B4:.25 C#5:.25 D5:.25 E5:.25 F#5:.25 G5:.25 A5:.25"
440 REM Cycle 9: Reno single-string run and cascading pull-offs
450 PLAY "F#5:.5 D5:.25 E5:.25 F#5:.5 E5:.25 D5:.25 E5:.25 C#5:.25 D5:.25 E5:.25 F#5:.25 E5:.25 D5:.25 C#5:.25 D5:.5 B4:.25 C#5:.25 D5:.5 D4:.25 E4:.25 F#4:.25 G4:.25 F#4:.25 E4:.25 F#4:.25 D5:.25 C#5:.25 D5:.25 B4:.5 D5:.25 C#5:.25 B4:.5 A4:.25 G4:.25 A4:.25 G4:.25 F#4:.25 G4:.25 A4:.25 B4:.25 C#5:.25 D5:.25 B4:.5 D5:.25 C#5:.25 D5:.5 C#5:.25 B4:.25 C#5:.25 D5:.25 E5:.25 D5:.25 C#5:.25 D5:.25 B4:.25 C#5:.25"
460 TEMPO 100
470 VOL 1,.53
480 REM Cycles 10-11: clawhammer melody, space for the bum-ditty
490 PLAY "D5:.75 R:.25 A5:.25 R:.75 C#5:.75 R:.25 A5:.25 R:.75 B4:.75 R:.25 A5:.25 R:.75 C#5:.125 D5:.625 R:.25 A5:.25 R:.75 D4:.75 R:.25 A5:.25 R:.75 D4:.75 R:.25 A5:.25 R:.75 D4:.75 R:.25 A5:.25 R:.75 D4:.75 R:.25 A5:.25 R:.75 R:1 A4:.25 R:.75 A4:.75 R:.25 A5:.25 R:.75 F#4:.75 R:.25 A5:.25 R:.75 A4:.75 R:.25 A5:.25 R:.75 G4:.75 R:.25 A5:.25 R:.75 F#4:.75 R:.25 A5:.25 R:.75 G4:.75 R:.25 A5:.25 R:.75 E5:1"
495 PLAY "R:1"
500 TEMPO 96
510 VOL 1,.48
520 REM Cycle 12: quiet drop-thumb return, close to the fingerboard
530 PLAY "F#5:.5 F#4:.5 G4:.5 F#4:.5 E4:.5 E5:.5 F#5:.5 E5:.5 D5:.5 F#4:.5 D4:.5 D5:.5 C#5:.5 A3:.5 G3:.5 A3:.5 B3:.5 B4:.5 A4:.5 B4:.5 A4:.5 A3:.5 G3:.5 A3:.5 D4:.5 B4:.5 A4:.5 B4:.5 C#5:.5 C#4:.5 B3:.5 C#4:.5"
540 TEMPO 106
550 VOL 1,.59
560 REM Cycle 13: full rolling recapitulation with grace-note sparks
570 PLAY "E5:.125 F#5:.875 E5:1 D5:1 B4:.125 C#5:.875 B4:1 A4:1 A4:.125 B4:.875 C#5:1 D5:1 C#5:1 B4:1 A4:1 G4:1 G4:.125 F#4:.875 G4:1 F#4:.125 E4:.875"
580 TEMPO 114
590 VOL 1,.64
600 REM Cycle 14: high-neck finale, chromatic slide and triumphant fall
610 PLAY "D4:.5 E4:.125 F#4:.375 A4:1 D5:1 F#5:1 D5:1 A4:1 F#4:1 G4:.5 A4:.125 B4:.375 D5:1 G5:1 A4:.5 B4:.125 C#5:.375 E5:1 A5:1 B5:.25 C#6:.25 D6:.5 C#6:.25 B5:.25 A5:.5 F#5:.5 D5:.5"
620 TEMPO 96
630 REM Four-beat tag: classic banjo flourish into the final D
640 PLAY "A4:.25 D5:.25 F#5:.5 A5:.5 F#5:.5 D5:2"
650 REM ============================================================
660 REM === VOICE 2: FEATURED BANJO - THREE-FINGER ROLL ENGINE ===
670 VOICE 2
680 INSTRUMENT 2,105
690 VOL 2,.24
700 STEREO 2,-.12
710 REM Cycles 1-2: sparse square roll opens into a forward roll
720 PLAY "D4:.5 A4:.5 F#4:.5 A4:.5 A3:.5 E4:.5 C#4:.5 E4:.5 B3:.5 F#4:.5 D4:.5 F#4:.5 F#3:.5 C#4:.5 A4:.5 C#4:.5 G3:.5 D4:.5 B4:.5 D4:.5 D4:.5 A4:.5 F#4:.5 A4:.5 G3:.5 D4:.5 B4:.5 D4:.5 A3:.5 E4:.5 C#4:.5 E4:.5 D4:.25 F#4:.25 A4:.25 D5:.25 F#4:.25 A4:.25 D5:.25 A5:.25 A3:.25 C#4:.25 E4:.25 A4:.25 C#4:.25 E4:.25 A4:.25 A5:.25 B3:.25 D4:.25 F#4:.25 B4:.25 D4:.25 F#4:.25 B4:.25 A5:.25 F#3:.25 A4:.25 C#4:.25 F#4:.25 A4:.25 C#4:.25 F#4:.25 A5:.25 G3:.25 B4:.25 D4:.25 G4:.25 B4:.25 D4:.25 G4:.25 A5:.25 D3:.25 F#4:.25 A4:.25 D4:.25 F#4:.25 A4:.25 D5:.25 A5:.25 G3:.25 B4:.25 D4:.25 G4:.25 B4:.25 D4:.25 G4:.25 A5:.25 A3:.25 C#4:.25 E4:.25 A4:.25 C#4:.25 E4:.25 A4:.25 A5:.25"
730 TEMPO 100
740 VOL 2,.27
750 REM Cycles 3-4: alternating-thumb then forward-reverse rolls
760 PLAY "D3:.25 A4:.25 D4:.25 F#4:.25 D5:.25 A4:.25 F#4:.25 A5:.25 A3:.25 E4:.25 A4:.25 C#5:.25 E5:.25 A4:.25 C#5:.25 A5:.25 B3:.25 F#4:.25 B4:.25 D5:.25 F#5:.25 B4:.25 D5:.25 A5:.25 F#3:.25 C#4:.25 F#4:.25 A4:.25 C#5:.25 F#4:.25 A4:.25 A5:.25 G3:.25 D4:.25 G4:.25 B4:.25 D5:.25 G4:.25 B4:.25 A5:.25 D3:.25 A4:.25 D4:.25 F#4:.25 D5:.25 A4:.25 F#4:.25 A5:.25 G3:.25 D4:.25 G4:.25 B4:.25 D5:.25 G4:.25 B4:.25 A5:.25 A3:.25 E4:.25 A4:.25 C#5:.25 E5:.25 A4:.25 C#5:.25 A5:.25 D3:.25 F#4:.25 A4:.25 D5:.25 A5:.25 D5:.25 A4:.25 F#4:.25 A3:.25 C#4:.25 E4:.25 A4:.25 A5:.25 A4:.25 E4:.25 C#4:.25 B3:.25 D4:.25 F#4:.25 B4:.25 A5:.25 B4:.25 F#4:.25 D4:.25 F#3:.25 A4:.25 C#4:.25 F#4:.25 A5:.25 F#4:.25 C#4:.25 A4:.25 G3:.25 B4:.25 D4:.25 G4:.25 A5:.25 G4:.25 D4:.25 B4:.25 D3:.25 F#4:.25 A4:.25 D5:.25 A5:.25 D5:.25 A4:.25 F#4:.25 G3:.25 B4:.25 D4:.25 G4:.25 A5:.25 G4:.25 D4:.25 B4:.25 A3:.25 C#4:.25 E4:.25 A4:.25 A5:.25 A4:.25 E4:.25 C#4:.25"
770 TEMPO 104
780 VOL 2,.29
790 REM Cycle 5: forward roll follows the melodic cascade
800 PLAY "D3:.25 F#4:.25 A4:.25 D5:.25 A5:.25 D5:.25 A4:.25 F#4:.25 A3:.25 C#4:.25 E4:.25 A4:.25 A5:.25 A4:.25 E4:.25 C#4:.25 B3:.25 D4:.25 F#4:.25 B4:.25 A5:.25 B4:.25 F#4:.25 D4:.25 F#3:.25 A4:.25 C#4:.25 F#4:.25 A5:.25 F#4:.25 C#4:.25 A4:.25 G3:.25 B4:.25 D4:.25 G4:.25 A5:.25 G4:.25 D4:.25 B4:.25 D3:.25 F#4:.25 A4:.25 D5:.25 A5:.25 D5:.25 A4:.25 F#4:.25 G3:.25 B4:.25 D4:.25 G4:.25 A5:.25 G4:.25 D4:.25 B4:.25 A3:.25 C#4:.25 E4:.25 A4:.25 A5:.25 A4:.25 E4:.25 C#4:.25"
810 REM Cycles 6-7: reverse rolls leave room beneath the high melody
820 PLAY "D3:.25 A4:.25 F#4:.25 D4:.25 A5:.25 D5:.25 A4:.25 F#4:.25 A3:.25 E4:.25 C#4:.25 A4:.25 A5:.25 E5:.25 C#5:.25 A4:.25 B3:.25 F#4:.25 D4:.25 B4:.25 A5:.25 F#5:.25 D5:.25 B4:.25 F#3:.25 C#4:.25 A4:.25 F#4:.25 A5:.25 F#4:.25 C#4:.25 A4:.25 G3:.25 D4:.25 B4:.25 G4:.25 A5:.25 G5:.25 D5:.25 B4:.25 D3:.25 A4:.25 F#4:.25 D4:.25 A5:.25 D5:.25 A4:.25 F#4:.25 G3:.25 D4:.25 B4:.25 G4:.25 A5:.25 G5:.25 D5:.25 B4:.25 A3:.25 E4:.25 C#4:.25 A4:.25 A5:.25 E5:.25 C#5:.25 A4:.25 D3:.25 A4:.25 F#4:.25 D4:.25 A5:.25 D5:.25 A4:.25 F#4:.25 A3:.25 E4:.25 C#4:.25 A4:.25 A5:.25 E5:.25 C#5:.25 A4:.25 B3:.25 F#4:.25 D4:.25 B4:.25 A5:.25 F#5:.25 D5:.25 B4:.25 F#3:.25 C#4:.25 A4:.25 F#4:.25 A5:.25 F#4:.25 C#4:.25 A4:.25 G3:.25 D4:.25 B4:.25 G4:.25 A5:.25 G5:.25 D5:.25 B4:.25 D3:.25 A4:.25 F#4:.25 D4:.25 A5:.25 D5:.25 A4:.25 F#4:.25 G3:.25 D4:.25 B4:.25 G4:.25 A5:.25 G5:.25 D5:.25 B4:.25 A3:.25 E4:.25 C#4:.25 A4:.25 A5:.25 E5:.25 C#5:.25 A4:.25"
830 TEMPO 116
840 VOL 2,.34
850 REM Cycle 8: Foggy Mountain roll at full drive
860 PLAY "D3:.25 D4:.25 F#4:.25 A5:.25 D4:.25 F#4:.25 A4:.25 A5:.25 A3:.25 A4:.25 C#5:.25 A5:.25 E4:.25 C#5:.25 E5:.25 A5:.25 B3:.25 B4:.25 D5:.25 A5:.25 F#4:.25 D5:.25 F#5:.25 A5:.25 F#3:.25 F#4:.25 A4:.25 A5:.25 C#4:.25 A4:.25 C#5:.25 A5:.25 G3:.25 G4:.25 B4:.25 A5:.25 D4:.25 B4:.25 D5:.25 A5:.25 D3:.25 D4:.25 F#4:.25 A5:.25 D4:.25 F#4:.25 A4:.25 A5:.25 G3:.25 G4:.25 B4:.25 A5:.25 D4:.25 B4:.25 D5:.25 A5:.25 A3:.25 A4:.25 C#5:.25 A5:.25 E4:.25 C#5:.25 E5:.25 A5:.25"
870 REM Cycle 9: backward roll under the single-string descent
880 PLAY "D3:.25 A4:.25 F#4:.25 D4:.25 A5:.25 D5:.25 A4:.25 F#4:.25 A3:.25 E4:.25 C#4:.25 A4:.25 A5:.25 E5:.25 C#5:.25 A4:.25 B3:.25 F#4:.25 D4:.25 B4:.25 A5:.25 F#5:.25 D5:.25 B4:.25 F#3:.25 C#4:.25 A4:.25 F#4:.25 A5:.25 F#4:.25 C#4:.25 A4:.25 G3:.25 D4:.25 B4:.25 G4:.25 A5:.25 G5:.25 D5:.25 B4:.25 D3:.25 A4:.25 F#4:.25 D4:.25 A5:.25 D5:.25 A4:.25 F#4:.25 G3:.25 D4:.25 B4:.25 G4:.25 A5:.25 G5:.25 D5:.25 B4:.25 A3:.25 E4:.25 C#4:.25 A4:.25 A5:.25 E5:.25 C#5:.25 A4:.25"
890 TEMPO 100
900 VOL 2,.22
910 REM Cycles 10-11: roll thins out for the clawhammer episode
920 PLAY "D3:.5 A4:.5 F#4:.5 A5:.5 A3:.5 E4:.5 C#4:.5 A5:.5 B3:.5 F#4:.5 D4:.5 A5:.5 F#3:.5 C#4:.5 A4:.5 A5:.5 G3:.5 D4:.5 B4:.5 A5:.5 D3:.5 A4:.5 F#4:.5 A5:.5 G3:.5 D4:.5 B4:.5 A5:.5 A3:.5 E4:.5 C#4:.5 A5:.5 D3:.5 A4:.5 F#4:.5 A5:.5 A3:.5 E4:.5 C#4:.5 A5:.5 B3:.5 F#4:.5 D4:.5 A5:.5 F#3:.5 C#4:.5 A4:.5 A5:.5 G3:.5 D4:.5 B4:.5 A5:.5 D3:.5 A4:.5 F#4:.5 A5:.5 G3:.5 D4:.5 B4:.5 A5:.5 A3:.5 E4:.5 C#4:.5 A5:.5"
930 TEMPO 96
940 VOL 2,.18
950 REM Cycle 12: quiet square roll
960 PLAY "D4:.5 A4:.5 F#4:.5 A5:.5 A3:.5 E4:.5 C#4:.5 A5:.5 B3:.5 F#4:.5 D4:.5 A5:.5 F#3:.5 C#4:.5 A4:.5 A5:.5 G3:.5 D4:.5 B4:.5 A5:.5 D3:.5 A4:.5 F#4:.5 A5:.5 G3:.5 D4:.5 B4:.5 A5:.5 A3:.5 E4:.5 C#4:.5 A5:.5"
970 TEMPO 106
980 VOL 2,.30
990 REM Cycle 13: forward-reverse recapitulation
1000 PLAY "D3:.25 F#4:.25 A4:.25 D5:.25 A5:.25 D5:.25 A4:.25 F#4:.25 A3:.25 C#4:.25 E4:.25 A4:.25 A5:.25 A4:.25 E4:.25 C#4:.25 B3:.25 D4:.25 F#4:.25 B4:.25 A5:.25 B4:.25 F#4:.25 D4:.25 F#3:.25 A4:.25 C#4:.25 F#4:.25 A5:.25 F#4:.25 C#4:.25 A4:.25 G3:.25 B4:.25 D4:.25 G4:.25 A5:.25 G4:.25 D4:.25 B4:.25 D3:.25 F#4:.25 A4:.25 D5:.25 A5:.25 D5:.25 A4:.25 F#4:.25 G3:.25 B4:.25 D4:.25 G4:.25 A5:.25 G4:.25 D4:.25 B4:.25 A3:.25 C#4:.25 E4:.25 A4:.25 A5:.25 A4:.25 E4:.25 C#4:.25"
1010 TEMPO 114
1020 VOL 2,.35
1030 REM Cycle 14: maximum-drive Foggy Mountain roll
1040 PLAY "D3:.25 D4:.25 F#4:.25 A5:.25 D4:.25 F#4:.25 A4:.25 A5:.25 A3:.25 A4:.25 C#5:.25 A5:.25 E4:.25 C#5:.25 E5:.25 A5:.25 B3:.25 B4:.25 D5:.25 A5:.25 F#4:.25 D5:.25 F#5:.25 A5:.25 F#3:.25 F#4:.25 A4:.25 A5:.25 C#4:.25 A4:.25 C#5:.25 A5:.25 G3:.25 G4:.25 B4:.25 A5:.25 D4:.25 B4:.25 D5:.25 A5:.25 D3:.25 D4:.25 F#4:.25 A5:.25 D4:.25 F#4:.25 A4:.25 A5:.25 G3:.25 G4:.25 B4:.25 A5:.25 D4:.25 B4:.25 D5:.25 A5:.25 A3:.25 A4:.25 C#5:.25 A5:.25 E4:.25 C#5:.25 E5:.25 A5:.25"
1050 TEMPO 96
1060 PLAY "D3:.25 F#4:.25 A4:.25 D5:.25 A5:.25 F#5:.25 D5:.25 A4:.25 F#4:.25 D4:.25 A4:.25 F#4:.25 D4:.25 A3:.25 D4:.25 D5:.25"
1070 REM ============================================================
1080 REM === VOICE 3: FEATURED BANJO - FIFTH STRING, PINCH, CLAWHAMMER ===
1090 VOICE 3
1100 INSTRUMENT 3,105
1110 VOL 3,.17
1120 STEREO 3,.12
1130 REM Cycles 1-2: isolated fifth-string A drone after each phrase
1140 PLAY "R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75 R:1 A5:.25 R:.75"
1150 TEMPO 100
1160 VOL 3,.20
1170 REM Cycles 3-4: thumb drone plus chord-tone pinch accents
1180 PLAY "R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 E5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 C#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 B4:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 B4:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 E5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 E5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 C#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 B4:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 B4:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 E5:.5 A5:.25 R:.25"
1190 TEMPO 104
1200 VOL 3,.22
1210 REM Cycle 5: close pinches sparkle above the melodic cascade
1220 PLAY "D5:.25 R:.75 A5:.25 R:.75 C#5:.25 R:.75 A5:.25 R:.75 B4:.25 R:.75 A5:.25 R:.75 C#5:.25 R:.75 A5:.25 R:.75 B4:.25 R:.75 A5:.25 R:.75 D5:.25 R:.75 A5:.25 R:.75 B4:.25 R:.75 A5:.25 R:.75 E5:.25 R:.75 A5:.25 R:.75"
1230 REM Cycles 6-7: syncopated fifth-string responses to sustained lead
1240 PLAY "R:.75 A5:.25 R:.5 F#5:.25 A5:.25 R:.75 A5:.25 R:.5 E5:.25 A5:.25 R:.75 A5:.25 R:.5 F#5:.25 A5:.25 R:.75 A5:.25 R:.5 C#5:.25 A5:.25 R:.75 A5:.25 R:.5 B4:.25 A5:.25 R:.75 A5:.25 R:.5 F#5:.25 A5:.25 R:.75 A5:.25 R:.5 B4:.25 A5:.25 R:.75 A5:.25 R:.5 E5:.25 A5:.25 R:.75 A5:.25 R:.5 F#5:.25 A5:.25 R:.75 A5:.25 R:.5 E5:.25 A5:.25 R:.75 A5:.25 R:.5 F#5:.25 A5:.25 R:.75 A5:.25 R:.5 C#5:.25 A5:.25 R:.75 A5:.25 R:.5 B4:.25 A5:.25 R:.75 A5:.25 R:.5 F#5:.25 A5:.25 R:.75 A5:.25 R:.5 B4:.25 A5:.25 R:.75 A5:.25 R:.5 E5:.25 A5:.25"
1250 TEMPO 116
1260 VOL 3,.25
1270 REM Cycle 8: fifth-string drone fires through the Scruggs break
1280 PLAY "R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25"
1285 PLAY "R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25 R:.25 A5:.25"
1290 REM Cycle 9: pinches punctuate the descending single-string run
1300 PLAY "D5:.25 A5:.25 R:.5 C#5:.25 A5:.25 R:.5 B4:.25 A5:.25 R:.5 A4:.25 A5:.25 R:.5 G4:.25 A5:.25 R:.5 F#4:.25 A5:.25 R:.5 G4:.25 A5:.25 R:.5 E5:.25 A5:.25 R:.5 D5:.25 A5:.25 R:.5 C#5:.25 A5:.25 R:.5 B4:.25 A5:.25 R:.5 A4:.25 A5:.25 R:.5 G4:.25 A5:.25 R:.5 F#4:.25 A5:.25 R:.5 G4:.25 A5:.25 R:.5 E5:.25 A5:.25 R:.5"
1310 TEMPO 100
1320 VOL 3,.27
1330 REM Cycles 10-11: clawhammer bum-ditty and drop-thumb showcase
1340 PLAY "D5:.5 R:.25 A5:.25 F#5:.5 A5:.25 R:.25 C#5:.5 R:.25 A5:.25 E5:.5 A5:.25 R:.25 B4:.5 R:.25 A5:.25 F#5:.5 A5:.25 R:.25 A4:.5 R:.25 A5:.25 C#5:.5 A5:.25 R:.25 G4:.5 R:.25 A5:.25 B4:.5 A5:.25 R:.25 F#4:.5 R:.25 A5:.25 D5:.5 A5:.25 R:.25 G4:.5 R:.25 A5:.25 B4:.5 A5:.25 R:.25 A4:.5 R:.25 A5:.25 E5:.5 A5:.25 R:.25 D5:.5 R:.25 A5:.25 F#5:.5 A5:.25 R:.25 C#5:.5 R:.25 A5:.25 E5:.5 A5:.25 R:.25 B4:.5 R:.25 A5:.25 F#5:.5 A5:.25 R:.25 A4:.5 R:.25 A5:.25 C#5:.5 A5:.25 R:.25 G4:.5 R:.25 A5:.25 B4:.5 A5:.25 R:.25 F#4:.5 R:.25 A5:.25 D5:.5 A5:.25 R:.25 G4:.5 R:.25 A5:.25 B4:.5 A5:.25 R:.25 A4:.5 R:.25 A5:.25 E5:.5 A5:.25 R:.25"
1350 TEMPO 96
1360 VOL 3,.14
1370 REM Cycle 12: nearly solo lead, only a distant fifth-string pulse
1380 PLAY "R:1.5 A5:.25 R:.25 R:1.5 A5:.25 R:.25 R:1.5 A5:.25 R:.25 R:1.5 A5:.25 R:.25 R:1.5 A5:.25 R:.25 R:1.5 A5:.25 R:.25 R:1.5 A5:.25 R:.25 R:1.5 A5:.25 R:.25"
1390 TEMPO 106
1400 VOL 3,.22
1410 REM Cycle 13: thumb drone and pinches rebuild the energy
1420 PLAY "R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 E5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 C#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 B4:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 F#5:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 B4:.5 A5:.25 R:.25 R:.5 A5:.25 R:.25 E5:.5 A5:.25 R:.25"
1430 TEMPO 114
1440 VOL 3,.29
1450 REM Cycle 14: high pinches answer every phrase of the finale
1460 PLAY "D5:.25 A5:.25 R:.5 C#5:.25 A5:.25 R:.5 B4:.25 A5:.25 R:.5 C#5:.25 A5:.25 R:.5 B4:.25 A5:.25 R:.5 D5:.25 A5:.25 R:.5 B4:.25 A5:.25 R:.5 E5:.25 A5:.25 R:.5 D5:.25 A5:.25 R:.5 C#5:.25 A5:.25 R:.5 B4:.25 A5:.25 R:.5 G5:.25 A5:.25 R:.5 F#5:.25 A5:.25 R:.5 E5:.25 A5:.25 R:.5 A5:.25 D6:.25 R:.5"
1465 PLAY "R:1"
1470 TEMPO 96
1480 PLAY "D5:.25 A5:.25 R:.5 F#5:.25 A5:.25 R:.5 D5:.25 A5:.25 R:.5 D5:1"
1490 REM ============================================================
1500 REM === VOICE 4: STEEL-STRING GUITAR - RESTRAINED BOOM-CHUCK ===
1510 VOICE 4
1520 INSTRUMENT 4,25
1530 VOL 4,.22
1540 STEREO 4,.32
1550 REM Cycles 1-2: soft bass-brush rhythm, repeated progression
1560 PLAY "D3:.75 R:.25 F#4:.25 A4:.25 D5:.25 R:.25 A3:.75 R:.25 C#4:.25 E4:.25 A4:.25 R:.25 B3:.75 R:.25 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.75 R:.25 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.75 R:.25 B4:.25 D4:.25 G4:.25 R:.25 D3:.75 R:.25 F#4:.25 A4:.25 D5:.25 R:.25 G3:.75 R:.25 B4:.25 D4:.25 G4:.25 R:.25 A3:.75 R:.25 C#4:.25 E4:.25 A4:.25 R:.25 D3:.75 R:.25 F#4:.25 A4:.25 D5:.25 R:.25 A3:.75 R:.25 C#4:.25 E4:.25 A4:.25 R:.25 B3:.75 R:.25 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.75 R:.25 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.75 R:.25 B4:.25 D4:.25 G4:.25 R:.25 D3:.75 R:.25 F#4:.25 A4:.25 D5:.25 R:.25 G3:.75 R:.25 B4:.25 D4:.25 G4:.25 R:.25 A3:.75 R:.25 C#4:.25 E4:.25 A4:.25 R:.25"
1570 TEMPO 100
1580 VOL 4,.24
1590 REM Cycles 3-4: firmer boom-chuck, still behind the banjo
1600 PLAY "D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 B3:.5 F#4:.5 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.5 C#4:.5 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 B3:.5 F#4:.5 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.5 C#4:.5 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25"
1610 TEMPO 104
1620 REM Cycle 5: clean boom-chuck under the melodic passage
1630 PLAY "D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 B3:.5 F#4:.5 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.5 C#4:.5 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25"
1640 REM Cycles 6-7: half-time brushes make the banjo sound larger
1650 PLAY "D3:1 R:.5 A4:.25 D5:.25 A3:1 R:.5 E4:.25 A4:.25 B3:1 R:.5 F#4:.25 B4:.25 F#3:1 R:.5 C#4:.25 F#4:.25 G3:1 R:.5 D4:.25 G4:.25 D3:1 R:.5 A4:.25 D5:.25 G3:1 R:.5 D4:.25 G4:.25 A3:1 R:.5 E4:.25 A4:.25 D3:1 R:.5 A4:.25 D5:.25 A3:1 R:.5 E4:.25 A4:.25 B3:1 R:.5 F#4:.25 B4:.25 F#3:1 R:.5 C#4:.25 F#4:.25 G3:1 R:.5 D4:.25 G4:.25 D3:1 R:.5 A4:.25 D5:.25 G3:1 R:.5 D4:.25 G4:.25 A3:1 R:.5 E4:.25 A4:.25"
1660 TEMPO 116
1670 VOL 4,.27
1680 REM Cycles 8-9: driving boom-chuck beneath both banjo breaks
1690 PLAY "D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 B3:.5 F#4:.5 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.5 C#4:.5 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 B3:.5 F#4:.5 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.5 C#4:.5 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25"
1700 TEMPO 100
1710 VOL 4,.21
1720 REM Cycles 10-11: sparse backbeat for the clawhammer section
1730 PLAY "D3:1 R:.5 A4:.25 D5:.25 A3:1 R:.5 E4:.25 A4:.25 B3:1 R:.5 F#4:.25 B4:.25 F#3:1 R:.5 C#4:.25 F#4:.25 G3:1 R:.5 D4:.25 G4:.25 D3:1 R:.5 A4:.25 D5:.25 G3:1 R:.5 D4:.25 G4:.25 A3:1 R:.5 E4:.25 A4:.25 D3:1 R:.5 A4:.25 D5:.25 A3:1 R:.5 E4:.25 A4:.25 B3:1 R:.5 F#4:.25 B4:.25 F#3:1 R:.5 C#4:.25 F#4:.25 G3:1 R:.5 D4:.25 G4:.25 D3:1 R:.5 A4:.25 D5:.25 G3:1 R:.5 D4:.25 G4:.25 A3:1 R:.5 E4:.25 A4:.25"
1740 TEMPO 96
1750 VOL 4,.17
1760 REM Cycle 12: quietest guitar pass
1770 PLAY "D3:1 R:.5 A4:.25 D5:.25 A3:1 R:.5 E4:.25 A4:.25 B3:1 R:.5 F#4:.25 B4:.25 F#3:1 R:.5 C#4:.25 F#4:.25 G3:1 R:.5 D4:.25 G4:.25 D3:1 R:.5 A4:.25 D5:.25 G3:1 R:.5 D4:.25 G4:.25 A3:1 R:.5 E4:.25 A4:.25"
1780 TEMPO 106
1790 VOL 4,.24
1800 REM Cycle 13: rhythm returns
1810 PLAY "D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 B3:.5 F#4:.5 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.5 C#4:.5 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25"
1820 TEMPO 114
1830 VOL 4,.28
1840 REM Cycle 14: hard final boom-chuck without masking the banjo
1850 PLAY "D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25 B3:.5 F#4:.5 D4:.25 F#4:.25 B4:.25 R:.25 F#3:.5 C#4:.5 A4:.25 C#4:.25 F#4:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 D3:.5 A3:.5 F#4:.25 A4:.25 D5:.25 R:.25 G3:.5 D4:.5 B4:.25 D4:.25 G4:.25 R:.25 A3:.5 E4:.5 C#4:.25 E4:.25 A4:.25 R:.25"
1860 TEMPO 96
1870 PLAY "D3:1 R:.5 A4:.25 D5:.25 D3:2"
1880 REM ============================================================
1890 REM === VOICE 5: STEEL-STRING GUITAR - WALKING BASS ===
1900 VOICE 5
1910 INSTRUMENT 5,25
1920 VOL 5,.27
1930 STEREO 5,-.32
1940 REM Cycles 1-2: simple roots and fifths
1950 PLAY "D3:1 A2:1 A2:1 E3:1 B2:1 F#3:1 F#2:1 C#3:1 G2:1 D3:1 D3:1 A2:1 G2:1 D3:1 A2:1 E3:1 D3:1 A2:1 A2:1 E3:1 B2:1 F#3:1 F#2:1 C#3:1 G2:1 D3:1 D3:1 A2:1 G2:1 D3:1 A2:1 E3:1"
1960 TEMPO 100
1970 VOL 5,.29
1980 REM Cycles 3-4: walking approaches into each harmony
1990 PLAY "D3:1 A2:.5 G#2:.5 A2:1 E3:.5 A#2:.5 B2:1 F#3:.5 E2:.5 F#2:1 C#3:.5 F#2:.5 G2:1 D3:.5 C#3:.5 D3:1 A2:.5 F#2:.5 G2:1 D3:.5 G#2:.5 A2:1 E3:.5 C#3:.5 D3:1 A2:.5 G#2:.5 A2:1 E3:.5 A#2:.5 B2:1 F#3:.5 E2:.5 F#2:1 C#3:.5 F#2:.5 G2:1 D3:.5 C#3:.5 D3:1 A2:.5 F#2:.5 G2:1 D3:.5 G#2:.5 A2:1 E3:.5 C#3:.5"
2000 TEMPO 104
2010 REM Cycle 5: steady walking line
2020 PLAY "D3:1 A2:.5 G#2:.5 A2:1 E3:.5 A#2:.5 B2:1 F#3:.5 E2:.5 F#2:1 C#3:.5 F#2:.5 G2:1 D3:.5 C#3:.5 D3:1 A2:.5 F#2:.5 G2:1 D3:.5 G#2:.5 A2:1 E3:.5 C#3:.5"
2030 REM Cycles 6-7: long roots under the singing banjo
2040 PLAY "D3:2 A2:2 B2:2 F#2:2 G2:2 D3:2 G2:2 A2:2 D3:2 A2:2 B2:2 F#2:2 G2:2 D3:2 G2:2 A2:2"
2050 TEMPO 116
2060 VOL 5,.32
2070 REM Cycles 8-9: active bass drives the twin breaks
2080 PLAY "D3:.5 A2:.5 D3:.5 F#3:.5 A2:.5 E3:.5 A2:.5 C#3:.5 B2:.5 F#3:.5 B2:.5 D3:.5 F#2:.5 C#3:.5 F#2:.5 A2:.5 G2:.5 D3:.5 G2:.5 B2:.5 D3:.5 A2:.5 D3:.5 F#3:.5 G2:.5 D3:.5 G2:.5 B2:.5 A2:.5 E3:.5 A2:.5 C#3:.5 D3:.5 A2:.5 D3:.5 F#3:.5 A2:.5 E3:.5 A2:.5 C#3:.5 B2:.5 F#3:.5 B2:.5 D3:.5 F#2:.5 C#3:.5 F#2:.5 A2:.5 G2:.5 D3:.5 G2:.5 B2:.5 D3:.5 A2:.5 D3:.5 F#3:.5 G2:.5 D3:.5 G2:.5 B2:.5 A2:.5 E3:.5 A2:.5 C#3:.5"
2090 TEMPO 100
2100 VOL 5,.26
2110 REM Cycles 10-11: roots and fifths support the clawhammer groove
2120 PLAY "D3:1 A2:1 A2:1 E3:1 B2:1 F#3:1 F#2:1 C#3:1 G2:1 D3:1 D3:1 A2:1 G2:1 D3:1 A2:1 E3:1 D3:1 A2:1 A2:1 E3:1 B2:1 F#3:1 F#2:1 C#3:1 G2:1 D3:1 D3:1 A2:1 G2:1 D3:1 A2:1 E3:1"
2130 TEMPO 96
2140 VOL 5,.22
2150 REM Cycle 12: sparse foundation
2160 PLAY "D3:2 A2:2 B2:2 F#2:2 G2:2 D3:2 G2:2 A2:2"
2170 TEMPO 106
2180 VOL 5,.29
2190 REM Cycle 13: walking bass returns
2200 PLAY "D3:1 A2:.5 G#2:.5 A2:1 E3:.5 A#2:.5 B2:1 F#3:.5 E2:.5 F#2:1 C#3:.5 F#2:.5 G2:1 D3:.5 C#3:.5 D3:1 A2:.5 F#2:.5 G2:1 D3:.5 G#2:.5 A2:1 E3:.5 C#3:.5"
2210 TEMPO 114
2220 VOL 5,.33
2230 REM Cycle 14: final walking push
2240 PLAY "D3:.5 A2:.5 D3:.5 F#3:.5 A2:.5 E3:.5 A2:.5 C#3:.5 B2:.5 F#3:.5 B2:.5 D3:.5 F#2:.5 C#3:.5 F#2:.5 A2:.5 G2:.5 D3:.5 G2:.5 B2:.5 D3:.5 A2:.5 D3:.5 F#3:.5 G2:.5 D3:.5 G2:.5 B2:.5 A2:.5 E3:.5 A2:.5 C#3:.5"
2250 TEMPO 96
2260 PLAY "D3:2 A2:1 D3:1"
2270 REM ============================================================
2280 SOUND RESUME
2290 END
