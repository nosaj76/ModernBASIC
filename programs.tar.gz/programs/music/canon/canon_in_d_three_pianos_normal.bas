10 REM ============================================================
20 REM  PACHELBEL CANON IN D - THREE PIANOS AT NORMAL SPEED
30 REM  D MAJOR - 4/4 - CLEAR, RICH, AND FLOWING
40 REM  Composed by Johann Pachelbel, ca. 1680-1706, Public Domain
50 REM  Reorchestrated for ModernBASIC
60 REM  Piano I: lead melody
70 REM  Piano II: rhythmic broken chords and arpeggios
80 REM  Piano III: complete ground bass and bass variations
90 REM  Exactly three instruments, all using the PIANO voice
100 REM  Ground-bass introduction, fourteen cycles, final cadence
110 REM  Every piano is synchronized to exactly 244 beats
120 REM ============================================================
130 CLEAR
140 TEMPO 82
150 VOL .76
160 REM NORMAL CONCERT PACE WITH A CONTROLLED VARIATION ARC
170 REM ============================================================
180 REM === PIANO I: LEAD MELODY ===
190 VOICE 1
200 INSTRUMENT 1,"PIANO"
210 VOL 1,.24
220 STEREO 1,-.10
230 REM Introduction: the bass establishes the room before the lead
235 TEMPO 82
240 PLAY "R:16"
245 REM Cycle 1: canonical descending lead, with a breath before arrival
247 TEMPO 84
250 PLAY "F#5:2 E5:2 D5:2 C#5:2 B4:2 A4:2 B4:2 C#5:1.5 R:0.5"
255 REM Cycle 2: the first clear drink - D arrives across three octaves
257 TEMPO 86
258 PLAY "D5:2 C#5:2 B4:2 A4:2 G4:2 F#4:2 G4:2 E4:1.5 R:0.5"
260 REM Cycles 3-4: melody opens and gently moves forward
265 TEMPO 88
270 PLAY "D4:1 F#4:1 A4:1 G4:1 F#4:1 D4:1 F#4:1 E4:1 D4:1 B3:1 D4:1 A4:1 G4:1 B4:1 A4:1 G4:1 F#4:1 D4:1 E4:1 C#5:1 D5:1 F#5:1 A5:1 A4:1 B4:1 G4:1 A4:1 F#4:1 D4:1 D5:1 D5:1.5 C#5:0.5"
280 REM Cycle 5: flowing bridge
285 TEMPO 90
290 PLAY "D5:0.5 C#5:0.5 D5:0.5 D4:0.5 C#4:0.5 A4:0.5 E4:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 B4:0.5 C#5:0.5 F#5:0.5 A5:0.5 B5:0.5 G5:0.5 F#5:0.5 E5:0.5 G5:0.5 F#5:0.5 E5:0.5 D5:0.5 C#5:0.5 B4:0.5 A4:0.5 G4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 E4:0.5"
300 REM Cycles 6-7: broad central melody
305 TEMPO 92
310 PLAY "F#4:1 F#5:1 E5:1.75 R:1.25 D5:1 F#5:2 B5:2 A5:2 B5:2 C#6:2 D6:1 D5:1 C#5:1.75 R:1.25 B4:1 D5:2 D5:3 D5:1 D5:1 G5:1 E5:1 A5:1"
320 REM Cycle 8: energetic first peak variation
325 TEMPO 94
330 PLAY "A5:0.5 F#5:0.25 G5:0.25 A5:0.5 F#5:0.25 G5:0.25 A5:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 G5:0.25 F#5:0.5 D5:0.25 E5:0.25 F#5:0.5 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 A4:0.25 G4:0.25 A4:0.25 F#4:0.25 G4:0.25 A4:0.25 G4:0.5 B4:0.25 A4:0.25 G4:0.5 F#4:0.25 E4:0.25 F#4:0.25 E4:0.25 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 G4:0.5 B4:0.25 A4:0.25 B4:0.5 C#5:0.25 D5:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 G5:0.25 A5:0.25"
340 REM Cycle 9: strongest variation, still below 100 BPM
345 TEMPO 96
350 PLAY "F#5:0.5 D5:0.25 E5:0.25 F#5:0.5 E5:0.25 D5:0.25 E5:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 E5:0.25 D5:0.25 C#5:0.25 D5:0.5 B4:0.25 C#5:0.25 D5:0.5 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 F#4:0.25 E4:0.25 F#4:0.25 D5:0.25 C#5:0.25 D5:0.25 B4:0.5 D5:0.25 C#5:0.25 B4:0.5 A4:0.25 G4:0.25 A4:0.25 G4:0.25 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 B4:0.5 D5:0.25 C#5:0.25 D5:0.5 C#5:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 D5:0.25 C#5:0.25 D5:0.25 B4:0.25 C#5:0.25"
360 REM Cycles 10-11: controlled release, not a slow section
365 TEMPO 90
370 PLAY "D5:1 R:1 C#5:1 R:1 B4:1 R:1 D5:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1 R:1 A4:1 R:1 A4:1 R:1 F#4:1 R:1 A4:1 R:1 G4:1 R:1 F#4:1 R:1 G4:1 R:1 E5:1"
380 REM Cycle 12: return near the normal opening pace
385 TEMPO 86
390 PLAY "F#5:0.5 F#4:0.5 G4:0.5 F#4:0.5 E4:0.5 E5:0.5 F#5:0.5 E5:0.5 D5:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 A3:0.5 G3:0.5 A3:0.5 B3:0.5 B4:0.5 A4:0.5 B4:0.5 A4:0.5 A3:0.5 G3:0.5 A3:0.5 D4:0.5 B4:0.5 A4:0.5 B4:0.5 C#5:0.5 C#4:0.5 B3:0.5 C#4:0.5"
400 REM Cycle 13: clear recapitulation
405 TEMPO 84
410 PLAY "F#5:1 E5:1 D5:1 C#5:1 B4:1 A4:1 B4:1 C#5:1 D5:1 C#5:1 B4:1 A4:1 G4:1 F#4:1 G4:1 E4:1"
420 REM Cycle 14: modest broadening, still at normal speed
425 TEMPO 80
430 PLAY "D4:1 F#4:1 A4:1 D5:1 F#5:1 D5:1 A4:1 F#4:1 G4:1 B4:1 D5:1 G5:1 A4:1 C#5:1 E5:1 A5:1"
435 TEMPO 78
440 PLAY "D5:4"
450 REM ============================================================
460 REM === PIANO II: RHYTHM ===
470 VOICE 2
480 INSTRUMENT 2,"PIANO"
490 VOL 2,.17
500 STEREO 2,.28
510 REM Introduction: rhythm enters halfway through the bass opening
515 PLAY "R:8 D3:1 B3:1 D3:1 A3:1 D3:1 B3:1 E3:1 C#4:1"
517 REM Cycles 1-2: clear quarter-note broken chords
520 PLAY "D3:1 A3:1 E3:1 C#4:1 D3:1 F#3:1 C#3:1 A3:1 D3:1 B3:1 D3:1 A3:1 D3:1 B3:1 E3:1 C#4:1"
530 PLAY "D4:1 A3:1 E4:1 C#4:1 D4:1 F#3:1 C#4:1 A3:1 D4:1 B3:1 D4:1 A3:1 D4:1 B3:1 E4:1 C#4:1"
540 REM Cycles 3-4: clipped three-note pulses leave air for the lead
550 PLAY "D3:0.5 F#3:0.5 A3:0.5 R:0.5 E3:0.5 A3:0.5 C#4:0.5 R:0.5 D3:0.5 F#3:0.5 B3:0.5 R:0.5 C#3:0.5 F#3:0.5 A3:0.5 R:0.5 D3:0.5 G3:0.5 B3:0.5 R:0.5 D3:0.5 F#3:0.5 A3:0.5 R:0.5 D3:0.5 G3:0.5 B3:0.5 R:0.5 E3:0.5 A3:0.5 C#4:0.5 R:0.5"
560 PLAY "R:0.5 D3:0.5 F#3:0.5 A3:0.5 R:0.5 E3:0.5 A3:0.5 C#4:0.5 R:0.5 D3:0.5 F#3:0.5 B3:0.5 R:0.5 C#3:0.5 F#3:0.5 A3:0.5 R:0.5 D3:0.5 G3:0.5 B3:0.5 R:0.5 D3:0.5 F#3:0.5 A3:0.5 R:0.5 D3:0.5 G3:0.5 B3:0.5 R:0.5 E3:0.5 A3:0.5 C#4:0.5"
570 REM Cycles 5-9: rolling eighth-note rhythm drives the variations
580 PLAY "D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5"
590 PLAY "A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5 B3:0.5 F#3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5"
600 PLAY "D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5"
610 PLAY "A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5 B3:0.5 F#3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 A3:0.5 F#3:0.5 D3:0.5 F#3:0.5 B3:0.5 G3:0.5 D3:0.5 G3:0.5 C#4:0.5 A3:0.5 E3:0.5 A3:0.5"
620 PLAY "D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5 D3:0.5 F#3:0.5 B3:0.5 F#3:0.5 C#3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 D3:0.5 F#3:0.5 A3:0.5 F#3:0.5 D3:0.5 G3:0.5 B3:0.5 G3:0.5 E3:0.5 A3:0.5 C#4:0.5 A3:0.5"
630 REM Cycles 10-11: relax to articulated pulses
640 PLAY "D3:0.5 F#3:0.5 A3:0.5 R:0.5 E3:0.5 A3:0.5 C#4:0.5 R:0.5 D3:0.5 F#3:0.5 B3:0.5 R:0.5 C#3:0.5 F#3:0.5 A3:0.5 R:0.5 D3:0.5 G3:0.5 B3:0.5 R:0.5 D3:0.5 F#3:0.5 A3:0.5 R:0.5 D3:0.5 G3:0.5 B3:0.5 R:0.5 E3:0.5 A3:0.5 C#4:0.5 R:0.5"
650 PLAY "R:0.5 D3:0.5 F#3:0.5 A3:0.5 R:0.5 E3:0.5 A3:0.5 C#4:0.5 R:0.5 D3:0.5 F#3:0.5 B3:0.5 R:0.5 C#3:0.5 F#3:0.5 A3:0.5 R:0.5 D3:0.5 G3:0.5 B3:0.5 R:0.5 D3:0.5 F#3:0.5 A3:0.5 R:0.5 D3:0.5 G3:0.5 B3:0.5 R:0.5 E3:0.5 A3:0.5 C#4:0.5"
660 REM Cycles 12-13: simpler pulse supports the recapitulation
670 PLAY "D3:1 A3:1 E3:1 C#4:1 D3:1 F#3:1 C#3:1 A3:1 D3:1 B3:1 D3:1 A3:1 D3:1 B3:1 E3:1 C#4:1"
680 PLAY "A3:1 F#3:1 C#4:1 A3:1 B3:1 F#3:1 A3:1 C#3:1 B3:1 G3:1 A3:1 F#3:1 B3:1 G3:1 C#4:1 A3:1"
690 REM Cycle 14 and final rolled D chord
700 PLAY "D3:0.5 F#3:0.5 A3:0.5 D4:0.5 E3:0.5 A3:0.5 C#4:0.5 E4:0.5 D3:0.5 F#3:0.5 B3:0.5 D4:0.5 C#3:0.5 F#3:0.5 A3:0.5 C#4:0.5 D3:0.5 G3:0.5 B3:0.5 D4:0.5 D3:0.5 F#3:0.5 A3:0.5 D4:0.5 D3:0.5 G3:0.5 B3:0.5 D4:0.5 E3:0.5 A3:0.5 C#4:0.5 E4:0.5"
710 PLAY "D3:1 F#3:1 A3:1 D4:1"
720 REM ============================================================
730 REM === PIANO III: BASS ===
740 VOICE 3
750 INSTRUMENT 3,"PIANO"
760 VOL 3,.30
770 STEREO 3,0
780 REM Introduction: one complete ground cycle before the melody
785 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
787 REM Cycles 1-4: complete ground bass continues
790 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
800 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
810 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
820 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
830 REM Cycles 5-8: fifths and thirds broaden the piano bass
840 PLAY "D2:1 A2:1 A1:1 E2:1 B1:1 F#2:1 F#1:1 C#2:1 G1:1 D2:1 D2:1 A2:1 G1:1 D2:1 A1:1 E2:1"
850 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
860 PLAY "D2:1 A2:1 A1:1 E2:1 B1:1 F#2:1 F#1:1 C#2:1 G1:1 D2:1 D2:1 A2:1 G1:1 D2:1 A1:1 E2:1"
870 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
880 REM Cycles 9-10: restrained walking approach and warm thirds
890 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
900 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
910 REM Cycles 11-12: original ground returns
920 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
930 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
940 REM Cycle 13: final walking approach
950 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
960 REM Cycle 14 and final low tonic
970 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:1 D2:1 A1:1 E2:1"
980 PLAY "D2:4"
990 REM ============================================================
1000 SOUND RESUME
1010 END
