10 REM ============================================================
20 REM  PACHELBEL CANON IN D — THREE KOTO GUZHENG
30 REM  Composed Johann Pachelbel, ca. 1680-1706, Public Domain
40 REM  Based on timbral analysis of Mo Yun guzheng Canon video
50 REM  Key: D major (confirmed from spectral analysis, corr 0.900)
60 REM  Tempo: 86 BPM
70 REM  Fourteen 16-beat cycles + 4-beat final cadence = 228 beats
80 REM  Every voice synchronized to exactly 228 beats
90 REM
100 REM  THREE KOTO SoundFont (program 107) — one instrument, one room
110 REM  Voice 1: Lead melody (high strings)
120 REM  Voice 2: Harmony (mid strings, enters cycle 2)
130 REM  Voice 3: Bass ground (low strings, D3-A3 range)
140 REM  All centered (STEREO 0) for cohesive proximity
150 REM ============================================================
160 CLEAR
170 TEMPO 86
180 VOL .82
190 REM === GUZHENG 1: LEAD MELODY ===
200 VOICE 1
210 WAVE 1,"GUITAR"
220 VOL 1,.48
230 STEREO 1,0
240 REM Cycles 1-2: clear lyrical opening
250 PLAY "F#5:2 E5:2 D5:2 C#5:2 B4:2 A4:2 B4:2 C#5:2 D5:2 C#5:2 B4:2 A4:2 G4:2 F#4:2 G4:2 E4:2"
260 REM Cycles 3-4: the line opens outward
270 PLAY "D4:1 F#4:1 A4:1 G4:1 F#4:1 D4:1 F#4:1 E4:1 D4:1 B3:1 D4:1 A4:1 G4:1 B4:1 A4:1 G4:1 F#4:1 D4:1 E4:1 C#5:1 D5:1 F#5:1 A5:1 A4:1 B4:1 G4:1 A4:1 F#4:1 D4:1 D5:1 D5:1.5 C#5:0.5"
280 REM Cycle 5: flowing bridge
290 PLAY "D5:0.5 C#5:0.5 D5:0.5 D4:0.5 C#4:0.5 A4:0.5 E4:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 B4:0.5 C#5:0.5 F#5:0.5 A5:0.5 B5:0.5 G5:0.5 F#5:0.5 E5:0.5 G5:0.5 F#5:0.5 E5:0.5 D5:0.5 C#5:0.5 B4:0.5 A4:0.5 G4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 E4:0.5"
300 REM Cycles 6-7: broad central melody
310 PLAY "F#4:1 F#5:1 E5:1.75 R:1.25 D5:1 F#5:2 B5:2 A5:2 B5:2 C#6:2 D6:1 D5:1 C#5:1.75 R:1.25 B4:1 D5:2 D5:3 D5:1 D5:1 G5:1 E5:1 A5:1"
320 REM Cycle 8: first quick variation
330 PLAY "A5:0.5 F#5:0.25 G5:0.25 A5:0.5 F#5:0.25 G5:0.25 A5:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 G5:0.25 F#5:0.5 D5:0.25 E5:0.25 F#5:0.5 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 A4:0.25 G4:0.25 A4:0.25 F#4:0.25 G4:0.25 A4:0.25 G4:0.5 B4:0.25 A4:0.25 G4:0.5 F#4:0.25 E4:0.25 F#4:0.25 E4:0.25 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 G4:0.5 B4:0.25 A4:0.25 B4:0.5 C#5:0.25 D5:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 G5:0.25 A5:0.25"
340 REM Cycle 9: second quick variation
350 PLAY "F#5:0.5 D5:0.25 E5:0.25 F#5:0.5 E5:0.25 D5:0.25 E5:0.25 C#5:0.25 D5:0.25 E5:0.25 F#5:0.25 E5:0.25 D5:0.25 C#5:0.25 D5:0.5 B4:0.25 C#5:0.25 D5:0.5 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 F#4:0.25 E4:0.25 F#4:0.25 D5:0.25 C#5:0.25 D5:0.25 B4:0.5 D5:0.25 C#5:0.25 B4:0.5 A4:0.25 G4:0.25 A4:0.25 G4:0.25 F#4:0.25 G4:0.25 A4:0.25 B4:0.25 C#5:0.25 D5:0.25 B4:0.5 D5:0.25 C#5:0.25 D5:0.5 C#5:0.25 B4:0.25 C#5:0.25 D5:0.25 E5:0.25 D5:0.25 C#5:0.25 D5:0.25 B4:0.25 C#5:0.25"
360 REM Cycles 10-11: space and breath after the peak
370 PLAY "D5:1 R:1 C#5:1 R:1 B4:1 R:1 D5:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1 R:1 A4:1 R:1 A4:1 R:1 F#4:1 R:1 A4:1 R:1 G4:1 R:1 F#4:1 R:1 G4:1 R:1 E5:1"
380 REM Cycle 12: intimate return
390 PLAY "F#5:0.5 F#4:0.5 G4:0.5 F#4:0.5 E4:0.5 E5:0.5 F#5:0.5 E5:0.5 D5:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 A3:0.5 G3:0.5 A3:0.5 B3:0.5 B4:0.5 A4:0.5 B4:0.5 A4:0.5 A3:0.5 G3:0.5 A3:0.5 D4:0.5 B4:0.5 A4:0.5 B4:0.5 C#5:0.5 C#4:0.5 B3:0.5 C#4:0.5"
400 REM Cycle 13: concise recapitulation
410 PLAY "F#5:1 E5:1 D5:1 C#5:1 B4:1 A4:1 B4:1 C#5:1 D5:1 C#5:1 B4:1 A4:1 G4:1 F#4:1 G4:1 E4:1"
420 REM Cycle 14: cadence
430 PLAY "D4:1 F#4:1 A4:1 D5:1 F#5:1 D5:1 A4:1 F#4:1 G4:1 B4:1 D5:1 G5:1 A4:1 C#5:1 E5:1 A5:1"
440 PLAY "D5:4"
450 REM === GUZHENG 2: HARMONY — MID STRINGS ===
460 VOICE 2
470 WAVE 2,"GUITAR"
480 VOL 2,.30
490 STEREO 2,0
500 REM Cycles 1-2: enters at cycle 2
510 PLAY "R:16 D4:2 C#4:2 B3:2 A3:2 G3:2 F#3:2 G3:2 E3:2"
520 REM Cycles 3-4: arpeggiated chord support
530 PLAY "D3:1 F#3:1 A3:1 G3:1 F#3:1 D3:1 F#3:1 E3:1 D3:1 B2:1 D3:1 A3:1 G3:1 B3:1 A3:1 G3:1 F#3:1 D3:1 E3:1 C#4:1 D4:1 F#4:1 A4:1 A3:1 B3:1 G3:1 A3:1 F#3:1 D3:1 D4:1 D4:1.5 C#4:0.5"
540 REM Cycle 5: flowing bridge harmony
550 PLAY "D4:0.5 C#4:0.5 D4:0.5 D3:0.5 C#3:0.5 A3:0.5 E3:0.5 F#3:0.5 D3:0.5 D4:0.5 C#4:0.5 B3:0.5 C#4:0.5 F#4:0.5 A4:0.5 B4:0.5 G4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 E4:0.5 D4:0.5 C#4:0.5 B3:0.5 A3:0.5 G3:0.5 F#3:0.5 E3:0.5 G3:0.5 F#3:0.5 E3:0.5"
560 REM Cycles 6-7: broad central harmony
570 PLAY "F#3:1 F#4:1 E4:1.75 R:1.25 D4:1 F#4:2 B4:2 A4:2 B4:2 C#5:2 D5:1 D4:1 C#4:1.75 R:1.25 B3:1 D4:2 D4:3 D4:1 D4:1 G4:1 E4:1 A4:1"
580 REM Cycle 8: harmony under quick variation
590 PLAY "A4:0.5 F#4:0.25 G4:0.25 A4:0.5 F#4:0.25 G4:0.25 A4:0.25 A3:0.25 B3:0.25 C#4:0.25 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 F#4:0.5 D4:0.25 E4:0.25 F#4:0.5 F#3:0.25 G3:0.25 A3:0.25 B3:0.25 A3:0.25 G3:0.25 A3:0.25 F#3:0.25 G3:0.25 A3:0.25 G3:0.5 B3:0.25 A3:0.25 G3:0.5 F#3:0.25 E3:0.25 F#3:0.25 E3:0.25 D3:0.25 E3:0.25 F#3:0.25 G3:0.25 A3:0.25 B3:0.25 G3:0.5 B3:0.25 A3:0.25 B3:0.5 C#4:0.25 D4:0.25 A3:0.25 B3:0.25 C#4:0.25 D4:0.25 E4:0.25 F#4:0.25 G4:0.25 A4:0.25"
600 REM Cycle 9: harmony under second variation
610 PLAY "F#4:0.5 D4:0.25 E4:0.25 F#4:0.5 E4:0.25 D4:0.25 E4:0.25 C#4:0.25 D4:0.25 E4:0.25 F#4:0.25 E4:0.25 D4:0.25 C#4:0.25 D4:0.5 B3:0.25 C#4:0.25 D4:0.5 D3:0.25 E3:0.25 F#3:0.25 G3:0.25 F#3:0.25 E3:0.25 F#3:0.25 D4:0.25 C#4:0.25 D4:0.25 B3:0.5 D4:0.25 C#4:0.25 B3:0.5 A3:0.25 G3:0.25 A3:0.25 G3:0.25 F#3:0.25 G3:0.25 A3:0.25 B3:0.25 C#4:0.25 D4:0.25 B3:0.5 D4:0.25 C#4:0.25 D4:0.5 C#4:0.25 B3:0.25 C#4:0.25 D4:0.25 E4:0.25 D4:0.25 C#4:0.25 D4:0.25 B3:0.25 C#4:0.25"
620 REM Cycles 10-11: sparse harmony
630 PLAY "D4:1 R:1 C#4:1 R:1 B3:1 R:1 D4:1 R:1 D3:1 R:1 D3:1 R:1 D3:1 R:1 D3:1 R:1 R:1 A3:1 R:1 A3:1 R:1 F#3:1 R:1 A3:1 R:1 G3:1 R:1 F#3:1 R:1 G3:1 R:1 E4:1"
640 REM Cycle 12: intimate harmony
650 PLAY "F#4:0.5 F#3:0.5 G3:0.5 F#3:0.5 E3:0.5 E4:0.5 F#4:0.5 E4:0.5 D4:0.5 F#3:0.5 D3:0.5 D4:0.5 C#4:0.5 A2:0.5 G2:0.5 A2:0.5 B2:0.5 B3:0.5 A3:0.5 B3:0.5 A3:0.5 A2:0.5 G2:0.5 A2:0.5 D3:0.5 B3:0.5 A3:0.5 B3:0.5 C#4:0.5 C#3:0.5 B2:0.5 C#3:0.5"
660 REM Cycle 13: recapitulation harmony
670 PLAY "F#4:1 E4:1 D4:1 C#4:1 B3:1 A3:1 B3:1 C#4:1 D4:1 C#4:1 B3:1 A3:1 G3:1 F#3:1 G3:1 E3:1"
680 REM Cycle 14: cadence harmony
690 PLAY "D3:1 F#3:1 A3:1 D4:1 F#4:1 D4:1 A3:1 F#3:1 G3:1 B3:1 D4:1 G4:1 A3:1 C#4:1 E4:1 A4:1"
700 PLAY "D4:4"
710 REM === GUZHENG 3: BASS GROUND — LOW STRINGS ===
720 VOICE 3
730 INSTRUMENT 3,"KOTO"
740 VOL 3,.36
750 STEREO 3,0
760 REM Cycles 1-2: plain ground
770 PLAY "D3:2 A2:2 B2:2 F#2:2 G2:2 D3:2 G2:2 A2:2"
780 PLAY "D3:2 A2:2 B2:2 F#2:2 G2:2 D3:2 G2:2 A2:2"
790 REM Cycles 3-5: walking bass
800 PLAY "D3:1 A3:1 A2:1 E3:1 B2:1 F#3:1 F#2:1 C#3:1 G2:1 D3:1 D3:1 A3:1 G2:1 D3:1 A2:1 E3:1"
810 PLAY "D3:1 F#3:1 A2:1 C#3:1 B2:1 D3:1 F#2:1 A2:1 G2:1 B2:1 D3:1 F#3:1 G2:1 B2:1 A2:1 C#3:1"
820 PLAY "D3:1 A3:1 A2:1 E3:1 B2:1 F#3:1 F#2:1 C#3:1 G2:1 D3:1 D3:1 A3:1 G2:1 D3:1 A2:1 E3:1"
830 REM Cycle 6: chromatic approaches
840 PLAY "D3:1 C#3:1 A2:1 A#2:1 B2:1 A2:1 F#2:1 F2:1 G2:1 F#2:1 D3:1 F#2:1 G2:1 G#2:1 A2:1 C#3:1"
850 REM Cycles 7-8: syncopated under climax
860 PLAY "D3:1.5 A3:0.5 A2:1.5 E3:0.5 B2:1.5 F#3:0.5 F#2:1.5 C#3:0.5 G2:1.5 D3:0.5 D3:1.5 A3:0.5 G2:1.5 D3:0.5 A2:1.5 E3:0.5"
870 PLAY "D3:0.5 A3:1.5 A2:0.5 E3:1.5 B2:0.5 F#3:1.5 F#2:0.5 C#3:1.5 G2:0.5 D3:1.5 D3:0.5 A3:1.5 G2:0.5 D3:1.5 A2:0.5 E3:1.5"
880 REM Cycles 9-10: walking line
890 PLAY "D3:1 C#3:1 A2:1 A#2:1 B2:1 A2:1 F#2:1 F2:1 G2:1 F#2:1 D3:1 F#2:1 G2:1 G#2:1 A2:1 C#3:1"
900 PLAY "D3:1 F#3:1 A2:1 C#3:1 B2:1 D3:1 F#2:1 A2:1 G2:1 B2:1 D3:1 F#3:1 G2:1 B2:1 A2:1 C#3:1"
910 REM Cycles 11-12: return to plain ground
920 PLAY "D3:2 A2:2 B2:2 F#2:2 G2:2 D3:2 G2:2 A2:2"
930 PLAY "D3:2 A2:2 B2:2 F#2:2 G2:2 D3:2 G2:2 A2:2"
940 REM Cycle 13: last walking approach
950 PLAY "D3:1 C#3:1 A2:1 A#2:1 B2:1 A2:1 F#2:1 F2:1 G2:1 F#2:1 D3:1 F#2:1 G2:1 G#2:1 A2:1 C#3:1"
960 REM Cycle 14: final ground and cadence
970 PLAY "D3:2 A2:2 B2:2 F#2:2 G2:2 D3:2 G2:1 D3:1 A2:1 E3:1"
980 PLAY "D3:4"
990 SOUND RESUME
1000 END