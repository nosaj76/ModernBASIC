10 REM ============================================================
20 REM  PACHELBEL CANON IN D - SLOW, RICH FOUR-PIANO NOCTURNE
30 REM  D MAJOR - 4/4 - WARM, SPACIOUS, AND LYRICAL
40 REM  Composed by Johann Pachelbel, ca. 1680-1706, Public Domain
50 REM  Reorchestrated for ModernBASIC
60 REM  Piano I: restrained singing melody
70 REM  Piano II: gentle rolling arpeggios
80 REM  Piano III: warm inner harmony and suspensions
90 REM  Piano IV: rounded ground bass
100 REM  No chimes, no doubled lead, no constant high layer
110 REM  Fourteen 16-beat cycles plus a 4-beat final cadence
120 REM  Every piano is synchronized to exactly 228 beats
130 REM ============================================================
140 CLEAR
150 TEMPO 54
160 VOL .70
170 REM RICHNESS COMES FROM REGISTER, VOICE LEADING, AND RESONANCE
180 REM ============================================================
190 REM === PIANO I: RESTRAINED, HUMANIZED SINGING LEAD ===
200 VOICE 1
210 INSTRUMENT 1,"PIANO"
220 VOL 1,.20
230 STEREO 1,-.06
240 REM Cycles 1-2: LARGHETTO - small phrase-level breaths
241 TEMPO 54
242 PLAY "F#5:2 E5:2 D5:2 C#5:2"
243 TEMPO 56
244 PLAY "B4:2 A4:2 B4:2 C#5:2"
245 TEMPO 57
246 PLAY "D5:2 C#5:2 B4:2 A4:2"
247 TEMPO 55
248 PLAY "G4:2 F#4:2 G4:2 E4:2"
250 REM Cycles 3-4: POCO PIU MOSSO, leaning and relaxing naturally
251 TEMPO 58
252 PLAY "D4:1 F#4:1 A4:1 G4:1 F#4:1 D4:1 F#4:1 E4:1"
253 TEMPO 60
254 PLAY "D4:1 B3:1 D4:1 A4:1 G4:1 B4:1 A4:1 G4:1"
255 TEMPO 61
256 PLAY "F#4:1 D4:1 E4:1 C#5:1 D5:1 F#5:1 A5:1 A4:1"
257 TEMPO 59
258 PLAY "B4:1 G4:1 A4:1 F#4:1 D4:1 D5:1 D5:1.5 C#5:0.5"
260 REM Cycle 5: delicate flowing bridge, gently pressing forward
261 TEMPO 62
262 PLAY "D5:0.5 C#5:0.5 D5:0.5 D4:0.5 C#4:0.5 A4:0.5 E4:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 B4:0.5 C#5:0.5 F#5:0.5 A5:0.5 B5:0.5"
263 TEMPO 64
264 PLAY "G5:0.5 F#5:0.5 E5:0.5 G5:0.5 F#5:0.5 E5:0.5 D5:0.5 C#5:0.5 B4:0.5 A4:0.5 G4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 E4:0.5"
270 REM Cycles 6-7: CON MOTO - broad song with a breathing release
271 TEMPO 66
272 PLAY "F#4:1 F#5:1 E5:1.75 R:1.25 D5:1 F#5:2"
273 TEMPO 68
274 PLAY "B5:2 A5:2 B5:2 C#6:2"
275 TEMPO 69
276 PLAY "D6:1 D5:1 C#5:1.75 R:1.25 B4:1 D5:2"
277 TEMPO 67
278 PLAY "D5:3 D5:1 D5:1 G5:1 E5:1 A5:1"
280 REM Cycle 8: lyrical rise toward the central crest
281 TEMPO 70
282 PLAY "A5:1 F#5:1 G5:1 A5:1 F#5:1 D5:1 E5:1 F#5:1"
283 TEMPO 72
284 PLAY "G5:1 B5:1 A5:1 G5:1 F#5:1 E5:1 D5:1 C#5:1"
286 REM Cycle 9: animated peak, then a slight release
287 TEMPO 74
288 PLAY "F#5:1 D5:1 E5:1 F#5:1 E5:1 C#5:1 D5:1 E5:1"
289 TEMPO 72
290 PLAY "F#5:1 E5:1 D5:1 C#5:1 D5:1 B4:1 C#5:1 D5:1"
300 REM Cycles 10-11: gradual return with unforced rubato
301 TEMPO 69
302 PLAY "D5:1 R:1 C#5:1 R:1 B4:1 R:1 D5:1 R:1"
303 TEMPO 67
304 PLAY "D4:1 R:1 D4:1 R:1 D4:1 R:1 D4:1 R:1"
305 TEMPO 65
306 PLAY "R:1 A4:1 R:1 A4:1 R:1 F#4:1 R:1 A4:1"
307 TEMPO 63
308 PLAY "R:1 G4:1 R:1 F#4:1 R:1 G4:1 R:1 E5:1"
310 REM Cycle 12: RITARDANDO - quiet return toward the opening mood
311 TEMPO 60
312 PLAY "F#5:0.5 F#4:0.5 G4:0.5 F#4:0.5 E4:0.5 E5:0.5 F#5:0.5 E5:0.5 D5:0.5 F#4:0.5 D4:0.5 D5:0.5 C#5:0.5 A3:0.5 G3:0.5 A3:0.5"
313 TEMPO 58
314 PLAY "B3:0.5 B4:0.5 A4:0.5 B4:0.5 A4:0.5 A3:0.5 G3:0.5 A3:0.5 D4:0.5 B4:0.5 A4:0.5 B4:0.5 C#5:0.5 C#4:0.5 B3:0.5 C#4:0.5"
320 REM Cycle 13: broaden each half of the recapitulation
321 TEMPO 56
322 PLAY "F#5:1 E5:1 D5:1 C#5:1 B4:1 A4:1 B4:1 C#5:1"
323 TEMPO 54
324 PLAY "D5:1 C#5:1 B4:1 A4:1 G4:1 F#4:1 G4:1 E4:1"
330 REM Cycle 14: final ritardando with a very broad last resonance
331 TEMPO 52
332 PLAY "D4:1 F#4:1 A4:1 D5:1 F#5:1 D5:1 A4:1 F#4:1"
333 TEMPO 48
334 PLAY "G4:1 B4:1 D5:1 G5:1 A4:1 C#5:1 E5:1 A5:1"
335 TEMPO 44
336 PLAY "D5:4"
440 REM ============================================================
450 REM === PIANO II: GENTLE ROLLING ARPEGGIOS ===
460 VOICE 2
470 INSTRUMENT 2,"PIANO"
480 VOL 2,.14
490 STEREO 2,-.24
500 REM Cycles 1-5: spacious two-note shapes for each harmony
510 PLAY "D3:1 A3:1 E3:1 C#4:1 D3:1 F#3:1 C#3:1 A3:1 D3:1 B3:1 D3:1 A3:1 D3:1 B3:1 E3:1 C#4:1"
520 PLAY "A3:1 F#3:1 C#4:1 A3:1 B3:1 F#3:1 A3:1 C#3:1 B3:1 G3:1 A3:1 F#3:1 B3:1 G3:1 C#4:1 A3:1"
530 PLAY "D3:1 A3:1 E3:1 C#4:1 D3:1 F#3:1 C#3:1 A3:1 D3:1 B3:1 D3:1 A3:1 D3:1 B3:1 E3:1 C#4:1"
540 PLAY "A3:1 F#3:1 C#4:1 A3:1 B3:1 F#3:1 A3:1 C#3:1 B3:1 G3:1 A3:1 F#3:1 B3:1 G3:1 C#4:1 A3:1"
550 PLAY "D3:1 A3:1 E3:1 C#4:1 D3:1 F#3:1 C#3:1 A3:1 D3:1 B3:1 D3:1 A3:1 D3:1 B3:1 E3:1 C#4:1"
560 REM Cycles 6-8: the arpeggio blooms into soft eighth notes
570 PLAY "D3:0.5 F#3:0.5 A3:0.5 D4:0.5 E3:0.5 A3:0.5 C#4:0.5 E4:0.5 D3:0.5 F#3:0.5 B3:0.5 D4:0.5 C#3:0.5 F#3:0.5 A3:0.5 C#4:0.5 D3:0.5 G3:0.5 B3:0.5 D4:0.5 D3:0.5 F#3:0.5 A3:0.5 D4:0.5 D3:0.5 G3:0.5 B3:0.5 D4:0.5 E3:0.5 A3:0.5 C#4:0.5 E4:0.5"
580 PLAY "D4:0.5 A3:0.5 F#3:0.5 D3:0.5 E4:0.5 C#4:0.5 A3:0.5 E3:0.5 D4:0.5 B3:0.5 F#3:0.5 D3:0.5 C#4:0.5 A3:0.5 F#3:0.5 C#3:0.5 D4:0.5 B3:0.5 G3:0.5 D3:0.5 D4:0.5 A3:0.5 F#3:0.5 D3:0.5 D4:0.5 B3:0.5 G3:0.5 D3:0.5 E4:0.5 C#4:0.5 A3:0.5 E3:0.5"
590 PLAY "D3:0.5 F#3:0.5 A3:0.5 D4:0.5 E3:0.5 A3:0.5 C#4:0.5 E4:0.5 D3:0.5 F#3:0.5 B3:0.5 D4:0.5 C#3:0.5 F#3:0.5 A3:0.5 C#4:0.5 D3:0.5 G3:0.5 B3:0.5 D4:0.5 D3:0.5 F#3:0.5 A3:0.5 D4:0.5 D3:0.5 G3:0.5 B3:0.5 D4:0.5 E3:0.5 A3:0.5 C#4:0.5 E4:0.5"
600 REM Cycles 9-13: fold back into the slower rolling pattern
610 PLAY "A3:1 F#3:1 C#4:1 A3:1 B3:1 F#3:1 A3:1 C#3:1 B3:1 G3:1 A3:1 F#3:1 B3:1 G3:1 C#4:1 A3:1"
620 PLAY "D3:1 A3:1 E3:1 C#4:1 D3:1 F#3:1 C#3:1 A3:1 D3:1 B3:1 D3:1 A3:1 D3:1 B3:1 E3:1 C#4:1"
630 PLAY "A3:1 F#3:1 C#4:1 A3:1 B3:1 F#3:1 A3:1 C#3:1 B3:1 G3:1 A3:1 F#3:1 B3:1 G3:1 C#4:1 A3:1"
640 PLAY "D3:1 A3:1 E3:1 C#4:1 D3:1 F#3:1 C#3:1 A3:1 D3:1 B3:1 D3:1 A3:1 D3:1 B3:1 E3:1 C#4:1"
650 PLAY "A3:1 F#3:1 C#4:1 A3:1 B3:1 F#3:1 A3:1 C#3:1 B3:1 G3:1 A3:1 F#3:1 B3:1 G3:1 C#4:1 A3:1"
660 REM Cycle 14 and final rolled tonic
670 PLAY "D3:1 F#3:1 A3:1 D4:1 E3:1 A3:1 C#4:1 E4:1 D3:1 G3:1 B3:1 D4:1 E3:1 A3:1 C#4:1 A3:1"
680 PLAY "D3:1 F#3:1 A3:1 D4:1"
690 REM ============================================================
700 REM === PIANO III: WARM INNER HARMONY ===
710 VOICE 3
720 INSTRUMENT 3,"PIANO"
730 VOL 3,.10
740 STEREO 3,.24
750 REM Long chord tones create body without rhythmic clutter
760 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
770 PLAY "A4:2 E4:2 D4:2 C#4:2 B3:2 A3:2 B3:2 E4:2"
780 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
790 PLAY "D4:2 C#4:2 B3:2 A3:2 G3:2 F#3:2 G3:2 A3:2"
800 PLAY "A4:2 E4:2 F#4:2 C#4:2 D4:2 A4:2 B4:2 E4:2"
810 REM Cycles 6-9: gentle suspensions lift the center
820 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
830 PLAY "A4:2 A4:2 B4:2 A4:2 B4:2 A4:2 G4:2 E4:2"
840 PLAY "A4:2 E4:2 D4:2 C#4:2 B3:2 A3:2 B3:2 E4:2"
850 PLAY "D4:2 C#4:2 B3:2 A3:2 G3:2 F#3:2 G3:2 A3:2"
860 REM Cycles 10-13: descend softly toward home
870 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
880 PLAY "D4:2 C#4:2 B3:2 A3:2 G3:2 F#3:2 G3:2 A3:2"
890 PLAY "F#4:2 E4:2 F#4:2 C#4:2 D4:2 F#4:2 B3:2 C#4:2"
900 PLAY "A4:2 E4:2 D4:2 C#4:2 B3:2 A3:2 B3:2 E4:2"
910 REM Cycle 14 and final inner resolution
920 PLAY "F#4:2 E4:2 D4:2 C#4:2 B3:2 A3:2 G3:2 E4:2"
930 PLAY "D4:4"
940 REM ============================================================
950 REM === PIANO IV: WARM, ROUNDED GROUND BASS ===
960 VOICE 4
970 INSTRUMENT 4,"PIANO"
980 VOL 4,.24
990 STEREO 4,0
1000 REM Cycles 1-4: deep, simple ground lets the piano resonate
1010 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1020 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1030 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1040 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1050 REM Cycles 5-8: open fifths broaden the central resonance
1060 PLAY "D2:1 A2:1 A1:1 E2:1 B1:1 F#2:1 F#1:1 C#2:1 G1:1 D2:1 D2:1 A2:1 G1:1 D2:1 A1:1 E2:1"
1070 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
1080 PLAY "D2:1 A2:1 A1:1 E2:1 B1:1 F#2:1 F#1:1 C#2:1 G1:1 D2:1 D2:1 A2:1 G1:1 D2:1 A1:1 E2:1"
1090 PLAY "D2:1 F#2:1 A1:1 C#2:1 B1:1 D2:1 F#1:1 A1:1 G1:1 B1:1 D2:1 F#2:1 G1:1 B1:1 A1:1 C#2:1"
1100 REM Cycles 9-12: return to the calm original bass
1110 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1120 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1130 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1140 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:2 A1:2"
1150 REM Cycle 13: one restrained chromatic approach
1160 PLAY "D2:1 C#2:1 A1:1 A#1:1 B1:1 A1:1 F#1:1 F1:1 G1:1 F#1:1 D2:1 F#1:1 G1:1 G#1:1 A1:1 C#2:1"
1170 REM Cycle 14 and final low D
1180 PLAY "D2:2 A1:2 B1:2 F#1:2 G1:2 D2:2 G1:1 D2:1 A1:1 E2:1"
1190 PLAY "D2:4"
1200 REM ============================================================
1210 SOUND RESUME
1220 END
