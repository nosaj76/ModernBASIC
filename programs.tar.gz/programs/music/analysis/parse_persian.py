#!/usr/bin/env python3
"""Parse Persian .bas files and extract musical features for analysis."""
import re, os, json
from collections import Counter

MUSIC_DIR = "/home/jason/projects/OSprojects/BASIC/modernbasic-0.8.2/programs/music"

files = [
    "persian_silk_road_journey.bas",
    "persian_silk_road_journey2.bas",
    "persian_sufi_trance_isfahan.bas",
    "persian_sufi_trance_isfahan2.bas",
    "persian_sufi_trance_isfahan3.bas",
    "persian_whirling_trance_116bpm.bas",
]

# Note name to pitch class
NOTE_TO_PC = {
    'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3,
    'E': 4, 'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8,
    'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11,
}

PC_NAMES = ['C', 'C#/Db', 'D', 'D#/Eb', 'E', 'F', 'F#/Gb', 'G', 'G#/Ab', 'A', 'A#/Bb', 'B']

# Pattern to match notes like D5:2@96 or D5:.5@100 or D5:1@58 or R:8
NOTE_RE = re.compile(r'([A-G][#b]?)(\d)(?::([\d.]+))?(?:@(\d+))?')
REST_RE = re.compile(r'R:(\d+(?:\.\d+)?)')

def parse_bas(filepath):
    with open(filepath) as f:
        lines = f.readlines()
    
    result = {
        'filename': os.path.basename(filepath),
        'title': '', 'tempo': 0, 'beats': 0, 'duration_str': '',
        'maqam': '', 'key_info': '', 'form': '',
        'soundfont': '', 'instruments': {},
        'voices': 0,
        'note_counts': Counter(),
        'pitch_classes': Counter(),
        'velocity_range': (128, 0),
        'rest_beats': 0,
        'total_note_beats': 0,
        'phrase_strings': 0,
        'play_statements': 0,
    }
    
    for line in lines:
        line = line.strip()
        # Extract tempo
        m = re.search(r'TEMPO\s+(\d+)', line, re.IGNORECASE)
        if m:
            result['tempo'] = int(m.group(1))
        
        # Extract beats from REM
        m = re.search(r'(\d+)\s+BEATS', line, re.IGNORECASE)
        if m:
            result['beats'] = int(m.group(1))
        
        # Title
        if 'PRINT' in line.upper() and '"' in line:
            m = re.search(r'PRINT\s+"([^"]+)"', line, re.IGNORECASE)
            if m and not result['title']:
                result['title'] = m.group(1)
        
        # Maqam info from REM lines
        if line.startswith('REM'):
            if 'HOMAYUN' in line or 'BAYAT' in line or 'CHAHARGAH' in line or 'ESFAHAN' in line.upper():
                result['maqam'] = line.strip()
            if 'AQAZ' in line or 'IST' in line or 'SHAHED' in line or 'FINALIS' in line:
                result['key_info'] = line.strip()
            if 'DARAMAD' in line or 'INVOCATION' in line or 'LOCK' in line:
                result['form'] = line.strip()
        
        # Soundfont
        m = re.search(r'SOUNDFONT\s+(.+)', line, re.IGNORECASE)
        if m:
            result['soundfont'] = m.group(1).strip()
        
        # Instruments
        m = re.search(r'INSTRUMENT\s+(\d+)[,\s]+(.+?)(?:\s*$)', line, re.IGNORECASE)
        if m:
            voice = int(m.group(1))
            instr = m.group(2).strip().strip('"')
            # Check next line for REM comment
            idx = lines.index(line + '\n') if line + '\n' in lines else -1
            comment = ''
            if idx >= 0 and idx + 1 < len(lines):
                next_line = lines[idx+1].strip()
                if next_line.startswith('REM') and 'VOICE' in next_line:
                    comment = next_line
            result['instruments'][voice] = f"{instr} | {comment}"
        
        # Parse PLAY statements for note data
        if 'PLAY' in line.upper() and '$' in line:
            result['play_statements'] += 1
            # Find all variable references and extract notes from string literals
            # Also count phrase string definitions
        
        # Parse string assignments for notes
        if '=' in line and '"' in line and '$' in line.split('=')[0]:
            var_part = line.split('=')[0].strip()
            if var_part.endswith('$'):
                result['phrase_strings'] += 1
                # Extract all notes from the string
                for m in NOTE_RE.finditer(line):
                    note = m.group(1)
                    octave = int(m.group(2))
                    dur = float(m.group(3)) if m.group(3) else 1.0
                    vel = int(m.group(4)) if m.group(4) else 80
                    
                    pc = NOTE_TO_PC.get(note, -1)
                    if pc >= 0:
                        result['note_counts'][(note, octave)] += 1
                        result['pitch_classes'][pc] += 1
                        result['total_note_beats'] += dur
                        
                        vmin, vmax = result['velocity_range']
                        result['velocity_range'] = (min(vmin, vel), max(vmax, vel))
                
                # Count rests
                for m in REST_RE.finditer(line):
                    result['rest_beats'] += float(m.group(1))
    
    return result

# Parse all files
results = []
for f in files:
    path = os.path.join(MUSIC_DIR, f)
    if os.path.exists(path):
        r = parse_bas(path)
        results.append(r)
    else:
        print(f"NOT FOUND: {path}")

# Print comparative analysis
for r in results:
    print(f"\n{'='*70}")
    print(f"FILE: {r['filename']}")
    print(f"{'='*70}")
    print(f"  Title: {r['title']}")
    print(f"  Tempo: {r['tempo']} BPM")
    print(f"  Beats: {r['beats']}")
    duration_sec = r['beats'] * 60 / r['tempo'] if r['tempo'] > 0 else 0
    print(f"  Duration: {duration_sec:.0f}s ({duration_sec/60:.1f} min)")
    print(f"  Maqam: {r['maqam']}")
    print(f"  Key info: {r['key_info']}")
    print(f"  Form: {r['form']}")
    print(f"  Soundfont: {r['soundfont']}")
    print(f"  Voices: {len(r['instruments'])}")
    print(f"  Play statements: {r['play_statements']}")
    print(f"  Phrase strings: {r['phrase_strings']}")
    print(f"  Velocity range: {r['velocity_range'][0]}-{r['velocity_range'][1]}")
    print(f"  Total note beats: {r['total_note_beats']:.1f}")
    print(f"  Rest beats: {r['rest_beats']:.1f}")
    
    print(f"\n  PITCH CLASS DISTRIBUTION:")
    total_pc = sum(r['pitch_classes'].values()) or 1
    for pc in range(12):
        count = r['pitch_classes'][pc]
        pct = count / total_pc * 100
        bar = '#' * int(pct)
        print(f"    {PC_NAMES[pc]:6s}: {count:4d} ({pct:5.1f}%) {bar}")
    
    print(f"\n  TOP NOTES (by octave):")
    for (note, octv), count in r['note_counts'].most_common(15):
        print(f"    {note}{octv}: {count}")
    
    print(f"\n  INSTRUMENTS:")
    for v in sorted(r['instruments'].keys()):
        print(f"    V{v:2d}: {r['instruments'][v]}")

# Cross-file comparison
print(f"\n\n{'='*70}")
print("CROSS-FILE COMPARISON")
print(f"{'='*70}")
print(f"{'File':<40} {'BPM':>4} {'Beats':>6} {'Dur(s)':>7} {'Voices':>6} {'Scale center':>14}")
print("-" * 80)
for r in results:
    # Find dominant pitch class
    if r['pitch_classes']:
        dom_pc = max(r['pitch_classes'], key=r['pitch_classes'].get)
        dom_note = PC_NAMES[dom_pc]
    else:
        dom_note = '?'
    short_name = r['filename'].replace('persian_', '').replace('.bas', '')
    print(f"{short_name:<40} {r['tempo']:>4} {r['beats']:>6} {r['beats']*60/r['tempo'] if r['tempo']>0 else 0:>7.0f} {len(r['instruments']):>6} {dom_note:>14}")

# Scale analysis per file
print(f"\n\n{'='*70}")
print("SCALE/MODE ANALYSIS")
print(f"{'='*70}")
for r in results:
    if not r['pitch_classes']:
        continue
    total = sum(r['pitch_classes'].values()) or 1
    # Get notes that appear at >5% of total
    significant = []
    for pc in range(12):
        if r['pitch_classes'][pc] / total > 0.05:
            significant.append(PC_NAMES[pc])
    dom_pc = max(r['pitch_classes'], key=r['pitch_classes'].get)
    short_name = r['filename'].replace('persian_', '').replace('.bas', '')
    print(f"\n  {short_name}:")
    print(f"    Dominant: {PC_NAMES[dom_pc]}")
    print(f"    Significant notes (>5%): {', '.join(significant)}")
    
    # Check for Persian scale characteristics
    has_d = r['pitch_classes'][2] / total > 0.08
    has_eb = r['pitch_classes'][3] / total > 0.05
    has_fsharp = r['pitch_classes'][6] / total > 0.05
    has_g = r['pitch_classes'][7] / total > 0.08
    has_a = r['pitch_classes'][9] / total > 0.05
    has_bb = r['pitch_classes'][10] / total > 0.05
    has_c = r['pitch_classes'][0] / total > 0.05
    
    bayat_e_esfahan = has_d and has_eb and has_fsharp and has_g and has_a and has_bb and has_c
    if bayat_e_esfahan:
        print(f"    Scale match: D BAYAT-E ESFAHAN (D, Eb, F#, G, A, Bb, C) - ALL 7 notes present")
    else:
        missing = []
        if not has_d: missing.append('D')
        if not has_eb: missing.append('Eb')
        if not has_fsharp: missing.append('F#')
        if not has_g: missing.append('G')
        if not has_a: missing.append('A')
        if not has_bb: missing.append('Bb')
        if not has_c: missing.append('C')
        print(f"    Bayat-e Esfahan notes missing from >5%: {', '.join(missing) if missing else 'none'}")