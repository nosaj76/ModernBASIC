#!/usr/bin/env python3
"""Generate a 3-minute Persian .bas composition for ModernBASIC 0.8.2.
Synthesizes elements from all 5 analyzed Persian songs.
D Bayat-e Esfahan, G-centered, 96 BPM, 288 beats = 3:00.
18 sixteen-beat windows in 6 phases of 3 windows each.
"""
import re, os

OUT = "/home/jason/projects/OSprojects/BASIC/modernbasic-0.8.2/programs/music/persian_dawn_three_minutes.bas"

def count_beats(phrase):
    """Count total beats in a ModernBASIC phrase string."""
    total = 0.0
    for m in re.finditer(r':([\d.]+)', phrase):
        total += float(m.group(1))
    return total

def verify(name, phrase, expected):
    actual = count_beats(phrase)
    if abs(actual - expected) > 0.01:
        print(f"ERROR: {name} = {actual} beats, expected {expected}")
        print(f"  phrase: {phrase}")
        return False
    return True

# ============================================================
# 8-BEAT SANTUR LEAD PHRASES (36 phrases, 2 per 16-beat window)
# ============================================================

# Phase 1: INVOCATION (W1-3) - sparse, low-mid, D-G area
SA1="R:2 D5:1@56 Eb5:.5@52 F#5:.5@62 G5:2@68 R:1 G5:1@64"
SB1="F#5:1@58 Eb5:1@54 D5:2@52 R:2 G5:2@66"

SA2="R:1 G5:1@64 A5:.5@68 Bb5:.5@72 A5:1@66 G5:1@70 F#5:1@58 Eb5:1@54"
SB2="D5:1@52 R:1 G5:1@66 A5:.5@70 Bb5:.5@74 A5:1@70 G5:1@66 R:1"

SA3="R:1 D5:1@56 Eb5:.5@52 F#5:.5@62 G5:2@68 A5:.5@72 G5:.5@66"
SB3="F#5:1@60 Eb5:1@54 D5:1@52 R:1 Eb5:.5@54 F#5:.5@62 G5:2@70"

# Phase 2: GATHERING (W4-6) - more active, mid register
SA4="G5:.5@68 A5:.5@72 Bb5:.5@76 A5:.5@72 G5:1@68 F#5:.5@62 Eb5:.5@56 D5:1@52 R:1 G5:1@66"
SB4="A5:.5@70 Bb5:.5@74 C6:1@78 Bb5:.5@72 A5:.5@68 G5:1@66 F#5:1@60 Eb5:1@54 D5:1@52 R:1"

SA5="D5:.5@56 Eb5:.5@52 F#5:1@62 G5:1@68 A5:.5@72 G5:.5@66 F#5:.5@62 Eb5:.5@56 D5:1@52 R:1"
SB5="G5:1@66 A5:1@70 Bb5:1@74 A5:1@70 G5:1@66 F#5:.5@60 Eb5:.5@54 D5:1@52 R:1 G5:1@68"

SA6="G5:1@68 Bb5:1@74 D6:1@80 C6:.5@76 Bb5:.5@72 A5:.5@68 G5:.5@64 F#5:1@60 R:1"
SB6="D5:.5@56 Eb5:.5@52 F#5:.5@62 G5:1@68 A5:.5@72 Bb5:.5@76 A5:1@72 G5:1@68 R:1"

# Phase 3: SAMA (W7-9) - full melody, mid-high
SA7="G5:.5@70 A5:.5@74 Bb5:.5@78 A5:.5@72 G5:.5@68 F#5:.5@62 Eb5:.5@56 D5:.5@52 G5:1@68 R:1 G5:1@66"
SB7="A5:.5@70 Bb5:.5@74 C6:1@78 Bb5:.5@72 A5:.5@68 G5:1@66 F#5:1@60 Eb5:1@54 D5:1@52 R:1 G5:1@68"

SA8="D5:.5@56 Eb5:.5@52 F#5:.5@62 G5:1@68 A5:.5@72 Bb5:.5@76 A5:1@72 G5:1@68 R:1"
SB8="A5:1@72 Bb5:1@76 C6:1@80 Bb5:1@74 A5:1@70 G5:1@66 F#5:1@60 Eb5:1@54 D5:1@52 R:1"

SA9="G5:1@70 Bb5:1@76 D6:1@84 C6:.5@80 Bb5:.5@74 A5:.5@70 G5:.5@66 F#5:1@62 R:1 D5:1@56"
SB9="G5:1@68 A5:.5@72 Bb5:.5@76 C6:1@80 D6:1@86 C6:.5@80 Bb5:.5@74 A5:.5@70 G5:2@76 R:1"

# Phase 4: AWJ (W10-12) - highest register, climax
SA10="D6:1@82 Eb6:.5@76 F#6:.5@84 G6:1@90 A6:.5@94 G6:.5@88 F#6:.5@84 Eb6:.5@78 D6:1@82 R:1"
SB10="G6:.5@88 A6:.5@92 Bb6:.5@96 A6:.5@90 G6:1@86 F#6:1@82 Eb6:1@76 D6:1@82 R:1 G6:1@90"

SA11="D6:.5@84 Eb6:.5@78 F#6:.5@86 G6:.5@92 A6:.5@96 G6:.5@90 F#6:.5@84 G6:.5@92 A6:1@96 R:1"
SB11="Bb6:.5@98 A6:.5@92 G6:.5@88 F#6:.5@84 Eb6:.5@78 D6:1@82 C6:.5@76 D6:.5@82 Eb6:.5@78 F#6:1@84 G6:2@92"

SA12="D6:1@80 C6:.5@76 Bb5:.5@72 A5:1@68 G5:1@66 F#5:.5@60 Eb5:.5@54 D5:1@52 R:1"
SB12="G5:1@66 A5:.5@70 Bb5:.5@74 A5:1@70 G5:1@66 F#5:1@60 Eb5:1@54 D5:1@52 R:1 G5:2@70"

# Phase 5: DESCENT (W13-15) - descending, back to mid
SA13="G5:1@70 F#5:.5@64 Eb5:.5@58 D5:1@54 R:1 Eb5:.5@56 F#5:.5@64 G5:1@70 A5:.5@74 G5:.5@68 R:1"
SB13="F#5:.5@62 Eb5:.5@56 D5:1@52 R:1 G5:1@66 A5:.5@70 Bb5:.5@74 A5:1@70 G5:1@66 R:1 D5:1@54"

SA14="R:1 D5:1@56 Eb5:.5@52 F#5:.5@62 G5:2@68 A5:.5@72 G5:.5@66 F#5:1@60 Eb5:1@54 D5:1@52 R:1"
SB14="G5:1@66 A5:.5@70 Bb5:.5@74 A5:1@70 G5:1@66 F#5:.5@60 Eb5:.5@54 D5:1@52 R:1 G5:2@68"

SA15="G5:1@68 A5:.5@72 G5:.5@66 F#5:1@60 G5:1@68 R:1 A5:.5@72 G5:.5@66 F#5:.5@60 Eb5:.5@54"
SB15="D5:1@52 R:1 G5:1@66 F#5:.5@60 Eb5:.5@54 D5:1@52 R:1 G5:2@68 R:2"

# Phase 6: FORUD (W16-18) - final cadence, long tones
SA16="G5:1@66 F#5:1@60 Eb5:1@54 D5:1@52 R:2 G5:1@66 A5:.5@70 Bb5:.5@74 A5:1@70 G5:2@72"
SB16="F#5:1@60 Eb5:1@54 D5:1@52 R:1 Eb5:.5@54 F#5:.5@62 G5:2@70 R:2 D5:2@56 R:2"

SA17="R:1 D5:1@56 G5:2@68 R:1 F#5:.5@60 G5:.5@68 A5:.5@72 G5:.5@68 F#5:1@60 Eb5:1@54 D5:1@52 R:1"
SB17="G5:1@66 R:1 D5:1@56 Eb5:.5@52 F#5:.5@62 G5:2@68 R:1 F#5:.5@60 Eb5:.5@54 D5:1@52 R:1 G5:2@68"

SA18="R:1 G5:2@66 F#5:1@60 Eb5:1@54 D5:1@52 R:1 Eb5:.5@54 F#5:.5@62 G5:4@72 R:4"
SB18="R:4 G5:8@68 R:4"

# Verify all santur phrases = 8 beats
all_santur = [SA1,SB1,SA2,SB2,SA3,SB3,SA4,SB4,SA5,SB5,SA6,SB6,
              SA7,SB7,SA8,SB8,SA9,SB9,SA10,SB10,SA11,SB11,SA12,SB12,
              SA13,SB13,SA14,SB14,SA15,SB15,SA16,SB16,SA17,SB17,SA18,SB18]
for i, p in enumerate(all_santur):
    verify(f"santur[{i}]", p, 8)

# ============================================================
# HIGH SANTUR ANSWERS (8-beat phrases, enters at W7)
# ============================================================
HA1="R:1 G6:.25@58 A6:.25@54 Bb6:.25@62 A6:.25@56 G6:.5@60 F#6:.5@52 Eb6:1@54 R:2"
HB1="F#6:.5@56 G6:1.5@66 R:2 D6:.25@58 Eb6:.25@54 F#6:.5@64 G6:1@68 R:2"
HA2="G6:.25@72 A6:.25@76 Bb6:.25@80 A6:.25@74 G6:.5@78 F#6:.5@66 Eb6:1@70 D6:1@66 R:1"
HB2="D7:.5@82 C7:.5@76 Bb6:1@78 A6:1@74 G6:2@88 R:2 G6:.5@84 F#6:.5@78 Eb6:1@76"
HA3="G6:.25@84 A6:.25@88 Bb6:.25@92 A6:.25@86 G6:1@84 F#6:1@78 Eb6:1@72 D6:1@68 R:1"
HB3="D7:.5@86 C7:.5@80 Bb6:.5@76 A6:.5@72 G6:1@82 F#6:.5@68 Eb6:.5@62 D6:1@66 R:2"
HA4="G6:.5@78 F#6:.5@72 Eb6:.5@66 D6:1@68 C6:.5@58 Bb5:.5@56 A5:1@60 G5:2@70 R:1"
HB4="D6:.25@62 Eb6:.25@58 F#6:.25@66 G6:.25@72 A6:.5@76 G6:.5@68 F#6:.5@64 Eb6:.5@58 D6:1@66 R:1"

all_high = [HA1,HB1,HA2,HB2,HA3,HB3,HA4,HB4]
for i, p in enumerate(all_high):
    verify(f"high_santur[{i}]", p, 8)

# ============================================================
# TAR OSTINATO (8-beat cells)
# ============================================================
T0="G3:.5@58 D4:.5@54 G4:.25@68 A4:.25@64 G4:.5@68 F#4:.5@60 Eb4:.5@56 D4:.5@58 G3:.5@62"
T1="G3:.5@60 D4:.5@56 G4:.25@70 A4:.25@66 Bb4:.25@72 A4:.25@66 G4:.5@70 F#4:.5@62 Eb4:.5@58 D4:.5@60"
T2="G3:.5@62 Bb3:.5@58 D4:.5@66 G4:.5@74 A4:.25@70 Bb4:.25@76 A4:.25@68 G4:.25@72 F#4:1@64 Eb4:.5@58 D4:.5@62"
T3="G3:.25@68 D4:.25@62 G4:.25@76 A4:.25@72 Bb4:.25@80 A4:.25@70 G4:.25@78 F#4:.25@66 Eb4:.5@62 F#4:.5@68 G4:1@82 D4:.5@66 G3:.5@72"
T4="A3:.5@62 Bb3:.5@66 A3:.5@60 G3:.5@68 F#3:.5@56 Eb3:.5@54 D3:1@58 Eb3:.5@56 F#3:.5@62 G3:1@72 D3:.5@56 G2:.5@68"
T5="G3:.5@60 D4:.5@56 G4:1@72 A4:.25@68 G4:.25@72 F#4:.5@62 Eb4:.5@58 F#4:.5@64 G4:1@76 D4:.5@58 G3:.5@54 R:1"

all_tar = [T0,T1,T2,T3,T4,T5]
for i, p in enumerate(all_tar):
    verify(f"tar[{i}]", p, 8)

# ============================================================
# SETAR FILIGREE (8-beat cells, quieter)
# ============================================================
E1="G4:.25@52 A4:.25@48 G4:.25@54 F#4:.25@46 Eb4:.5@44 D4:.5@48 G3:1@50 D4:.5@52 R:1.5"
E2="D4:.25@50 Eb4:.25@46 F#4:.25@54 G4:.25@58 A4:.5@60 G4:.5@56 F#4:.5@52 Eb4:.5@46 D4:.5@50 G3:.5@48 R:1"
E3="G4:.25@56 Bb4:.25@60 A4:.25@54 G4:.25@58 F#4:.25@50 Eb4:.25@46 D4:.5@48 Eb4:.25@46 F#4:.5@54 G4:.5@60 A4:.5@58 R:1"
E4="A4:.5@56 Bb4:.5@60 A4:.5@54 G4:.5@62 F#4:.5@50 Eb4:.5@46 D4:1@50 Eb4:.5@48 F#4:.5@54 G4:1@64 R:1"

all_setar = [E1,E2,E3,E4]
for i, p in enumerate(all_setar):
    verify(f"setar[{i}]", p, 8)

# ============================================================
# NEY LEAD (16-beat phrases, with breath breaks)
# ============================================================
N1="R:2 D5:1@50 Eb5:.5@48 F#5:.5@58 G5:3@68 R:1 G5:.5@64 A5:.5@68 Bb5:1@72 A5:.5@66 G5:.5@64 F#5:1@58 Eb5:1@54 F#5:.5@58 G5:2@68 R:1"
N2="G5:1@66 A5:.5@70 Bb5:.5@74 C6:1@78 Bb5:.5@72 A5:.5@68 G5:2@72 R:1 F#5:.5@60 G5:.5@68 A5:1@72 G5:1@70 D5:1@52 Eb5:1@56 F#5:1@62 G5:3@74 R:1"
N3="R:.5 G5:.5@68 A5:1@72 Bb5:1@76 C6:1@80 D6:2@86 C6:.5@78 Bb5:.5@74 A5:1@70 G5:1@72 A5:.5@74 Bb5:.5@78 C6:1@82 D6:1@88 C6:1@80 Bb5:1@76 A5:1@72 G5:1@78"
N4="G5:1@76 A5:.25@72 G5:.25@76 F#5:.5@64 G5:1@78 Bb5:.5@82 A5:.5@76 G5:1@78 F#5:.5@64 Eb5:.5@58 D5:1@54 Eb5:.25@56 F#5:.25@64 G5:.5@74 A5:1@76 G5:1@78 F#5:1@66 Eb5:1@60 F#5:1@66 G5:3@84"
N5="R:.5 D6:.5@80 Eb6:.25@76 F#6:.25@84 G6:1@90 A6:.5@92 G6:.5@88 F#6:.5@82 Eb6:.5@76 D6:1@84 C6:.5@78 Bb5:.5@74 A5:1@72 G5:1@80 Bb5:1@82 A5:.5@76 G5:.5@80 F#5:1@68 Eb5:1@62 F#5:1@68 G5:2.5@88"
NF="A5:1@70 Bb5:.5@74 A5:.5@68 G5:2@76 R:.5 F#5:.5@62 Eb5:1@58 D5:1@54 Eb5:.5@58 F#5:.5@64 G5:1@72 A5:.5@68 G5:.5@74 F#5:1@60 Eb5:1@54 D5:1@50 G5:3@78 R:1"

all_ney = [N1,N2,N3,N4,N5,NF]
for i, p in enumerate(all_ney):
    verify(f"ney[{i}]", p, 16)

# ============================================================
# LOW NAY HETEROPHONY (8-beat cells, long notes)
# ============================================================
K1="G4:4@44 A4:2@48 Bb4:2@50 A4:2@46 G4:4@52 F#4:1@44 Eb4:1@42"
# Wait, that's 16 beats not 8. Let me split:
K1="G4:4@44 A4:2@48 Bb4:2@50 A4:4@46"
K2="G4:4@52 F#4:2@44 Eb4:2@42 D4:4@40"
K3="D5:2@48 Eb5:2@46 F#5:2@50 G5:4@56"
K4="A5:2@58 G5:2@54 F#5:2@48 G5:2@58"
K5="G5:2@54 A5:2@58 Bb5:2@60 C6:4@62"
K6="D6:4@66 C6:2@60 Bb5:1@56 A5:1@54"
KF="A4:2@48 G4:4@56 F#4:2@48 Eb4:2@44 D4:2@42 Eb4:1@44 F#4:1@48"

all_lownay = [K1,K2,K3,K4,K5,K6,KF]
for i, p in enumerate(all_lownay):
    verify(f"low_nay[{i}]", p, 8)

# ============================================================
# OUD BASS PUNCTUATION (8-beat cells)
# ============================================================
B1="D3:1@48 A3:.5@42 D4:.5@54 R:1 Eb3:1@44 Bb3:.5@40 Eb4:.5@50 R:1 G3:2@56"
B2="G2:1@48 D3:.5@42 G3:.5@54 R:1 Bb2:1@46 F#3:.5@40 Bb3:.5@52 R:1 G2:2@56"
B3="D3:.5@48 A3:.5@42 D4:1@56 C4:.5@48 Bb3:.5@46 A3:1@50 G3:1@54 F#3:.5@44 Eb3:.5@42 D3:1@46 G2:1@56"
B4="A2:.5@44 Bb2:.5@46 A2:.5@42 G2:.5@50 F#2:.5@40 Eb2:.5@38 D2:1@42 Eb2:.5@40 F#2:.5@44 G2:1@54 D2:1@40 G2:1@58"
# B3 and B4 are 16 beats, not 8. Fix:
B3="D3:.5@48 A3:.5@42 D4:1@56 R:1 C4:.5@48 Bb3:.5@46 A3:1@50 G3:1@54 R:1"
B4="F#3:.5@44 Eb3:.5@42 D3:1@46 R:1 G2:2@56 R:2"

all_oud = [B1,B2,B3,B4]
for i, p in enumerate(all_oud):
    verify(f"oud[{i}]", p, 8)

# ============================================================
# TOMBAK CELLS (8-beat, building in density)
# ============================================================
M0="C2:.5@74 R:.5 G2:.25@43 G2:.25@48 D2:.5@56 C2:1@72 R:.5 D2:.5@50 G2:.5@44 A2:.5@48 G2:.5@42 D2:.5@54 C2:1@74 D2:1@50"
# That's 16. Split:
M0="C2:.5@72 R:.5 G2:.25@43 G2:.25@48 D2:.5@54 C2:1@70 D2:.5@50 G2:.5@44 A2:.5@48"
M1="C2:.5@76 G2:.25@46 G2:.25@52 D2:.5@58 G2:.5@44 C2:1@74 R:.5 D2:.5@54 G2:.5@46"
M2="C2:.5@80 D2:.5@58 G2:.5@46 A2:.5@52 G2:.5@48 D2:.5@60 C2:1@78 D2:.5@54 G2:.5@48"
M3="C2:.25@84 D2:.25@62 G2:.25@52 A2:.25@56 G2:.25@52 D2:.25@64 C2:.5@82 G2:.25@54 A2:.25@58 D2:.5@66 C2:1@84"
ML="C2:1@74 R:.5 G2:.5@50 D2:1@60 C2:.5@72 R:.5 D2:.5@54 G2:.5@46 R:1"

all_tombak = [M0,M1,M2,M3,ML]
for i, p in enumerate(all_tombak):
    verify(f"tombak[{i}]", p, 8)

# ============================================================
# DAF CELLS (8-beat, building in density)
# ============================================================
D0="F#2:1@44 R:1 A#2:.5@50 R:1.5 F#2:1@42 R:1 A#2:.5@54 R:1.5"
D1="F#2:.5@46 A#2:.5@58 R:.5 F#2:1@42 C#3:.5@62 R:.5 F#2:.5@48 A#2:.5@60 C#3:.5@64 R:.5"
D2="F#2:.5@48 A#2:.5@62 C#3:.5@68 R:.5 F#2:1@44 R:.5 A#2:.5@60 R:.5 F#2:.5@46 C#3:.5@66"
D3="F#2:.25@52 A#2:.25@66 C#3:.25@72 A#2:.25@64 F#2:.5@56 A#2:.25@68 C#3:.25@74 A#2:.25@62 F#2:1@50 R:1"
DL="F#2:.5@42 A#2:.5@46 C#3:.5@50 A#2:.5@44 F#2:1@48 R:1 A#2:.5@46 C#3:.5@50 R:1.5"

all_daf = [D0,D1,D2,D3,DL]
for i, p in enumerate(all_daf):
    verify(f"daf[{i}]", p, 8)

# ============================================================
# LOW SANTUR ANSWERS (8-beat cells, G-centered mantra)
# ============================================================
L1="G3:1@44 D4:1@48 G4:1@56 F#4:.5@50 Eb4:.5@46 D4:1@48 Eb4:1@46 F#4:1@52"
L2="D4:.5@48 G4:.5@56 A4:.5@58 Bb4:.5@60 A4:1@56 G4:1@62 F#4:.5@50 Eb4:.5@46 D4:.5@48"
L3="G4:.5@56 A4:.5@58 Bb4:.5@62 A4:.5@56 G4:.5@60 F#4:.5@50 Eb4:.5@46 D4:.5@48 Eb4:1@48 F#4:1@54 G4:1@60 R:1"
# L3 is 9 beats... fix:
L3="G4:.5@56 A4:.5@58 Bb4:.5@62 A4:.5@56 G4:.5@60 F#4:.5@50 Eb4:.5@46 D4:1@48 G4:1@60 R:1"
LR="G3:.5@48 D4:.5@52 G4:.5@60 A4:.5@62 G4:.5@58 F#4:.5@52 Eb4:.5@48 D4:.5@50"

all_lowsantur = [L1,L2,L3,LR]
for i, p in enumerate(all_lowsantur):
    verify(f"low_santur[{i}]", p, 8)

# ============================================================
# TAR RIZ (8-beat cells, for climax only)
# ============================================================
Z1="G4:.25@62 G4:.25@56 G4:.25@64 G4:.25@58 D4:.25@56 D4:.25@50 D4:.25@58 D4:.25@52 Eb4:.25@54 F#4:.25@60 G4:.5@68 F#4:.5@60 Eb4:.5@56 D4:.5@58"
Z2="A4:.25@66 A4:.25@60 Bb4:.25@68 Bb4:.25@62 A4:.25@66 G4:.25@60 F#4:1@62 Eb4:1@56 D4:1@58 G3:1@64 R:1"

all_tariz = [Z1,Z2]
for i, p in enumerate(all_tariz):
    verify(f"tar_riz[{i}]", p, 8)

# ============================================================
# HIGH TAR ANSWERS (8-beat cells)
# ============================================================
TA1="R:1 G5:.25@62 A5:.25@66 Bb5:.25@70 A5:.25@64 G5:.5@68 F#5:.5@60 Eb5:.5@56 F#5:.5@62 R:1"
TA2="D5:.5@56 A5:.5@64 D6:1@70 Eb6:.5@62 D6:.5@66 A5:1@58 G5:.5@56 F#5:.5@60 Eb5:1@54 D5:2@64"

all_hightar = [TA1,TA2]
for i, p in enumerate(all_hightar):
    verify(f"high_tar[{i}]", p, 8)

print("All phrase verification complete.")
print(f"Santur phrases: {len(all_santur)} × 8 beats = {len(all_santur)*8} beats")
print(f"Total windows: 18 × 16 beats = 288 beats")
print(f"At 96 BPM: {288*60/96:.0f} seconds = {288*60/96/60:.1f} minutes")

# ============================================================
# GENERATE THE .BAS FILE
# ============================================================
lines = []
def w(s=""):
    lines.append(s)

# Header
w("10 REM ============================================================")
w("20 REM  PERSIAN DAWN AT ESFAHAN - A THREE-MINUTE SUFI JOURNEY")
w("30 REM  ORIGINAL IRANIAN MUSIC FOR MODERNBASIC 0.8.2+")
w("40 REM  D BAYAT-E ESFAHAN: D, E-KORON, F#, G, A, BB, C")
w("50 REM  E-KORON IS RENDERED AS EB IN THIS 12-TONE-SAFE EDITION")
w("60 REM  AQAZ D/G - IST EB - SHAHED AND FINALIS G")
w("70 REM  288 BEATS AT 96 BPM - ABOUT 3 MINUTES 0 SECONDS")
w("80 REM  18 SIXTEEN-BEAT WINDOWS IN SIX PHASES OF THREE")
w("90 REM  INVOCATION - GATHERING - SAMA - AWJ - DESCENT - FORUD")
w("100 REM  COMPOSED FROM ANALYSIS OF ALL PERSIAN .BAS SONGS IN THIS DIR")
w("110 REM ============================================================")
w("120 CLEAR")
w("130 GOSUB 5000")
w("140 TEMPO 96")
w("150 VOL 1")
w("160 PRINT \"PERSIAN DAWN AT ESFAHAN - THREE-MINUTE SUFI JOURNEY\"")
w("170 PRINT \"INVOCATION - GATHERING - SAMA - AWJ - DESCENT - FORUD\"")
w("180 PRINT \"NAY, SANTUR, TAR, OUD, TOMBAK AND DAF - NO GM SUBSTITUTES\"")
w("190 REM")
w("200 REM === AUTHENTIC PERSIAN SOUNDFONT ============================")
w("210 SOUNDFONT 1,16,\"soundfont/Persa.sf2\"")
w("220 REM")

# Instrument map
w("230 REM === IRANIAN ENSEMBLE ROLES ===============================")
instruments = [
    (1,1,"SANTUR SOLOIST"),
    (2,1,"HIGH SANTUR ANSWERS"),
    (3,2,"TAR CHAHARMEZRAB"),
    (4,2,"SETAR-LIKE FILIGREE"),
    (5,0,"NEY SOLOIST"),
    (6,0,"LOW NAY HETEROPHONY"),
    (7,4,"OUD BASS PUNCTUATION"),
    (8,3,"TOUMBAK HAND-DRUM"),
    (9,5,"DAFF FRAME-DRUM HEARTBEAT"),
    (10,1,"LOW SANTUR RESPONSES"),
    (11,2,"TAR RIZ AT THE AWJ"),
    (12,0,"LOW NAY RESONANCE"),
    (13,1,"SANTUR RESONANCE"),
    (14,2,"HIGH TAR ANSWERS"),
    (15,0,"DISTANT NEY SHADOW"),
    (16,1,"QUIET LOW SANTUR RESONANCE"),
]
for v, preset, role in instruments:
    w(f"{230+10*(v-1)} INSTRUMENT {v},{preset}")
    w(f"{230+10*(v-1)+5} REM VOICE {v:2d} = {role}")
w("")

# DSP
w("720 REM === SAMPLE ARTICULATION AND SMALL WOODEN ROOM ============")
dsp_vals = [
    (1,.01,.50,.62,.12,.74), (2,.01,.44,.58,.08,.70),
    (3,.01,.40,.58,.12,.60), (4,.01,.46,.54,.08,.66),
    (5,0,.48,.68,.06,.98),   (6,.03,.34,.82,.10,.94),
    (7,.02,.48,.60,.10,.66), (8,.005,.38,.48,.14,.48),
    (9,.005,.40,.52,.12,.46), (10,.01,.42,.62,.08,.72),
    (11,.02,.36,.58,.10,.60), (12,0,.43,.50,.10,.97),
    (13,.01,.54,.62,.10,.72), (14,.02,.50,.66,.12,.60),
    (15,0,.48,.56,.05,.98),   (16,.02,.48,.70,.12,.76),
]
for v, a, b, c, d, e in dsp_vals:
    w(f"{730+10*(v-1)} DSP {v},{a},{b},{c},{d},{e}")
w("")

# Expression
w("900 REM === EXPRESSION: SOLOISTS FORWARD, SHADOWS WITHDRAWN ========")
expr_vals = [
    (1,.80), (2,.59), (3,.72), (4,.50), (5,.86), (6,.62),
    (7,.57), (8,.82), (9,.72), (10,.55), (11,.62), (12,.43),
    (13,.49), (14,.48), (15,.38), (16,.28)
]
for v, e in expr_vals:
    w(f"{910+10*(v-1)} EXPRESSION {v},{e}")
w(f"1070 MODULATION 5,.065")
w(f"1080 MODULATION 6,.04")
w(f"1090 MODULATION 12,.04")
w(f"1100 MODULATION 15,.03")
w("")

# Balance, stereo, reverb
w("1120 REM === BALANCE, STEREO, AND REVERB =========================")
vol_vals = [
    (1,.58), (2,.25), (3,.36), (4,.18), (5,.72), (6,.30),
    (7,.25), (8,.52), (9,.36), (10,.22), (11,.20), (12,.13),
    (13,.16), (14,.15), (15,.10), (16,.08)
]
for v, vol in vol_vals:
    w(f"{1130+10*(v-1)} VOL {v},{vol}")
w("")
stereo_vals = [
    (1,-.08), (2,.24), (3,-.27), (4,.28), (5,.06), (6,-.17),
    (7,.19), (8,-.05), (9,.08), (10,.14), (11,-.22), (12,.16),
    (13,.21), (14,-.19), (15,-.10), (16,.03)
]
for v, s in stereo_vals:
    w(f"{1290+10*(v-1)} STEREO {v},{s}")
w("")
reverb_vals = [
    (1,.24), (2,.22), (3,.14), (4,.16), (5,.30), (6,.34),
    (7,.17), (8,.06), (9,.10), (10,.22), (11,.15), (12,.28),
    (13,.24), (14,.18), (15,.38), (16,.26)
]
for v, r in reverb_vals:
    w(f"{1450+10*(v-1)} REVERB {v},{r}")
w("")

# Phrase definitions
w("1610 REM ============================================================")
w("1620 REM  PHRASE DEFINITIONS - ALL PHRASES ARE 8 BEATS UNLESS NOTED")
w("1630 REM ============================================================")
w("")

# Santur lead phrases (define as combined 16-beat strings)
w("1640 REM === SANTUR SOLO: 18 SIXTEEN-BEAT PHRASES ================")
santur_pairs = [
    ("S1$", SA1, SB1), ("S2$", SA2, SB2), ("S3$", SA3, SB3),
    ("S4$", SA4, SB4), ("S5$", SA5, SB5), ("S6$", SA6, SB6),
    ("S7$", SA7, SB7), ("S8$", SA8, SB8), ("S9$", SA9, SB9),
    ("S10$", SA10, SB10), ("S11$", SA11, SB11), ("S12$", SA12, SB12),
    ("S13$", SA13, SB13), ("S14$", SA14, SB14), ("S15$", SA15, SB15),
    ("S16$", SA16, SB16), ("S17$", SA17, SB17), ("S18$", SA18, SB18),
]
for name, a, b in santur_pairs:
    w(f'{1700+santur_pairs.index((name,a,b))*10} {name}="{a} {b}"')
w("")

# High santur
w("1880 REM === HIGH SANTUR ANSWERS (8-BEAT CELLS) =================")
hnames = ["HA1$","HB1$","HA2$","HB2$","HA3$","HB3$","HA4$","HB4$"]
hvals = [HA1,HB1,HA2,HB2,HA3,HB3,HA4,HB4]
for i, (n, v) in enumerate(zip(hnames, hvals)):
    w(f'{1890+i*5} {n}="{v}"')
w("")

# Tar cells
w("1930 REM === TAR OSTINATO (8-BEAT CELLS) =======================")
tnames = ["T0$","T1$","T2$","T3$","T4$","T5$"]
tvals = [T0,T1,T2,T3,T4,T5]
for i, (n, v) in enumerate(zip(tnames, tvals)):
    w(f'{1940+i*5} {n}="{v}"')
w("")

# Setar
w("1970 REM === SETAR FILIGREE (8-BEAT CELLS) =====================")
enames = ["E1$","E2$","E3$","E4$"]
evals = [E1,E2,E3,E4]
for i, (n, v) in enumerate(zip(enames, evals)):
    w(f'{1980+i*5} {n}="{v}"')
w("")

# Ney (16-beat phrases)
w("2000 REM === NEY LEAD (16-BEAT PHRASES WITH BREATH BREAKS) =====")
nnames = ["N1$","N2$","N3$","N4$","N5$","NF$"]
nvals = [N1,N2,N3,N4,N5,NF]
for i, (n, v) in enumerate(zip(nnames, nvals)):
    w(f'{2010+i*10} {n}="{v}"')
w("")

# Low nay
w("2070 REM === LOW NAY HETEROPHONY (8-BEAT CELLS) ================")
knames = ["K1$","K2$","K3$","K4$","K5$","K6$","KF$"]
kvals = [K1,K2,K3,K4,K5,K6,KF]
for i, (n, v) in enumerate(zip(knames, kvals)):
    w(f'{2080+i*5} {n}="{v}"')
w("")

# Oud
w("2120 REM === OUD BASS PUNCTUATION (8-BEAT CELLS) ===============")
bnames = ["B1$","B2$","B3$","B4$"]
bvals = [B1,B2,B3,B4]
for i, (n, v) in enumerate(zip(bnames, bvals)):
    w(f'{2130+i*5} {n}="{v}"')
w("")

# Tombak
w("2150 REM === TOMBAK CELLS (8-BEAT, BUILDING IN DENSITY) =========")
mnames = ["M0$","M1$","M2$","M3$","ML$"]
mvals = [M0,M1,M2,M3,ML]
for i, (n, v) in enumerate(zip(mnames, mvals)):
    w(f'{2160+i*5} {n}="{v}"')
w("")

# Daf
w("2190 REM === DAF CELLS (8-BEAT, BUILDING IN DENSITY) ===========")
dnames = ["D0$","D1$","D2$","D3$","DL$"]
dvals = [D0,D1,D2,D3,DL]
for i, (n, v) in enumerate(zip(dnames, dvals)):
    w(f'{2200+i*5} {n}="{v}"')
w("")

# Low santur
w("2230 REM === LOW SANTUR ANSWERS (8-BEAT CELLS) =================")
lnames = ["L1$","L2$","L3$","LR$"]
lvals = [L1,L2,L3,LR]
for i, (n, v) in enumerate(zip(lnames, lvals)):
    w(f'{2240+i*5} {n}="{v}"')
w("")

# Tar riz
w("2260 REM === TAR RIZ (8-BEAT CELLS, AWJ ONLY) ===================")
znames = ["Z1$","Z2$"]
zvals = [Z1,Z2]
for i, (n, v) in enumerate(zip(znames, zvals)):
    w(f'{2270+i*5} {n}="{v}"')
w("")

# High tar
w("2280 REM === HIGH TAR ANSWERS (8-BEAT CELLS) ===================")
tahnames = ["TA1$","TA2$"]
tahvals = [TA1,TA2]
for i, (n, v) in enumerate(zip(tahnames, tahvals)):
    w(f'{2290+i*5} {n}="{v}"')
w("")

# Rest strings
w("2300 R8$=\" R:8 \"")
w("2310 R16$=\" R:16 \"")
w("2320 R24$=\" R:24 \"")
w("2330 R32$=\" R:32 \"")
w("2340 R48$=\" R:48 \"")
w("")

# ============================================================
# PLAY STATEMENTS - 18 WINDOWS PER VOICE
# ============================================================
w("2350 REM ============================================================")
w("2360 REM  FORM: 18 SIXTEEN-BEAT WINDOWS - 6 PHASES OF 3")
w("2370 REM  W1-3  INVOCATION   W4-6  GATHERING   W7-9  SAMA")
w("2380 REM  W10-12 AWJ         W13-15 DESCENT   W16-18 FORUD")
w("2390 REM ============================================================")
w("")

# V1 - SANTUR LEAD: all 18 windows
w("2400 REM === VOICE 1 - SANTUR, THE PRINCIPAL NARRATOR ===========")
for i in range(18):
    w(f'{2410+i*10} PLAY 1,S{i+1}$')
w("")

# V2 - HIGH SANTUR: W7-15 (9 windows)
w("2590 REM === VOICE 2 - HIGH SANTUR HAMMER ANSWERS ================")
v2_schedule = [
    None, None, None, None, None, None,  # W1-6 rest
    "HA1$+HB1$", "HA2$+HB2$", "HA2$+HB2$",  # W7-9
    "HA3$+HB3$", "HA3$+HB3$", "HA2$+HB3$",  # W10-12
    "HA2$+HB2$", "HA4$+HB4$", "HA4$+HB1$",  # W13-15
    None, None, None  # W16-18 rest
]
for i, s in enumerate(v2_schedule):
    if s:
        w(f'{2600+i*10} PLAY 2,{s}')
    else:
        w(f'{2600+i*10} PLAY 2,R16$')
w("")

# V3 - TAR: W4-15 (12 windows)
w("2780 REM === VOICE 3 - TAR CHAHARMEZRAB ========================")
v3_schedule = [
    None, None, None,  # W1-3
    "T0$+T0$", "T0$+T1$", "T1$+T0$",  # W4-6
    "T1$+T2$", "T2$+T1$", "T1$+T3$",  # W7-9
    "T3$+T3$", "T3$+T4$", "T4$+T3$",  # W10-12
    "T2$+T1$", "T1$+T2$", "T0$+T0$",  # W13-15
    None, None, None  # W16-18
]
for i, s in enumerate(v3_schedule):
    if s:
        w(f'{2790+i*10} PLAY 3,{s}')
    else:
        w(f'{2790+i*10} PLAY 3,R16$')
w("")

# V4 - SETAR: W7-15 (9 windows)
w("2980 REM === VOICE 4 - SETAR-LIKE FILIGREE ======================")
v4_schedule = [
    None, None, None, None, None, None,
    "R8$+E1$", "E2$+E1$", "E1$+E2$",  # W7-9
    "E3$+E4$", "E3$+E2$", "E4$+E3$",  # W10-12
    "E2$+E1$", "R8$+E1$", "E1$+R8$",  # W13-15
    None, None, None
]
for i, s in enumerate(v4_schedule):
    if s:
        w(f'{2990+i*10} PLAY 4,{s}')
    else:
        w(f'{2990+i*10} PLAY 4,R16$')
w("")

# V5 - NEY: all 18 windows (with breath breaks)
w("3180 REM === VOICE 5 - NEY LEAD MELODY ========================")
v5_schedule = [
    "N1$", "R16$", "N1$",  # W1-3
    "N2$", "R16$", "N1$",  # W4-6
    "N2$", "N3$", "N4$",  # W7-9
    "N5$", "R16$", "N3$",  # W10-12
    "N2$", "N4$", "R16$",  # W13-15
    "NF$", "R16$", "NF$",  # W16-18
]
for i, s in enumerate(v5_schedule):
    w(f'{3190+i*10} PLAY 5,{s}')
w("")

# V6 - LOW NAY: W7-15 (9 windows)
w("3370 REM === VOICE 6 - LOW NAY HETEROPHONY =====================")
v6_schedule = [
    None, None, None, None, None, None,
    "K1$+K2$", "K1$+K2$", "K3$+K4$",  # W7-9
    "K5$+K6$", "K5$+K4$", "K3$+K2$",  # W10-12
    "K2$+K1$", "K1$+KF$", "KF$+K1$",  # W13-15
    None, None, None
]
for i, s in enumerate(v6_schedule):
    if s:
        w(f'{3380+i*10} PLAY 6,{s}')
    else:
        w(f'{3380+i*10} PLAY 6,R16$')
w("")

# V7 - OUD: all 18 windows
w("3570 REM === VOICE 7 - OUD BASS PUNCTUATION =====================")
v7_schedule = [
    "B1$+R8$", "B1$+R8$", "B2$+R8$",  # W1-3
    "B1$+B2$", "B2$+R8$", "B1$+B3$",  # W4-6
    "B2$+B3$", "B3$+B2$", "B1$+B3$",  # W7-9
    "B3$+B4$", "B2$+B3$", "B3$+B4$",  # W10-12
    "B2$+B1$", "B1$+R8$", "B1$+B4$",  # W13-15
    "B4$+R8$", "R8$+B1$", "R16$+B4$"  # W16-18
]
for i, s in enumerate(v7_schedule):
    w(f'{3580+i*10} PLAY 7,{s}')
w("")

# V8 - TOMBAK: W4-17 (14 windows)
w("3760 REM === VOICE 8 - TOUMBAK HAND-DRUM =======================")
v8_schedule = [
    None, None, None,  # W1-3
    "M0$+M0$", "M0$+M1$", "M1$+M0$",  # W4-6
    "M1$+M2$", "M2$+M1$", "M2$+M2$",  # W7-9
    "M3$+M3$", "M3$+M2$", "M2$+M3$",  # W10-12
    "M1$+M2$", "M0$+M1$", "M0$+M0$",  # W13-15
    "ML$+ML$", "R16$", None  # W16-18
]
for i, s in enumerate(v8_schedule):
    if s:
        w(f'{3770+i*10} PLAY 8,{s}')
    else:
        w(f'{3770+i*10} PLAY 8,R16$')
w("")

# V9 - DAF: W7-17 (11 windows)
w("3950 REM === VOICE 9 - DAFF FRAME-DRUM HEARTBEAT ===============")
v9_schedule = [
    None, None, None, None, None, None,
    "D0$+D0$", "D0$+D1$", "D1$+D0$",  # W7-9
    "D1$+D2$", "D2$+D2$", "D2$+D1$",  # W10-12
    "D1$+D0$", "D0$+D1$", "D0$+D0$",  # W13-15
    "DL$+DL$", "R16$", None  # W16-18
]
for i, s in enumerate(v9_schedule):
    if s:
        w(f'{3960+i*10} PLAY 9,{s}')
    else:
        w(f'{3960+i*10} PLAY 9,R16$')
w("")

# V10 - LOW SANTUR: W4-17 (14 windows)
w("4140 REM === VOICE 10 - LOW SANTUR G-CENTERED MANTRA ===========")
v10_schedule = [
    None, None, None,
    "L1$+L1$", "L1$+L2$", "L1$+L1$",  # W4-6
    "L2$+L1$", "L1$+L3$", "L3$+L1$",  # W7-9
    "L2$+L3$", "L3$+L2$", "L2$+L1$",  # W10-12
    "L1$+L1$", "L1$+LR$", "LR$+L1$",  # W13-15
    "L1$+R8$", "R8$+L1$", "R16$"  # W16-18
]
for i, s in enumerate(v10_schedule):
    if s:
        w(f'{4150+i*10} PLAY 10,{s}')
    else:
        w(f'{4150+i*10} PLAY 10,R16$')
w("")

# V11 - TAR RIZ: W10-12 only (3 windows)
w("4330 REM === VOICE 11 - TAR RIZ AT THE AWJ =====================")
for i in range(18):
    if 9 <= i <= 11:
        if i == 9:
            w(f'{4340+i*10} PLAY 11,Z1$+Z2$')
        elif i == 10:
            w(f'{4340+i*10} PLAY 11,Z2$+Z1$')
        else:
            w(f'{4340+i*10} PLAY 11,Z1$+Z1$')
    else:
        w(f'{4340+i*10} PLAY 11,R16$')
w("")

# V12 - LOW NAY RESONANCE: all 18 windows (long tones)
w("4520 REM === VOICE 12 - LOW NAY RESONANCE =======================")
v12_tones = [
    "D3:8@34 R:8", "G3:8@38 R:8", "D3:8@34 R:8",  # W1-3
    "G3:8@38 R:8", "Eb3:8@34 R:8", "G3:8@40 R:8",  # W4-6
    "D4:8@38 R:8", "G4:8@42 R:8", "D4:8@38 G4:8@40",  # W7-9
    "G4:8@44 D5:8@42", "D5:8@44 G4:8@40", "G4:8@42 D4:8@38",  # W10-12
    "G3:8@40 R:8", "D3:8@34 R:8", "G3:8@38 R:8",  # W13-15
    "D3:8@32 R:8", "G2:8@36 R:8", "G2:16@34"  # W16-18
]
for i, t in enumerate(v12_tones):
    w(f'{4530+i*10} PLAY 12,"{t}"')
w("")

# V13 - SANTUR RESONANCE: W7-15 (9 windows)
w("4710 REM === VOICE 13 - SANTUR RESONANCE =======================")
v13_schedule = [
    None, None, None, None, None, None,
    "HA1$+R8$", "R8$+HA2$", "HA2$+R8$",  # W7-9
    "HA3$+R8$", "R8$+HB3$", "HB3$+HA4$",  # W10-12
    "HA4$+R8$", "R8$+HA1$", "HA1$+R8$",  # W13-15
    None, None, None
]
for i, s in enumerate(v13_schedule):
    if s:
        w(f'{4720+i*10} PLAY 13,{s}')
    else:
        w(f'{4720+i*10} PLAY 13,R16$')
w("")

# V14 - HIGH TAR: W7-15 (9 windows)
w("4900 REM === VOICE 14 - HIGH TAR ANSWERS =======================")
v14_schedule = [
    None, None, None, None, None, None,
    "R8$+TA1$", "TA1$+TA2$", "TA2$+TA1$",  # W7-9
    "TA2$+TA2$", "TA2$+TA1$", "TA1$+TA2$",  # W10-12
    "TA1$+R8$", "R8$+TA1$", "R16$",  # W13-15
    None, None, None
]
for i, s in enumerate(v14_schedule):
    if s:
        w(f'{4910+i*10} PLAY 14,{s}')
    else:
        w(f'{4910+i*10} PLAY 14,R16$')
w("")

# V15 - DISTANT NEY: W7-15 (9 windows, very sparse)
w("5090 REM === VOICE 15 - DISTANT NEY SHADOW =====================")
v15_schedule = [
    None, None, None, None, None, None,
    "N1$", "R16$", "N2$",  # W7-9
    "R16$", "N3$", "R16$",  # W10-12
    "NF$", "R16$", "R16$",  # W13-15
    None, None, None
]
for i, s in enumerate(v15_schedule):
    if s:
        w(f'{5100+i*10} PLAY 15,{s}')
    else:
        w(f'{5100+i*10} PLAY 15,R16$')
w("")

# V16 - LOW SANTUR RESONANCE: all 18 windows
w("5280 REM === VOICE 16 - LOW SANTUR SYMPATHETIC RESONANCE ========")
v16_tones = [
    "G3:2@30 R:6 D4:2@32 R:6", "G3:2@32 R:6 D4:2@34 R:6", "G3:2@32 R:6 D4:2@34 R:6",  # W1-3
    "G3:2@34 D4:2@36 G4:2@38 D4:2@34", "G3:2@32 R:6 D4:2@34 R:6", "G3:2@34 D4:2@36 G4:2@38 D4:2@34",  # W4-6
    "G3:2@36 D4:2@38 G4:2@40 D4:2@36", "G3:2@38 D4:2@40 G4:2@42 D4:2@38", "G3:2@38 D4:2@40 G4:2@44 D4:2@40",  # W7-9
    "G3:2@40 D4:2@42 G4:2@46 D4:2@42", "G3:2@40 D4:2@42 G4:2@46 D4:2@42", "G3:2@38 D4:2@40 G4:2@44 D4:2@38",  # W10-12
    "G3:2@36 D4:2@38 G4:2@42 D4:2@36", "G3:2@34 D4:2@36 G4:2@40 D4:2@34", "G3:2@32 R:6 D4:2@34 R:6",  # W13-15
    "G3:2@30 R:6 D4:2@32 R:6", "Eb3:2@28 R:6 D3:2@30 R:6", "G3:8@32 R:8"  # W16-18
]
for i, t in enumerate(v16_tones):
    w(f'{5290+i*10} PLAY 16,"{t}"')
w("")

# Export and play
w("5470 REM === RENDER WAV AND BEGIN LIVE PLAYBACK =================")
w('5480 WAVEFILE "persian_dawn_three_minutes.wav"')
w("5490 SOUND RESUME")
w("5500 END")
w("")

# ============================================================
# VISUAL SCENE (GOSUB 5000)
# ============================================================
w("5510 REM ============================================================")
w("5520 REM  PERSIAN DAWN SCENE - ISFAHAN SKYLINE AT SUNRISE")
w("5530 REM  LAPIS SKY, SAFFRON HORIZON, DOMES, BRIDGE, CYPRESSES")
w("5540 REM ============================================================")
w('5550 SCREEN 1280,720,"#0B1228"')
w('5560 CLS "#0B1228"')
w("5570 REM === BANDED LAPIS-TO-SAFFRON DAWN =========================")
w('5580 RECTANGLE 0,0,1280,55,"#0E1838","#0E1838",1')
w('5590 RECTANGLE 0,55,1280,55,"#162856","#162856",1')
w('5600 RECTANGLE 0,110,1280,55,"#1E3870","#1E3870",1')
w('5610 RECTANGLE 0,165,1280,55,"#3A4678","#3A4678",1')
w('5620 RECTANGLE 0,220,1280,55,"#886078","#886078",1')
w('5630 RECTANGLE 0,275,1280,65,"#D58B68","#D58B68",1')
w("5640 REM === SUN WITH GLOW HALO ==================================")
w('5650 CIRCLE 1025,168,48,"#F8D995","#F8D995",2')
w('5660 CIRCLE 1025,168,60,"#F3B96A","none",3')
w('5670 CIRCLE 1025,168,72,"#E89A50","none",2')
w("5680 REM === DISTANT ZAGROS MOUNTAIN SILHOUETTES ==================")
w('5690 POLYGON (0,325),(120,248),(235,320),(365,238),(505,325),(650,255),(805,325),(965,240),(1110,318),(1280,255),(1280,360),(0,360),"#343657","#343657",1')
w('5700 POLYGON (0,342),(165,286),(315,342),(485,278),(660,345),(825,292),(1010,344),(1165,282),(1280,330),(1280,370),(0,370),"#262C4A","#262C4A",1')
w("5710 REM === ISFAHAN DOMES AND MINARETS ==========================")
w('5720 RECTANGLE 675,270,150,78,"#173248","#173248",1')
w('5730 CIRCLE 750,270,47,"#173248","#173248",1')
w('5740 LINE 750,210,750,222,"#E2B668",3')
w('5750 CIRCLE 750,207,4,"#E2B668","#E2B668",1')
w('5760 RECTANGLE 610,232,18,116,"#162D43","#162D43",1')
w('5770 CIRCLE 619,231,12,"#162D43","#162D43",1')
w('5780 LINE 619,198,619,221,"#E2B668",2')
w('5790 RECTANGLE 872,245,20,103,"#162D43","#162D43",1')
w('5800 CIRCLE 882,244,13,"#162D43","#162D43",1')
w('5810 LINE 882,208,882,233,"#E2B668",2')
w('5820 RECTANGLE 910,295,94,53,"#19364B","#19364B",1')
w('5830 CIRCLE 957,295,30,"#19364B","#19364B",1')
w("5835 REM === ZAYANDEH-RUD WATER ====================================")
w('5840 RECTANGLE 0,340,1280,55,"#183B57","#183B57",1')
w('5850 RECTANGLE 0,395,1280,55,"#164761","#164761",1')
w('5860 RECTANGLE 0,450,1280,55,"#1C566B","#1C566B",1')
w('5870 RECTANGLE 0,505,1280,55,"#286579","#286579",1')
w('5880 LINE 45,378,410,378,"#D9A76A",2')
w('5890 LINE 780,393,1210,393,"#E5BC78",2')
w('5900 LINE 180,472,635,472,"#74A8A6",2')
w('5910 LINE 700,505,1125,505,"#7EB1AD",2')
w("5920 REM === SI-O-SE-POL BRIDGE ===================================")
w('5930 RECTANGLE 54,345,1172,82,"#9E6040","#B9784B",3')
w('5940 RECTANGLE 42,337,1196,13,"#6D3B35","#D39A62",2')
w("5950 FOR X=105 TO 1175 STEP 74")
w('5960 CIRCLE X,398,25,"#173F59","#173F59",1')
w('5970 RECTANGLE X-25,398,50,31,"#173F59","#173F59",1')
w("5980 NEXT X")
w("5990 REM === BRIDGE REFLECTIONS =================================")
w("6000 FOR X=105 TO 1175 STEP 74")
w('6010 LINE X-18,438,X-9,495,"#8F704F",2')
w('6020 LINE X,438,X+5,507,"#C18E58",2')
w("6030 NEXT X")
w("6040 REM === CYPRESS TREES =======================================")
w('6050 RECTANGLE 82,365,13,155,"#172E36","#172E36",1')
w('6060 POLYGON (48,440),(88,228),(128,440),"#0F3C39","#0F3C39",2')
w('6070 POLYGON (57,394),(88,264),(119,394),"#155149","#155149",2')
w('6080 RECTANGLE 1180,365,13,155,"#172E36","#172E36",1')
w('6090 POLYGON (1144,440),(1187,218),(1230,440),"#0F3C39","#0F3C39",2')
w('6100 POLYGON (1154,392),(1187,254),(1220,392),"#155149","#155149",2')
w("6110 REM === PERSIAN MINIATURE BORDER ============================")
w('6120 RECTANGLE 12,12,1256,696,"#D6A94F","none",7')
w('6130 RECTANGLE 25,25,1230,670,"#2A8A83","none",3')
w('6140 RECTANGLE 35,35,1210,650,"#D6A94F","none",2')
w("6150 FOR X=58 TO 1220 STEP 58")
w('6160 CIRCLE X,28,5,"#68B6A9","#D6A94F",1')
w('6170 CIRCLE X,692,5,"#68B6A9","#D6A94F",1')
w("6180 NEXT X")
w("6190 FOR Y=58 TO 662 STEP 54")
w('6200 CIRCLE 28,Y,5,"#68B6A9","#D6A94F",1')
w('6210 CIRCLE 1252,Y,5,"#68B6A9","#D6A94F",1')
w("6220 NEXT Y")
w("6230 REM === FOREGROUND CARPET ===================================")
w('6240 POLYGON (190,562),(1060,562),(1165,677),(95,677),"#E1B058","#7B263B",4')
w('6250 POLYGON (260,580),(990,580),(1065,660),(180,660),"#D6A94F","#173C59",3')
w('6260 LINE 260,620,990,620,"#D6A94F",3')
w("6270 FOR X=300 TO 950 STEP 65")
w('6280 POLYGON (X,600),(X+18,620),(X,640),(X-18,620),"#D6A94F","#2E8B83",2')
w("6290 NEXT X")
w("6300 REM === SANTUR PLAYER AT CENTER ============================")
w('6310 CIRCLE 628,530,14,"#442739","#D8A06E",2')
w('6320 POLYGON (601,547),(655,547),(676,620),(580,620),"#31243B","#385B67",2')
w('6330 POLYGON (525,603),(730,603),(696,650),(555,650),"#D6A94F","#A96335",4')
w('6340 LINE 590,570,565,612,"#D8A06E",4')
w('6350 LINE 665,570,692,612,"#D8A06E",4')
w('6360 LINE 575,614,683,638,"#E7C073",2')
w("6370 REM === NEY PLAYER AT LEFT =================================")
w('6380 CIRCLE 332,540,14,"#442739","#D8A06E",2')
w('6390 POLYGON (308,558),(354,558),(372,628),(292,628),"#31243B","#394C70",2')
w('6400 LINE 350,570,420,540,"#D8A06E",3')
w('6410 LINE 420,540,440,528,"#D7AB61",2')
w("6420 REM === DAF PLAYER AT RIGHT ================================")
w('6430 CIRCLE 858,536,14,"#442739","#D8A06E",2')
w('6440 POLYGON (832,554),(883,554),(902,626),(815,626),"#31243B","#5A3B5D",2')
w('6450 CIRCLE 925,579,34,"#D6A94F","#8D3F34",5')
w('6460 CIRCLE 925,579,25,"#D6A94F","none",2')
w('6470 LINE 880,568,907,574,"#D8A06E",5')
w("6480 REM === WHIRLING SUFI FIGURE ================================")
w('6490 CIRCLE 1082,526,13,"#442739","#D8A06E",2')
w('6500 RECTANGLE 1073,539,18,48,"#E8D7B5","#E8D7B5",1')
w('6510 LINE 1082,550,1030,570,"#E8D7B5",7')
w('6520 LINE 1082,550,1138,566,"#E8D7B5",7')
w('6530 POLYGON (1082,575),(1007,649),(1157,649),"#D9C7A5","#D9C7A5",2')
w('6540 LINE 1032,615,1132,615,"#B24D47",3')
w("6550 REM === TITLE CARTOUCHE =====================================")
w('6560 RECTANGLE 405,50,470,58,"#D6A94F","#13294A",3')
w('6570 TEXT 459,77,26,"PERSIAN DAWN AT ESFAHAN","#F1D38B"')
w('6580 TEXT 496,99,15,"THREE-MINUTE SUFI JOURNEY","#72C0B2"')
w('6590 RENDER "persian_dawn_scene.svg"')
w("6600 DISPLAY")
w("6610 RETURN")

# Write the file
content = "\n".join(lines) + "\n"
with open(OUT, "w") as f:
    f.write(content)

print(f"\nFile written: {OUT}")
print(f"Total lines: {len(lines)}")
print(f"File size: {len(content)} bytes")