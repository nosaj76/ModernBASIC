# ModernBASIC examples

Run these commands from the repository root:

```sh
./target/release/modernbasic run programs/examples/hello.bas
./target/release/modernbasic run programs/examples/input.bas
./target/release/modernbasic shell programs/examples/graphics.bas
```

| Program | Purpose |
| --- | --- |
| `hello.bas` | Core arithmetic, functions, date, time, and output. |
| `input.bas` | Runtime terminal input. |
| `matrix.bas` | Dartmouth-style matrix operations. |
| `graphics.bas` | Native graphical drawing. |
| `perspective_world.bas` | Retained X/Y/Z objects projected, depth-scaled, and lit on the 2D canvas. |
| `music.bas` | Built-in synthesizer features. |
| `native_audio.bas` | Self-contained oscillator synthesis and WAV export. |
| `synth_patch.bas` | Three-oscillator native instrument with filter contour, LFO, glide, and drive. |
| `configurable_synth.bas` | Per-program 12-voice, six-oscillator synthesis arrangement. |
| `soundfont.bas` | Sampled piano, strings, cello, flute, and drums with MIDI dynamics and effects. |
| `artist_demo.bas` | Integrated Artist-derived renderer. |
| `chat.bas` | Portable local interactive text example. |

Graphical examples require the Linux/X11 shell. Live audio prefers `paplay` and
falls back to `aplay`; native WAV generation needs neither. `soundfont.bas`
uses the bank installed by `./install-soundfont.sh` or another project/system
bank described in the main audio reference.
