# ModernBASIC program catalog

Run programs from the repository root with the release binary:

```sh
./target/release/modernbasic run programs/examples/hello.bas
./target/release/modernbasic run programs/games/guess.bas
./target/release/modernbasic shell programs/demos/bouncing_ball.bas
```

## Directory guide

| Directory | Contents |
| --- | --- |
| `examples/` | Small programs demonstrating core input, matrix, graphics, music, and renderer features. |
| `demos/` | Larger ModernBASIC demonstrations, including graphical programs. |
| `calculators/`, `games/`, `music/`, `navigation/`, `word/` | Ported program collections using the current 0.8 statement set. `music/magnetic_dawn.bas` is an original extended native-synthesis showcase. Some programs require interactive input, X11, or audio. |
| `tests/` | BASIC diagnostics and manual regression programs; the automated Rust suite is run by `./verify.sh`. |

Use `./target/release/modernbasic help` for command-line options. BASIC file access remains confined to the configured `--file-root`.

The repository tracks 345 numbered `.bas` files. They have unique,
increasing line numbers and contain none of the removed `MUSIC`, `VOLUME`,
`STRUM`, `HIT`, `SID`, `SYNTH`, `CHARDEF`, or TCP statement families. The
release smoke test enforces those invariants for `.bas` and `.BAS` names and
also rejects empty source files.
